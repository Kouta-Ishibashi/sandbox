Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u971C\u5D0E\u6843\u591C",
      "screen_name" : "shimo_zaki",
      "indices" : [ 3, 14 ],
      "id_str" : "110304270",
      "id" : 110304270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41705107292692480",
  "text" : "RT @shimo_zaki: \u3010\u62E1\u6563\u5E0C\u671B\u3011\u30A2\u30CB\u30E1\u30A4\u30C8\u3067\u8A71\u3057\u304B\u3051\u3089\u308C\u3001\u540C\u3058\u8DA3\u5473\u3092\u6301\u3063\u305F\u4EF2\u9593\u3092\u88C5\u308F\u308C(\u591A\u5C11\u306F\u30A2\u30CB\u30E1\u306A\u3069\u306E\u77E5\u8B58\u3092\u5165\u308C\u3066\u3044\u308B)\u3001\u5B97\u6559\u306E\u52E7\u8A98\u3092\u3055\u308C\u307E\u3057\u305F\u3002\u7686\u3055\u307E\u6C17\u3092\u3064\u3051\u3066\uFF01\uFF01\u305D\u3046\u3044\u3046\u6C5A\u3044\u624B\u53E3\u3067\u52E7\u8A98\u3084\u3089\u304C\u5897\u3048\u3066\u307E\u3059\uFF01\uFF01\u3010\u62E1\u6563\u5E0C\u671B\u3011",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41410294613807104",
    "text" : "\u3010\u62E1\u6563\u5E0C\u671B\u3011\u30A2\u30CB\u30E1\u30A4\u30C8\u3067\u8A71\u3057\u304B\u3051\u3089\u308C\u3001\u540C\u3058\u8DA3\u5473\u3092\u6301\u3063\u305F\u4EF2\u9593\u3092\u88C5\u308F\u308C(\u591A\u5C11\u306F\u30A2\u30CB\u30E1\u306A\u3069\u306E\u77E5\u8B58\u3092\u5165\u308C\u3066\u3044\u308B)\u3001\u5B97\u6559\u306E\u52E7\u8A98\u3092\u3055\u308C\u307E\u3057\u305F\u3002\u7686\u3055\u307E\u6C17\u3092\u3064\u3051\u3066\uFF01\uFF01\u305D\u3046\u3044\u3046\u6C5A\u3044\u624B\u53E3\u3067\u52E7\u8A98\u3084\u3089\u304C\u5897\u3048\u3066\u307E\u3059\uFF01\uFF01\u3010\u62E1\u6563\u5E0C\u671B\u3011",
    "id" : 41410294613807104,
    "created_at" : "2011-02-26 08:12:38 +0000",
    "user" : {
      "name" : "\u971C\u5D0E\u6843\u591C",
      "screen_name" : "shimo_zaki",
      "protected" : false,
      "id_str" : "110304270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596920432764194816\/YFDEFm50_normal.jpg",
      "id" : 110304270,
      "verified" : false
    }
  },
  "id" : 41705107292692480,
  "created_at" : "2011-02-27 03:44:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41397067280695296",
  "geo" : { },
  "id_str" : "41411288491884544",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u82F1\u8A9E\u306F\u3068\u3082\u304B\u304F\u3001\u6587\u7CFB\u6570\u5B66\u306F\u9AA8\u304C\u306A\u3055\u904E\u304E\u305F\u3088\u306A\u3002\uFF16\uFF10\u5206\u3067\u3082\u89E3\u3051\u308B\u30EC\u30D9\u30EB\u3002",
  "id" : 41411288491884544,
  "in_reply_to_status_id" : 41397067280695296,
  "created_at" : "2011-02-26 08:16:35 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41254000359645184",
  "text" : "\u7720\u3044\u4E0A\u306B\u96EA\u3060\u3057\u306D\u3047",
  "id" : 41254000359645184,
  "created_at" : "2011-02-25 21:51:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41253887700631552",
  "text" : "\uFF17\u6642\u304B\u3089\u8ECA\u306E\u7DF4\u7FD2\u3068\u304B\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0",
  "id" : 41253887700631552,
  "created_at" : "2011-02-25 21:51:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41253749548646401",
  "text" : "\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u2606\u6559\u7FD2\uFF6F\uFF01",
  "id" : 41253749548646401,
  "created_at" : "2011-02-25 21:50:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41126182103547904",
  "geo" : { },
  "id_str" : "41129805856374784",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u30BD\u30EA\u30C6\u30A3\u30A2\u306F\u30BF\u30A4\u30E0\u30A2\u30BF\u30C3\u30AF\u30AA\u30B9\u30B9\u30E1\u3000\u3042\u3068\u30D5\u30EA\u30FC\u30BB\u30EB\u306E\u3053\u3068\u3082\u305F\u307E\u306B\u306F\u601D\u3044\u51FA\u3057\u3066\u3042\u3052\u3066\u304F\u3060\u3055\u3044\u3002",
  "id" : 41129805856374784,
  "in_reply_to_status_id" : 41126182103547904,
  "created_at" : "2011-02-25 13:38:04 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E9C\u5B63\u3002",
      "screen_name" : "aki_1909",
      "indices" : [ 3, 12 ],
      "id_str" : "61257065",
      "id" : 61257065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41125217883394048",
  "text" : "RT @aki_1909: \u5404\u5C40\u306E\u5730\u9707\u5831\u9053\u306E\u5DEE\n\u65E5\u30C6\u30EC\u300C\u5730\u9707\u306E\u73FE\u5834\u3067\u306F\u3053\u3093\u306A\u6700\u65B0\u6A5F\u5668\u304C\u4F7F\u308F\u308C\u3066\u3044\u307E\u3059\u300D\n\u30C6\u30EC\u671D\u300C\u65E5\u672C\u306E\u653F\u5E9C\u306F\u3053\u3093\u306A\u6642\u306B\u306A\u306B\u3084\u3063\u3066\u308B\u3093\u3060\u300D\n\uFF34\uFF22\uFF33\u300C\u541B\u306F\u52A9\u3051\u51FA\u3055\u308C\u305F\u3051\u3069\u3001\u53CB\u9054\u306F\u307E\u3060\u74E6\u792B\u306E\u4E0B\u3060\u306D\u300D\n\u30D5\u30B8\u300C\u6551\u51FA\u3055\u308C\u305F\u3051\u3069\u8DB3\u5207\u3089\u308C\u3061\u3083\u3063\u3066\u3082\u3046\u30B9\u30DD\u30FC\u30C4\u51FA\u6765\u306A\u3044\u306D\u3063\u300D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flight.co.jp\/iPhone\/TweetMe\/\" rel=\"nofollow\"\u003ETweetMe for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41095643367735296",
    "text" : "\u5404\u5C40\u306E\u5730\u9707\u5831\u9053\u306E\u5DEE\n\u65E5\u30C6\u30EC\u300C\u5730\u9707\u306E\u73FE\u5834\u3067\u306F\u3053\u3093\u306A\u6700\u65B0\u6A5F\u5668\u304C\u4F7F\u308F\u308C\u3066\u3044\u307E\u3059\u300D\n\u30C6\u30EC\u671D\u300C\u65E5\u672C\u306E\u653F\u5E9C\u306F\u3053\u3093\u306A\u6642\u306B\u306A\u306B\u3084\u3063\u3066\u308B\u3093\u3060\u300D\n\uFF34\uFF22\uFF33\u300C\u541B\u306F\u52A9\u3051\u51FA\u3055\u308C\u305F\u3051\u3069\u3001\u53CB\u9054\u306F\u307E\u3060\u74E6\u792B\u306E\u4E0B\u3060\u306D\u300D\n\u30D5\u30B8\u300C\u6551\u51FA\u3055\u308C\u305F\u3051\u3069\u8DB3\u5207\u3089\u308C\u3061\u3083\u3063\u3066\u3082\u3046\u30B9\u30DD\u30FC\u30C4\u51FA\u6765\u306A\u3044\u306D\u3063\u300D\n\u30C6\u30EC\u6771\u300C\u6765\u9031\u3082\u307F\u3066\u306D\uFF01\uFF08\u30A2\u30CB\u30E1\uFF09\u300D",
    "id" : 41095643367735296,
    "created_at" : "2011-02-25 11:22:19 +0000",
    "user" : {
      "name" : "\u4E9C\u5B63\u3002",
      "screen_name" : "aki_1909",
      "protected" : false,
      "id_str" : "61257065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555378120815951872\/rZpg6IbN_normal.jpeg",
      "id" : 61257065,
      "verified" : false
    }
  },
  "id" : 41125217883394048,
  "created_at" : "2011-02-25 13:19:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41108349726490624",
  "text" : "\u3042\u30FC\u4E00\u65E5\u4E00\u30C4\u30A4\u30FC\u30C8\u65E9\u304F\u3082\u5B88\u3089\u308C\u3066\u3044\u306A\u3044\uFF57",
  "id" : 41108349726490624,
  "created_at" : "2011-02-25 12:12:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40311241557676032",
  "geo" : { },
  "id_str" : "40311909106323457",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3093\uFF1F",
  "id" : 40311909106323457,
  "in_reply_to_status_id" : 40311241557676032,
  "created_at" : "2011-02-23 07:28:02 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u5927\u7528\u8A9E\u4E8B\u5178",
      "screen_name" : "kyodaijiten",
      "indices" : [ 3, 15 ],
      "id_str" : "225923044",
      "id" : 225923044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40311059831066624",
  "text" : "RT @kyodaijiten: \u4EAC\u5927\u672C\u90E8\u69CB\u5185\u3067\u53D7\u9A13\u3055\u308C\u308B\u65B9\u3078\u3002\u672C\u90E8\u306F\u73FE\u5728\u5DE5\u4E8B\u4E2D\u306E\u305F\u3081\u81F3\u308B\u3068\u3053\u308D\u304C\u901A\u884C\u7981\u6B62\u306B\u306A\u3063\u3066\u3044\u307E\u3059\u3002\u4E0B\u898B\u3092\u6B20\u304B\u3055\u306A\u3044\u3088\u3046\u306B\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40305005428740096",
    "text" : "\u4EAC\u5927\u672C\u90E8\u69CB\u5185\u3067\u53D7\u9A13\u3055\u308C\u308B\u65B9\u3078\u3002\u672C\u90E8\u306F\u73FE\u5728\u5DE5\u4E8B\u4E2D\u306E\u305F\u3081\u81F3\u308B\u3068\u3053\u308D\u304C\u901A\u884C\u7981\u6B62\u306B\u306A\u3063\u3066\u3044\u307E\u3059\u3002\u4E0B\u898B\u3092\u6B20\u304B\u3055\u306A\u3044\u3088\u3046\u306B\uFF01",
    "id" : 40305005428740096,
    "created_at" : "2011-02-23 07:00:36 +0000",
    "user" : {
      "name" : "\u4EAC\u5927\u7528\u8A9E\u4E8B\u5178",
      "screen_name" : "kyodaijiten",
      "protected" : false,
      "id_str" : "225923044",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 225923044,
      "verified" : false
    }
  },
  "id" : 40311059831066624,
  "created_at" : "2011-02-23 07:24:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5343\u539F\u6B66@kaku-butsu",
      "screen_name" : "chinko_mama",
      "indices" : [ 3, 15 ],
      "id_str" : "205587478",
      "id" : 205587478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40163325824204800",
  "text" : "RT @chinko_mama: \uFF21\u5B50\u300C\u3042\u305F\u3057\u3001\u5148\u8F29\u306E\u3053\u3068B\u5B50\u3088\u308A\u308210\u500D\u306F\u597D\u304D\u3067\u3059\uFF01\u300DB\u5B50\u300C\u3042\u305F\u3057\u3053\u305D\u3001\u5148\u8F29\u306E\u3053\u3068A\u5B50\u3088\u308A\u308210\u500D\u306F\u597D\u304D\u3067\u3059\uFF01\u300D\u7406\u7CFB\u7537\u5B50\u300C\u4E8C\u4EBA\u306E\u4E3B\u5F35\u304C\u6210\u308A\u7ACB\u3064\u3068\u304D\u3001\u541B\u305F\u3061\u306E\u50D5\u3078\u306E\u611B\u60C5\u306F\u5171\u306B0\u3060\u30FB\u30FB\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33842821320552448",
    "text" : "\uFF21\u5B50\u300C\u3042\u305F\u3057\u3001\u5148\u8F29\u306E\u3053\u3068B\u5B50\u3088\u308A\u308210\u500D\u306F\u597D\u304D\u3067\u3059\uFF01\u300DB\u5B50\u300C\u3042\u305F\u3057\u3053\u305D\u3001\u5148\u8F29\u306E\u3053\u3068A\u5B50\u3088\u308A\u308210\u500D\u306F\u597D\u304D\u3067\u3059\uFF01\u300D\u7406\u7CFB\u7537\u5B50\u300C\u4E8C\u4EBA\u306E\u4E3B\u5F35\u304C\u6210\u308A\u7ACB\u3064\u3068\u304D\u3001\u541B\u305F\u3061\u306E\u50D5\u3078\u306E\u611B\u60C5\u306F\u5171\u306B0\u3060\u30FB\u30FB\u300D",
    "id" : 33842821320552448,
    "created_at" : "2011-02-05 11:02:12 +0000",
    "user" : {
      "name" : "\u5343\u539F\u6B66@kaku-butsu",
      "screen_name" : "chinko_mama",
      "protected" : false,
      "id_str" : "205587478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1178995520\/cba6e7a8-b1aa-44cf-8fcf-c99fa7d348b5_normal.jpg",
      "id" : 205587478,
      "verified" : false
    }
  },
  "id" : 40163325824204800,
  "created_at" : "2011-02-22 21:37:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39876368640507904",
  "text" : "\u5C71\u5F62\u306A\u3046\u3002\u6771\u306B\u5317\u306B\u5FD9\u3057\u3044\u3002",
  "id" : 39876368640507904,
  "created_at" : "2011-02-22 02:37:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39649063519391745",
  "text" : "\u307E\u3041\u5B89\u624B\u306B\u3057\u304B\u632F\u308A\u8FBC\u3093\u3067\u306A\u3044\u304B\u3089\u826F\u3044\u304B\u306A\u30025200\u306F\u75DB\u304B\u3063\u305F\u3051\u3069\u2190",
  "id" : 39649063519391745,
  "created_at" : "2011-02-21 11:34:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39648867112722432",
  "text" : "\u30DE\u30F3\u30AC\u30F3\u4EE5\u4E0A\u306E\u624B\u304C\u51FA\u3066\u306A\u304B\u3063\u305F\u304B\u3089\u3001\u3068\u8A00\u3046\u5E78\u904B\u304B\u3002",
  "id" : 39648867112722432,
  "created_at" : "2011-02-21 11:33:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39648638363766784",
  "text" : "\u6771\u5834\u3067\u5168\u304F\u548C\u4E86\u308C\u306A\u304B\u3063\u305F\u306A\u3041\u3002\u5357\uFF12\u3001\u5357\uFF13\u304B\u3089\u3042\u304C\u308A\u59CB\u3081\u3066\u4E00\u4F4D\u3001\u4E8C\u4F4D\u3002\u7D50\u679C\u306F\u826F\u3044\u304C\u5FC3\u81D3\u306B\u306F\u60AA\u3044\u3002",
  "id" : 39648638363766784,
  "created_at" : "2011-02-21 11:32:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39235840144052224",
  "geo" : { },
  "id_str" : "39236082100862976",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308C\u306F\u30E4\u30D0\u3044\uFF57\uFF57\uFF57",
  "id" : 39236082100862976,
  "in_reply_to_status_id" : 39235840144052224,
  "created_at" : "2011-02-20 08:13:05 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39226837301202944",
  "geo" : { },
  "id_str" : "39232292006141952",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6C17\u306B\u3059\u308B\u306A\u3002\u30C4\u30A4\u30C3\u30BF\u30FC\u306A\u3093\u3066\u305D\u3082\u305D\u3082\u30C1\u30E9\u30B7\u306E\u88CF\u307F\u305F\u3044\u306A\u3082\u3093\u3060\u304B\u3089\u3002",
  "id" : 39232292006141952,
  "in_reply_to_status_id" : 39226837301202944,
  "created_at" : "2011-02-20 07:58:01 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39192944233684992",
  "text" : "retrospective\u4E2D\u592E\u7DDA",
  "id" : 39192944233684992,
  "created_at" : "2011-02-20 05:21:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39190953898020864",
  "text" : "\u3042\u3068\u30A8\u30B9\u30AB\u30EC\u30FC\u30BF\u30FC\u306E\u8FFD\u3044\u8D8A\u3057\u8ECA\u7DDA\uFF08\uFF1F\uFF09\u306E\u5DE6\u53F3\u306B\u6238\u60D1\u3046",
  "id" : 39190953898020864,
  "created_at" : "2011-02-20 05:13:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39190791523926016",
  "text" : "\u65B0\u5E79\u7DDA\u3060\u3068\u6642\u9593\u306B\u5BFE\u3057\u3066\u611F\u899A\u304C\u79FB\u52D5\u306B\u3064\u3044\u3066\u3053\u306A\u3044\u3093\u3060\u3088\u306A\u30FC\u3002",
  "id" : 39190791523926016,
  "created_at" : "2011-02-20 05:13:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39190332847427585",
  "text" : "\u3082\u3046\u3061\u3087\u3044\u3067\u6771\u4EAC",
  "id" : 39190332847427585,
  "created_at" : "2011-02-20 05:11:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39179135527944192",
  "text" : "\u79FB\u52D5\u4E2D\u3001\u672C\u3092\u8AAD\u307F\u7D42\u3048\u308B\u306E\u306F\u3069\u3046\u3057\u3066\u5230\u7740\u76F4\u524D\u3058\u3083\u306A\u3044\u3093\u3060\u308D\u3046\u3002",
  "id" : 39179135527944192,
  "created_at" : "2011-02-20 04:26:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39131608636203008",
  "geo" : { },
  "id_str" : "39134255367852032",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u666E\u901A\u306B\u3084\u3093\u308F\u308A\u65AD\u308B\u306E\u306B\u4F7F\u3046\u3051\u3069\u306A\u3002\u771F\u306B\u884C\u3051\u305F\u3089\u884C\u304F\u5834\u5408\u3082\u78BA\u304B\u306B\u3042\u308B\u304C\u3002\u65B9\u8A00\u3066\u304B\u65B9\u4FBF\u3060\u306A\u2190",
  "id" : 39134255367852032,
  "in_reply_to_status_id" : 39131608636203008,
  "created_at" : "2011-02-20 01:28:28 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39117959460823040",
  "text" : "\u6700\u8FD1\u79FB\u52D5\u3057\u3063\u3071\u306A\u3057\u3060\u306A\u3041\u3002",
  "id" : 39117959460823040,
  "created_at" : "2011-02-20 00:23:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38984733639720960",
  "text" : "@koketomi \u3064\u68A8 \u5265\u304D\u3059\u304E\u3066\u98DF\u3079\u304D\u308C\u306A\u3044orz",
  "id" : 38984733639720960,
  "created_at" : "2011-02-19 15:34:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38902670055972864",
  "text" : "@koketomi \u622F\u4E8B\u30CA\u30EA",
  "id" : 38902670055972864,
  "created_at" : "2011-02-19 10:08:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38898836722155520",
  "geo" : { },
  "id_str" : "38902415361052672",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u3059\u308C\u9055\u3046\u306D\u3047\u3002\u514D\u8A31\u5408\u5BBF\u884C\u304F\u304B\u3089\u6771\u4EAC\u306B\u3044\u308B\u306E\u306F\u6570\u65E5\u3060\u304B\u3089\u3061\u3087\u3063\u3068\u53B3\u3057\u3044\u304B\u3082\u306D\u3002",
  "id" : 38902415361052672,
  "in_reply_to_status_id" : 38898836722155520,
  "created_at" : "2011-02-19 10:07:13 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38893009755967488",
  "geo" : { },
  "id_str" : "38896483717619712",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u3084\u3001\u4EAC\u90FD\u99C5\u306A\u3046\u3002 \u660E\u65E5\u306E\u5348\u524D\u4E2D\u306B\u767A\u3064\u3088\u3002\u5411\u3053\u3046\u3067\u4F1A\u3048\u305F\u3089\u9762\u767D\u304B\u3063\u305F\u304C\u3042\u3044\u306B\u304F\u7121\u7406\u3063\u307D\u3044\u3002\u30B9\u30AB\u30A4\u30D7\u5165\u308C\u305F\u3089ID\u6559\u3048\u3066\u304F\u308C\u3043",
  "id" : 38896483717619712,
  "in_reply_to_status_id" : 38893009755967488,
  "created_at" : "2011-02-19 09:43:39 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38892470469132289",
  "geo" : { },
  "id_str" : "38892686400290816",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3081\u3063\u3061\u3083\u4FBF\u5229\u3088\u3002\u30AA\u30B9\u30B9\u30E1\uFF01",
  "id" : 38892686400290816,
  "in_reply_to_status_id" : 38892470469132289,
  "created_at" : "2011-02-19 09:28:33 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38889743630475264",
  "text" : "\u3093\u30FC\u3001\u30D0\u30B9\u306B\u4E57\u3063\u305F\u306F\u3044\u3044\u304C\u4E07\u672D\u3068\uFF11\uFF19\uFF10\u5186\u3057\u304B\u7121\u3044\u3053\u3068\u306B\u6C17\u3065\u3044\u3066\u3057\u307E\u3063\u305F\u3002\u5982\u4F55\u306B\u305B\u3093\u3002",
  "id" : 38889743630475264,
  "created_at" : "2011-02-19 09:16:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 25, 35 ]
    }, {
      "text" : "sm4516291",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/bNElPv5",
      "expanded_url" : "http:\/\/nico.ms\/sm4516291",
      "display_url" : "nico.ms\/sm4516291"
    } ]
  },
  "geo" : { },
  "id_str" : "38833386768306176",
  "text" : "\u30C9\u3068\u30EC\u3068\u30DF\u306E\u97F3\u304C\u51FA\u306A\u3044\u30C8\u30EB\u30B3\u884C\u9032\u66F2 (2:46) #nicovideo #sm4516291 http:\/\/t.co\/bNElPv5 \u6C17\u6301\u3061\u60AA\u3044\u3051\u3069\u306A\u305C\u304B\u611F\u52D5\u3067\u304D\u308B\u4E0D\u601D\u8B70",
  "id" : 38833386768306176,
  "created_at" : "2011-02-19 05:32:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38806603037671424",
  "geo" : { },
  "id_str" : "38815510447529984",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u660E\u65E5\u5E30\u308A\u307E\u3059\u30FC\u3002\u3064\u307E\u308A\u5E30\u308A\u969B\u3063\u3066\u306E\u306F\u5E30\u7701\u3059\u308B\u9014\u4E2D\u3067\u3001\u307F\u305F\u3044\u306A\u610F\u5473\u3001\u5206\u304B\u308A\u306B\u304F\u304F\u3066\u3054\u3081\u3093\u3088\u30FC\u3002",
  "id" : 38815510447529984,
  "in_reply_to_status_id" : 38806603037671424,
  "created_at" : "2011-02-19 04:21:53 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38794003298123776",
  "text" : "\u5409\u7965\u5BFA\u30D1\u30EB\u30B3\u306E\u30D5\u30E9\u30AF\u30BF\u30EB\u5C55\u3063\u3066\u3044\u3064\u307E\u3067\u3084\u3063\u3066\u3093\u306E\u304B\u306A\uFF1F\u660E\u65E5\u3042\u305F\u308A\u5E30\u308A\u969B\u306B\u884C\u3063\u3066\u307F\u3088\u3046\u3002\u539F\u753B\u7B49\u3005\u306F\u3068\u3082\u304B\u304F\u30D5\u30E9\u30AF\u30BF\u30EB\u56F3\u5F62\u304C\u898B\u3089\u308C\u308B\u3068\u3044\u3044\u306A\u3002",
  "id" : 38794003298123776,
  "created_at" : "2011-02-19 02:56:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38761474201485312",
  "geo" : { },
  "id_str" : "38774419757211650",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6771\u4EAC\u3044\u3064\u884C\u304F\u306E\uFF1F",
  "id" : 38774419757211650,
  "in_reply_to_status_id" : 38761474201485312,
  "created_at" : "2011-02-19 01:38:36 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38574023386337280",
  "text" : "\u6E80\u6708\u304C\u5947\u9E97\u3060",
  "id" : 38574023386337280,
  "created_at" : "2011-02-18 12:22:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38477344175820800",
  "geo" : { },
  "id_str" : "38477927582539777",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u82B1\u7C89\uFF1F\u98A8\u90AA\uFF1F",
  "id" : 38477927582539777,
  "in_reply_to_status_id" : 38477344175820800,
  "created_at" : "2011-02-18 06:00:27 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38434898800803840",
  "geo" : { },
  "id_str" : "38468147333955584",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30B9\u30AD\u30FC\u30B9\u30CE\u30DC\u30FC\u3057\u3066\u53C2\u308A\u307E\u3057\u305F\u3002",
  "id" : 38468147333955584,
  "in_reply_to_status_id" : 38434898800803840,
  "created_at" : "2011-02-18 05:21:35 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38433665704787968",
  "text" : "\u5168\u8EAB\u8ED2\u4E26\u307F\u7B4B\u8089\u75DB\u306A\u3046",
  "id" : 38433665704787968,
  "created_at" : "2011-02-18 03:04:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30CB\u30E1 \u30D5\u30E9\u30AF\u30BF\u30EB",
      "screen_name" : "fractale_system",
      "indices" : [ 3, 19 ],
      "id_str" : "219889700",
      "id" : 219889700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fractaleanime",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38331115127185408",
  "text" : "RT @fractale_system: \u5409\u7965\u5BFA\u30D1\u30EB\u30B3B1F\u30CE\u30A4\u30BF\u30DF\u30CA\u30B7\u30E7\u30C3\u30D7\u306B\u3066\u300C\u30D5\u30E9\u30AF\u30BF\u30EB\u5C55\u300D\u958B\u50AC\u4E2D\uFF01\u7D75\u30B3\u30F3\u30C6\u3001\u7F8E\u8853\u8A2D\u5B9A\u3001\u30B3\u30DF\u30C3\u30AF\u7248\u8907\u88FD\u539F\u753B\u306A\u3069\u8CB4\u91CD\u306A\u8CC7\u6599\u3092\u5C55\u793A\u30022\/19(\u571F)\u306F\u5C0F\u6797\u3086\u3046\u3055\u3093\u304C\u4E00\u65E5\u5E97\u9577\u306B!\u3000\u8A73\u7D30\u2192\u3000http:\/\/bit.ly\/fHWGqi\u3000#fract ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fractaleanime",
        "indices" : [ 109, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38271926791045120",
    "text" : "\u5409\u7965\u5BFA\u30D1\u30EB\u30B3B1F\u30CE\u30A4\u30BF\u30DF\u30CA\u30B7\u30E7\u30C3\u30D7\u306B\u3066\u300C\u30D5\u30E9\u30AF\u30BF\u30EB\u5C55\u300D\u958B\u50AC\u4E2D\uFF01\u7D75\u30B3\u30F3\u30C6\u3001\u7F8E\u8853\u8A2D\u5B9A\u3001\u30B3\u30DF\u30C3\u30AF\u7248\u8907\u88FD\u539F\u753B\u306A\u3069\u8CB4\u91CD\u306A\u8CC7\u6599\u3092\u5C55\u793A\u30022\/19(\u571F)\u306F\u5C0F\u6797\u3086\u3046\u3055\u3093\u304C\u4E00\u65E5\u5E97\u9577\u306B!\u3000\u8A73\u7D30\u2192\u3000http:\/\/bit.ly\/fHWGqi\u3000#fractaleanime",
    "id" : 38271926791045120,
    "created_at" : "2011-02-17 16:21:53 +0000",
    "user" : {
      "name" : "\u30A2\u30CB\u30E1 \u30D5\u30E9\u30AF\u30BF\u30EB",
      "screen_name" : "fractale_system",
      "protected" : false,
      "id_str" : "219889700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1185917529\/fractalesystem_normal.jpg",
      "id" : 219889700,
      "verified" : false
    }
  },
  "id" : 38331115127185408,
  "created_at" : "2011-02-17 20:17:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37489045265195008",
  "text" : "\u52E2\u3044\u3067\u4E00\u554F\u3002\u300C\uFF21\u306F\uFF22\u3067\u3042\u308B\u3002\uFF21\u306F\uFF22\u3067\u306A\u3044\u3002\u300D\u4E21\u65B9\u306E\u6587\u304C\u6210\u308A\u7ACB\u3064\u3088\u3046\u306B\uFF21\u3001\uFF22\u306B\u8A9E\u53E5\u3092\u57CB\u3081\u3088\u3002\u53CB\u4EBA\u306E\u53D7\u3051\u58F2\u308A\u3060\u304C\u3002",
  "id" : 37489045265195008,
  "created_at" : "2011-02-15 12:30:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37487111363887104",
  "text" : "\u7720\u3044\u3068\u304D\u306B\u9192\u3081\u308B\u304B\u7720\u308B\u304B\u306E\u7A76\u6975\u306E\uFF12\u629E\u3092\u63D0\u4F9B\u3059\u308B\u306E\u306F\u6570\u5B66\u306E\u554F\u984C\u3002\u591A\u304F\u306E\u4EBA\u306B\u306F\u5F8C\u8005\u3060\u308D\u3046\u3057\u81EA\u5206\u3082\u5927\u62B5\u5F8C\u8005\u3060\u3051\u3069\u3002",
  "id" : 37487111363887104,
  "created_at" : "2011-02-15 12:23:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37465190488346624",
  "text" : "\u5206\u304B\u3063\u3061\u3083\u3044\u305F\u304C\u7761\u9B54\u304C\u2026\u3002\u3042\u3068\uFF12\u6642\u9593\u306F\u9000\u3051\u7D9A\u3051\u306A\u3051\u308C\u3070\u2026\u3002",
  "id" : 37465190488346624,
  "created_at" : "2011-02-15 10:56:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37459341413982208",
  "text" : "\u30AA\u30FC\u30EB\u30C9\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u306A\u3082\u306E\u306F\u3001\u6642\u3068\u3057\u3066\u65B0\u3057\u3044\u3082\u306E\u3088\u308A\u9762\u767D\u3044\u3002",
  "id" : 37459341413982208,
  "created_at" : "2011-02-15 10:32:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37441950059597824",
  "text" : "\u5C0F\u3055\u306A\u7070\u8272\u306E\u8133\u7D30\u80DE",
  "id" : 37441950059597824,
  "created_at" : "2011-02-15 09:23:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37379788800925696",
  "geo" : { },
  "id_str" : "37391234339176449",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 3m\u304F\u3089\u3044\u3042\u308B\u56DE\u89A7\u677F\u3092\u4F5C\u308C\u3070\u3044\u3044\uFF01",
  "id" : 37391234339176449,
  "in_reply_to_status_id" : 37379788800925696,
  "created_at" : "2011-02-15 06:02:19 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37377232884203520",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u90E8\u5C4B\u306E\u304B\u305F\u305A\u5BB6\u3092\u306C\u308B\u306C\u308B\u3084\u308D\u3046\uFF57",
  "id" : 37377232884203520,
  "created_at" : "2011-02-15 05:06:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37377152403898371",
  "text" : "\u4E45\u3005\u306B10\u6642\u306B\u8D77\u304D\u3066\u307F\u305F\u306E\u306F\u3044\u3044\u3051\u308C\u3069\u3001\u5B9F\u8CEA\u7761\u7720\u6642\u95933\uFF5E4\u6642\u9593\u30FB\u30FB\u30FB\u307E\u3041\u3053\u306E\u4E00\u9031\u9593\u30EA\u30BA\u30E0\u9177\u304B\u3063\u305F\u304B\u3089\u3044\u3044\u304B\u306A\uFF1F",
  "id" : 37377152403898371,
  "created_at" : "2011-02-15 05:06:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37168958666702848",
  "geo" : { },
  "id_str" : "37169677679468546",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6700\u5F37\u306A\u306E\u306F\u57FC\u4EAC\u7DDA\u3058\u3083\u306A\u3044\u306E\u304B\uFF1F\u2026\u30B5\u30FC\u7DDA\uFF57\uFF57\uFF57",
  "id" : 37169677679468546,
  "in_reply_to_status_id" : 37168958666702848,
  "created_at" : "2011-02-14 15:21:56 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6E96\u6025\u304F\u304D",
      "screen_name" : "semiexp",
      "indices" : [ 3, 11 ],
      "id_str" : "19898621",
      "id" : 19898621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37140153520623616",
  "text" : "RT @semiexp: \u305F\u307E\u306B\u805E\u304F\u300C\u30DB\u30EF\u30A4\u30C8\u30C7\u30FC\u306B\uFF13\u500D\u8FD4\u3057\u300D\u3068\u3044\u3046\u306E\u306F\u3001\uFF11\u30F6\u6708\uFF08\uFF12\uFF18\u65E5\u9593\uFF09\u3067200%\u306E\u5229\u5B50\u3092\u8981\u6C42\u3057\u3066\u3044\u308B\u3053\u3068\u306B\u306A\u308A\u3001\u5E74\u5229\u3067\u8868\u3059\u3068\u304A\u3088\u305D2607%\u306B\u306A\u308A\u3001\u51FA\u8CC7\u6CD5\u306E\u898F\u5B9A\u304B\u3089\u91D1\u878D\u696D\u8005\u4EE5\u5916\u3067\u3082\u5E74109.5%\u4EE5\u4E0A\u306E\u5229\u5B50\u3092\u53D7\u9818\u3059\u308B\u3053\u3068\u306F\u9055\u6CD5\u306E\u305F\u3081\u3001\u3053\u306E\u8981\u6C42\u306F\u9055\u6CD5\u3067\u7121 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37114709417140224",
    "text" : "\u305F\u307E\u306B\u805E\u304F\u300C\u30DB\u30EF\u30A4\u30C8\u30C7\u30FC\u306B\uFF13\u500D\u8FD4\u3057\u300D\u3068\u3044\u3046\u306E\u306F\u3001\uFF11\u30F6\u6708\uFF08\uFF12\uFF18\u65E5\u9593\uFF09\u3067200%\u306E\u5229\u5B50\u3092\u8981\u6C42\u3057\u3066\u3044\u308B\u3053\u3068\u306B\u306A\u308A\u3001\u5E74\u5229\u3067\u8868\u3059\u3068\u304A\u3088\u305D2607%\u306B\u306A\u308A\u3001\u51FA\u8CC7\u6CD5\u306E\u898F\u5B9A\u304B\u3089\u91D1\u878D\u696D\u8005\u4EE5\u5916\u3067\u3082\u5E74109.5%\u4EE5\u4E0A\u306E\u5229\u5B50\u3092\u53D7\u9818\u3059\u308B\u3053\u3068\u306F\u9055\u6CD5\u306E\u305F\u3081\u3001\u3053\u306E\u8981\u6C42\u306F\u9055\u6CD5\u3067\u7121\u52B9\u3068\u3044\u3046\u3053\u3068\u306B\u306A\u308A\u307E\u3059\u3002",
    "id" : 37114709417140224,
    "created_at" : "2011-02-14 11:43:30 +0000",
    "user" : {
      "name" : "\u6E96\u6025\u304F\u304D",
      "screen_name" : "semiexp",
      "protected" : false,
      "id_str" : "19898621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461140997263466496\/mDLQLZ2A_normal.png",
      "id" : 19898621,
      "verified" : false
    }
  },
  "id" : 37140153520623616,
  "created_at" : "2011-02-14 13:24:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37070520222490625",
  "geo" : { },
  "id_str" : "37079988553392128",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 c\u8A00\u8A9E\u306E\u6388\u696D\u306A\u3093\u304B\u3067\u53D6\u308C\u308B\u306A\u3089\u4E00\u7DD2\u306B\u53D6\u308D\u3046\u305C",
  "id" : 37079988553392128,
  "in_reply_to_status_id" : 37070520222490625,
  "created_at" : "2011-02-14 09:25:32 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36789019048148992",
  "geo" : { },
  "id_str" : "36791850975244288",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u8EAB\u306E\u56DE\u308A\u306B\u6C17\u306E\u304D\u3044\u305F\u30CD\u30A4\u30C6\u30A3\u30D6\u304C\u3044\u308C\u3070\u5C1A\u826F\u3044\u3051\u3069\u306A",
  "id" : 36791850975244288,
  "in_reply_to_status_id" : 36789019048148992,
  "created_at" : "2011-02-13 14:20:35 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36761895323049985",
  "text" : "1\u65E5\uFF11\u30C4\u30A4\u2010\u30C8\u3092\u76EE\u6A19\u306B\u3057\u3066\u307F\u3088\u3046\u304B\u306A\u3002\u5BA2\u89B3\u7684\u306B\u307F\u3066\u545F\u304B\u306A\u3055\u3059\u304E\u308B\u3002",
  "id" : 36761895323049985,
  "created_at" : "2011-02-13 12:21:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E2D\u6FA4\u5DE5\uFF08Takumi Nakazawa\uFF09",
      "screen_name" : "nakazawatakumi",
      "indices" : [ 3, 18 ],
      "id_str" : "29660979",
      "id" : 29660979
    }, {
      "name" : "\u6BCE\u65E5\u65B0\u805E\u30CB\u30E5\u30FC\u30B9\u901F\u5831",
      "screen_name" : "mainichijpnews",
      "indices" : [ 85, 100 ],
      "id_str" : "46282367",
      "id" : 46282367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/zt3RlXK",
      "expanded_url" : "http:\/\/mainichi.jp\/select\/jiken\/news\/20110212k0000e040044000c.html",
      "display_url" : "mainichi.jp\/select\/jiken\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "36280961624838144",
  "text" : "RT @nakazawatakumi: \u5A01\u529B\u696D\u52D9\u59A8\u5BB3\uFF1A\u30CD\u30C3\u30C8\u306B\u901A\u308A\u9B54\u4E88\u544A\u3000\u4E2D\uFF13\u5C11\u5E74\u902E\u6355\u2026\u8B66\u8996\u5E81 - \u6BCE\u65E5\uFF4A\uFF50(\u6BCE\u65E5\u65B0\u805E) http:\/\/t.co\/zt3RlXK via @mainichijpnews\u3000\u3000\u6355\u307E\u3063\u305F\u305D\u3046\u3067\u4F55\u3088\u308A\u3002\u3053\u306E\u624B\u306E\u9A12\u304E\u3092\u8D77\u3053\u3057\u305F\u304B\u3089\u306B\u306F\u4E2D\uFF13\u3067\u3082\u304D\u3063\u3061\u308A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6BCE\u65E5\u65B0\u805E\u30CB\u30E5\u30FC\u30B9\u901F\u5831",
        "screen_name" : "mainichijpnews",
        "indices" : [ 65, 80 ],
        "id_str" : "46282367",
        "id" : 46282367
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 60 ],
        "url" : "http:\/\/t.co\/zt3RlXK",
        "expanded_url" : "http:\/\/mainichi.jp\/select\/jiken\/news\/20110212k0000e040044000c.html",
        "display_url" : "mainichi.jp\/select\/jiken\/n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "36270459372703744",
    "text" : "\u5A01\u529B\u696D\u52D9\u59A8\u5BB3\uFF1A\u30CD\u30C3\u30C8\u306B\u901A\u308A\u9B54\u4E88\u544A\u3000\u4E2D\uFF13\u5C11\u5E74\u902E\u6355\u2026\u8B66\u8996\u5E81 - \u6BCE\u65E5\uFF4A\uFF50(\u6BCE\u65E5\u65B0\u805E) http:\/\/t.co\/zt3RlXK via @mainichijpnews\u3000\u3000\u6355\u307E\u3063\u305F\u305D\u3046\u3067\u4F55\u3088\u308A\u3002\u3053\u306E\u624B\u306E\u9A12\u304E\u3092\u8D77\u3053\u3057\u305F\u304B\u3089\u306B\u306F\u4E2D\uFF13\u3067\u3082\u304D\u3063\u3061\u308A\u7F70\u3057\u3066\u6B32\u3057\u3044\u3002\u5F8C\u3005\u306E\u305F\u3081\u306B\u3082\u3002",
    "id" : 36270459372703744,
    "created_at" : "2011-02-12 03:48:46 +0000",
    "user" : {
      "name" : "\u4E2D\u6FA4\u5DE5\uFF08Takumi Nakazawa\uFF09",
      "screen_name" : "nakazawatakumi",
      "protected" : false,
      "id_str" : "29660979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3094597953\/2c3bb19c540926ee1ffe4bea1987626c_normal.jpeg",
      "id" : 29660979,
      "verified" : false
    }
  },
  "id" : 36280961624838144,
  "created_at" : "2011-02-12 04:30:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "sm8497403",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/1OGveEa",
      "expanded_url" : "http:\/\/nico.ms\/sm8497403",
      "display_url" : "nico.ms\/sm8497403"
    } ]
  },
  "geo" : { },
  "id_str" : "36043431801257984",
  "text" : "\u8DF3\u8E8D\u306E\u6FC0\u3057\u3044\u300C\u697D\u8208\u306E\u6642\u300D\u7B2C\uFF13\u756A (2:20) #nicovideo #sm8497403 http:\/\/t.co\/1OGveEa",
  "id" : 36043431801257984,
  "created_at" : "2011-02-11 12:46:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5FD7\u4E43\uFF20\u30D7\u30EA\u30D1\u30E9\uFF1A\u8D64\u3046\u3055\u30DE\u30CD\u3010\u30A4\u30B4\u3077\u308A\u52E2\u3011",
      "screen_name" : "sino1759",
      "indices" : [ 3, 12 ],
      "id_str" : "122911411",
      "id" : 122911411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35984463364100096",
  "text" : "RT @sino1759: \u3010\u62E1\u6563\u5E0C\u671B\u3011\u6BBA\u5BB3\u4E88\u544A\u306E\u72AF\u4EBA\u3001\u671D\u304B\u3089\u307E\u305F2\u3061\u3083\u3093\u306D\u308B\u3067\u4ECA\u65E5\u306E\u4E88\u5B9A\u306A\u3069\u66F8\u304D\u8FBC\u3093\u3067\u307E\u3059\u3002 \u672C\u5F53\u306B21\u6642\u65B0\u5BBF\u6C17\u3092\u4ED8\u3051\u305F\u65B9\u304C\u826F\u3044\u304B\u3082\u3002\u5618\u3067\u3082\u6016\u3044\u304B\u3089\u3001\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u898B\u305F\u4EBA\u306F21\u6642\u524D\u5F8C\u3060\u3051\u306F\u65E7\uFF65\u65B0\u5357\u53E3\u306B\u306F\u884C\u304B\u306A\u3044\u3088\u3046\u306B\u3057\u3066\u307B\u3057\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35888233720053760",
    "text" : "\u3010\u62E1\u6563\u5E0C\u671B\u3011\u6BBA\u5BB3\u4E88\u544A\u306E\u72AF\u4EBA\u3001\u671D\u304B\u3089\u307E\u305F2\u3061\u3083\u3093\u306D\u308B\u3067\u4ECA\u65E5\u306E\u4E88\u5B9A\u306A\u3069\u66F8\u304D\u8FBC\u3093\u3067\u307E\u3059\u3002 \u672C\u5F53\u306B21\u6642\u65B0\u5BBF\u6C17\u3092\u4ED8\u3051\u305F\u65B9\u304C\u826F\u3044\u304B\u3082\u3002\u5618\u3067\u3082\u6016\u3044\u304B\u3089\u3001\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u898B\u305F\u4EBA\u306F21\u6642\u524D\u5F8C\u3060\u3051\u306F\u65E7\uFF65\u65B0\u5357\u53E3\u306B\u306F\u884C\u304B\u306A\u3044\u3088\u3046\u306B\u3057\u3066\u307B\u3057\u3044\u3002",
    "id" : 35888233720053760,
    "created_at" : "2011-02-11 02:29:56 +0000",
    "user" : {
      "name" : "\u5FD7\u4E43\uFF20\u30D7\u30EA\u30D1\u30E9\uFF1A\u8D64\u3046\u3055\u30DE\u30CD\u3010\u30A4\u30B4\u3077\u308A\u52E2\u3011",
      "screen_name" : "sino1759",
      "protected" : false,
      "id_str" : "122911411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480813318433566720\/ijkTmoZW_normal.jpeg",
      "id" : 122911411,
      "verified" : false
    }
  },
  "id" : 35984463364100096,
  "created_at" : "2011-02-11 08:52:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "indices" : [ 3, 12 ],
      "id_str" : "161910608",
      "id" : 161910608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35919586243117056",
  "text" : "RT @izugyoza: \u98DF\u6B32\u7121\u304F\u3066\u9903\u5B50\u3057\u304B\u98DF\u3079\u308C\u306A\u3044(T_T)\u3063\u3066\u8A00\u3063\u305F\u3089\u5341\u5206\u3060\u3088\u3063\u3066\u8A00\u308F\u308C\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35886643365810177",
    "text" : "\u98DF\u6B32\u7121\u304F\u3066\u9903\u5B50\u3057\u304B\u98DF\u3079\u308C\u306A\u3044(T_T)\u3063\u3066\u8A00\u3063\u305F\u3089\u5341\u5206\u3060\u3088\u3063\u3066\u8A00\u308F\u308C\u305F\u3002",
    "id" : 35886643365810177,
    "created_at" : "2011-02-11 02:23:37 +0000",
    "user" : {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "protected" : false,
      "id_str" : "161910608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607820959492370432\/IgL617FR_normal.png",
      "id" : 161910608,
      "verified" : false
    }
  },
  "id" : 35919586243117056,
  "created_at" : "2011-02-11 04:34:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35716833923301376",
  "geo" : { },
  "id_str" : "35718532436066304",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4F11\u65E5\u3060\u2606 \u3084\u3063\u305F\u306D\uFF01",
  "id" : 35718532436066304,
  "in_reply_to_status_id" : 35716833923301376,
  "created_at" : "2011-02-10 15:15:36 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35705622192193537",
  "geo" : { },
  "id_str" : "35706557169668096",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 tk\u3082\u3046\u4E88\u5B9A\u5165\u3063\u3066\u3044\u3066\u78BA\u5B9A\u3067\u884C\u3051\u306A\u3044\u3068\u3044\u3046\u3002\u3082\u3046\u5C11\u3057\u65E9\u304F\u304A\u77E5\u3089\u305B\u3057\u3066\u307B\u3057\u304B\u3063\u305F\u306A\u30FC\u3002",
  "id" : 35706557169668096,
  "in_reply_to_status_id" : 35705622192193537,
  "created_at" : "2011-02-10 14:28:01 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35688112508252160",
  "text" : "\u3042\u3041\u3001\u672A\u6210\u5E74\u6700\u5F8C\u306E\u591C\u2026\u3002",
  "id" : 35688112508252160,
  "created_at" : "2011-02-10 13:14:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35628590682865665",
  "geo" : { },
  "id_str" : "35630737533181952",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5BD2\u304B\u3063\u305F\u308D\u3046\u306B\u3002\u98A8\u90AA\u5F15\u304F\u306A\u3088\u30FC\u3002",
  "id" : 35630737533181952,
  "in_reply_to_status_id" : 35628590682865665,
  "created_at" : "2011-02-10 09:26:44 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35626408478777344",
  "text" : "\u672C\u304C\u826F\u3044\u3068\u3053\u308D\u3067\u7D42\u70B9orz",
  "id" : 35626408478777344,
  "created_at" : "2011-02-10 09:09:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35621902479261697",
  "text" : "\u4F55\u6545\u304B\u77ED\u7DE8\u96C6\u3088\u308A\u9577\u7DE8\u306E\u65B9\u304C\u8AAD\u3080\u306E\u304C\u65E9\u3044\u3002",
  "id" : 35621902479261697,
  "created_at" : "2011-02-10 08:51:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34820348197216256",
  "text" : "\u307E\u3041\u305D\u3082\u305D\u3082\u30B9\u30D1\u30A4\u30B9\u5168\u7136\u8DB3\u308A\u3066\u306A\u3044\u3093\u3060\u3051\u3069\uFF57\u30ED\u30FC\u30EA\u30A8\u3001\u30B3\u30EA\u30A2\u30F3\u30C0\u30FC\u3001\u30AC\u30E9\u30E0\u30DE\u30B5\u30E9\u3001\u30AF\u30DF\u30F3\u30B7\u30FC\u30C9\u3002\u3053\u306E\u8FBA\u5FC5\u8981\u3060\u308D\u3046\u306B\u7AEF\u6298\u3063\u305F\u306E\u304C\u307E\u305A\u304B\u3063\u305F\u3002",
  "id" : 34820348197216256,
  "created_at" : "2011-02-08 03:46:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34820096429920256",
  "text" : "\u3044\u3084\u3001\u5473\u306F\u3044\u3044\u3093\u3060\u3051\u3069\u30AB\u30EC\u30FC\u3058\u3083\u306A\u3044\u3093\u3060\u3088\u306D\u30FC\u3002\u672C\u5834\u306E\u30AB\u30EC\u30FC\u3068\u3082\u9055\u3046\u6C17\u304C\u3059\u308B\u3002",
  "id" : 34820096429920256,
  "created_at" : "2011-02-08 03:45:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34819968533008385",
  "text" : "\u30B9\u30D1\u30A4\u30B9\u304B\u3089\u30AB\u30EC\u30FC\u3092\u4F5C\u3063\u3066\u307F\u305F\u304C\u306A\u3093\u3068\u3044\u3046\u304B\u30B9\u30D1\u30A4\u30B9\u306E\u7092\u3081\u716E\u307F\u305F\u3044\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3002",
  "id" : 34819968533008385,
  "created_at" : "2011-02-08 03:45:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34616681712058369",
  "text" : "@koketomi \u5473\u4ED8\u3051\u306B\u554F\u984C\u304C\u3042\u308B\u306E\u3067\u306F\uFF1F\u78BA\u304B\u306B\u304F\u3069\u3044\u6599\u7406\u3067\u306F\u3042\u308B\u304C\u2026",
  "id" : 34616681712058369,
  "created_at" : "2011-02-07 14:17:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34560449915658240",
  "text" : "\u3053\u306E\u5BD2\u3044\u306E\u306B\u30A2\u30A4\u30B9\u98DF\u3079\u3066\u308B\u5973\u5B50\u4E2D\u5B66\u751F\u2026\u30A2\u30A4\u30B9\u3068\u304B\u4ECA\u5E74\u307E\u3060\u98DF\u3079\u3066\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u3060\u308D\u3046\u304B",
  "id" : 34560449915658240,
  "created_at" : "2011-02-07 10:33:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34546015314907137",
  "geo" : { },
  "id_str" : "34550092333588480",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u4E45\u3005\u306E\u30C4\u30A4\u30FC\u30C8\u304C\u305D\u308C\u304B\u3088\uFF57\uFF57\uFF57",
  "id" : 34550092333588480,
  "in_reply_to_status_id" : 34546015314907137,
  "created_at" : "2011-02-07 09:52:38 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34147704816795648",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u306F\u5BD2\u304F\u306A\u3044\u3002",
  "id" : 34147704816795648,
  "created_at" : "2011-02-06 07:13:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33892673664323584",
  "text" : "\u30A2\u30DE\u30C4\u30DE\u30AC\u30C4\u30C1\u5012\u3057\u305F\u30FC\u3002\u5F13\u30BD\u30ED\u3002\u4E00\u56DE\u4E09\u6B7B\u3057\u305F\u306E\u306F\u5185\u7DD2\u300225\u5206\u3082\u304B\u304B\u3063\u305F\u304C\u3002",
  "id" : 33892673664323584,
  "created_at" : "2011-02-05 14:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33503721459556352",
  "geo" : { },
  "id_str" : "33505526729940992",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u3084\u3001\u30C4\u30A4\u30C3\u30BF\u30FC\u3063\u3066\u983B\u7E41\u306B\u898B\u308B\u5272\u306B\u81EA\u5206\u306E\u30C4\u30A4\u30FC\u30C8\u306F\u5C11\u306A\u3044\u306A\u3001\u3068\u601D\u3063\u3066\u9B54\u304C\u3055\u3057\u305F",
  "id" : 33505526729940992,
  "in_reply_to_status_id" : 33503721459556352,
  "created_at" : "2011-02-04 12:41:54 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33501362121609216",
  "text" : "\u3064\u3044\u3063\u305F\u30FC\u306A\u3046\u3001\u3068\u8A00\u3046\u81EA\u5DF1\u8A00\u53CA\u306A\u3046\u3002\u7D50\u5C40\u4F55\u3082\u8A00\u3063\u3066\u306A\u3044\u3002",
  "id" : 33501362121609216,
  "created_at" : "2011-02-04 12:25:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33115226714931200",
  "geo" : { },
  "id_str" : "33115727984590848",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u3048\u3066\u30CA\u30AB\u30D2\u3068\u8AAD\u3081\u3070\u8A9E\u5442\u306F\u5408\u3046\u3088\u306D",
  "id" : 33115727984590848,
  "in_reply_to_status_id" : 33115226714931200,
  "created_at" : "2011-02-03 10:52:59 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32971603235045376",
  "text" : "\u30CF\u30C3\u30CF\u30FC\uFF01\u6570\u5B66\uFF14\u5358\u4F4D\u4F59\u88D5\u306E\uFF33\u30A5\uFF01\u6628\u65E5\u306E\u304C\u9B3C\u755C\u904E\u304E\u305F\u305B\u3044\u304B\u7269\u8DB3\u308A\u306A\u3044\u30EC\u30D9\u30EB",
  "id" : 32971603235045376,
  "created_at" : "2011-02-03 01:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32947930050596864",
  "text" : "\u4FFA\u2026\u3053\u306E\u30C6\u30B9\u30C8\u304C\u7D42\u308F\u3063\u305F\u3089\u5BB6\u306B\u5E30\u3063\u3066\u7720\u308B\u3093\u3060\u2026\uFF01",
  "id" : 32947930050596864,
  "created_at" : "2011-02-02 23:46:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32703984036745216",
  "geo" : { },
  "id_str" : "32704561353334784",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u53EF\u80FD\u306A\u3089\u6765\u5E74\u5EA6\u30EA\u30D9\u30F3\u30B8\u304B\u306A\u30FC\u3002",
  "id" : 32704561353334784,
  "in_reply_to_status_id" : 32703984036745216,
  "created_at" : "2011-02-02 07:39:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32699695750971392",
  "text" : "\u5319\u306F\u6295\u3052\u3089\u308C\u305F\u3002\u7121\u7406\u3002",
  "id" : 32699695750971392,
  "created_at" : "2011-02-02 07:19:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32667270043926529",
  "text" : "\u3042\u306830\u5206\u3067\u3001\u8CFD\u304C\uFF08\u3042\u308B\u3044\u306F\u5319\u304C\uFF09\u6295\u3052\u3089\u308C\u308B\u3002",
  "id" : 32667270043926529,
  "created_at" : "2011-02-02 05:10:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32359289729327104",
  "geo" : { },
  "id_str" : "32361324839182336",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30A4\u30A4\u30CD\uFF01",
  "id" : 32361324839182336,
  "in_reply_to_status_id" : 32359289729327104,
  "created_at" : "2011-02-01 08:55:15 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32343652378353664",
  "text" : "@koketomi \u8AB0\u306E\u58F0\uFF1F\uFF1F",
  "id" : 32343652378353664,
  "created_at" : "2011-02-01 07:45:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32340085860990976",
  "text" : "\u3042\u308C\uFF1F\u8A66\u9A13\u52C9\u5F37\u3057\u3066\u305F\u306F\u305A\u306A\u306E\u306B\u306A\u3002\u4ECA\u304B\u3089\u3067\u3082\u9045\u304F\u306A\u3044\u3002\u9811\u5F35\u308D\u3046\u3002",
  "id" : 32340085860990976,
  "created_at" : "2011-02-01 07:30:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32339948703055872",
  "text" : "\u3053\u306E\u90E8\u5C4B\u3069\u3046\u306A\u3063\u3066\u3093\u3060\uFF57\uFF57\nhttp:\/\/www.youtube.com\/watch?v=s-SpzO4qTEU&NR=1",
  "id" : 32339948703055872,
  "created_at" : "2011-02-01 07:30:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32277770742538241",
  "geo" : { },
  "id_str" : "32278288487419904",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u3084\uFF1F\u6700\u5F8C\u306E\u6388\u696D\u3060\u304B\u3089\u554F\u984C\u306A\u3057\u3002\u6728\u66DC\u306B\u30C6\u30B9\u30C8\u3002",
  "id" : 32278288487419904,
  "in_reply_to_status_id" : 32277770742538241,
  "created_at" : "2011-02-01 03:25:18 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32265564093157376",
  "text" : "\u4ECA\u65E5\u4E00\u9650\u6700\u5F8C\u306E\u6388\u696D\u3084\u3063\u305F\u306E\u306B\u5BDD\u5012\u3057\u3061\u307E\u3063\u305F\u3002\u3042\u3041\u3042\u3002",
  "id" : 32265564093157376,
  "created_at" : "2011-02-01 02:34:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]