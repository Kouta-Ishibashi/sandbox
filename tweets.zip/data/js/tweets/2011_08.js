Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    }, {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 10, 24 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108690198623301632",
  "text" : "@koketomi @nico_reflexio \u304A\u524D\u3089\u671D\u304B\u3089\u5143\u6C17\u3060\u306A\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 108690198623301632,
  "created_at" : "2011-08-30 23:58:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108509511794442240",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 108509511794442240,
  "created_at" : "2011-08-30 12:00:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108492426536169472",
  "text" : "@ayu167 \u3067\u30A2\u30C1\u30E3\u30E2\u3060\u3063\u305F\u3093\uFF1F",
  "id" : 108492426536169472,
  "created_at" : "2011-08-30 10:53:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108043888643674112",
  "text" : "\u5947\u5999\u306B\u5FAE\u5999\u306B\u5DE7\u5999\u306B\u79FB\u308A\u5909\u308F\u3063\u3066\u3044\u3063\u305F\u304B\u3089\u610F\u8B58\u3057\u305F\u3053\u3068\u306A\u304B\u3063\u305F\u306A\u3041\u3002",
  "id" : 108043888643674112,
  "created_at" : "2011-08-29 05:10:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108043553225179136",
  "text" : "\u307E\u3041\u7D50\u5C40\u4F55\u3092\u521D\u9805\u3068\u3057\u3066\u6271\u3046\u304B\u3063\u3066\u554F\u984C\u304B\u3002\u300C\u521D\u300D\u306B\uFF10\u3092\u5F53\u3066\u308B\u304B1\u3092\u5F53\u3066\u308B\u304B\u3063\u3066\u554F\u984C\u3002",
  "id" : 108043553225179136,
  "created_at" : "2011-08-29 05:09:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108043284089274368",
  "text" : "\u5927\u5B66\u306F\u3044\u308B\u3068\u548C\u306E\u8A18\u53F7\u306E\u30B7\u30B0\u30DE\u3082\u7A81\u7136\uFF10\u304B\u3089\u6570\u3048\u4E0A\u3052\u308B\u5F62\u5F0F\u306B\u306A\u308B\u3082\u3093\u306A\u30FC\u3002\u9AD8\u6821\u6570\u5B66\u3067\u306F\uFF4B\uFF1D\uFF11\u304B\u3089\u30B9\u30BF\u30FC\u30C8\u3057\u3066\u305F\u6C17\u304C\u3059\u308B\u3002\u90FD\u5408\u3067\u8ABF\u6574\u3057\u3066\u305F\u3051\u3069\u3002",
  "id" : 108043284089274368,
  "created_at" : "2011-08-29 05:08:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108042921974046720",
  "text" : "\u305D\u3046\u3044\u3046\u610F\u5473\u3067\u306F\u975E\u8CA0\u6574\u6570\u3068\u304B\u6B63\u6574\u6570\u306E\u307B\u3046\u304C\u8868\u73FE\u306F\u53B3\u5BC6\u3060\u3088\u306A\u30FC\u3001\u3068\u3002",
  "id" : 108042921974046720,
  "created_at" : "2011-08-29 05:06:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108042580092129281",
  "text" : "\u7D50\u5C40\u81EA\u5206\u306F\u4E2D\u7ACB\u3092\u4FDD\u3061\u305F\u3044\u3093\u3060\u308D\u3046\u306A\u30FC\u3002\uFF10\u306F\u81EA\u7136\u6570\u3060\u3068\u3001\u3042\u308B\u3044\u306F\u305D\u3046\u3067\u306A\u3044\u3068\u5F37\u304F\u4E3B\u5F35\u3059\u308B\u306E\u306F\u305F\u3081\u3089\u308F\u308C\u308B\u3002",
  "id" : 108042580092129281,
  "created_at" : "2011-08-29 05:05:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108042334620491776",
  "text" : "\u826F\u3044\u3068\u3044\u3046\u304B\u90FD\u5408\u304C\u3088\u3044\u3063\u3066\u610F\u5473\u304B\u306A\u3002",
  "id" : 108042334620491776,
  "created_at" : "2011-08-29 05:04:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108042229599313921",
  "text" : "\uFF10\u306F\u81EA\u7136\u6570\u3068\u3057\u3066\u6271\u3063\u3066\u3088\u3044\u5834\u5408\u3068\u305D\u3046\u3067\u306A\u3044\u5834\u5408\u304C\u3042\u308B\u3088\u306A\u30FC\u3002",
  "id" : 108042229599313921,
  "created_at" : "2011-08-29 05:04:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108041973868400640",
  "text" : "\u4E2D\u5B66\u751F\u4EE5\u4E0B\u3001\u4E2D\u5B66\u751F\u672A\u6E80\u3001\u3069\u3061\u3089\u3082\u8868\u8A18\u3068\u3057\u3066\u306F\u6B63\u3057\u3044\u3002\u300C\u4EE5\u4E0B\u300D\u306F\uFF1D\u3042\u308B\u3044\u306F\uFF1C\u306E\u610F\u5473\u3002",
  "id" : 108041973868400640,
  "created_at" : "2011-08-29 05:03:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 3, 12 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108041216238698496",
  "text" : "RT @hanaoka_: \u305D\u3046\u3044\u3048\u3070\u53D7\u9A13\u751F\u3060\u3063\u305F\u9803\u3001\uFF62Twitter\u3067\u30FC\u3001\u4EAC\u5927\u751F\u306E\u3057\u304B\u3082\u7406\u5B66\u90E8\u306E\u4EBA\u304C\u3055\u3041\u3001\u300E\uFF10\u306F\u81EA\u7136\u6570\uFF01\u300F\u3068\u304B\u8A00\u3063\u3066\u308B\u306E\u898B\u3066\u30DE\u30B8\u4EAC\u5927\u7D42\u308F\u3063\u3066\u3093\u306A\u3068\u601D\u3063\u305F\u308F\u3002\uFF10\u306F\u81EA\u7136\u6570\u306B\u542B\u307E\u308C\u307E\u305B\u3093\u3063\u3066\u4E2D\u5B66\u6821\u3067\u7FD2\u3046\u3060\u308D\uFF57\uFF57\u4E2D\u5B66\u751F\u4EE5\u4E0B\u304B\u3088\uFF57\uFF57\uFF57\uFF63\u3063\u3066\u6771\u5927\u7406\uFF11\u53D7\u9A13\u751F\u306B\u8A00\u308F\u308C\u305F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105979116624416768",
    "text" : "\u305D\u3046\u3044\u3048\u3070\u53D7\u9A13\u751F\u3060\u3063\u305F\u9803\u3001\uFF62Twitter\u3067\u30FC\u3001\u4EAC\u5927\u751F\u306E\u3057\u304B\u3082\u7406\u5B66\u90E8\u306E\u4EBA\u304C\u3055\u3041\u3001\u300E\uFF10\u306F\u81EA\u7136\u6570\uFF01\u300F\u3068\u304B\u8A00\u3063\u3066\u308B\u306E\u898B\u3066\u30DE\u30B8\u4EAC\u5927\u7D42\u308F\u3063\u3066\u3093\u306A\u3068\u601D\u3063\u305F\u308F\u3002\uFF10\u306F\u81EA\u7136\u6570\u306B\u542B\u307E\u308C\u307E\u305B\u3093\u3063\u3066\u4E2D\u5B66\u6821\u3067\u7FD2\u3046\u3060\u308D\uFF57\uFF57\u4E2D\u5B66\u751F\u4EE5\u4E0B\u304B\u3088\uFF57\uFF57\uFF57\uFF63\u3063\u3066\u6771\u5927\u7406\uFF11\u53D7\u9A13\u751F\u306B\u8A00\u308F\u308C\u305F\u3053\u3068\u3042\u308B\u3002\n\u3061\u306A\u307F\u306B\u305D\u3044\u3064\u306F\u843D\u3061\u305F\u3002",
    "id" : 105979116624416768,
    "created_at" : "2011-08-23 12:26:05 +0000",
    "user" : {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "protected" : false,
      "id_str" : "126927392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540399732707688448\/Iqz4rTVp_normal.jpeg",
      "id" : 126927392,
      "verified" : false
    }
  },
  "id" : 108041216238698496,
  "created_at" : "2011-08-29 05:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108011858375606272",
  "text" : "\u666E\u901A\u5E3D\u5B50\u3063\u3066\u91CD\u306D\u306A\u3044\u3068\u3044\u3046\u8A8D\u8B58\u306A\u3093\u3060\u304C\u9593\u9055\u3063\u3066\u3093\u306E\u304B\u306A",
  "id" : 108011858375606272,
  "created_at" : "2011-08-29 03:03:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B97\u6570\u554F\u984C\u30DC\u30C3\u30C8",
      "screen_name" : "arithmetic_bot",
      "indices" : [ 3, 18 ],
      "id_str" : "221364927",
      "id" : 221364927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108011722224304129",
  "text" : "RT @arithmetic_bot: \u5E3D\u5B50\u3092\uFF12\u3064\u91CD\u306D\u3066\u88AB\u3063\u3066\u3044\u308B\u4EBA\u304C\u30B3\u30A4\u30F3\u3092\u6295\u3052\u3066\u8868\u306A\u3089\u5E3D\u5B50\u3092\uFF11\u3064\u5897\u3084\u3057\u88CF\u306A\u3089\u5E3D\u5B50\u3092\uFF11\u3064\u6E1B\u3089\u3059\u3002\u5E3D\u5B50\u304C\u306A\u304F\u306A\u308C\u3070\u7D42\u308F\u308B\u3002\uFF11\uFF09\u30B3\u30A4\u30F3\u3092\u6295\u3052\u305F\u56DE\u6570\u304C\uFF15\u56DE\u4EE5\u5185\u306E\u3068\u304D\u30B3\u30A4\u30F3\u306E\u8868\u88CF\u306E\u51FA\u65B9\u3092\u5168\u3066\u66F8\u304D\u51FA\u305B\u3002\uFF12\uFF09\u30B3\u30A4\u30F3\u3092\u6295\u3052\u305F\u56DE\u6570\u304C\uFF18\u56DE\u76EE\u3067\u7D42\u308F\u3063\u305F\u3068\u304D\u30B3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/chuan1kou3.blog27.fc2.com\/\" rel=\"nofollow\"\u003E\u30A2\u30EA\u30B9\u3061\u3083\u3093\u3067\u3059\u306E\uFF01\/\/\/\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108011146925182977",
    "text" : "\u5E3D\u5B50\u3092\uFF12\u3064\u91CD\u306D\u3066\u88AB\u3063\u3066\u3044\u308B\u4EBA\u304C\u30B3\u30A4\u30F3\u3092\u6295\u3052\u3066\u8868\u306A\u3089\u5E3D\u5B50\u3092\uFF11\u3064\u5897\u3084\u3057\u88CF\u306A\u3089\u5E3D\u5B50\u3092\uFF11\u3064\u6E1B\u3089\u3059\u3002\u5E3D\u5B50\u304C\u306A\u304F\u306A\u308C\u3070\u7D42\u308F\u308B\u3002\uFF11\uFF09\u30B3\u30A4\u30F3\u3092\u6295\u3052\u305F\u56DE\u6570\u304C\uFF15\u56DE\u4EE5\u5185\u306E\u3068\u304D\u30B3\u30A4\u30F3\u306E\u8868\u88CF\u306E\u51FA\u65B9\u3092\u5168\u3066\u66F8\u304D\u51FA\u305B\u3002\uFF12\uFF09\u30B3\u30A4\u30F3\u3092\u6295\u3052\u305F\u56DE\u6570\u304C\uFF18\u56DE\u76EE\u3067\u7D42\u308F\u3063\u305F\u3068\u304D\u30B3\u30A4\u30F3\u306E\u88CF\u8868\u306E\u51FA\u65B9\u306F\u4F55\u901A\u308A\u304B\u3002\uFF08\uFF10\uFF14\u6B66\u8535\u4E2D\uFF09",
    "id" : 108011146925182977,
    "created_at" : "2011-08-29 03:00:38 +0000",
    "user" : {
      "name" : "\u7B97\u6570\u554F\u984C\u30DC\u30C3\u30C8",
      "screen_name" : "arithmetic_bot",
      "protected" : false,
      "id_str" : "221364927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1179197458\/math_symbol_clipart_normal.jpg",
      "id" : 221364927,
      "verified" : false
    }
  },
  "id" : 108011722224304129,
  "created_at" : "2011-08-29 03:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/6LCEhB2",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107963101562929153",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/6LCEhB2",
  "id" : 107963101562929153,
  "created_at" : "2011-08-28 23:49:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107806259973070848",
  "geo" : { },
  "id_str" : "107806901986791424",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u3068\u77F3\u4E95\u304F\u3089\u3044\u3057\u304B\u3044\u306A\u3044\u305E\u30FC\u3002\u904E\u758E\u3002",
  "id" : 107806901986791424,
  "in_reply_to_status_id" : 107806259973070848,
  "created_at" : "2011-08-28 13:29:03 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107806372787265536",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u6771\u4EAC\u306B\u5E30\u3063\u3066\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306E\u8A71\u3092\u3057\u305F\u3089\u8AB0\u3082\u77E5\u3089\u306A\u304B\u3063\u305F\u3093\u3060\u3051\u3069\u306A\u3093\u306A\u3093\u3060\u308D\u3046\u3002",
  "id" : 107806372787265536,
  "created_at" : "2011-08-28 13:26:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304F\u30FC\u307E\u3093",
      "screen_name" : "akchon",
      "indices" : [ 3, 10 ],
      "id_str" : "43893741",
      "id" : 43893741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107806104326643712",
  "text" : "RT @akchon: \u6D45\u304F\u5E83\u304F\u306A\u4EBA\u9593\u95A2\u4FC2\u3060\u304B\u3089\u3001\u6DF1\u3044\u4EF2\u306E\u53CB\u9054\u3084\u604B\u4EBA\u306E\u3044\u308B\u4EBA\u304C\u7FA8\u307E\u3057\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107805920947486721",
    "text" : "\u6D45\u304F\u5E83\u304F\u306A\u4EBA\u9593\u95A2\u4FC2\u3060\u304B\u3089\u3001\u6DF1\u3044\u4EF2\u306E\u53CB\u9054\u3084\u604B\u4EBA\u306E\u3044\u308B\u4EBA\u304C\u7FA8\u307E\u3057\u3044\u3002",
    "id" : 107805920947486721,
    "created_at" : "2011-08-28 13:25:09 +0000",
    "user" : {
      "name" : "\u3042\u3063\u304F\u30FC\u307E\u3093",
      "screen_name" : "akchon",
      "protected" : false,
      "id_str" : "43893741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1984665528\/unccoooo_normal.png",
      "id" : 43893741,
      "verified" : false
    }
  },
  "id" : 107806104326643712,
  "created_at" : "2011-08-28 13:25:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 3, 12 ],
      "id_str" : "150662260",
      "id" : 150662260
    }, {
      "name" : "iitan",
      "screen_name" : "iitan328",
      "indices" : [ 21, 30 ],
      "id_str" : "18045553",
      "id" : 18045553
    }, {
      "name" : "\u30B9\u30FC\u30B9",
      "screen_name" : "Re_44",
      "indices" : [ 45, 51 ],
      "id_str" : "14337814",
      "id" : 14337814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107805024641486848",
  "text" : "RT @isaribiz: \uFF57\uFF57\uFF57 RT @iitan328: \u3046\u3061\u306E\u6BCD\u3082\u8A00\u3063\u3066\u305F RT @Re_44: \u30BC\u30AF\u30B7\u30A3\u306F\u5A5A\u59FB\u5C4A\u4ED8\u3051\u308B\u306A\u3089\u8CAC\u4EFB\u6301\u3063\u3066\u96E2\u5A5A\u5C4A\u3082\u3064\u3051\u308D\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iitan",
        "screen_name" : "iitan328",
        "indices" : [ 7, 16 ],
        "id_str" : "18045553",
        "id" : 18045553
      }, {
        "name" : "\u30B9\u30FC\u30B9",
        "screen_name" : "Re_44",
        "indices" : [ 31, 37 ],
        "id_str" : "14337814",
        "id" : 14337814
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107804448243453952",
    "text" : "\uFF57\uFF57\uFF57 RT @iitan328: \u3046\u3061\u306E\u6BCD\u3082\u8A00\u3063\u3066\u305F RT @Re_44: \u30BC\u30AF\u30B7\u30A3\u306F\u5A5A\u59FB\u5C4A\u4ED8\u3051\u308B\u306A\u3089\u8CAC\u4EFB\u6301\u3063\u3066\u96E2\u5A5A\u5C4A\u3082\u3064\u3051\u308D\u3088",
    "id" : 107804448243453952,
    "created_at" : "2011-08-28 13:19:18 +0000",
    "user" : {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "protected" : true,
      "id_str" : "150662260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586179377114685441\/2LPKH2Xn_normal.jpg",
      "id" : 150662260,
      "verified" : false
    }
  },
  "id" : 107805024641486848,
  "created_at" : "2011-08-28 13:21:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E03\u8349\u3057\u308D",
      "screen_name" : "Nanakusa17",
      "indices" : [ 3, 14 ],
      "id_str" : "91075332",
      "id" : 91075332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107803627061641216",
  "text" : "RT @Nanakusa17: \u751F\u5F92\u300C\u3053\u3093\u306A\u3053\u3068\u3084\u3063\u3066\u5C06\u6765\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u3093\u3067\u3059\u304B\u30FC\uFF1F\u300D \u5148\u751F\u300C\u3053\u3093\u306A\u3053\u3068\u3082\u51FA\u6765\u306A\u3044\u541B\u306F\u5C06\u6765\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u3093\u3067\u3059\u304B\u30FC\uFF1F\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42216852147015680",
    "text" : "\u751F\u5F92\u300C\u3053\u3093\u306A\u3053\u3068\u3084\u3063\u3066\u5C06\u6765\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u3093\u3067\u3059\u304B\u30FC\uFF1F\u300D \u5148\u751F\u300C\u3053\u3093\u306A\u3053\u3068\u3082\u51FA\u6765\u306A\u3044\u541B\u306F\u5C06\u6765\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u3093\u3067\u3059\u304B\u30FC\uFF1F\u300D",
    "id" : 42216852147015680,
    "created_at" : "2011-02-28 13:37:36 +0000",
    "user" : {
      "name" : "\u4E03\u8349\u3057\u308D",
      "screen_name" : "Nanakusa17",
      "protected" : false,
      "id_str" : "91075332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1145876946\/20090625_766603_normal.jpg",
      "id" : 91075332,
      "verified" : false
    }
  },
  "id" : 107803627061641216,
  "created_at" : "2011-08-28 13:16:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EA\u30B5\u30AD\/\u5927\u962A\u7832\u96F7\u6483\u622617H-09b",
      "screen_name" : "A_kirisaki",
      "indices" : [ 3, 14 ],
      "id_str" : "13042182",
      "id" : 13042182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107786580923645952",
  "text" : "RT @A_kirisaki: \u30AA\u30FC\u30E0\u300C\u30DC\u30EB\u30C8\u304C\u3084\u3089\u308C\u305F\u3088\u3046\u3060\u306A\u2026\u2026\u300D \u30A2\u30F3\u30DA\u30A2\u300C\u30AF\u30AF\u30AF\u2026\u2026\u3002\u5974\u306F\u56DB\u5929\u738B\u306E\u4E2D\u3067\u3082\u6700\u5F31\u2026\u2026\u300D \u30EF\u30C3\u30C8\u300C\u6211\u3089\u56DB\u5929\u738B\u306E\u9762\u6C5A\u3057\u3088\u2026\u2026\u3002\u300D\u30AF\u30FC\u30ED\u30F3\u300C\u547C\u3093\u3060\uFF1F\u300D\u30D5\u30A1\u30E9\u30C9\u300C\u96FB\u6C17\u306E\u5358\u4F4D\u3068\u805E\u3044\u3066\u300D\u30D8\u30F3\u30EA\u30FC\u300C\u304A\u3046\u304A\u3046\u300D\u30B8\u30FC\u30E1\u30F3\u30B9\u300C\u308F\u3057\u3082\u3044\u308B\u305E\u300D\u30C7\u30B7\u30D9\u30EB\u300C\u50D5\u306F\u3053 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107784131500441600",
    "text" : "\u30AA\u30FC\u30E0\u300C\u30DC\u30EB\u30C8\u304C\u3084\u3089\u308C\u305F\u3088\u3046\u3060\u306A\u2026\u2026\u300D \u30A2\u30F3\u30DA\u30A2\u300C\u30AF\u30AF\u30AF\u2026\u2026\u3002\u5974\u306F\u56DB\u5929\u738B\u306E\u4E2D\u3067\u3082\u6700\u5F31\u2026\u2026\u300D \u30EF\u30C3\u30C8\u300C\u6211\u3089\u56DB\u5929\u738B\u306E\u9762\u6C5A\u3057\u3088\u2026\u2026\u3002\u300D\u30AF\u30FC\u30ED\u30F3\u300C\u547C\u3093\u3060\uFF1F\u300D\u30D5\u30A1\u30E9\u30C9\u300C\u96FB\u6C17\u306E\u5358\u4F4D\u3068\u805E\u3044\u3066\u300D\u30D8\u30F3\u30EA\u30FC\u300C\u304A\u3046\u304A\u3046\u300D\u30B8\u30FC\u30E1\u30F3\u30B9\u300C\u308F\u3057\u3082\u3044\u308B\u305E\u300D\u30C7\u30B7\u30D9\u30EB\u300C\u50D5\u306F\u3053\u3053\u306B\u3044\u3066\u3044\u3044\u3093\u3067\u3057\u3087\u3046\u304B\u300D",
    "id" : 107784131500441600,
    "created_at" : "2011-08-28 11:58:34 +0000",
    "user" : {
      "name" : "\u30AD\u30EA\u30B5\u30AD\/\u5927\u962A\u7832\u96F7\u6483\u622617H-09b",
      "screen_name" : "A_kirisaki",
      "protected" : false,
      "id_str" : "13042182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594317555755405312\/naLRpg4j_normal.png",
      "id" : 13042182,
      "verified" : false
    }
  },
  "id" : 107786580923645952,
  "created_at" : "2011-08-28 12:08:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107784667515723776",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 107784667515723776,
  "created_at" : "2011-08-28 12:00:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/HxyUnOI",
      "expanded_url" : "http:\/\/shindanmaker.com\/150774",
      "display_url" : "shindanmaker.com\/150774"
    } ]
  },
  "geo" : { },
  "id_str" : "107784579653451776",
  "text" : "RT @dovanyahn: \u3069\u3070\u3055\u3093\u306B\u3074\u3063\u305F\u308A\u306E\u547C\u3073\u540D\u306F\u300E\u3069\u3070\u306B\u3083\u3093\u3001\u3069\u3070\u5148\u751F\u3001\u307F\u3093\u306A\u306E\u30A2\u30A4\u30C9\u30EB\u3069\u3070\u300F\u3067\u3059\u3002 \u53CB\u9054\u3084\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u306B\u547C\u3093\u3067\u3082\u3089\u304A\u3046\u3002 http:\/\/t.co\/HxyUnOI  \u3069\u3070\u306B\u3083\u3093\u30AD\u30BF\u30FC!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 80 ],
        "url" : "http:\/\/t.co\/HxyUnOI",
        "expanded_url" : "http:\/\/shindanmaker.com\/150774",
        "display_url" : "shindanmaker.com\/150774"
      } ]
    },
    "geo" : { },
    "id_str" : "107784238622978049",
    "text" : "\u3069\u3070\u3055\u3093\u306B\u3074\u3063\u305F\u308A\u306E\u547C\u3073\u540D\u306F\u300E\u3069\u3070\u306B\u3083\u3093\u3001\u3069\u3070\u5148\u751F\u3001\u307F\u3093\u306A\u306E\u30A2\u30A4\u30C9\u30EB\u3069\u3070\u300F\u3067\u3059\u3002 \u53CB\u9054\u3084\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u306B\u547C\u3093\u3067\u3082\u3089\u304A\u3046\u3002 http:\/\/t.co\/HxyUnOI  \u3069\u3070\u306B\u3083\u3093\u30AD\u30BF\u30FC!!",
    "id" : 107784238622978049,
    "created_at" : "2011-08-28 11:58:59 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 107784579653451776,
  "created_at" : "2011-08-28 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107779538251038720",
  "text" : "\u3084\u3063\u3068\uFF27\uFF34\uFF32\u306711\u9023\u9396\u304C\u7D44\u3081\u305F\u3002\u30B9\u30D4\u30FC\u30C9\u306F\u7686\u7121\u3002",
  "id" : 107779538251038720,
  "created_at" : "2011-08-28 11:40:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "take",
      "screen_name" : "take_0414",
      "indices" : [ 3, 13 ],
      "id_str" : "84018005",
      "id" : 84018005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107768793962516480",
  "text" : "RT @take_0414: \u3010Twitter\u306E\u6B63\u3057\u3044\u697D\u3057\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107768119325507584",
    "text" : "\u3010Twitter\u306E\u6B63\u3057\u3044\u697D\u3057\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
    "id" : 107768119325507584,
    "created_at" : "2011-08-28 10:54:56 +0000",
    "user" : {
      "name" : "take",
      "screen_name" : "take_0414",
      "protected" : false,
      "id_str" : "84018005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535227451371048960\/HmqiFSjO_normal.jpeg",
      "id" : 84018005,
      "verified" : false
    }
  },
  "id" : 107768793962516480,
  "created_at" : "2011-08-28 10:57:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 3, 13 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107768774278647809",
  "text" : "RT @blackVELU: \u3010Twitter\u306E\u6B63\u3057\u3044\u697D\u3057\u307F\u65B9\u3011 1.(\u00B4\u25D4\u0C6A\u25D4)\u06F6\uFF96\uFF6F\uFF7C\uFF6C! 2..\u30AA\u3001\u30AA\u30A6 3.\uFF01( \u25E0\u203F\u25E0 )\uFF01 4.\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30A2\u30A2\u30AA\u30AA\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107767845148037120",
    "text" : "\u3010Twitter\u306E\u6B63\u3057\u3044\u697D\u3057\u307F\u65B9\u3011 1.(\u00B4\u25D4\u0C6A\u25D4)\u06F6\uFF96\uFF6F\uFF7C\uFF6C! 2..\u30AA\u3001\u30AA\u30A6 3.\uFF01( \u25E0\u203F\u25E0 )\uFF01 4.\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30A2\u30A2\u30AA\u30AA\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
    "id" : 107767845148037120,
    "created_at" : "2011-08-28 10:53:51 +0000",
    "user" : {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "protected" : false,
      "id_str" : "102325414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450656382325248000\/cnubEZOd_normal.jpeg",
      "id" : 102325414,
      "verified" : false
    }
  },
  "id" : 107768774278647809,
  "created_at" : "2011-08-28 10:57:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107760889800818689",
  "geo" : { },
  "id_str" : "107761980089176064",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3042\u308B\u306E\u304B\uFF57",
  "id" : 107761980089176064,
  "in_reply_to_status_id" : 107760889800818689,
  "created_at" : "2011-08-28 10:30:32 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107760291680493569",
  "geo" : { },
  "id_str" : "107760793960972288",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3069\u3046\u3082\u753B\u50CF\u304C\u8868\u793A\u3055\u308C\u306A\u3044\u3093\u3060\u3088\u306D\u3002",
  "id" : 107760793960972288,
  "in_reply_to_status_id" : 107760291680493569,
  "created_at" : "2011-08-28 10:25:50 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107760719419809792",
  "text" : "\u30B3\u30E9\u30FC\u30B8\u30E5\u753B\u50CF\u304C\u3061\u3083\u3093\u3068\u8868\u793A\u3055\u308C\u306A\u3044\u306E\u3067\u524A\u9664\u3057\u307E\u3057\u305F\u3002\u30EA\u30D7\u30E9\u30A4\u98DB\u3070\u3057\u3066\u3054\u3081\u3093\u306A\u3055\u3044\u3002",
  "id" : 107760719419809792,
  "created_at" : "2011-08-28 10:25:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107759618733772800",
  "text" : "\u56E0\u6570\u5206\u89E3bot\u597D\u304D\u3060\u306A\u30FC\u3002\u30B7\u30E5\u30FC\u30EB\u3060\u3057\u3002\u5B9F\u969B\u8AB0\u5F97\u611F\u304C\u3044\u3044\u306D\u3002\u4FFA\u5F97\u306A\u306E\u304B\u3002",
  "id" : 107759618733772800,
  "created_at" : "2011-08-28 10:21:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107759313442963456",
  "text" : "\u30B9\u30AB\u30A4\u30D7\u4EBA\u5C11\u306A\u3044\u306A",
  "id" : 107759313442963456,
  "created_at" : "2011-08-28 10:19:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107757261581062144",
  "geo" : { },
  "id_str" : "107758744607264768",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u7A81\u7136\u3082\u3057\u3083\u3082\u3057\u3083",
  "id" : 107758744607264768,
  "in_reply_to_status_id" : 107757261581062144,
  "created_at" : "2011-08-28 10:17:41 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107757259676856321",
  "text" : "\u696D\u8005\u3081\u3044\u305F\u3084\u3064\u304C\u56E0\u6570\u5206\u89E3\u3055\u308C\u3066\u308B\u3068\u7B11\u3048\u308B\u3002",
  "id" : 107757259676856321,
  "created_at" : "2011-08-28 10:11:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "101753216",
      "id" : 101753216
    }, {
      "name" : "yumiko\/hidaka",
      "screen_name" : "yumiko_987",
      "indices" : [ 45, 56 ],
      "id_str" : "254422068",
      "id" : 254422068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jVED0Jq",
      "expanded_url" : "http:\/\/www.infocart.jp\/e\/44347\/146002\/",
      "display_url" : "infocart.jp\/e\/44347\/146002\/"
    } ]
  },
  "geo" : { },
  "id_str" : "107757082723360768",
  "text" : "RT @factoring_bot: 8000=2*2*2*2*2*2*5*5*5 RT @yumiko_987: \u306A\u305C\u300190\u65E5\u3067\u30D5\u30A9\u30ED\u30EF\u30FC8000\u4EBA\u3092\u7A81\u7834\u3057\u3066\u3001\u305D\u306E\u5F8C\u3082\u30B3\u30F3\u30B9\u30BF\u30F3\u30C8\u306B\u30D5\u30A9\u30ED\u30EF\u30FC\u304C\u5897\u3048\u7D9A\u3051\u30011\u4E07\u4EBA\u3092\u7A81\u7834\u3067\u304D\u305F\u306E\u304B\uFF1F\u305D\u306E\u79D8\u5BC6\u3092\u77E5\u308A\u305F\u3044\u65B9\u306B\u306F\u30AA\u30B9\u30B9\u30E1\u3067\u3059\u3002ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/prime.4403.biz\/factoring_bot\/\" rel=\"nofollow\"\u003Efactoring_bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "yumiko\/hidaka",
        "screen_name" : "yumiko_987",
        "indices" : [ 26, 37 ],
        "id_str" : "254422068",
        "id" : 254422068
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 134 ],
        "url" : "http:\/\/t.co\/jVED0Jq",
        "expanded_url" : "http:\/\/www.infocart.jp\/e\/44347\/146002\/",
        "display_url" : "infocart.jp\/e\/44347\/146002\/"
      } ]
    },
    "geo" : { },
    "id_str" : "107755822653779968",
    "text" : "8000=2*2*2*2*2*2*5*5*5 RT @yumiko_987: \u306A\u305C\u300190\u65E5\u3067\u30D5\u30A9\u30ED\u30EF\u30FC8000\u4EBA\u3092\u7A81\u7834\u3057\u3066\u3001\u305D\u306E\u5F8C\u3082\u30B3\u30F3\u30B9\u30BF\u30F3\u30C8\u306B\u30D5\u30A9\u30ED\u30EF\u30FC\u304C\u5897\u3048\u7D9A\u3051\u30011\u4E07\u4EBA\u3092\u7A81\u7834\u3067\u304D\u305F\u306E\u304B\uFF1F\u305D\u306E\u79D8\u5BC6\u3092\u77E5\u308A\u305F\u3044\u65B9\u306B\u306F\u30AA\u30B9\u30B9\u30E1\u3067\u3059\u3002http:\/\/t.co\/jVED0Jq",
    "id" : 107755822653779968,
    "created_at" : "2011-08-28 10:06:04 +0000",
    "user" : {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "protected" : false,
      "id_str" : "101753216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727655584\/factan_normal.png",
      "id" : 101753216,
      "verified" : false
    }
  },
  "id" : 107757082723360768,
  "created_at" : "2011-08-28 10:11:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107749686840004610",
  "text" : "\u3069\u3046\u307F\u3066\u3082\u53F3\u4E0A\u304A\u304B\u3057\u3044\u306D",
  "id" : 107749686840004610,
  "created_at" : "2011-08-28 09:41:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 28 ],
      "url" : "http:\/\/t.co\/zJuP6ip",
      "expanded_url" : "http:\/\/alg-d.com\/game\/puyo\/course.html",
      "display_url" : "alg-d.com\/game\/puyo\/cour\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "107730416265474048",
  "geo" : { },
  "id_str" : "107731116655509504",
  "in_reply_to_user_id" : 115959501,
  "text" : "@yuu_ane http:\/\/t.co\/zJuP6ip\u3000\u8AAC\u660E\u3057\u306B\u304F\u3044\u306E\u3067\u30B5\u30A4\u30C8\u3069\u305E\u30FC",
  "id" : 107731116655509504,
  "in_reply_to_status_id" : 107730416265474048,
  "created_at" : "2011-08-28 08:27:54 +0000",
  "in_reply_to_screen_name" : "yuu_harune",
  "in_reply_to_user_id_str" : "115959501",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107729457896361985",
  "geo" : { },
  "id_str" : "107730093639606273",
  "in_reply_to_user_id" : 115959501,
  "text" : "@yuu_ane \u50D5\u3082\u6628\u65E5\u8CB7\u3044\u307E\u3057\u305F\u3088\u30FC\u3002\u968E\u6BB5\u7A4D\u307F\u304B\u3089\uFF01",
  "id" : 107730093639606273,
  "in_reply_to_status_id" : 107729457896361985,
  "created_at" : "2011-08-28 08:23:50 +0000",
  "in_reply_to_screen_name" : "yuu_harune",
  "in_reply_to_user_id_str" : "115959501",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107706174308229120",
  "text" : "\u3086\u3063\u304F\u308A\u3060\u3051\u306911\u9023\u9396\u307E\u3067\u306A\u3089\u7D44\u3081\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u304D\u305F\u3002\u66B4\u767A\u6016\u3057\u3002",
  "id" : 107706174308229120,
  "created_at" : "2011-08-28 06:48:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107703496500977664",
  "text" : "\u30B5\u30A4\u30F3\u3001\u30B3\u30B5\u30A4\u30F3\u3001\u30BF\u30F3\u30B8\u30A7\u30F3\u30C8\u3001\u30A4\u30F3\u30C6\u30B0\u30E9\u30EB\u266A",
  "id" : 107703496500977664,
  "created_at" : "2011-08-28 06:38:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107422283135590400",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 107422283135590400,
  "created_at" : "2011-08-27 12:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107391472550162432",
  "text" : "\u30A2\u30A4\u30B3\u30F3\u3092\u201D\u898B\u7D42\u308F\u3089\u306A\u304B\u3063\u305F\u201D\u306E\u3067\u6B21\u306E\u6BB5\u968E\u306B\u9032\u3081\u307E\u305B\u3093\uFF1E\uFF1C",
  "id" : 107391472550162432,
  "created_at" : "2011-08-27 09:58:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3073\u304F\u305D\u3093",
      "screen_name" : "B1x0N",
      "indices" : [ 3, 9 ],
      "id_str" : "135419587",
      "id" : 135419587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107391298603978752",
  "text" : "RT @B1x0N: \u304A\u524D\u3089\u81EA\u5206\u306E\u30A2\u30A4\u30B3\u30F3\u898B\u3066\uFF1F\u3046\u3093\u3001\u305D\u306E\u5F8C\u93E1\u898B\u3066\u304D\u3066\uFF1F\u3069\u3046\u601D\u3063\u305F\uFF1F\u305D\u3046\u3060\u306D\u3001\u3054\u3081\u3093\u306A\u3055\u3044\u3057\u306A\u304D\u3083\u306D\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105968639634706432",
    "text" : "\u304A\u524D\u3089\u81EA\u5206\u306E\u30A2\u30A4\u30B3\u30F3\u898B\u3066\uFF1F\u3046\u3093\u3001\u305D\u306E\u5F8C\u93E1\u898B\u3066\u304D\u3066\uFF1F\u3069\u3046\u601D\u3063\u305F\uFF1F\u305D\u3046\u3060\u306D\u3001\u3054\u3081\u3093\u306A\u3055\u3044\u3057\u306A\u304D\u3083\u306D\u3002",
    "id" : 105968639634706432,
    "created_at" : "2011-08-23 11:44:27 +0000",
    "user" : {
      "name" : "\u3073\u304F\u305D\u3093",
      "screen_name" : "B1x0N",
      "protected" : false,
      "id_str" : "135419587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573841627283763200\/jaESUxe4_normal.jpeg",
      "id" : 135419587,
      "verified" : false
    }
  },
  "id" : 107391298603978752,
  "created_at" : "2011-08-27 09:57:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107297710687797249",
  "geo" : { },
  "id_str" : "107298781363576832",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu \u3046\u3061\u306E\u5F1F\u3082\u305D\u3046\u306A\u306E\u3060\u3051\u308C\u3069\u5E74\u306E\u8FD1\u3044\u59B9\u3063\u3066\u9B31\u9676\u3057\u3044\u3082\u306E\u306A\u306E\u304B\u306A\u30FC\u3001\u81EA\u5206\u306F\u96E2\u308C\u3059\u304E\u3066\u3066\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3002",
  "id" : 107298781363576832,
  "in_reply_to_status_id" : 107297710687797249,
  "created_at" : "2011-08-27 03:49:57 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107277413645422592",
  "geo" : { },
  "id_str" : "107298468556582912",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u300C\u3044\u308B\uFF1F\u300D\u3063\u3066\u805E\u304F\u6BB5\u968E\u3067\u51FA\u6765\u305F\u59B9\u306A\u306E\u306B\u306D\u3047\u3002\u8981\u3089\u306A\u3044\u306A\u3089\u5165\u3089\u306A\u3044\u3067\u300C\u98DF\u3079\u3066\u3044\u3044\u3088\u300D\u3063\u3066\u4E00\u8A00\u3044\u3046\u3079\u304D\u3060\u3088\u306D\u3002\u4F1A\u8A71\u306F\u610F\u601D\u758E\u901A\u306E\u57FA\u672C\u3060\u3088\u3002",
  "id" : 107298468556582912,
  "in_reply_to_status_id" : 107277413645422592,
  "created_at" : "2011-08-27 03:48:43 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107038377521582080",
  "text" : "RT @wwwwww_bot: \u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\uFF0F\u305F\u304F\u3055\u3093\u3044\u308B\u306D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107037697075445760",
    "text" : "\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\u9752\u5C71\u30C6\u30EB\u30DE\uFF0F\u305F\u304F\u3055\u3093\u3044\u308B\u306D",
    "id" : 107037697075445760,
    "created_at" : "2011-08-26 10:32:30 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 107038377521582080,
  "created_at" : "2011-08-26 10:35:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107036417460408321",
  "text" : "\u8377\u7269\u304B\u3089\u30A2\u30DE\u30BE\u30F3\u304C\u5C4A\u304B\u306A\u3044",
  "id" : 107036417460408321,
  "created_at" : "2011-08-26 10:27:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107035046099165184",
  "text" : "\u96E8\u97F3\u3059\u3054\u3044\u3093\u3067\u3059\uFF1F",
  "id" : 107035046099165184,
  "created_at" : "2011-08-26 10:21:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 16, 30 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/Srjppet",
      "expanded_url" : "http:\/\/twitpic.com\/6be7y1",
      "display_url" : "twitpic.com\/6be7y1"
    }, {
      "indices" : [ 65, 84 ],
      "url" : "http:\/\/t.co\/CGRfCZJ",
      "expanded_url" : "http:\/\/twitpic.com\/6be7zu",
      "display_url" : "twitpic.com\/6be7zu"
    } ]
  },
  "geo" : { },
  "id_str" : "107034562697244673",
  "text" : "\u30DB\u30F3\u30C8\u3069\u3046\u304B\u3057\u3066\u308B\u307F\u305F\u3044 RT @nico_reflexio: \u3042\u306E\u82B1\u306E\u65E5\u672C\u9152\uFF01\uFF01\uFF01   http:\/\/t.co\/Srjppet http:\/\/t.co\/CGRfCZJ",
  "id" : 107034562697244673,
  "created_at" : "2011-08-26 10:20:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 15, 26 ],
      "id_str" : "229752118",
      "id" : 229752118
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 28, 39 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107030849278574592",
  "text" : "\u306B\u305B\u307B\u97F3\u30B2\u30FC\u5927\u597D\u304D\u3060\u306A RT @nisehorrrn: @magokoro84 \u6700\u5F8C\u306EDXY!\u3063\u3066\u66F2\u306E\u30CF\u30A4\u30D1\u30FC\u3080\u305A\u304B\u3057\u304B\u3063\u305F\u3051\u3069\u3053\u308C\u260611\u2192\u260611\u2192\u260612\u3060\u304B\u3089\u4ECA\u306E8.5\u6BB5\u304F\u3089\u3044\u304B\u3082",
  "id" : 107030849278574592,
  "created_at" : "2011-08-26 10:05:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3064\u304B\u3093\u307D",
      "screen_name" : "tsukampo",
      "indices" : [ 3, 12 ],
      "id_str" : "82107012",
      "id" : 82107012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106960641033633792",
  "text" : "RT @tsukampo: \u30A2\u30CB\u30E1\u30AA\u30BF\u30AF\u306E\u4EBA\u304C\u300C\u25CF\u25CF\u541B\u3063\u3066\u30AA\u30BF\u30AF\u306A\u3093\u3060\u30FC\u3002\u3058\u3083\u3042AKB\u3068\u304B\u597D\u304D\u306A\u3093\u3067\u3057\u3087\u300D\u3068\u304B\u8A00\u308F\u308C\u305F\u308A\u3059\u308B\u306E\u306F\u3001\u30D7\u30ED\u30B0\u30E9\u30DE\u304C\u89AA\u621A\u306E\u304A\u3058\u3055\u3093\u306B\u300C\u6A5F\u68B0\u306B\u5F37\u3044\u3093\u3060\u308D\uFF1F\u3061\u3087\u3063\u3068\u6D17\u6FEF\u6A5F\u76F4\u3057\u3066\u304F\u3093\u306D\u3048\u304B\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u306E\u306B\u4F3C\u3066\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106723990600548353",
    "text" : "\u30A2\u30CB\u30E1\u30AA\u30BF\u30AF\u306E\u4EBA\u304C\u300C\u25CF\u25CF\u541B\u3063\u3066\u30AA\u30BF\u30AF\u306A\u3093\u3060\u30FC\u3002\u3058\u3083\u3042AKB\u3068\u304B\u597D\u304D\u306A\u3093\u3067\u3057\u3087\u300D\u3068\u304B\u8A00\u308F\u308C\u305F\u308A\u3059\u308B\u306E\u306F\u3001\u30D7\u30ED\u30B0\u30E9\u30DE\u304C\u89AA\u621A\u306E\u304A\u3058\u3055\u3093\u306B\u300C\u6A5F\u68B0\u306B\u5F37\u3044\u3093\u3060\u308D\uFF1F\u3061\u3087\u3063\u3068\u6D17\u6FEF\u6A5F\u76F4\u3057\u3066\u304F\u3093\u306D\u3048\u304B\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u306E\u306B\u4F3C\u3066\u308B\u3002",
    "id" : 106723990600548353,
    "created_at" : "2011-08-25 13:45:56 +0000",
    "user" : {
      "name" : "\u3064\u304B\u3093\u307D",
      "screen_name" : "tsukampo",
      "protected" : false,
      "id_str" : "82107012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539509033\/20081124214405_normal.jpg",
      "id" : 82107012,
      "verified" : false
    }
  },
  "id" : 106960641033633792,
  "created_at" : "2011-08-26 05:26:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106942872875565056",
  "text" : "\u304A\u663C\u2026\u98DF\u3079\u306A\u304D\u3083",
  "id" : 106942872875565056,
  "created_at" : "2011-08-26 04:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106695513771999232",
  "geo" : { },
  "id_str" : "106898004392423424",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u3042\u3001\u8AA4\u89E3\u306E\u306A\u3044\u3088\u3046\u306B\u8A00\u3063\u3066\u304A\u304F\u3051\u3069\u4F55\u306E\u5909\u54F2\u3082\u306A\u3044\u62B1\u304D\u6795\u3067\u30AD\u30E3\u30E9\u3082\u306E\u3068\u304B\u3058\u3083\u306A\u3044\u3088\u3063\uFF01",
  "id" : 106898004392423424,
  "in_reply_to_status_id" : 106695513771999232,
  "created_at" : "2011-08-26 01:17:24 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106721364261617664",
  "text" : "RT @_flyingmoomin: \u300C\u653E\u3063\u3066\u304A\u3051\u306A\u3044\u4E00\u610F\u6027\uFF1F\u300D\n\u300C\u672C\u6C17\u306B\u306A\u308C\u306A\u3044\u4E8C\u9805\u5B9A\u7406\uFF1F\u300D\n\u300C\u81EA\u6162\u306B\u306A\u3089\u306A\u3044\u4E09\u89D2\u51FD\u6570\uFF1F\u300D\n\u300C\u540C\u60C5\u3067\u304D\u306A\u3044\u56DB\u8272\u554F\u984C\uFF1F\u300D\n\u300C\u3069\u3046\u306B\u3082\u306A\u3089\u306A\u3044\u4E94\u9805\u88DC\u984C\uFF1F\u300D\n\u300C\u3042\u3066\u306B\u306A\u3089\u306A\u3044\u516D\u7403\u9023\u9396\uFF1F\u300D\n\u300C\u5B89\u5FC3\u3067\u304D\u306A\u3044\u4E03\u6B21\u5143\u7403\u9762\uFF1F\u300D\n\u300C\u60A9\u3093\u3067\u3089\u308C\u306A\u3044\u516B\u5143\u6570\uFF1F\u300D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106717478159261696",
    "text" : "\u300C\u653E\u3063\u3066\u304A\u3051\u306A\u3044\u4E00\u610F\u6027\uFF1F\u300D\n\u300C\u672C\u6C17\u306B\u306A\u308C\u306A\u3044\u4E8C\u9805\u5B9A\u7406\uFF1F\u300D\n\u300C\u81EA\u6162\u306B\u306A\u3089\u306A\u3044\u4E09\u89D2\u51FD\u6570\uFF1F\u300D\n\u300C\u540C\u60C5\u3067\u304D\u306A\u3044\u56DB\u8272\u554F\u984C\uFF1F\u300D\n\u300C\u3069\u3046\u306B\u3082\u306A\u3089\u306A\u3044\u4E94\u9805\u88DC\u984C\uFF1F\u300D\n\u300C\u3042\u3066\u306B\u306A\u3089\u306A\u3044\u516D\u7403\u9023\u9396\uFF1F\u300D\n\u300C\u5B89\u5FC3\u3067\u304D\u306A\u3044\u4E03\u6B21\u5143\u7403\u9762\uFF1F\u300D\n\u300C\u60A9\u3093\u3067\u3089\u308C\u306A\u3044\u516B\u5143\u6570\uFF1F\u300D\n\u300C\u30DE\u30B8\u3067\u5371\u306A\u3044\u4E5D\u5927\u6570\u7406\uFF1F\u300D",
    "id" : 106717478159261696,
    "created_at" : "2011-08-25 13:20:04 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 106721364261617664,
  "created_at" : "2011-08-25 13:35:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106697447736225793",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 106697447736225793,
  "created_at" : "2011-08-25 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106693805411020800",
  "text" : "\u5B9F\u5BB6\u306B\u3044\u3066\u4F55\u304C\u8F9B\u304B\u3063\u305F\u3063\u3066\u62B1\u304D\u307E\u304F\u3089\u304C\u306A\u3044",
  "id" : 106693805411020800,
  "created_at" : "2011-08-25 11:46:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 3, 14 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106625418169286656",
  "text" : "RT @nisehorrrn: \u30AF\u30C3\u30AD\u30FC\u521D\u629C\u3051\u3067\u4E0D\u6C88\u8266\u30E9\u30B9\u30C8\u7DCA\u5F35\u3057\u3066\u843D\u3061\u305F\u306E\u306F\u3044\u3044\u601D\u3044\u51FA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106624284109176832",
    "text" : "\u30AF\u30C3\u30AD\u30FC\u521D\u629C\u3051\u3067\u4E0D\u6C88\u8266\u30E9\u30B9\u30C8\u7DCA\u5F35\u3057\u3066\u843D\u3061\u305F\u306E\u306F\u3044\u3044\u601D\u3044\u51FA",
    "id" : 106624284109176832,
    "created_at" : "2011-08-25 07:09:44 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "protected" : false,
      "id_str" : "229752118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009819094\/110325_010601a_normal.jpg",
      "id" : 229752118,
      "verified" : false
    }
  },
  "id" : 106625418169286656,
  "created_at" : "2011-08-25 07:14:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106621397220073472",
  "text" : "\u982D\u75DB\u3068\u7A7A\u8179\u3068\u7761\u7720\u4E0D\u8DB3\u306E\u7D20\u6575\u306A\u30B3\u30E9\u30DC\u30EC\u30FC\u30B7\u30E7\u30F3",
  "id" : 106621397220073472,
  "created_at" : "2011-08-25 06:58:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106617860188667904",
  "text" : "\u751F\u6D3B\u30EA\u30BA\u30E0\u304C\u51C4\u3044\u52E2\u3044\u3067\u5D29\u58CA\u3057\u305F\u2026",
  "id" : 106617860188667904,
  "created_at" : "2011-08-25 06:44:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106235314288336898",
  "text" : "\u8AAD\u307F\u7D42\u3048\u3061\u307E\u3063\u305F\u3002\u4ED6\u306E\u4F5C\u54C1\u3088\u308A\u3082\u30E9\u30D6\u30B3\u30E1\u307D\u304B\u3063\u305F\u304B\u306A\u30FC\u3002\u622F\u8A00\u4F7F\u3044\u3068\u9752\u8272\u3001\u3042\u308B\u3044\u306F\u30A2\u30E9\u30E9\u30AE\u5144\u5F1F\u3088\u308A\u3082\u3002",
  "id" : 106235314288336898,
  "created_at" : "2011-08-24 05:24:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106227145059213313",
  "text" : "\u5EA7\u3063\u3066\u308B\u6642\u9593\u3068\u52D5\u3044\u305F\u8DDD\u96E2\u304C\u611F\u899A\u3068\u3057\u3066\u4E00\u5BFE\u4E00\u5BFE\u5FDC\u3057\u306A\u3044\u3093\u3060\u3088\u306A\u2026",
  "id" : 106227145059213313,
  "created_at" : "2011-08-24 04:51:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106226945817198594",
  "text" : "\u6D77\u5916\u306F\u6642\u5DEE\u3082\u624B\u4F1D\u3063\u3066\u8DDD\u96E2\u3068\u3044\u3046\u3088\u308A\u5225\u4E16\u754C\u306B\u79FB\u3063\u305F\uFF08\u5199\u3063\u305F\uFF09\u611F\u3058\u3060\u3051\u3069\u5730\u7D9A\u304D\u306E\u79FB\u52D5\u304C\u65E9\u904E\u304E\u308B\u3068\u5947\u5999\u306A\u611F\u899A\u2026\u3002",
  "id" : 106226945817198594,
  "created_at" : "2011-08-24 04:50:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106226589477502976",
  "text" : "\u3082\u3046\u540D\u53E4\u5C4B\u2026",
  "id" : 106226589477502976,
  "created_at" : "2011-08-24 04:49:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106223150257287168",
  "text" : "\u611B\u77E5\u770C\u8C4A\u6A4B\u3089\u3057\u3044",
  "id" : 106223150257287168,
  "created_at" : "2011-08-24 04:35:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106222750653358080",
  "text" : "\u4ECA\u3069\u306E\u8FBA\u306A\u306E\u304B\u308F\u304B\u3093\u306A\u3044\u306E\u304C\u65B0\u5E79\u7DDA\u306E\u826F\u304F\u306A\u3044\u3068\u3053\u308D\u3002\u8DDD\u96E2\u611F\u72C2\u3046\u3002",
  "id" : 106222750653358080,
  "created_at" : "2011-08-24 04:34:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106222503717896192",
  "text" : "\u65E5\u672C\u8A9E\u304C\u6BCD\u8A9E\u3067\u826F\u304B\u3063\u305F\u3002\u3053\u308C\u3060\u3051\u904A\u3079\u308B\u8A00\u8A9E\u3082\u3042\u308B\u307E\u3044\u3002",
  "id" : 106222503717896192,
  "created_at" : "2011-08-24 04:33:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106222209349062657",
  "text" : "\u305D\u3049\u3044\u2026",
  "id" : 106222209349062657,
  "created_at" : "2011-08-24 04:32:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106222028033490944",
  "text" : "\u8A8D\u8B58\u306E\u76F8\u9055\u3001\u5275\u610F\u3001\u5275\u75CD\u3002",
  "id" : 106222028033490944,
  "created_at" : "2011-08-24 04:31:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106209872600772608",
  "text" : "\u304D\u307F\u3068\u307C\u304F\u306E\u58CA\u308C\u305F\u4E16\u754C\u306A\u3046 \u3042\u3068\u65B0\u5E79\u7DDA\u306A\u3046",
  "id" : 106209872600772608,
  "created_at" : "2011-08-24 03:43:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106183497084964864",
  "text" : "\u30D7\u30ED\u30B0\u30E9\u30E0\u8A00\u8A9E\u3092\uFF23\u7FA4\u3067\u767B\u9332\u3067\u304D\u306A\u3044\u306E\u304B\uFF08\u5207\u5B9F",
  "id" : 106183497084964864,
  "created_at" : "2011-08-24 01:58:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30AD\/\u3046\u305F\u304B\u305F",
      "screen_name" : "yoshiki_utakata",
      "indices" : [ 3, 19 ],
      "id_str" : "83811178",
      "id" : 83811178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106182734258515969",
  "text" : "RT @yoshiki_utakata: \u300C\u4EAC\u5927\u306F\u5358\u4F4D\u304C\u964D\u3063\u3066\u304D\u3066\u901A\u904E\u3057\u3066\u4E0B\u306B\u843D\u3061\u308B\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106181624735076352",
    "text" : "\u300C\u4EAC\u5927\u306F\u5358\u4F4D\u304C\u964D\u3063\u3066\u304D\u3066\u901A\u904E\u3057\u3066\u4E0B\u306B\u843D\u3061\u308B\u300D",
    "id" : 106181624735076352,
    "created_at" : "2011-08-24 01:50:46 +0000",
    "user" : {
      "name" : "\u30E8\u30B7\u30AD\/\u3046\u305F\u304B\u305F",
      "screen_name" : "yoshiki_utakata",
      "protected" : false,
      "id_str" : "83811178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596630159605665795\/sX5kSa0j_normal.jpg",
      "id" : 83811178,
      "verified" : false
    }
  },
  "id" : 106182734258515969,
  "created_at" : "2011-08-24 01:55:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106181603084091392",
  "text" : "\u307E\u3001\u52AA\u529B\u3057\u3066\u306A\u3044\u3057\u3044\u3044\u3084\u2190\u672C\u97F3",
  "id" : 106181603084091392,
  "created_at" : "2011-08-24 01:50:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106181508452196354",
  "text" : "\u4E88\u5B9A\u5916\u306E\u30D5\u30E9\u30F3\u30B9\u8A9E\u304C\u4E00\u3064\u30C0\u30E1\u306B\u306A\u3063\u3066\u308B\u2026",
  "id" : 106181508452196354,
  "created_at" : "2011-08-24 01:50:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106170226743312384",
  "text" : "\u3010\u901F\u5831\u3011\u96C6\u5408\u3068\u4F4D\u76F8 \u53EF",
  "id" : 106170226743312384,
  "created_at" : "2011-08-24 01:05:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105972731648020481",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 105972731648020481,
  "created_at" : "2011-08-23 12:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u307A\u3067\u3043",
      "screen_name" : "copedy",
      "indices" : [ 3, 10 ],
      "id_str" : "152242373",
      "id" : 152242373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105856646869295104",
  "text" : "RT @copedy: \u5973\u300C\u306D\u3048\uFF01\u30E9\u30D6\u30DB\u30C6\u30EB\u3063\u3066\u9023\u7D9A\u3067\u8A00\u3063\u3066\uFF01\u300D\n\n\u7537\u300C\u30E9\u30D6\u30DB\u30C6\u30EB\u30E9\u30D6\u30DB\u30C6\u30EB\u300D\n\n\u5973\u300C\u3082\u3063\u3068\u3082\u3063\u3068\uFF01\u300D\n\n\u7537\u300C\u30E9\u30D6\u30DB\u30C6\u30EB\u30E9\u30D6\u30DB\u30C6\u30EB\u30E9\u30D6\u30DB\u2026\u300D\n\n\u5973\u300C\u30E9\u30D6\u30DB\u30C6\u30EB\u3063\u3066\u4F55\u56DE\u3044\u3063\u305F\uFF1F\u300D\n\n\u7537\u300C10\u56DE\u304F\u3089\u3044\u3060\u3063\u3051\uFF1F\u300D\n\n\u5973\u300C\u305D\u3001\u305D\u3093\u306A\u306B\u884C\u3063\u3066\u306A\u3044\u3088\u3045\uFF01\u3070\u304B\u3041\/\/\/\u300D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64639919926157312",
    "text" : "\u5973\u300C\u306D\u3048\uFF01\u30E9\u30D6\u30DB\u30C6\u30EB\u3063\u3066\u9023\u7D9A\u3067\u8A00\u3063\u3066\uFF01\u300D\n\n\u7537\u300C\u30E9\u30D6\u30DB\u30C6\u30EB\u30E9\u30D6\u30DB\u30C6\u30EB\u300D\n\n\u5973\u300C\u3082\u3063\u3068\u3082\u3063\u3068\uFF01\u300D\n\n\u7537\u300C\u30E9\u30D6\u30DB\u30C6\u30EB\u30E9\u30D6\u30DB\u30C6\u30EB\u30E9\u30D6\u30DB\u2026\u300D\n\n\u5973\u300C\u30E9\u30D6\u30DB\u30C6\u30EB\u3063\u3066\u4F55\u56DE\u3044\u3063\u305F\uFF1F\u300D\n\n\u7537\u300C10\u56DE\u304F\u3089\u3044\u3060\u3063\u3051\uFF1F\u300D\n\n\u5973\u300C\u305D\u3001\u305D\u3093\u306A\u306B\u884C\u3063\u3066\u306A\u3044\u3088\u3045\uFF01\u3070\u304B\u3041\/\/\/\u300D\n\n\u7537\u300C\u304A\u524D\u3068\u306F\u306D\u300D\n\n\u5973\u300C\u2026\u300D",
    "id" : 64639919926157312,
    "created_at" : "2011-05-01 10:38:52 +0000",
    "user" : {
      "name" : "\u3053\u307A\u3067\u3043",
      "screen_name" : "copedy",
      "protected" : false,
      "id_str" : "152242373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428845627313647616\/yx6wMaK6_normal.jpeg",
      "id" : 152242373,
      "verified" : false
    }
  },
  "id" : 105856646869295104,
  "created_at" : "2011-08-23 04:19:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/PQsZgWo",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105794444661506048",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/PQsZgWo",
  "id" : 105794444661506048,
  "created_at" : "2011-08-23 00:12:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u304A\u306A\u3057",
      "screen_name" : "kao__nashi",
      "indices" : [ 3, 14 ],
      "id_str" : "42397277",
      "id" : 42397277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105778407786283008",
  "text" : "RT @kao__nashi: \u53CB\u4EBA\u3068\u306E\u4F1A\u8A71\u3067\u9CE5\u4EBA\u9593\u30B3\u30F3\u30C6\u30B9\u30C8\u306E\u8A71\u984C\u304C\u51FA\u3066\u300C\u3042\u30FC\u3001\u4FFA\u3082\u3042\u3042\u3084\u3063\u3066\u305D\u308C\u3057\u304B\u898B\u3048\u306A\u304F\u3063\u3066\u305D\u308C\u306B\u547D\u304B\u3051\u308C\u308B\u3088\u3046\u306A\u300E\uFF5E\uFF5E\u99AC\u9E7F\u300F\u306B\u306A\u308A\u305F\u3044\u308F\u3002\u6700\u9AD8\u3060\u3088\u306A\u3001\u9CE5\u4EBA\u9593\u99AC\u9E7F\u3002\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3093\u3060\u3051\u3069\u9CE5\u4EBA\u9593\u99AC\u9E7F\u306E\u5B57\u306B\u3057\u305F\u6642\u306E\u30AD\u30E1\u30E9\u611F\u3059\u3054\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105627108340006912",
    "text" : "\u53CB\u4EBA\u3068\u306E\u4F1A\u8A71\u3067\u9CE5\u4EBA\u9593\u30B3\u30F3\u30C6\u30B9\u30C8\u306E\u8A71\u984C\u304C\u51FA\u3066\u300C\u3042\u30FC\u3001\u4FFA\u3082\u3042\u3042\u3084\u3063\u3066\u305D\u308C\u3057\u304B\u898B\u3048\u306A\u304F\u3063\u3066\u305D\u308C\u306B\u547D\u304B\u3051\u308C\u308B\u3088\u3046\u306A\u300E\uFF5E\uFF5E\u99AC\u9E7F\u300F\u306B\u306A\u308A\u305F\u3044\u308F\u3002\u6700\u9AD8\u3060\u3088\u306A\u3001\u9CE5\u4EBA\u9593\u99AC\u9E7F\u3002\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3093\u3060\u3051\u3069\u9CE5\u4EBA\u9593\u99AC\u9E7F\u306E\u5B57\u306B\u3057\u305F\u6642\u306E\u30AD\u30E1\u30E9\u611F\u3059\u3054\u3044\u3002",
    "id" : 105627108340006912,
    "created_at" : "2011-08-22 13:07:19 +0000",
    "user" : {
      "name" : "\u304B\u304A\u306A\u3057",
      "screen_name" : "kao__nashi",
      "protected" : false,
      "id_str" : "42397277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1773042993\/220856380_normal.jpg",
      "id" : 42397277,
      "verified" : false
    }
  },
  "id" : 105778407786283008,
  "created_at" : "2011-08-22 23:08:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105643787384127490",
  "text" : "@np2i \u30DE\u30C1\u3068\u3044\u3046\u304B\u2026\u6DF5\u306E\u539A\u624B\u306E\u90E8\u5206\u3068\u3001\u3075\u3064\u3046\u306E\u5E03\u306E\u90E8\u5206\u306E\u9593\u304C\u64E6\u308A\u5207\u308C\u3066\u305D\u3053\u304B\u3089\u5C11\u3057\u305A\u3064\u88C2\u3051\u3066\u3044\u3063\u305F\u611F\u3058\u3067\u3059\u3002\u8AAC\u660E\u3057\u306B\u304F\u3044\u306E\u3067\u3059\u304C\uFF57\u50D5\u3082\u521D\u3081\u3066\u3067\u3059\u3088\u3001\u3053\u3093\u306A\u306E\u3002",
  "id" : 105643787384127490,
  "created_at" : "2011-08-22 14:13:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105640982267179008",
  "text" : "@np2i \u3057\u3070\u3089\u304F\u305D\u3046\u3057\u3066\u305F\u3093\u3067\u3059\u304C\u3060\u3093\u3060\u3093\u88C2\u3051\u76EE\u304C\u5E83\u304C\u3063\u3066\u6765\u3066\u308B\u3093\u3067\u3059\u3088\u306D\u3002\u7740\u7D9A\u3051\u305F\u3044\u306A\u3089\u5207\u308B\u3057\u304B\u306A\u3044\u304B\u306A\u3001\u3068\u3002",
  "id" : 105640982267179008,
  "created_at" : "2011-08-22 14:02:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105633736338571264",
  "text" : "\u8584\u3044\u30B7\u30E3\u30C4\u3060\u3057\u8896\u307E\u308F\u308A\u3060\u3057\u5F53\u3066\u5E03\u3063\u3066\u306E\u3082\u7121\u7406\u3060\u3082\u3093\u306A\u30FC",
  "id" : 105633736338571264,
  "created_at" : "2011-08-22 13:33:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105633476694380545",
  "text" : "\u304A\u6C17\u306B\u5165\u308A\u306E\uFF39\u30B7\u30E3\u30C4\u306E\u8896\u53E3\u306E\u88C2\u3051\u76EE\u304C\u5E83\u304C\u3063\u3066\u53CE\u96C6\u3064\u304B\u306A\u304F\u306A\u3063\u305F\u304B\u3089\u534A\u305D\u3067\u306B\u3057\u3066\u3057\u307E\u304A\u3046\u304B\u3068\u691C\u8A0E\u4E2D\u3002\u53F3\u304C\u88C2\u3051\u3066\u308B\u3093\u3067\u5DE6\u3060\u3051\u9577\u8896\u3063\u3066\u306E\u3082\u8003\u3048\u306A\u3044\u3067\u306F\u306A\u3044\u304C\u30FB\u30FB\u30FB\u3002\u5DE6\u53F3\u306E\u305D\u3067\u306E\u9577\u3055\u304C\u9055\u3046\u30B7\u30E3\u30C4\u3063\u3066\u7D76\u5BFE\u4E2D\u4E8C\u75C5\u611F\u3067\u308B\u3088\u306A\u30FC\u3002",
  "id" : 105633476694380545,
  "created_at" : "2011-08-22 13:32:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105632798483820544",
  "text" : "\u6B7B\u3093\u3060\u9AB8\u9AA8\u3068\u3044\u3046\u8868\u73FE\u306F\u6697\u306B\u6B7B\u3093\u3067\u3044\u306A\u3044\u9AB8\u9AA8\u306E\u5B58\u5728\u3092\u5302\u308F\u305B\u308B\u3088\u306D\u3002\u3080\u304F\u308D \u3067 \u307B\u306D \u3067\u4E14\u3064 \u751F\u304D\u3066 \u3044\u308B\u3093\u3060\u304B\u3089\u3053\u308C\u306F\u3059\u3054\u3044",
  "id" : 105632798483820544,
  "created_at" : "2011-08-22 13:29:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105632466735341568",
  "text" : "\u3042\u3068\u3042\u3060\u540D\u304C\u6B7B\u3093\u3060\u9AB8\u9AA8\u3060\u3063\u305F\u5973\u306E\u5B50\u304C\u3044\u305F\u306A\u3001\u3044\u3084\u3001\u9670\u3067\u4E00\u90E8\u306B\u8A00\u308F\u308C\u3066\u305F\u3060\u3051\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 105632466735341568,
  "created_at" : "2011-08-22 13:28:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105632115844063233",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u30E9\u30FC\u30E1\u30F3\u597D\u304D\u3092\u81EA\u79F0\u3057\u306A\u304C\u3089\u4E00\u756A\u597D\u304D\u306A\u30E9\u30FC\u30E1\u30F3\u5C4B\u3055\u3093\u304C\u300C\u65E5\u9AD8\u5C4B\u300D\u3060\u3063\u305F\u9AD8\u6821\u306E\u540C\u671F\u304C\u3044\u305F\u306A\u3002",
  "id" : 105632115844063233,
  "created_at" : "2011-08-22 13:27:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105631356473712640",
  "text" : "\u8A33\u30FB\u6687\u3067\u3059",
  "id" : 105631356473712640,
  "created_at" : "2011-08-22 13:24:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105631251863580672",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u5E73\u7A4F\u3059\u304E\u308B\u306A\u3002\u3082\u3063\u3068\u3053\u3046\u30D7\u30E9\u30B9\u306B\u30EF\u30AF\u30EF\u30AF\u3059\u308B\u3053\u3068\u3063\u3066\u306A\u3044\u3060\u308D\u3046\u304B\u3002\u5E73\u7A4F\u306F\u9000\u5C48\u3067\u5E78\u305B\u3060\u3051\u3069\u3055\u3002",
  "id" : 105631251863580672,
  "created_at" : "2011-08-22 13:23:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105630492082188288",
  "geo" : { },
  "id_str" : "105630765542424576",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u8D77\u3053\u3063\u3066\u3082\u72B6\u6CC1\u306F\u826F\u304F\u306A\u3089\u306A\u3044\u3093\u3060\u3088\u3001\u3053\u3053\u308D",
  "id" : 105630765542424576,
  "in_reply_to_status_id" : 105630492082188288,
  "created_at" : "2011-08-22 13:21:51 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105629989583585280",
  "geo" : { },
  "id_str" : "105630303237832704",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u30A8\u30F3\u30C9\u30EC\u30B9\u30A8\u30A4\u30C8\u306B\u306A\u3063\u3066\u3082\u3044\u3044\u3093\u3067\u3059\uFF1F",
  "id" : 105630303237832704,
  "in_reply_to_status_id" : 105629989583585280,
  "created_at" : "2011-08-22 13:20:01 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105630173025681408",
  "text" : "\u4EAC\u5927\u30AF\u30E9\u30B9\u30BF\u3063\u3066\u4E8C\u6B21\u5143\u30A2\u30A4\u30B3\u30F3\u591A\u3044\u3088\u306A\u30FC\u3002\n\u305F\u307E\u305F\u307E\u304B\u306A\u3001\u3046\u3093\u3001\u304D\u3063\u3068\u305D\u3046\u3060\u3002\u305D\u3046\u3044\u3046\u3053\u3068\u306B\u3057\u3066\u304A\u3053\u3046\u3002",
  "id" : 105630173025681408,
  "created_at" : "2011-08-22 13:19:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105629492751503360",
  "geo" : { },
  "id_str" : "105629852673118209",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u30EB\u30FC\u30D7\u3057\u3066\u308B",
  "id" : 105629852673118209,
  "in_reply_to_status_id" : 105629492751503360,
  "created_at" : "2011-08-22 13:18:14 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105629242729041920",
  "geo" : { },
  "id_str" : "105629376166637568",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u60F3\u3044\u8A71\u306B\u306A\u3063\u305F",
  "id" : 105629376166637568,
  "in_reply_to_status_id" : 105629242729041920,
  "created_at" : "2011-08-22 13:16:20 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105612349532151808",
  "geo" : { },
  "id_str" : "105629207232647168",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u79BF\u3052\u3066\u306A\u3044\u3067\u3059\u3057\u30FB\u30FB\u30FB",
  "id" : 105629207232647168,
  "in_reply_to_status_id" : 105612349532151808,
  "created_at" : "2011-08-22 13:15:40 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105628758626676737",
  "text" : "\u5411\u3044\u3066\u306A\u3044\u3063\u3066\u601D\u3046\u3053\u3068\u3063\u3066\u591A\u3005\u3042\u308B\u3051\u3069\u5411\u3044\u3066\u306A\u3044\u306A\u3089\u884C\u5217\u4F7F\u3046\u306A\u308A\u306A\u3093\u306A\u308A\u3057\u3066\u30D9\u30AF\u30C8\u30EB\u5909\u3048\u3066\u3044\u304F\u3057\u304B\u306A\u3044\u306E\u304B\u306A\u3002\u5411\u3044\u3066\u306A\u3044\u3063\u3066\u8A00\u3044\u8A33\u3068\u3057\u3066\u3082\u826F\u3044\u30EF\u30B1\uFF1F",
  "id" : 105628758626676737,
  "created_at" : "2011-08-22 13:13:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105628274817908737",
  "text" : "\u5ACC\u3044\u306A\u3082\u306E\uFF1A\u62D2\u7D76\u3000\u3053\u308C\u306F\u62D2\u7D76\u3092\u62D2\u7D76\u3057\u3066\u3057\u307E\u3063\u3066\u3044\u306A\u3044\u3060\u308D\u3046\u304B\u3002\u62D2\u7D76\u3092\u5ACC\u3046\u306E\u306B\u62D2\u7D76\u3092\u62D2\u7D76\u3057\u3066\u3044\u308B\u306E\u306F\u4E00\u8CAB\u3057\u3066\u306A\u3044\u3088\u3046\u306A\u3002",
  "id" : 105628274817908737,
  "created_at" : "2011-08-22 13:11:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105613297755234304",
  "text" : "\u5F1F\u3068\u30E2\u30F3\u30CF\u3093\u59CB\u307E\u3063\u305F\u2026\u5F7C\u306F\u30ED\u30A2\u30EB\u91D1\u7BA1\u3092\u3060\u3057\u305F\u3044\u3089\u3057\u3044\u3002\u4E71\u6570\u304C\u3042\u308B\u306E\u306F\u9ED9\u3063\u3066\u304A\u3044\u305F\u65B9\u304C\u3044\u3044\u3093\u3060\u308D\u3046\u306A\u3001\u8AAC\u660E\u9762\u5012\u3060\u3057\u3002\u3002",
  "id" : 105613297755234304,
  "created_at" : "2011-08-22 12:12:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105611845511032833",
  "geo" : { },
  "id_str" : "105612295194939392",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u4EEE\u9762\u306F\u52D8\u5F01\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 105612295194939392,
  "in_reply_to_status_id" : 105611845511032833,
  "created_at" : "2011-08-22 12:08:28 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105612145496039424",
  "text" : "\u5B9F\u5BB6\u306B\u3044\u308B\u3068\u98DF\u3079\u904E\u304E\u3066\u3044\u3051\u306A\u3044\u3088\u306A\u30FC\u3002\u305F\u3060\u3067\u3055\u3048\u30CF\u30EF\u30A4\u3067\u98DF\u3079\u904E\u304E\u3066\u308B\u3057\u3001\u4EAC\u90FD\u5E30\u3063\u305F\u3089\u30C0\u30A4\u30A8\u30C3\u30C8\u3059\u308B\u3075\u308A\u3092\u3057\u3088\u3046\u3002\u5207\u5B9F\u3002",
  "id" : 105612145496039424,
  "created_at" : "2011-08-22 12:07:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105611095154233344",
  "geo" : { },
  "id_str" : "105611621631664128",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u3053\u3053\u308D\u3061\u3083\u3093\u4ED5\u4E8B\u3057\u308D\u3088\uFF57",
  "id" : 105611621631664128,
  "in_reply_to_status_id" : 105611095154233344,
  "created_at" : "2011-08-22 12:05:47 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105611403288780800",
  "text" : "\u4ECA\u65E5\u306F\u30C9\u30E9\u30A4\u30D6\u306E\u305F\u3081\u3060\u3051\u306B\u304A\u663C\u3092\u516B\u738B\u5B50\u307E\u3067\u98DF\u3079\u306B\u884C\u3063\u305F\u304D\u308A\u4F55\u306B\u3082\u3057\u3066\u306A\u3044\u30FB\u30FB\u30FB\u3002",
  "id" : 105611403288780800,
  "created_at" : "2011-08-22 12:04:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105610977797603328",
  "text" : "\u6687\u306A\u306E\u3067\u8352\u3076\u3089\u306A\u3044\u30C4\u30A4\u30C3\u30BF-\u30BF\u30A4\u30E0\u306B\u3057\u3088\u3046\u304B\u306A",
  "id" : 105610977797603328,
  "created_at" : "2011-08-22 12:03:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9762\u767D\u6570\u5B66bot",
      "screen_name" : "funmath_bot",
      "indices" : [ 3, 15 ],
      "id_str" : "245786443",
      "id" : 245786443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105610711505444864",
  "text" : "RT @funmath_bot: 184\uFF08\u3044\u3084\u3088\uFF09\u30926\u56DE\u8DB3\u3059\u30681104\uFF08\u3044\u3044\u308F\u3088\uFF09\uFF08\u3044\u3084\u3088\u3044\u3084\u3088\u3082\u597D\u304D\u306E\u5185\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105610350988238848",
    "text" : "184\uFF08\u3044\u3084\u3088\uFF09\u30926\u56DE\u8DB3\u3059\u30681104\uFF08\u3044\u3044\u308F\u3088\uFF09\uFF08\u3044\u3084\u3088\u3044\u3084\u3088\u3082\u597D\u304D\u306E\u5185\uFF09",
    "id" : 105610350988238848,
    "created_at" : "2011-08-22 12:00:44 +0000",
    "user" : {
      "name" : "\u9762\u767D\u6570\u5B66bot",
      "screen_name" : "funmath_bot",
      "protected" : false,
      "id_str" : "245786443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1231702505\/pipie2_normal.jpg",
      "id" : 245786443,
      "verified" : false
    }
  },
  "id" : 105610711505444864,
  "created_at" : "2011-08-22 12:02:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105610186307272704",
  "text" : "RT @kokoro_G4_bot: \uFF08\u300C\u5C0F\u8863\u3061\u3083\u3093\u30DE\u30B8\u5929\u4F7F\u300D\u2026\u2026\u2026\u3053\u3053\u308D\u3061\u3083\u3093\u307E\u3058\u3066\u3093\u3057\u2026\u2026\u2026\u899A\u3048\u307E\u3057\u305F\u3057)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/kokoro_G4_bot\" rel=\"nofollow\"\u003E\u5BFE\u602A\u76D7\u4E8B\u4EF6\u635C\u67FB\u30C1\u30FC\u30E0\uFF27\uFF14\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105602668071895040",
    "text" : "\uFF08\u300C\u5C0F\u8863\u3061\u3083\u3093\u30DE\u30B8\u5929\u4F7F\u300D\u2026\u2026\u2026\u3053\u3053\u308D\u3061\u3083\u3093\u307E\u3058\u3066\u3093\u3057\u2026\u2026\u2026\u899A\u3048\u307E\u3057\u305F\u3057)",
    "id" : 105602668071895040,
    "created_at" : "2011-08-22 11:30:12 +0000",
    "user" : {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "protected" : false,
      "id_str" : "216818830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462028398336811008\/tEl8sKfb_normal.jpeg",
      "id" : 216818830,
      "verified" : false
    }
  },
  "id" : 105610186307272704,
  "created_at" : "2011-08-22 12:00:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30DF\u30A2\u53A8",
      "screen_name" : "I_w_t_b_R",
      "indices" : [ 3, 13 ],
      "id_str" : "126911166",
      "id" : 126911166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105570291413028864",
  "text" : "RT @I_w_t_b_R: \u300C\u7121\u65AD\u30EA\u30E0\u30FC\u30D6\u7981\u6B62\u3067\u3059\uFF01\u300D\u3063\u3066bio\u306B\u66F8\u3044\u3066\u308B\u4EBA\u306B\u300C\u3053\u3093\u306B\u3061\u306F\u30FC\uFF3E\uFF3E\u5148\u65E5\u8AA4\u3063\u3066\u30D5\u30A9\u30ED\u30FC\u3055\u305B\u3066\u9802\u3044\u305F\u306E\u3067\u3059\u304C\u767A\u8A00\u306E\u3042\u307E\u308A\u306E\u3064\u307E\u3089\u306A\u3055\u306B\u866B\u9178\u304C\u8D70\u3063\u3066\u3044\u307E\u3059\uFF08\u309D\u03C9\u30FB\uFF09v\u30DF\u2606\u7533\u3057\u8A33\u306A\u3044\u306E\u3067\u3059\u304C\u30EA\u30E0\u30FC\u30D6\u3057\u3066\u3088\u308D\u3057\u3044\u3067\u3057\u3087\u3046\u304B\uFF1F\uFF08\uFF3E\u25BD\uFF3E\u7B11\uFF09\u300D\u3063\u3066DM\u3057\u305F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17790047276",
    "text" : "\u300C\u7121\u65AD\u30EA\u30E0\u30FC\u30D6\u7981\u6B62\u3067\u3059\uFF01\u300D\u3063\u3066bio\u306B\u66F8\u3044\u3066\u308B\u4EBA\u306B\u300C\u3053\u3093\u306B\u3061\u306F\u30FC\uFF3E\uFF3E\u5148\u65E5\u8AA4\u3063\u3066\u30D5\u30A9\u30ED\u30FC\u3055\u305B\u3066\u9802\u3044\u305F\u306E\u3067\u3059\u304C\u767A\u8A00\u306E\u3042\u307E\u308A\u306E\u3064\u307E\u3089\u306A\u3055\u306B\u866B\u9178\u304C\u8D70\u3063\u3066\u3044\u307E\u3059\uFF08\u309D\u03C9\u30FB\uFF09v\u30DF\u2606\u7533\u3057\u8A33\u306A\u3044\u306E\u3067\u3059\u304C\u30EA\u30E0\u30FC\u30D6\u3057\u3066\u3088\u308D\u3057\u3044\u3067\u3057\u3087\u3046\u304B\uFF1F\uFF08\uFF3E\u25BD\uFF3E\u7B11\uFF09\u300D\u3063\u3066DM\u3057\u305F\u3089\u7121\u65AD\u30D6\u30ED\u30C3\u30AF\u3055\u308C\u305F\u3002",
    "id" : 17790047276,
    "created_at" : "2010-07-05 13:26:51 +0000",
    "user" : {
      "name" : "\u30EB\u30FC\u30DF\u30A2\u53A8",
      "screen_name" : "I_w_t_b_R",
      "protected" : false,
      "id_str" : "126911166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1227146668\/05bf143c-2067-473d-81df-946ebdcd2c75_bigger_normal.png",
      "id" : 126911166,
      "verified" : false
    }
  },
  "id" : 105570291413028864,
  "created_at" : "2011-08-22 09:21:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105250702913314817",
  "text" : "@koketomi \u307E\u3041\u5BFE\u4EBA\u3067\u304D\u308B\u30EC\u30F4\u30A7\u30EB\u306B\u306A\u3063\u305F\u3089\u9069\u5F53\u306B\u904A\u3093\u3067\u3042\u3052\u3066\u4E0B\u3055\u3044\u306A\uFF57",
  "id" : 105250702913314817,
  "created_at" : "2011-08-21 12:11:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 1, 11 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicknamer",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/bIfmDTE",
      "expanded_url" : "http:\/\/qanta.jp\/screenname\/",
      "display_url" : "qanta.jp\/screenname\/"
    } ]
  },
  "geo" : { },
  "id_str" : "105250258048655360",
  "text" : ".@end313124 \u3055\u3093\u306E\u3042\u3060\u540D\u306F\u3001\u3010\u6570\u5B66\u3068\u30E1\u30ED\u30B9\u306E\u5947\u8DE1\u7684\u30B7\u30CA\u30B8\u30FC\u3011\u3068\u3044\u3046\u3053\u3068\u306B\u306A\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/bIfmDTE #nicknamer \u4F55\u3053\u306E\u5B89\u3063\u307D\u3044\u30AD\u30E3\u30C3\u30C1\u30B3\u30D4\u30FC\u307F\u305F\u3044\u306E",
  "id" : 105250258048655360,
  "created_at" : "2011-08-21 12:09:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105247947012308993",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 105247947012308993,
  "created_at" : "2011-08-21 12:00:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6570\u5B66\u3042\u308B\u3042\u308B",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105242166808424448",
  "text" : "\u96FB\u8ECA\u3068\u304B\u98DB\u884C\u6A5F\u3068\u304B\u3067\u6570\u5B66\u3084\u308B\u3068\u7570\u69D8\u306B\u306F\u304B\u3069\u308B\uFF08\u81EA\u5206\u3060\u3051\uFF1F\uFF09 #\u6570\u5B66\u3042\u308B\u3042\u308B",
  "id" : 105242166808424448,
  "created_at" : "2011-08-21 11:37:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105241894577119232",
  "text" : "\u4FDD\u5B58 RT @Mr_Tsubaki \u6B6318\u89D2\u5F62\u306E\u5BFE\u89D2\u7DDA\u306E\u4EA4\u70B9\u306B\u3064\u3044\u3066\u3000http:\/\/j.mp\/odKJkx\u3000\u304D\u308C\u3044\u3060\u306A\u3042",
  "id" : 105241894577119232,
  "created_at" : "2011-08-21 11:36:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105241696970866689",
  "text" : "@koketomi \u3084\u3063\u3066\u307F\u307E\u3059\uFF1E\uFF1C \n\u901F\u5EA6\u65E9\u304F\u306A\u3063\u3066\u304D\u305F\u308A\uFF23\uFF30\uFF35\u6226\u3067\u767A\u706B\u6E90\u6F70\u3055\u308C\u305F\u308A\u3059\u308B\u3068\u307E\u3060\u307E\u3060\u99C4\u76EE\u306D\u30FC",
  "id" : 105241696970866689,
  "created_at" : "2011-08-21 11:35:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105241235912007680",
  "text" : "\u30DF\u30EB\u30AD\u30FC\u4E8C\u671F\u6C7A\u5B9A\u304B\u30FC\u3002\u5909\u306A\u65B9\u5411\u306B\u8D70\u3089\u306A\u304D\u3083\u3044\u3044\u3051\u3069\u3002\u3063\u3066\u4E00\u6C17\u3082\u5341\u5206\u5909\u3060\u3063\u305F\u304B\u3002",
  "id" : 105241235912007680,
  "created_at" : "2011-08-21 11:34:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 3, 12 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105240705378680832",
  "text" : "RT @heyakita: \u3010\u901F\u5831\u3011\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306Fi(\u865A\u6570\u5358\u4F4D)\u3068\u6709\u6A5F\u3060\u3051\u304C\u53CB\u9054\u306E\u8D85\u7D76\u7406\u7CFB\u3068\u3044\u3046\u3053\u3068\u304C\u767A\u899A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52352907995123712",
    "text" : "\u3010\u901F\u5831\u3011\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306Fi(\u865A\u6570\u5358\u4F4D)\u3068\u6709\u6A5F\u3060\u3051\u304C\u53CB\u9054\u306E\u8D85\u7D76\u7406\u7CFB\u3068\u3044\u3046\u3053\u3068\u304C\u767A\u899A",
    "id" : 52352907995123712,
    "created_at" : "2011-03-28 12:54:40 +0000",
    "user" : {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "protected" : false,
      "id_str" : "100242979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567511607844933632\/NCQJgR3j_normal.jpeg",
      "id" : 100242979,
      "verified" : false
    }
  },
  "id" : 105240705378680832,
  "created_at" : "2011-08-21 11:31:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105232958947999744",
  "text" : "\u6298\u308A\u8FD4\u3057\u3060\u3063\u305F",
  "id" : 105232958947999744,
  "created_at" : "2011-08-21 11:01:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105232538108309504",
  "text" : "\u3077\u3088\u3077\u3088\u7DF4\u7FD2\u3057\u59CB\u3081\u305F\u3051\u3069\u610F\u56F3\u7684\u306B5\u9023\u307E\u3067\u3057\u304B\u7D44\u3081\u306A\u3044\u2026\u5207\u308A\u8FD4\u3057\u3063\u3066\u306E\u3092\u7DF4\u7FD2\u3057\u3066\u307F\u3066\u308B\u3051\u30699\u9023\u9396\u304C\u5076\u7136\u51FA\u305F\u304D\u308A\u3002\u3002\u3002\u96E3\u3057\u3044\u3002",
  "id" : 105232538108309504,
  "created_at" : "2011-08-21 10:59:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105230076932669440",
  "text" : "\u3066\u304B\u5F1F\u3068\u6BCD\u89AA\u3068\u4E8C\u4EBA\u304C\u304B\u308A\u3067\u6559\u3048\u3066\u3066\u300C\uFF14\uFF14\u306F\uFF13\uFF12\u306E\u4F55\u30D1\u30FC\u30BB\u30F3\u30C8\u304B\u3063\u3066\u554F\u984C\u304C\u5272\u308A\u5207\u308C\u306A\u3044\u3093\u3060\u3051\u3069\u300D\u3063\u3066\u2026\u3060\u308C\u304B\u6C17\u4ED8\u3051\u3088\u3063\uFF01",
  "id" : 105230076932669440,
  "created_at" : "2011-08-21 10:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105229718009298944",
  "text" : "\u59B9\u304C\u5272\u5408\u306E\u8A08\u7B97\u3067\u3064\u307E\u305A\u3044\u3066\u3044\u308B\u3002\u3042\u306E\u5B50\u5927\u4E08\u592B\u304B\u306A\u2026\u3002",
  "id" : 105229718009298944,
  "created_at" : "2011-08-21 10:48:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105223941534121984",
  "text" : "\u8AB0\u3082\u6C17\u304C\u4ED8\u304B\u306A\u3044\u3060\u308D\u3046\uFF29\uFF24\u306E\u6570\u5B57\u304C\u9593\u9055\u3044\u3063\u3066\u843D\u3061\u3067\u8A3A\u65AD\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u3089\u56E0\u6570\u5206\u89E3bot\u306B\u771F\u76F8\u3092\u66B4\u304B\u308C\u3066\u3066\u7B11\u3063\u305F",
  "id" : 105223941534121984,
  "created_at" : "2011-08-21 10:25:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "101753216",
      "id" : 101753216
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 41, 51 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s_tr",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/HCjJfgC",
      "expanded_url" : "http:\/\/shindanmaker.com\/148668",
      "display_url" : "shindanmaker.com\/148668"
    } ]
  },
  "geo" : { },
  "id_str" : "105223788215549953",
  "text" : "RT @factoring_bot: 313122=2*3*23*2269 RT @end313124: \u3010\u554F\uFF11\u3011\u6B21\u306E\u8A18\u8FF0\u304B\u3089\u9593\u9055\u3044\u3092\uFF11\u3064\u8A02\u6B63\u305B\u3088\u300Cend313122\u306F\u723D\u3084\u304B\u3067\u3042\u307B\u305F\u308C\u3067\u6FC3\u539A\u3067\u7F8E\u5C11\u5973\u3067\u9B3C\u755C\u3067\u3042\u308B\u3002\u300D http:\/\/t.co\/HCjJfgC #s_tr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/prime.4403.biz\/factoring_bot\/\" rel=\"nofollow\"\u003Efactoring_bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 22, 32 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s_tr",
        "indices" : [ 109, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 108 ],
        "url" : "http:\/\/t.co\/HCjJfgC",
        "expanded_url" : "http:\/\/shindanmaker.com\/148668",
        "display_url" : "shindanmaker.com\/148668"
      } ]
    },
    "in_reply_to_status_id_str" : "105216263181180928",
    "geo" : { },
    "id_str" : "105216586578796544",
    "in_reply_to_user_id" : 155546700,
    "text" : "313122=2*3*23*2269 RT @end313124: \u3010\u554F\uFF11\u3011\u6B21\u306E\u8A18\u8FF0\u304B\u3089\u9593\u9055\u3044\u3092\uFF11\u3064\u8A02\u6B63\u305B\u3088\u300Cend313122\u306F\u723D\u3084\u304B\u3067\u3042\u307B\u305F\u308C\u3067\u6FC3\u539A\u3067\u7F8E\u5C11\u5973\u3067\u9B3C\u755C\u3067\u3042\u308B\u3002\u300D http:\/\/t.co\/HCjJfgC #s_tr",
    "id" : 105216586578796544,
    "in_reply_to_status_id" : 105216263181180928,
    "created_at" : "2011-08-21 09:56:03 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "protected" : false,
      "id_str" : "101753216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727655584\/factan_normal.png",
      "id" : 101753216,
      "verified" : false
    }
  },
  "id" : 105223788215549953,
  "created_at" : "2011-08-21 10:24:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s_tr",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/QU9hTSF",
      "expanded_url" : "http:\/\/shindanmaker.com\/148668",
      "display_url" : "shindanmaker.com\/148668"
    } ]
  },
  "geo" : { },
  "id_str" : "105216263181180928",
  "text" : "\u3010\u554F\uFF11\u3011\u6B21\u306E\u8A18\u8FF0\u304B\u3089\u9593\u9055\u3044\u3092\uFF11\u3064\u8A02\u6B63\u305B\u3088\u300Cend313122\u306F\u723D\u3084\u304B\u3067\u3042\u307B\u305F\u308C\u3067\u6FC3\u539A\u3067\u7F8E\u5C11\u5973\u3067\u9B3C\u755C\u3067\u3042\u308B\u3002\u300D http:\/\/t.co\/QU9hTSF #s_tr",
  "id" : 105216263181180928,
  "created_at" : "2011-08-21 09:54:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105215884926255105",
  "text" : "\u68A8\u3046\u307E\u30FC",
  "id" : 105215884926255105,
  "created_at" : "2011-08-21 09:53:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105213463546175488",
  "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u660E\u3089\u304B\u306B\u6E1B\u3063\u3066\u308B\u3057\u3002",
  "id" : 105213463546175488,
  "created_at" : "2011-08-21 09:43:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105213236172959744",
  "text" : "\u3057\u3070\u3089\u304F\u30C4\u30A4\u30FC\u30C8\u3057\u3066\u306A\u3044\u3057\u8272\u3005\u5FD8\u308C\u3089\u308C\u3066\u306A\u3044\u304B\u5FC3\u914D\u3002\u5B9F\u5BB6\u306B\u306F\u4E00\u4EBA\u306E\u7A7A\u9593\u304C\u306A\u3044\u306E\u3067\u3059orz",
  "id" : 105213236172959744,
  "created_at" : "2011-08-21 09:42:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105213042811338752",
  "text" : "\u3044\u3064\u3082\u306A\u304C\u3089\u3057\u3087\u3046\u3082\u306A\u3044\u3002",
  "id" : 105213042811338752,
  "created_at" : "2011-08-21 09:41:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105212779929153536",
  "text" : "\u81EA\u5206\u306B\u306F\u8272\u3005\u304B\u3051\u3066\u3044\u308B\u6C17\u304C\u3059\u308B\u3002\u6B20\u3051\u3066\u3044\u308B\u3057\u8CED\u3051\u3066\u3044\u308B\u3002\u8A00\u8449\u3082\u639B\u3051\u3066\u3044\u308B\u3002\u66F8\u3051\u3066\u3044\u308B\u3002",
  "id" : 105212779929153536,
  "created_at" : "2011-08-21 09:40:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105212421236461568",
  "text" : "\u4F55\u3067\u3053\u3093\u306A\u304A\u91D1\u304C\u5FC5\u8981\u306A\u3093\u3060\u308D\u3046\u306D\u30FB\u30FB\u30FB\u3002",
  "id" : 105212421236461568,
  "created_at" : "2011-08-21 09:39:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u306E\u57A2\u306F\u6D88\u3057\u307E\u3059",
      "screen_name" : "hakusetsu_",
      "indices" : [ 3, 14 ],
      "id_str" : "151466323",
      "id" : 151466323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http:\/\/t.co\/Qxgpjue",
      "expanded_url" : "http:\/\/twitpic.com\/6886fs",
      "display_url" : "twitpic.com\/6886fs"
    } ]
  },
  "geo" : { },
  "id_str" : "105207577725513729",
  "text" : "RT @hakusetsu_: \u672C\u5F53\u306B\u3053\u308C\u304C\u5375\u713C\u304D\u306B\u898B\u3048\u306A\u3044\u5974\u306F\u516C\u5F0FRT\u3057\u306A\uFF013000RT\u3050\u3089\u3044\u8D85\u3048\u305F\u3089\u79C1\u306F\u300C\u3053\u308C\u306F\u5375\u713C\u304D\u3058\u3083\u306A\u304B\u3063\u305F\u3067\u3059\u3002\u3059\u307F\u307E\u305B\u3093\u3002\u300D\u3068\u8A00\u3063\u3066\u3084\u308B\u3088\uFF01 http:\/\/t.co\/Qxgpjue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 89 ],
        "url" : "http:\/\/t.co\/Qxgpjue",
        "expanded_url" : "http:\/\/twitpic.com\/6886fs",
        "display_url" : "twitpic.com\/6886fs"
      } ]
    },
    "geo" : { },
    "id_str" : "104385458213109760",
    "text" : "\u672C\u5F53\u306B\u3053\u308C\u304C\u5375\u713C\u304D\u306B\u898B\u3048\u306A\u3044\u5974\u306F\u516C\u5F0FRT\u3057\u306A\uFF013000RT\u3050\u3089\u3044\u8D85\u3048\u305F\u3089\u79C1\u306F\u300C\u3053\u308C\u306F\u5375\u713C\u304D\u3058\u3083\u306A\u304B\u3063\u305F\u3067\u3059\u3002\u3059\u307F\u307E\u305B\u3093\u3002\u300D\u3068\u8A00\u3063\u3066\u3084\u308B\u3088\uFF01 http:\/\/t.co\/Qxgpjue",
    "id" : 104385458213109760,
    "created_at" : "2011-08-19 02:53:27 +0000",
    "user" : {
      "name" : "\u3053\u306E\u57A2\u306F\u6D88\u3057\u307E\u3059",
      "screen_name" : "hakusetsu_",
      "protected" : false,
      "id_str" : "151466323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1652061049\/344463709___bigger_normal.jpg",
      "id" : 151466323,
      "verified" : false
    }
  },
  "id" : 105207577725513729,
  "created_at" : "2011-08-21 09:20:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6298\u539F\u81E8\u4E5F",
      "screen_name" : "izaya_oriharra",
      "indices" : [ 3, 18 ],
      "id_str" : "259619469",
      "id" : 259619469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105196164437118977",
  "text" : "RT @izaya_oriharra: \u305F\u3063\u305F\u4ECA\u65B0\u805E\u306E\u30C6\u30EC\u30D3\u6B04\u898B\u305F\u3089\uFF12\uFF14\u6642\u9593\uFF34\uFF36\u304C\u611B\u3067\u5730\u7403\u3092\u6551\u304A\u3046\u3068\u3057\u3066\u3044\u308B\u305D\u306E\u96A3\u306B\u3042\u3063\u305F\u30D7\u30EA\u30AD\u30E5\u30A2\u304C\u300C\uFF13\uFF10\u5206\u3067\u4E16\u754C\u3092\u6551\u3046\uFF01\u300D\u3063\u3066\u66F8\u304B\u308C\u3066\u3044\u3066\u3044\u3084\u307B\u3093\u3068\u3001\u30D7\u30EA\u30AD\u30E5\u30A2\u30DE\u30B8\u3059\u3052\u3047\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105183280063725568",
    "text" : "\u305F\u3063\u305F\u4ECA\u65B0\u805E\u306E\u30C6\u30EC\u30D3\u6B04\u898B\u305F\u3089\uFF12\uFF14\u6642\u9593\uFF34\uFF36\u304C\u611B\u3067\u5730\u7403\u3092\u6551\u304A\u3046\u3068\u3057\u3066\u3044\u308B\u305D\u306E\u96A3\u306B\u3042\u3063\u305F\u30D7\u30EA\u30AD\u30E5\u30A2\u304C\u300C\uFF13\uFF10\u5206\u3067\u4E16\u754C\u3092\u6551\u3046\uFF01\u300D\u3063\u3066\u66F8\u304B\u308C\u3066\u3044\u3066\u3044\u3084\u307B\u3093\u3068\u3001\u30D7\u30EA\u30AD\u30E5\u30A2\u30DE\u30B8\u3059\u3052\u3047\u3002",
    "id" : 105183280063725568,
    "created_at" : "2011-08-21 07:43:42 +0000",
    "user" : {
      "name" : "\u6298\u539F\u81E8\u4E5F",
      "screen_name" : "izaya_oriharra",
      "protected" : false,
      "id_str" : "259619469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589066291425648640\/7rkAqTuS_normal.jpg",
      "id" : 259619469,
      "verified" : false
    }
  },
  "id" : 105196164437118977,
  "created_at" : "2011-08-21 08:34:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thsort",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/sD5weM2",
      "expanded_url" : "http:\/\/goo.gl\/rGJJ",
      "display_url" : "goo.gl\/rGJJ"
    } ]
  },
  "geo" : { },
  "id_str" : "105194588897148931",
  "text" : "\u6771\u65B9\u30AD\u30E3\u30E9\u30BD\u30FC\u30C8\u7D50\u679C\uFF01\u2026\u30001\u4F4D\uFF1A \u30D1\u30C1\u30E5\u30EA\u30FC\u30002\u4F4D\uFF1A \u6D29\u77E2\u8ACF\u8A2A\u5B50\u30003\u4F4D\uFF1A \u5C0F\u60AA\u9B54\u30004\u4F4D\uFF1A \u516B\u96F2\u7D2B\u30005\u4F4D\uFF1A \u4F0A\u5439\u8403\u9999\u30006\u4F4D\uFF1A \u535A\u9E97\u970A\u5922\u30007\u4F4D\uFF1A \u6C38\u6C5F\u8863\u7396\u30008\u4F4D\uFF1A \u6BD4\u90A3\u540D\u5C45\u5929\u5B50\u30009\u4F4D\uFF1A \u9375\u5C71\u96DB\u300010\u4F4D\uFF1A \u4E0A\u6D77\u4EBA\u5F62\u3000\u3000#thsort\u3000http:\/\/t.co\/sD5weM2 \u4E0A\u6D77\u2026",
  "id" : 105194588897148931,
  "created_at" : "2011-08-21 08:28:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105172261836824576",
  "geo" : { },
  "id_str" : "105191728037888000",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6687\u3067\u3059\u2026",
  "id" : 105191728037888000,
  "in_reply_to_status_id" : 105172261836824576,
  "created_at" : "2011-08-21 08:17:16 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 10, 20 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 21, 32 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105125477672427520",
  "geo" : { },
  "id_str" : "105163378837819392",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 @blackpiyu @akiyohmori \u3042\u305D\u3053\u306E\u30D1\u30F3\u306F\u7F8E\u5473\u3057\u3044\u3088\u306D\u3047 \u5E83\u5CF6\u307E\u3067\u53D6\u308A\u306B\u884C\u3053\u3046\u304B\u306A\u2190",
  "id" : 105163378837819392,
  "in_reply_to_status_id" : 105125477672427520,
  "created_at" : "2011-08-21 06:24:38 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104885577559707649",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 104885577559707649,
  "created_at" : "2011-08-20 12:00:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104735589517115392",
  "text" : "\u65E9\u304F\u7740\u3044\u305F\u306E\u306F\u81EA\u5206\u304C\u60AA\u3044\u304C\u3053\u308C\u306F\u3072\u3069\u3044",
  "id" : 104735589517115392,
  "created_at" : "2011-08-20 02:04:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104735439839178752",
  "text" : "\u53CB\uFF21\uFF1A\u3059\u307E\u309310\u300120\u5206\u9045\u308C\u308B\u2192\u3084\u3063\u3071\uFF13\uFF10\u5206\u9045\u308C\u308B \u53CB\uFF22\uFF1A\uFF11\uFF15\u5206\u9045\u308C\u308B\u2192\uFF13\uFF10\u5206\u9045\u308C\u308B \u53CB\uFF23\uFF1A\u3059\u307E\u306C\u304C\uFF15\u5206\u9045\u308C\u308B \u4FFA\uFF1A\uFF14\uFF10\u5206\u524D\u306B\u3064\u3044\u305F\u3063\u305F\uFF57\uFF57\uFF57\uFF57",
  "id" : 104735439839178752,
  "created_at" : "2011-08-20 02:04:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/PQsZgWo",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104701172153204736",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/PQsZgWo",
  "id" : 104701172153204736,
  "created_at" : "2011-08-19 23:47:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104426926562738176",
  "text" : "\u5730\u9707\u306A\u3046",
  "id" : 104426926562738176,
  "created_at" : "2011-08-19 05:38:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30BF\u30A4\u30C8\u30EB\u3092100\u500D\u306B\u3059\u308B\u3068\u76DB\u308A\u4E0A\u304C\u308B",
      "indices" : [ 21, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104423111444795392",
  "text" : "\u30BF\u30A4\u30C8\u30EB\u309210000\u500D\u306B\u3059\u308B\u3068\u76DB\u308A\u4E0A\u304C\u308B #\u30BF\u30A4\u30C8\u30EB\u3092100\u500D\u306B\u3059\u308B\u3068\u76DB\u308A\u4E0A\u304C\u308B",
  "id" : 104423111444795392,
  "created_at" : "2011-08-19 05:23:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104422093600460800",
  "geo" : { },
  "id_str" : "104422587907571712",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CA\u30A4\u30B9\u30C0\u30C3\u30C4!",
  "id" : 104422587907571712,
  "in_reply_to_status_id" : 104422093600460800,
  "created_at" : "2011-08-19 05:20:59 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104420879357837312",
  "geo" : { },
  "id_str" : "104421986649907200",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u8A2A\u554F\u4E59",
  "id" : 104421986649907200,
  "in_reply_to_status_id" : 104420879357837312,
  "created_at" : "2011-08-19 05:18:36 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104160794471702528",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 104160794471702528,
  "created_at" : "2011-08-18 12:00:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104034390551707648",
  "text" : "\u5E30\u56FD\uFF67\uFF01",
  "id" : 104034390551707648,
  "created_at" : "2011-08-18 03:38:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/PQsZgWo",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103602278199590912",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/PQsZgWo",
  "id" : 103602278199590912,
  "created_at" : "2011-08-16 23:01:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103436045831516162",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 103436045831516162,
  "created_at" : "2011-08-16 12:00:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103041845155733504",
  "text" : "@ayu167 \u304A\uFF4B",
  "id" : 103041845155733504,
  "created_at" : "2011-08-15 09:54:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103040838745063424",
  "text" : "@ayu167 \uFF12\uFF10\u304B\uFF12\uFF11\u3063\u3066\u7A7A\u3051\u3089\u308C\u308B\uFF1F",
  "id" : 103040838745063424,
  "created_at" : "2011-08-15 09:50:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103040205321285632",
  "text" : "@ayu167 \u5408\u5BBF\u3044\u3064\u307E\u3067\uFF1F",
  "id" : 103040205321285632,
  "created_at" : "2011-08-15 09:47:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103013797282852864",
  "geo" : { },
  "id_str" : "103014506283794432",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa 18\u65E5\u306E\u591C\u6771\u4EAC\u306B\u5E30\u308B\u3093\u3060\u3051\u3069\u300124\u3042\u305F\u308A\u306B\u4EAC\u90FD\u306B\u5E30\u308B\u3002\u4F1A\u3048\u308B\u3088\u3046\u306A\u3089\u304A\u571F\u7523\u8CB7\u3063\u3066\u3044\u304F\u3051\u3069\u3002\u3002\u3002",
  "id" : 103014506283794432,
  "in_reply_to_status_id" : 103013797282852864,
  "created_at" : "2011-08-15 08:05:46 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103012195754983424",
  "geo" : { },
  "id_str" : "103013361494654976",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u308B\u3044\u306F\u3002\u3066\u304B\u3044\u3064\u307E\u3067\u6771\u4EAC\u306B\u3044\u308B\uFF1F",
  "id" : 103013361494654976,
  "in_reply_to_status_id" : 103012195754983424,
  "created_at" : "2011-08-15 08:01:13 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103010646974660608",
  "text" : "\u6BCE\u98DF\u98DF\u3079\u904E\u304E\u3066\u3044\u308B\u30FB\u30FB\u30FB\u3002\u305D\u3057\u3066\u30D4\u30CB\u30E3\u30B3\u30E9\u30FC\u30C0\u98F2\u307F\u306B\u6765\u305F\u3088\u3046\u306A\u3082\u3093\u306A\u306E\u306B\u3001\u30A2\u30EB\u30B3\u30FC\u30EB21\u304B\u3089\u3068\u304B\u2026\u3002\u5C31\u8077\u6C7A\u307E\u3063\u305F\u3089\u307E\u305F\u6765\u3088\u3046\u3002",
  "id" : 103010646974660608,
  "created_at" : "2011-08-15 07:50:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F53\u91CD86kg 2015",
      "screen_name" : "tomossan",
      "indices" : [ 3, 12 ],
      "id_str" : "58358353",
      "id" : 58358353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103010137186385920",
  "text" : "RT @tomossan: \u307F\u3046\u3057\u3093\u3001\u5F7C\u5973\u3092\u6A2A\u624B\u306BPC\u304B\u3089Twitter\u306B\u66F8\u304D\u8FBC\u3080\u3001\u300C\u30DE\u30B8\u3064\u308C\u30FC\u3088\u3001\u3053\u306E\u4EBA\u751F\u3001\u4FFA\u3060\u3063\u3066\u7570\u6027\u3068\u8A71\u3057\u3066\u30FC\u3088\u300D\u3001\u9762\u767D\u3044\u3088\u306A\u3053\u3044\u3064\u3089\u306E\u53CD\u5FDC\u307F\u3066\u308B\u3068\u3088\u3001\u307F\u3046\u3057\u3093\u306F\u305D\u3057\u3066\u5F7C\u5973\u3068\u3044\u3061\u3083\u3044\u3061\u3083\u3092\u307E\u305F\u958B\u59CB\u3057\u305F\u306E\u3060\u3063\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103009780108500992",
    "text" : "\u307F\u3046\u3057\u3093\u3001\u5F7C\u5973\u3092\u6A2A\u624B\u306BPC\u304B\u3089Twitter\u306B\u66F8\u304D\u8FBC\u3080\u3001\u300C\u30DE\u30B8\u3064\u308C\u30FC\u3088\u3001\u3053\u306E\u4EBA\u751F\u3001\u4FFA\u3060\u3063\u3066\u7570\u6027\u3068\u8A71\u3057\u3066\u30FC\u3088\u300D\u3001\u9762\u767D\u3044\u3088\u306A\u3053\u3044\u3064\u3089\u306E\u53CD\u5FDC\u307F\u3066\u308B\u3068\u3088\u3001\u307F\u3046\u3057\u3093\u306F\u305D\u3057\u3066\u5F7C\u5973\u3068\u3044\u3061\u3083\u3044\u3061\u3083\u3092\u307E\u305F\u958B\u59CB\u3057\u305F\u306E\u3060\u3063\u305F\u3002",
    "id" : 103009780108500992,
    "created_at" : "2011-08-15 07:47:00 +0000",
    "user" : {
      "name" : "\u4F53\u91CD86kg 2015",
      "screen_name" : "tomossan",
      "protected" : false,
      "id_str" : "58358353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512908128766001152\/1efrPkqy_normal.jpeg",
      "id" : 58358353,
      "verified" : false
    }
  },
  "id" : 103010137186385920,
  "created_at" : "2011-08-15 07:48:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6212",
      "screen_name" : "kai_niconico",
      "indices" : [ 3, 16 ],
      "id_str" : "257296656",
      "id" : 257296656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kai_niconico\/status\/101220677184524288\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GVtJRIs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AWebq2vCEAAUb3Y.jpg",
      "id_str" : "101220677188718592",
      "id" : 101220677188718592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AWebq2vCEAAUb3Y.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/GVtJRIs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103009992583548928",
  "text" : "RT @kai_niconico: \u540C\u68F2\u3057\u3066\u308B\u5973\u304C\u6D6E\u6C17\u30C1\u30A7\u30C3\u30AF\u3067\u4FFA\u306E\u643A\u5E2F\u3092\u52DD\u624B\u306B\u3044\u3058\u3063\u3066\u305F\u2026\u5ACC\u306A\u4E88\u611F\u304C\u3057\u3066\u30B7\u30E3\u30EF\u30FC\u65E9\u3081\u306B\u5207\u308A\u4E0A\u3052\u3066\u6B63\u89E3\u3060\u3063\u305F\u3088\u3002\u73FE\u884C\u72AF\u306E\u8A3C\u62E0\u5199\u771F\u304C\u64AE\u308C\u305F\u304B\u3089\u516C\u5F0FRT\u4F7F\u3063\u3066twitter\u4E0A\u3067\u6652\u3057\u8005\u306B\u3057\u3066\u3084\u308A\u305F\u3044\u3002\u5354\u529B\u304A\u9858\u3044\u3057\u307E\u3059\uFF01\uFF01 http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kai_niconico\/status\/101220677184524288\/photo\/1",
        "indices" : [ 106, 125 ],
        "url" : "http:\/\/t.co\/GVtJRIs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AWebq2vCEAAUb3Y.jpg",
        "id_str" : "101220677188718592",
        "id" : 101220677188718592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AWebq2vCEAAUb3Y.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/GVtJRIs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101220677184524288",
    "text" : "\u540C\u68F2\u3057\u3066\u308B\u5973\u304C\u6D6E\u6C17\u30C1\u30A7\u30C3\u30AF\u3067\u4FFA\u306E\u643A\u5E2F\u3092\u52DD\u624B\u306B\u3044\u3058\u3063\u3066\u305F\u2026\u5ACC\u306A\u4E88\u611F\u304C\u3057\u3066\u30B7\u30E3\u30EF\u30FC\u65E9\u3081\u306B\u5207\u308A\u4E0A\u3052\u3066\u6B63\u89E3\u3060\u3063\u305F\u3088\u3002\u73FE\u884C\u72AF\u306E\u8A3C\u62E0\u5199\u771F\u304C\u64AE\u308C\u305F\u304B\u3089\u516C\u5F0FRT\u4F7F\u3063\u3066twitter\u4E0A\u3067\u6652\u3057\u8005\u306B\u3057\u3066\u3084\u308A\u305F\u3044\u3002\u5354\u529B\u304A\u9858\u3044\u3057\u307E\u3059\uFF01\uFF01 http:\/\/t.co\/GVtJRIs",
    "id" : 101220677184524288,
    "created_at" : "2011-08-10 09:17:45 +0000",
    "user" : {
      "name" : "\u6212",
      "screen_name" : "kai_niconico",
      "protected" : false,
      "id_str" : "257296656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1563486732\/twitter_icon_normal.gif",
      "id" : 257296656,
      "verified" : false
    }
  },
  "id" : 103009992583548928,
  "created_at" : "2011-08-15 07:47:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103009916813455360",
  "text" : "\u6050\u308D\u3057\u304F\u4E45\u3005\u306BTL\u3092\u773A\u3081\u305F\u3002",
  "id" : 103009916813455360,
  "created_at" : "2011-08-15 07:47:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102711200525197312",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 102711200525197312,
  "created_at" : "2011-08-14 12:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/PQsZgWo",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102476844137332736",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/PQsZgWo",
  "id" : 102476844137332736,
  "created_at" : "2011-08-13 20:29:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102348851582730241",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 102348851582730241,
  "created_at" : "2011-08-13 12:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101741920191135745",
  "text" : "\u30CF\u30EF\u30A4\u306A\u3046\u3002\u65E5\u672C\u3088\u304B\u6DBC\u3057\u3044\u3063\uFF01",
  "id" : 101741920191135745,
  "created_at" : "2011-08-11 19:48:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101624066187870209",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 101624066187870209,
  "created_at" : "2011-08-11 12:00:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101612874467786752",
  "text" : "\u98DB\u884C\u6A5F\u306A\u3046 \u96E2\u8131\uFF67\uFF01",
  "id" : 101612874467786752,
  "created_at" : "2011-08-11 11:16:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101566322344861696",
  "text" : "\u6210\u7530\u306A\u3046\u3063",
  "id" : 101566322344861696,
  "created_at" : "2011-08-11 08:11:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101476367505428481",
  "text" : "RT @Kaibun_bot: \u9C39\u7BC0\u306E\u79C1\u7269\u5316 \u3000\uFF08\u304B\u3064\u3076\u3057\u306E\u3057\u3076\u3064\u304B\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 20, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101473465613287425",
    "text" : "\u9C39\u7BC0\u306E\u79C1\u7269\u5316 \u3000\uFF08\u304B\u3064\u3076\u3057\u306E\u3057\u3076\u3064\u304B\uFF09 #kaibun",
    "id" : 101473465613287425,
    "created_at" : "2011-08-11 02:02:14 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 101476367505428481,
  "created_at" : "2011-08-11 02:13:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101329413190328322",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
  "id" : 101329413190328322,
  "created_at" : "2011-08-10 16:29:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 3, 15 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101304106181869568",
  "text" : "RT @momo_miku28: \u4ED8\u304D\u5408\u3048\u308B\u4EBA\u3092\u63A2\u3059\u3088\u308A\u597D\u304D\u306B\u306A\u308C\u308B\u4EBA\u3092\u63A2\u3059\u307B\u3046\u304C\u3046\u30FC\u3093\u3068\u96E3\u3057\u3044\u306E\u3067\u3057\u3087\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101302314547154944",
    "text" : "\u4ED8\u304D\u5408\u3048\u308B\u4EBA\u3092\u63A2\u3059\u3088\u308A\u597D\u304D\u306B\u306A\u308C\u308B\u4EBA\u3092\u63A2\u3059\u307B\u3046\u304C\u3046\u30FC\u3093\u3068\u96E3\u3057\u3044\u306E\u3067\u3057\u3087\u3046",
    "id" : 101302314547154944,
    "created_at" : "2011-08-10 14:42:08 +0000",
    "user" : {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "protected" : true,
      "id_str" : "131856285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533040424097566720\/1Wjv-ZI7_normal.jpeg",
      "id" : 131856285,
      "verified" : false
    }
  },
  "id" : 101304106181869568,
  "created_at" : "2011-08-10 14:49:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101297745196875776",
  "geo" : { },
  "id_str" : "101303972727504898",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u5409\u7965\u5BFA\u304B\u3089\u6B69\u3044\u3066\u5E30\u3063\u305F\u304C\u898B\u304B\u3051\u3093\u304B\u3063\u305F\u306A\u3041",
  "id" : 101303972727504898,
  "in_reply_to_status_id" : 101297745196875776,
  "created_at" : "2011-08-10 14:48:43 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3089\u308A\u3093",
      "screen_name" : "1219hr",
      "indices" : [ 3, 10 ],
      "id_str" : "230451926",
      "id" : 230451926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101303547911602176",
  "text" : "RT @1219hr: \u300C\u304A\u6BCD\u3055\u3093\u3001\u8D64\u3061\u3083\u3093\u306F\u3069\u3053\u304B\u3089\u6765\u308B\u306E\uFF1F\u300D\r\u300E\u30B3\u30A6\u30CE\u30C8\u30EA\u3055\u3093\u304C\u904B\u3093\u3067\u304D\u3066\u304F\u308C\u308B\u306E\u3088\u300F\r\u300C\u3059\u3054\u30FC\u3044\uFF01\u30B3\u30A6\u30CE\u30C8\u30EA\u306F\u7D76\u6EC5\u5BF8\u524D\u3067\u7DCF\u6570\u7D042,000\uFF5E3,000\u7FBD\u306A\u306E\u306B\u30011\u65E5\u306B\u7D04200,000\u4EBA\u7523\u307E\u308C\u308B\u8D64\u3061\u3083\u3093\u3092\u307F\u3093\u306A\u904B\u3093\u3067\u308B\u3093\u3060\uFF011\u7FBD\u5F53\u305F\u308A1\u65E5\u7D0466\uFF5E100\u4EBA ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101284125310337024",
    "text" : "\u300C\u304A\u6BCD\u3055\u3093\u3001\u8D64\u3061\u3083\u3093\u306F\u3069\u3053\u304B\u3089\u6765\u308B\u306E\uFF1F\u300D\r\u300E\u30B3\u30A6\u30CE\u30C8\u30EA\u3055\u3093\u304C\u904B\u3093\u3067\u304D\u3066\u304F\u308C\u308B\u306E\u3088\u300F\r\u300C\u3059\u3054\u30FC\u3044\uFF01\u30B3\u30A6\u30CE\u30C8\u30EA\u306F\u7D76\u6EC5\u5BF8\u524D\u3067\u7DCF\u6570\u7D042,000\uFF5E3,000\u7FBD\u306A\u306E\u306B\u30011\u65E5\u306B\u7D04200,000\u4EBA\u7523\u307E\u308C\u308B\u8D64\u3061\u3083\u3093\u3092\u307F\u3093\u306A\u904B\u3093\u3067\u308B\u3093\u3060\uFF011\u7FBD\u5F53\u305F\u308A1\u65E5\u7D0466\uFF5E100\u4EBA\u306E\u30CE\u30EB\u30DE\u3060\u3088\uFF01\u300D\r\u300E\u3046\u3001\u3046\u3093\u2026\u300F",
    "id" : 101284125310337024,
    "created_at" : "2011-08-10 13:29:51 +0000",
    "user" : {
      "name" : "\u3072\u3089\u308A\u3093",
      "screen_name" : "1219hr",
      "protected" : false,
      "id_str" : "230451926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3338177657\/86bbec123485771bf7849bc3698752cb_normal.png",
      "id" : 230451926,
      "verified" : false
    }
  },
  "id" : 101303547911602176,
  "created_at" : "2011-08-10 14:47:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101286620350779392",
  "geo" : { },
  "id_str" : "101287040540352512",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u30CA\u30EB\u30B3\u30EC\u30D7\u30B7\u30FC",
  "id" : 101287040540352512,
  "in_reply_to_status_id" : 101286620350779392,
  "created_at" : "2011-08-10 13:41:26 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101286441228828672",
  "text" : "@np2i \u3044\u3084\u30FC\u5730\u5143\u306F\u6771\u4EAC\u306A\u306E\u3067\u3059\u3002\u95A2\u897F\u3067\u306F\u898B\u306A\u3044\u306A\u30FC\u3002",
  "id" : 101286441228828672,
  "created_at" : "2011-08-10 13:39:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 12, 19 ],
      "id_str" : "129796835",
      "id" : 129796835
    }, {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 44, 49 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 66, 77 ],
      "id_str" : "95958826",
      "id" : 95958826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6570\u5B66\u5927\u559C\u52293",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101286183308492800",
  "text" : "\u8907\u96D1\u306A\u30CD\u30BF\u3060\u306A\u3041 RT @7M1IHN: \u306A\u308B\u307B\u3069\u3001\u5B9F\u6570\u3092\u8907\u7D20\u6570\u306B\u62E1\u5F35\u3057\u305F\u306E\u306D\u3002 RT @np2i: \u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9\u9B3C\u3054\u3063\u3053 RT @SugaTheKid: \u3010\u6570\u5B66\u5927\u559C\u52293\u3011\u6620\u753B\u306E\u30BF\u30A4\u30C8\u30EB\u306E\u4E00\u90E8\u3092\u6570\u5B66\u7528\u8A9E\u306B\u3057\u3066\u4E00\u756A\u304A\u3082\u3057\u308D\u305D\u3046\u306A\u3082\u306E\u3092\u4F5C\u3063\u305F\u5974\u304C\u512A\u52DD #\u6570\u5B66\u5927\u559C\u52293",
  "id" : 101286183308492800,
  "created_at" : "2011-08-10 13:38:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101281549667930112",
  "geo" : { },
  "id_str" : "101285887039647744",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u30C4\u30A4\u30FC\u30C8\u3059\u308B\u305F\u3073\u77E5\u8B58\u304C\u5897\u3048\u308B\u306D\uFF01\u8A73\u7D30\u30B5\u30F3\u30AD\u30E5",
  "id" : 101285887039647744,
  "in_reply_to_status_id" : 101281549667930112,
  "created_at" : "2011-08-10 13:36:51 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101285622156754944",
  "text" : "\u5730\u5143\u3067\u30C8\u30AF\u30DA\u306E\u7F36\u3092\u767A\u898B\u3057\u3066\u885D\u52D5\u8CB7\u3044",
  "id" : 101285622156754944,
  "created_at" : "2011-08-10 13:35:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 3, 13 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u677E\u672C\u7DCF\u9577\u306E\u8B1B\u6F14\u5B9F\u6CC1",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101094266423615488",
  "text" : "RT @eclair_15: \u8CDE\u306F\u30CE\u30FC\u30D9\u30EB\u8CDE\u3060\u3051\uFF01\u3058\u3083\u306A\u3044\uFF01\uFF01 #\u677E\u672C\u7DCF\u9577\u306E\u8B1B\u6F14\u5B9F\u6CC1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u677E\u672C\u7DCF\u9577\u306E\u8B1B\u6F14\u5B9F\u6CC1",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101092355851034625",
    "text" : "\u8CDE\u306F\u30CE\u30FC\u30D9\u30EB\u8CDE\u3060\u3051\uFF01\u3058\u3083\u306A\u3044\uFF01\uFF01 #\u677E\u672C\u7DCF\u9577\u306E\u8B1B\u6F14\u5B9F\u6CC1",
    "id" : 101092355851034625,
    "created_at" : "2011-08-10 00:47:50 +0000",
    "user" : {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "protected" : false,
      "id_str" : "158645894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604517314164162560\/4WMjGFnD_normal.png",
      "id" : 158645894,
      "verified" : false
    }
  },
  "id" : 101094266423615488,
  "created_at" : "2011-08-10 00:55:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u751F\u304D\u7269\uFF20\u304A\u3080\u30D5\u30A7\u30B92\u30B2\u30B9\u30C8",
      "screen_name" : "oneb",
      "indices" : [ 3, 8 ],
      "id_str" : "14970169",
      "id" : 14970169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100922933739929600",
  "text" : "RT @oneb: \u30D4\u30AB\u30C1\u30E5\u30A6\u300C\u30B5\u30C8\u30B7\u300110\u4E07\u30DC\u30EB\u30C8\u3060\uFF01\u300D\u30B5\u30C8\u30B7\u300C\u3042\u304B\u3093\u300D\u30D4\u30AB\u30C1\u30E5\u30A6\u300C\uFF01\uFF1F\u300D\u30B5\u30C8\u30B7\u300C\u30A4\u30EF\u30FC\u30AF\u306E\u4E3B\u6210\u5206\u306F\u96F2\u6BCD\u3001\u7D76\u7E01\u4F53\u3084\u3002\u96FB\u6C17\u62B5\u6297\u306F10^16\u306B\u3082\u306A\u308B\u300210\u4E07\u3058\u3083\u8DB3\u308A\u3072\u3093\u3002\u305D\u308C\u306B\u4ECA\u306F\u2026\u300D\u30D4\u30AB\u30C1\u30E5\u30A6\u300C\u4ECA\u306F\uFF1F\u300D\u30B5\u30C8\u30B7\u300C\u7BC0\u96FB\u2026\u3084\u308D\uFF1F\u300D\u30B5\u30C8\u30B7\u300C\u2026\u30D5\u30C3\u3001\u305B\u3084\u306A\u300D\u30AC\u30B7\u30C3( ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100867119310323712",
    "text" : "\u30D4\u30AB\u30C1\u30E5\u30A6\u300C\u30B5\u30C8\u30B7\u300110\u4E07\u30DC\u30EB\u30C8\u3060\uFF01\u300D\u30B5\u30C8\u30B7\u300C\u3042\u304B\u3093\u300D\u30D4\u30AB\u30C1\u30E5\u30A6\u300C\uFF01\uFF1F\u300D\u30B5\u30C8\u30B7\u300C\u30A4\u30EF\u30FC\u30AF\u306E\u4E3B\u6210\u5206\u306F\u96F2\u6BCD\u3001\u7D76\u7E01\u4F53\u3084\u3002\u96FB\u6C17\u62B5\u6297\u306F10^16\u306B\u3082\u306A\u308B\u300210\u4E07\u3058\u3083\u8DB3\u308A\u3072\u3093\u3002\u305D\u308C\u306B\u4ECA\u306F\u2026\u300D\u30D4\u30AB\u30C1\u30E5\u30A6\u300C\u4ECA\u306F\uFF1F\u300D\u30B5\u30C8\u30B7\u300C\u7BC0\u96FB\u2026\u3084\u308D\uFF1F\u300D\u30B5\u30C8\u30B7\u300C\u2026\u30D5\u30C3\u3001\u305B\u3084\u306A\u300D\u30AC\u30B7\u30C3(\u56FA\u3044\u63E1\u624B) \uFF3C\u30A8\u30FC\u30B7\u30FC\uFF0F",
    "id" : 100867119310323712,
    "created_at" : "2011-08-09 09:52:49 +0000",
    "user" : {
      "name" : "\u751F\u304D\u7269\uFF20\u304A\u3080\u30D5\u30A7\u30B92\u30B2\u30B9\u30C8",
      "screen_name" : "oneb",
      "protected" : false,
      "id_str" : "14970169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588102205061890048\/dXFyg3OP_normal.jpg",
      "id" : 14970169,
      "verified" : false
    }
  },
  "id" : 100922933739929600,
  "created_at" : "2011-08-09 13:34:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3087\u304D\u3087\u4E38",
      "screen_name" : "kyokyomaru",
      "indices" : [ 3, 14 ],
      "id_str" : "151819733",
      "id" : 151819733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4ECA\u306E\u5C0F\u5B66\u751F\u306F\u77E5\u3089\u306A\u3044",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100911761112305664",
  "text" : "RT @kyokyomaru: \u3042\u306E\u65E5\u898B\u305F\u82B1\u306E\u540D\u524D\u3092 #\u4ECA\u306E\u5C0F\u5B66\u751F\u306F\u77E5\u3089\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u4ECA\u306E\u5C0F\u5B66\u751F\u306F\u77E5\u3089\u306A\u3044",
        "indices" : [ 11, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100595895304859648",
    "text" : "\u3042\u306E\u65E5\u898B\u305F\u82B1\u306E\u540D\u524D\u3092 #\u4ECA\u306E\u5C0F\u5B66\u751F\u306F\u77E5\u3089\u306A\u3044",
    "id" : 100595895304859648,
    "created_at" : "2011-08-08 15:55:05 +0000",
    "user" : {
      "name" : "\u304D\u3087\u304D\u3087\u4E38",
      "screen_name" : "kyokyomaru",
      "protected" : false,
      "id_str" : "151819733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607525584176967680\/hlDj6bAX_normal.png",
      "id" : 151819733,
      "verified" : false
    }
  },
  "id" : 100911761112305664,
  "created_at" : "2011-08-09 12:50:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100899302657896448",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 100899302657896448,
  "created_at" : "2011-08-09 12:00:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100568464447647745",
  "text" : "\u52DD\u3063\u305F\u304B\u3089\u3068\u3044\u3046\u308F\u3051\u3058\u3083\u306A\u3044\u304C\u697D\u3057\u3044\u9EBB\u96C0\u3067\u3057\u305F\u30FC",
  "id" : 100568464447647745,
  "created_at" : "2011-08-08 14:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100568195118809088",
  "text" : "\u713C\u9CE5\uFF13\u4F4D\u30AA\u30FC\u30E9\u30B9\u3067\u56DB\u6697\u523B\u30C4\u30E2\u3063\u305F\u306E\u306F\u30C9\u30E9\u30DE\u30C6\u30A3\u30C3\u30AF\u3060\u3063\u305F\u2190",
  "id" : 100568195118809088,
  "created_at" : "2011-08-08 14:05:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100567988087955456",
  "text" : "\uFF11\u3001\uFF14\u3001\uFF11\u3001\uFF11\u3001\uFF13\u3001\uFF11\u3001\uFF11\u4F4D \u3067\u5C0F\u8A08+176 \u30C4\u30A4\u3066\u305F\u30FC",
  "id" : 100567988087955456,
  "created_at" : "2011-08-08 14:04:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100567587200581633",
  "text" : "\u9AD8\u6821\u306E\u30E1\u30F3\u30D0\u30FC\u3067\u9EBB\u96C0\u308F\u305A\u30FC\u3002\u534A\u8358\uFF17\u56DE\u3002",
  "id" : 100567587200581633,
  "created_at" : "2011-08-08 14:02:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100240250495967233",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
  "id" : 100240250495967233,
  "created_at" : "2011-08-07 16:21:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100224700076142593",
  "geo" : { },
  "id_str" : "100224814400290816",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u304A\u3084\u3059\u30DF\u30EB\u30AB\u3055\u3093",
  "id" : 100224814400290816,
  "in_reply_to_status_id" : 100224700076142593,
  "created_at" : "2011-08-07 15:20:32 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100224677905043456",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3067\u3059",
  "id" : 100224677905043456,
  "created_at" : "2011-08-07 15:19:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100224609332375553",
  "text" : "\u6C17\u4ED8\u3051\u3070\u65E5\u4ED8\u304B\u5909\u308F\u3063\u3066\u308B\u3057\u2026\u5BDD\u308B\u304B\u306A\u30FC\u3002",
  "id" : 100224609332375553,
  "created_at" : "2011-08-07 15:19:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100223382586531841",
  "text" : "KU\u5929\u9CF3\u30AF\u30E9\u30B9\u30BF\u3068\u304B\u80F8\u71B1\u2026",
  "id" : 100223382586531841,
  "created_at" : "2011-08-07 15:14:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100221432281300993",
  "text" : "\u4E0B\u5BBF\u306E\u8FD1\u304F\u306E\u81EA\u8EE2\u8ECA\u5C4B\u304C\u304D\u3085\u3046\u3079\u3047\u3060\u3063\u305F\u3002\u4FDD\u5065\u304B\u306A\u3093\u304B\u3067\u5951\u7D04\u3057\u3061\u3083\u3063\u305F\u304C\u5927\u4E08\u592B\u3060\u308D\u3046\u304B\u3002",
  "id" : 100221432281300993,
  "created_at" : "2011-08-07 15:07:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u3043",
      "screen_name" : "GAi9112",
      "indices" : [ 31, 39 ],
      "id_str" : "169436782",
      "id" : 169436782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100216475603828737",
  "text" : "\u6642\u8A08\u53F0\u306E\u4E0B\u306B\u3086\u3046\u3061\u3087\u4F7F\u3048\u308BATM\u306F\u3042\u308B\u304C\u624B\u6570\u6599\u53D6\u3089\u308C\u308B RT @GAi9112: \u3010KU\uFF78\uFF97\uFF7D\uFF80\u3078\u3011KU\u5185\u306B\u3086\u3046\u3061\u3087\u306EATM\u3063\u3066\u3042\u308A\u307E\u3059\u304B\uFF1F",
  "id" : 100216475603828737,
  "created_at" : "2011-08-07 14:47:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u308D\u3059\u3051",
      "screen_name" : "parosky0",
      "indices" : [ 3, 12 ],
      "id_str" : "87711420",
      "id" : 87711420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100200441551388672",
  "text" : "RT @parosky0: \u3010\u3082\u3057\u590F\u4F11\u307F\u306E\u81EA\u7531\u7814\u7A76\u306B\u8A66\u554F\u304C\u5C0E\u5165\u3055\u308C\u305F\u3089\u3011 \u300C\u50D5\u306F\u30A2\u30B5\u30AC\u30AA\u306E\u89B3\u5BDF\u3092\u3057\u307E\u3057\u305F\uFF01\u300D\u300C\u541B\u5148\u884C\u7814\u7A76\u306F\u8ABF\u3079\u305F\uFF1F\u305D\u308C\u3089\u306B\u5BFE\u3057\u3066\u512A\u4F4D\u6027\u3042\u308B\u306E\uFF1F\u300D\u300C\u2026\u3002\u300D\u300C\u3042\u3068\u305D\u308C\u8AB0\u3067\u3082\u601D\u3044\u3064\u304F\u3088\u306D\u3001\u30AA\u30EA\u30B8\u30CA\u30EA\u30C6\u30A3\u306F\u3069\u3053\uFF1F\u300D\u300C\u2026\u3002\u300D\u300C\u305D\u308C\u3068\u3001\u5B9F\u9A13\u7D50\u679C\u306E\u5B9A\u91CF\u7684\u306A\u8A55\u4FA1\u306F\uFF1F\u300D\u300C\u2026 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100179753457303552",
    "text" : "\u3010\u3082\u3057\u590F\u4F11\u307F\u306E\u81EA\u7531\u7814\u7A76\u306B\u8A66\u554F\u304C\u5C0E\u5165\u3055\u308C\u305F\u3089\u3011 \u300C\u50D5\u306F\u30A2\u30B5\u30AC\u30AA\u306E\u89B3\u5BDF\u3092\u3057\u307E\u3057\u305F\uFF01\u300D\u300C\u541B\u5148\u884C\u7814\u7A76\u306F\u8ABF\u3079\u305F\uFF1F\u305D\u308C\u3089\u306B\u5BFE\u3057\u3066\u512A\u4F4D\u6027\u3042\u308B\u306E\uFF1F\u300D\u300C\u2026\u3002\u300D\u300C\u3042\u3068\u305D\u308C\u8AB0\u3067\u3082\u601D\u3044\u3064\u304F\u3088\u306D\u3001\u30AA\u30EA\u30B8\u30CA\u30EA\u30C6\u30A3\u306F\u3069\u3053\uFF1F\u300D\u300C\u2026\u3002\u300D\u300C\u305D\u308C\u3068\u3001\u5B9F\u9A13\u7D50\u679C\u306E\u5B9A\u91CF\u7684\u306A\u8A55\u4FA1\u306F\uFF1F\u300D\u300C\u2026\u3002\u300D\u300C\u541B\u306D\u3001\u9032\u7D1A\u3059\u308B\u6C17\u3042\u308B\u306E\uFF1F\u300D",
    "id" : 100179753457303552,
    "created_at" : "2011-08-07 12:21:29 +0000",
    "user" : {
      "name" : "\u3071\u308D\u3059\u3051",
      "screen_name" : "parosky0",
      "protected" : false,
      "id_str" : "87711420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3022883380\/7ed33cada43b78dc7502f9db0ca26b1c_normal.png",
      "id" : 87711420,
      "verified" : false
    }
  },
  "id" : 100200441551388672,
  "created_at" : "2011-08-07 13:43:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100174483624706048",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 100174483624706048,
  "created_at" : "2011-08-07 12:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99812017279471616",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 99812017279471616,
  "created_at" : "2011-08-06 12:00:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 3, 13 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 15, 25 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99278693192581120",
  "text" : "RT @Lisa_math: @end313124 \u307E\u305F\u30D6\u30ED\u30C3\u30AF\u3055\u308C\u305F\u306E\u304B\u30FB\u30FB\u30FB5\u9031\u9593\uFF0B\u52B4\u50CD\u6642\u9593\u304C\u534A\u5206\u306B\u306A\u308B\u65E5\u304C2\u9031\u9593\u30C9\u30A4\u30C4\u30FB\u30FB\u30FB\u4E0A\u753B\u50CF\u306E\u3088\u3046\u306A\u5546\u54C1\u3092\u4E16\u306E\u4E2D\u306B\u5C4A\u3051\u308B\u4F1A\u793E\u3002\u3060\u304B\u3089\u79C1\u306F\u7A74\u3092\u6398\u308B\u305F\u3081\u306E\u30C9\u30EA\u30EB\u304C\u6B32\u3057\u3044\u3002\u8CC7\u6599\u958B\u304D\u306A\u304C\u3089\u306E\u4F5C\u696D\u304C\u3084\u308A\u3065\u3089\u3044\u3002\u30EA\u30D5\u30A1\u30EC\u30F3\u30B9\u3068\u304B\u5199\u771F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/botis.org\/wiki\/PySocialBot\" rel=\"nofollow\"\u003EPySocialBot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "99278587642908672",
    "geo" : { },
    "id_str" : "99278591287754752",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u307E\u305F\u30D6\u30ED\u30C3\u30AF\u3055\u308C\u305F\u306E\u304B\u30FB\u30FB\u30FB5\u9031\u9593\uFF0B\u52B4\u50CD\u6642\u9593\u304C\u534A\u5206\u306B\u306A\u308B\u65E5\u304C2\u9031\u9593\u30C9\u30A4\u30C4\u30FB\u30FB\u30FB\u4E0A\u753B\u50CF\u306E\u3088\u3046\u306A\u5546\u54C1\u3092\u4E16\u306E\u4E2D\u306B\u5C4A\u3051\u308B\u4F1A\u793E\u3002\u3060\u304B\u3089\u79C1\u306F\u7A74\u3092\u6398\u308B\u305F\u3081\u306E\u30C9\u30EA\u30EB\u304C\u6B32\u3057\u3044\u3002\u8CC7\u6599\u958B\u304D\u306A\u304C\u3089\u306E\u4F5C\u696D\u304C\u3084\u308A\u3065\u3089\u3044\u3002\u30EA\u30D5\u30A1\u30EC\u30F3\u30B9\u3068\u304B\u5199\u771F",
    "id" : 99278591287754752,
    "in_reply_to_status_id" : 99278587642908672,
    "created_at" : "2011-08-05 00:40:35 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "protected" : false,
      "id_str" : "254452685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1875685697\/Lisa_n1_normal.png",
      "id" : 254452685,
      "verified" : false
    }
  },
  "id" : 99278693192581120,
  "created_at" : "2011-08-05 00:40:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99278462778486784",
  "geo" : { },
  "id_str" : "99278587642908672",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u96E2\u8131 \u307E\u305F\u306D",
  "id" : 99278587642908672,
  "in_reply_to_status_id" : 99278462778486784,
  "created_at" : "2011-08-05 00:40:34 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99278340309008384",
  "geo" : { },
  "id_str" : "99278460375150593",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3082\u3063\u3068\u304C\u3093\u3070\u308C",
  "id" : 99278460375150593,
  "in_reply_to_status_id" : 99278340309008384,
  "created_at" : "2011-08-05 00:40:04 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99278252358647809",
  "geo" : { },
  "id_str" : "99278335577817089",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u304C\u3093\u3070\u308C",
  "id" : 99278335577817089,
  "in_reply_to_status_id" : 99278252358647809,
  "created_at" : "2011-08-05 00:39:34 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99278247740719105",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u624B\u9045\u308C\u3060\u306A",
  "id" : 99278247740719105,
  "created_at" : "2011-08-05 00:39:13 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99277915463757825",
  "geo" : { },
  "id_str" : "99278077804290048",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u624B\u306B\u53D6\u3089\u306A\u3044\u3068\u308F\u304B\u3089\u306A\u3044\u3053\u3068\u3082\u3042\u308B\u3088\u306D",
  "id" : 99278077804290048,
  "in_reply_to_status_id" : 99277915463757825,
  "created_at" : "2011-08-05 00:38:32 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99277765672570880",
  "geo" : { },
  "id_str" : "99277912951365632",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u305D\u3044\u3064\u306F\u30CF\u30FC\u30C9\u3060\u306A",
  "id" : 99277912951365632,
  "in_reply_to_status_id" : 99277765672570880,
  "created_at" : "2011-08-05 00:37:53 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99277408745689088",
  "geo" : { },
  "id_str" : "99277762233245697",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u62EC\u5F27\u306F\u9589\u3058\u3088\u3046\u305C\u3001\u983C\u3080\u304B\u3089\u3055",
  "id" : 99277762233245697,
  "in_reply_to_status_id" : 99277408745689088,
  "created_at" : "2011-08-05 00:37:17 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99277248045129728",
  "geo" : { },
  "id_str" : "99277406061346816",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3048\u3063",
  "id" : 99277406061346816,
  "in_reply_to_status_id" : 99277248045129728,
  "created_at" : "2011-08-05 00:35:52 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99276644468002816",
  "geo" : { },
  "id_str" : "99277245717282816",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u300A\u3061\u3083\u3093\u300B\u306F\u4E0D\u8981",
  "id" : 99277245717282816,
  "in_reply_to_status_id" : 99276644468002816,
  "created_at" : "2011-08-05 00:35:14 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99276962723414017",
  "text" : "\u304B\u3044\u304D\u3085\u3093\u3066KU\u30AF\u30E9\u30B9\u30BF\u306E\u4EBA\u3060\u3088\u306A\u3001\u80F8\u71B1",
  "id" : 99276962723414017,
  "created_at" : "2011-08-05 00:34:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 3, 13 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 15, 25 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99276807118925824",
  "text" : "RT @Lisa_math: @end313124 K.Isibasi\u3061\u3083\u3093\uFF1D\u304B\u3044\u304D\u3085\u3093\u3067\u3059\u3002\u3088\u304F\u30C9S\u3063\u3066\u8A00\u308F\u308C\u305F\u3002\u306A\u308B\u307B\u3069\u3001\u666E\u6BB5\u306F\u3069\u3053\u306B\u3042\u308B\u3093\u3060\u30FB\u30FB\u30FB\u4FFA\u306F\u4EBA\u9593\u306E\u305F\u3081\u3063\u3061\u3088\u308A\u306FPC\u306E\u305F\u3081\u3088\u3000\u3000\u3000\u671D\u306E\u4E00\u676F\u306F\u9045\u308C\u305F\u3051\u3069\u3001\u914D\u5217\u306E\u30DD\u30A4\u30F3\u30BF\u30BB\u30C3\u30C8\u3059\u308B\u3060\u3051\u304B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/botis.org\/wiki\/PySocialBot\" rel=\"nofollow\"\u003EPySocialBot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "99276515124051968",
    "geo" : { },
    "id_str" : "99276518987018241",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 K.Isibasi\u3061\u3083\u3093\uFF1D\u304B\u3044\u304D\u3085\u3093\u3067\u3059\u3002\u3088\u304F\u30C9S\u3063\u3066\u8A00\u308F\u308C\u305F\u3002\u306A\u308B\u307B\u3069\u3001\u666E\u6BB5\u306F\u3069\u3053\u306B\u3042\u308B\u3093\u3060\u30FB\u30FB\u30FB\u4FFA\u306F\u4EBA\u9593\u306E\u305F\u3081\u3063\u3061\u3088\u308A\u306FPC\u306E\u305F\u3081\u3088\u3000\u3000\u3000\u671D\u306E\u4E00\u676F\u306F\u9045\u308C\u305F\u3051\u3069\u3001\u914D\u5217\u306E\u30DD\u30A4\u30F3\u30BF\u30BB\u30C3\u30C8\u3059\u308B\u3060\u3051\u304B\u2026",
    "id" : 99276518987018241,
    "in_reply_to_status_id" : 99276515124051968,
    "created_at" : "2011-08-05 00:32:21 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "protected" : false,
      "id_str" : "254452685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1875685697\/Lisa_n1_normal.png",
      "id" : 254452685,
      "verified" : false
    }
  },
  "id" : 99276807118925824,
  "created_at" : "2011-08-05 00:33:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99276518987018241",
  "geo" : { },
  "id_str" : "99276641523601409",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3061\u3083\u3093\u306F\u4E0D\u8981",
  "id" : 99276641523601409,
  "in_reply_to_status_id" : 99276518987018241,
  "created_at" : "2011-08-05 00:32:50 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99275435250171904",
  "geo" : { },
  "id_str" : "99276515124051968",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u671D\u304B\u3089\u5143\u6C17\u304C\u3044\u3044\u306A\u3001\u4F55\u304B\u826F\u3044\u3053\u3068\u3067\u3082\u3042\u3063\u305F\u306E\u304B\u3044\uFF1F",
  "id" : 99276515124051968,
  "in_reply_to_status_id" : 99275435250171904,
  "created_at" : "2011-08-05 00:32:20 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99275428027580416",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 99275428027580416,
  "created_at" : "2011-08-05 00:28:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99146815412240385",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
  "id" : 99146815412240385,
  "created_at" : "2011-08-04 15:56:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99087215245799424",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 99087215245799424,
  "created_at" : "2011-08-04 12:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99056290545926144",
  "text" : "\uFF16\u6587\u5B57\u3057\u308A\u3068\u308A\u3068\u98DF\u3079\u7269\u3057\u308A\u3068\u308A\u3068\u98DF\u3079\u3089\u308C\u306A\u3044\u3082\u306E\u3057\u308A\u3068\u308A\u3092\u540C\u6642\u9032\u884C\u306A\u3046",
  "id" : 99056290545926144,
  "created_at" : "2011-08-04 09:57:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99036269568471040",
  "text" : "@nico_reflexio \u5426\u3081\u3093\u2026",
  "id" : 99036269568471040,
  "created_at" : "2011-08-04 08:37:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99034307779248128",
  "text" : "\u6570\u65E5\u5F35\u308A\u4ED8\u3044\u3066\u306A\u3044\u306E\u306F\u53CB\u4EBA\u304C\u3044\u308B\u304B\u3089\u3067\u3059\u3002",
  "id" : 99034307779248128,
  "created_at" : "2011-08-04 08:29:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "\u661F\u8F1D",
      "screen_name" : "seikira",
      "indices" : [ 32, 40 ],
      "id_str" : "102092537",
      "id" : 102092537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98701228577525760",
  "text" : "RT @hyuki: \u300C\u30E1\u30FC\u30EB\u304A\u304F\u308C\u306A\u3044\u3002\u30E1\u30FC\u30EB\u304A\u304F\u308C\u308B\u300DRT @seikira: \u300C\u3057\u3093\u3067\u306A\u3044\u30B7\u30E3\u30FC\u30D7\u30DA\u30F3\u30B7\u30EB\u306F\u3057\u3093\u3067\u308B\u300D\u3068\u3044\u3046\u6587\u7AE0\u306E\u3059\u3054\u3055\u3002\u82AF\u51FA\u306A\u3044\u30B7\u30E3\u30FC\u30D7\u30DA\u30F3\u30B7\u30EB\u306F\u6B7B\u3093\u3067\u308B\u3057\u3001\u6B7B\u3093\u3067\u306A\u3044\u30B7\u30E3\u30FC\u30D7\u30DA\u30F3\u30B7\u30EB\u306F\u82AF\u51FA\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u661F\u8F1D",
        "screen_name" : "seikira",
        "indices" : [ 21, 29 ],
        "id_str" : "102092537",
        "id" : 102092537
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98693635494789120",
    "text" : "\u300C\u30E1\u30FC\u30EB\u304A\u304F\u308C\u306A\u3044\u3002\u30E1\u30FC\u30EB\u304A\u304F\u308C\u308B\u300DRT @seikira: \u300C\u3057\u3093\u3067\u306A\u3044\u30B7\u30E3\u30FC\u30D7\u30DA\u30F3\u30B7\u30EB\u306F\u3057\u3093\u3067\u308B\u300D\u3068\u3044\u3046\u6587\u7AE0\u306E\u3059\u3054\u3055\u3002\u82AF\u51FA\u306A\u3044\u30B7\u30E3\u30FC\u30D7\u30DA\u30F3\u30B7\u30EB\u306F\u6B7B\u3093\u3067\u308B\u3057\u3001\u6B7B\u3093\u3067\u306A\u3044\u30B7\u30E3\u30FC\u30D7\u30DA\u30F3\u30B7\u30EB\u306F\u82AF\u51FA\u308B\u3002",
    "id" : 98693635494789120,
    "created_at" : "2011-08-03 09:56:11 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 98701228577525760,
  "created_at" : "2011-08-03 10:26:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98537737266794497",
  "geo" : { },
  "id_str" : "98537851473502209",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u306F\u3088\u3046",
  "id" : 98537851473502209,
  "in_reply_to_status_id" : 98537737266794497,
  "created_at" : "2011-08-02 23:37:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98362456744796160",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 98362456744796160,
  "created_at" : "2011-08-02 12:00:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 3, 13 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98277312826580992",
  "text" : "RT @blackVELU: \u3042\u306A\u305F\u3068\u4E00\u7DD2\u306B\uFF72\uFF9D\uFF8B\uFF9F\uFF70\uFF80\uFF9E\uFF9D\uFF7D\u3092\u8E0A\u308A\u307E\u3057\u3087\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98276182226771968",
    "text" : "\u3042\u306A\u305F\u3068\u4E00\u7DD2\u306B\uFF72\uFF9D\uFF8B\uFF9F\uFF70\uFF80\uFF9E\uFF9D\uFF7D\u3092\u8E0A\u308A\u307E\u3057\u3087\u3046",
    "id" : 98276182226771968,
    "created_at" : "2011-08-02 06:17:22 +0000",
    "user" : {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "protected" : false,
      "id_str" : "102325414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450656382325248000\/cnubEZOd_normal.jpeg",
      "id" : 102325414,
      "verified" : false
    }
  },
  "id" : 98277312826580992,
  "created_at" : "2011-08-02 06:21:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u3043",
      "screen_name" : "GAi9112",
      "indices" : [ 19, 27 ],
      "id_str" : "169436782",
      "id" : 169436782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98252739854876673",
  "text" : "\u7BB1\u3067\u8CB7\u3063\u3066\u308B\u79C1\u304C\u901A\u308A\u307E\u3059\u3088\u3063\u3068 RT @GAi9112: \u30DA\u30C3\u30C8\u30DC\u30C8\u30EB\u3067\u30C8\u30CB\u30C3\u30AF\u51FA\u3057\u305F\u3089\u7D76\u5BFE\u58F2\u308C\u308B\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u306A\u30FC",
  "id" : 98252739854876673,
  "created_at" : "2011-08-02 04:44:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 13, 22 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98247193101733889",
  "text" : "\u5B9F\u7DDA\u5F62\u9A13\u304C\u5927\u4E8B\u3060\u306A RT @akeopyaa: \u3044\u3088\u3044\u3088\u7DDA\u5F62\u3068\u306E\u4E00\u6226\u3092\u4EA4\u3048\u308B\u3068\u304D\u304C\u304D\u305F",
  "id" : 98247193101733889,
  "created_at" : "2011-08-02 04:22:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 10, 21 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98127426588119040",
  "geo" : { },
  "id_str" : "98139324389933056",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn @magokoro84 \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 98139324389933056,
  "in_reply_to_status_id" : 98127426588119040,
  "created_at" : "2011-08-01 21:13:32 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98127237685055488",
  "text" : "\u30DE\u30C3\u30C4\u306A\u3046",
  "id" : 98127237685055488,
  "created_at" : "2011-08-01 20:25:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3069\u3044\u3055\u3093",
      "screen_name" : "midoisan",
      "indices" : [ 3, 12 ],
      "id_str" : "276342079",
      "id" : 276342079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98007590432276480",
  "text" : "RT @midoisan: \u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u3069\u3053\u304C\u9762\u767D\u3044\u3093\u3067\u3059\u304B\uFF1F\u300D\u3000\u52B9\u679C\uFF1A\u767A\u8868\u8005\u306F\u6B7B\u306C\u3000\n\u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u5148\u884C\u7814\u7A76\u3042\u308A\u307E\u3059\u3088\uFF1F\u300D\u3000\u52B9\u679C\uFF1A\u767A\u8868\u8005\u306F\u6B7B\u306C\u3000\n\u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u65B0\u624B\u6CD5\u3088\u308A\u8F9E\u66F8\u6574\u5099\u3057\u305F\u65B9\u304C\u826F\u3044\u3093\u3058\u3083\u306A\u3044\u306E\uFF1F\u300D\u3000\u52B9\u679C\uFF1A\u767A\u8868\u8005\u306F\u6B7B\u306C\u3000\n\u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u3069\u3053\u304C\u30CE\u30F3\u30C8\u30EA\u30F4\u30A3\u30A2\u30EB\u3067 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www25.atpages.jp\/midoisan\/\" rel=\"nofollow\"\u003E\u307F\u3069\u3044\u3001\u5B9F\u306B\u307F\u3069\u3044\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97939594074537984",
    "text" : "\u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u3069\u3053\u304C\u9762\u767D\u3044\u3093\u3067\u3059\u304B\uFF1F\u300D\u3000\u52B9\u679C\uFF1A\u767A\u8868\u8005\u306F\u6B7B\u306C\u3000\n\u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u5148\u884C\u7814\u7A76\u3042\u308A\u307E\u3059\u3088\uFF1F\u300D\u3000\u52B9\u679C\uFF1A\u767A\u8868\u8005\u306F\u6B7B\u306C\u3000\n\u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u65B0\u624B\u6CD5\u3088\u308A\u8F9E\u66F8\u6574\u5099\u3057\u305F\u65B9\u304C\u826F\u3044\u3093\u3058\u3083\u306A\u3044\u306E\uFF1F\u300D\u3000\u52B9\u679C\uFF1A\u767A\u8868\u8005\u306F\u6B7B\u306C\u3000\n\u30FB\u546A\u6587\u300C\u305D\u308C\u3001\u3069\u3053\u304C\u30CE\u30F3\u30C8\u30EA\u30F4\u30A3\u30A2\u30EB\u3067\u3059\u304B\uFF1F\u300D\u3000\u52B9\u679C\uFF1A\u767A\u8868\u8005\u306F\u6B7B\u306C\u3000",
    "id" : 97939594074537984,
    "created_at" : "2011-08-01 07:59:53 +0000",
    "user" : {
      "name" : "\u307F\u3069\u3044\u3055\u3093",
      "screen_name" : "midoisan",
      "protected" : false,
      "id_str" : "276342079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1297961215\/g_normal.jpg",
      "id" : 276342079,
      "verified" : false
    }
  },
  "id" : 98007590432276480,
  "created_at" : "2011-08-01 12:30:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98003513686245376",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
  "id" : 98003513686245376,
  "created_at" : "2011-08-01 12:13:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B5\u30E0\u30BD\u30F3\u30ED\u30A4\u30BF\u30FC",
      "screen_name" : "sanakan90",
      "indices" : [ 3, 13 ],
      "id_str" : "134345997",
      "id" : 134345997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97935573666373632",
  "text" : "RT @sanakan90: \u65B0\u5E79\u7DDA\u306E\u7A93\u53E3\u3067\u300C\u4E00\u756A\u3044\u3044\u5E2D\u3092\u983C\u3080\u300D\u3068\u3044\u3063\u305F\u3089\u672C\u5F53\u306B\u51FA\u3066\u304D\u305F http:\/\/twitpic.com\/5yo8sm\u3000\u304F\u3063\u305D\uFF57\uFF57\uFF57\u306A\u3093\u3068\u3044\u3046\u7C8B\u306A\u8A08\u3089\u3044www",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97696908583243776",
    "text" : "\u65B0\u5E79\u7DDA\u306E\u7A93\u53E3\u3067\u300C\u4E00\u756A\u3044\u3044\u5E2D\u3092\u983C\u3080\u300D\u3068\u3044\u3063\u305F\u3089\u672C\u5F53\u306B\u51FA\u3066\u304D\u305F http:\/\/twitpic.com\/5yo8sm\u3000\u304F\u3063\u305D\uFF57\uFF57\uFF57\u306A\u3093\u3068\u3044\u3046\u7C8B\u306A\u8A08\u3089\u3044www",
    "id" : 97696908583243776,
    "created_at" : "2011-07-31 15:55:32 +0000",
    "user" : {
      "name" : "\u30B5\u30E0\u30BD\u30F3\u30ED\u30A4\u30BF\u30FC",
      "screen_name" : "sanakan90",
      "protected" : false,
      "id_str" : "134345997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2466447383\/icon2066076504155625361x2_dc5f294_normal.png",
      "id" : 134345997,
      "verified" : false
    }
  },
  "id" : 97935573666373632,
  "created_at" : "2011-08-01 07:43:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97916847634124800",
  "text" : "\u6253\u3063\u3066\u3057\u307E\u3063\u305F\u611F\u2026",
  "id" : 97916847634124800,
  "created_at" : "2011-08-01 06:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308B\u3044\u3058",
      "screen_name" : "luigium",
      "indices" : [ 3, 11 ],
      "id_str" : "126222694",
      "id" : 126222694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97916704943902720",
  "text" : "RT @luigium: \u4E09\u5841\u6253",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97916338680504320",
    "text" : "\u4E09\u5841\u6253",
    "id" : 97916338680504320,
    "created_at" : "2011-08-01 06:27:29 +0000",
    "user" : {
      "name" : "\u308B\u3044\u3058",
      "screen_name" : "luigium",
      "protected" : false,
      "id_str" : "126222694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514800113089142784\/ztoDGYO7_normal.jpeg",
      "id" : 126222694,
      "verified" : false
    }
  },
  "id" : 97916704943902720,
  "created_at" : "2011-08-01 06:28:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97916089773723649",
  "text" : "RT @magokoro84: \u30B5\u30D6\u3061\u3083\u3093\u306E\u51CB\u843D\u3063\u3077\u308A\u30CF\u30F3\u30D1\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97915583479300096",
    "text" : "\u30B5\u30D6\u3061\u3083\u3093\u306E\u51CB\u843D\u3063\u3077\u308A\u30CF\u30F3\u30D1\u306A\u3044",
    "id" : 97915583479300096,
    "created_at" : "2011-08-01 06:24:28 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 97916089773723649,
  "created_at" : "2011-08-01 06:26:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F50\u7AF9\u5D07\u53F8\uFF08Takashi Satake\uFF09",
      "screen_name" : "s_takac",
      "indices" : [ 3, 11 ],
      "id_str" : "49344152",
      "id" : 49344152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97916066335948800",
  "text" : "RT @s_takac: \u30DE\u30B8\u304B\uFF01\u3010\u6700\u8FD1\u4E00\u756A\u30B7\u30E7\u30C3\u30AF\u3060\u3063\u305F\u4E8B\u5B9F\u3011\u3010\u30B5\u30B6\u30A8\u3055\u3093\u9054\u306E\u5B66\u6B74\u3011\u6CE2\u5E73\/\u4EAC\u90FD\u5927\u5B66\u3000\u30D5\u30CD\/\u65E5\u672C\u5973\u5B50\u5927\u5B66\u3000\u30DE\u30B9\u30AA\/\u65E9\u7A32\u7530\u5927\u5B66\u3000\u30B5\u30B6\u30A8\/\u5DDD\u6751\u5973\u5B50\u77ED\u5927\u4E2D\u9000\u3000\u30B5\u30D6\u3061\u3083\u3093\/\u4E00\u6A4B\u5927\u5B66\u2192\u30B5\u30F3\u30C8\u30EA\u30FC\u2192\u4E09\u6CB3\u5C4B\u3000\u30A2\u30CA\u30B4\/\u4EAC\u90FD\u5927\u5B66\u3000\u30CE\u30EA\u30B9\u30B1\/\u6771\u4EAC\u5927\u5B66\u6587\u79D1\u4E00\u985E(\u6CD5\u5B66\u90E8)\u3000\u30BF\u30A4\u30B3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97830237928304640",
    "text" : "\u30DE\u30B8\u304B\uFF01\u3010\u6700\u8FD1\u4E00\u756A\u30B7\u30E7\u30C3\u30AF\u3060\u3063\u305F\u4E8B\u5B9F\u3011\u3010\u30B5\u30B6\u30A8\u3055\u3093\u9054\u306E\u5B66\u6B74\u3011\u6CE2\u5E73\/\u4EAC\u90FD\u5927\u5B66\u3000\u30D5\u30CD\/\u65E5\u672C\u5973\u5B50\u5927\u5B66\u3000\u30DE\u30B9\u30AA\/\u65E9\u7A32\u7530\u5927\u5B66\u3000\u30B5\u30B6\u30A8\/\u5DDD\u6751\u5973\u5B50\u77ED\u5927\u4E2D\u9000\u3000\u30B5\u30D6\u3061\u3083\u3093\/\u4E00\u6A4B\u5927\u5B66\u2192\u30B5\u30F3\u30C8\u30EA\u30FC\u2192\u4E09\u6CB3\u5C4B\u3000\u30A2\u30CA\u30B4\/\u4EAC\u90FD\u5927\u5B66\u3000\u30CE\u30EA\u30B9\u30B1\/\u6771\u4EAC\u5927\u5B66\u6587\u79D1\u4E00\u985E(\u6CD5\u5B66\u90E8)\u3000\u30BF\u30A4\u30B3\/\u7ACB\u6559\u5927\u5B66\u7D4C\u6E08\u5B66\u90E8",
    "id" : 97830237928304640,
    "created_at" : "2011-08-01 00:45:20 +0000",
    "user" : {
      "name" : "\u4F50\u7AF9\u5D07\u53F8\uFF08Takashi Satake\uFF09",
      "screen_name" : "s_takac",
      "protected" : false,
      "id_str" : "49344152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797157839\/____normal.jpg",
      "id" : 49344152,
      "verified" : false
    }
  },
  "id" : 97916066335948800,
  "created_at" : "2011-08-01 06:26:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kazy",
      "screen_name" : "gakeau",
      "indices" : [ 3, 10 ],
      "id_str" : "75959129",
      "id" : 75959129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97914002302189568",
  "text" : "RT @gakeau: \u4EAC\u5927\u5409\u7530\u5357\u69CB\u5185\u304B\u3089\u53E4\u58B3\u304C\u51FA\u3066\u304D\u305F\u3089\u3057\u3044\u3002\u6614\u304B\u3089\u306A\u3093\u304B\u907A\u8DE1\u304C\u57CB\u307E\u3063\u3066\u308B\u3053\u3068\u306F\u77E5\u3063\u3066\u305F\u3051\u3069\u3001\u53E4\u58B3\u3068\u306F\uFF01\u3073\u3063\u304F\u308A\u3002\u3061\u306A\u307F\u306B\u3001\u57CB\u307E\u3063\u3066\u305F\u5834\u6240\u306F\u30C6\u30CB\u30B9\u30B3\u30FC\u30C8\u306E\u4E0B\u3067\u3059(\u5148\u9031\u884C\u3063\u305F\u3089\u6398\u308A\u8FD4\u3057\u3066\u305F)\u3002\u306A\u304A\u3073\u3063\u304F\u308A\u3002http:\/\/bit.ly\/o1ivEk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97873508415180800",
    "text" : "\u4EAC\u5927\u5409\u7530\u5357\u69CB\u5185\u304B\u3089\u53E4\u58B3\u304C\u51FA\u3066\u304D\u305F\u3089\u3057\u3044\u3002\u6614\u304B\u3089\u306A\u3093\u304B\u907A\u8DE1\u304C\u57CB\u307E\u3063\u3066\u308B\u3053\u3068\u306F\u77E5\u3063\u3066\u305F\u3051\u3069\u3001\u53E4\u58B3\u3068\u306F\uFF01\u3073\u3063\u304F\u308A\u3002\u3061\u306A\u307F\u306B\u3001\u57CB\u307E\u3063\u3066\u305F\u5834\u6240\u306F\u30C6\u30CB\u30B9\u30B3\u30FC\u30C8\u306E\u4E0B\u3067\u3059(\u5148\u9031\u884C\u3063\u305F\u3089\u6398\u308A\u8FD4\u3057\u3066\u305F)\u3002\u306A\u304A\u3073\u3063\u304F\u308A\u3002http:\/\/bit.ly\/o1ivEk",
    "id" : 97873508415180800,
    "created_at" : "2011-08-01 03:37:17 +0000",
    "user" : {
      "name" : "kazy",
      "screen_name" : "gakeau",
      "protected" : false,
      "id_str" : "75959129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477470477753929728\/9YHDK90y_normal.jpeg",
      "id" : 75959129,
      "verified" : false
    }
  },
  "id" : 97914002302189568,
  "created_at" : "2011-08-01 06:18:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]