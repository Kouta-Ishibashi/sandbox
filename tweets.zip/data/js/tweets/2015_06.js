Grailbird.data.tweets_2015_06 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608233299681509376",
  "geo" : { },
  "id_str" : "608242759183405056",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u304B\u304F\u306B\u3093\u3057\u307E\u3057\u305F\u3002",
  "id" : 608242759183405056,
  "in_reply_to_status_id" : 608233299681509376,
  "created_at" : "2015-06-09 12:02:29 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608231355080507392",
  "text" : "\u300C\u5099\u4E2D\u936C \u30CF\u30F3\u30C9\u30A2\u30C3\u30AF\u30B9\u300D\u3067\u4E00\u756A\u4E0A\u306B\u6765\u308B\u306E\u3067\u63A1\u7528\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 608231355080507392,
  "created_at" : "2015-06-09 11:17:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "indices" : [ 3, 16 ],
      "id_str" : "181966634",
      "id" : 181966634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608231243910496256",
  "text" : "RT @zweisleeping: \u300C\u693F\u4E95\u307E\u305B\u308A\u300D\u3067\u4E00\u756A\u4E0A\u306B\u304F\u308B\u306E\u3067\u63A1\u7528\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u5F53\u305F\u308A\u524D\u3060\u3063\u305F\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608230960564301824",
    "text" : "\u300C\u693F\u4E95\u307E\u305B\u308A\u300D\u3067\u4E00\u756A\u4E0A\u306B\u304F\u308B\u306E\u3067\u63A1\u7528\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u5F53\u305F\u308A\u524D\u3060\u3063\u305F\uFF09",
    "id" : 608230960564301824,
    "created_at" : "2015-06-09 11:15:36 +0000",
    "user" : {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "protected" : false,
      "id_str" : "181966634",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548543809970135040\/cUm2VAC0_normal.jpeg",
      "id" : 181966634,
      "verified" : false
    }
  },
  "id" : 608231243910496256,
  "created_at" : "2015-06-09 11:16:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608229572438417409",
  "text" : "\u5730\u306B\u8DB3\u3092\u3064\u3051\u3066\u3044\u3051",
  "id" : 608229572438417409,
  "created_at" : "2015-06-09 11:10:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608229091540467714",
  "text" : "\u3061\u3083\u3093\u3075\u30FC\u3068\u3068\u8DA3\u5473\u304C\u5408\u3044\u305D\u3046",
  "id" : 608229091540467714,
  "created_at" : "2015-06-09 11:08:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608228664862310400",
  "text" : "\u6771\u306E\u56FD\u306E\u7720\u308B\u65B9\u306E",
  "id" : 608228664862310400,
  "created_at" : "2015-06-09 11:06:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608228574940659713",
  "text" : "\u6771\u306E\u56FD\u306E\u7720\u3089\u306A\u3044\u65B9\u306E\u3075\u30FC\u3068\u3061\u3083\u3093",
  "id" : 608228574940659713,
  "created_at" : "2015-06-09 11:06:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608168288414265344",
  "text" : "\u3053\u306E\u753B\u50CF\u610F\u5473\u4E0D\u660E\u3067\u597D\u304D",
  "id" : 608168288414265344,
  "created_at" : "2015-06-09 07:06:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/608168203563450368\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rpn4bLQwZx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHClvqsUgAAGuhM.jpg",
      "id_str" : "608168188027633664",
      "id" : 608168188027633664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHClvqsUgAAGuhM.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rpn4bLQwZx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608168203563450368",
  "text" : "http:\/\/t.co\/rpn4bLQwZx",
  "id" : 608168203563450368,
  "created_at" : "2015-06-09 07:06:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608133654452183040",
  "text" : "\u5E73\u65E5\u306E\u304A\u663C\u306F\u30AD\u30E3\u30C3\u30B9\u30EB\u3060\u3051\u304C\u697D\u3057\u307F\u307F\u305F\u3044\u306A\u3068\u3053\u308D\u51FA\u3066\u304D\u305F",
  "id" : 608133654452183040,
  "created_at" : "2015-06-09 04:48:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608011804879384577",
  "text" : "\u3086\u308C\u3086\u308C",
  "id" : 608011804879384577,
  "created_at" : "2015-06-08 20:44:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607795558305034240",
  "geo" : { },
  "id_str" : "607795699233587200",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u7D4C\u9A13\u7684\u306B\u306F\u8A00\u308F\u306A\u3044\u3068\u4F1D\u308F\u3089\u306A\u3044\u3093\u3060\u3088\u306A\u3041",
  "id" : 607795699233587200,
  "in_reply_to_status_id" : 607795558305034240,
  "created_at" : "2015-06-08 06:26:01 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607795133283573760",
  "geo" : { },
  "id_str" : "607795281212473344",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u4EBA\u9593\u30FC\u91CF\u5B50\u30B3\u30F3\u30D0\u30FC\u30BF\u30FC\u306E\u958B\u767A\u304C\u5F85\u3061\u671B\u307E\u308C\u308B",
  "id" : 607795281212473344,
  "in_reply_to_status_id" : 607795133283573760,
  "created_at" : "2015-06-08 06:24:21 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607794945890476033",
  "geo" : { },
  "id_str" : "607795161892913156",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u3069\u3053\u3067\u3082\u30C9\u30A2\u3067\u3082\u30EF\u30FC\u30D7\u3067\u3082\u4F55\u3067\u3082\u3044\u3044\u3093\u3067\u3059\u3051\u3069\u306D",
  "id" : 607795161892913156,
  "in_reply_to_status_id" : 607794945890476033,
  "created_at" : "2015-06-08 06:23:53 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607794898490638336",
  "text" : "\u3069\u3053\u306B\u3067\u3082\u3044\u305F\u3044",
  "id" : 607794898490638336,
  "created_at" : "2015-06-08 06:22:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607794789514276864",
  "text" : "\u306F\u30FC\u672D\u5E4C\u3068\u6771\u4EAC\u3068\u4EAC\u90FD\u3068\u306B\u540C\u6642\u306B\u5B58\u5728\u3057\u3066\u3044\u305F\u3044\u306A\u30FC",
  "id" : 607794789514276864,
  "created_at" : "2015-06-08 06:22:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607779411367108609",
  "text" : "helm\u3092\u3044\u308F\u308C\u308B\u304C\u307E\u307E\u306B\u30A4\u30F3\u30B9\u30B3\u3057\u305F",
  "id" : 607779411367108609,
  "created_at" : "2015-06-08 05:21:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607778879684538368",
  "text" : "\u306F\u3089\u3072\u308C",
  "id" : 607778879684538368,
  "created_at" : "2015-06-08 05:19:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607768557829521409",
  "geo" : { },
  "id_str" : "607768641598128129",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u60AA\u3044\u304C\u3088\u308D\u3057\u304F\u983C\u307F\u307E\u3059",
  "id" : 607768641598128129,
  "in_reply_to_status_id" : 607768557829521409,
  "created_at" : "2015-06-08 04:38:30 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607767461509734401",
  "text" : "\u4ECA\u65E5\u306E\u30AD\u30E3\u30C3\u30B9\u30EB\u3001\u30A2\u30EC\u30AF\u30B7\u30B9\u306E\u771F\u9854\u82B8\u304C\u6700\u9AD8\u3060\u3063\u305F",
  "id" : 607767461509734401,
  "created_at" : "2015-06-08 04:33:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607766458869776384",
  "geo" : { },
  "id_str" : "607767268571770880",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u91CD\u3055\u3082\u3042\u308B\u3060\u308D\u3046\u3057\u5B9A\u5F62\u5916\u304B\u306A\u3001\u304A\u91D1\u306F\u3042\u3068\u3067\u6255\u3046\u3088",
  "id" : 607767268571770880,
  "in_reply_to_status_id" : 607766458869776384,
  "created_at" : "2015-06-08 04:33:03 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607742277759279104",
  "text" : "NASA",
  "id" : 607742277759279104,
  "created_at" : "2015-06-08 02:53:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/607742261170827264\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/xV3jalG66Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG8iUYhUAAASm4I.jpg",
      "id_str" : "607742208293208064",
      "id" : 607742208293208064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG8iUYhUAAASm4I.jpg",
      "sizes" : [ {
        "h" : 451,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xV3jalG66Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607742261170827264",
  "text" : "\u5FC3\u5F53\u305F\u308A\u306EMASA http:\/\/t.co\/xV3jalG66Z",
  "id" : 607742261170827264,
  "created_at" : "2015-06-08 02:53:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607724144352837632",
  "text" : "(\u00B4_\u309D\u02CB)\uFF87\uFF70\uFF9D",
  "id" : 607724144352837632,
  "created_at" : "2015-06-08 01:41:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/qo2qBK1WLt",
      "expanded_url" : "http:\/\/www.geocities.jp\/tomoatomi\/raira0001.htm",
      "display_url" : "geocities.jp\/tomoatomi\/rair\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607576967802519552",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u7A7A http:\/\/t.co\/qo2qBK1WLt",
  "id" : 607576967802519552,
  "created_at" : "2015-06-07 15:56:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607574546598617091",
  "text" : "\u85C1\u4EBA\u5F62\u8AD6\u6CD5",
  "id" : 607574546598617091,
  "created_at" : "2015-06-07 15:47:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607571733684482048",
  "text" : "\u904E\u3061\u3092\u72AF\u3057\u305F\u4EBA\u9593\u306A\u3089\u601D\u3044\u3063\u304D\u308A\u53E9\u3044\u3066\u3082\u826F\u3044\u3001\u3068\u306F\u9650\u3089\u306A\u3044",
  "id" : 607571733684482048,
  "created_at" : "2015-06-07 15:36:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/6yZvHXdNLP",
      "expanded_url" : "http:\/\/blog.kentarok.org\/entry\/20090223\/1235397237",
      "display_url" : "blog.kentarok.org\/entry\/20090223\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607563675457576960",
  "text" : "\u7D20\u6575\u30B3\u30FC\u30C9\u3060\u2026\u2026\nhttp:\/\/t.co\/6yZvHXdNLP",
  "id" : 607563675457576960,
  "created_at" : "2015-06-07 15:04:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607465454064377856",
  "geo" : { },
  "id_str" : "607465683916439552",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u305D\u308C\u306F\u904B\u304C\u60AA\u3044\u3067\u3059\u306D\u2026\u50D5\u3082\u521D\u898B\u3067\u30B7\u30E3\u30C3\u30BF\u30FC\u9589\u307E\u3063\u3066\u305F\u3089\u540C\u3058\u9053\u3092\u8FBF\u3063\u3066\u3044\u305F\u3053\u3068\u3067\u3057\u3087\u3046",
  "id" : 607465683916439552,
  "in_reply_to_status_id" : 607465454064377856,
  "created_at" : "2015-06-07 08:34:39 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607465281741389824",
  "text" : "\u7A4D\u6975\u7684\u306B\u512A\u79C0\u306A\u306E\u3067\u3063\u3066\u81EA\u5206\u3067\u4ED8\u3051\u3066\u3044\u3051",
  "id" : 607465281741389824,
  "created_at" : "2015-06-07 08:33:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607464964022890497",
  "geo" : { },
  "id_str" : "607465226582159361",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u30D3\u30EB\u307E\u3067\u305F\u3069\u308A\u7740\u3051\u308C\u3070\u6642\u9593\u306E\u554F\u984C\u3067\u306F\u306A\u3044\u304B\u3068\uFF08\u50D5\u306F\u512A\u79C0\u306A\u306E\u3067\u521D\u898B\u3067\u3082\u8FF7\u3044\u307E\u305B\u3093\u3067\u3057\u305F\uFF09",
  "id" : 607465226582159361,
  "in_reply_to_status_id" : 607464964022890497,
  "created_at" : "2015-06-07 08:32:50 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607464621893550081",
  "text" : "\u6EDE\u5728\u4E2D\u306B\u3059\u3054\u308D\u304F\u3084\u3068\u5BC4\u751F\u866B\u535A\u7269\u9928\u3068\u6771\u4E9E\u91CD\u5DE5\u30B7\u30E7\u30C3\u30D7\u306B\u884C\u304D\u305F\u3044\u3051\u3069\u307E\u3060\u3069\u308C\u306B\u3082\u884C\u3063\u3066\u306A\u3044",
  "id" : 607464621893550081,
  "created_at" : "2015-06-07 08:30:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    }, {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 8, 15 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607464031847247872",
  "geo" : { },
  "id_str" : "607464254912884736",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y @ark184 \u99C5\u8FD1\u3067\u3059\u3057\u3042\u30FC\u304F\u3055\u3093\u3067\u3082\u304D\u3063\u3068\u5206\u304B\u308B",
  "id" : 607464254912884736,
  "in_reply_to_status_id" : 607464031847247872,
  "created_at" : "2015-06-07 08:28:59 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607441373814362113",
  "text" : "\u300E\u50D5\u306F\u60AA\u304F\u306A\u3044\u300F",
  "id" : 607441373814362113,
  "created_at" : "2015-06-07 06:58:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607441337583951873",
  "text" : "\u587E\u306E\u30D0\u30A4\u30C8\u3001\u7D66\u6599\u306E\u767A\u751F\u3057\u306A\u3044\u96D1\u52D9\u3042\u3063\u305F\u3051\u3069\u3001\u7A7A\u6C17\u306E\u8AAD\u3081\u306A\u3044\u3048\u3093\u3069\u3055\u3093\u306F\u300C\u3048\uFF1F\u7D66\u6599\u767A\u751F\u3057\u306A\u3044\u3093\u3067\u3057\u3087\uFF1F\u300D\u3063\u3066\u8A00\u3063\u3066\u5168\u90E8\u30B9\u30EB\u30FC\u3057\u3066\u305F",
  "id" : 607441337583951873,
  "created_at" : "2015-06-07 06:57:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/IeyolhkLYe",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/tokyo.html",
      "display_url" : "sx9.jp\/weather\/tokyo.\u2026"
    }, {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/251awNHVE0",
      "expanded_url" : "http:\/\/blog.imoz.jp\/post\/7316967132\/ninetan-forecast",
      "display_url" : "blog.imoz.jp\/post\/731696713\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "607101838265966592",
  "geo" : { },
  "id_str" : "607105767313833985",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \n\u6771\u4EAC\u7248 http:\/\/t.co\/IeyolhkLYe\n\u307F\u304B\u305F http:\/\/t.co\/251awNHVE0",
  "id" : 607105767313833985,
  "in_reply_to_status_id" : 607101838265966592,
  "created_at" : "2015-06-06 08:44:29 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 11, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607089233254187009",
  "text" : "\u54B3\u6255\u3044\u3092\u751F\u696D\u3068\u3059\u308B\u4EBA #\u4EBA",
  "id" : 607089233254187009,
  "created_at" : "2015-06-06 07:38:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607047762283106306",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u3057\u306A\u3063\u3068\u6D3E\u306F\u5C11\u6570\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u3002\u3057\u306A\u3063\u3068\u6D3E\u3060\u3051\u3069\uFF01",
  "id" : 607047762283106306,
  "created_at" : "2015-06-06 04:53:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607046526850859008",
  "text" : "\u30B7\u30FC\u30B6\u30FC\u30B5\u30E9\u30C0\u3068\u304B\u3067\u3082\u3057\u306A\u3063\u3068\u3057\u3066\u308B\u306E\u3082\u597D\u304D\u3060",
  "id" : 607046526850859008,
  "created_at" : "2015-06-06 04:49:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607046247787069440",
  "text" : "\u3057\u306A\u3063\u3068\u6D3E\u3067\u3059\u304C",
  "id" : 607046247787069440,
  "created_at" : "2015-06-06 04:47:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607046216610779136",
  "text" : "\u30B9\u30FC\u30D7\u30D0\u30FC\u306B\u304A\u3051\u308B\u30AF\u30EB\u30C8\u30F3\u306E\u30AB\u30EA\u30C3\u3068\u6D3E\u3068\u3057\u306A\u3063\u3068\u6D3E\u306E\u5929\u5730\u958B\u95E2\u4EE5\u6765\u7D9A\u3044\u3066\u3044\u308B\u8AD6\u4E89\u306E\u8A71",
  "id" : 607046216610779136,
  "created_at" : "2015-06-06 04:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5341\u6708\u514E@\u6700\u9AD8\u306E\u590F",
      "screen_name" : "nekaya_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "271979824",
      "id" : 271979824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607045707401293824",
  "geo" : { },
  "id_str" : "607045788359720960",
  "in_reply_to_user_id" : 271979824,
  "text" : "@nekaya_bot \u30CA\u30A4\u30B9\u6771\u4EAC\uFF01",
  "id" : 607045788359720960,
  "in_reply_to_status_id" : 607045707401293824,
  "created_at" : "2015-06-06 04:46:08 +0000",
  "in_reply_to_screen_name" : "nekaya_bot",
  "in_reply_to_user_id_str" : "271979824",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607042046210117632",
  "text" : "\u7FA8\u307E\u3057\u3044\u305E",
  "id" : 607042046210117632,
  "created_at" : "2015-06-06 04:31:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607042023279882240",
  "text" : "\u306A\u3093\u3067\u50D5\u304C\u6771\u4EAC\u306B\u3044\u308B\u6642\u306B\u3075\u3060\u3093\u6771\u4EAC\u306B\u3044\u308B\u306F\u305A\u306E\u4EBA\u305F\u3061\u304C\u4EAC\u90FD\u306B\u3044\u308B\u3093\u3060\u2026",
  "id" : 607042023279882240,
  "created_at" : "2015-06-06 04:31:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607041893499740160",
  "text" : "\u61D0\u304B\u3057\u3044\u60E8\u72B6\u3060",
  "id" : 607041893499740160,
  "created_at" : "2015-06-06 04:30:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u306C\u3044\u30C8\u30A5\u30FC\u30F3",
      "screen_name" : "0_u0",
      "indices" : [ 3, 8 ],
      "id_str" : "62833617",
      "id" : 62833617
    }, {
      "name" : "togetter_jp",
      "screen_name" : "togetter_jp",
      "indices" : [ 69, 81 ],
      "id_str" : "72555864",
      "id" : 72555864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/TuhRXsRkq7",
      "expanded_url" : "http:\/\/togetter.com\/li\/597601",
      "display_url" : "togetter.com\/li\/597601"
    } ]
  },
  "geo" : { },
  "id_str" : "607041860603740160",
  "text" : "RT @0_u0: \u305D\u308C\u306Fhoge\u3060\u3088TL\/huga\u3067\u3057\u3087TL - Togetter\u307E\u3068\u3081 http:\/\/t.co\/TuhRXsRkq7 @togetter_jp\u3055\u3093\u304B\u3089",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "togetter_jp",
        "screen_name" : "togetter_jp",
        "indices" : [ 59, 71 ],
        "id_str" : "72555864",
        "id" : 72555864
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/TuhRXsRkq7",
        "expanded_url" : "http:\/\/togetter.com\/li\/597601",
        "display_url" : "togetter.com\/li\/597601"
      } ]
    },
    "geo" : { },
    "id_str" : "607041406821990400",
    "text" : "\u305D\u308C\u306Fhoge\u3060\u3088TL\/huga\u3067\u3057\u3087TL - Togetter\u307E\u3068\u3081 http:\/\/t.co\/TuhRXsRkq7 @togetter_jp\u3055\u3093\u304B\u3089",
    "id" : 607041406821990400,
    "created_at" : "2015-06-06 04:28:44 +0000",
    "user" : {
      "name" : "\u304D\u306C\u3044\u30C8\u30A5\u30FC\u30F3",
      "screen_name" : "0_u0",
      "protected" : false,
      "id_str" : "62833617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549969572116185088\/0QrRj46-_normal.png",
      "id" : 62833617,
      "verified" : false
    }
  },
  "id" : 607041860603740160,
  "created_at" : "2015-06-06 04:30:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607041093423661056",
  "text" : "\u3068\u306F\u3044\u3048\u9811\u5F35\u3063\u3066\u77E5\u8B58\u306A\u308A\u30B9\u30AD\u30EB\u306A\u308A\u3092\u8EAB\u306B\u3064\u3051\u305F\u4EBA\u9593\u304C\u305D\u308C\u3067\u304A\u91D1\u3092\u3082\u3089\u3048\u308B\u306E\u306F\u3001\u305D\u308C\u3089\u306E\u77E5\u8B58\u306A\u308A\u30B9\u30AD\u30EB\u306A\u308A\u304C\u3055\u3063\u3071\u308A\u308F\u304B\u3089\u306A\u3044\u5927\u591A\u6570\u306E\u5B58\u5728\u306E\u304A\u304B\u3052\u306A\u3093\u3060\u3088\u306A",
  "id" : 607041093423661056,
  "created_at" : "2015-06-06 04:27:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Zj8CybPtcp",
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/214725862631817217",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    }, {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/NUUN9XapwG",
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/214726030089400320",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607040431369551872",
  "text" : "\u30C0\u30D6\u30EB\u30AF\u30EA\u30C3\u30AF\u306E\u3084\u308A\u65B9\u3068\u304B\u6559\u3048\u3066\u3066\u307E\u3058\u304B\u2026\u3063\u3066\u601D\u3063\u305F\u3051\u3069\u3001\nhttp:\/\/t.co\/Zj8CybPtcp\nhttp:\/\/t.co\/NUUN9XapwG\n\n\u3053\u3046\u3044\u3046\u5C64\u3082\u3044\u308B\u3088\u3046\u3060\u3057\u4ED5\u65B9\u306A\u3044\u306E\u304B\u306A\u3063\u3066",
  "id" : 607040431369551872,
  "created_at" : "2015-06-06 04:24:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607039849170796544",
  "text" : "\u4ECA\u601D\u3048\u3070\u30AF\u30BD\u307F\u305F\u3044\u306A\u60C5\u5831\u306A\u3093\u305F\u3089\u57FA\u790E\u3060\u3063\u305F",
  "id" : 607039849170796544,
  "created_at" : "2015-06-06 04:22:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 33, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607039769961324544",
  "text" : "\u732B\u30C8\u30FC\u30B9\u30C8\u306E\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9\u3067\u30D1\u30EF\u30FC\u30DD\u30A4\u30F3\u30C8\u3092\u4F5C\u6210\u3057\u3066\u512A\u3092\u3082\u3089\u3063\u305F\u56DE #\u56DE",
  "id" : 607039769961324544,
  "created_at" : "2015-06-06 04:22:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B9\u30D7\u30E9\u30A4\u3068",
      "screen_name" : "sait3110c",
      "indices" : [ 3, 13 ],
      "id_str" : "60850602",
      "id" : 60850602
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sait3110c\/status\/606338318834352128\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BXTFV9dKSz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CGolfMSVAAEn4oC.png",
      "id_str" : "606338317639024641",
      "id" : 606338317639024641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CGolfMSVAAEn4oC.png",
      "sizes" : [ {
        "h" : 142,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 142,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 142,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 142,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 142,
        "resize" : "fit",
        "w" : 270
      } ],
      "display_url" : "pic.twitter.com\/BXTFV9dKSz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607039661777641472",
  "text" : "RT @sait3110c: \u3042\u308B\u7269\u7406\u6CD5\u5247\u304C\u3042\u308B\u3002\u300C\u732B\u306F\u5FC5\u305A\u8DB3\u304B\u3089\u5148\u306B\u7740\u5730\u3059\u308B\u300D\u300C\u30C8\u30FC\u30B9\u30C8\u306F\u5FC5\u305A\u30D0\u30BF\u30FC\u3092\u5857\u3063\u305F\u9762\u3092\u4E0B\u306B\u3057\u3066\u843D\u3061\u308B\u300D\u306A\u3089\u3070\u30D0\u30BF\u30FC\u3092\u5857\u3063\u305F\u9762\u3092\u4E0A\u306B\u3057\u305F\u307E\u307E\u3001\u732B\u306E\u80CC\u4E2D\u306B\u8CBC\u308A\u4ED8\u3051\u305F\u5834\u5408\u3001\u843D\u4E0B\u3059\u308B\u3053\u3068\u306A\u304F\u6C38\u4E45\u306B\u56DE\u8EE2\u3057\u7D9A\u3051\u308B\u3002\u3053\u308C\u3092\u300C\u732B-\u30C8\u30FC\u30B9\u30C8\u88C5\u7F6E\u300D\u3068\u547C\u3076\u3002 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sait3110c\/status\/606338318834352128\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BXTFV9dKSz",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CGolfMSVAAEn4oC.png",
        "id_str" : "606338317639024641",
        "id" : 606338317639024641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CGolfMSVAAEn4oC.png",
        "sizes" : [ {
          "h" : 142,
          "resize" : "fit",
          "w" : 270
        }, {
          "h" : 142,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 142,
          "resize" : "fit",
          "w" : 270
        }, {
          "h" : 142,
          "resize" : "fit",
          "w" : 270
        }, {
          "h" : 142,
          "resize" : "fit",
          "w" : 270
        } ],
        "display_url" : "pic.twitter.com\/BXTFV9dKSz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606338318834352128",
    "text" : "\u3042\u308B\u7269\u7406\u6CD5\u5247\u304C\u3042\u308B\u3002\u300C\u732B\u306F\u5FC5\u305A\u8DB3\u304B\u3089\u5148\u306B\u7740\u5730\u3059\u308B\u300D\u300C\u30C8\u30FC\u30B9\u30C8\u306F\u5FC5\u305A\u30D0\u30BF\u30FC\u3092\u5857\u3063\u305F\u9762\u3092\u4E0B\u306B\u3057\u3066\u843D\u3061\u308B\u300D\u306A\u3089\u3070\u30D0\u30BF\u30FC\u3092\u5857\u3063\u305F\u9762\u3092\u4E0A\u306B\u3057\u305F\u307E\u307E\u3001\u732B\u306E\u80CC\u4E2D\u306B\u8CBC\u308A\u4ED8\u3051\u305F\u5834\u5408\u3001\u843D\u4E0B\u3059\u308B\u3053\u3068\u306A\u304F\u6C38\u4E45\u306B\u56DE\u8EE2\u3057\u7D9A\u3051\u308B\u3002\u3053\u308C\u3092\u300C\u732B-\u30C8\u30FC\u30B9\u30C8\u88C5\u7F6E\u300D\u3068\u547C\u3076\u3002 http:\/\/t.co\/BXTFV9dKSz",
    "id" : 606338318834352128,
    "created_at" : "2015-06-04 05:54:55 +0000",
    "user" : {
      "name" : "\u30B9\u30D7\u30E9\u30A4\u3068",
      "screen_name" : "sait3110c",
      "protected" : false,
      "id_str" : "60850602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436782567128174592\/mhc_aHMc_normal.jpeg",
      "id" : 60850602,
      "verified" : false
    }
  },
  "id" : 607039661777641472,
  "created_at" : "2015-06-06 04:21:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607039457997393920",
  "text" : "\u5927\u62B5\u306E\u98DF\u3079\u7269\u306F\u304A\u8179\u3044\u3063\u3071\u3044\u306E\u6642\u306B\u98DF\u3079\u305F\u304F\u306A\u3044\u3093\u3060\u3088\u306A\u3001\u3060\u3063\u3066\u304A\u8179\u3044\u3063\u3071\u3044\u306A\u3093\u3060\u3082\u3093",
  "id" : 607039457997393920,
  "created_at" : "2015-06-06 04:20:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3053\u3093\u306A\u30AA\u30E0\u30E9\u30A4\u30B9\u306F\u5ACC\u3060",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607039292200742914",
  "text" : "\u304A\u8179\u3044\u3063\u3071\u3044\u306E\u6642\u306B\u51FA\u3066\u304F\u308B #\u3053\u3093\u306A\u30AA\u30E0\u30E9\u30A4\u30B9\u306F\u5ACC\u3060",
  "id" : 607039292200742914,
  "created_at" : "2015-06-06 04:20:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607038651369857024",
  "text" : "\u30B9\u30D7\u30E9\u30C8\u30A5\u30FC\u30F3\u3084\u308B\u305F\u3081\u306BWii U\u8CB7\u3046\u304B\u3089\u304A\u5C0F\u9063\u3044\u3092\u4E0B\u3055\u3044\u306A",
  "id" : 607038651369857024,
  "created_at" : "2015-06-06 04:17:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607031064087789568",
  "text" : "\u7BA1\u7406\u8077\u4EBA\u9593\u30DE\u30F3\u3001\u4F11\u65E5\u51FA\u52E4\u3067\u624B\u5F53\u3067\u306A\u3044\u306E\u3063\u3066\u306A\u3093\u3067\u306A\u3093\u3060\u3001\u7D20\u6734\u306B\u610F\u5473\u4E0D\u660E\u3060",
  "id" : 607031064087789568,
  "created_at" : "2015-06-06 03:47:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HamminG",
      "screen_name" : "E8lattice",
      "indices" : [ 0, 10 ],
      "id_str" : "1533610844",
      "id" : 1533610844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607028975051808768",
  "geo" : { },
  "id_str" : "607030484900519936",
  "in_reply_to_user_id" : 1533610844,
  "text" : "@E8lattice \u304A\u624B\u6570\u304A\u304B\u3051\u3057\u307E\u3059\u3002\u50D5\u306E\u5F15\u304D\u51FA\u3057\u306B\u3042\u308B\u30D3\u30B9\u30B1\u30C3\u30C8\u3067\u3082\u3069\u3046\u305E",
  "id" : 607030484900519936,
  "in_reply_to_status_id" : 607028975051808768,
  "created_at" : "2015-06-06 03:45:20 +0000",
  "in_reply_to_screen_name" : "E8lattice",
  "in_reply_to_user_id_str" : "1533610844",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607028185327239168",
  "text" : "\u5B8C\u5168\u306B\u30CF\u30DF\u30F3\u30B0\u3055\u3093\u95A2\u4FC2\u306A\u3044\u7528\u4E8B\u3060\u3063\u305F",
  "id" : 607028185327239168,
  "created_at" : "2015-06-06 03:36:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HamminG",
      "screen_name" : "E8lattice",
      "indices" : [ 0, 10 ],
      "id_str" : "1533610844",
      "id" : 1533610844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607027921492926464",
  "geo" : { },
  "id_str" : "607028122240745473",
  "in_reply_to_user_id" : 1533610844,
  "text" : "@E8lattice \u90E8\u5C4B\u306B\u3044\u308D\u3044\u308D\u7F6E\u3044\u3066\u3042\u308B\u30A2\u30EC\u6D3B\u8CC7\u6599\u3092\u8AB0\u304B\u90E8\u5C4B\u306E\u4EBA\u306B\u9001\u3063\u3066\u3082\u3089\u304A\u3046\u304B\u3068(\u3067\u3093\u308F\u306B\u3060\u308C\u3082\u3067\u3093\u308F)",
  "id" : 607028122240745473,
  "in_reply_to_status_id" : 607027921492926464,
  "created_at" : "2015-06-06 03:35:57 +0000",
  "in_reply_to_screen_name" : "E8lattice",
  "in_reply_to_user_id_str" : "1533610844",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HamminG",
      "screen_name" : "E8lattice",
      "indices" : [ 0, 10 ],
      "id_str" : "1533610844",
      "id" : 1533610844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607027151775227905",
  "geo" : { },
  "id_str" : "607027257060651008",
  "in_reply_to_user_id" : 1533610844,
  "text" : "@E8lattice \u3080\u3080\u3080\u3001\u306A\u308B\u307B\u3069",
  "id" : 607027257060651008,
  "in_reply_to_status_id" : 607027151775227905,
  "created_at" : "2015-06-06 03:32:30 +0000",
  "in_reply_to_screen_name" : "E8lattice",
  "in_reply_to_user_id_str" : "1533610844",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HamminG",
      "screen_name" : "E8lattice",
      "indices" : [ 0, 10 ],
      "id_str" : "1533610844",
      "id" : 1533610844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607026639600369664",
  "geo" : { },
  "id_str" : "607026937215598593",
  "in_reply_to_user_id" : 1533610844,
  "text" : "@E8lattice \u307E\u3041\u305D\u3046\u306A\u3093\u3067\u3059\u304C\u3002\u4F55\u6642\u3054\u308D\u307E\u3067\u3044\u307E\u3059\uFF1F",
  "id" : 607026937215598593,
  "in_reply_to_status_id" : 607026639600369664,
  "created_at" : "2015-06-06 03:31:14 +0000",
  "in_reply_to_screen_name" : "E8lattice",
  "in_reply_to_user_id_str" : "1533610844",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607026692876464130",
  "text" : "\u305D\u306E\u3042\u3068\u306E\u5468\u308A\u65B9\u3068\u304B\u3082\u6C7A\u3081\u306A\u3044\u3068\u3060\u304C",
  "id" : 607026692876464130,
  "created_at" : "2015-06-06 03:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607026578107727872",
  "text" : "\u53CD\u5C04\u795E\u7D4C\u30B2\u30FC\u30E0\u8981\u7D20\u3068\u3057\u3066J\u306B\u5BFE\u3057\u3066\u4EFB\u610F\u306E\u4EBA\u304CJ\u4EE5\u5916\u306E\u672D\u3092\u51FA\u305B\u308B\u3001\u3068\u304B",
  "id" : 607026578107727872,
  "created_at" : "2015-06-06 03:29:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HamminG",
      "screen_name" : "E8lattice",
      "indices" : [ 0, 10 ],
      "id_str" : "1533610844",
      "id" : 1533610844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607025672834314240",
  "geo" : { },
  "id_str" : "607025900505333760",
  "in_reply_to_user_id" : 1533610844,
  "text" : "@E8lattice \u7686\u3055\u3093\u306B\u3088\u308D\u3057\u304F\u304A\u4F1D\u3048\u304F\u3060\u3055\u3044",
  "id" : 607025900505333760,
  "in_reply_to_status_id" : 607025672834314240,
  "created_at" : "2015-06-06 03:27:07 +0000",
  "in_reply_to_screen_name" : "E8lattice",
  "in_reply_to_user_id_str" : "1533610844",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607025807756652544",
  "text" : "\u30A2\u30A4\u30E0\u30A2\u30C3\u30C8\u5317\u534A\u7403",
  "id" : 607025807756652544,
  "created_at" : "2015-06-06 03:26:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607025692379770880",
  "text" : "\u30A2\u30A4\u30E0\u30A2\u30C3\u30C8\u5E02\u30F6\u8C37",
  "id" : 607025692379770880,
  "created_at" : "2015-06-06 03:26:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3059\u306A\u308D",
      "screen_name" : "snowy_tree",
      "indices" : [ 0, 11 ],
      "id_str" : "159426366",
      "id" : 159426366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607024312634056704",
  "geo" : { },
  "id_str" : "607024927284207617",
  "in_reply_to_user_id" : 159426366,
  "text" : "@snowy_tree \u307E\u3042\u5468\u308A\u306E\u30EB\u30FC\u30EB\u306B\u3088\u3063\u3066\u3082\u69D8\u5B50\u304C\u5909\u308F\u308B\u306E\u3067\u5225\u306E\u6A5F\u4F1A\u306B\u5165\u308C\u308B\u3068\u307E\u305F\u5225\u306E\u5473\u306B\u306A\u308A\u307E\u3059\u3088",
  "id" : 607024927284207617,
  "in_reply_to_status_id" : 607024312634056704,
  "created_at" : "2015-06-06 03:23:15 +0000",
  "in_reply_to_screen_name" : "snowy_tree",
  "in_reply_to_user_id_str" : "159426366",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3059\u306A\u308D",
      "screen_name" : "snowy_tree",
      "indices" : [ 0, 11 ],
      "id_str" : "159426366",
      "id" : 159426366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607023808365490176",
  "geo" : { },
  "id_str" : "607024025718562816",
  "in_reply_to_user_id" : 159426366,
  "text" : "@snowy_tree \u82B1\u5CA1\u3055\u3093\u3001\u308F\u3093\u3069\u3055\u3093\u3042\u305F\u308A\u3067\u3084\u3063\u305F\u6642\u306B\u305D\u3093\u306A\u306E\u304C\u8FFD\u52A0\u3055\u308C\u3066\u307E\u3057\u305F\u306D",
  "id" : 607024025718562816,
  "in_reply_to_status_id" : 607023808365490176,
  "created_at" : "2015-06-06 03:19:40 +0000",
  "in_reply_to_screen_name" : "snowy_tree",
  "in_reply_to_user_id_str" : "159426366",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607023768968364032",
  "text" : "\u6B7B\u8005\u3068\u751F\u8005\u304C\u5165\u308C\u66FF\u308F\u308B\u3068\u304B\u306A",
  "id" : 607023768968364032,
  "created_at" : "2015-06-06 03:18:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607023436301365248",
  "text" : "\u3042\u3068\u306F\u4E00\u5B9A\u6761\u4EF6\u3067\u5FA9\u6D3B\u3068\u304B\u306A",
  "id" : 607023436301365248,
  "created_at" : "2015-06-06 03:17:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607023368638824449",
  "text" : "\u5F85\u3063\u3066\u3044\u308B\u4EBA\u9593\u304C\u9000\u5C48\u3057\u306A\u3044\u30EB\u30FC\u30EB\u3092\u8FFD\u52A0\u3057\u3066\u3044\u3051",
  "id" : 607023368638824449,
  "created_at" : "2015-06-06 03:17:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607021942248341505",
  "text" : "\u5B8C\u5168\u306B\u5225\u306E\u30B2\u30FC\u30E0\u306E\u30EB\u30FC\u30EB\u3092\u7121\u7406\u3084\u308A\u8F38\u5165\u3059\u308B\u306E\u3082\u697D\u3057\u3044",
  "id" : 607021942248341505,
  "created_at" : "2015-06-06 03:11:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607021259814113280",
  "text" : "\u500B\u4EBA\u7684\u306B\u306F\u6CE5\u8A66\u5408\u597D\u304D\u3060\u304B\u3089\u306A\u3041\u3001\u52A0\u901F\u30EB\u30FC\u30EB\u306F\u3042\u3063\u3066\u3082\u306A\u304F\u3066\u3082\u3063\u3066\u601D\u3046",
  "id" : 607021259814113280,
  "created_at" : "2015-06-06 03:08:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607020742903865344",
  "text" : "\u3044\u3084\u307E\u3041\u5E73\u6C11\u304C\u8FFD\u52A0\u3057\u3066\u3082\u826F\u3044\u3093\u3060\u3051\u3069",
  "id" : 607020742903865344,
  "created_at" : "2015-06-06 03:06:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607020462074261504",
  "text" : "\u5927\u8CA7\u6C11\u304C\u30EB\u30FC\u30EB\u3092\u8FFD\u52A0\u3057\u3066\u3082\u826F\u3044\u6C17\u304C\u3059\u308B\u304C\u3001\u30C6\u30F3\u30DD\u306F\u60AA\u3044\u304B\u3082\u306A\u3041",
  "id" : 607020462074261504,
  "created_at" : "2015-06-06 03:05:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607015711718928385",
  "geo" : { },
  "id_str" : "607015838529380352",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u3059\u3067\u306B\u30E1\u30BF\u30EB\u30FC\u30EB\u3082\u8FFD\u52A0\u3067\u304D\u308B\u306E\u3067",
  "id" : 607015838529380352,
  "in_reply_to_status_id" : 607015711718928385,
  "created_at" : "2015-06-06 02:47:08 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607015461348188160",
  "text" : "\u7A4D\u6975\u7684\u306B\u8A87\u308A\u306B\u601D\u3063\u3066\u3044\u3051",
  "id" : 607015461348188160,
  "created_at" : "2015-06-06 02:45:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607015380704296960",
  "text" : "\u30EB\u30FC\u30EB\u8FFD\u52A0hogehoge\u306E\u6D41\u884C\u3092\u8A87\u308A\u306B\u601D\u3046",
  "id" : 607015380704296960,
  "created_at" : "2015-06-06 02:45:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607014804180443136",
  "text" : "\u5B8C\u5168\u306B\u3046\u30FC\u3093\u3001\u3046\u30FC\u3093\u3063\u3066\u8A00\u3063\u3066\u308B\u2026\u2026",
  "id" : 607014804180443136,
  "created_at" : "2015-06-06 02:43:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607014749700681728",
  "text" : "\u3046\u30FC\u3093\u3001\u3046\u30FC\u3093\u3063\u3066\u8A00\u3063\u3066\u308B",
  "id" : 607014749700681728,
  "created_at" : "2015-06-06 02:42:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606977229810057216",
  "text" : "\u30C7\u30A3\u30E2\u30C1\u30D9\u30A4\u30C6\u30C3\u30C9\u30A2\u30EC\u6D3B\u30A4\u30D9\u30F3\u30C8",
  "id" : 606977229810057216,
  "created_at" : "2015-06-06 00:13:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606973614324187136",
  "text" : "\u6BCD\u89AA\u3068\u59B9\u306E\u6E96\u540C\u578B\u3068\u7236\u89AA\u3068\u5F1F\u306E\u6E96\u540C\u578B\u3042\u308B\u3051\u3069\u50D5\u306F\u7279\u7570\u70B9\u3081\u3044\u3066\u4E00\u4EBA\u3060\u3001\u6027\u683C\u3068\u304B\u597D\u307F\u3068\u304B",
  "id" : 606973614324187136,
  "created_at" : "2015-06-05 23:59:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606972874490920960",
  "text" : "\u9006\u4E8C\u516B\u305D\u3070\u3063\u3066\u5024\u6BB5\u304C1\/16\u6587\u3060\u3063\u305F\u3068\u304B\u305D\u3046\u3044\u3046\uFF1F",
  "id" : 606972874490920960,
  "created_at" : "2015-06-05 23:56:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606972129691631617",
  "text" : "\u3044\u304F\u3089\u8EAB\u5185\u3060\u304B\u3089\u3063\u3066\u9762\u767D\u304F\u306A\u3044\u30AF\u30BD\u30EA\u30D7\u306F\u9762\u767D\u304F\u306A\u3044",
  "id" : 606972129691631617,
  "created_at" : "2015-06-05 23:53:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606971247159681025",
  "geo" : { },
  "id_str" : "606971423484018688",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u4E00\u822C\u306B\u3001\u6D17\u6FEF\u304C\u59CB\u307E\u3063\u3066\u7D42\u308F\u308B\u307E\u3067\u306B\u4E00\u5B9A\u306E\u6642\u9593\u304C\u639B\u304B\u308B\u3093\u3067\u3059\u3088",
  "id" : 606971423484018688,
  "in_reply_to_status_id" : 606971247159681025,
  "created_at" : "2015-06-05 23:50:38 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/BxVzf6UGvw",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/606970473751052288",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "606970732426321920",
  "geo" : { },
  "id_str" : "606971102032560128",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u3082\u3046\u3044\u3061\u3069\u3001\u3088\u304F\u3088\u307F\u307E\u3057\u3087\u3046 https:\/\/t.co\/BxVzf6UGvw",
  "id" : 606971102032560128,
  "in_reply_to_status_id" : 606970732426321920,
  "created_at" : "2015-06-05 23:49:22 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 37, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606970473751052288",
  "text" : "\u79C1\u304C\u30B7\u30E3\u30EF\u30FC\u3092\u6D74\u3073\u3066\u3044\u308B\u9593\u306B\u3053\u308C\u304B\u3089\u7740\u308B\u4E88\u5B9A\u306E\u4E0B\u7740\u3068\u808C\u7740\u3092\u6D17\u6FEF\u3055\u308C\u3066\u305F\u56DE #\u56DE",
  "id" : 606970473751052288,
  "created_at" : "2015-06-05 23:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606882299829841920",
  "text" : "\u3064\u3080\u304E\u3061\u3083\u3093\u898B\u305F\u76EE\u3060\u3051\u3060\u3068\u30DE\u30B8\u3067\u30E2\u30F3\u30B9\u30BF\u30FC\u3060\u304B\u3089\u306A\u2026\u2026",
  "id" : 606882299829841920,
  "created_at" : "2015-06-05 17:56:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606882229738827776",
  "text" : "\u30D2\u30AB\u30EA\u30A8\u306Emonster\u5C55\u3092\u3061\u3089\u3063\u3068\u898B\u305F\u3093\u3060\u3051\u3069\u3001\u30A2\u30E1\u30EA\u30AB\u306E\u30E2\u30F3\u30B9\u30BF\u30FC\u5206\u985E\u307F\u305F\u3044\u306A\u7D75\u304C\u3042\u3063\u305F\u3093\u3060\u3051\u3069\n\u3048\u3093\u3069\u3055\u3093\u300C\u3042\u30FC\u3001\u30B7\u30C9\u30CB\u30A2\u306E\u30D2\u30ED\u30A4\u30F3\u306E\u4E00\u4EBA\u304C\u3053\u3093\u306A\u611F\u3058\u3060\u308F\u300D\n\u53CB\u4EBA\u300C\u3078\u3047\u30FC\u3001\u30D2\u30ED\u30A4\u30F3\u2026\u30D2\u30ED\u30A4\u30F3\uFF1F\uFF01\u300D\n\u3063\u3066\u826F\u3044\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3057\u3066\u305F",
  "id" : 606882229738827776,
  "created_at" : "2015-06-05 17:56:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606821899016925184",
  "geo" : { },
  "id_str" : "606822104554573824",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u306A\u3093\u304B\u4F53\u8ABF\u60AA\u304F\u3066\u5BDD\u305F\u306E\u3067\u2026\u305F\u307E\u306B\u3042\u308A\u307E\u305B\u3093\u304B",
  "id" : 606822104554573824,
  "in_reply_to_status_id" : 606821899016925184,
  "created_at" : "2015-06-05 13:57:18 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3063\u3057\u3043\u0E05",
      "screen_name" : "aitaioddstr",
      "indices" : [ 0, 12 ],
      "id_str" : "1523835464",
      "id" : 1523835464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606821711028224000",
  "geo" : { },
  "id_str" : "606821842842566656",
  "in_reply_to_user_id" : 1523835464,
  "text" : "@aitaioddstr \u306F\u3044\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 606821842842566656,
  "in_reply_to_status_id" : 606821711028224000,
  "created_at" : "2015-06-05 13:56:16 +0000",
  "in_reply_to_screen_name" : "aitaioddstr",
  "in_reply_to_user_id_str" : "1523835464",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606821672688099330",
  "text" : "\u307F\u3087\u3093\u306A\u6642\u9593\u306B\u76EE\u304C\u899A\u3081\u3066\u3057\u307E\u3063\u305F\u2026",
  "id" : 606821672688099330,
  "created_at" : "2015-06-05 13:55:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606756262705926144",
  "geo" : { },
  "id_str" : "606756350878572544",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u85AC\u98F2\u3093\u3067\u5BDD\u308B",
  "id" : 606756350878572544,
  "in_reply_to_status_id" : 606756262705926144,
  "created_at" : "2015-06-05 09:36:01 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606754265583853568",
  "text" : "\u3042\u3042\uFF01\u3082\u3046\u982D\u75DB\u3044\uFF01\uFF01\uFF01\u3082\u3046\uFF01\uFF01\uFF01",
  "id" : 606754265583853568,
  "created_at" : "2015-06-05 09:27:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606719537153638400",
  "text" : "\u80A9\u3053\u308A\u982D\u75DB\u304C\u3046\u3049\u30A9\u30F3",
  "id" : 606719537153638400,
  "created_at" : "2015-06-05 07:09:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/606705988939317248\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/zVIknFyeNN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGtz4UaUcAAv5b2.jpg",
      "id_str" : "606705986200432640",
      "id" : 606705986200432640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGtz4UaUcAAv5b2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/zVIknFyeNN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606705988939317248",
  "text" : "\u3053\u308C\u624B\u6570\u6599\u8CB0\u3048\u308B\u30D1\u30BF\u30FC\u30F3\u3082\u3042\u308B\u308F\u3051\u3060\u3088\u306D http:\/\/t.co\/zVIknFyeNN",
  "id" : 606705988939317248,
  "created_at" : "2015-06-05 06:15:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606666471029108736",
  "text" : "\u751F\u304D\u3065\u3089\u3044\u793E\u4F1A\u3092\u4F5C\u3063\u3066\u3044\u308B\u306E\u306F\u304A\u524D\u81EA\u8EAB\u3060",
  "id" : 606666471029108736,
  "created_at" : "2015-06-05 03:38:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606666415190376448",
  "text" : "\u96A3\u306E\u5927\u5B66\u751F\u304CTwitter\u306E\u8A71\u3067\u8AB0\u305D\u308C\u306F\u30DF\u30E5\u30FC\u30C8\u3057\u3066\u308B\u3068\u304B\u3063\u3066\u558B\u3063\u3066\u3066\u306A\u3089\u3082\u3046\u30D5\u30A9\u30ED\u30FC\u5207\u308C\u3088\u3063\u3066\u601D\u3063\u305F",
  "id" : 606666415190376448,
  "created_at" : "2015-06-05 03:38:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606645325621653505",
  "text" : "\u5148\u65E5\u6765\u305F\u6642\u306F\u9580\u524D\u6255\u3044\u3057\u305F\u3093\u3060\u3051\u3069\u3082\u59B9\u306B\u8CB7\u3063\u3066\u304A\u3044\u3066\u6B32\u3057\u3044\u3068\u983C\u307E\u308C\u305F\u306E\u3067\u30B8\u30E7\u30A2\u3092\u8CB7\u3063\u305F",
  "id" : 606645325621653505,
  "created_at" : "2015-06-05 02:14:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606644623860101120",
  "text" : "\u30E4\u30AF\u30EB\u30C8\u30EC\u30C7\u30A3\u304A\u59C9\u3055\u3093\u5973\u5B50\u3068\u30CF\u30FC\u30C8\u30A6\u30A9\u30FC\u30DF\u30F3\u30B0\u306A\u96D1\u8AC7\u3092\u3057\u305F",
  "id" : 606644623860101120,
  "created_at" : "2015-06-05 02:12:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606644183491674112",
  "text" : "\u3082\u3061\u308D\u3093\u305D\u3046\u3067\u306A\u3044\u7537\u6027\u306E\u5B58\u5728\u306F\u8A8D\u77E5\u3057\u3066\u304A\u308A\u307E\u3059\u306F\u3044",
  "id" : 606644183491674112,
  "created_at" : "2015-06-05 02:10:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606644106668867584",
  "text" : "\u9AD8\u6821\u306E\u6559\u5E2B\u304C\u6388\u696D\u4E2D\u306E\u96D1\u8AC7\u3067\u300C\u5973\u5B50\u306E\u7686\u3055\u3093\u306F\u3001\u8ECA\u3068\u304B\u30D0\u30A4\u30AF\u304C\u8DA3\u5473\u306E\u7537\u306E\u4EBA\u3068\u7D50\u5A5A\u3057\u306A\u3044\u307B\u3046\u304C\u826F\u3044\u3067\u3059\u3088\u3001\u305D\u3046\u3044\u3046\u4EBA\u305F\u3061\u306F\u8ECA\u3001\u30D0\u30A4\u30AF\u304C\u4E00\u756A\u3067\u5965\u3055\u3093\u306F\u4E8C\u756A\u3067\u3059\u304B\u3089\u300D\u3068\u304B\u8A00\u3063\u3066\u3066\u3001\u904E\u5EA6\u306A\u4E00\u822C\u5316\u306E\u7BC0\u306F\u5426\u3081\u306A\u3044\u3051\u3069\u5370\u8C61\u7684\u3060\u3063\u305F",
  "id" : 606644106668867584,
  "created_at" : "2015-06-05 02:10:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606635395162345472",
  "text" : "\u3063\u3066\u6570\u5E74\u524D\u304B\u3089\u30B9\u30DD\u30FC\u30C4\u5927\u597D\u304D\u4EBA\u9593\u306E\u5F1F\u306B\u8A00\u3063\u3066\u717D\u3063\u3066\u904A\u3093\u3067\u308B\u3093\u3060\u3051\u3069\u30DE\u30B8\u3067\u8A00\u3063\u3066\u308B\u4EBA\u304C\u3044\u308B\u306E\u304B",
  "id" : 606635395162345472,
  "created_at" : "2015-06-05 01:35:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606635277314957312",
  "text" : "\u4EFB\u610F\u306E\u30B9\u30DD\u30FC\u30C4\u306F\u602A\u6211\u3057\u3046\u308B\u304B\u3089\u30AD\u30B1\u30F3\u3060\uFF01\uFF01\uFF01\u307F\u3093\u306A\u304A\u5BB6\u3067\u30A8\u30A2\u30FC\u30AD\u30E3\u30C3\u30D7\u3092\u6F70\u3059\u6D3B\u52D5\u306B\u52E4\u3057\u3082\u3046\uFF01\uFF01\uFF01",
  "id" : 606635277314957312,
  "created_at" : "2015-06-05 01:34:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606449564829126656",
  "text" : "KP\u300C\u3053\u3053\u306F\u5927\u5E83\u9593\u3067\u3001\u3053\u3053\u306B\u306F\u3001\u3053\u308C\u3053\u308C\u3053\u3046\u3044\u3046\u4EBA\u305F\u3061\u304C\u3044\u307E\u3059\u300D\n\u307E\u308C\u3044\u3093\u300C\u805E\u304D\u8033\u3044\u3089\u306A\u3044\u7BC4\u56F2\u3067\u3069\u3093\u306A\u8A71\u3057\u3066\u308B\u3068\u304B\u5206\u304B\u308A\u307E\u305B\u3093\u304B\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u30C1\u30E7\u30B3\u306E\u8A71\u3057\u3066\u308B\u3063\u307D\u3044\uFF01\u3068\u304B\u300D",
  "id" : 606449564829126656,
  "created_at" : "2015-06-04 13:16:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606448479288713216",
  "text" : "\u4ECA\u307E\u3067\u63CF\u3044\u305F\u4E2D\u3067\u4E00\u756A\u3044\u3044\u811A\u3060\u306E\u8170\u3060\u306E\u6652\u305B\u3063\u3066\u306E\u3001\u30E2\u30A2\u30A4\u50CF\u306E\u524D\u3067\u30CF\u30F3\u30C9\u30A2\u30C3\u30AF\u30B9\u63B2\u3052\u3066\u559C\u3093\u3067\u3044\u308B\u5973\u306E\u4EBA\u304F\u3089\u3044\u3057\u304B\u63CF\u3044\u305F\u3053\u3068\u7121\u3044\u304B\u3089\u5FC5\u7136\u7684\u306B\u305D\u308C\u306B\u306A\u3063\u3066\u30B3\u30EC\u30B8\u30E3\u30CA\u30A4\u611F",
  "id" : 606448479288713216,
  "created_at" : "2015-06-04 13:12:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606448103793647616",
  "text" : "\u305D\u306E\u70B9\u30C9\u30F3\u30AD\u30FC\u30B3\u30F3\u30B064\u3063\u3066\u3059\u3054\u3044\u3088\u306A\uFF08\uFF1F\uFF09",
  "id" : 606448103793647616,
  "created_at" : "2015-06-04 13:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606447864860901377",
  "text" : "\u3082\u3061\u308D\u3093\u4E00\u4EBA\u3067\u3082\u697D\u3057\u3081\u308B\u3088\u3046\u306B\u4F01\u696D\u306F\u52AA\u529B\u3057\u3066\u3044\u308B\u3068\u601D\u3046\u3051\u3069\u3069\u3046\u3057\u3066\u3082\u306A",
  "id" : 606447864860901377,
  "created_at" : "2015-06-04 13:10:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606447773538353152",
  "text" : "\u6700\u8FD1\u306E\u30B2\u30FC\u30E0\u3001\u5354\u529B\u30D7\u30EC\u30A4\u3068\u304B\u76DB\u3093\u306A\u305B\u3044\u3067\u3001\u9006\u306B\u767A\u58F2\u304B\u3089\u4E00\u5B9A\u671F\u9593\u7D4C\u3063\u305F\u5F8C\u306B\u59CB\u3081\u308B\u3068\u3001\u305D\u3082\u305D\u3082\u30D6\u30FC\u30E0\u304C\u7D42\u308F\u3063\u3066\u307F\u3093\u306A\u98FD\u304D\u3066\u305F\u308A\u3001\u30EC\u30D9\u30EB\u304C\u9055\u3044\u3059\u304E\u3066\u4E00\u7DD2\u306B\u904A\u3073\u96E3\u304B\u3063\u305F\u308A\u3059\u308B\u3093\u3060\u3088\u306A\u3041",
  "id" : 606447773538353152,
  "created_at" : "2015-06-04 13:09:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606447481539293185",
  "text" : "\u534A\u5E74\u304B\u3089\u4E00\u5E74\u5F8C\u3060\u3063\u305F\u3089\u30B9\u30D7\u30E9\u30C8\u30A5\u30FC\u30F3\u3068\u304B\u51FA\u6765\u308B\u304B\u306A\u30FC\u3063\u3066\u601D\u3063\u305F\u3051\u3069\u3001\u305D\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u59CB\u3081\u308B\u306E\u3082\u306A\u30FC\u3063\u3066",
  "id" : 606447481539293185,
  "created_at" : "2015-06-04 13:08:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606435546605314051",
  "geo" : { },
  "id_str" : "606435682077179906",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u308F\u304B\u308A\u3084\u3059\u3044\u5358\u8A9E\u304C\u51FA\u3066\u6765\u306A\u304B\u3063\u305F\u3051\u3069\u304A\u3063\u3057\u3083\u308B\u3068\u304A\u308A\u3067\u3059",
  "id" : 606435682077179906,
  "in_reply_to_status_id" : 606435546605314051,
  "created_at" : "2015-06-04 12:21:48 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606434377728327681",
  "geo" : { },
  "id_str" : "606435473184014337",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u89AA\u306E\u907A\u7523\u3068\u304B\u3067\u82B8\u8853\u3001\u6559\u990A\u306B\u5168\u632F\u308A\u3057\u3066\u308B\u6D6E\u4E16\u96E2\u308C\u4EBA\u9593\u3001\u304F\u3089\u3044\u306E\u611F\u3058\u3067\u3059",
  "id" : 606435473184014337,
  "in_reply_to_status_id" : 606434377728327681,
  "created_at" : "2015-06-04 12:20:58 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606430137266020352",
  "text" : "\u30B7\u30E7\u30B3\u30E9\u30DF\u30F3\u30C8",
  "id" : 606430137266020352,
  "created_at" : "2015-06-04 11:59:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606430117200429056",
  "text" : "\u30C7\u30A3\u30EC\u30C3\u30BF\u30F3\u30C8\u3060\u304B\u3089\u30CF\u30FC\u30B2\u30F3\u30C0\u30C3\u30C4\u98DF\u3079\u308B",
  "id" : 606430117200429056,
  "created_at" : "2015-06-04 11:59:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606370108403908608",
  "text" : "\u306F\u3089\u3072\u308C\u307B\u308D\u306F\u308C\u301C",
  "id" : 606370108403908608,
  "created_at" : "2015-06-04 08:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606366384260390915",
  "geo" : { },
  "id_str" : "606369911338696705",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u306A\u3093\u304B\u30C7\u30A3\u30BA\u30CB\u30FC\u306E\u6642\u9593\u307F\u305F\u3044\u3067\u3059\u306D\uFF1F",
  "id" : 606369911338696705,
  "in_reply_to_status_id" : 606366384260390915,
  "created_at" : "2015-06-04 08:00:27 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606355214472507392",
  "text" : "\u3068\u306F\u3044\u30488\u8A71\u306F\u5168\u304F\u3082\u3063\u3066\u30E9\u30D6\u30B3\u30E1\u56DE\u3067\u6226\u95D8\u63CF\u5199\u5168\u7136\u7121\u304B\u3063\u305F\u306E\u3046",
  "id" : 606355214472507392,
  "created_at" : "2015-06-04 07:02:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606354998377738240",
  "text" : "\u65E5\u9803\u306E\u884C\u3044\u3063\u3066\u5927\u5207\u3088\u306D",
  "id" : 606354998377738240,
  "created_at" : "2015-06-04 07:01:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606354698925281280",
  "geo" : { },
  "id_str" : "606354791791501312",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3080\u3057\u308D\u6BCD\u89AA\u304C\u597D\u3093\u3067\u898B\u3066\u308B\u306E\u3067\u559C\u3076\u3088\u3046\u306A\u6C17\u304C\u3057\u307E\u3059",
  "id" : 606354791791501312,
  "in_reply_to_status_id" : 606354698925281280,
  "created_at" : "2015-06-04 07:00:22 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606353270265815040",
  "text" : "\u30E6\u30EC\u535A\u58EB\u3001\u8FEB\u771F\u306E\u6F14\u6280\u3081\u3063\u3061\u3087\u7B11\u3046",
  "id" : 606353270265815040,
  "created_at" : "2015-06-04 06:54:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606352357497012224",
  "geo" : { },
  "id_str" : "606353008230862849",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3061\u3087\u3063\u3068\u8ABF\u3079\u3066\u307F\u307E\u3057\u305F\u304C\u7121\u6599\u3060\u3057\u73FE\u74B0\u5883\uFF08\u3068\u3044\u3063\u3066\u3082\u5B9F\u5BB6\uFF09\u3067\u898B\u308C\u305D\u3046\u3067\u3059\u3002\u8A66\u3057\u3066\u307F\u307E\u3059\u3002",
  "id" : 606353008230862849,
  "in_reply_to_status_id" : 606352357497012224,
  "created_at" : "2015-06-04 06:53:17 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606352224416100352",
  "text" : "\u305D\u3057\u3066\u3086\u306F\u305F\u304B\u308F\u3044\u3044",
  "id" : 606352224416100352,
  "created_at" : "2015-06-04 06:50:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606352150009155584",
  "text" : "\u30B7\u30C9\u30CB\u30A2\u3001\u307E\u305F\u30D7\u30E9\u30E2\u5C4B\u3055\u3093\u51FA\u3066\u304D\u3066\u3054\u6E80\u60A6",
  "id" : 606352150009155584,
  "created_at" : "2015-06-04 06:49:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606351708906586112",
  "geo" : { },
  "id_str" : "606351893997223936",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3080\u3057\u308D\u3061\u3047\u308A\u3043\u3055\u3093\u3069\u3046\u3084\u3063\u3066\u307F\u3066\u308B\u3093\u3067\u3059\u304B\u2026\u30EC\u30F3\u30BF\u30EB\uFF1F\u30CD\u30C3\u30C8\uFF1F",
  "id" : 606351893997223936,
  "in_reply_to_status_id" : 606351708906586112,
  "created_at" : "2015-06-04 06:48:51 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606348515661508608",
  "text" : "\u3082\u3068\u3082\u3068\u7D50\u69CB\u30B5\u30B9\u30DA\u30F3\u30B9\u30B9\u30AD\u30FC\u3060\u304B\u3089\u306A",
  "id" : 606348515661508608,
  "created_at" : "2015-06-04 06:35:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606329139335806976",
  "geo" : { },
  "id_str" : "606348469809344512",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 CSI\u3082\u30DB\u30EF\u30A4\u30C8\u30AB\u30E9\u30FC\u3082\u305D\u3046\u3067\u3059\u304C\u30C6\u30F3\u30DD\u826F\u304F\u4E8C\u8EE2\u4E09\u8EE2\u3059\u308B\u611F\u3058\u306F\u7D50\u69CB\u6C17\u306B\u5165\u3063\u3066\u307E\u3059",
  "id" : 606348469809344512,
  "in_reply_to_status_id" : 606329139335806976,
  "created_at" : "2015-06-04 06:35:15 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606317829802102785",
  "text" : "\u30AD\u30E3\u30C3\u30B9\u30EB\u898B\u3066\u305F",
  "id" : 606317829802102785,
  "created_at" : "2015-06-04 04:33:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606307182712397824",
  "text" : "\u3069\u3058\u3083\u30FC\u3093",
  "id" : 606307182712397824,
  "created_at" : "2015-06-04 03:51:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    }, {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 13, 19 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606301584876642304",
  "geo" : { },
  "id_str" : "606302077971791874",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 @k08a_ \u305D\u308C\u3044\u3044\u306D\u3002\u305D\u3046\u3044\u3048\u3070\u53BB\u5E74\u98DF\u3079\u305D\u3073\u308C\u3066\u6C17\u306B\u306A\u3063\u3066\u308B\u3068\u3053\u308D\u3042\u308B\u304B\u3089\u660E\u65E513\uFF1A00\u306B\u30CF\u30C1\u516C\u524D\u3068\u304B\u3067\u4E00\u65E6\u96C6\u307E\u3089\u306A\u3044\u304B\u3002",
  "id" : 606302077971791874,
  "in_reply_to_status_id" : 606301584876642304,
  "created_at" : "2015-06-04 03:30:54 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606284390683926528",
  "text" : "PONPON NO PAIN",
  "id" : 606284390683926528,
  "created_at" : "2015-06-04 02:20:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606153012021624832",
  "text" : "\u3044\u306A\u308A",
  "id" : 606153012021624832,
  "created_at" : "2015-06-03 17:38:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606152994992713728",
  "text" : "\u306F\u3044\u304B\u3089\u3046\u3069\u3093\u305F\u3079\u305F\u3044\u306A\u308A\u307E\u3057\u305F",
  "id" : 606152994992713728,
  "created_at" : "2015-06-03 17:38:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606151556493250560",
  "text" : "\u4E45\u3005\u306B\u30DB\u30D3\u30FC\u30C8\u30FC\u30AF\u3057\u305F\u3089\u9045\u304F\u306A\u3063\u3066\u3057\u3082\u3046\u305F",
  "id" : 606151556493250560,
  "created_at" : "2015-06-03 17:32:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606037479183941632",
  "text" : "\u5F7C\u5973\u306E\u8A00\u8449\u3092\u9D5C\u5451\u307F\u306B\u3057\u305F\u79C1\u304C\u60AA\u3044",
  "id" : 606037479183941632,
  "created_at" : "2015-06-03 09:59:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606037416403558400",
  "text" : "\u89AA\u300C\u5E30\u308A\u306B\u30D1\u30F3\u8CB7\u3063\u3066\u304D\u3066\u3001hoge\u3068huga\u30011000\u5186\u3042\u3052\u308B\u304B\u3089\u4F59\u3063\u305F\u304A\u91D1\u3067\u597D\u304D\u306A\u306E\u8CB7\u3063\u3066\u3044\u3044\u3088\u300D\n\u304A\u5E97\u306E\u4EBA\u300Choge\u3068huga\u3067994\u5186\u306B\u306A\u308A\u307E\u3059\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u306A\u308B\u307B\u3069\u300D",
  "id" : 606037416403558400,
  "created_at" : "2015-06-03 09:59:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606036475201753088",
  "text" : "\u826F\u3044\u6539\u5909\u3060\u304C\u60AA\u3044\u614B\u5EA6\u3060",
  "id" : 606036475201753088,
  "created_at" : "2015-06-03 09:55:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606036399012200448",
  "text" : "RT @koizumi_fifty: \u300C\u305D\u3053\u3061\u3083\u3093\u3068\u8A3C\u660E\u3067\u304D\u308B\uFF1F\u300D\n\u300C\u4E16\u306E\u4E2D\u306B\u306F\u8A3C\u660E\u3067\u304D\u306A\u3044\u3082\u306E\u306E\u65B9\u304C\u591A\u3044\u3067\u3059\u304B\u3089\u306D\u30FC\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606036203767406592",
    "text" : "\u300C\u305D\u3053\u3061\u3083\u3093\u3068\u8A3C\u660E\u3067\u304D\u308B\uFF1F\u300D\n\u300C\u4E16\u306E\u4E2D\u306B\u306F\u8A3C\u660E\u3067\u304D\u306A\u3044\u3082\u306E\u306E\u65B9\u304C\u591A\u3044\u3067\u3059\u304B\u3089\u306D\u30FC\u300D",
    "id" : 606036203767406592,
    "created_at" : "2015-06-03 09:54:25 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 606036399012200448,
  "created_at" : "2015-06-03 09:55:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606035797783887872",
  "text" : "\u610F\u5473\u4E0D\u660E\u3060\u3068\u8B17\u3089\u308C\u3066\u3082\u300C\u4E16\u306E\u4E2D\u306B\u306F\u610F\u5473\u4E0D\u660E\u306A\u3082\u306E\u306E\u65B9\u304C\u591A\u3044\u304B\u3089\u306D\u30FC\u300D\u3063\u3066\u8A00\u3048\u3070\u826F\u3044",
  "id" : 606035797783887872,
  "created_at" : "2015-06-03 09:52:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606035433730904064",
  "text" : "hoge\u4EE5\u5916\u306Ehuga\u7684\u306A\u3084\u3064",
  "id" : 606035433730904064,
  "created_at" : "2015-06-03 09:51:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606035182047469568",
  "text" : "\u53E3\u8A9E\u3067\u306F\u4F7F\u3046\u3051\u3069",
  "id" : 606035182047469568,
  "created_at" : "2015-06-03 09:50:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606035125411807232",
  "text" : "\u30B0\u30B0\u30E9\u30D3\u30EA\u30C6\u30A3\u3063\u3066\u4E8B\u8C61\u306B\u5BFE\u3057\u3066\u306F\u8A00\u3046\u3051\u3069\u691C\u7D22\u80FD\u529B\u3068\u3057\u3066\u306F\u4F7F\u308F\u308C\u306A\u3044\u306E\u304B\u306A",
  "id" : 606035125411807232,
  "created_at" : "2015-06-03 09:50:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606034639845597184",
  "text" : "\u4EBA\u9593\u4EE5\u5916\u306E\u30B5\u30EB\u7684\u306A\u3084\u3064\u3067\u3082\u3067\u304D\u308B\u3067\u3057\u3087",
  "id" : 606034639845597184,
  "created_at" : "2015-06-03 09:48:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606034501047705600",
  "text" : "\u306F\u3050\u308B\u3093\u3055\u3059\u304C\u306E\u691C\u7D22\u529B\u3060",
  "id" : 606034501047705600,
  "created_at" : "2015-06-03 09:47:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606034342259757059",
  "text" : "\u4E8C\u756A\u76EE\u304B\u30FC\u3046\u3063\u304B\u308A",
  "id" : 606034342259757059,
  "created_at" : "2015-06-03 09:47:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u4F50\u85E4\u5065\u5BFF",
      "screen_name" : "x51",
      "indices" : [ 69, 73 ],
      "id_str" : "3800471",
      "id" : 3800471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/u3ACJXGWlM",
      "expanded_url" : "http:\/\/x51.org\/x\/06\/01\/0603.php",
      "display_url" : "x51.org\/x\/06\/01\/0603.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606034287322791936",
  "text" : "RT @haguruma20: \u6F14\u594F\u6642\u9593639\u5E74\u306E\u97F3\u697D\u3001\u7B2C\u4E8C\u306E\u30B3\u30FC\u30C9\u304C\u9CF4\u3089\u3055\u308C\u308B \u72EChttp:\/\/t.co\/u3ACJXGWlM via @x51\u3000\u3053\u308C\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u4F50\u85E4\u5065\u5BFF",
        "screen_name" : "x51",
        "indices" : [ 53, 57 ],
        "id_str" : "3800471",
        "id" : 3800471
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/u3ACJXGWlM",
        "expanded_url" : "http:\/\/x51.org\/x\/06\/01\/0603.php",
        "display_url" : "x51.org\/x\/06\/01\/0603.p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606033161105973248",
    "text" : "\u6F14\u594F\u6642\u9593639\u5E74\u306E\u97F3\u697D\u3001\u7B2C\u4E8C\u306E\u30B3\u30FC\u30C9\u304C\u9CF4\u3089\u3055\u308C\u308B \u72EChttp:\/\/t.co\/u3ACJXGWlM via @x51\u3000\u3053\u308C\u304B",
    "id" : 606033161105973248,
    "created_at" : "2015-06-03 09:42:19 +0000",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 606034287322791936,
  "created_at" : "2015-06-03 09:46:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606034195119370240",
  "text" : "\u6E29\u304B\u3044\u30D1\u30F3\u3001\u5E78\u305B\u3060",
  "id" : 606034195119370240,
  "created_at" : "2015-06-03 09:46:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606032903848337408",
  "text" : "\u30E8\u30FC\u30ED\u30C3\u30D1\u306E\u3069\u3053\u304B\u306E\u5BFA\u9662\u304B\u8056\u5802\u304B\u3067\u4ECA\u3082\u9CF4\u308A\u7D9A\u3051\u3066\u305F\u306F\u305A",
  "id" : 606032903848337408,
  "created_at" : "2015-06-03 09:41:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606032801570226176",
  "text" : "\u6F14\u594F\u6642\u9593\u304C\u4F55\u767E\u5E74\u3063\u3066\u697D\u66F2\u3042\u308B\u3088\u306D\u30012\uFF0C3\u5E74\u524D\u306B3\u56DE\u76EE\u306E\u97F3\u306E\u5909\u5316\u304C\u3042\u3063\u305F\u3068\u304B\u3063\u3066",
  "id" : 606032801570226176,
  "created_at" : "2015-06-03 09:40:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606032512360443904",
  "text" : "\u51FA\u6765\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u9375\u76E4\u30CF\u30FC\u30E2\u30CB\u30AB\u3092\u5F3E\u304D\u7D9A\u3051\u3088\u3046",
  "id" : 606032512360443904,
  "created_at" : "2015-06-03 09:39:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606032423046946816",
  "text" : "\u5438\u3044\u306A\u304C\u3089\u5410\u304F\u3084\u3064\u3001\u306A\u3093\u3068\u304B\u547C\u5438",
  "id" : 606032423046946816,
  "created_at" : "2015-06-03 09:39:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606031887052599296",
  "text" : "\u547C\u5438\u3057\u306A\u304C\u3089\u3001\u751F\u304D\u3066\u3044\u304F",
  "id" : 606031887052599296,
  "created_at" : "2015-06-03 09:37:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606031778847981570",
  "text" : "\u3042\u30FC\u3063\u3066\u8A00\u3044\u306A\u304C\u3089\u30C1\u30A7\u30B9\u30DC\u30AF\u30B7\u30F3\u30B0\u3057\u3088\u3046\u305C",
  "id" : 606031778847981570,
  "created_at" : "2015-06-03 09:36:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606031502984384512",
  "text" : "\u3042\u30FC\u3063\u3066\u3044\u3046\u306E\u3068\u547C\u5438\u3059\u308B\u306E\u3001\u3069\u3063\u3061\u304B\u3092\u63A7\u3048\u308B\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u3088\u3046",
  "id" : 606031502984384512,
  "created_at" : "2015-06-03 09:35:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606030887390605312",
  "text" : "\u96E8\u964D\u3063\u3066\u6DBC\u3057\u304F\u306A\u3063\u305F\u304B\u3068\u601D\u3063\u305F\u304C\u7D50\u5C40\u6691\u304F\u3066\u6C57\u304B\u3044\u3066\u308B",
  "id" : 606030887390605312,
  "created_at" : "2015-06-03 09:33:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606029145517101057",
  "geo" : { },
  "id_str" : "606029310269399040",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u307B\u3068\u3093\u3069\u77E5\u3089\u306A\u3044",
  "id" : 606029310269399040,
  "in_reply_to_status_id" : 606029145517101057,
  "created_at" : "2015-06-03 09:27:01 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606027380302299136",
  "text" : "\u30C6\u30EC\u30D3\u306E\u7279\u96C6\u300CMARS\u304C\u97D3\u56FD\u3067\u611F\u67D3\u62E1\u5927\u3057\u3066\u308B\u3088\uFF01\uFF01\u65E5\u672C\u306B\u3082\u6765\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3088\uFF01\uFF01\u300D\n\u30C6\u30EC\u30D3\u306E\u4EBA\u300C\u7121\u95C7\u306B\u6016\u304C\u308B\u306E\u3067\u306F\u306A\u304F\u3001\u3061\u3083\u3093\u3068\u6016\u304C\u3089\u306A\u3044\u3068\u3044\u3051\u307E\u305B\u3093\u306D\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3069\u306E\u53E3\u304C\u8A00\u3046\u3093\u3060\u2026\u2026\u300D",
  "id" : 606027380302299136,
  "created_at" : "2015-06-03 09:19:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605996045907066880",
  "text" : "\u30A4\u30B6\u30CA\u3082\u3086\u306F\u305F\u3082\u3064\u3080\u304E\u3082\u53EF\u611B\u3044\u3093\u3060\u3088\u306A",
  "id" : 605996045907066880,
  "created_at" : "2015-06-03 07:14:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605988574698180608",
  "text" : "\u306A\u3093\u3068\u306A\u304F\u53D6\u308A\u6B8B\u3055\u308C\u305F\u611F\u304C\u3042\u3063\u3066\u7269\u60B2\u3057\u3044",
  "id" : 605988574698180608,
  "created_at" : "2015-06-03 06:45:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605988296104099841",
  "text" : "\u4E2D\u91CE\u306E\u99C5\u524D\u30ED\u30FC\u30BF\u30EA\u30FC\u3001\u7DBA\u9E97\u306B\u306A\u3063\u3066\u308B\uFF1F",
  "id" : 605988296104099841,
  "created_at" : "2015-06-03 06:44:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605987565406060544",
  "text" : "\u7740\u5B9F\u306B\u5FCD\u3073\u5BC4\u308B KOSHI NO ITAMI",
  "id" : 605987565406060544,
  "created_at" : "2015-06-03 06:41:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605943994225291266",
  "text" : "\u4E00\u3064\u306E\u30DD\u30FC\u30BF\u30EB\u3067\u30AC\u30FC\u30C7\u30A3\u30A2\u30F3\u30E1\u30C0\u30EB\u76EE\u6307\u3057\u3066\u4FDD\u5B88\u3057\u3066\u3066\u3082\u6570\u65E5\u7D4C\u3064\u3068\u6575\u30A8\u30FC\u30B8\u30A7\u30F3\u30C8\u304C\u3084\u3063\u3066\u304D\u3066\u843D\u3068\u3057\u3066\u3044\u304F\u69CB\u56F3\u3001\u8CFD\u306E\u6CB3\u539F\u3060",
  "id" : 605943994225291266,
  "created_at" : "2015-06-03 03:48:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605940051457896448",
  "text" : "\u307E\u308C\u3044\u3093\u306F\u5E7C\u5C11\u306E\u9803\u306B\u906D\u3063\u305F\u4E8B\u6545\u3067\u7D0D\u5F97\u3057\u305F\u9854\u3092\u5931\u3063\u3066\u3057\u307E\u3063\u305F\u3063\u3066\u805E\u3044\u305F",
  "id" : 605940051457896448,
  "created_at" : "2015-06-03 03:32:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605938351909117957",
  "text" : "\u5B9F\u5BB6\u306B\u3044\u308B\u3060\u3051\u306A\u3089\u5B9F\u5BB6\u3067\u6388\u696D\u53D7\u3051\u3066\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3082\u3093\u306D\u3047",
  "id" : 605938351909117957,
  "created_at" : "2015-06-03 03:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605938237652135936",
  "text" : "\u3042\u3063\uFF01\u3055\u3089\u306B\u5B9F\u5BB6\u3067\u6388\u696D\u306F\u884C\u308F\u308C\u3066\u306A\u3044\u3067\u3059\uFF01",
  "id" : 605938237652135936,
  "created_at" : "2015-06-03 03:25:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605938137932529665",
  "text" : "\u30A8\u30B9\u30B1\u30FC\u30D7\u30A8\u30B9\u30B1\u30FC\u30D7",
  "id" : 605938137932529665,
  "created_at" : "2015-06-03 03:24:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605938120354230272",
  "text" : "\u3042\u3001\u50D5\u306F\u5B9F\u5BB6\u306B\u3044\u308B\u306E\u3067\u6388\u696D\u4E2D\u3067\u306F\u306A\u3044\u3067\u3059",
  "id" : 605938120354230272,
  "created_at" : "2015-06-03 03:24:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605937483021287425",
  "text" : "\u307E\u308C\u3044\u3093\u3055\u3093\u306E\u7D0D\u5F97\u51FA\u6765\u306A\u3044\u9854\u3068\u82B1\u5CA1\u3055\u3093\u306E\u771F\u9854\u306F\u672C\u5F53\u306B\u5C0A\u656C\u3059\u308B\u30EC\u30D9\u30EB\u3067\u5B8C\u6210\u3055\u308C\u3066\u3044\u308B",
  "id" : 605937483021287425,
  "created_at" : "2015-06-03 03:22:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605935684604456962",
  "text" : "\u78BA\u304B\u306B of the world",
  "id" : 605935684604456962,
  "created_at" : "2015-06-03 03:14:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u72ED\u7FA9\u306E\u6B63\u5B9A\u7B26\u53F7\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 3, 12 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605935617180958721",
  "text" : "RT @tenapyon: \uFF20\u5404\u4F4D\n\u3063\u3066\u304B\u3001\u6388\u696D\u4E2D\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u63A7\u3048\u306A\u3055\u3044\u3063\u3066\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605935583890841603",
    "text" : "\uFF20\u5404\u4F4D\n\u3063\u3066\u304B\u3001\u6388\u696D\u4E2D\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u63A7\u3048\u306A\u3055\u3044\u3063\u3066\u3002",
    "id" : 605935583890841603,
    "created_at" : "2015-06-03 03:14:35 +0000",
    "user" : {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "protected" : false,
      "id_str" : "2306283966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426289973814235136\/xzX5XH6__normal.jpeg",
      "id" : 2306283966,
      "verified" : false
    }
  },
  "id" : 605935617180958721,
  "created_at" : "2015-06-03 03:14:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605935551934398465",
  "text" : "\u306A\u3093\u304B\u81EA\u5206\u3067\u8A00\u3046\u306E\u3081\u3063\u3061\u3087\u3053\u305D\u3070\u3086\u3044\u306A\u3053\u308C",
  "id" : 605935551934398465,
  "created_at" : "2015-06-03 03:14:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605935480375418880",
  "text" : "@\u6388\u696D\u4E2D\u5404\u4F4D \u9762\u767D\u3044\u30C4\u30A4\u30FC\u30C8\u3092\u3057\u3066\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F",
  "id" : 605935480375418880,
  "created_at" : "2015-06-03 03:14:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605934923577360385",
  "text" : "\u307E\u308C\u3044\u3093\u306E\u201C\u7D0D\u5F97\u3067\u304D\u306A\u3044\u9854\u201C\u3092\u71C3\u6599\u306B\u3057\u3066\u8D70\u308B\u8ECA\u304C\u3042\u3063\u305F\u3089\u826F\u3044\u306E\u306B",
  "id" : 605934923577360385,
  "created_at" : "2015-06-03 03:11:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605934236982378496",
  "geo" : { },
  "id_str" : "605934619523825665",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u307E\u308C\u3044\u3093\u306E\u201C\u201D\u7D0D\u5F97\u3067\u304D\u306A\u3044\u9854\u201C\u201D",
  "id" : 605934619523825665,
  "in_reply_to_status_id" : 605934236982378496,
  "created_at" : "2015-06-03 03:10:45 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 30, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605934138793730048",
  "text" : "\u63D0\u4F9B\u3055\u308C\u308B\u30B5\u30FC\u30D3\u30B9\u3068\u63D0\u4F9B\u3055\u308C\u308B\u5074\u306E\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u304C\u4E00\u81F4\u3059\u308B\u56DE #\u56DE",
  "id" : 605934138793730048,
  "created_at" : "2015-06-03 03:08:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605933709338935296",
  "text" : "\u5E97\u54E1\u3055\u3093\u304C\u3044\u306A\u304F\u306A\u3063\u305F\u5F8C\u306B\u795E\u5999\u306A\u9854\u3067\u30DC\u30BD\u30C3\u3068\u300C\u304A\u524D\u2026\u2026A\u30BB\u30C3\u30C8\u3060\u3063\u305F\u306E\u2026\u2026\u3069\u3046\u3057\u3066\u96A0\u3057\u3066\u305F\u3093\u3060\u3088\u2026\u300D\u3068\u304B\u8A00\u3063\u3066\u3082\u9762\u767D\u3044",
  "id" : 605933709338935296,
  "created_at" : "2015-06-03 03:07:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605933445215223810",
  "text" : "\u5E97\u54E1\u3055\u3093\u300CA\u30BB\u30C3\u30C8\u306E\u304A\u5BA2\u69D8\u30FC\uFF1F\u300D\n\u53CB\u4EBA\u300C\u306F\u3044\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3048\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\u304A\u524DA\u30BB\u30C3\u30C8\u3060\u3063\u305F\u306E\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\u4EBA\u9593\u3058\u3083\u306A\u3044\u306E\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\u3048\uFF1F\uFF01\uFF1F\uFF01\uFF1F\u4F55\uFF1F\uFF01\u50D5A\u30BB\u30C3\u30C8\u3068\u3054\u98EF\u98DF\u3079\u306B\u6765\u3066\u305F\u306E\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\u300D",
  "id" : 605933445215223810,
  "created_at" : "2015-06-03 03:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605932599505059840",
  "text" : "\u5426\u5B9A\u3059\u308B\u3060\u3051\u3058\u3083\u306A\u304F\u3066\u3061\u3083\u3093\u3068\u4EE3\u6848\u3092\u8FF0\u3079\u3066\u3066\u5049\u3044\u3067\u3057\u3087",
  "id" : 605932599505059840,
  "created_at" : "2015-06-03 03:02:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605932444810801153",
  "text" : "\u304A\u5BA2\u69D8\u306F\u795E\u69D8\u3058\u3083\u306A\u3044\u3067\u3057\u3087(\u7D4C\u9A13\u4E0A\u306F\u4EBA\u9593\u3067\u3042\u308B\u3053\u3068\u304C\u591A\u3044)",
  "id" : 605932444810801153,
  "created_at" : "2015-06-03 03:02:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605931272356044801",
  "text" : "\u3053\u3082\u308A\u3093\u306E\u30A8\u30A2\u30B3\u30F3\u306E\u4E2D\u306E\u4EBA\u3001\u4F53\u8ABF\u60AA\u3044\u306E\u3067\u306F",
  "id" : 605931272356044801,
  "created_at" : "2015-06-03 02:57:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605930367015481344",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma dm\u3057\u307E\u3057\u305F",
  "id" : 605930367015481344,
  "created_at" : "2015-06-03 02:53:51 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605913635865493505",
  "text" : "\u6DBC\u3057\u3044\u306E\u306F\u826F\u3044\u304C\u6E7F\u6C17\u306A\u2026\u2026",
  "id" : 605913635865493505,
  "created_at" : "2015-06-03 01:47:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605913578076438530",
  "text" : "\u3042\u30FC\u3001\u96E8\u30FC\u3001\u3042\u30FC",
  "id" : 605913578076438530,
  "created_at" : "2015-06-03 01:47:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605596557988085760",
  "text" : "\u30CF\u30AB\u30C9\u30E9\u30F3\u3001\u30E2\u30F3\u30CF\u30F3\u3068\u304B\u306B\u51FA\u3066\u304D\u305D\u3046",
  "id" : 605596557988085760,
  "created_at" : "2015-06-02 04:47:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605596486957559808",
  "text" : "\u306C\u3046\u30FC\u6357\u3089\u3093",
  "id" : 605596486957559808,
  "created_at" : "2015-06-02 04:47:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605589542603620352",
  "text" : "\u8A95\u751F\u65E5\u3055\u3093\u3001\u3074\u3042\u306E\u3093\u304A\u3081\u3067\u3068\u3046",
  "id" : 605589542603620352,
  "created_at" : "2015-06-02 04:19:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3063\u3057\u3043\u0E05",
      "screen_name" : "aitaioddstr",
      "indices" : [ 0, 12 ],
      "id_str" : "1523835464",
      "id" : 1523835464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605589023277510656",
  "geo" : { },
  "id_str" : "605589166127054849",
  "in_reply_to_user_id" : 1523835464,
  "text" : "@aitaioddstr \u305D\u308A\u3083\u307E\u3041\u5727\u3092\u304B\u3051\u308C\u3070\u6691\u3044\u3067\u3059\u306D",
  "id" : 605589166127054849,
  "in_reply_to_status_id" : 605589023277510656,
  "created_at" : "2015-06-02 04:18:03 +0000",
  "in_reply_to_screen_name" : "aitaioddstr",
  "in_reply_to_user_id_str" : "1523835464",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605588925889912833",
  "text" : "\u3042\u3064\u3044\u3042\u3064\u3044",
  "id" : 605588925889912833,
  "created_at" : "2015-06-02 04:17:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605579975085821952",
  "text" : "\u5B9F\u5BB6\u306A\u306E\u306B\u306A\u3093\u3060\u3053\u306E\u30E9\u30A4\u30F3\u30E9\u30C3\u30D7",
  "id" : 605579975085821952,
  "created_at" : "2015-06-02 03:41:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605579941422374912",
  "text" : "\u304A\u3072\u308B\u3054\u306F\u3093\u306B\u751F\u30C1\u30E7\u30B3\u3068\u8535\u751F\u3068\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC",
  "id" : 605579941422374912,
  "created_at" : "2015-06-02 03:41:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605537480792633344",
  "text" : "\u306F\u30FC\u3082\u306B\u30FC",
  "id" : 605537480792633344,
  "created_at" : "2015-06-02 00:52:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605382900058603520",
  "text" : "\u4ECA\u56DE\u306E\u3046\u3054\u30AF\u30C8\u30A5\u3001\u3081\u3063\u3061\u3087\u3081\u3063\u3061\u3087\u52D5\u304F\u306A\u3001\u3053\u308A\u3083\u6642\u9593\u304B\u304B\u308A\u307E\u3059\u308F",
  "id" : 605382900058603520,
  "created_at" : "2015-06-01 14:38:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605380914550554624",
  "text" : "\u4EBA\u72FC\u5927\u5BCC\u8C6A\u3001\u3082\u3046\u3061\u3087\u3063\u3068\u8ABF\u6574\u3059\u308C\u3070\u3082\u3046\u3061\u3087\u3063\u3068\u307E\u3068\u3082\u306A\u9762\u767D\u3044\u30B2\u30FC\u30E0\u306B\u306A\u308B\u3063\u3066\u78BA\u4FE1\u304C\u3042\u308B\u3093\u3060\u3051\u3069\u3001\u73FE\u72B6\u304C\u30AF\u30BD\u30B2\u30FC\u904E\u304E\u3066\u30C6\u30B9\u30C8\u30D7\u30EC\u30A4\u306B\u7CBE\u795E\u304C\u3064\u3044\u3066\u3044\u304B\u306A\u3044",
  "id" : 605380914550554624,
  "created_at" : "2015-06-01 14:30:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sm26393929",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/C69L5AJNoX",
      "expanded_url" : "http:\/\/nico.ms\/sm26393929",
      "display_url" : "nico.ms\/sm26393929"
    } ]
  },
  "geo" : { },
  "id_str" : "605379496175267840",
  "text" : "\u3010CoC\u30EA\u30D7\u30EC\u30A4\u3011\u6CBC\u7537\u300A\u30B9\u30EF\u30F3\u30D7\u30DE\u30F3\u300B\u306F\u8AB0\u3060\uFF1F \u7B2C2\u8A71\u3010\u3046\u3054\u30AF\u30C8\u30A5\u30EB\u30D5\u3011 (16:01) http:\/\/t.co\/C69L5AJNoX #sm26393929 \u6765\u3066\u305F\uFF01\uFF01\uFF01\uFF01",
  "id" : 605379496175267840,
  "created_at" : "2015-06-01 14:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605378635944628226",
  "text" : "s\/\u91E3\/\u540A",
  "id" : 605378635944628226,
  "created_at" : "2015-06-01 14:21:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605378512032280576",
  "text" : "\u4EBA\u72FC\u5927\u5BCC\u8C6A\u30017\u6E21\u3057\u3067JK\u6E21\u3055\u308C\u3066\u76F4\u5F8C\u306B\u91E3\u3089\u308C\u305F\u306E\u3001\u672C\u5F53\u306B\u7406\u4E0D\u5C3D\u3060\u3063\u305F",
  "id" : 605378512032280576,
  "created_at" : "2015-06-01 14:20:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605378139770908673",
  "geo" : { },
  "id_str" : "605378314883215361",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 Skype\u304F\u3089\u3044\u3058\u3083\u306A\u3044\u3068\u3081\u3063\u3061\u3083\u6642\u9593\u304B\u304B\u308A\u305D\u3046\u3067\u3059\u306D",
  "id" : 605378314883215361,
  "in_reply_to_status_id" : 605378139770908673,
  "created_at" : "2015-06-01 14:20:12 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605373939745890304",
  "geo" : { },
  "id_str" : "605374706947096576",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u3046\u3093\u3001\u3088\u304F\u3067\u304D\u3066\u3044\u308B\u3088\u306D",
  "id" : 605374706947096576,
  "in_reply_to_status_id" : 605373939745890304,
  "created_at" : "2015-06-01 14:05:52 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605370980064706560",
  "text" : "\u30B9\u30D1\u30E2\u30F3\u6559\u3001\u30CD\u30BF\u5B97\u6559\u3068\u3070\u304B\u308A\u601D\u3063\u3066\u305F\u304CID\u8AD6\u3068\u9032\u5316\u8AD6\u306E\u8AD6\u4E89\u306E\u6D41\u308C\u304B\u3089\u51FA\u3066\u304D\u3066\u3093\u306E\u304B\u3088\u30A6\u30B1\u308B",
  "id" : 605370980064706560,
  "created_at" : "2015-06-01 13:51:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605370788632530944",
  "text" : "\u5929\u56FD\u306B\u306F\u30B9\u30C8\u30EA\u30C3\u30D1\u30FC\u5DE5\u5834\u3068\u30D3\u30FC\u30EB\u706B\u5C71\u304C\u7D04\u675F\u3055\u308C\u3066\u3044\u308B\u3002\u307E\u305F\u3001\u5973\u6027\u3084\u30B2\u30A4\u306E\u4FE1\u8005\u306E\u305F\u3081\u306E\u7537\u6027\u30B9\u30C8\u30EA\u30C3\u30D1\u30FC\u3082\u5B58\u5728\u3057\u3066\u3044\u308B\u3002\u5730\u7344\u306F\u30D3\u30FC\u30EB\u306E\u6C17\u304C\u629C\u3051\u3066\u3044\u3066\u30B9\u30C8\u30EA\u30C3\u30D1\u30FC\u304C\u6027\u75C5\u6301\u3061\u3067\u3042\u308B\u3068\u3044\u3046\u4E8B\u4EE5\u5916\u5929\u56FD\u3068\u540C\u3058\u3067\u3042\u308B\u3002",
  "id" : 605370788632530944,
  "created_at" : "2015-06-01 13:50:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605370600757055488",
  "text" : "\u3064\u307E\u308A\u3001\u5929\u5730\u958B\u95E2\u306B\u969B\u3057\u3066\u6DF7\u6C8C\u306E\u4E2D\u304B\u3089\u6D6E\u304B\u3073\u4E0A\u304C\u3063\u305F\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u70CF\u9F8D\u8336\u5DE5\u5834\u3082\u3081\u3050\u308A\u3081\u3050\u3063\u3066\u7A7A\u98DB\u3076\u30B9\u30D1\u30B2\u30C3\u30C6\u30A3\u30FB\u30E2\u30F3\u30B9\u30BF\u30FC\u69D8\u304C\u5275\u9020\u3057\u305F\u3053\u3068\u306B\u306A\u308B\u306A\u3002",
  "id" : 605370600757055488,
  "created_at" : "2015-06-01 13:49:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605370381336244226",
  "text" : "\u5B87\u5B99\u306F\u7A7A\u98DB\u3076\u30B9\u30D1\u30B2\u30C3\u30C6\u30A3\u30FB\u30E2\u30F3\u30B9\u30BF\u30FC\u306B\u3088\u3063\u3066\u5275\u9020\u3055\u308C\u305F\u3002\u3053\u308C\u306F\u7A7A\u98DB\u3076\u30B9\u30D1\u30B2\u30C3\u30C6\u30A3\u30FB\u30E2\u30F3\u30B9\u30BF\u30FC\u304C\u5927\u9152\u3092\u98F2\u3093\u3060\u5F8C\u306E\u4E8B\u3067\u3042\u3063\u305F\u3002",
  "id" : 605370381336244226,
  "created_at" : "2015-06-01 13:48:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605364407799943168",
  "text" : "\u30B0\u30EB\u30FC\u30D7DM\u304C\u898B\u308C\u308BiOS\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u3063\u3066\u5B58\u5728\u3059\u308B\uFF1F",
  "id" : 605364407799943168,
  "created_at" : "2015-06-01 13:24:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605361103460286465",
  "text" : "\u5357\u533A\u304B\u3089\u7686\u4E09\u9688\uFF08\u4E09\u9688\u304C\u3044\u3063\u3071\u3044\u4E26\u3093\u3067\u308B\u753B\u50CF\u3092\u8F09\u305B\u308B\uFF09\u3063\u3066\u306E\u304C\u5B89\u6613\u306B\u601D\u3044\u3064\u3044\u305F\u3051\u3069\u753B\u529B\u3082\u30BB\u30F3\u30B9\u3082\u7121\u3044",
  "id" : 605361103460286465,
  "created_at" : "2015-06-01 13:11:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605360298241978369",
  "text" : "\u5E83 \u304C \u308B \u69D8 \u5F0F \u7F8E \u306E \u6587 \u5316",
  "id" : 605360298241978369,
  "created_at" : "2015-06-01 13:08:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "\u304D\u3063\u3057\u3043\u0E05",
      "screen_name" : "aitaioddstr",
      "indices" : [ 36, 48 ],
      "id_str" : "1523835464",
      "id" : 1523835464
    }, {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 50, 59 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605360215811309568",
  "text" : "RT @kagakuma: \u304D\u3001\u304D\u305F\u3001\u5317\u533A\u304B\u3089\u5E30\u5B85\u9B54\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01RT @aitaioddstr: @kagakuma \u3069\u3053\u304B\u3089\u304D\u305F\u304F\u3057\u3066\u305F\u3093\u3067\u3059\u304B\u30FC\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u304D\u3063\u3057\u3043\u0E05",
        "screen_name" : "aitaioddstr",
        "indices" : [ 22, 34 ],
        "id_str" : "1523835464",
        "id" : 1523835464
      }, {
        "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
        "screen_name" : "kagakuma",
        "indices" : [ 36, 45 ],
        "id_str" : "139989698",
        "id" : 139989698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605360109485580288",
    "text" : "\u304D\u3001\u304D\u305F\u3001\u5317\u533A\u304B\u3089\u5E30\u5B85\u9B54\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01RT @aitaioddstr: @kagakuma \u3069\u3053\u304B\u3089\u304D\u305F\u304F\u3057\u3066\u305F\u3093\u3067\u3059\u304B\u30FC\uFF1F",
    "id" : 605360109485580288,
    "created_at" : "2015-06-01 13:07:51 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 605360215811309568,
  "created_at" : "2015-06-01 13:08:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 37, 47 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 49, 58 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605360184429539330",
  "text" : "RT @kagakuma: \u304D\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01RT @end313124: @kagakuma \u3048\uFF1F\uFF01\u4F55\u533A\u304B\u3089\u3069\u3046\u3057\u305F\u3063\u3066\u3044\u3046\u3093\u3067\u3059\u304B\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 23, 33 ],
        "id_str" : "155546700",
        "id" : 155546700
      }, {
        "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
        "screen_name" : "kagakuma",
        "indices" : [ 35, 44 ],
        "id_str" : "139989698",
        "id" : 139989698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605360044276740096",
    "text" : "\u304D\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01RT @end313124: @kagakuma \u3048\uFF1F\uFF01\u4F55\u533A\u304B\u3089\u3069\u3046\u3057\u305F\u3063\u3066\u3044\u3046\u3093\u3067\u3059\u304B\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01",
    "id" : 605360044276740096,
    "created_at" : "2015-06-01 13:07:36 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 605360184429539330,
  "created_at" : "2015-06-01 13:08:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605359874172547072",
  "geo" : { },
  "id_str" : "605359986923974656",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3048\uFF1F\uFF01\u4F55\u533A\u304B\u3089\u3069\u3046\u3057\u305F\u3063\u3066\u3044\u3046\u3093\u3067\u3059\u304B\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01",
  "id" : 605359986923974656,
  "in_reply_to_status_id" : 605359874172547072,
  "created_at" : "2015-06-01 13:07:22 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3060\u306E\u3075\u3041",
      "screen_name" : "lotz84_",
      "indices" : [ 0, 8 ],
      "id_str" : "2515111958",
      "id" : 2515111958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605340314434297856",
  "geo" : { },
  "id_str" : "605340470244483072",
  "in_reply_to_user_id" : 2515111958,
  "text" : "@lotz84_ \u3046\u3080\u3001\u3044\u3064\u307E\u3067\u5C45\u308B\u304B\u308F\u304B\u3089\u306A\u3044\u304C\u3001\u3057\u3070\u3089\u304F\u5C45\u308B\u6C17\u304C\u3059\u308B\u304B\u3089\u305C\u3072\u884C\u3053\u3046",
  "id" : 605340470244483072,
  "in_reply_to_status_id" : 605340314434297856,
  "created_at" : "2015-06-01 11:49:49 +0000",
  "in_reply_to_screen_name" : "lotz84_",
  "in_reply_to_user_id_str" : "2515111958",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3060\u306E\u3075\u3041",
      "screen_name" : "lotz84_",
      "indices" : [ 0, 8 ],
      "id_str" : "2515111958",
      "id" : 2515111958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605338061191258113",
  "geo" : { },
  "id_str" : "605340246381854720",
  "in_reply_to_user_id" : 2515111958,
  "text" : "@lotz84_ \u99AC\u8089\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\u3002\u3042\u308A\u304C\u3068\u3046\u3002",
  "id" : 605340246381854720,
  "in_reply_to_status_id" : 605338061191258113,
  "created_at" : "2015-06-01 11:48:56 +0000",
  "in_reply_to_screen_name" : "lotz84_",
  "in_reply_to_user_id_str" : "2515111958",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3060\u306E\u3075\u3041",
      "screen_name" : "lotz84_",
      "indices" : [ 0, 8 ],
      "id_str" : "2515111958",
      "id" : 2515111958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605336056834105344",
  "geo" : { },
  "id_str" : "605337009541001217",
  "in_reply_to_user_id" : 2515111958,
  "text" : "@lotz84_ \u3093\u30FC\u3001\u3058\u3083\u3042\u3082\u3046\u3061\u3087\u3044\u5451\u307F\u3068\u3044\u3046\u3088\u308A\u3054\u98EF\u98DF\u3079\u308B\u5BC4\u308A\u306A\u611F\u3058\u3060\u3068\u3069\u3046\u3060\u308D\u3046\u304B",
  "id" : 605337009541001217,
  "in_reply_to_status_id" : 605336056834105344,
  "created_at" : "2015-06-01 11:36:04 +0000",
  "in_reply_to_screen_name" : "lotz84_",
  "in_reply_to_user_id_str" : "2515111958",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3060\u306E\u3075\u3041",
      "screen_name" : "lotz84_",
      "indices" : [ 0, 8 ],
      "id_str" : "2515111958",
      "id" : 2515111958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605335883101827073",
  "geo" : { },
  "id_str" : "605335980585971712",
  "in_reply_to_user_id" : 2515111958,
  "text" : "@lotz84_ \u304A\u304A\u30FC\u3044\u3063\u3071\u3044\u3042\u308A\u304C\u3068\u3046\uFF01",
  "id" : 605335980585971712,
  "in_reply_to_status_id" : 605335883101827073,
  "created_at" : "2015-06-01 11:31:59 +0000",
  "in_reply_to_screen_name" : "lotz84_",
  "in_reply_to_user_id_str" : "2515111958",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3060\u306E\u3075\u3041",
      "screen_name" : "lotz84_",
      "indices" : [ 0, 8 ],
      "id_str" : "2515111958",
      "id" : 2515111958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605335407698526208",
  "in_reply_to_user_id" : 2515111958,
  "text" : "@lotz84_ \u6E0B\u8C37\u3067\u4F55\u304B\u304A\u3044\u3057\u3044\u98DF\u3079\u7269\u3084\u3055\u3093\u6559\u3048\u3066\u304F\u308C\u307E\u305B\u3093\u304B\u30FC",
  "id" : 605335407698526208,
  "created_at" : "2015-06-01 11:29:42 +0000",
  "in_reply_to_screen_name" : "lotz84_",
  "in_reply_to_user_id_str" : "2515111958",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605307723081596928",
  "text" : "\u5B9F\u969B\u4F53\u611F\u6642\u9593\u30675\u5104\u5E74\u304F\u3089\u3044\u5F85\u3063\u3066\u308B\u3001\u6620\u753B\u7248\u306E\u50B7\u7269\u8A9E",
  "id" : 605307723081596928,
  "created_at" : "2015-06-01 09:39:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605307374228770816",
  "geo" : { },
  "id_str" : "605307529321529346",
  "in_reply_to_user_id" : 2985743269,
  "text" : "@yui_izumo \u307E\u3041\u3001\u3053\u3053\u308D\u306E\u9685\u3067\u5C0F\u3055\u304F\u671F\u5F85\u3057\u3066\u304A\u304D\u307E\u3057\u3087\u3046",
  "id" : 605307529321529346,
  "in_reply_to_status_id" : 605307374228770816,
  "created_at" : "2015-06-01 09:38:55 +0000",
  "in_reply_to_screen_name" : "rolle_ryo_ice",
  "in_reply_to_user_id_str" : "2985743269",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605307258717630464",
  "text" : "\u3057\u304B\u3082\u66F8\u3044\u3066\u308B\u306E\u304C\u8C9D\u6728\u76EE\u7DDA\u3063\u3066\u3042\u3041\u2026",
  "id" : 605307258717630464,
  "created_at" : "2015-06-01 09:37:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605306636614246400",
  "geo" : { },
  "id_str" : "605306816738623488",
  "in_reply_to_user_id" : 2985743269,
  "text" : "@yui_izumo 2\u670830\u65E5\u2026\uFF1F",
  "id" : 605306816738623488,
  "in_reply_to_status_id" : 605306636614246400,
  "created_at" : "2015-06-01 09:36:05 +0000",
  "in_reply_to_screen_name" : "rolle_ryo_ice",
  "in_reply_to_user_id_str" : "2985743269",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605305846650699777",
  "geo" : { },
  "id_str" : "605306140885319680",
  "in_reply_to_user_id" : 2985743269,
  "text" : "@yui_izumo \u3064\u3044\u306B\u6620\u753B\u3084\u308B\u3093\u3067\u3059\u304B\uFF01\u3069\u3053\u60C5\u5831\u3067\u3059\u304B\uFF1F",
  "id" : 605306140885319680,
  "in_reply_to_status_id" : 605305846650699777,
  "created_at" : "2015-06-01 09:33:24 +0000",
  "in_reply_to_screen_name" : "rolle_ryo_ice",
  "in_reply_to_user_id_str" : "2985743269",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605305354306514944",
  "text" : "Wii U\u6301\u3063\u3066\u305F\u3089\u7247\u8155\u304F\u3089\u3044\u306F\u6301\u3063\u3066\u884C\u304B\u308C\u3066\u3044\u305F\u304B\u3082\u3057\u308C\u306C",
  "id" : 605305354306514944,
  "created_at" : "2015-06-01 09:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605305265685176320",
  "text" : "\u30B9\u30D7\u30E9\u30C8\u30A5\u30FC\u30F3\u5B9F\u969B\u9762\u767D\u305D\u3046",
  "id" : 605305265685176320,
  "created_at" : "2015-06-01 09:29:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605221588141776897",
  "text" : "\uFF20\u6E0B\u8C37\u4EBA\u9593 \u306A\u3093\u304B\u304A\u3044\u3057\u3044\u3054\u306F\u3093\u3084\u3055\u3093\u3092\u30B5\u30B8\u30A7\u30B9\u30C8\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 605221588141776897,
  "created_at" : "2015-06-01 03:57:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605210424301264896",
  "text" : "\u306A\u3093\u3067\u3082\u305D\u3046\u3060\u3051\u3069\u306A",
  "id" : 605210424301264896,
  "created_at" : "2015-06-01 03:13:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605210374477127680",
  "text" : "\u50BE\u5411\u306F\u50BE\u5411\u3068\u3057\u3066\u3042\u308B\u3093\u3060\u308D\u3046\u3051\u3069\u3001\u904E\u5EA6\u306B\u4E00\u822C\u5316\u3055\u308C\u308B\u3068\u60B2\u3057\u3044\u6C17\u6301\u3061\u306B\u306A\u308B\u3053\u3068\u304C\u591A\u3044",
  "id" : 605210374477127680,
  "created_at" : "2015-06-01 03:12:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605209706127355906",
  "text" : "\u672C\u97F3\u3068\u5EFA\u524D\u3092\u7A4D\u6975\u7684\u306B\u5165\u308C\u66FF\u3048\u3066\u3044\u3051",
  "id" : 605209706127355906,
  "created_at" : "2015-06-01 03:10:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605209311036309504",
  "geo" : { },
  "id_str" : "605209644630437888",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u8AAD\u307F\u843D\u3068\u3057\u3066\u3044\u305F\u306A\u3093\u3066\u8A00\u3048\u306A\u3044\uFF08\u3044\u3048\u307E\u3041\u50D5\u3082\u5927\u5B66\u5165\u5B66\u5F53\u521D\u305D\u3093\u306A\u611F\u3058\u306E\u504F\u898B\u306E\u5F71\u3092\u611F\u3058\u305F\u3053\u3068\u304C\u3042\u3063\u305F\u306E\u3067\u3054\u306B\u3087\u3054\u306B\u3087\uFF09",
  "id" : 605209644630437888,
  "in_reply_to_status_id" : 605209311036309504,
  "created_at" : "2015-06-01 03:09:58 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605208851915218944",
  "geo" : { },
  "id_str" : "605209028705288193",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u6771\u4EAC\u4EBA\u9593\u304C\u307F\u3093\u306A\u305D\u3093\u306A\u611F\u3058\u3060\u3068\u601D\u3063\u3066\u63A5\u305B\u3089\u308C\u308B\u3068\u60B2\u3057\u3044\u6C17\u6301\u3061\u306B\u306A\u308B\u6642\u304C\u3042\u308B\u306E\u3067\u3054\u914D\u616E\u304F\u3060\u3055\u308C",
  "id" : 605209028705288193,
  "in_reply_to_status_id" : 605208851915218944,
  "created_at" : "2015-06-01 03:07:31 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605208102774784000",
  "geo" : { },
  "id_str" : "605208309021450240",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u3086\u3086\u3057\u304D\u3082\u3093\u3060\u3044\u3067\u3059\u306D",
  "id" : 605208309021450240,
  "in_reply_to_status_id" : 605208102774784000,
  "created_at" : "2015-06-01 03:04:39 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605204173643235328",
  "text" : "\u51FA\u3055\u308C\u305F\u304A\u8336\u3092\u98F2\u3080\u3088\u308A\u51FA\u3055\u308C\u3066\u306A\u3044\u304A\u8336\u3092\u98F2\u3080\u65B9\u304C\u5931\u793C",
  "id" : 605204173643235328,
  "created_at" : "2015-06-01 02:48:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    }, {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 13, 19 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605202684556263424",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 @k08a_ \u30B0\u30EB\u30FC\u30D7DM\u3057\u305F\u306E\u3067\u9811\u5F35\u3063\u3066\u307F\u308C\u304F\u308C\u3001\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306B\u3088\u3063\u3066\u306F\u898B\u308C\u306A\u3044\u304B\u3082\u3060\u304C\u3001\u516C\u5F0F\u306A\u3089\u898B\u308C\u308B\u306F\u305A",
  "id" : 605202684556263424,
  "created_at" : "2015-06-01 02:42:18 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605201336544534528",
  "geo" : { },
  "id_str" : "605201412100894721",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u3048\u3063\u3088\u308B\u306B\uFF1F\u307E\u3058\u3067",
  "id" : 605201412100894721,
  "in_reply_to_status_id" : 605201336544534528,
  "created_at" : "2015-06-01 02:37:15 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu@\u7121\u8077",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    }, {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 11, 17 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605201051130593280",
  "geo" : { },
  "id_str" : "605201181510660096",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 @k08a_ \u6C34\u66DC\u591C\u306F\u4E88\u5B9A\u304C\u304C\u304C",
  "id" : 605201181510660096,
  "in_reply_to_status_id" : 605201051130593280,
  "created_at" : "2015-06-01 02:36:20 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605200870909710336",
  "geo" : { },
  "id_str" : "605201025750970368",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u591C\u307E\u3067\u3084\u3063\u3066\u308B\u30A4\u30D9\u30F3\u30C8\u306F\u30E4\u30D0\u3044",
  "id" : 605201025750970368,
  "in_reply_to_status_id" : 605200870909710336,
  "created_at" : "2015-06-01 02:35:43 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605200787275399168",
  "text" : "\u3044\u3064\u307E\u3067\u3060\u308D\u30FC",
  "id" : 605200787275399168,
  "created_at" : "2015-06-01 02:34:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605200773480333312",
  "text" : "\u305D\u3046\u3044\u3048\u3070kindle\u5B9F\u8CEA\u534A\u984D\u306A\u3093\u305F\u3089\u306A\u3093\u304B",
  "id" : 605200773480333312,
  "created_at" : "2015-06-01 02:34:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    }, {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 13, 19 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605199929477193728",
  "geo" : { },
  "id_str" : "605200154170404866",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 @k08a_ \u304D\u3093\u304D\u3087\u3046\u307B\u3046\u3053\u304F\u3067\u306F\u306A\u3044\u304C\u3001\u8FD1\u3044\u3046\u3061\u3054\u306F\u3093\u3067\u3082\u305F\u3079\u306B\u3044\u304B\u306A\u3044\u304B",
  "id" : 605200154170404866,
  "in_reply_to_status_id" : 605199929477193728,
  "created_at" : "2015-06-01 02:32:15 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]