Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351340979896336388",
  "text" : "\u3044\u3084\u5BB6\u306B\u5C45\u308B\u3051\u3069",
  "id" : 351340979896336388,
  "created_at" : "2013-06-30 14:06:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351340942625742849",
  "text" : "\u306A\u304B\u536F\u3067\u3054\u98EF\u3092\u98DF\u3079\u306A\u3044\u5974\u3078\u306E\u8B66\u544A\u3068\u3057\u3066\u306E\u5E97\u5185BGM",
  "id" : 351340942625742849,
  "created_at" : "2013-06-30 14:06:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351309134769045504",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 351309134769045504,
  "created_at" : "2013-06-30 11:59:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/psH0HwocdH",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=Chris_mtmr",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351090026215518208",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/psH0HwocdH",
  "id" : 351090026215518208,
  "created_at" : "2013-06-29 21:29:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350997256951967744",
  "geo" : { },
  "id_str" : "350997417820307459",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u5965\u306E\u65B9\u306F\u9055\u3063\u305F",
  "id" : 350997417820307459,
  "in_reply_to_status_id" : 350997256951967744,
  "created_at" : "2013-06-29 15:21:20 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 0, 7 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350995364712685568",
  "geo" : { },
  "id_str" : "350996915292344321",
  "in_reply_to_user_id" : 50640629,
  "text" : "@igaris \u51B7\u305F\u304F\u3066\u7F8E\u5473\u3057\u304B\u3063\u305F\u3067\u3059",
  "id" : 350996915292344321,
  "in_reply_to_status_id" : 350995364712685568,
  "created_at" : "2013-06-29 15:19:20 +0000",
  "in_reply_to_screen_name" : "igaris",
  "in_reply_to_user_id_str" : "50640629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 0, 7 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350994887769980928",
  "geo" : { },
  "id_str" : "350995148798300161",
  "in_reply_to_user_id" : 50640629,
  "text" : "@igaris \u3053\u308C\u3068\u306F\u5225\u3067\u3059\u304C\u51CD\u308A\u304B\u3051\u305F\u30D3\u30FC\u30EB\u306F\u3042\u307E\u308A\u6CE1\u7ACB\u3061\u307E\u305B\u3093\u3067\u3057\u305F",
  "id" : 350995148798300161,
  "in_reply_to_status_id" : 350994887769980928,
  "created_at" : "2013-06-29 15:12:19 +0000",
  "in_reply_to_screen_name" : "igaris",
  "in_reply_to_user_id_str" : "50640629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350994912960987136",
  "text" : "\u51B7\u8535\u5EAB\u306E\u672C\u6C17\u3092\u898B\u305F",
  "id" : 350994912960987136,
  "created_at" : "2013-06-29 15:11:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350994484332478464",
  "text" : "\u3053\u308C\u3082\u3046\u30D3\u30FC\u30EB\u3058\u3083\u306A\u3044",
  "id" : 350994484332478464,
  "created_at" : "2013-06-29 15:09:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/350994390187126784\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/SDhgdk2VFL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN77icmCMAAqHea.jpg",
      "id_str" : "350994390191321088",
      "id" : 350994390191321088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN77icmCMAAqHea.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/SDhgdk2VFL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350994390187126784",
  "text" : "\u30D3\u30FC\u30EB\u3092\u51B7\u3084\u3057\u904E\u304E\u305F\u7D50\u679Cwwwwwwwwwww http:\/\/t.co\/SDhgdk2VFL",
  "id" : 350994390187126784,
  "created_at" : "2013-06-29 15:09:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350946721741799424",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 350946721741799424,
  "created_at" : "2013-06-29 11:59:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350868049290735616",
  "text" : "\u3055\u3044\u3066\u30FC\u3052\u3093\u3076\u3093\u304B\u3066\u304D\u306A\u305B\u30FC\u304B\u3064\u3092\u3057\u3044\u3089\u308C\u3066\u308B\u3093\u3060",
  "id" : 350868049290735616,
  "created_at" : "2013-06-29 06:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350826987436253186",
  "text" : "\u3044\u3061\u3058\u308B\u3057\u304F\u3044\u3061\u3058",
  "id" : 350826987436253186,
  "created_at" : "2013-06-29 04:04:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350715895187898369",
  "text" : "\"\"\"\u8DDD\u96E2\u611F\"\"\"\u304C\u304B\u306A\u308A\u5C0F\u3055\u304F\u306A\u3089\u306A\u3044\u3068\u96D1\u306B\u306F\u6271\u3048\u306A\u3044\u3057\u306A\uFF1F",
  "id" : 350715895187898369,
  "created_at" : "2013-06-28 20:42:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350715624223277056",
  "text" : "\u5B89\u5FC3\u3057\u3066\u96D1\u306B\u6271\u3048\u308B\u76F8\u624Bis\u5927\u5207",
  "id" : 350715624223277056,
  "created_at" : "2013-06-28 20:41:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350715310111866880",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u306F\u3001\"\u3053\u308C\u3060\u3051\u9069\u5F53\u306B\u558B\u3063\u3066\u3066(\u6700\u4F4E\u9650\u306E)\u914D\u616E\u304C\u51FA\u6765\u3066\u308B\"\u3089\u3057\u3044\u306E\u3067\u3053\u308C\u304B\u3089\u3082\u7A4D\u6975\u7684\u306B\u9069\u5F53\u306B\u558B\u308B",
  "id" : 350715310111866880,
  "created_at" : "2013-06-28 20:40:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350714594676842497",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u30CA\u30C1\u30E5\u30E9\u30EB\u30CF\u30A4\u3068\u8A00\u3046\u304B\u30B9\u30D4\u30FC\u30AB\u30FC\u30BA\u30CF\u30A4\u3068\u8A00\u3046\u304B\u3001\u7720\u308C\u306A\u3044",
  "id" : 350714594676842497,
  "created_at" : "2013-06-28 20:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350705970952941568",
  "geo" : { },
  "id_str" : "350706434578722816",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u305D\u3046\u3044\u3048\u3070\u8A18\u61B6\u306A\u3044\u2026[\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u2026]",
  "id" : 350706434578722816,
  "in_reply_to_status_id" : 350705970952941568,
  "created_at" : "2013-06-28 20:05:04 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350705715586924545",
  "text" : "\u5B9F\u969B\u30D0\u30AC\u30C5\u30AD\u3057\u3066\u308B\u4EBA\u304C\u3044\u308B\u5B85\u3067\u3064\u3044\u3066\u7121\u3044\u3068\u304B\u306A\u308A\u53B3\u3057\u3044",
  "id" : 350705715586924545,
  "created_at" : "2013-06-28 20:02:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350699239392821248",
  "geo" : { },
  "id_str" : "350705527904403456",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 (\u8272\u3005)\u3042\u3063\u2026(\u5BDF\u3057)",
  "id" : 350705527904403456,
  "in_reply_to_status_id" : 350699239392821248,
  "created_at" : "2013-06-28 20:01:28 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350705342461657088",
  "text" : "\u304C\u3001\u3069\u3046\u8003\u3048\u3066\u3082\u666E\u6BB5\u306E\u4F1A\u8A71\u306E\u30DD\u30B8\u30B7\u30E7\u30F3\u3086\u305A\u3053\u306A\u306E\u3067\u30D6\u30FC\u30E1\u30E9\u30F3\u3060\u3063\u305F",
  "id" : 350705342461657088,
  "created_at" : "2013-06-28 20:00:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350705177847808003",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u3086\u3086\u5F0F\u3061\u3087\u3063\u3068\u3060\u3051\u898B\u305F\u9650\u308A\u3067\u30DE\u30B8\u30AD\u30C1\u611F\u306F\u3059\u3054\u3044\u4F1D\u308F\u3063\u305F",
  "id" : 350705177847808003,
  "created_at" : "2013-06-28 20:00:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350697646081585152",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u8D77\u304D\u305F\u3089\u30CD\u30B2\u30F3\u30C8\u30ED\u30D4\u30FC\u3057\u306A\u3044\u3068\u3053\u306E\u5C45\u4F4F\u74B0\u5883\u306F\u3084\u3070\u3044",
  "id" : 350697646081585152,
  "created_at" : "2013-06-28 19:30:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350694893464727552",
  "text" : "\u632F\u308A\u8FD4\u308B\u3068\u4E88\u5B9A\u8ABF\u548C\u611F\u3042\u3063\u305F[\u6771\u30E9\u30B99600\u304B\u3089\u306E4\u9023\u7D9A\u548C\u4E86\u3068\u304B]",
  "id" : 350694893464727552,
  "created_at" : "2013-06-28 19:19:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350694464332894208",
  "text" : "\u30D0\u30AB\u30C4\u30AD\u3057\u3066\u308B\u4EBA\u304C\u5C45\u308B\u3068\u4E8C\u7740\u3057\u304B\u53D6\u308C\u306A\u3044\u3001\u3068\u8A00\u3046\u81EA\u7136\u306A\u4E8B\u5B9F\u3092\u76EE\u306E\u5F53\u305F\u308A\u306B\u3057\u305F",
  "id" : 350694464332894208,
  "created_at" : "2013-06-28 19:17:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350575803525902336",
  "geo" : { },
  "id_str" : "350576123396104192",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u3044\u3084\u3001\u9375\u306F\u6301\u3063\u3066\u308B\u304B\u3089\u5E73\u6C17\u2026",
  "id" : 350576123396104192,
  "in_reply_to_status_id" : 350575803525902336,
  "created_at" : "2013-06-28 11:27:15 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350575068520263680",
  "geo" : { },
  "id_str" : "350575446838099969",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u5148\u3044\u3063\u3066\u3066",
  "id" : 350575446838099969,
  "in_reply_to_status_id" : 350575068520263680,
  "created_at" : "2013-06-28 11:24:34 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350464143419129856",
  "text" : "\u30C7\u30E5\u30A2\u30EB\u30C7\u30A3\u30B9\u30D7\u30EC\u30A4\u306E\u74B0\u5883\u304C\u6574\u3044\u3064\u3064\u3042\u308B",
  "id" : 350464143419129856,
  "created_at" : "2013-06-28 04:02:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350463829873930240",
  "geo" : { },
  "id_str" : "350463954931298305",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma (\u305D\u308A\u3083\u307E\u3041\u884C\u304D\u305F\u3044\u3060\u3051\u306A\u3089\u884C\u304D\u305F\u3044\u3067\u3059\u3051\u308C\u3069)",
  "id" : 350463954931298305,
  "in_reply_to_status_id" : 350463829873930240,
  "created_at" : "2013-06-28 04:01:32 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350463807128215558",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u3075\u3056\u3051\u304C\u3061\u3060\u3051\u3069\u672C\u6C17\u51FA\u305B\u3070\u3042\u308B\u7A0B\u5EA6\u793C\u5100\u6B63\u3057\u304F\u3067\u304D\u308B",
  "id" : 350463807128215558,
  "created_at" : "2013-06-28 04:00:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350463560444424192",
  "geo" : { },
  "id_str" : "350463665885028355",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304A\u624B\u6570\u304A\u304B\u3051\u3057\u307E\u3059",
  "id" : 350463665885028355,
  "in_reply_to_status_id" : 350463560444424192,
  "created_at" : "2013-06-28 04:00:23 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350463248673423360",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30E1\u30FC\u30EB\u3057\u307E\u3057\u305F\u306E\u3067\u3054\u78BA\u8A8D\u304F\u3060\u3055\u3044",
  "id" : 350463248673423360,
  "created_at" : "2013-06-28 03:58:44 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350422479543615489",
  "text" : "\u5B9F\u969B\u5965\u3086\u304B\u3057\u3044\u671D\u3054\u306F\u3093\u3082\u3069\u304D",
  "id" : 350422479543615489,
  "created_at" : "2013-06-28 01:16:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350422414187962369",
  "text" : "\u304B\u308A\u3093\u3068\u3046\u3082\u3050\u3082\u3050\u3046\u30FC\u308D\u3093\u3061\u3083\u3054\u304F\u3054\u304F",
  "id" : 350422414187962369,
  "created_at" : "2013-06-28 01:16:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350251679159025664",
  "text" : "\u3088\u3057\u3001\u4E00\u6BB5\u843D\u3002\u3053\u308C\u3067\u30D5\u30EB\u30DC\u30C3\u30B3\u306B\u3055\u308C\u308B\u306A\u3089\u5168\u54E1\u30D5\u30EB\u30DC\u30C3\u30B3\u3060\u3057\u307E\u3041\u3044\u3044\u3084\u3002",
  "id" : 350251679159025664,
  "created_at" : "2013-06-27 13:58:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350222000880484353",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 350222000880484353,
  "created_at" : "2013-06-27 12:00:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350178460179763200",
  "text" : "\u304A\u306A\u304B\u3078\u3063\u305F\u306A\u3041",
  "id" : 350178460179763200,
  "created_at" : "2013-06-27 09:07:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350156140312662017",
  "text" : "\u30A2\u30DB\u306A\u570F\u306E\u4F8B\u306A\u3044\u304B\u306A\u30FC[\u53B3\u5BC6\u306B\u570F\u3067\u306A\u304F\u3066\u3082\u6700\u60AA\u826F\u3057]",
  "id" : 350156140312662017,
  "created_at" : "2013-06-27 07:38:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349889580499083266",
  "text" : "\u4E09\u5C0B\u6728\u30D7\u30ED\u306E\u682A\u304C\u3060\u3060\u3042\u304C\u308A",
  "id" : 349889580499083266,
  "created_at" : "2013-06-26 13:59:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/349837428682547200\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/MZBzvCVFjs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNrfSbJCYAA2xzA.jpg",
      "id_str" : "349837428690935808",
      "id" : 349837428690935808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNrfSbJCYAA2xzA.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/MZBzvCVFjs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349837428682547200",
  "text" : "\u8089\u3058\u3083\u304C\u304C\u88AB\u3063\u3066\u3057\u307E\u3063\u305F http:\/\/t.co\/MZBzvCVFjs",
  "id" : 349837428682547200,
  "created_at" : "2013-06-26 10:31:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349795412200263682",
  "text" : "\u30BF\u30DE\u30CD\u30AE\u3068\u30D4\u30AF\u30EB\u30B9\u3045",
  "id" : 349795412200263682,
  "created_at" : "2013-06-26 07:44:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349795375575609344",
  "text" : "\u4ECA\uFF01\uFF01\u30DB\u30C3\u30C8\u30C9\u30C3\u30B0\u98DF\u3079\u305F\u307F\u3067\u306A\u3089\uFF01\uFF01\u4EAC\u90FDNO1\u3092\uFF01\uFF01\u72D9\u3048\u308B\uFF01\uFF01\uFF01\uFF01",
  "id" : 349795375575609344,
  "created_at" : "2013-06-26 07:44:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349692878311796736",
  "text" : "\u30A4\u30A4\u30C6\u30F3\u30AD\u30C0\u30CA\u30FC",
  "id" : 349692878311796736,
  "created_at" : "2013-06-26 00:57:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349497309370920960",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 349497309370920960,
  "created_at" : "2013-06-25 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349394199432536065",
  "text" : "\u304B\u305A\u30FC\u6C0F123456\u30C4\u30A4\u30FC\u30C8\u8FD1\u3044",
  "id" : 349394199432536065,
  "created_at" : "2013-06-25 05:10:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349383990362390528",
  "text" : "\u51FA\u304B\u3051\u308B\u304B\u2026",
  "id" : 349383990362390528,
  "created_at" : "2013-06-25 04:30:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yPXgQte7v4",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/kyoto.html",
      "display_url" : "sx9.jp\/weather\/kyoto.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349082958407299072",
  "text" : "http:\/\/t.co\/yPXgQte7v4 \u3059\u3050\u6B62\u3080\u3068\u4FE1\u3058\u3066\u308B",
  "id" : 349082958407299072,
  "created_at" : "2013-06-24 08:33:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349082655163289600",
  "text" : "\u30A2\u30DE\u30AA\u30C8\u30CE\u30AB\u30CA\u30B7\u30DF",
  "id" : 349082655163289600,
  "created_at" : "2013-06-24 08:32:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349068846579200000",
  "text" : "\u5FAE\u5206\u3068\u306F\u304A\u524D\u81EA\u8EAB\u3060",
  "id" : 349068846579200000,
  "created_at" : "2013-06-24 07:37:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349067946745790464",
  "text" : "\u3042\u3001\u5B9F\u5BB6\u306B\u5927\u91CF\u306B\u8CB7\u3063\u305F\u3042\u305A\u304D\u30D0\u30FC\u98DF\u3079\u640D\u306A\u3063\u305F",
  "id" : 349067946745790464,
  "created_at" : "2013-06-24 07:34:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349067207143206912",
  "text" : "\u8B70\u8AD6\u306E\u3059\u308C\u9055\u3044\u3092\u8868\u3059\u826F\u3044\u4F8B\u3067\u3042\u308B(^^)(^^)(^^)",
  "id" : 349067207143206912,
  "created_at" : "2013-06-24 07:31:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349066688072929280",
  "text" : "\u4E94\u6761",
  "id" : 349066688072929280,
  "created_at" : "2013-06-24 07:29:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0430\u043B\u044F White",
      "screen_name" : "getty_on_r318",
      "indices" : [ 0, 14 ],
      "id_str" : "2884913343",
      "id" : 2884913343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349027117545177089",
  "geo" : { },
  "id_str" : "349027687064551424",
  "in_reply_to_user_id" : 379262851,
  "text" : "@getty_on_r318 \u3042\u308C\u306F\u300C\u6587\u7CFB()\u306E\u30A2\u30EC\u306A\u5973bot\u300D\u3060\u304B\u3089\u306A\u3042\u3041",
  "id" : 349027687064551424,
  "in_reply_to_status_id" : 349027117545177089,
  "created_at" : "2013-06-24 04:54:19 +0000",
  "in_reply_to_screen_name" : "komorin95",
  "in_reply_to_user_id_str" : "379262851",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349026664463859712",
  "text" : "\u65B0\u5E79\u7DDA\u306E\u30D7\u30E9\u30C3\u30C8\u30D5\u30A9\u30FC\u30E0\u3067\u30B5\u30F3\u30C8\u30EA\u30FC\u70CF\u9F8D\u8336\u304C\u58F2\u3089\u308C\u3066\u3044\u306A\u304B\u3063\u305F\u306E\u3067\u6CE3\u304D\u306A\u304C\u3089\u307B\u3046\u3058\u8336\u8CB7\u3063\u305F",
  "id" : 349026664463859712,
  "created_at" : "2013-06-24 04:50:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349022726553489408",
  "text" : "\u306A\u304A\u3048\u3093\u3069\u6C0F\u81EA\u8EAB\u3001\u81EA\u5206\u306E\u5E74\u3092\u306F\u3063\u304D\u308A\u3068\u899A\u3048\u3066\u3044\u306A\u3044\u6A21\u69D8",
  "id" : 349022726553489408,
  "created_at" : "2013-06-24 04:34:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349022581363470336",
  "text" : "\u6BCD\u300C\u79C1\u660E\u65E5\u8A95\u751F\u65E5\u306A\u3093\u3060\u3051\u3069\u300D\n\u3048\u3093\u3069\u300C\u305D\u306E\u5E74\u306B\u306A\u308B\u3068\u8A95\u751F\u65E5\u305D\u3093\u306A\u306B\u5B09\u3057\u304F\u306A\u3044\u3067\u3057\u3087\u300D\n\u6BCD\u300C\u308F\u304B\u308B\u300D",
  "id" : 349022581363470336,
  "created_at" : "2013-06-24 04:34:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349022090504069120",
  "text" : "\u795E\u7530",
  "id" : 349022090504069120,
  "created_at" : "2013-06-24 04:32:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349020568097525760",
  "text" : "\u6BCD\u6821\u306F\u697D\u3057\u304B\u3063\u305F\u3051\u3069\u624B\u653E\u3057\u3067\u597D\u304D\u3068\u306F\u8A00\u3048\u306A\u3044\u306A\u3093\u3068\u3082\u8A00\u3048\u306A\u3044\u611F\u3058",
  "id" : 349020568097525760,
  "created_at" : "2013-06-24 04:26:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349017749483311106",
  "text" : "\u591A\u5206\u540C\u671F\u3067\u3042\u308B\u7A0B\u5EA6\u306F\u5BFE\u5FDC\u51FA\u6765\u308B\u3068\u601D\u3046\u304C\u2026",
  "id" : 349017749483311106,
  "created_at" : "2013-06-24 04:14:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349017604792406016",
  "text" : "\u5999\u306A\u518D\u8D77\u52D5\u304C\u3042\u3063\u305F\u3068\u601D\u3063\u305F\u3089\u96FB\u8A71\u5E33\u304C\u96F6\u5316\u3057\u3066\u305F",
  "id" : 349017604792406016,
  "created_at" : "2013-06-24 04:14:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348827723134816257",
  "text" : "\u306A\u3093\u3064\u3063\u3066\u3063\u3064\u3063\u3061\u3083\u3063\u305F\uFF1F\uFF01\uFF1F",
  "id" : 348827723134816257,
  "created_at" : "2013-06-23 15:39:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348819932487757826",
  "text" : "\u59B9\u304C\u30B3\u30F3\u30BF\u30AF\u30C8\u5916\u3057\u3066\u305F\u304B\u3089\u300C\u76EE\u304B\u3089\u9C57\uFF1F\u300D\u3063\u3066\u805E\u304F\u904A\u3073\u3057\u3066\u305F",
  "id" : 348819932487757826,
  "created_at" : "2013-06-23 15:08:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348818168669671424",
  "text" : "\u70CF\u9F8D\u8336\u304C\u51FA\u3066\u304F\u308B\u86C7\u53E3\u3068\u304B\u914D\u3063\u3066\u304F\u308C\u305F\u3089\u7968\u5165\u308C\u308B",
  "id" : 348818168669671424,
  "created_at" : "2013-06-23 15:01:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beepcap Z3(\u9632\u6C34)",
      "screen_name" : "beepcap",
      "indices" : [ 3, 11 ],
      "id_str" : "3933721",
      "id" : 3933721
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 13, 23 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348818031822118912",
  "text" : "RT @beepcap: @end313124 \u305D\u3053\u3067\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u793E\u9577\u304C\u51FA\u99AC\u3057\u3066\u304F\u308B\u30FB\u30FB\u30FB\u3068\u3044\u3046\u6D41\u308C\u3092\u6B62\u3081\u3089\u308C\u306A\u3044\u304B\u3089\u3001\u3069\u3046\u306B\u3082\u306A\u3089\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "348816505561030657",
    "geo" : { },
    "id_str" : "348816674247557121",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u305D\u3053\u3067\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u793E\u9577\u304C\u51FA\u99AC\u3057\u3066\u304F\u308B\u30FB\u30FB\u30FB\u3068\u3044\u3046\u6D41\u308C\u3092\u6B62\u3081\u3089\u308C\u306A\u3044\u304B\u3089\u3001\u3069\u3046\u306B\u3082\u306A\u3089\u306A\u3044\u3002",
    "id" : 348816674247557121,
    "in_reply_to_status_id" : 348816505561030657,
    "created_at" : "2013-06-23 14:55:50 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "beepcap Z3(\u9632\u6C34)",
      "screen_name" : "beepcap",
      "protected" : false,
      "id_str" : "3933721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583285245631332352\/Y6p7aeFx_normal.png",
      "id" : 3933721,
      "verified" : false
    }
  },
  "id" : 348818031822118912,
  "created_at" : "2013-06-23 15:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348816505561030657",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\"\u30B5\u30F3\u30C8\u30EA\u30FC\u70CF\u9F8D\u8336\u304C\u3082\u3089\u3048\u308B\"\u3068\u304B\u306B\u3057\u305F\u3089\u82E5\u8005\u3082\u3082\u3063\u3068\u9078\u6319\u306B\u884C\u304F\u306E\u3067\u306F",
  "id" : 348816505561030657,
  "created_at" : "2013-06-23 14:55:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348816279454486529",
  "text" : "\u9078\u6319\u304C\u6848\u5916\u9762\u767D\u304F\u306A\u304B\u3063\u305F\u3068\u8A00\u3046\u3053\u3068\u3060\u3051\u4F1D\u3048\u3066\u304A\u304D\u307E\u3059",
  "id" : 348816279454486529,
  "created_at" : "2013-06-23 14:54:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348784509770145793",
  "text" : "\u54B2\u306F\u4E00\u5DFB\u306E\u300C\u4E0B\u3089\u306A\u304F\u306A\u3044\u3088\u3063\uFF01\u300D\u306E\u9854\u304C\u304B\u308F\u3044\u3044",
  "id" : 348784509770145793,
  "created_at" : "2013-06-23 12:48:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348772271692853248",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 348772271692853248,
  "created_at" : "2013-06-23 11:59:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348760475422556160",
  "text" : "\u9078\u6319\u306E\u7D19\u306B\u5C0F\u91CE\u5BFA\u5149\u3063\u3066\u66F8\u3051\u3070\u826F\u304B\u3063\u305F\u306A\u2026",
  "id" : 348760475422556160,
  "created_at" : "2013-06-23 11:12:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348757712156364800",
  "text" : "\u59B9\u306B\u30A2\u30A4\u30B9\u983C\u307E\u308C\u305F\u304B\u3089\u30ED\u30C3\u30AF\u30A2\u30A4\u30B9\u8CB7\u3063\u3066\u5E30\u3063\u305F\u50D5\u306E\u8A71\u3057\u3066\u307E\u3059\uFF1F",
  "id" : 348757712156364800,
  "created_at" : "2013-06-23 11:01:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348714438452469761",
  "text" : "\u9078\u6319\u3001\u5168\u304F\u60C5\u5831\u306A\u3044\u3051\u3069\u30BF\u30A4\u30DF\u30F3\u30B0\u826F\u3044\u3057\u884C\u3063\u3066\u307F\u3088\u3046\u304B\u3068\u601D\u3063\u3066\u3044\u308B",
  "id" : 348714438452469761,
  "created_at" : "2013-06-23 08:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348714152484806657",
  "text" : "Q.\u4F55\u56DE\u751F\u3067\u3059\u304B\uFF1F\nA.9\u30683\/4\u56DE\u751F\u3067\u3059\uFF01\uFF01\uFF01\n\n\u3063\u3066\u306E\u3092\u3084\u308A\u305F\u3044",
  "id" : 348714152484806657,
  "created_at" : "2013-06-23 08:08:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348713734413381632",
  "text" : "\u308F\u3063\u304B\u3093\u306D\u30FC\u3047\u5168\u7136\u308F\u3063\u304B\u3093\u306D\u30FC\u3047",
  "id" : 348713734413381632,
  "created_at" : "2013-06-23 08:06:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348705977614348288",
  "geo" : { },
  "id_str" : "348713622559670273",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u9662\u9032\u3067\u3059\u304C\u3001\u9662\u6B7B\u4E88\u544A\u3055\u308C\u3066\u308B\u611F\u3058\u3067\u3059\u306D\u30FC[\u308F\u304B\u3093\u306A\u3044\u3067\u3059\u3051\u3069]",
  "id" : 348713622559670273,
  "in_reply_to_status_id" : 348705977614348288,
  "created_at" : "2013-06-23 08:06:21 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348713193708859392",
  "text" : "\u5411\u304B\u3044\u306E\u5E7C\u7A1A\u5712\u5150\u304C\u6BCD\u89AA\u306E\u307B\u3063\u307A\u305F\u7A81\u3064\u3044\u3066\u3066\u3069\u3063\u3061\u3082\u304B\u308F\u3044\u3044",
  "id" : 348713193708859392,
  "created_at" : "2013-06-23 08:04:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348712838761684992",
  "text" : "\u308B\u308B\u308B\u30FC\u30FC\u308B\u308B\u30FC\u266A\u308B\u30FC",
  "id" : 348712838761684992,
  "created_at" : "2013-06-23 08:03:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348712759472570368",
  "text" : "\u305D\u306E\u5C11\u6570\u7CBE\u92ED\u3001\u5C11\u306A\u3044\u3060\u3051\u3067\u7CBE\u92ED\u3068\u306F\u9650\u3089\u306A\u3044\u306E\u3067\u306F\uFF1F\uFF1F\uFF1F\uFF1F\u308B\u308B\u308B\uFF1F\uFF1F",
  "id" : 348712759472570368,
  "created_at" : "2013-06-23 08:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348701139618910208",
  "text" : "\u30DB\u30C6\u30EB\u306E\u4E00\u5BA4\u3092\u8CB7\u3044\u53D6\u308B\u30E9\u30A4\u30D5\u30CF\u30C3\u30AF[\uFF1F]",
  "id" : 348701139618910208,
  "created_at" : "2013-06-23 07:16:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ton",
      "screen_name" : "o_tton",
      "indices" : [ 0, 7 ],
      "id_str" : "216098832",
      "id" : 216098832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348698129698258944",
  "geo" : { },
  "id_str" : "348700245875638273",
  "in_reply_to_user_id" : 86330520,
  "text" : "@o_tton \u3067\u3059\u3088\u306D\uFF01",
  "id" : 348700245875638273,
  "in_reply_to_status_id" : 348698129698258944,
  "created_at" : "2013-06-23 07:13:11 +0000",
  "in_reply_to_screen_name" : "o_t_t_o_n",
  "in_reply_to_user_id_str" : "86330520",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348698418882936832",
  "geo" : { },
  "id_str" : "348700177017749505",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u3048\u30FC\u3001\u305D\u3046\u3067\u3059\u304B[\u3044\u3084\u307E\u3041\u5B9F\u969B\u4F4F\u3080\u3068\u306A\u3063\u305F\u3089\u3044\u308D\u3044\u308D\u9762\u5012\u3067\u3057\u3087\u3046\u304C]\u3048\u3093\u3069\u3055\u30934\u56DE\u751F\u3067\u3059\u3088",
  "id" : 348700177017749505,
  "in_reply_to_status_id" : 348698418882936832,
  "created_at" : "2013-06-23 07:12:55 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348697998022287360",
  "text" : "\u30DB\u30C6\u30EB\u306B\u4F4F\u307F\u305F\u3044\u3068\u601D\u3063\u305F\u3053\u3068\u306A\u3044\u3067\u3059\u304B\u305D\u3046\u3067\u3059\u304B",
  "id" : 348697998022287360,
  "created_at" : "2013-06-23 07:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348693336292474881",
  "text" : "\u30D3\u30FC\u30CA\u30B9\u30D5\u30A9\u30FC\u30C8\u306E\u4E8C\u968E\u306A",
  "id" : 348693336292474881,
  "created_at" : "2013-06-23 06:45:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348692748787912706",
  "text" : "\u306A\u3093\u304B\u9A12\u304C\u3057\u3044\u3068\u601D\u3063\u305F\u3089\u30D9\u30EA\u30FC\u30BA\u5DE5\u623F\u304C\u30E9\u30A4\u30D6\u3084\u3063\u3066\u308B",
  "id" : 348692748787912706,
  "created_at" : "2013-06-23 06:43:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348671216724344833",
  "text" : "\u30D3\u30C3\u30AF\u30B5\u30A4\u30C8\u3067\u5451\u6C17\u306B\u8CB7\u3044\u7269\u3068\u304B\u3057\u3066\u3093\u5834\u5408\u3058\u3083\u306A\u3044[\u8AAC\u660E\u4F1A\u307F\u305F\u3044\u306E\u3084\u3063\u3066\u3066\u76EE\u3092\u9038\u3089\u3059\u8A71]",
  "id" : 348671216724344833,
  "created_at" : "2013-06-23 05:17:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348670687298326528",
  "text" : "\u30E1\u30A4\u30AF \u30CE\u30FC \u30BB\u30F3\u30B9",
  "id" : 348670687298326528,
  "created_at" : "2013-06-23 05:15:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348670378354286593",
  "text" : "\u6247\u5B50\u3068\u304B\u8CB7\u3063\u305F",
  "id" : 348670378354286593,
  "created_at" : "2013-06-23 05:14:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348468986159190017",
  "geo" : { },
  "id_str" : "348483322319630336",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u3044\u3044\u305F\u3044\u3053\u3068\u306A\u3093\u3066\u306A\u3044",
  "id" : 348483322319630336,
  "in_reply_to_status_id" : 348468986159190017,
  "created_at" : "2013-06-22 16:51:13 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348466386932211714",
  "text" : "\u9593\u9055\u3063\u3066\u306A\u3044\u304C\u9593\u9055\u3063\u3066\u3044\u308B\u611F\u3058\u304C\u3059\u308B\u3002[\u7D75\u306B\u63CF\u3044\u305F\u3088\u3046\u306A\u9905]",
  "id" : 348466386932211714,
  "created_at" : "2013-06-22 15:43:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348466259869962240",
  "text" : "\u606F\u3092\u3059\u308B\u3088\u3046\u306B\u606F\u3092\u5438\u3063\u3066\u3044\u308B\u3057\u606F\u3092\u3059\u308B\u3088\u3046\u306B\u606F\u3092\u5410\u3044\u3066\u3044\u308B\u3088",
  "id" : 348466259869962240,
  "created_at" : "2013-06-22 15:43:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348465284308410368",
  "text" : "\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u306E\u3046\u3093\u306C\u3093\u307B\u3068\u3093\u3069\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u305F\u304C\u6F0F\u308C\u3066\u305F\u6570\u4EBA\u3092\u9069\u5F53\u306B\u30D5\u30A9\u30FC\u30ED\u3057\u307E",
  "id" : 348465284308410368,
  "created_at" : "2013-06-22 15:39:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348462680379645952",
  "text" : "\u307E\u3041\u81EA\u793E\u30D6\u30E9\u30F3\u30C9\u306E\u3084\u3064\u306F\u3042\u3093\u307E\u308A\u7F8E\u5473\u3057\u304F\u306A\u3044\u3068\u601D\u3063\u3066\u307E\u3059\u3051\u3069",
  "id" : 348462680379645952,
  "created_at" : "2013-06-22 15:29:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348462602373980160",
  "text" : "\u51CD\u9802\u70CF\u9F8D\u8336\u98F2\u3093\u3067\u305F\u3089\u300C\u3042\u308C\uFF1F\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u3058\u3083\u306A\u3044\u306E\uFF1F\u300D\u3063\u3066\u717D\u3089\u308C\u305F\u3051\u3069\u5225\u306B\u30B5\u30F3\u30C8\u30EA\u30FC\u70CF\u9F8D\u8336\u4E00\u5143\u4E3B\u7FA9\u3067\u306F\u306A\u3044\u3067\u3059",
  "id" : 348462602373980160,
  "created_at" : "2013-06-22 15:28:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348461667736252416",
  "text" : "\u9AEA\u306E\u6BDB\u304C\u4E7E\u304B\u306A\u3044\u3001\u3064\u307E\u308A\u3001\u9AEA\u306E\u6BDB\u306F\u305D\u3053\u306B\u3042\u308B",
  "id" : 348461667736252416,
  "created_at" : "2013-06-22 15:25:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348460727314554880",
  "text" : "\u3046\u3057\u3046\u3057\u8A95\u751F\u65E5\u304A\u3081\u3069\u3066\u3046\uFF01\uFF01\uFF01",
  "id" : 348460727314554880,
  "created_at" : "2013-06-22 15:21:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348453616442540032",
  "text" : "\u4ED6\u4EBA\u306E\u4E0D\u5E78\u306F\u5B9F\u969B\u304A\u3044\u3057\u3044",
  "id" : 348453616442540032,
  "created_at" : "2013-06-22 14:53:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348453559492308992",
  "text" : "\u75F4\u8A71\u55A7\u5629\u3057\u3066\u308B\u3081\u3044\u305F\u30AB\u30C3\u30D7\u30EB\u304C\u5C45\u3066\u30EF\u30AF\u30EF\u30AF\u3057\u3066\u308B",
  "id" : 348453559492308992,
  "created_at" : "2013-06-22 14:52:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 0, 8 ],
      "id_str" : "57847957",
      "id" : 57847957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348453090560704512",
  "geo" : { },
  "id_str" : "348453341010984960",
  "in_reply_to_user_id" : 57847957,
  "text" : "@ninetan \u3082\u3046\u3061\u3087\u3063\u3068\u9811\u5F35\u308C\u3088\u70CF\u9F8D\u8336\u3060\u3088",
  "id" : 348453341010984960,
  "in_reply_to_status_id" : 348453090560704512,
  "created_at" : "2013-06-22 14:52:05 +0000",
  "in_reply_to_screen_name" : "ninetan",
  "in_reply_to_user_id_str" : "57847957",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 0, 8 ],
      "id_str" : "57847957",
      "id" : 57847957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348452586849964032",
  "geo" : { },
  "id_str" : "348453036747800578",
  "in_reply_to_user_id" : 57847957,
  "text" : "@ninetan \u70CF\u9F8D\u8336\u3060",
  "id" : 348453036747800578,
  "in_reply_to_status_id" : 348452586849964032,
  "created_at" : "2013-06-22 14:50:52 +0000",
  "in_reply_to_screen_name" : "ninetan",
  "in_reply_to_user_id_str" : "57847957",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348452963024510976",
  "text" : "\u6E80\u6708\u304C\u30D5\u30EB\u30E0\u30FC\u30F3( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 348452963024510976,
  "created_at" : "2013-06-22 14:50:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 0, 8 ],
      "id_str" : "57847957",
      "id" : 57847957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348452331798536192",
  "geo" : { },
  "id_str" : "348452477726765056",
  "in_reply_to_user_id" : 57847957,
  "text" : "@ninetan \u70CF\u9F8D\u8336\u98F2\u307F\u305F\u3044",
  "id" : 348452477726765056,
  "in_reply_to_status_id" : 348452331798536192,
  "created_at" : "2013-06-22 14:48:39 +0000",
  "in_reply_to_screen_name" : "ninetan",
  "in_reply_to_user_id_str" : "57847957",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348452259044130816",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 348452259044130816,
  "created_at" : "2013-06-22 14:47:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348452232750047233",
  "text" : "\u7720\u305F\u307F\u304C\u9759\u304B\u306B\u7720\u3044",
  "id" : 348452232750047233,
  "created_at" : "2013-06-22 14:47:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348450211565293569",
  "text" : "\u306A\u304A\u5409\u7965\u5BFA\u304B\u3089\u306E\u96FB\u8ECA\u3082\u3042\u308B\u6A21\u69D8",
  "id" : 348450211565293569,
  "created_at" : "2013-06-22 14:39:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348449806328426496",
  "text" : "\u7121\u4E8B\u3067\u308C\u305F",
  "id" : 348449806328426496,
  "created_at" : "2013-06-22 14:38:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348448992952201216",
  "text" : "\u554F\u984C\u306F\u5409\u7965\u5BFA\u304B\u3089\u306E\u96FB\u8ECA\u304C\u306A\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u3053\u3068\u3060\u306A\uFF1F[\u7D42\u96FB\u6982\u5FF5\u306E\u6B20\u843D]",
  "id" : 348448992952201216,
  "created_at" : "2013-06-22 14:34:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348448814484557825",
  "text" : "(\u6700\u60AA\u53CB\u4EBA\u3092\u53E3\u5BC4\u305B\u3059\u308B)",
  "id" : 348448814484557825,
  "created_at" : "2013-06-22 14:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348448579691618304",
  "text" : "\u3053\u306E\u6642\u9593\u3060\u3057ATM\u3084\u3063\u3066\u306A\u304B\u3063\u305F\u3089\u6B7B\u306C\u304B\u3082\u3057\u308C\u3093\u306A\uFF1F",
  "id" : 348448579691618304,
  "created_at" : "2013-06-22 14:33:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348448429686521856",
  "text" : "\u5409\u7965\u5BFA\u3067\u964D\u308A\u308B\u3051\u3069\u3053\u308CICOCA\u306E\u4E2D\u8DB3\u308A\u3066\u308B\u306E\u304B\u306A(\u30B4\u30B4\u30B4\u30B4\u30B4",
  "id" : 348448429686521856,
  "created_at" : "2013-06-22 14:32:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348409948625059841",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 348409948625059841,
  "created_at" : "2013-06-22 11:59:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348332151818838016",
  "text" : "\u3072\u3069\u304B\u308D\u3046\u3068\u3072\u3069\u304F\u306A\u304B\u308D\u3046\u3068\u3001TL\u3092\u4F5C\u3063\u305F\u306E\u306F\"\"\"\"\u304A\u524D\u81EA\u8EAB\"\"\"\"\u3060",
  "id" : 348332151818838016,
  "created_at" : "2013-06-22 06:50:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348331106262736896",
  "text" : "\u3046\u3068\u3063\u2026",
  "id" : 348331106262736896,
  "created_at" : "2013-06-22 06:46:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348328451486396416",
  "text" : "\u50D5\u306F\u60AA\u304F\u306A\u3044",
  "id" : 348328451486396416,
  "created_at" : "2013-06-22 06:35:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348325629139234817",
  "text" : "#\u306F\u3044",
  "id" : 348325629139234817,
  "created_at" : "2013-06-22 06:24:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348325535102943232",
  "text" : "\u30C1\u30E3\u30C1\u30E3\u30C1\u30E3\u266A",
  "id" : 348325535102943232,
  "created_at" : "2013-06-22 06:24:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348325454240956417",
  "text" : "\u4E0B\u624B\u306A\u9244\u7832\u6570\u6253\u3061\u3083\u30C1\u30E3\u30C1\u30E3\u30C1\u30E3",
  "id" : 348325454240956417,
  "created_at" : "2013-06-22 06:23:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348323982275117057",
  "text" : "hogehoge\u3092\u3072\u306D\u308B\u3068hugahuga\u304C\u51FA\u3066\u304F\u308B:\u30C6\u30F3\u30D7\u30EC",
  "id" : 348323982275117057,
  "created_at" : "2013-06-22 06:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348323905825554433",
  "text" : "\u30CD\u30BF\u3092\u3072\u306D\u308B\u3068\u7B11\u3044\u6B7B\u306C\u4EBA\u304C\u51FA\u3066\u304F\u308B",
  "id" : 348323905825554433,
  "created_at" : "2013-06-22 06:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348323229527576577",
  "text" : "\u9999\u5DDD\u3067\u306F\u3046\u3069\u3093\u3092\u3072\u306D\u308B\u3068\u30B3\u30B7\u304C\u3067\u3066\u304F\u308B",
  "id" : 348323229527576577,
  "created_at" : "2013-06-22 06:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348323060492931073",
  "text" : "\u30DE\u30B8\u30B7\u30E3\u30F3\u300C\u3044\u307E\u304B\u3089\u3053\u306E\u6D88\u3057\u30D1\u30F3\u3092\u4F7F\u3063\u3066\u3053\u306E\u7F8E\u5973\u3092\u6D88\u3057\u3066\u898B\u305B\u307E\u3059\u300D",
  "id" : 348323060492931073,
  "created_at" : "2013-06-22 06:14:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348322607730413569",
  "geo" : { },
  "id_str" : "348322934969999361",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6D88\u3057\u30B4\u30E0\u7684\u306B\u4F7F\u308F\u308C\u308B\u6D88\u3057\u30D1\u30F3\u3063\u3066\u306E\u304C\u3042\u3063\u3066\u306D",
  "id" : 348322934969999361,
  "in_reply_to_status_id" : 348322607730413569,
  "created_at" : "2013-06-22 06:13:53 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348322647110742017",
  "text" : "\u50D5\u306F\u51B7\u9EA6\u306E\u307B\u3046\u304C\u597D\u304D",
  "id" : 348322647110742017,
  "created_at" : "2013-06-22 06:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348322148244398080",
  "text" : "\u6728\u3092\u898B\u3066\u68EE\u3092\u6C34",
  "id" : 348322148244398080,
  "created_at" : "2013-06-22 06:10:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348321828848164864",
  "text" : "\u65E5\u5E38\u3067\u305D\u3046\u3081\u3093\u304C\u5165\u3063\u3066\u3044\u306A\u3044\u72B6\u614B\u3067\u6D41\u308C\u308B\u6C34\u3092\u76EE\u306B\u3059\u308B\u6A5F\u4F1A\u306A\u3093\u3066\u306A\u3044\u304B\u3089\u306A\u3041",
  "id" : 348321828848164864,
  "created_at" : "2013-06-22 06:09:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348321690612297731",
  "text" : "\u6C34\u306F\u305D\u3046\u3081\u3093\u304C\u306A\u304F\u3066\u3082\u6D41\u308C\u308B\u3068\u304B\u6C17\u304C\u4ED8\u304B\u306A\u304B\u3063\u305F",
  "id" : 348321690612297731,
  "created_at" : "2013-06-22 06:08:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348320966205648897",
  "text" : "\u3069\u306E\u3066\u3093\u3060\u308D\u3046",
  "id" : 348320966205648897,
  "created_at" : "2013-06-22 06:06:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348320930084306944",
  "text" : "\u305D\u306E\u70B9\u3072\u3084\u3080\u304E\u306F\u304A\u3044\u3057\u3044",
  "id" : 348320930084306944,
  "created_at" : "2013-06-22 06:05:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348320646238973952",
  "text" : "\u6D41\u3057\u305D\u3046\u3081\u3093\u306F\u6C34\u3092\u6D41\u3059\u305F\u3081\u306B\u5B58\u5728\u3059\u308B\uFF1F",
  "id" : 348320646238973952,
  "created_at" : "2013-06-22 06:04:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348320356358045698",
  "geo" : { },
  "id_str" : "348320555419705344",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3042\u308C\u306F\u6C34\u3092\u98F2\u3080\u904A\u3073\u306A\u306E\u3067\u306F[\u305D\u3046\u3081\u3093\u304C\u5A92\u4ECB]",
  "id" : 348320555419705344,
  "in_reply_to_status_id" : 348320356358045698,
  "created_at" : "2013-06-22 06:04:26 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348316108106891265",
  "text" : "\u6700\u5927\u5916\u79D1\u533B\u3001\u6700\u5C0F\u5185\u79D1\u533B",
  "id" : 348316108106891265,
  "created_at" : "2013-06-22 05:46:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348295030852706304",
  "geo" : { },
  "id_str" : "348311511598514176",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u30E1\u30FC\u30EB\u3057\u305F\u3068\u304A\u308A\u3067\u3042\u308B",
  "id" : 348311511598514176,
  "in_reply_to_status_id" : 348295030852706304,
  "created_at" : "2013-06-22 05:28:30 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348274963981139968",
  "geo" : { },
  "id_str" : "348286277482844161",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u3046\u3048\u30FC\u3044",
  "id" : 348286277482844161,
  "in_reply_to_status_id" : 348274963981139968,
  "created_at" : "2013-06-22 03:48:14 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/qfsF4I1kGe",
      "expanded_url" : "http:\/\/4sq.com\/1a0lraI",
      "display_url" : "4sq.com\/1a0lraI"
    } ]
  },
  "geo" : { },
  "id_str" : "348271812527923201",
  "text" : "I'm at \u30B4\u30FC\u30B4\u30FC\u30AB\u30EC\u30FC \u795E\u4FDD\u753A\u30B9\u30BF\u30B8\u30A2\u30E0 (\u5343\u4EE3\u7530\u533A, \u6771\u4EAC\u90FD) http:\/\/t.co\/qfsF4I1kGe",
  "id" : 348271812527923201,
  "created_at" : "2013-06-22 02:50:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348247058014171136",
  "text" : "\u96FB\u8ECA\u304C\u6DF7\u3093\u3067\u304D\u305F\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u5EA7\u308C\u305F\u3068\u304D\u306E\u30AB\u30C1\u30B0\u30DF=\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2",
  "id" : 348247058014171136,
  "created_at" : "2013-06-22 01:12:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348020269870362624",
  "geo" : { },
  "id_str" : "348020654261559296",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u304A\u304D\u306B\u306A\u3089\u3055\u305A\u30FC",
  "id" : 348020654261559296,
  "in_reply_to_status_id" : 348020269870362624,
  "created_at" : "2013-06-21 10:12:44 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348018383930937344",
  "geo" : { },
  "id_str" : "348019038057811968",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u9045\u3044\u3067\u3059\u3088\u3046",
  "id" : 348019038057811968,
  "in_reply_to_status_id" : 348018383930937344,
  "created_at" : "2013-06-21 10:06:19 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348017390614872064",
  "text" : "\u300C\u305D\u308C\u3001\u9762\u767D\u3044\u3068\u601D\u3063\u3066\u8A00\u3063\u3066\u308B\u3093\u3067\u3059\u304B\uFF1F\u300D\u3063\u3066\u8A00\u308F\u308C\u3066\u3082\u300C\u3044\u3048\u3001\u4F55\u3082\u8003\u3048\u305A\u306B\u558B\u3063\u3066\u3044\u307E\u3059\u300D\u3063\u3066\u8A00\u3048\u308B\u5F37\u307F",
  "id" : 348017390614872064,
  "created_at" : "2013-06-21 09:59:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348015836998553600",
  "text" : "\u3057\u3093\u3058\u304F\u3067\u3060\u3044\u3076\u3072\u3068\u3075\u3048\u305F",
  "id" : 348015836998553600,
  "created_at" : "2013-06-21 09:53:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348013417442979840",
  "text" : "\u306A\u3093\u3067\u65B0\u5E79\u7DDA\u3068\u304B\u3044\u3046\u30AB\u30C1\u30B0\u30DF\u30D3\u30FC\u30AF\u30EB\u3067\u79FB\u52D5\u3057\u3066\u3093\u306E\u306B\u75B2\u308C\u308B\u306E\u304B\u306A\u2026[\u305D\u308A\u3083\u307E\u3041\u591C\u884C\u30D0\u30B9\u3068\u306F\u6BD4\u3079\u7269\u306B\u306A\u3089\u306A\u3044\u3067\u3059\u3051\u308C\u3069]",
  "id" : 348013417442979840,
  "created_at" : "2013-06-21 09:43:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348012717312974848",
  "text" : "\u5BB6\u306B\u307E\u3060\u534A\u30C0\u30FC\u30B9\u307B\u3069\u3042\u308B\u3051\u308C\u3069",
  "id" : 348012717312974848,
  "created_at" : "2013-06-21 09:41:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348012639131168768",
  "text" : "\u3061\u306A\u307F\u306B\u50D5\u304C\u597D\u304D\u3060\u3063\u305F\u307A\u3093\u3066\u308B\u306E\u30D6\u30E9\u30C3\u30AF\u30DD\u30EA\u30DE\u30FC999\u3068\u3044\u3046\u925B\u7B46\u306F\u3082\u3046\u751F\u7523\u3057\u3066\u306A\u3044\u3089\u3057\u304F\u3066\u6D99",
  "id" : 348012639131168768,
  "created_at" : "2013-06-21 09:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348012412131221504",
  "text" : "\u80F8\u30DD\u30B1\u30C3\u30C8\u306B\u925B\u7B46\u304C\u5165\u3063\u3066\u308B\u306E\u306A\u3093\u304B\u3084\u3070\u3044",
  "id" : 348012412131221504,
  "created_at" : "2013-06-21 09:39:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348008229445443584",
  "text" : "\u3082\u3046\u54C1\u5DDD",
  "id" : 348008229445443584,
  "created_at" : "2013-06-21 09:23:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347998966031478784",
  "text" : "\u53F0\u98A8\u304B\u3089\u65B0\u5E79\u7DDA\u3067\u9003\u3052\u308B\u30E9\u30A4\u30D5\u30CF\u30C3\u30AF[\uFF1F]",
  "id" : 347998966031478784,
  "created_at" : "2013-06-21 08:46:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3079\u306B\u3070\u306A\uFF201\u56DE\u751F",
      "screen_name" : "CcreticusL",
      "indices" : [ 0, 11 ],
      "id_str" : "407066804",
      "id" : 407066804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347998224373653504",
  "geo" : { },
  "id_str" : "347998384965156865",
  "in_reply_to_user_id" : 407066804,
  "text" : "@CcreticusL \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 347998384965156865,
  "in_reply_to_status_id" : 347998224373653504,
  "created_at" : "2013-06-21 08:44:15 +0000",
  "in_reply_to_screen_name" : "CcreticusL",
  "in_reply_to_user_id_str" : "407066804",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347998013211414528",
  "text" : "\u306A\u3093\u304B\u7A93\u306E\u5916\u4E16\u754C\u306E\u7D42\u308F\u308A of the world\u307F\u305F\u3044\u306B\u306A\u3063\u3066\u308B",
  "id" : 347998013211414528,
  "created_at" : "2013-06-21 08:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347997857200078848",
  "text" : "\u9055\u6CD5\u30AB\u30AD\u30CE\u30BF\u30CD",
  "id" : 347997857200078848,
  "created_at" : "2013-06-21 08:42:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347997785892737024",
  "text" : "\u30C9\u30FC\u30CA\u30C4\u3086\u3063\u304F\u308A\u98DF\u3079\u3066\u305F\u3089\u5869\u5473\u304C\u6B32\u3057\u304F\u306A\u3063\u305F\u306A\uFF1F",
  "id" : 347997785892737024,
  "created_at" : "2013-06-21 08:41:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347996462413647872",
  "geo" : { },
  "id_str" : "347997543973679104",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u6708\u66DC\u306B\u306F\u5E30\u308B\u3088",
  "id" : 347997543973679104,
  "in_reply_to_status_id" : 347996462413647872,
  "created_at" : "2013-06-21 08:40:54 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347996296860295168",
  "text" : "\u5C71\u304C\u3059\u3054\u3044\u7159\u3063\u3066\u308B\u2026\u9744\uFF1F\u9727\uFF1F",
  "id" : 347996296860295168,
  "created_at" : "2013-06-21 08:35:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347994433259716608",
  "geo" : { },
  "id_str" : "347995384834048000",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u305D\u308C\u306B\u30CE\u30FC\u30C8\u30D1\u30BD\u30B3\u30F3\u3068iPad\u8DB3\u3057\u305F\u611F\u3058",
  "id" : 347995384834048000,
  "in_reply_to_status_id" : 347994433259716608,
  "created_at" : "2013-06-21 08:32:19 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347977333883424768",
  "text" : "\u3084\u3063\u3071\u308A\u30C1\u30E7\u30B3\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u304C\u7F8E\u5473\u3044",
  "id" : 347977333883424768,
  "created_at" : "2013-06-21 07:20:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347975685995913216",
  "text" : "\u3055\u30FC\u3066\u70CF\u9F8D\u8336\u98F2\u307F\u3064\u3064\u30C9\u30FC\u30CA\u30C4\u98DF\u3079\u3064\u3064\u82F1\u8A9E\u306E\u6587\u7AE0\u3092\u3060\u306A\u2026",
  "id" : 347975685995913216,
  "created_at" : "2013-06-21 07:14:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347975360882831360",
  "text" : "\u901F\u5831:\u3048\u3093\u3069\u6C0F\u306E\u5EA7\u5E2D\u3001\u65B0\u5E79\u7DDA\u306E\u4E00\u756A\u524D\u306E\u5E2D\u306E\u7A93\u5074",
  "id" : 347975360882831360,
  "created_at" : "2013-06-21 07:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347959552865611776",
  "text" : "\u4FFA\u6C0F\u3001\u4FFA\u6C0F\u53F2\u4E0A\u6700\u3082\u8EFD\u88C5\u3067\u306E\u5E30\u7701\u3092\u958B\u59CB",
  "id" : 347959552865611776,
  "created_at" : "2013-06-21 06:09:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347938414894665728",
  "geo" : { },
  "id_str" : "347959196727263232",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u3059\u307F\u307E\u305B\u3093\u3001\u6765\u9031\u306E\u539F\u7A3F\u304C\u3044\u308D\u3044\u308D\u307E\u3068\u307E\u3063\u3066\u306A\u304F\u3066\u6C17\u4ED8\u3044\u305F\u3089\u6642\u9593\u3059\u304E\u3066\u3066\u3042\u30FC\u3068\u3044\u3046\u611F\u3058\u3067\u3057\u305F",
  "id" : 347959196727263232,
  "in_reply_to_status_id" : 347938414894665728,
  "created_at" : "2013-06-21 06:08:31 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347924823588085760",
  "text" : "\u30B5\u30F3\u30C8\u30EA\u30FC\u70CF\u9F8D\u8336\u306F\u98F2\u307F\u5E72\u3059\u3068\u306A\u304F\u306A\u3063\u3066\u3057\u307E\u3046\u70B9\u3060\u3051\u304C\u6C17\u306B\u5165\u3089\u306A\u3044\u3001\u3042\u306E\u30D7\u30ED\u30D1\u30C6\u30A3\u306F\u3069\u3046\u8003\u3048\u3066\u3082\u8A2D\u8A08\u30DF\u30B9\u3002",
  "id" : 347924823588085760,
  "created_at" : "2013-06-21 03:51:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347924598957948929",
  "text" : "\u5B09\u3057\u3044",
  "id" : 347924598957948929,
  "created_at" : "2013-06-21 03:51:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347924533149315076",
  "text" : "\u56DB\u9650\u4F11\u8B1B\u3041\u3041\u3041\u3041\u3049\u3047\u3041\u3043\u3041\u3041\u3041\u3041\uFF01\uFF01\uFF01\u308C\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 347924533149315076,
  "created_at" : "2013-06-21 03:50:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347918193865682945",
  "text" : "\u30AC\u30ED\u30A2\u796D\u306B\u884C\u304F\u3068\u30AC\u30ED\u30A2\u62E1\u5927\u3055\u308C\u3066\u3057\u307E\u3046\uFF1F",
  "id" : 347918193865682945,
  "created_at" : "2013-06-21 03:25:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347918102811533312",
  "text" : "\u30ED\u30FC\u30EC\u30F3\u30C4\u796D\u306B\u884C\u304F\u3068\u30ED\u30FC\u30EC\u30F3\u30C4\u5909\u63DB\u3055\u308C\u3066\u3057\u307E\u3046\u3068\u805E\u304D\u307E\u3057\u305F",
  "id" : 347918102811533312,
  "created_at" : "2013-06-21 03:25:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347685173850144768",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 347685173850144768,
  "created_at" : "2013-06-20 11:59:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347560735271952386",
  "text" : "\u4F55\u3082\u3057\u3066\u306A\u3044\u306E\u306B\u30D1\u30BD\u30B3\u30F3\u304C\u6CBB\u3063\u305F\uFF01\uFF01",
  "id" : 347560735271952386,
  "created_at" : "2013-06-20 03:45:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347560655412424704",
  "text" : "\u60C5\u5F31\u3060\u304B\u3089\u554F\u984C\u89E3\u6C7A\u3057\u3066\u3082\u8CE2\u304F\u306A\u3089\u306A\u3044\u3053\u3068\u304C\u3042\u308B[\u306A\u305C\u304B\u6CBB\u3063\u305F]",
  "id" : 347560655412424704,
  "created_at" : "2013-06-20 03:44:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347560547669131264",
  "text" : "\u3042\u3001\u306A\u3093\u304B\u306E\u62CD\u5B50\u306B\u52D5\u3044\u305F\u3002",
  "id" : 347560547669131264,
  "created_at" : "2013-06-20 03:44:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347557215152005121",
  "text" : "bamear\u8A73\u3057\u3044\u4EBA\u5C45\u307E\u305B\u3093\u304B\u2026\u30A8\u30E9\u30FC\u5410\u304D\u6563\u3089\u3057\u305F\u3042\u3052\u304Fpdf\u306Fdvi\u306E\u6BB5\u968E\u3067\u6587\u5B57\u5316\u3051\u3057\u3066\u308B\u306E\u3067\u3059\u304C\u2026",
  "id" : 347557215152005121,
  "created_at" : "2013-06-20 03:31:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347194360036741120",
  "text" : "\u30AD\u30E3\u30D0\u30FC\u30F3\uFF01",
  "id" : 347194360036741120,
  "created_at" : "2013-06-19 03:29:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346960471666089984",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 346960471666089984,
  "created_at" : "2013-06-18 11:59:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346731757409796097",
  "text" : "\u3046\u3075\u3075\u3075\u3075\u3075\u3075\u3001\u8D77\u304D\u3066\u307E\u3059\u3088\uFF5E(^^)(^^)(^^)",
  "id" : 346731757409796097,
  "created_at" : "2013-06-17 20:51:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "indices" : [ 0, 9 ],
      "id_str" : "105498380",
      "id" : 105498380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346595325475172353",
  "in_reply_to_user_id" : 105498380,
  "text" : "@_Nururin DM\u3057\u307E\u3057\u305F",
  "id" : 346595325475172353,
  "created_at" : "2013-06-17 11:48:59 +0000",
  "in_reply_to_screen_name" : "_Nururin",
  "in_reply_to_user_id_str" : "105498380",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346521347494662145",
  "text" : "\u30CF\u30EA\u30CD\u30BA\u30DF",
  "id" : 346521347494662145,
  "created_at" : "2013-06-17 06:55:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346474473790251008",
  "text" : "\u9762\u767D\u3044\u306F\u7406\u4E0D\u5C3D\u3001\u7406\u4E0D\u5C3D\u306F\u9762\u767D\u3044",
  "id" : 346474473790251008,
  "created_at" : "2013-06-17 03:48:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346472767320907776",
  "text" : "\u30DE\u30AF\u30EC\u30FC\u30F3\u306E\u82F1\u8A9E\u3001\u8D85\u8AAD\u307F\u3084\u3059\u3044",
  "id" : 346472767320907776,
  "created_at" : "2013-06-17 03:41:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346463919436595201",
  "text" : "\u3080\u3057\u308D\u3082\u3046\u3001\u3044\u307E\u306E\u4EE5\u5916\u306A\u3057",
  "id" : 346463919436595201,
  "created_at" : "2013-06-17 03:06:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346463804818866176",
  "text" : "\u3044\u307E\u306E\u306A\u3057",
  "id" : 346463804818866176,
  "created_at" : "2013-06-17 03:06:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346463781171388416",
  "text" : "\u610F\u56F3\u304C\u306A\u3044\u304B\u3089\u3044\u3068\u53EF\u7B11\u3057",
  "id" : 346463781171388416,
  "created_at" : "2013-06-17 03:06:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346461232074727425",
  "text" : "\u50D5\u306F\u4FE1\u3058\u3066\u5F85\u3063\u3066\u3044\u307E\u3059\u3088(\u5727\u529B)",
  "id" : 346461232074727425,
  "created_at" : "2013-06-17 02:56:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346461151468584960",
  "text" : "\u30B5\u30F3\u30C0\u30FC\u30D5\u30A3\u30B9\u30C8\u2026",
  "id" : 346461151468584960,
  "created_at" : "2013-06-17 02:55:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346436195267530752",
  "text" : "\uFF08\u300C\u9055\u548C\u611F\u300D\u2026\u2026\u2026\u3044\u308F\u304B\u3093\u2026\u2026\u2026\u899A\u3048\u307E\u3057\u305F\u3057)",
  "id" : 346436195267530752,
  "created_at" : "2013-06-17 01:16:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346298395209641984",
  "text" : "\u81EA\u5206\u306EFacebook\u306E\u6295\u7A3F\u3001\u672C\u5F53\u306B\u30ED\u30AF\u306A\u4E8B\u304C\u66F8\u3044\u3066\u306A\u304F\u3066\u3001\u305D\u3046\u3044\u3046\u306E\u3092\u8A87\u308A\u306B\u3057\u3066\u884C\u3053\u3046\u3068\u601D\u3046",
  "id" : 346298395209641984,
  "created_at" : "2013-06-16 16:09:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346296762589401088",
  "text" : "\u3068\u307D\uFF5E",
  "id" : 346296762589401088,
  "created_at" : "2013-06-16 16:02:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346262941571637248",
  "geo" : { },
  "id_str" : "346263156789743616",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u7389\u9732\u56DE\u3060\u3051\u5B9F\u6CC1\u3057\u3066\u305F\u3089\u76EE\u7ACB\u3064\u304C\u3057\u3087\u3063\u3061\u3085\u3046\u3084\u3063\u3066\u308B\u3058\u3083\u3093www",
  "id" : 346263156789743616,
  "in_reply_to_status_id" : 346262941571637248,
  "created_at" : "2013-06-16 13:49:04 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346262685916209154",
  "geo" : { },
  "id_str" : "346262834574925825",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u307B\u3046\u2026[\u601D\u3048\u3070\u524D\u304B\u3089\u304A\u8336\u8981\u7D20\u306A\u304B\u3063\u305F\u6C17\u3082]",
  "id" : 346262834574925825,
  "in_reply_to_status_id" : 346262685916209154,
  "created_at" : "2013-06-16 13:47:47 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346262556261904384",
  "text" : "@lgcisvlc \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30C9\u30AF\u30DA\uFF01",
  "id" : 346262556261904384,
  "created_at" : "2013-06-16 13:46:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346262475043377152",
  "text" : "\u307E\u3046\u3061\u3083\u304B\u3089\u304A\u8336\u8981\u7D20\u304C\u6D88\u3048\u3066\u4E45\u3057\u3044",
  "id" : 346262475043377152,
  "created_at" : "2013-06-16 13:46:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346261665874079744",
  "text" : "Twitter\u3067\u306F\u708E\u4E0A\u3057\u306A\u3044\u7A0B\u5EA6\u306B\u66B4\u308C\u305F\u3089\u826F\u3044\u306E\u3067\u3059",
  "id" : 346261665874079744,
  "created_at" : "2013-06-16 13:43:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346261589881679874",
  "text" : "\u307E\u3041\u30EA\u30A2\u30EB\u3060\u3063\u305F\u3089\u826F\u5FC3\u3042\u308B\u4EBA\u304C\"\u305D\u306E\u8A71\u984C\u306F\/\u8A00\u8449\u9063\u3044\u306F\u826F\u304F\u306A\u3044\u3088\"\u3063\u3066\u8A00\u3063\u3066\u304F\u308C\u308B\u306F\u305A\u3060\u3057",
  "id" : 346261589881679874,
  "created_at" : "2013-06-16 13:42:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346261323715317760",
  "geo" : { },
  "id_str" : "346261383249276928",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305D\u308C\u304C\u826F\u3044\u3068\u601D\u308F\u308C\u307E\u3057",
  "id" : 346261383249276928,
  "in_reply_to_status_id" : 346261323715317760,
  "created_at" : "2013-06-16 13:42:01 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346261261278904320",
  "text" : "\u30C9\u30AF\u30DA\u30FC\u30BF\u30C3\u30D1\u30FC\u98F2\u3080",
  "id" : 346261261278904320,
  "created_at" : "2013-06-16 13:41:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346260977907552256",
  "text" : "\u30AB\u30EC\u30FC\u304C\u6B7B\u306C\u307B\u3069\u5ACC\u3044\u3067\u30AB\u30EC\u30FC\u306E\u5302\u3044\u3092\u55C5\u3044\u3060\u3060\u3051\u3067\u3058\u3093\u307E\u3057\u3093\u304C\u3067\u308B\u4EBA\u306B\u306F\u30AB\u30EC\u30FC\u306E\u8A71\u3067\u304D\u306A\u3044\u3057\u306A\u2026",
  "id" : 346260977907552256,
  "created_at" : "2013-06-16 13:40:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346260480890912769",
  "geo" : { },
  "id_str" : "346260860634816512",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305D\u306E\u7A0B\u5EA6\u306E\u30EF\u30FC\u30C9\u306B\u53CD\u5FDC\u3057\u3061\u3083\u3046\u306E\u306F\u305D\u306E\u4EBA\u306B\u554F\u984C\u304C\u3042\u308B\u3088\u3046\u306A\u6C17\u3082\u3057\u307E\u3059\u304C\u2026[\u307F\u3093\u306A\u304C\u7D76\u5BFE\u5FC3\u5730\u3044\u3044\u8A71\u984C\u3063\u3066\u96E3\u3057\u3044\u3067\u3059\u3057]",
  "id" : 346260860634816512,
  "in_reply_to_status_id" : 346260480890912769,
  "created_at" : "2013-06-16 13:39:57 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346260032469487617",
  "geo" : { },
  "id_str" : "346260230507745280",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u6027\u306B\u95A2\u308F\u308B\u30B3\u30F3\u30C6\u30F3\u30C4\u304B\u3082\u3067\u3059\u304C\u6027\u7684\u306A\u3082\u306E\u3067\u306F\u7121\u3044\u3088\u3046\u306A\u2026\u7DDA\u5F15\u304D\u304C\u96E3\u3057\u3044\u3067\u3059\u304C[\u307E\u3041\u4E2D\u5B66\u751F\u3068\u304B\u306A\u3089\u559C\u3073\u307E\u3059\u3051\u308C\u3069]",
  "id" : 346260230507745280,
  "in_reply_to_status_id" : 346260032469487617,
  "created_at" : "2013-06-16 13:37:26 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346259500107436032",
  "geo" : { },
  "id_str" : "346259635629592576",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3068\u3044\u3046\u304B\u30B3\u30F3\u30C9\u30FC\u30E0\u3063\u3066\u6027\u7684\u306A\u5185\u5BB9\u306A\u3093\u3067\u3059\uFF1F[\uFF1F]",
  "id" : 346259635629592576,
  "in_reply_to_status_id" : 346259500107436032,
  "created_at" : "2013-06-16 13:35:04 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 3, 11 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346259381593190401",
  "text" : "RT @chr1233: \u81EA\u5206\u306E\u7BA1\u7406\u4E0B\u306B\u306A\u3044\u4EBA\u9593\u306F\u4FE1\u7528\u3057\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346259309186928640",
    "text" : "\u81EA\u5206\u306E\u7BA1\u7406\u4E0B\u306B\u306A\u3044\u4EBA\u9593\u306F\u4FE1\u7528\u3057\u306A\u3044",
    "id" : 346259309186928640,
    "created_at" : "2013-06-16 13:33:47 +0000",
    "user" : {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "protected" : false,
      "id_str" : "145536184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604587837543948289\/EBLw8dtv_normal.jpg",
      "id" : 145536184,
      "verified" : false
    }
  },
  "id" : 346259381593190401,
  "created_at" : "2013-06-16 13:34:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346259255134916611",
  "text" : "\uFF1F",
  "id" : 346259255134916611,
  "created_at" : "2013-06-16 13:33:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346259244259102720",
  "text" : "\u81EA\u5206\u306E\u7BA1\u7406\u4E0B\u306B\u306A\u3044Wikipedia\u306F\u4FE1\u7528\u3057\u306A\u3044",
  "id" : 346259244259102720,
  "created_at" : "2013-06-16 13:33:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346259147525853184",
  "text" : "RT @kagakuma: \u300C\u81EA\u5206\u306E\u7BA1\u7406\u4E0B\u306B\u306A\u3044\u30B3\u30F3\u30C9\u30FC\u30E0\u306F\u4FE1\u7528\u3057\u306A\u3044\u300D\u3063\u3066\u5E38\u8B58\u3058\u3083\u306A\u3044\u306E\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346258975030906880",
    "text" : "\u300C\u81EA\u5206\u306E\u7BA1\u7406\u4E0B\u306B\u306A\u3044\u30B3\u30F3\u30C9\u30FC\u30E0\u306F\u4FE1\u7528\u3057\u306A\u3044\u300D\u3063\u3066\u5E38\u8B58\u3058\u3083\u306A\u3044\u306E\uFF1F",
    "id" : 346258975030906880,
    "created_at" : "2013-06-16 13:32:27 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 346259147525853184,
  "created_at" : "2013-06-16 13:33:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346259116374777856",
  "text" : "\u81EA\u5206\u306E\u7BA1\u7406\u4E0B\u306B\u306A\u3044hogehoge\u306F\u4FE1\u7528\u3057\u306A\u3044:\u30C6\u30F3\u30D7\u30EC",
  "id" : 346259116374777856,
  "created_at" : "2013-06-16 13:33:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346258998879727616",
  "text" : "\u70CF\u9F8D\u8336\u306F\u4E00\u65E52L\u307E\u3067\u3060\u306A\u2026",
  "id" : 346258998879727616,
  "created_at" : "2013-06-16 13:32:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346258701423882241",
  "text" : "OHSHO(\u738B\u5C06)\u3082NISHIOISHIN\u3082\u56DE\u6587\u3069\u3053\u308D\u304B\u70B9\u5BFE\u79F0\u3060\u3057\u306A\uFF1F",
  "id" : 346258701423882241,
  "created_at" : "2013-06-16 13:31:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/346256443839750144\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/EfnxkTYalG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM4mZrCCIAAWEmA.jpg",
      "id_str" : "346256443843944448",
      "id" : 346256443843944448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM4mZrCCIAAWEmA.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/EfnxkTYalG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346256443839750144",
  "text" : "\u30AB\u30EC\u30FC http:\/\/t.co\/EfnxkTYalG",
  "id" : 346256443839750144,
  "created_at" : "2013-06-16 13:22:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346255571332263936",
  "text" : "\u30AB\u30EC\u30FC\u6E29\u3081\u3066\u305F\u3079\u308B",
  "id" : 346255571332263936,
  "created_at" : "2013-06-16 13:18:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346255116455792640",
  "text" : "\u66D6\u6627\u3067\u3082\u306A\u3093\u304B\u3067\u898B\u305F\u30CD\u30BF\u3067\u3042\u308B\u3053\u3068\u3092\u5F37\u8ABF\u3059\u3079\u304D\u3060\u306A\uFF1F",
  "id" : 346255116455792640,
  "created_at" : "2013-06-16 13:17:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346254991406817280",
  "text" : "\u3044\u3084\u307E\u3041\u50D5\u3082\u51FA\u5178\u304C\u66D6\u6627\u306A\u30CD\u30BF\u3092\u8A71\u3059\u3053\u3068\u306F\u3042\u308B\u3051\u3069\u3001\u3042\u305F\u304B\u3082\u81EA\u5206\u3067\u8003\u3048\u305F\u3088\u3046\u306B\u30CD\u30BF\u3092\u545F\u304F\u4EBA\u3092\u307F\u308B\u3068\u2026( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D\u3063\u3066\u306A\u308B",
  "id" : 346254991406817280,
  "created_at" : "2013-06-16 13:16:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346250664604729345",
  "text" : "\u30DE\u30E8\u30E9\u30FC\u306B\u5BFE\u3057\u3066\u30B1\u30C1\u30E3\u30C3\u30D1\u30FC\u3068\u304B\u30DA\u30C3\u30D1\u30E9\u30FC\u3068\u304B\u30BD\u30FC\u30B5\u30FC\u3068\u304B\u5C45\u308B",
  "id" : 346250664604729345,
  "created_at" : "2013-06-16 12:59:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346250084989681664",
  "text" : "\uFF1F",
  "id" : 346250084989681664,
  "created_at" : "2013-06-16 12:57:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346250073241427969",
  "text" : "\u30C6\u30F3\u30D7\u30EC\u9063\u3044\u3068\u3057\u3066\u3053\u308C\u304B\u3089\u306F\u30C6\u30F3\u30D7\u30E9\u30FC\u3068\u540D\u4E57\u308B\u304B",
  "id" : 346250073241427969,
  "created_at" : "2013-06-16 12:57:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346249448235626496",
  "text" : "\u3069\u3046\u3042\u304C\u3044\u3066\u3082\u6B7B\u306C",
  "id" : 346249448235626496,
  "created_at" : "2013-06-16 12:54:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346249398151417856",
  "text" : "\u81F4\u6B7B\u91CF\u306E\u30D1\u30BB\u30EA\u3092\u98DF\u3079\u3066\u3082\u6B7B\u306C",
  "id" : 346249398151417856,
  "created_at" : "2013-06-16 12:54:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346249340039352320",
  "text" : "\u81F4\u6B7B\u91CF\u306E\u524D\u83DC\u3092\u98DF\u3079\u308B\u3068\u6B7B\u306C",
  "id" : 346249340039352320,
  "created_at" : "2013-06-16 12:54:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346249219365031936",
  "text" : "\u81F4\u6B7B\u91CF\u306Ehogehoge\u3092\u98F2\u3093\u3060\u3089\u6B7B\u306C:\u30C6\u30F3\u30D7\u30EC",
  "id" : 346249219365031936,
  "created_at" : "2013-06-16 12:53:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346249141120270336",
  "text" : "RT @kagakuma: \u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3042\u3076\u306A\u3044\u3067\u3002\u81F4\u6B7B\u91CF\u306E\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u98F2\u3093\u3060\u3089\u6B7B\u306C\u304B\u3089\u306A\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346248398862688256",
    "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3042\u3076\u306A\u3044\u3067\u3002\u81F4\u6B7B\u91CF\u306E\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u98F2\u3093\u3060\u3089\u6B7B\u306C\u304B\u3089\u306A\u3002",
    "id" : 346248398862688256,
    "created_at" : "2013-06-16 12:50:25 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 346249141120270336,
  "created_at" : "2013-06-16 12:53:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346235737018085376",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 346235737018085376,
  "created_at" : "2013-06-16 12:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346209179930882049",
  "text" : "\u570F\u8AD6\u304C\u3068\u3044\u3046\u304B\u570F\u8AD6\u306E\u6B74\u53F2\u304C\u3001\u3060\u3052\u3069",
  "id" : 346209179930882049,
  "created_at" : "2013-06-16 10:14:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346209030378766336",
  "text" : "\u305D\u308A\u3083\u3042\u305D\u3046\u3060\u308D\u3046\u3088",
  "id" : 346209030378766336,
  "created_at" : "2013-06-16 10:13:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346208985310953472",
  "text" : "\"\u570F\u8AD6\u304C\u306A\u3093\u306A\u306E\u304B\u5B66\u3073\u305F\u3044\u306A\u3089\u30011930\u5E74\u4EE3\u306E\u30C8\u30DD\u30ED\u30B8\u30FC\u3084\u30B0\u30ED\u30BF\u30F3\u30C7\u30A3\u30FC\u30AF\u304B\u3089\u59CB\u3081\u306A\u3044\u65B9\u304C\u826F\u3044\"\u3063\u3066\u8AD6\u6587\u306B\u66F8\u3044\u3066\u3042\u3063\u3066\u8349\u4E0D\u53EF\u907F",
  "id" : 346208985310953472,
  "created_at" : "2013-06-16 10:13:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346204969021603840",
  "text" : "\u554F\u984C\u3092\u898B\u3064\u3051\u306A\u304D\u3083\u3044\u3051\u306A\u3044\u3068\u3044\u3046\u554F\u984C",
  "id" : 346204969021603840,
  "created_at" : "2013-06-16 09:57:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346202538900586497",
  "text" : "\u3057\u304B\u3057\u98A8\u5442\u4E0A\u308A\u306E\u30A6\u30FC\u30ED\u30F3\u8336\u306E\u304A\u3044\u3057\u3055\u3063\u305F\u3089",
  "id" : 346202538900586497,
  "created_at" : "2013-06-16 09:48:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346202402434723841",
  "text" : "\u534A\u8EAB\u306B\u3057\u3068\u304F\u3079\u304D\u3060\u3063\u305F",
  "id" : 346202402434723841,
  "created_at" : "2013-06-16 09:47:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346202289024946176",
  "text" : "20\u5206\u304F\u3089\u3044\u304A\u98A8\u5442\u5165\u3063\u3066\u305F\u3089\u6B7B\u306C\u304B\u3068\u601D\u3063\u305F",
  "id" : 346202289024946176,
  "created_at" : "2013-06-16 09:47:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346193753867964417",
  "text" : "\u660E\u308B\u3044\u304B\u3089\u81EA\u899A\u306A\u3044\u304C\u3082\u304618\u3058\u307E\u308F\u3063\u3066\u3093\u306E\u304B",
  "id" : 346193753867964417,
  "created_at" : "2013-06-16 09:13:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346149433223823360",
  "text" : "\u305D\u30FC\u3044\u3084\u3053\u3093\u304B\u3044\u3081\u3093\u3064\u3086\u4F7F\u308F\u306A\u304B\u3063\u305F\u306A",
  "id" : 346149433223823360,
  "created_at" : "2013-06-16 06:17:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346148187150618624",
  "text" : "\u3061\u3087\u3063\u3068\u5869\u5165\u308C\u3059\u304E\u305F[\u524D\u3082\u3053\u3093\u306A\u3053\u3068\u3042\u3063\u305F\u3088\u3046\u306A]",
  "id" : 346148187150618624,
  "created_at" : "2013-06-16 06:12:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346147754201972736",
  "text" : "\u8F9B\u3044\u304A\u3076\u3056\u308F\u30FC\u308B\u3069",
  "id" : 346147754201972736,
  "created_at" : "2013-06-16 06:10:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346145658215989248",
  "text" : "\u30B9\u30D1\u30A4\u30B9\u304B\u3089\u4F5C\u308B\u30AB\u30EC\u30FC\u306F\u8907\u96D1\u7CFB",
  "id" : 346145658215989248,
  "created_at" : "2013-06-16 06:02:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346145382524416001",
  "text" : "\u75FA\u308C\u308B\u307B\u3069\u306B\u8F9B\u3044\uFF01\uFF01",
  "id" : 346145382524416001,
  "created_at" : "2013-06-16 06:01:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346145272537157632",
  "text" : "\u4E45\u3005\u306B\u30AB\u30EC\u30FC\u4F5C\u3063\u305F",
  "id" : 346145272537157632,
  "created_at" : "2013-06-16 06:00:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346080537988976640",
  "text" : "ODE:Oxford-Dictionary-of-English\u306E\u3001\u8A71\u3092\u3057\u3066\u305F\u53CB\u4EBA\u304C\u5C45\u305F\u304C\u3069\u3046\u8DB3\u63BB\u3044\u3066\u3082\u5E38\u5FAE\u5206\u65B9\u7A0B\u5F0F",
  "id" : 346080537988976640,
  "created_at" : "2013-06-16 01:43:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346079410987872258",
  "text" : "1\u6642\u3060\u3068\u601D\u3063\u305F\u308910\u6642\u3060\u3063\u305F\u306E\u3067\u52A9\u304B\u3063\u305F(?)",
  "id" : 346079410987872258,
  "created_at" : "2013-06-16 01:38:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345909797662625793",
  "text" : "\u4ED6\u306E\u7814\u7A76\u5BA4\u306E\u5148\u8F29\u306B\u300C\u6700\u8FD1\u6691\u3044\u3067\u3059\u306D\u3047\u3001\u6691\u3044\u3060\u3051\u306A\u3089\u307E\u3060\u3057\u3082\u84B8\u3057\u307E\u3059\u306D\u3047\u300D\u3063\u3066\u8A00\u3063\u305F\u3089\u540C\u8F29\u306B\u300C\u8A71\u3057\u65B9\u304C\u5927\u5B66\u751F\u306E\u305D\u308C\u3067\u306F\u306A\u3044\u300D\u3068\u8A00\u308F\u308C\u305F\u65B9\u306E\u3048\u3093\u3069\u3067\u3059",
  "id" : 345909797662625793,
  "created_at" : "2013-06-15 14:24:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345909114632802304",
  "geo" : { },
  "id_str" : "345909214457249792",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u30BB\u30B5\u30DF\u3068\u3044\u3046\u5224\u65AD\u306F\u8912\u3081\u3066\u9063\u308F\u305D\u3046",
  "id" : 345909214457249792,
  "in_reply_to_status_id" : 345909114632802304,
  "created_at" : "2013-06-15 14:22:38 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345908913012629504",
  "geo" : { },
  "id_str" : "345909045837844480",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u30D4\u30AF\u30EB\u30B9\u591A\u3081\u306B\u3057\u306A\u3044\u3068\u304B\u4F55\u8003\u3048\u3066\u3093\u3060\uFF01\uFF01\uFF01",
  "id" : 345909045837844480,
  "in_reply_to_status_id" : 345908913012629504,
  "created_at" : "2013-06-15 14:21:57 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345907601625731072",
  "geo" : { },
  "id_str" : "345907718432890880",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u30DE\u30A4\u30AF\u3068\u304B\u3082\u306E\u306B\u3082\u3088\u308B\u304C1000\u5186\u3067\u8CB7\u3048\u308B",
  "id" : 345907718432890880,
  "in_reply_to_status_id" : 345907601625731072,
  "created_at" : "2013-06-15 14:16:41 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345907483887419393",
  "text" : "\u305D\u3046\u304B\u3001\u6D74\u8863\u304F\u3089\u3044\u306A\u3089(?)\u4F5C\u3063\u3061\u3083\u3048\u3070\u826F\u3044\u306E\u304B",
  "id" : 345907483887419393,
  "created_at" : "2013-06-15 14:15:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345906789453295616",
  "text" : "\u30B7\u30E3\u30D0\u30C9\u30A5\u30D3\u30BF\u30C3\u30C1\u30ED\u30F3\u30D6\u30FC\u30F3",
  "id" : 345906789453295616,
  "created_at" : "2013-06-15 14:12:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345898000406679553",
  "geo" : { },
  "id_str" : "345906603872100354",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u306A\u306B\u305D\u308C\u3059\u3054\u3044[\u7D39\u4ECB\u3057\u3066\u6B32\u3057\u3044]",
  "id" : 345906603872100354,
  "in_reply_to_status_id" : 345898000406679553,
  "created_at" : "2013-06-15 14:12:15 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345894352276566016",
  "text" : "\u5FC5\u8981\u3088\u308A\u591A\u3044hogehoge\u306F\u5FC5\u8981\u306A\u3044\u3088",
  "id" : 345894352276566016,
  "created_at" : "2013-06-15 13:23:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345894133728161792",
  "text" : "\u300C\u5FC5\u8981\u4EE5\u4E0A\u306Ehogehoge\u306F\u5FC5\u8981\u306A\u3044\u3088\u300D\u3068\u3044\u3046\u30C6\u30F3\u30D7\u30EC[\u4EE5\u4E0A\u306F\u30A4\u30B3\u30FC\u30EB\u3092\u542B\u3080\u3068\u304B\u8A00\u308F\u306A\u3044]",
  "id" : 345894133728161792,
  "created_at" : "2013-06-15 13:22:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345892821984768000",
  "text" : "\u72C2\u4EBA\u306E\u771F\u4F3C\u3092\u3057\u305F\u3089\u5B9F\u969B\u72C2\u4EBA",
  "id" : 345892821984768000,
  "created_at" : "2013-06-15 13:17:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345892444283478016",
  "geo" : { },
  "id_str" : "345892759296675841",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kiu_uit \u5927\u4E08\u592B\u3067\u3059\u304B\uFF1F\u304A\u5927\u4E8B\u306B\u306A\u3055\u3063\u3066\u304F\u3060\u3055\u3044\u306D\uFF1F",
  "id" : 345892759296675841,
  "in_reply_to_status_id" : 345892444283478016,
  "created_at" : "2013-06-15 13:17:14 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345892057593810944",
  "geo" : { },
  "id_str" : "345892320811577344",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kiu_uit \u30A6\u30C4\u30C9\u30F3\u3063\u3066\u5165\u3063\u3066\u3044\u308C\u3070\u3075\u3041\u307C\u308B\u3068\u601D\u3046\u306A\u3088\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 345892320811577344,
  "in_reply_to_status_id" : 345892057593810944,
  "created_at" : "2013-06-15 13:15:30 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345892148148850688",
  "text" : "\u717D\u308A\u611B\u3068\u304B\u3044\u3046\u7D20\u6575\u5909\u63DB",
  "id" : 345892148148850688,
  "created_at" : "2013-06-15 13:14:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345892091395715072",
  "text" : "\u304D\u306C\u3044\u3068\u6C0F\u3068\u3053\u3093\u306A\u717D\u308A\u3042\u3044\u3092\u3059\u308B\u4EF2\u3058\u3083\u306A\u304B\u3063\u305F\u3088\u3046\u306A",
  "id" : 345892091395715072,
  "created_at" : "2013-06-15 13:14:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345891772116914176",
  "geo" : { },
  "id_str" : "345891959195451392",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kiu_uit \u79C1\u306F\u3042\u306A\u305F\u304C\u201D\u201D\u306A\u306B\u3092\u8A00\u3063\u3066\u3044\u308B\u306E\u304B\u308F\u304B\u3089\u306A\u3044\u201D\u201D\u3068\u8A00\u3063\u3066\u3044\u307E\u3059(^^)(^^)(^^)",
  "id" : 345891959195451392,
  "in_reply_to_status_id" : 345891772116914176,
  "created_at" : "2013-06-15 13:14:04 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6709\u76CA\u306A\u3053\u3068\u3092\u3046\u3093\u306C\u3093",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345891807068057601",
  "text" : "\u6C34\u3092\u51CD\u3089\u305B\u308C\u3070\u6C37\u306B\u306A\u308B #\u6709\u76CA\u306A\u3053\u3068\u3092\u3046\u3093\u306C\u3093",
  "id" : 345891807068057601,
  "created_at" : "2013-06-15 13:13:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345891672657375233",
  "text" : "\u8D05\u6CA2\u306B\u4F7F\u3046\u304B\u3089\u306A\uFF1F",
  "id" : 345891672657375233,
  "created_at" : "2013-06-15 13:12:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345891629145653248",
  "text" : "\u6691\u304F\u306A\u3063\u3066\u304D\u305F\u3089\u6C37\u306E\u4F9B\u7D66\u304C\u9593\u306B\u5408\u308F\u306A\u3044",
  "id" : 345891629145653248,
  "created_at" : "2013-06-15 13:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345891174399229953",
  "text" : "\u4E16\u754C\u306B\u5BFE\u3057\u3066\u7533\u3057\u8A33 of the world",
  "id" : 345891174399229953,
  "created_at" : "2013-06-15 13:10:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345890624144306176",
  "geo" : { },
  "id_str" : "345890828746649600",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u304A\u524D\u306F\u4F55\u3082\u308F\u304B\u3063\u3066\u306A\u3044\u306A\uFF1F",
  "id" : 345890828746649600,
  "in_reply_to_status_id" : 345890624144306176,
  "created_at" : "2013-06-15 13:09:34 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345890595962769408",
  "geo" : { },
  "id_str" : "345890692129771520",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kiu_uit \u306A\u306B\u3044\u3063\u3066\u308B\u306E\u2026",
  "id" : 345890692129771520,
  "in_reply_to_status_id" : 345890595962769408,
  "created_at" : "2013-06-15 13:09:02 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345890575922376705",
  "text" : "\uFF1F",
  "id" : 345890575922376705,
  "created_at" : "2013-06-15 13:08:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345890559388426242",
  "text" : "\u982D\u5F85\u3061\u3060\u3068\u30D4\u30F3\u30D5\u304C\u3064\u304B\u306A\u3044",
  "id" : 345890559388426242,
  "created_at" : "2013-06-15 13:08:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345890490610225152",
  "text" : "\u982D\u3060\u3051\u6301\u3063\u3066\u6765\u3089\u308C\u3066\u3082\u56F0\u308A\u307E\u3059",
  "id" : 345890490610225152,
  "created_at" : "2013-06-15 13:08:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345890455411634178",
  "text" : "\u4F55\u304B\u306E\u982D\u3092\u64AB\u305C\u305F\u3044",
  "id" : 345890455411634178,
  "created_at" : "2013-06-15 13:08:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345890254001143809",
  "text" : "\u307F\u305F\u304B\u3060\u3044\u3067\u307F\u305F\u304B\u3060\u3044",
  "id" : 345890254001143809,
  "created_at" : "2013-06-15 13:07:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345888646349611008",
  "text" : "\u201C\u5A9A\u3073\u201D\u306F\u6EC5\u3073\u308C\u3070\u826F\u3044",
  "id" : 345888646349611008,
  "created_at" : "2013-06-15 13:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345888018827190275",
  "text" : "\uFF71\uFF70\uFF71\uFF70\uFF8F\uFF73\uFF81\uFF6C\uFF72\uFF79\uFF92\uFF9D\uFF8F\uFF73\uFF81\uFF6C\uFF72\uFF79\uFF92\uFF9D\uFF70",
  "id" : 345888018827190275,
  "created_at" : "2013-06-15 12:58:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etyping",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "et_r",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/8teokwJjN4",
      "expanded_url" : "http:\/\/www.e-typing.ne.jp\/",
      "display_url" : "e-typing.ne.jp"
    } ]
  },
  "geo" : { },
  "id_str" : "345885357801340928",
  "text" : "\u4ECA\u65E5\u306E\u8155\u8A66\u3057\u30BF\u30A4\u30D4\u30F3\u30B0\uFF08\u30ED\u30FC\u30DE\u5B57\uFF09\u306E\u7D50\u679C\u306F\u300CThunder\u300D\u30B9\u30B3\u30A2\u300C334\u300D\u3067\u3057\u305F\u3002 http:\/\/t.co\/8teokwJjN4 #etyping #et_r",
  "id" : 345885357801340928,
  "created_at" : "2013-06-15 12:47:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306E\u305E\u305E\u3046",
      "screen_name" : "noz_mint07",
      "indices" : [ 0, 11 ],
      "id_str" : "522080703",
      "id" : 522080703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345876424688807936",
  "geo" : { },
  "id_str" : "345876619400990720",
  "in_reply_to_user_id" : 522080703,
  "text" : "@noz_mint07 \u3048\u3001\u307E\u3058\u3067[\u4ECA\u65E5\u884C\u3063\u305F\u306E\u306B\u70CF\u9F8D\u83364\u672C\u8CB7\u3063\u3066\u5E30\u3063\u3066\u3057\u307E\u3063\u305F]",
  "id" : 345876619400990720,
  "in_reply_to_status_id" : 345876424688807936,
  "created_at" : "2013-06-15 12:13:06 +0000",
  "in_reply_to_screen_name" : "noz_mint07",
  "in_reply_to_user_id_str" : "522080703",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345876423430512640",
  "text" : "\u30A2\u30A4\u30B9\u8CB7\u3063\u3066\u6765\u3044\u3068\u8A00\u308F\u308C\u3066\u201D\u3042\u305A\u304D\u30D0\u30FC\u3068\u30A2\u30A4\u30B9\u307E\u3093\u3058\u3085\u3046\u201D\u8CB7\u3063\u3066\u5E30\u3063\u3066\u53F1\u3089\u308C\u305F\u306E\u306F\u53BB\u5E74\u306E\u590F\u3060\u3063\u305F\u304B",
  "id" : 345876423430512640,
  "created_at" : "2013-06-15 12:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345876254366519297",
  "text" : "\u3042\u305A\u304D\u30D0\u30FC\u98DF\u3079\u305F\u304F\u306A\u3063\u305F\u56F0\u308B",
  "id" : 345876254366519297,
  "created_at" : "2013-06-15 12:11:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306E\u305E\u305E\u3046",
      "screen_name" : "noz_mint07",
      "indices" : [ 0, 11 ],
      "id_str" : "522080703",
      "id" : 522080703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345876137999732736",
  "geo" : { },
  "id_str" : "345876214508052480",
  "in_reply_to_user_id" : 522080703,
  "text" : "@noz_mint07 \u3044\u3044\u3067\u3059\u306D\uFF01\uFF01\uFF01",
  "id" : 345876214508052480,
  "in_reply_to_status_id" : 345876137999732736,
  "created_at" : "2013-06-15 12:11:30 +0000",
  "in_reply_to_screen_name" : "noz_mint07",
  "in_reply_to_user_id_str" : "522080703",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345874856333688833",
  "text" : "\u306A\u3093\u304B\u3082\u3046\u6240\u5C5E\u3068\u304B\u4E00\u5207\u4F0F\u305B\u3066\u4EBA\u3068\u95A2\u308F\u3063\u305F\u3089\u826F\u3044\u306E\u3067\u306F\u2026",
  "id" : 345874856333688833,
  "created_at" : "2013-06-15 12:06:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345874418276380672",
  "text" : "\u5BDD\u65B9\u304C\u60AA\u304B\u3063\u305F\u306E\u304B\u9759\u304B\u306A\u982D\u75DB\u304C\u7D9A\u304F\u306E\u3084\u3081\u3066\u6B32\u3057\u3044",
  "id" : 345874418276380672,
  "created_at" : "2013-06-15 12:04:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345873343855091713",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 345873343855091713,
  "created_at" : "2013-06-15 12:00:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345853098645929984",
  "text" : "\u6628\u65E5\u304B\u3089\u3084\u305F\u3089\u8FF7\u60D1\u30E1\u30FC\u30EB\u304F\u308B\u306A\u2026",
  "id" : 345853098645929984,
  "created_at" : "2013-06-15 10:39:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345851164589436929",
  "text" : "\u305D\u3046\u304B\u3001\u7A7A\u8179\u304B",
  "id" : 345851164589436929,
  "created_at" : "2013-06-15 10:31:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345839387663278080",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u305F\u3076\u3093\u201D\u4F55\u304B(\u6D88\u8CBB\u7269)\u304C\u5927\u91CF\u306B\u3042\u3063\u3066\u307E\u3060\u307E\u3060\u7121\u304F\u306A\u3089\u306A\u3044\u72B6\u614B\u201D\u304C\u597D\u304D",
  "id" : 345839387663278080,
  "created_at" : "2013-06-15 09:45:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345839043621294080",
  "text" : "\u305D\u3057\u3066\u725B\u4E73\u8CB7\u3044\u5FD8\u308C\u305F",
  "id" : 345839043621294080,
  "created_at" : "2013-06-15 09:43:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345838963753357313",
  "text" : "\u30DD\u30EA\u30D5\u30A7\u30CE\u30FC\u30E9\u30FC\u30A8\u30F3\u30C9",
  "id" : 345838963753357313,
  "created_at" : "2013-06-15 09:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345838908749279234",
  "text" : "\u70CF\u9F8D\u8336\u3068\u30C1\u30E7\u30B3\u30EC\u30FC\u30BA\u30F3\u3068\u304B\u30DD\u30EA\u30D5\u30A7\u30CE\u30FC\u30EA\u30A3",
  "id" : 345838908749279234,
  "created_at" : "2013-06-15 09:43:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345835332589211648",
  "text" : "\u6211\u306A\u304C\u3089\u982D\u306E\u60AA\u3044\u8CB7\u3044\u7269\u3067\u3042\u308B",
  "id" : 345835332589211648,
  "created_at" : "2013-06-15 09:29:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345835268135321600",
  "text" : "\u30B3\u30D4\u30FC\u7528\u7D191000\u679A\u3068\u70CF\u9F8D\u83368\u2113\u8CB7\u3063\u305F\u3057\u3082\u3046\u4F55\u3082\u6016\u304F\u306A\u3044",
  "id" : 345835268135321600,
  "created_at" : "2013-06-15 09:28:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345830435114328065",
  "text" : "\u3061\u3087\u3063\u3068\u524D\u306B\u8CB7\u3063\u305F\u306F\u305A\u306E\u30B3\u30D4\u30FC\u7528\u9AEA\u304C\u3042\u3093\u307E\u308A\u306A\u3044\u304B\u3089\u70CF\u9F8D\u8336\u8CB7\u3044\u306B\u884C\u304F",
  "id" : 345830435114328065,
  "created_at" : "2013-06-15 09:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/gynFIcO3qs",
      "expanded_url" : "http:\/\/4sq.com\/11F8quW",
      "display_url" : "4sq.com\/11F8quW"
    } ]
  },
  "geo" : { },
  "id_str" : "345555242982727680",
  "text" : "I'm at \u8239\u5CA1\u6E29\u6CC9 (funaoka onsen) (\u4EAC\u90FD\u5E02\u5317\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/gynFIcO3qs",
  "id" : 345555242982727680,
  "created_at" : "2013-06-14 14:56:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345548406992826368",
  "text" : "\u92AD\u6E6F\u306B90\u5206\u307B\u3069\u5C45\u305F\u3042\u3068\u98F2\u3080\u30B5\u30A4\u30C0\u30FC\u304C\u6C81\u307F\u308B",
  "id" : 345548406992826368,
  "created_at" : "2013-06-14 14:28:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345514563854270466",
  "geo" : { },
  "id_str" : "345514812685574144",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u6301\u3063\u3066\u884C\u304D\u307E\u3059\u30FC",
  "id" : 345514812685574144,
  "in_reply_to_status_id" : 345514563854270466,
  "created_at" : "2013-06-14 12:15:25 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345513100138672130",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3086\u3063\u304F\u308A\u3081\u3067\u826F\u3044\u3067\u3059\u30FC",
  "id" : 345513100138672130,
  "created_at" : "2013-06-14 12:08:37 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/345463397036482560\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/7Hba7Rot0B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMtVIReCYAAO-g5.jpg",
      "id_str" : "345463397040676864",
      "id" : 345463397040676864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMtVIReCYAAO-g5.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7Hba7Rot0B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345463397036482560",
  "text" : "\u6BBA\u4F10\u3068\u3057\u305FTL\u306B\u30CB\u30E7\u30ED\u30ED\u30F3\u304C\uFF01 http:\/\/t.co\/7Hba7Rot0B",
  "id" : 345463397036482560,
  "created_at" : "2013-06-14 08:51:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345447487030575104",
  "text" : "\u9078\u3076\u30AD\u30E3\u30E9\u306E\u30CB\u30C3\u30C1\u3055\u306B\u306F\u81EA\u4FE1\u304C\u3042\u308B(?)",
  "id" : 345447487030575104,
  "created_at" : "2013-06-14 07:47:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/345447378616201217\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/LCbayXwyE7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMtGj4OCMAEdxsq.jpg",
      "id_str" : "345447378624589825",
      "id" : 345447378624589825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMtGj4OCMAEdxsq.jpg",
      "sizes" : [ {
        "h" : 100,
        "resize" : "crop",
        "w" : 130
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 130
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 130
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 130
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 130
      } ],
      "display_url" : "pic.twitter.com\/LCbayXwyE7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345447378616201217",
  "text" : "\u306A\u304A\u30D7\u30EA\u30F3\u30C8\u306E\u4F59\u767D\u306B\u30CB\u30E7\u30ED\u30ED\u30F3\u304C\u66F8\u3044\u3066\u3042\u3063\u305F\u6A21\u69D8\u3001\u3057\u304B\u3082\u76EE\u306E\u4F4D\u7F6E\u3068\u304B\u3061\u3087\u3063\u3068\u9055\u3046 http:\/\/t.co\/LCbayXwyE7",
  "id" : 345447378616201217,
  "created_at" : "2013-06-14 07:47:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345446394909319168",
  "text" : "\u30D7\u30EA\u30F3\u30C8\u306E\u4F59\u767D\u306B\u843D\u66F8\u304D\u3057\u3066\u3001\u305D\u308C\u3092\u5FD8\u308C\u305F\u7FCC\u9031\u898B\u3064\u3051\u3066\u7B11\u3044\u305D\u3046\u306B\u306A\u308B\u30BB\u30EB\u30D5\u30C6\u30ED\u305F\u306E\u3057\u3044",
  "id" : 345446394909319168,
  "created_at" : "2013-06-14 07:43:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345445665725349888",
  "text" : "\u3051\u3069\u4ECA\u65E5\u306E\u5927\u6839\u304A\u308D\u3057\u306F\u5168\u7136\u8F9B\u304F\u306A\u304B\u3063\u305F\u3001\u6C34\u66DC\u306E\u306F\u3084\u305F\u3089\u8F9B\u304B\u3063\u305F[\u30AB\u30EB\u30AB\u30C3\u30BF]",
  "id" : 345445665725349888,
  "created_at" : "2013-06-14 07:40:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345445520615043073",
  "text" : "\u3072\u3084\u3057\u304A\u308D\u3057\u3046\u3069\u3093\u304A\u3044\u3057\u3044",
  "id" : 345445520615043073,
  "created_at" : "2013-06-14 07:40:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345445233028378624",
  "text" : "\u30A6\u30C4\u30C9\u30F3\u30CD\u30BF\u50D5\u304C\u3044\u308B\u6642\u3057\u304B\u545F\u3044\u3066\u306A\u3044\u306E\u3067\u306F",
  "id" : 345445233028378624,
  "created_at" : "2013-06-14 07:38:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345445166720622592",
  "text" : "RT @kip_qit: \u820C\u9F13\u3092\u30A6\u30C4\u30C9\u30F3\uFF0E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345445025833943040",
    "text" : "\u820C\u9F13\u3092\u30A6\u30C4\u30C9\u30F3\uFF0E",
    "id" : 345445025833943040,
    "created_at" : "2013-06-14 07:38:06 +0000",
    "user" : {
      "name" : "\u304D\u3068",
      "screen_name" : "8_u8",
      "protected" : true,
      "id_str" : "1230390426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574511385389887488\/zeqPOQq1_normal.jpeg",
      "id" : 1230390426,
      "verified" : false
    }
  },
  "id" : 345445166720622592,
  "created_at" : "2013-06-14 07:38:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345445027482304512",
  "text" : "\u30E1\u30C8\u30ED\u30CE\u30FC\u30E0\u306E\u3088\u3046\u306B",
  "id" : 345445027482304512,
  "created_at" : "2013-06-14 07:38:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345444911627264000",
  "text" : "\u8EFD\u53E3\u3092\u53E9\u304F[16\u5206\u306E\u30D3\u30FC\u30C8\u3067]",
  "id" : 345444911627264000,
  "created_at" : "2013-06-14 07:37:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/WOIdMFWqwH",
      "expanded_url" : "http:\/\/headlines.yahoo.co.jp\/hl?a=20130613-00000016-zdn_b-bus_all",
      "display_url" : "headlines.yahoo.co.jp\/hl?a=20130613-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345176385574297600",
  "text" : "\u3053\u308C\u3092\u6A5F\u306B\u4E00\u3064\u307E\u3048\u304B\u3089\u3042\u308B\u30BF\u30A4\u30D7\u304C\u5B89\u304F\u306A\u3063\u305F\u308A\u3057\u306A\u3044\u304B\u306A... ScanSnap\u306B\u30B9\u30BF\u30F3\u30C9\u30BF\u30A4\u30D7\u578B\u300CSV600\u300D\u3001\u975E\u63A5\u89E6\u65B9\u5F0F\u3067\u672C\u3092\u5207\u3089\u305A\u30B9\u30AD\u30E3\u30F3\uFF08\u8AA0 Biz.ID\uFF09 - Y!\u30CB\u30E5\u30FC\u30B9 http:\/\/t.co\/WOIdMFWqwH",
  "id" : 345176385574297600,
  "created_at" : "2013-06-13 13:50:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0430\u043B\u044F White",
      "screen_name" : "getty_on_r318",
      "indices" : [ 0, 14 ],
      "id_str" : "2884913343",
      "id" : 2884913343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345173299854184448",
  "in_reply_to_user_id" : 379262851,
  "text" : "@getty_on_r318  DM\u304A\u304F\u308A\u307E\u3057\u305F",
  "id" : 345173299854184448,
  "created_at" : "2013-06-13 13:38:22 +0000",
  "in_reply_to_screen_name" : "komorin95",
  "in_reply_to_user_id_str" : "379262851",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345154292266696705",
  "text" : "\u5916\u306E\u4EBA\u306F...\u4E00\u4EBA\u3058\u3083\u306A\u3044\uFF01",
  "id" : 345154292266696705,
  "created_at" : "2013-06-13 12:22:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345151868755906561",
  "text" : "\u4E2D\u306E\u4EBA\u306F\u96E2\u8131\u3057\u307E\u3059\uFF0E[\u3067\u306F\u5916\u306E\u4EBA\u306F\uFF1F]",
  "id" : 345151868755906561,
  "created_at" : "2013-06-13 12:13:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345151692276375555",
  "text" : "\u5B9F\u969B\u4E2D\u306E\u4EBA\u30E2\u30C7\u30EB\u306F\u307B\u3068\u3093\u3069\u306A\u3093\u3067\u3082\u8AAC\u660E\u3067\u304D\u308B\u304B\u3089\u7121\u6575",
  "id" : 345151692276375555,
  "created_at" : "2013-06-13 12:12:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345151598722433024",
  "text" : "\u9855\u5FAE\u93E1\u306E\u4E2D\u306E\u4EBA\uFF0E",
  "id" : 345151598722433024,
  "created_at" : "2013-06-13 12:12:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345151374570426368",
  "geo" : { },
  "id_str" : "345151538035056640",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u306E\u3046\u3053\u304C\u9855\u5FAE\u93E1\u3092\u306E\u305E\u304F\u3068\u304D\uFF0C\u9855\u5FAE\u93E1\u3082\u307E\u305F\u306E\u3046\u3053\u3092\u8997\u304D\u8FD4\u3059\u306E\u3060 [\uFF1F]",
  "id" : 345151538035056640,
  "in_reply_to_status_id" : 345151374570426368,
  "created_at" : "2013-06-13 12:11:53 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345151325014736896",
  "text" : "\uFF9C\uFF9C\uFF70",
  "id" : 345151325014736896,
  "created_at" : "2013-06-13 12:11:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345151294236930048",
  "text" : "\u30EF\u30EF\u30FC\u3057\u3083\u3073\u308B\u304B\u30FC",
  "id" : 345151294236930048,
  "created_at" : "2013-06-13 12:10:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345150951658754048",
  "text" : "\u3044\u3084\u307E\u3041\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3057\u306B\u304F\u3044\u3068\u306F\u601D\u3044\u307E\u3059\u304C\u30A2\u30A6\u30C8\u306A\u30B3\u30E1\u30F3\u30C8\u306F\u3057\u3066\u306A\u3044\u3068\u601D\u3046\u306E\u3067\u3059",
  "id" : 345150951658754048,
  "created_at" : "2013-06-13 12:09:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345150856691331072",
  "text" : "\u30B3\u30E1\u30F3\u30C8\u30A2\u30A6\u30C8\uFF01",
  "id" : 345150856691331072,
  "created_at" : "2013-06-13 12:09:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345150804124135424",
  "text" : "\u307F\u3093\u306A\u304C\u62EC\u5F27\u306E\u4E2D\u8EAB\u7121\u8996\u3059\u308B\u306E\uFF0CTeX\u306E\u4E2D\u306E\u4EBA\u304C%\u4EE5\u964D\u8AAD\u307E\u306A\u3044\u306E\u306B\u4F3C\u3066\u308B\uFF0E",
  "id" : 345150804124135424,
  "created_at" : "2013-06-13 12:08:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345150599806996480",
  "text" : "\u307E\u3041\u3048\u3093\u3069\u3055\u3093\u304C\u3075\u3056\u3051\u3066\u308B\u6642\u306F\u771F\u9762\u76EE\u306B\u76F8\u624B\u306B\u3057\u306A\u3044\u306B\u9650\u308A\u307E\u3059\u3088\uFF0E",
  "id" : 345150599806996480,
  "created_at" : "2013-06-13 12:08:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345150412350976000",
  "text" : "\u62EC\u5F27\u306E\u4E2D\u8EAB\u5168\u90E8\u7121\u8996\u3055\u308C\u308B\u306E\u697D\u3057\u3044\uFF01",
  "id" : 345150412350976000,
  "created_at" : "2013-06-13 12:07:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345150262660435971",
  "geo" : { },
  "id_str" : "345150339193905153",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u795E",
  "id" : 345150339193905153,
  "in_reply_to_status_id" : 345150262660435971,
  "created_at" : "2013-06-13 12:07:08 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345149801920360448",
  "geo" : { },
  "id_str" : "345149983588229120",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u308F\u304B\u308B [\u306A\u306B\u3044\u3063\u3066\u3093\u306E\u304B\u308F\u304B\u3089\u306A\u3044\u3053\u3068\u306B\u304B\u3093\u3059\u308B\u3069\u3046\u3044\u3067\u3042\u3063\u3066\u308F\u304B\u308B\u306F\u305A\u3060\u3068\u3044\u3046\u304A\u3057\u3064\u3051\u3067\u306F\u306A\u3044\u3068\u3044\u3046\u3066\u3093\u306B\u3061\u3085\u3046\u3044][\u307C\u304F\u3082\u3088\u304F\u308F\u304B\u3093\u306A\u3044]",
  "id" : 345149983588229120,
  "in_reply_to_status_id" : 345149801920360448,
  "created_at" : "2013-06-13 12:05:43 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345149137005723648",
  "geo" : { },
  "id_str" : "345149346544775168",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u4F1A\u8A71\u3058\u3083\u306A\u304F\u3066\u3082\u308F\u3051\u308F\u304B\u3093\u306A\u3044\u3053\u3068\u8A00\u3063\u3066\u308B\u304B\u3089\u5927\u4E08\u592B\u3060\u305C\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 345149346544775168,
  "in_reply_to_status_id" : 345149137005723648,
  "created_at" : "2013-06-13 12:03:11 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345149199421169664",
  "text" : "\u50D5\u81EA\u8EAB\u3082\u4F55\u8A00\u3063\u3066\u3093\u306E\u304B\u308F\u304B\u3093\u306A\u3044\u304B\u3089\u306A",
  "id" : 345149199421169664,
  "created_at" : "2013-06-13 12:02:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345149013328265216",
  "geo" : { },
  "id_str" : "345149098829164545",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u50D5\u306A\u3093\u304B\u3044\u3064\u3082\u4F55\u8A00\u3063\u3066\u3093\u306E\u304B\u308F\u304B\u3093\u306A\u3044\u3063\u3066\u8A00\u308F\u308C\u307E\u3059\u3088",
  "id" : 345149098829164545,
  "in_reply_to_status_id" : 345149013328265216,
  "created_at" : "2013-06-13 12:02:12 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345149015245082624",
  "text" : "\uFF08\u2207_\u2207\uFF09\uFF92\uFF76\uFF9E\uFF85\uFF8C\uFF9E\uFF97\uFF70",
  "id" : 345149015245082624,
  "created_at" : "2013-06-13 12:01:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345148653448622081",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 345148653448622081,
  "created_at" : "2013-06-13 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345148655025659905",
  "text" : "\u4E00\u79D2\u5DEE\u3067\u81EA\u5206\u3067\u601D\u3044\u51FA\u3057\u305F\u3053\u3068\u3092\u8A3C\u660E\u3067\u304D\u305F\u306A\u30FB",
  "id" : 345148655025659905,
  "created_at" : "2013-06-13 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345148565464682496",
  "text" : "\u30CA\u30D6\u30E9\uFF01",
  "id" : 345148565464682496,
  "created_at" : "2013-06-13 12:00:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345148240301260800",
  "geo" : { },
  "id_str" : "345148423198101505",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u305D\u308C\u30C7\u30EB\u30BF\u3058\u3083\u306A\u3044\u306A\uFF1F\u30E9\u30D7\u30E9\u30B7\u30A2\u30F3\uFF1F\u306A\u3093\u3060\u3063\u3051\u304B",
  "id" : 345148423198101505,
  "in_reply_to_status_id" : 345148240301260800,
  "created_at" : "2013-06-13 11:59:31 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345148249637806081",
  "text" : "\u305C\u308A\u30FC\u3055\u3093\u300Chogehoge\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u305D\u308C\u8A00\u304A\u3046\u3068\u601D\u3063\u3066\u3084\u3081\u305F\u3093\u3060\u3088\u306D\u300D\n\u305C\u308A\u30FC\u3055\u3093\u300C\u3053\u308C\u3048\u3093\u3069\u3055\u3093\u304C\u8A00\u304A\u3046\u3068\u601D\u3063\u305F\u3068\u601D\u3063\u305F\u3093\u3060\u3088\u306D\u300D\n\u4F55\u3053\u306E\u9AD8\u5EA6\u306A\u5FC3\u7406\u6226",
  "id" : 345148249637806081,
  "created_at" : "2013-06-13 11:58:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345147849937391616",
  "geo" : { },
  "id_str" : "345147982041202689",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u2203\u03B4\uFF5E",
  "id" : 345147982041202689,
  "in_reply_to_status_id" : 345147849937391616,
  "created_at" : "2013-06-13 11:57:46 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345147769079611394",
  "text" : "\u8179\u3092\u5272\u3063\u3066\u8A71\u3059\uFF0E\u6B7B\u4EBA\u306B\u53E3\u306A\u3057\uFF0E\u3055\u3066\uFF1F",
  "id" : 345147769079611394,
  "created_at" : "2013-06-13 11:56:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345147398751911937",
  "text" : "\u305D\u306E\u304B\u308F\u308A\u4F55\u6C17\u306A\u3044\u4F1A\u8A71\u306E\u4E2D\u306B\u3058\u308F\u3058\u308F\u6765\u308B\u4E00\u8A00\u3092\u6DF7\u305C\u307E\u3059\uFF0E",
  "id" : 345147398751911937,
  "created_at" : "2013-06-13 11:55:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345147285421817856",
  "text" : "\u3059\u3044\u307E\u305B\u3093\uFF0C\u3046\u305D\u3064\u304D\u307E\u3057\u305F\uFF0E\u3044\u3046\u305F\u307B\u3069\u306F\u3084\u304F\u30DC\u30B1\u307E\u305B\u3093\uFF0E",
  "id" : 345147285421817856,
  "created_at" : "2013-06-13 11:55:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345147210465435648",
  "text" : "\u50D5\u306E\u30DC\u30B1\u306B\u3064\u3044\u3066\u3053\u308C\u308B\u304B\u306A [\u65E9\u304F\u30DC\u30B1\u3059\u304E\u3066\u6B8B\u50CF\u304C\u751F\u3058\u308B]",
  "id" : 345147210465435648,
  "created_at" : "2013-06-13 11:54:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345146458326056961",
  "geo" : { },
  "id_str" : "345146625842376705",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u4E5D\u5DDE\uFF1F",
  "id" : 345146625842376705,
  "in_reply_to_status_id" : 345146458326056961,
  "created_at" : "2013-06-13 11:52:22 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345146550667866112",
  "text" : "FB\u958B\u3044\u305F\u3089 \u300Chogehoge\u3055\u3093\u304C\u3055\u3093\u304C\u597D\u304D\u306A\u30B9\u30DD\u30FC\u30C4\u306B\u30B7\u30E5\u30EC\u30C7\u30A3\u30F3\u30AC\u30FC\u97F3\u982D\u3092\u8FFD\u52A0\u3057\u307E\u3057\u305F\u3002\u300D\u3063\u3066\u66F8\u3044\u3066\u3042\u3063\u3066\u5F7C\u3082\u7121\u4E8BFacebook\u6BBA\u4F10\u52E2\u3068\u3057\u3066\u3084\u3063\u3066\u3044\u3051\u305D\u3046\u3067\u3042\u308B\uFF0E",
  "id" : 345146550667866112,
  "created_at" : "2013-06-13 11:52:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345145930141556736",
  "geo" : { },
  "id_str" : "345146280776957952",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u30A2\u30E1\u30EA\u30AB\u3060\u3063\u305F\u3089\u30B0\u30FC\u5168\u632F\u308A\u306F\u5DDE\u306B\u3088\u3063\u3066\u306F\u91CD\u7F6A\u3084\u3067",
  "id" : 345146280776957952,
  "in_reply_to_status_id" : 345145930141556736,
  "created_at" : "2013-06-13 11:51:00 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345144976881094656",
  "text" : "\u3044\u307E\u306E\u306A\u3057",
  "id" : 345144976881094656,
  "created_at" : "2013-06-13 11:45:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345144938184445954",
  "text" : "\uFF1F\uFF1F",
  "id" : 345144938184445954,
  "created_at" : "2013-06-13 11:45:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345144892047126528",
  "text" : "\u904E\u591A\u904E\u591A",
  "id" : 345144892047126528,
  "created_at" : "2013-06-13 11:45:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345144866013081600",
  "text" : "\u30AB\u30EB\u30B7\u30A6\u30E0\u304C\u30AB\u30BF\u30AB\u30BF\u3068\u97F3\u3092\u305F\u3066\u3066\u4F53\u306B\u6D41\u308C\u8FBC\u3093\u3067\u304F\u308B",
  "id" : 345144866013081600,
  "created_at" : "2013-06-13 11:45:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345144377691238400",
  "text" : "\u3057\u3089\u3059\u3054\u306F\u3093\u304B\u3089\u306E\u304D\u306A\u3053\u304E\u3085\u3046\u306B\u3085\u3046\u3063\u3066\u30AB\u30EB\u30B7\u30A6\u30E0\u904E\u591A\u611F\u3084\u3070\u3044",
  "id" : 345144377691238400,
  "created_at" : "2013-06-13 11:43:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345143746498801664",
  "text" : "\uFF1F",
  "id" : 345143746498801664,
  "created_at" : "2013-06-13 11:40:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345143732657586176",
  "text" : "\u554F\u984C\u306F\u3069\u3046\u3084\u3063\u3066\u9EC4\u306A\u7C89\u725B\u4E73\u3092\u5410\u304F\u304B\u3067\u3042\u308B",
  "id" : 345143732657586176,
  "created_at" : "2013-06-13 11:40:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345143689238151168",
  "text" : "\u9EC4\u306A\u7C89\u725B\u4E73\u98F2\u3080\u3068\u80F8\u304C\u5927\u304D\u304F\u306A\u308B\uFF0C\u307F\u305F\u3044\u306A\u3053\u3068\u805E\u3044\u305F\u3053\u3068\u3042\u308B\u3051\u3069\uFF0C\u9006\u306B\uFF0C\u9EC4\u306A\u7C89\u725B\u4E73\u3092\u5410\u3044\u305F\u3089\u80F8\u75E9\u305B\u3067\u304D\u308B\u306E\u3067\u306F\uFF1F",
  "id" : 345143689238151168,
  "created_at" : "2013-06-13 11:40:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345143491766140928",
  "text" : "\u304D\u306A\u3053\u304E\u3085\u3046\u306B\u3085\u3046\u3064\u304F\u308B\uFF0E",
  "id" : 345143491766140928,
  "created_at" : "2013-06-13 11:39:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345143235389304833",
  "text" : "\u3042\u3068\u9C39\u7BC0\u3082\uFF01",
  "id" : 345143235389304833,
  "created_at" : "2013-06-13 11:38:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345143202342375426",
  "text" : "\u3044\u308A\u3054\u307E\u306F\u3084\u3059\u3044\u306E\u306B\u3061\u3083\u304F\u3058\u3064\u306BQOL\u3042\u3052\u3066\u304F\u308C\u308B\u3059\u3066\u304D\u3057\u3087\u304F\u3056\u3044",
  "id" : 345143202342375426,
  "created_at" : "2013-06-13 11:38:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345142371610136577",
  "text" : "\u3057\u3089\u3059\u3068\u3054\u307E\u3068\u304B\u3064\u304A\u3076\u3057\u3054\u98EF\u304C\u304A\u3044\u3057\u3044\u3044",
  "id" : 345142371610136577,
  "created_at" : "2013-06-13 11:35:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345106372880396288",
  "text" : "\u4E88\u60F3\u304C\u5F53\u305F\u3063\u3066\u7B11\u3063\u3066\u308B",
  "id" : 345106372880396288,
  "created_at" : "2013-06-13 09:12:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345062863473373184",
  "text" : "\u6771\u5927\u8DEF\u306E\u30B9\u30FC\u30D1\u30FC\u306F\u3069\u3046\u3060\u3063\u305F\u304B\u306A\uFF0E\u3042\u305D\u3053\u6DF7\u3080\u304B\u3089\u3042\u3093\u307E\u308A\u884C\u304B\u306A\u3044\u3093\u3060\u3088\u306A\u3041\uFF0E[\u70CF\u9F8D\u8336]",
  "id" : 345062863473373184,
  "created_at" : "2013-06-13 06:19:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345062362656690176",
  "text" : "\u305D\u306E\u70B9\u30D3\u30D6\u30EC\u306E\u30B9\u30FC\u30D1\u30FC\u306F\uFF12\uFF4C\u3067\uFF11\uFF15\uFF18\u5186\u3067\u3057\u304B\u3082\u51B7\u3048\u3066\u308B\u304B\u3089\u795E\uFF0E",
  "id" : 345062362656690176,
  "created_at" : "2013-06-13 06:17:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345062287469576192",
  "text" : "\u30A4\u30BA\u30DF\u30E4\u306F\u70CF\u9F8D\u8336\u7F6E\u3044\u3066\u3042\u308B\u3051\u3069\u51B7\u3048\u3066\u306A\u3044\u3057\uFF08\u81EA\u793E\u30D6\u30E9\u30F3\u30C9\u306E\u306F\u51B7\u3048\u3066\u308B\u306E\u304C\u306A\u304A\u6C17\u306B\u98DF\u308F\u306A\u3044\uFF09\uFF0C\u5FA1\u5F71\u306E\u751F\u9BAE\u9928\u306F\u7F6E\u3044\u3066\u306A\u3044\u304B\u3089\u307E\u308B\u3067\u30C0\u30E1\uFF0E",
  "id" : 345062287469576192,
  "created_at" : "2013-06-13 06:17:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345061915262857216",
  "text" : "\uFF7B\uFF9D\uFF84\uFF98\uFF70\u306B\u306F\u7121\u9650\u70CF\u9F8D\u8336\u6A5F\u95A2\u3092\u4F5C\u3063\u3066\u3082\u3089\u3044\u305F\u3044\uFF0E",
  "id" : 345061915262857216,
  "created_at" : "2013-06-13 06:15:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345061770962018304",
  "text" : "\u4ECA\u671D\u958B\u3051\u305F\u70CF\u9F8D\u8336\uFF12\uFF4C\u304C\u3082\u3046\u307B\u3068\u3093\u3069\u306A\u3044\uFF0E\u3069\u3046\u3057\u3066\u70CF\u9F8D\u8336\u3059\u3050\u306A\u304F\u306A\u3063\u3066\u3057\u307E\u3046\u3093\uFF1F",
  "id" : 345061770962018304,
  "created_at" : "2013-06-13 06:15:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345061442912911361",
  "text" : "\u3042\u307E\u308A\u306E\u6691\u3055\u306B\u8010\u3048\u304B\u306D\u3066\u30A8\u30A2\u30B3\u30F3\u3064\u3051\u305F\uFF0E35\u5EA6\u3068\u304B\u3061\u3087\u3063\u3068\u3055\u3059\u304C\u306B\uFF0E",
  "id" : 345061442912911361,
  "created_at" : "2013-06-13 06:13:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345059966887026688",
  "text" : "\u50D5\u304C\u300C\u305D\u3063\u304B\u3041\u300D\u3063\u3066\u8A00\u3046\u6642\u306F\u3053\u308C\u610F\u8B58\u3057\u3066\u308B",
  "id" : 345059966887026688,
  "created_at" : "2013-06-13 06:08:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345056448344109056",
  "text" : "\u7F6A\u306E\u306A\u3044\u5618\u3001\u610F\u5473\u306E\u306A\u3044\u5618",
  "id" : 345056448344109056,
  "created_at" : "2013-06-13 05:54:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345056223760113664",
  "text" : "\u304F\u308B\u30FC\u3069\u6C0F\u3057\u3070\u3089\u304F\u89B3\u6E2C\u3057\u3066\u306A\u3044",
  "id" : 345056223760113664,
  "created_at" : "2013-06-13 05:53:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345014071025868800",
  "text" : "\u6885\u96E8\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B",
  "id" : 345014071025868800,
  "created_at" : "2013-06-13 03:05:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345014038272544769",
  "text" : "\u96E8\u304C\u964D\u3089\u306A\u3044\u306E\u3001\u500B\u4EBA\u7684\u306B\u306F\u5B09\u3057\u3044\u3051\u3069\u3001\u5927\u5C40\u7684\u306B\u306F\u5FC3\u914D\u3067\u3042\u308B",
  "id" : 345014038272544769,
  "created_at" : "2013-06-13 03:05:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345011902054801408",
  "text" : "\u30DD\u30B1\u30E2\u30F3\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u53CB\u4EBA\u306B\u300C\u7389\u30E9\u30C6\u30A3\u30AA\u30B9\u306E\u6D41\u661F\u8010\u3048\u306F\u30B2\u30F3\u30AC\u30FC\u306E\u30B7\u30E3\u30C9\u30DC\u4E8C\u767A\u8010\u3048\u300D\u3068\u304B\u8A00\u3046\u6DF1\u3044\u77E5\u8B58\u3092\u4E38\u6697\u8A18\u3055\u305B\u308B\u904A\u3073\u697D\u3057\u304B\u3063\u305F\u306A\u3041",
  "id" : 345011902054801408,
  "created_at" : "2013-06-13 02:57:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345009881180418048",
  "text" : "\u306A\u301C\u306B\u304C\u3084\u3093\u3068\u5927\u597D\u304D\u3063\u5B50\u3058\u3083",
  "id" : 345009881180418048,
  "created_at" : "2013-06-13 02:49:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345001207263268864",
  "text" : "\u53CB\u4EBA\u304C\u201D\u30AB\u30C6\u30B4\u30EA\u30FC\u201D[\u7BC4\u7587]\u3068\u304B\u201D\u305E\u304F\u201D\n[\u8A00\u8A9E\uFF1F]\u3068\u304B\u8A00\u3063\u3066\u3066\u53CD\u5FDC\u3057\u3066\u3057\u307E\u3046",
  "id" : 345001207263268864,
  "created_at" : "2013-06-13 02:14:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345000855537348608",
  "text" : "\u7DB4\u308A\u9055\u3046\u304B\u3082",
  "id" : 345000855537348608,
  "created_at" : "2013-06-13 02:13:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345000822054195200",
  "text" : "membrane\u3063\u3066\u30E1\u30F3\u30D6\u30EC[\u306F\u304F\u307E\u304F]",
  "id" : 345000822054195200,
  "created_at" : "2013-06-13 02:13:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344999879426338818",
  "text" : "\u30B9\u30DE\u30D6\u30E9\u3084\u308A\u305F\u3044[\u30EA\u30E5\u30AB\u3057\u304B\u4F7F\u3048\u306A\u3044]",
  "id" : 344999879426338818,
  "created_at" : "2013-06-13 02:09:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344998938568441856",
  "text" : "\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC",
  "id" : 344998938568441856,
  "created_at" : "2013-06-13 02:05:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344942058726883329",
  "text" : "\u4E7E\u3044\u305F\u305C\u5589 \u98F2\u3080\u305C\u70CF\u9F8D\u8336",
  "id" : 344942058726883329,
  "created_at" : "2013-06-12 22:19:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344941951184932864",
  "text" : "\u5589\u4E7E\u3044\u305F of the world",
  "id" : 344941951184932864,
  "created_at" : "2013-06-12 22:19:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344737256206114816",
  "text" : "\u51FA\u304B\u3051\u308B",
  "id" : 344737256206114816,
  "created_at" : "2013-06-12 08:45:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344737224828534787",
  "text" : "\u90E8\u5C4B\u306B\u5C45\u3066\u6C57\u3060\u304F\u306B\u306A\u3063\u3066\u3044\u308B\uFF0E\u71B1\u3044\uFF0E[\u4E3B\u306BPC\u306E\u6392\u6C17\u71B1\u3060\u3068\u601D\u308F\u308C\u308B]",
  "id" : 344737224828534787,
  "created_at" : "2013-06-12 08:45:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344736448118931458",
  "text" : "\u30E4\u30AEwww\u30B2\u30FC\u30E0\u30BB\u30F3\u30BF\u30FC\u30E4\u30AEwwwww",
  "id" : 344736448118931458,
  "created_at" : "2013-06-12 08:42:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344736353126330368",
  "text" : "\u5F8C\u8F29\u304B\u3089\u53F0\u98A8\u4E09\u53F7\u306E\u540D\u524D\u304C\u201DYagi\u201D\u3068\u805E\u3044\u3066\u304B\u3089\u601D\u3044\u51FA\u3059\u305F\u3073\u306B\u306B\u3084\u306B\u3084\u3057\u3066\u308B",
  "id" : 344736353126330368,
  "created_at" : "2013-06-12 08:42:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344735448201043968",
  "text" : "\u3053\u306E250\u5186\u306E\u305F\u3081\u306B\u4ECA\u591C\u306F\u81EA\u708A\u3059\u308B\u3053\u3068\u306B\u3057\u3088\u3046\u3063\u3068",
  "id" : 344735448201043968,
  "created_at" : "2013-06-12 08:38:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344734244796502016",
  "text" : "[\u304B\u3063\u3053\u306B\u3044\u308C\u640D\u306D\u305F\u6642\u306E]",
  "id" : 344734244796502016,
  "created_at" : "2013-06-12 08:33:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344734144217108481",
  "text" : "\u30E6\u30FC\u30B6\u30FC\u30B9\u30C8\u30EA\u30FC\u30E0\u3060\u3057\u96FB\u6C60\u55B0\u3044\u305D\u3046[]\u3053\u306A\u307F\u304B\u3093",
  "id" : 344734144217108481,
  "created_at" : "2013-06-12 08:33:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344733842709553152",
  "text" : "\u3042\u30FC\u3053\u308C\u4F7F\u7528\u611F\u3042\u3093\u307E\u308AiPad\u306E\u3084\u3064\u3068\u5909\u308F\u3089\u306A\u3044\u306A[\u753B\u9762\u72ED\u3044\u3051\u3069]",
  "id" : 344733842709553152,
  "created_at" : "2013-06-12 08:32:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344732562343739392",
  "text" : "\u80CC\u306B\u8179\u306F\u4EE3\u3048\u3089\u308C\u306A\u3044\u306E\u3067\u3042\u308B",
  "id" : 344732562343739392,
  "created_at" : "2013-06-12 08:27:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344732511970152448",
  "text" : "\u307E\u3041iPad\u3067\u4F7F\u3044\u52DD\u624B\u826F\u3044\u306E\u77E5\u3063\u3066\u308B\u304B\u3089250\u5186\u6255\u3063\u3066\u843D\u3068\u305D\u3046\uFF0E",
  "id" : 344732511970152448,
  "created_at" : "2013-06-12 08:26:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344731758996103169",
  "text" : "Tweetbot\u3063\u3066iPhone\u30D0\u30FC\u30B8\u30E7\u30F3\u3042\u308B\u306E",
  "id" : 344731758996103169,
  "created_at" : "2013-06-12 08:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344731536534409216",
  "text" : "\u3076\u3063\u3061\u3083\u3051\uFF0C\u3069\u306E\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u304C\u751F\u304D\u6B8B\u3063\u3066\u3066\u3069\u306E\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u304C\u6B7B\u3093\u3067\u308B\u306E\u304B\u308F\u304B\u3089\u3093\u307D\u3093",
  "id" : 344731536534409216,
  "created_at" : "2013-06-12 08:22:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344731441508270080",
  "text" : "TheWorld\u3082\u6B7B\u3093\u3060\u3068\u304B\u8A00\u3046\u306E\u3092\u805E\u3044\u305F\u3088\u3046\u306A[\u6C17\u306E\u305B\u3044\uFF1F]",
  "id" : 344731441508270080,
  "created_at" : "2013-06-12 08:22:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344730897960026112",
  "text" : "\u3067\u3001iPhone\u3067\u826F\u3044\u611F\u3058\u306E\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306A\u306B\u304C\u3042\u308A\u307E\u3059\u304B\u306D",
  "id" : 344730897960026112,
  "created_at" : "2013-06-12 08:20:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344625976820518913",
  "text" : "\u65B0\u3057\u3044\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u3092\u5165\u308C\u308B\u3079\u304D\u6642\u306A\u306E\u304B\u3082\u77E5\u308C\u306A\u3044",
  "id" : 344625976820518913,
  "created_at" : "2013-06-12 01:23:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344625853046616064",
  "text" : "\u30BD\u30A4\u30C1\u30E3\u6B7B\u3093\u3060\u3063\u307D\u304F\u3066\u671D\u304B\u3089\u6357\u3089\u306A\u3044",
  "id" : 344625853046616064,
  "created_at" : "2013-06-12 01:23:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344423788139655168",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 344423788139655168,
  "created_at" : "2013-06-11 12:00:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344317702904623106",
  "text" : "\u9759\u304B\u306B\u304A\u5225\u308C\u3057\u305F",
  "id" : 344317702904623106,
  "created_at" : "2013-06-11 04:58:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344317601259872256",
  "text" : "\u3068\u601D\u3063\u305F\u3089\u30D5\u30A9\u30ED\u30FC\u306F\u3080\u3063\u3061\u3083\u3057\u3066\u305F[300]",
  "id" : 344317601259872256,
  "created_at" : "2013-06-11 04:58:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344317398188441600",
  "text" : "\u306A\u3093\u3067\u79C1\u306E\u3088\u3046\u306A\u96F6\u7D30\u30C4\u30C3\u30A4\u30BF\u30E9\u30FC\u304C\u305D\u3093\u306A\u30A2\u30AB\u30A6\u30F3\u30C8\u306B\u30DB\u30A9\u30ED\u30FC\u3055\u308C\u3066\u3044\u308B\u306E\u304B",
  "id" : 344317398188441600,
  "created_at" : "2013-06-11 04:57:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344317104884961280",
  "text" : "\u3064\u3076\u3084\u304D4\u3068\u304B\u30D5\u30A9\u30ED\u30FC4\u3068\u304B\u3067\u3001\u3064\u3076\u3084\u304D\u304C\u300C\u30C4\u30A4\u30C3\u30BF\u30FC\u59CB\u3081\u307E\u3057\u305F\u30FC\u2606\u300D\u307F\u305F\u3044\u306A\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30B9\u30D1\u30E0\u611F\u304C\u3084\u3070\u3044",
  "id" : 344317104884961280,
  "created_at" : "2013-06-11 04:56:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344281473328758784",
  "text" : "\u725B\u4E73\u5165\u308C\u308C\u3070\u5E7E\u5206\u304B\u30DE\u30B7",
  "id" : 344281473328758784,
  "created_at" : "2013-06-11 02:34:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glacier",
      "screen_name" : "glacier_phys",
      "indices" : [ 0, 13 ],
      "id_str" : "543379554",
      "id" : 543379554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344275292346535936",
  "geo" : { },
  "id_str" : "344281416873414656",
  "in_reply_to_user_id" : 841274743,
  "text" : "@glacier_phys \u30DB\u30C3\u30C8\u30B3\u30FC\u30D2\u30FC\u3082\u80C3\u306B\u306F\u826F\u304F\u306A\u3044\u3067\u3059\u3088[\u6B63\u78BA\u306B\u306F\u7A7A\u8179\u6642\u306B\u306F\u3001\u3067\u3059\u304C]",
  "id" : 344281416873414656,
  "in_reply_to_status_id" : 344275292346535936,
  "created_at" : "2013-06-11 02:34:20 +0000",
  "in_reply_to_screen_name" : "glacier_string",
  "in_reply_to_user_id_str" : "841274743",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344275119503458304",
  "text" : "\u306A\u304A\u80C3\u306B\u306F\u304B\u306A\u308A\u306E\u8CA0\u62C5\u3067\u3042\u308B\u6A21\u69D8",
  "id" : 344275119503458304,
  "created_at" : "2013-06-11 02:09:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344274985449316352",
  "text" : "\u76EE\u899A\u3081\u306E\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u3046\u307E\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042",
  "id" : 344274985449316352,
  "created_at" : "2013-06-11 02:08:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344142075404627968",
  "text" : "[memo]HELLMAN,G. [2003]:'Does category theory provide a framework for mathematical structuralism?', Philosophia Mathematica (3) 11, 129-157.",
  "id" : 344142075404627968,
  "created_at" : "2013-06-10 17:20:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344027932626403328",
  "text" : "\u5B9F\u969B\u3082\u3046\u904E\u53BB\u306E\u907A\u7269",
  "id" : 344027932626403328,
  "created_at" : "2013-06-10 09:47:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344027859368701953",
  "text" : "\u53E3\u304B\u3089\u30E9\u30B8\u30AB\u30BB",
  "id" : 344027859368701953,
  "created_at" : "2013-06-10 09:46:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344027382279188480",
  "text" : "\u81EA\u52D5\u8ECA\u3092\u4E8C\u53F0\u3082\u3089\u3063\u305F\u6642\u3069\u3046\u3059\u308B\u304B\u3001\u3068\u3001\u727D\u5F15\u514D\u8A31\u306B\u3064\u3044\u3066\u5F8C\u8F29\u3068\u697D\u3057\u304F\u304A\u3057\u3083\u3079\u308A\u3057\u305F\u3002",
  "id" : 344027382279188480,
  "created_at" : "2013-06-10 09:44:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344027216046354432",
  "text" : "\u53E3\u304B\u3089\u30C7\u30DE\u67B7",
  "id" : 344027216046354432,
  "created_at" : "2013-06-10 09:44:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344026928354828288",
  "text" : "\u30C7\u30DE\u306F\u3084\u3081\u3088\u3046",
  "id" : 344026928354828288,
  "created_at" : "2013-06-10 09:43:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344026567007154176",
  "text" : "\u306A\u306B\u3044\u3063\u3066\u3093\u306E(\u5DE6\u53F3)",
  "id" : 344026567007154176,
  "created_at" : "2013-06-10 09:41:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344026447993790465",
  "text" : "\u5168\u5358\u5C04\u3041\u3041\u3041\u3041(^^)(^^)(^^)",
  "id" : 344026447993790465,
  "created_at" : "2013-06-10 09:41:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344004296678977537",
  "geo" : { },
  "id_str" : "344004756336943104",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5E97\u5074\u3068\u3057\u3066\u306F\u78BA\u8A8D\u3057\u305F\u3053\u3068\u304C\u5927\u4E8B\u306A\u3093\u3060\u308D\u30FC\u306D\u30FC\u30FC",
  "id" : 344004756336943104,
  "in_reply_to_status_id" : 344004296678977537,
  "created_at" : "2013-06-10 08:14:59 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343998863465664512",
  "text" : "\u4ED8\u5C5E\u56F3\u66F8\u9928\u3067\u30A2\u30A4\u30B9\u30AD\u30E3\u30F3\u30C7\u30FC\u58F2\u3063\u305F\u3089\u58F2\u308C\u308B\u306E\u3067\u306F(\u63D0\u6848)",
  "id" : 343998863465664512,
  "created_at" : "2013-06-10 07:51:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343998723271049217",
  "text" : "\u30A2\u30A4\u30B9\uFF01\uFF01\uFF01\u30A2\u30A4\u30B9\u30F2\u30AF\u30EC\u30FC\uFF01\uFF01\uFF01",
  "id" : 343998723271049217,
  "created_at" : "2013-06-10 07:51:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343998524721098752",
  "text" : "\u3075\u3068\u304F\u305E\u3057\u3087\u304B\u3093 is \u30A2\u30C4\u30A4",
  "id" : 343998524721098752,
  "created_at" : "2013-06-10 07:50:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343998438146457600",
  "text" : "\u30A2\u30A4\u30B9\u98DF\u3079\u305F\u3044\u30FC\u30FC\u30FC\u6C34\u7F8A\u7FB9\u3068\u304B\u3067\u3082\u3044\u3044\u30FC\u30FC\u30FC",
  "id" : 343998438146457600,
  "created_at" : "2013-06-10 07:49:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343987723285196800",
  "text" : "6\u30DA\u30FC\u30B8\u3042\u308B\u30EC\u30B8\u30E5\u30E1\u8349\u6848\u30924\u30DA\u30FC\u30B8\u306B\u53CE\u3081\u308B\u30B9\u30AD\u30EB",
  "id" : 343987723285196800,
  "created_at" : "2013-06-10 07:07:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343932964930998273",
  "text" : "\u8D85\u8179\u75DB\u3045\u3045\u3045",
  "id" : 343932964930998273,
  "created_at" : "2013-06-10 03:29:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343819297220591616",
  "text" : "\u5BDD\u306A\u3044\u3068\u3084\u3070\u3044\u306D\u3001\u304A\u3084\u3059\u307F",
  "id" : 343819297220591616,
  "created_at" : "2013-06-09 19:58:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343818681287061504",
  "text" : "\u7834\u308C\u306A\u3044\u9375\u306F\u306A\u3044(\u6642\u9593\u3084\u3089\u9053\u5177\u304C\u3042\u308C\u3070)\u304B\u3089\u9632\u72AF\u306B\u306F\u958B\u3051\u308B\u306E\u306B\u6642\u9593\u304C\u304B\u304B\u308B\u9375\u304C\u826F\u3044\u3089\u3057\u3044\u3067\u3059\u306D\uFF1F",
  "id" : 343818681287061504,
  "created_at" : "2013-06-09 19:55:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343817887552782337",
  "text" : "\u9AD8\u6821\u306E\u9803\u53CB\u4EBA\u306E\u30A8\u30D5\u30A7\u30AF\u30BF\u30FC\u30B1\u30FC\u30B9\u306E\u9375\u3092\u7834\u3063\u305F\u61D0\u304B\u3057\u3044\u601D\u3072\u51FA[\u672C\u4EBA\u306E\u4F9D\u983C\u3067]",
  "id" : 343817887552782337,
  "created_at" : "2013-06-09 19:52:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343817601178271744",
  "text" : "\u3042\u3068\u306F\u7269\u7406\u7684\u306B\u3054\u306B\u3087\u3054\u306B\u3087\uFF1F",
  "id" : 343817601178271744,
  "created_at" : "2013-06-09 19:51:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343817521662660610",
  "text" : "\u5B89\u3044\u5357\u4EAC\u9320\u304F\u3089\u3044\u306A\u3089\u306A\u3093\u3068\u304B\u306A\u308B",
  "id" : 343817521662660610,
  "created_at" : "2013-06-09 19:50:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343817382466314240",
  "text" : "\u306A\u305CTL\u304C\u9375\u958B\u3051\u306E\u8A71\u306B\u306A\u3063\u3066\u3044\u308B\u306E",
  "id" : 343817382466314240,
  "created_at" : "2013-06-09 19:50:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343817091280953344",
  "text" : "\u7720\u308C\u306A\u307F \u30BA\u30E2\u30E2\u30E2\u30E2\u30E2 \u30A4\u30F3\u30AC\u30AA\u30DB\u30FC",
  "id" : 343817091280953344,
  "created_at" : "2013-06-09 19:49:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343816549309767680",
  "text" : "\u9EBB\u96C0\u3057\u306A\u304C\u3089\u304A\u5C4A\u3051\u3057\u3066\u305F\u54B2\u306E\u30E9\u30B8\u30AA\u3092\u601D\u3044\u51FA\u3057\u305F\u3002",
  "id" : 343816549309767680,
  "created_at" : "2013-06-09 19:47:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343816118043029505",
  "text" : "\u30C4\u30A4\u30B9\u30BF\u30FC\u653E\u9001\u672C\u5F53\u306B\u4F1D\u308F\u3089\u306A\u304B\u3063\u305F\u306A\uFF1F",
  "id" : 343816118043029505,
  "created_at" : "2013-06-09 19:45:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343814836389560320",
  "text" : "(\u304D\u3044\u3066\u3044\u307E\u3059\u3088)",
  "id" : 343814836389560320,
  "created_at" : "2013-06-09 19:40:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343814244585836545",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u306B\u3064\u3044\u30AD\u30E3\u30B9\u3084\u3063\u3066\u3093\u306E\u304B",
  "id" : 343814244585836545,
  "created_at" : "2013-06-09 19:37:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343740922183421952",
  "text" : "facebook\u306E\u6295\u7A3F\u3001\u30B3\u30E1\u30F3\u30C817\u4EF6\u4E2D12\u4EF6\u304C\u306E\u3046\u3053\u3055\u3093\u306A\u306E\u8272\u3005\u3084\u3070\u3044\u3068\u601D\u3046",
  "id" : 343740922183421952,
  "created_at" : "2013-06-09 14:46:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343708145312493568",
  "geo" : { },
  "id_str" : "343708334551097344",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30D2\u30F3\u30C8:\u304B\u304C\u304F\u307E\u3055\u3093\u306E\u5F97\u610F\u6280\u306F\u30C1\u30E7\u30F3\u30DC",
  "id" : 343708334551097344,
  "in_reply_to_status_id" : 343708145312493568,
  "created_at" : "2013-06-09 12:37:07 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343707866789728256",
  "text" : "\u611A\u8005\u3063[\u4F55\u304B\u304C\u6F70\u308C\u308B\u97F3]",
  "id" : 343707866789728256,
  "created_at" : "2013-06-09 12:35:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343707775320326144",
  "text" : "\u512A\u3057\u3044\u5148\u8F29\u3068\u611A\u304B\u306A\u5F8C\u8F29\u306E\u56F3",
  "id" : 343707775320326144,
  "created_at" : "2013-06-09 12:34:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343707530347810817",
  "geo" : { },
  "id_str" : "343707690347933696",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30A2\u30C3\u30CF\u30A4\u2026",
  "id" : 343707690347933696,
  "in_reply_to_status_id" : 343707530347810817,
  "created_at" : "2013-06-09 12:34:33 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343707376089718785",
  "text" : "\u591A\u5206\u9055\u3046",
  "id" : 343707376089718785,
  "created_at" : "2013-06-09 12:33:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343706699191967745",
  "geo" : { },
  "id_str" : "343707341545414657",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30DD\u30F3",
  "id" : 343707341545414657,
  "in_reply_to_status_id" : 343706699191967745,
  "created_at" : "2013-06-09 12:33:10 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343699036433416193",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 343699036433416193,
  "created_at" : "2013-06-09 12:00:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 1, 11 ],
      "id_str" : "158645894",
      "id" : 158645894
    }, {
      "name" : "__pooka",
      "screen_name" : "__pooka",
      "indices" : [ 12, 20 ],
      "id_str" : "2549404663",
      "id" : 2549404663
    }, {
      "name" : "\u3060\u30FC\u3059\u306A",
      "screen_name" : "DarknessCatX",
      "indices" : [ 21, 34 ],
      "id_str" : "258868251",
      "id" : 258868251
    }, {
      "name" : "\u6D85\u69C3",
      "screen_name" : "_ne_ha_n_",
      "indices" : [ 35, 45 ],
      "id_str" : "499591313",
      "id" : 499591313
    }, {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 46, 54 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343650257244147712",
  "text" : ".@eclair_15 @__pooka @DarknessCatX @_ne_ha_n_ @shigmax \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 343650257244147712,
  "created_at" : "2013-06-09 08:46:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343633707514601472",
  "text" : "4\/19\u4EE5\u6765\u306E\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3060\u3063\u305F\u3082\u3088\u3046",
  "id" : 343633707514601472,
  "created_at" : "2013-06-09 07:40:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343633355058864128",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 343633355058864128,
  "created_at" : "2013-06-09 07:39:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343633265246212096",
  "text" : "\u3055\u3066\u3055\u3066\u3072\u3055\u3073\u3055\u306E",
  "id" : 343633265246212096,
  "created_at" : "2013-06-09 07:38:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343597110261841920",
  "text" : "ppp",
  "id" : 343597110261841920,
  "created_at" : "2013-06-09 05:15:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343596118124404736",
  "text" : "\u7D75\u306B\u63CF\u3044\u305F\u3088\u3046\u306A\u5384\u4ECB",
  "id" : 343596118124404736,
  "created_at" : "2013-06-09 05:11:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343596082472833024",
  "text" : "\u3053\u308C\u3057\u304B\u3064\u3076\u3084\u3044\u3066\u3044\u306A\u3044\u30A2\u30AB\u30A6\u30F3\u30C8\u72C2\u6C17\u3092\u611F\u3058\u308B",
  "id" : 343596082472833024,
  "created_at" : "2013-06-09 05:11:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343595510336212992",
  "text" : "\u4E16\u754C\u306F\u7121\u6148\u60B2\u3060\u306A\u3041\u3001\u3068\u601D\u3044\u307E\u3057\u305F[\u3053\u306A\u307F\u304B\u3093]",
  "id" : 343595510336212992,
  "created_at" : "2013-06-09 05:08:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343595281419468801",
  "text" : "\u9854\u672C\u306E\u52E4\u52D9\u5148\u3001\u66F8\u3051\u66F8\u3051\u3063\u3066\u3046\u308B\u3055\u3044\u304B\u3089\"\u52E4\u52D9\u5148:\u660E\u65E5\u3082\u50CD\u304B\u306A\u3044\"\u3063\u3066\u8A2D\u5B9A\u3057\u305F\u3051\u3069\u307E\u3060\u8AB0\u304B\u3089\u3082\u7A81\u3063\u8FBC\u307F\u304C\u6765\u306A\u3044",
  "id" : 343595281419468801,
  "created_at" : "2013-06-09 05:07:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343594684817485825",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u304C\u5C4A\u304F\u624B\u7B48\u3092\u6574\u3048\u305F[\u6301\u3064\u30D9\u30AD\u3082\u306E\u306F\u53CB\u4EBA][\u53CB\u4EBA\u306E\u53CB\u4EBA\u306F\u30A2\u30EB\u30AB\u30A4\u30C0]",
  "id" : 343594684817485825,
  "created_at" : "2013-06-09 05:05:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343592118901698560",
  "text" : "\u8C5A\u30AD\u30E0\u30C1\u3046\u307E\u30FC",
  "id" : 343592118901698560,
  "created_at" : "2013-06-09 04:55:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343578022873550849",
  "text" : "\u8CB7\u3044\u7269\u2026",
  "id" : 343578022873550849,
  "created_at" : "2013-06-09 03:59:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343574713840316418",
  "text" : "\u3042\u30FC\u3001\u30ED\u30C3\u30AF\u306E\u65E5\u304B",
  "id" : 343574713840316418,
  "created_at" : "2013-06-09 03:46:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343425037149286400",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u30A8\u30A8",
  "id" : 343425037149286400,
  "created_at" : "2013-06-08 17:51:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/7563LmLGiC",
      "expanded_url" : "http:\/\/4sq.com\/19RFh6z",
      "display_url" : "4sq.com\/19RFh6z"
    } ]
  },
  "geo" : { },
  "id_str" : "343341922234015744",
  "text" : "\u30A2\u30A4\u30B9\u30C9\u30B3\u30FC\u30D2\u30FC\u30A3\u30A3\u30A3\u30A3\u30A3\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01 (@ \u81EA\u5BB6\u7119\u714E\u73C8\u7432 \u30AC\u30ED) http:\/\/t.co\/7563LmLGiC",
  "id" : 343341922234015744,
  "created_at" : "2013-06-08 12:21:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343338781220421634",
  "text" : "\u6226\u95D8\u306E\u30C6\u30EC\u30D3\u3067AKB\u306E\u306A\u3093\u3061\u3083\u3089\u307F\u3066\u308B\u3051\u3069\u3053\u308C\u4E00\u4F4D\u306E\u5A18\u304C\u697D\u5C4B\u3067\u56F2\u3093\u3067\u68D2\u3067\u53E9\u304B\u308C\u308B\u672A\u6765\u3057\u304B\u898B\u3048\u306A\u3044",
  "id" : 343338781220421634,
  "created_at" : "2013-06-08 12:08:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343337294306091009",
  "text" : "\u51B7\u3084\u3057\u3042\u3081\u3068\u304B\u98F2\u3093\u3067\u308B",
  "id" : 343337294306091009,
  "created_at" : "2013-06-08 12:02:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/TnRjEi2hpx",
      "expanded_url" : "http:\/\/4sq.com\/ZYqTaB",
      "display_url" : "4sq.com\/ZYqTaB"
    } ]
  },
  "geo" : { },
  "id_str" : "343337079092158464",
  "text" : "I'm at \u8239\u5CA1\u6E29\u6CC9 (funaoka onsen) (\u4EAC\u90FD\u5E02\u5317\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/TnRjEi2hpx",
  "id" : 343337079092158464,
  "created_at" : "2013-06-08 12:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343336654611816448",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 343336654611816448,
  "created_at" : "2013-06-08 12:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343307467427545088",
  "text" : "\u81EA\u7136\u9078\u629E\u3068\u30BF\u30A4\u30D7\u3057\u3088\u3046\u3068\u3057\u3066\u81EA\u7136\u5909\u63DB\u3068\u30BF\u30A4\u30D7\u3057\u3066\u3057\u307E\u3046\u4E0D\u5177\u5408",
  "id" : 343307467427545088,
  "created_at" : "2013-06-08 10:04:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343093594116218880",
  "text" : "\u30C4\u30D0\u30E1\u304C\u4F4E\u304F\u98DB\u3093\u3060\u3089\u3001\u305D\u3053\u3089\u4E00\u5E2F\u3092\u6DF1\u304F\u6398\u308B\u3053\u3068\u3067\u96E8\u3092\u9632\u3050\u3068\u3044\u3046\u9078\u629E",
  "id" : 343093594116218880,
  "created_at" : "2013-06-07 19:54:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342983099040276480",
  "text" : "\u5F7C\u306F\u30C0\u30D6\u30EB\u30D9\u30C3\u30C9\u3068\u8A00\u3044\u640D\u306D\u3066\u3053\u308C\u3092\u8A00\u3044\u307E\u3057\u305F",
  "id" : 342983099040276480,
  "created_at" : "2013-06-07 12:35:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342961516355661824",
  "geo" : { },
  "id_str" : "342961603664310273",
  "in_reply_to_user_id" : 155546700,
  "text" : "@DAIKICHIinKUS \uFF1F",
  "id" : 342961603664310273,
  "in_reply_to_status_id" : 342961516355661824,
  "created_at" : "2013-06-07 11:09:52 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342961516355661824",
  "text" : "@DAIKICHIinKUS \u50D5\u304C\u60C5\u5831\u793E\u4F1A\u5B66\u3067Twitter\u306B\u3064\u3044\u3066\u30EC\u30DD\u30FC\u30C8\u66F8\u3044\u305F\u8A71\u3057\u3066\u307E\u3059",
  "id" : 342961516355661824,
  "created_at" : "2013-06-07 11:09:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/u3QzPiqdqy",
      "expanded_url" : "http:\/\/4sq.com\/125yTa3",
      "display_url" : "4sq.com\/125yTa3"
    } ]
  },
  "geo" : { },
  "id_str" : "342960455922352128",
  "text" : "\u3046\u3072\u3087\u30FC (@ \u56DB\u5DDD\u4EAD w\/ 2 others) http:\/\/t.co\/u3QzPiqdqy",
  "id" : 342960455922352128,
  "created_at" : "2013-06-07 11:05:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342797264831520768",
  "text" : "\u7720\u3044\u7720\u3044\uFF01\u7720\u3044\u7720\u3044\uFF01\uFF01\uFF01\uFF01\u4E16\u754C\u306E\u7720\u3044\u304C\u3053\u3053\u306B\u3042\u308B\uFF01",
  "id" : 342797264831520768,
  "created_at" : "2013-06-07 00:16:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342700101170511872",
  "text" : "\u7280",
  "id" : 342700101170511872,
  "created_at" : "2013-06-06 17:50:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342700040663490561",
  "text" : "\u304A\u3084\u3059\u307F\u306A",
  "id" : 342700040663490561,
  "created_at" : "2013-06-06 17:50:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u3042\u308B",
      "screen_name" : "fuwafuwa_Fuaru",
      "indices" : [ 3, 18 ],
      "id_str" : "237330800",
      "id" : 237330800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342699973214863360",
  "text" : "RT @fuwafuwa_Fuaru: \u306A\u3093\u304B\u30B3\u30F3\u30D3\u30CB\u3067\u8CB7\u3044\u7269\u3057\u305F\u3068\u304D\u5272\u308A\u7BB8\u307F\u305F\u3044\u306A\u611F\u3058\u3067\u300C\u3053\u3061\u30895\u5104\u304A\u4ED8\u3051\u3057\u307E\u3059\u304B\u30FC\uFF1F\u300D\u3063\u3066\u805E\u304B\u308C\u30665\u5104\u6B32\u3057\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342699857196244992",
    "text" : "\u306A\u3093\u304B\u30B3\u30F3\u30D3\u30CB\u3067\u8CB7\u3044\u7269\u3057\u305F\u3068\u304D\u5272\u308A\u7BB8\u307F\u305F\u3044\u306A\u611F\u3058\u3067\u300C\u3053\u3061\u30895\u5104\u304A\u4ED8\u3051\u3057\u307E\u3059\u304B\u30FC\uFF1F\u300D\u3063\u3066\u805E\u304B\u308C\u30665\u5104\u6B32\u3057\u3044",
    "id" : 342699857196244992,
    "created_at" : "2013-06-06 17:49:47 +0000",
    "user" : {
      "name" : "\u3075\u3042\u308B",
      "screen_name" : "fuwafuwa_Fuaru",
      "protected" : false,
      "id_str" : "237330800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606238942044647424\/R1YAek2g_normal.png",
      "id" : 237330800,
      "verified" : false
    }
  },
  "id" : 342699973214863360,
  "created_at" : "2013-06-06 17:50:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342611923596083201",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 342611923596083201,
  "created_at" : "2013-06-06 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342551187905720322",
  "text" : "\u6628\u65E5\u306E\u30A6\u30C4\u30C9\u30F3TL\u3092\u771F\u9854\u3067\u30C6\u30E5\u30AC\u308A\u307E\u3057\u305F",
  "id" : 342551187905720322,
  "created_at" : "2013-06-06 07:59:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/59OJY5Rm4c",
      "expanded_url" : "http:\/\/togetter.com\/li\/514450",
      "display_url" : "togetter.com\/li\/514450"
    } ]
  },
  "geo" : { },
  "id_str" : "342550957260931072",
  "text" : "\u300C\u7A7A\u524D\u306E\u30A6\u30C4\u30C9\u30F3TL\u300D\u3092\u30C8\u30A5\u30AE\u30E3\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/59OJY5Rm4c",
  "id" : 342550957260931072,
  "created_at" : "2013-06-06 07:58:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342488276852170753",
  "text" : "\u53CB\u4EBA\u300C\u98F2\u307F\u7269\u8CB7\u3044\u306B\u884C\u304F\u3051\u3069\u306A\u3093\u304B\u3044\u308B\uFF1F\u300D\n\u3048\u3093\u3069\u300C\u3055\u3063\u304D\u8CB7\u3063\u3061\u3083\u3063\u305F\u3057130\u5186\u3061\u3087\u3046\u3060\u3044(\u30BD\u30EB\u30C6\u30A3\u30E9\u30A4\u30C1\u3092\u3068\u308A\u3060\u3057\u306A\u304C\u3089)\u300D\n\u53CB\u4EBA\u300C\u300D",
  "id" : 342488276852170753,
  "created_at" : "2013-06-06 03:49:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342486955285684224",
  "text" : "\u9B3C\u592A\u90CE\u306A\u306E\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 342486955285684224,
  "created_at" : "2013-06-06 03:43:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342486901187543041",
  "text" : "\u76F8\u99AC\u3055\u3093\u306B\u307E\u3067\u9B3C\u592A\u90CE\u547C\u3070\u308F\u308A\u3055\u308C\u305F",
  "id" : 342486901187543041,
  "created_at" : "2013-06-06 03:43:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342486776285364224",
  "text" : "\u66F8\u8A18\u30DD\u30B8\u30B7\u30E7\u30F3\u306A",
  "id" : 342486776285364224,
  "created_at" : "2013-06-06 03:43:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342486233617948672",
  "geo" : { },
  "id_str" : "342486657183920129",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30DE\u30AB\u30BB\u30ED\u30FC",
  "id" : 342486657183920129,
  "in_reply_to_status_id" : 342486233617948672,
  "created_at" : "2013-06-06 03:42:36 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342483554690809856",
  "text" : "\u3053\u3086\u304B\u306A\u308B\u308A",
  "id" : 342483554690809856,
  "created_at" : "2013-06-06 03:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342464260196167681",
  "text" : "\u306A\u306B\u305D\u308C\u3053\u306E\u30DE\u30F3\u30B7\u30E7\u30F3\u307F\u3093\u306A\u30EA\u30A2\u5145\u304B",
  "id" : 342464260196167681,
  "created_at" : "2013-06-06 02:13:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342464197914927104",
  "text" : "(\u540C\u3058\u30A2\u30D1\u30FC\u30C8\u306E)\u4ED6\u306E\u304A\u5BA2\u69D8\u3082\u30CD\u30C3\u30C8\u4F7F\u3048\u3066\u306A\u3044\u72B6\u614B\u306A\u306E\u3067\u2026\u3063\u3066\u306A\u3093\u3060\u305D\u308A\u3083\uFF014\u65E5\u3082\u7E4B\u304C\u3063\u3066\u306A\u304B\u3063\u305F\u3093\u3060\u3088\uFF1F\uFF01\u8AB0\u3082NTT\u306B\u9023\u7D61\u3057\u3066\u306A\u304B\u3063\u305F\u308F\u3051\uFF1F\uFF01",
  "id" : 342464197914927104,
  "created_at" : "2013-06-06 02:13:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342454837562179584",
  "text" : "\u4F55\u3082\u3057\u3066\u306A\u3044\u306E\u306B\u30CD\u30C3\u30C8\u304C\u7E4B\u304C\u3089\u306A\u304F\u306A\u3063\u305F\uFF01\uFF01\uFF01",
  "id" : 342454837562179584,
  "created_at" : "2013-06-06 01:36:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342454689377427458",
  "text" : "NTT\u306E\u4EBA\u3046\u3061\u306B\u304F\u308B\u3089\u3057\u3044\u3057\u7247\u4ED8\u3051\u306A\u304F\u3061\u3083\u3044\u3051\u306A\u304F\u306A\u3063\u305F[\u602A\u6211\u306E\u529F\u540D\uFF1F]",
  "id" : 342454689377427458,
  "created_at" : "2013-06-06 01:35:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342265026566037504",
  "geo" : { },
  "id_str" : "342454563963543553",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304A\u3084\u3042\u308A\u3067\u3057\u305F[\u3044\u307E\u3055\u3089]",
  "id" : 342454563963543553,
  "in_reply_to_status_id" : 342265026566037504,
  "created_at" : "2013-06-06 01:35:05 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342454214431215616",
  "text" : "\u305F\u3076\u3093\u305D\u306E\"\u306A\u3093\u3061\u3083\u3089\u30C6\u30B9\u30C8\"\u4E16\u4EE3\u304C\u793E\u4F1A\u306B\u51FA\u305F\u3089\"\u8907\u6570\u56DE\u30C1\u30E3\u30F3\u30B9\u3092\u4E0E\u3048\u3089\u308C\u3066\u6765\u305F\u82E5\u8005\u306F\u30D7\u30EC\u30C3\u30B7\u30E3\u30FC\u306B\u5F31\u3044\"\u3060\u3068\u304B\"\u3053\u3053\u4E00\u756A\u3068\u3044\u3046\u52DD\u8CA0\u306B\u5F31\u3044\"\u307F\u305F\u3044\u306A\u6279\u5224\u304C\u51FA\u308B\u3093\u3060\u308D\u30FC\u306A\u30FC\u3068\u307C\u3093\u3084\u308A\u601D\u3063\u3066\u3044\u308B",
  "id" : 342454214431215616,
  "created_at" : "2013-06-06 01:33:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342453680559226880",
  "text" : "\u30AA\u30DA\u30EC\u30FC\u30BF\u306E\u304A\u59C9\u3055\u3093\u304C\u7533\u3057\u8A33\u306A\u3055\u305D\u3046\u3067\u7533\u3057\u8A33\u306A\u304B\u3063\u305F[\u8CB4\u65B9\u306F\u60AA\u304F\u306A\u3044]",
  "id" : 342453680559226880,
  "created_at" : "2013-06-06 01:31:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342451563576586240",
  "text" : "\u30CD\u30C3\u30C8\u304C\u7E4B\u304C\u3089\u3093\u304B\u3089\u30B5\u30DD\u30FC\u30C8\u306B\u96FB\u8A71\u3057\u3066\u308B\u306E\u306B\u97F3\u58F0\u304C\u30E1\u30FC\u30EB\u7A93\u53E3\u3082\u3042\u308A\u307E\u3059\u3063\u3066\u30DB\u30FC\u30E0\u30DA\u30FC\u30B8\u3092\u6848\u5185\u3057\u3066\u3066\u8349",
  "id" : 342451563576586240,
  "created_at" : "2013-06-06 01:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342437730141224960",
  "text" : "\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u306E\u697D\u3057\u307F\u65B9\n\u98F2\u307F\u307E\u3059 ( \u25E0\u203F\u25E0 ) \n\u7F8E\u5473\u3057\u3044\uFF01\uFF01 \u270C('\u03C9'\u270C )\u4E09\u270C('\u03C9')\u270C\u4E09( \u270C'\u03C9')\u270C",
  "id" : 342437730141224960,
  "created_at" : "2013-06-06 00:28:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342422161635557376",
  "text" : "\u30BB\u30F3\u30BF\u8A66\u9A13\u5EC3\u6B62\u30CA\u30F3\u30C7\uFF1F\uFF01",
  "id" : 342422161635557376,
  "created_at" : "2013-06-05 23:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342265004936011776",
  "text" : "\u304A\u3084\u3059\u307F\uFF01",
  "id" : 342265004936011776,
  "created_at" : "2013-06-05 13:01:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342264997335928832",
  "text" : "\u3042\u307E\u308A\u306B\u7720\u3044\u306E\u30676\u6642\u306B\u8D77\u304D\u308B\u4E88\u5B9A\u3067\u5BDD\u308B",
  "id" : 342264997335928832,
  "created_at" : "2013-06-05 13:01:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342250932081401858",
  "text" : "\u304B\u3048\u308B\u304B",
  "id" : 342250932081401858,
  "created_at" : "2013-06-05 12:05:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342248886171230208",
  "geo" : { },
  "id_str" : "342248988147335170",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u30EC\u30DD\u304A\u5F85\u3061\u3057\u3066\u307E\u3059\uFF01",
  "id" : 342248988147335170,
  "in_reply_to_status_id" : 342248886171230208,
  "created_at" : "2013-06-05 11:58:12 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342247851075727361",
  "geo" : { },
  "id_str" : "342248080613191680",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u8DDD\u96E2\u7684\u306B\u306F\u3069\u306E\u4F4D\u3067\u3059\uFF1F",
  "id" : 342248080613191680,
  "in_reply_to_status_id" : 342247851075727361,
  "created_at" : "2013-06-05 11:54:35 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342247204007837696",
  "text" : "\u5BB6\u5E30\u3063\u305F\u3089\u3066\u3085\u304E\u3083\u308B\u304B\u30FC",
  "id" : 342247204007837696,
  "created_at" : "2013-06-05 11:51:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u3054\u305F\u3093(\u02D8\u03C9\u02D8)",
      "screen_name" : "_sgtn",
      "indices" : [ 3, 9 ],
      "id_str" : "138688851",
      "id" : 138688851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342246081368825857",
  "text" : "RT @_sgtn: \u30A6\u30C4\u30C9\u30F3\u3063\u3066\u5317\u671D\u9BAE\u3067\u683D\u57F9\u3055\u308C\u3066\u305D\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342245272816070656",
    "text" : "\u30A6\u30C4\u30C9\u30F3\u3063\u3066\u5317\u671D\u9BAE\u3067\u683D\u57F9\u3055\u308C\u3066\u305D\u3046",
    "id" : 342245272816070656,
    "created_at" : "2013-06-05 11:43:26 +0000",
    "user" : {
      "name" : "\u3057\u3087\u3054\u305F\u3093(\u02D8\u03C9\u02D8)",
      "screen_name" : "_sgtn",
      "protected" : false,
      "id_str" : "138688851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595075025981476864\/zdeIKA6X_normal.jpg",
      "id" : 138688851,
      "verified" : false
    }
  },
  "id" : 342246081368825857,
  "created_at" : "2013-06-05 11:46:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342245497051963392",
  "geo" : { },
  "id_str" : "342245704724520960",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3069\u3053\u306B\u767E\u5186\u3044\u308C\u308B\u3093\u3067\u3059\u304B\uFF1F(\u307E\u304C\u304A",
  "id" : 342245704724520960,
  "in_reply_to_status_id" : 342245497051963392,
  "created_at" : "2013-06-05 11:45:09 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342245214422962177",
  "text" : "\u30B9\u30B4\u30A4=\u30A6\u30A4\u30C6\u30EB",
  "id" : 342245214422962177,
  "created_at" : "2013-06-05 11:43:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342244777321963520",
  "text" : "\u30A6\u30C4\u30C9\u30F3\uFF01\u4E00\u756A\u5927\u597D\u304D\u306A\u30DD\u30B1\u30E2\u30F3\u3067\u3059\uFF01",
  "id" : 342244777321963520,
  "created_at" : "2013-06-05 11:41:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342244615426015232",
  "text" : "RT @kiu_uit: \u30A6\u30C4\u30C9\u30F3\u304B\u3089\u30A6\u3092\u3068\u3063\u3066\u307F\u3088\u3046\uFF01\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F \n\uFF1E\u3000\u30C4\u30C9\u30F3\u3000\uFF1C\n \uFFE3Y^Y^Y^Y^Y\uFFE3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yuugatter.yu-yake.com\/\" rel=\"nofollow\"\u003EYuugatter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342244468814147584",
    "text" : "\u30A6\u30C4\u30C9\u30F3\u304B\u3089\u30A6\u3092\u3068\u3063\u3066\u307F\u3088\u3046\uFF01\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F \n\uFF1E\u3000\u30C4\u30C9\u30F3\u3000\uFF1C\n \uFFE3Y^Y^Y^Y^Y\uFFE3",
    "id" : 342244468814147584,
    "created_at" : "2013-06-05 11:40:14 +0000",
    "user" : {
      "name" : "\u304D\u306C\u3044\u30C8\u30A5\u30FC\u30F3",
      "screen_name" : "0_u0",
      "protected" : false,
      "id_str" : "62833617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549969572116185088\/0QrRj46-_normal.png",
      "id" : 62833617,
      "verified" : false
    }
  },
  "id" : 342244615426015232,
  "created_at" : "2013-06-05 11:40:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342243612333076480",
  "text" : "\u304B\u3064\u3066\u30A6\u30C4\u30C9\u30F3\u304C\u3053\u3093\u306A\u306B\u811A\u5149\u3092\u6D74\u3073\u305F\u3053\u3068\u304C\u3042\u3063\u305F\u3060\u308D\u3046\u304B",
  "id" : 342243612333076480,
  "created_at" : "2013-06-05 11:36:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342243436369420288",
  "geo" : { },
  "id_str" : "342243498348646400",
  "in_reply_to_user_id" : 1230390426,
  "text" : "@kip_qit \u304F\u3063\u305D\u3053\u3093\u306A\u306E\u3067wwwww",
  "id" : 342243498348646400,
  "in_reply_to_status_id" : 342243436369420288,
  "created_at" : "2013-06-05 11:36:23 +0000",
  "in_reply_to_screen_name" : "8_u8",
  "in_reply_to_user_id_str" : "1230390426",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342243205418471424",
  "text" : "\u30A6\u30C4\u30C9\u30F3\u304C\u7D76\u5BFE\u306B\u8A00\u308F\u306A\u3044\u30B7\u30EA\u30FC\u30BAwwwww",
  "id" : 342243205418471424,
  "created_at" : "2013-06-05 11:35:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342243148124266498",
  "text" : "RT @kip_qit: \u3046\u3064\u3069\u3093\u300C\u3082\u3046\u4E00\u66F2\u904A\u3079\u308B\u30C9\u30F3\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yuugatter.yu-yake.com\/\" rel=\"nofollow\"\u003EYuugatter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342243105703067648",
    "text" : "\u3046\u3064\u3069\u3093\u300C\u3082\u3046\u4E00\u66F2\u904A\u3079\u308B\u30C9\u30F3\u300D",
    "id" : 342243105703067648,
    "created_at" : "2013-06-05 11:34:49 +0000",
    "user" : {
      "name" : "\u304D\u3068",
      "screen_name" : "8_u8",
      "protected" : true,
      "id_str" : "1230390426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574511385389887488\/zeqPOQq1_normal.jpeg",
      "id" : 1230390426,
      "verified" : false
    }
  },
  "id" : 342243148124266498,
  "created_at" : "2013-06-05 11:34:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342243070236045312",
  "text" : "@DAIKICHIinKUS \u8349\u30BF\u30A4\u30D7\u304C\u504F\u308A\u307E\u3059\u306D\uFF01\uFF01\uFF01",
  "id" : 342243070236045312,
  "created_at" : "2013-06-05 11:34:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342242777444270080",
  "text" : "[\u3086\u308B\u307C]\u30AD\u30E5\u30A2\u30A6\u30C4\u30C9\u30F3\u306E\u306A\u304B\u307E",
  "id" : 342242777444270080,
  "created_at" : "2013-06-05 11:33:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342242169907736576",
  "text" : "\u30AD\u30E5\u30A2\u30A6\u30C4\u30C9\u30F3",
  "id" : 342242169907736576,
  "created_at" : "2013-06-05 11:31:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342241946544250880",
  "text" : "\u8D85\u53D7\u3051\u308Bwwwwwww",
  "id" : 342241946544250880,
  "created_at" : "2013-06-05 11:30:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342240415937863681",
  "geo" : { },
  "id_str" : "342240614101946369",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30A6\u30C4\u30C9\u30F3\u306E\u30E2\u30CE\u30DE\u30CD\u304B\u3068\u601D\u3044\u307E\u3057\u305F",
  "id" : 342240614101946369,
  "in_reply_to_status_id" : 342240415937863681,
  "created_at" : "2013-06-05 11:24:55 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342240510938861568",
  "text" : "\u305C\u308A\u30FC\u300C\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u306E\u3053\u308C\u3001\u30A6\u30C4\u30C9\u30F3\u3058\u3083\u306A\u304F\u3066\u30AB\u30A8\u30EB\u3060\u308F\u300D",
  "id" : 342240510938861568,
  "created_at" : "2013-06-05 11:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342239985761648641",
  "text" : "favster\u8AB2\u91D1\u3057\u3066\u305F\u3089\u30C8\u30ED\u30D5\u30A3\u30FC\u3042\u3052\u3066\u305F\u30EC\u30D9\u30EB",
  "id" : 342239985761648641,
  "created_at" : "2013-06-05 11:22:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342239743104405504",
  "text" : "\u60AA\u30CE\u30EA\u306B\u3057\u3066\u3082\u3072\u3069\u3044",
  "id" : 342239743104405504,
  "created_at" : "2013-06-05 11:21:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342239634094444544",
  "text" : "@kotorin_phoenix \u3046\u3073\u3087\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\uFF1F(\uFF84\uFF9E\uFF70\uFF9D",
  "id" : 342239634094444544,
  "created_at" : "2013-06-05 11:21:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342239244124815360",
  "text" : "@DAIKICHIinKUS \u3046\u3073\u3087\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048(\uFF84\uFF9E\uFF70\uFF9D",
  "id" : 342239244124815360,
  "created_at" : "2013-06-05 11:19:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342238965925040128",
  "text" : "\u3069\u3093\u306A\u30EA\u30D7\u30E9\u30A4\u306B\u3082 \u3046\u3073\u3087\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048(\uFF84\uFF9E\uFF70\uFF9D \u3063\u3066\u8FD4\u305B\u3070\u52DD\u3066\u308B",
  "id" : 342238965925040128,
  "created_at" : "2013-06-05 11:18:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306E\u7834\u58CA\u529B",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342238687121264641",
  "text" : "\u3046\u3073\u3087\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048(\uFF84\uFF9E\uFF70\uFF9D #\u306E\u7834\u58CA\u529B",
  "id" : 342238687121264641,
  "created_at" : "2013-06-05 11:17:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342238366097612804",
  "text" : "\u4E00\u3064\u306E\u7A7A\u8033\u304C\u30A6\u30C4\u30C9\u30F3\u306E\u4EBA\u6C17\u3092\u3055\u3055\u3084\u304B\u306B\u3067\u3082\u3042\u3052\u305F\u3053\u3068\u3092\u8003\u3048\u308C\u3070\u7A7A\u8033\u3082\u60AA\u304F\u306A\u3044\u3067\u3059\u306D",
  "id" : 342238366097612804,
  "created_at" : "2013-06-05 11:15:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342238083636412417",
  "text" : "\u3064 \u30EA\u30FC\u30D5\u306E\u3044\u3057 RT @DAIKICHIinKUS: \u308F\u305F\u3057\u3046\u30FC\u30FC\u30FC\u30FC\u3064\u30FC\u30FC\u30FC\u30FC\u3069\u3093\n\u3044\u3064\u30FC\u307E\u3067\u30FC\u3082\u3046\u30FC\u30FC\u30FC\u30FC\u3064\u30FC\u30FC\u30FC\u30FC\u3069\u3093",
  "id" : 342238083636412417,
  "created_at" : "2013-06-05 11:14:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "river4361",
      "screen_name" : "river4361",
      "indices" : [ 0, 10 ],
      "id_str" : "2526962401",
      "id" : 2526962401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342237602918842369",
  "geo" : { },
  "id_str" : "342237814110425088",
  "in_reply_to_user_id" : 320494295,
  "text" : "@river4361 \u3060\u3044\u305F\u3044\u305D\u3053\u3089\u3078\u3093\u306B\u3057\u304B\u3044\u306A\u3044\u3067\u3059\u306D",
  "id" : 342237814110425088,
  "in_reply_to_status_id" : 342237602918842369,
  "created_at" : "2013-06-05 11:13:48 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "river4361",
      "screen_name" : "river4361",
      "indices" : [ 0, 10 ],
      "id_str" : "2526962401",
      "id" : 2526962401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342237070917509120",
  "geo" : { },
  "id_str" : "342237497683763200",
  "in_reply_to_user_id" : 320494295,
  "text" : "@river4361 \u30C9\u30B3\u30C7\u30FC\uFF1F\uFF01",
  "id" : 342237497683763200,
  "in_reply_to_status_id" : 342237070917509120,
  "created_at" : "2013-06-05 11:12:32 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u306B\uFF08\u59B9\uFF09",
      "screen_name" : "funiimouto",
      "indices" : [ 3, 14 ],
      "id_str" : "292901585",
      "id" : 292901585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342237446249005056",
  "text" : "RT @funiimouto: \u30EB\u30D5\u30A3\u300C\u3046\u308B\u305B\u3047\uFF01\u3044\u3053\u3046\uFF01\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30C9\u30F3\u3000\uFF1C\n  \uFFE3Y^Y^Y\uFFE3\n\u30C1\u30E7\u30C3\u30D1\u30FC\u300C\u3046\u308B\u305B\u3047\uFF01\u3044\u304B\u3093\uFF01\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30C9\u30F3\u3000\uFF1C\n  \uFFE3Y^Y^Y\uFFE3\n\u30EB\u30D5\u30A3\u300C\u3046\u308B\u305B\u3047\uFF01\u3044\u3053\u3046\uFF01\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30C9\u30F3\u3000\uFF1C\n  \uFFE3Y^Y^Y\uFFE3\n\u30C1\u30E7\u30C3\u30D1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/589lab.net\/works\/cerisier\/\" rel=\"nofollow\"\u003ECerisier\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342237227222462465",
    "text" : "\u30EB\u30D5\u30A3\u300C\u3046\u308B\u305B\u3047\uFF01\u3044\u3053\u3046\uFF01\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30C9\u30F3\u3000\uFF1C\n  \uFFE3Y^Y^Y\uFFE3\n\u30C1\u30E7\u30C3\u30D1\u30FC\u300C\u3046\u308B\u305B\u3047\uFF01\u3044\u304B\u3093\uFF01\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30C9\u30F3\u3000\uFF1C\n  \uFFE3Y^Y^Y\uFFE3\n\u30EB\u30D5\u30A3\u300C\u3046\u308B\u305B\u3047\uFF01\u3044\u3053\u3046\uFF01\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30C9\u30F3\u3000\uFF1C\n  \uFFE3Y^Y^Y\uFFE3\n\u30C1\u30E7\u30C3\u30D1\u30FC\u300C\u3046\u308B\u305B\u3047\uFF01\u3044\u304B\u3093\uFF01\u300D",
    "id" : 342237227222462465,
    "created_at" : "2013-06-05 11:11:28 +0000",
    "user" : {
      "name" : "\u3075\u306B\uFF08\u59B9\uFF09",
      "screen_name" : "funiimouto",
      "protected" : false,
      "id_str" : "292901585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561846964774375424\/sAxenHIN_normal.jpeg",
      "id" : 292901585,
      "verified" : false
    }
  },
  "id" : 342237446249005056,
  "created_at" : "2013-06-05 11:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342237294092247040",
  "text" : "\u30A6\u30C4\u30C9\u30F3\u3068\u3044\u3046\u30C1\u30E7\u30A4\u30B9\u306E\u5FAE\u5999\u3055\u304C\u5FC3\u306B\u97FF\u304D\u6E21\u308B",
  "id" : 342237294092247040,
  "created_at" : "2013-06-05 11:11:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342236927744933888",
  "text" : "RT @kagakuma: \u300C\u7D76\u5BFE\u6E26\u5EA6\u300D\u3092\u300C\u7D76\u5BFE\u30A6\u30C4\u30C9\u30F3\u300D\u306B\u7A7A\u8033\u3057\u305F\u4E0A\u306B20\u5206\u304F\u3089\u3044\u30C4\u30A4\u30FC\u30C8\u30CD\u30BF\u306B\u3057\u3066\u30B1\u30E9\u30B1\u30E9\u7B11\u3063\u3066\u308B\u5F8C\u8F29\u3092\u6301\u3063\u3066\u3057\u307E\u3063\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342236662098702336",
    "text" : "\u300C\u7D76\u5BFE\u6E26\u5EA6\u300D\u3092\u300C\u7D76\u5BFE\u30A6\u30C4\u30C9\u30F3\u300D\u306B\u7A7A\u8033\u3057\u305F\u4E0A\u306B20\u5206\u304F\u3089\u3044\u30C4\u30A4\u30FC\u30C8\u30CD\u30BF\u306B\u3057\u3066\u30B1\u30E9\u30B1\u30E9\u7B11\u3063\u3066\u308B\u5F8C\u8F29\u3092\u6301\u3063\u3066\u3057\u307E\u3063\u305F\u3002",
    "id" : 342236662098702336,
    "created_at" : "2013-06-05 11:09:13 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 342236927744933888,
  "created_at" : "2013-06-05 11:10:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342236895926960128",
  "text" : "\u7D76\u5BFE\u30A6\u30C4\u30C9\u30F3\u3068\u304B\u7A81\u7136\u3064\u3076\u3084\u304F\u5148\u8F29\u3092\u6301\u3063\u3066\u3057\u307E(\u3069\u30FC\u3093",
  "id" : 342236895926960128,
  "created_at" : "2013-06-05 11:10:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342236535778836480",
  "text" : "\u3042\u305F\u307E\u304A\u304B\u3057\u3044",
  "id" : 342236535778836480,
  "created_at" : "2013-06-05 11:08:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u77F3\u585A\uFF08\u7121\u6240\u5C5E\uFF09",
      "screen_name" : "Yusuke_Ishizuka",
      "indices" : [ 0, 16 ],
      "id_str" : "132814552",
      "id" : 132814552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342236201056620544",
  "geo" : { },
  "id_str" : "342236235403771904",
  "in_reply_to_user_id" : 132814552,
  "text" : "@Yusuke_Ishizuka \u3044\u3048\u306A\u306B\u3082",
  "id" : 342236235403771904,
  "in_reply_to_status_id" : 342236201056620544,
  "created_at" : "2013-06-05 11:07:31 +0000",
  "in_reply_to_screen_name" : "Yusuke_Ishizuka",
  "in_reply_to_user_id_str" : "132814552",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/342236016213639168\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/O7ElPwGu3D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL_d1_ACQAAFw3y.png",
      "id_str" : "342236016217833472",
      "id" : 342236016217833472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL_d1_ACQAAFw3y.png",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/O7ElPwGu3D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342236016213639168",
  "text" : "\u4E00\u69D8\u30A6\u30C4\u30C9\u30F3 http:\/\/t.co\/O7ElPwGu3D",
  "id" : 342236016213639168,
  "created_at" : "2013-06-05 11:06:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342235588101038081",
  "text" : "\u203B\u3075\u3064\u3046\u306E\u30A6\u30C4\u30C9\u30F3\u3067\u3059",
  "id" : 342235588101038081,
  "created_at" : "2013-06-05 11:04:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/342235473684615168\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/lDwF3DQMK0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL_dWZ7CUAALJdt.gif",
      "id_str" : "342235473688809472",
      "id" : 342235473688809472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL_dWZ7CUAALJdt.gif",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lDwF3DQMK0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342235473684615168",
  "text" : "\u4E00\u69D8\u30A6\u30C4\u30C9\u30F3 http:\/\/t.co\/lDwF3DQMK0",
  "id" : 342235473684615168,
  "created_at" : "2013-06-05 11:04:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342225054555308032",
  "text" : "\u7D76\u5BFE\u30A6\u30C4\u30C9\u30F3",
  "id" : 342225054555308032,
  "created_at" : "2013-06-05 10:23:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342177623390158848",
  "text" : "\u9078\u629E\u516C\u7406\u3061\u3083\u3093\u300C\u6574\u5217\u3057\u306A\u3055\u3044\u300D\n\u96C6\u5408\u300C\u30CF\u30A4\u30E8\u30ED\u30B3\u30F3\u30C7\u30FC\uFF01\u300D",
  "id" : 342177623390158848,
  "created_at" : "2013-06-05 07:14:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342068148616454144",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 342068148616454144,
  "created_at" : "2013-06-04 23:59:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342068122532052992",
  "text" : "\u3084\u3070\u2026\u3053\u306E\u304A\u8179\u306E\u75DB\u307F\u65B9\u306F\u2026\u4E0D\u7A4F\u2026",
  "id" : 342068122532052992,
  "created_at" : "2013-06-04 23:59:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341944550555795456",
  "text" : "\u304A\u304A\u304A\u304A\u3084\u3059\u307F\uFF01\uFF01",
  "id" : 341944550555795456,
  "created_at" : "2013-06-04 15:48:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341943458933645314",
  "text" : "\u3044\u308D\u3093\u306A\u3082\u306E\u306B\u5BFE\u3057\u3066\u7533\u3057\u8A33\u306A\u3044\u3068\u601D\u3046",
  "id" : 341943458933645314,
  "created_at" : "2013-06-04 15:44:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341942656299057153",
  "text" : "[\u751F\u4F53\u306E\u30A8\u30CD\u30EB\u30AE\u30FC\u5909\u63DB\u52B9\u7387\u304C\u7570\u5E38\u306B\u826F\u3044\u3063\u3066\u805E\u3044\u305F\u3053\u3068\u3042\u308B\u3051\u3069]",
  "id" : 341942656299057153,
  "created_at" : "2013-06-04 15:40:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341942617224904704",
  "text" : "\u4EBA\u9593\u3001\u71C3\u8CBB\u60AA\u3044",
  "id" : 341942617224904704,
  "created_at" : "2013-06-04 15:40:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341942248721756160",
  "text" : "\u3061\u3087\u3063\u3068\u96E2\u8131\u3057\u3066\u305F\u3089\u6D74\u8863\u306Epost\u5730\u5473\u306B\u4F38\u3073\u3066\u308B",
  "id" : 341942248721756160,
  "created_at" : "2013-06-04 15:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341919108700442625",
  "text" : "\u666E\u6BB5\u304B\u30893\u3064\u4F7F\u3063\u3066\u305F(",
  "id" : 341919108700442625,
  "created_at" : "2013-06-04 14:07:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341919058217816065",
  "text" : "\u30C0\u30D6\u30EB\u30D9\u30C3\u30C9\u3067\u4E00\u4EBA\u3067\u6795\u30925\u3064\u304F\u3089\u3044\u4F7F\u3063\u3066\u7720\u308A\u305F\u3044",
  "id" : 341919058217816065,
  "created_at" : "2013-06-04 14:07:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341918570055356417",
  "text" : "\u571F\u4E0B\u5EA7\u306F\u66B4\u529B\u306B\u9650\u308A\u306A\u304F\u8FD1\u3044",
  "id" : 341918570055356417,
  "created_at" : "2013-06-04 14:05:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341918038163075072",
  "text" : "(\uFF1F)",
  "id" : 341918038163075072,
  "created_at" : "2013-06-04 14:03:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341918027941564416",
  "text" : "\u6D74\u8863\u306B\u300C\u305D\u306E\u5973\u306E\u5B50\u4F3C\u5408\u3063\u3066\u308B\u3058\u3083\u3093\u3002\u300D\u3068\u304B\u8A00\u3044\u305F\u3044",
  "id" : 341918027941564416,
  "created_at" : "2013-06-04 14:03:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341917902150189056",
  "text" : "RT @kagakuma: \u7947\u5712\u796D\u306F\u3069\u3063\u3061\u3067\u3082\u3044\u3044\u306E\u3067\u6D74\u8863\u59FF\u306E\u5973\u306E\u5B50\u3068\u5F85\u3061\u5408\u308F\u305B\u3057\u3066\u300C\u304A\u304A\u3001\u6D74\u8863\u306A\u3093\u3060\u3002\u4F3C\u5408\u3063\u3066\u3093\u3058\u3083\u3093\u3002\u99AC\u5B50\u306B\u3082\u8863\u88C5\u3063\u3066\u3084\u3064\uFF1F\u300D\u3068\u304B\u4E00\u8A00\u591A\u3044\u3053\u3068\u8A00\u3063\u3066\u307D\u304B\u3063\u3068\u3084\u3089\u308C\u305F\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341917707224088576",
    "text" : "\u7947\u5712\u796D\u306F\u3069\u3063\u3061\u3067\u3082\u3044\u3044\u306E\u3067\u6D74\u8863\u59FF\u306E\u5973\u306E\u5B50\u3068\u5F85\u3061\u5408\u308F\u305B\u3057\u3066\u300C\u304A\u304A\u3001\u6D74\u8863\u306A\u3093\u3060\u3002\u4F3C\u5408\u3063\u3066\u3093\u3058\u3083\u3093\u3002\u99AC\u5B50\u306B\u3082\u8863\u88C5\u3063\u3066\u3084\u3064\uFF1F\u300D\u3068\u304B\u4E00\u8A00\u591A\u3044\u3053\u3068\u8A00\u3063\u3066\u307D\u304B\u3063\u3068\u3084\u3089\u308C\u305F\u3044\u3002",
    "id" : 341917707224088576,
    "created_at" : "2013-06-04 14:01:48 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 341917902150189056,
  "created_at" : "2013-06-04 14:02:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341917832851898370",
  "text" : "\u4E00\u4EBA\u571F\u4E0B\u5EA7\u3063\u3066\u8907\u6570\u4EBA\u571F\u4E0B\u5EA7\u304C\u524D\u63D0\u307F\u305F\u3044\u3067\u8B0E\u3081\u3044\u3066\u3044\u308B",
  "id" : 341917832851898370,
  "created_at" : "2013-06-04 14:02:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341917554744389633",
  "text" : "\u30D9\u30C3\u30C9\u306F\u5E83\u3044\u306B\u8D8A\u3057\u305F\u3053\u3068\u306A\u3044\u3058\u3083\u306A\u3044\u3067\u3059\u304B\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 341917554744389633,
  "created_at" : "2013-06-04 14:01:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 17, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341917383323181056",
  "text" : "@kotorin_phoenix #\u306F\u3044",
  "id" : 341917383323181056,
  "created_at" : "2013-06-04 14:00:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341917337030647808",
  "text" : "@desole_mi \u4E00\u4EBA\u66AE\u3089\u3057\u306E\u90E8\u5C4B\u306B\u30C0\u30D6\u30EB\u30D9\u30C3\u30C9\u304A\u3053\u3046\u3068\u601D\u3063\u3066\u305F\u50D5\u306E\u60AA\u53E3\u306F\u3084\u3081\u307E\u3057\u3087\u3046[\u7279\u306B\u5973\u6027\u3092\u9023\u308C\u8FBC\u3080\u3064\u3082\u308A\u3082\u306A\u304F]",
  "id" : 341917337030647808,
  "created_at" : "2013-06-04 14:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341917151730487296",
  "text" : "\u4E00\u4EBA\u30B9\u30EF\u30F3\u30DC\u30FC\u30C8\u306F\u904B\u52D5\u306B\u306A\u308A\u305D\u3046(\u3053\u306A\u307F)",
  "id" : 341917151730487296,
  "created_at" : "2013-06-04 13:59:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341916843327492097",
  "text" : "\u4E00\u4EBA\u796D\u308A(\u796D\u308A\u306B\u4E00\u4EBA\u3067\u53C2\u52A0[\u4E00\u4EBA\u3067\u796D\u308A\u3092\u3057\u305F\u308F\u3051\u3067\u306F\u306A\u3044])\u306F\u3084\u3063\u305F\u3053\u3068\u3042\u308B",
  "id" : 341916843327492097,
  "created_at" : "2013-06-04 13:58:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341916622845517825",
  "text" : "\u4E00\u4EBA\u30E9\u30D6\u30DB\u3068\u3044\u3046\u96FB\u6CE2\u3092\u53D7\u3051\u53D6\u3063\u305F\u304C\u3053\u308C\u306F\u2026[\u5BBF\u6CCA\u65BD\u8A2D\u3068\u3057\u3066\u4F7F\u3046\u4EBA\u3082\u3044\u308B\u3089\u3057\u3044\u304B\u3089\u3042\u308A\u306A\u306E\u304B\uFF1F]",
  "id" : 341916622845517825,
  "created_at" : "2013-06-04 13:57:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341916223413579776",
  "text" : "\u4E00\u4EBA\u904A\u5712\u5730\u3001\u4E00\u4EBA\u5C45\u9152\u5C4B\u3001\u4E00\u4EBA\u5BFF\u53F8\u3092\u63D0\u6848\u3055\u308C\u305F\u3051\u3069\u5F8C\u308D\u4E8C\u3064\u306F\u304A\u91D1\u306B\u4F59\u88D5\u304C\u3042\u308C\u3070\u3059\u3050\u306B\u3067\u3082\u3067\u304D\u305D\u3046",
  "id" : 341916223413579776,
  "created_at" : "2013-06-04 13:55:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341915787105288192",
  "geo" : { },
  "id_str" : "341915985613312000",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3084\u3063\u3066\u898B\u305F\u3044[\u304A\u91D1\u304A\u304B\u306D\u2026]",
  "id" : 341915985613312000,
  "in_reply_to_status_id" : 341915787105288192,
  "created_at" : "2013-06-04 13:54:58 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E00\u4EBA",
      "indices" : [ 22, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341915876829835267",
  "text" : "\u4E00\u4EBA\u30C7\u30A3\u30BA\u30CB\u30FC\u30E9\u30F3\u30C9\u3092\u697D\u3057\u3080\u58F0\u512A\u3055\u3093\u306E\u8A71\u2026 #\u4E00\u4EBA\u25CB\u25CB",
  "id" : 341915876829835267,
  "created_at" : "2013-06-04 13:54:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341914992855117824",
  "geo" : { },
  "id_str" : "341915389934063616",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305D\u308C\u306F\u9593\u9055\u3044\u306A\u3044\u3067\u3059\u306D\u3001\u81E8\u5834\u611F\u3082\u542B\u3081\u3066\u3042\u306E\u5024\u6BB5\u306A\u3093\u3067\u3057\u3087\u3046\u3057[\u305D\u308C\u3067\u3082\u3061\u3087\u3063\u3068\u9AD8\u304F\u611F\u3058\u3066\u3057\u307E\u3044\u307E\u3059][\u305F\u3076\u3093\u50D5\u306E\u91D1\u92AD\u72B6\u6CC1\u306B\u3082\u4F9D\u5B58\u3057\u305F\u611F\u899A\u3067\u3059\u304C]",
  "id" : 341915389934063616,
  "in_reply_to_status_id" : 341914992855117824,
  "created_at" : "2013-06-04 13:52:36 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341915072337174528",
  "text" : "\u304A\u3064\u307E\u307F\u5168\u822C\u5927\u597D\u304D\u306A\u306E\u3067\u6C17\u6301\u3061\u7684\u306B\u306F\u826F\u3044\u3051\u308C\u3069\u5E97\u5074\u304B\u3089\u3057\u305F\u3089\u826F\u3044\u9854\u3055\u308C\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u601D\u3063\u3066\u3057\u307E\u3046[\u4E00\u4EBA\u5C45\u9152\u5C4B[\u30CE\u30F3\u30A2\u30EB\u30B3\u30FC\u30EB]]",
  "id" : 341915072337174528,
  "created_at" : "2013-06-04 13:51:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 3, 15 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341914880183504896",
  "text" : "RT @p_joker1989: \u5C45\u9152\u5C4B\u306B\u4E00\u4EBA\u3067\u884C\u3063\u3066\u9152\u3092\u98F2\u307E\u305A\u6599\u7406\u3060\u3051\u98DF\u3046\u306E\u306F\u5272\u9AD8\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.youtube.com\/watch?v=_8oxXbWE8AI\" rel=\"nofollow\"\u003E\u30B7\u30CA\u30D7\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341914781516718080",
    "text" : "\u5C45\u9152\u5C4B\u306B\u4E00\u4EBA\u3067\u884C\u3063\u3066\u9152\u3092\u98F2\u307E\u305A\u6599\u7406\u3060\u3051\u98DF\u3046\u306E\u306F\u5272\u9AD8\u304B",
    "id" : 341914781516718080,
    "created_at" : "2013-06-04 13:50:11 +0000",
    "user" : {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "protected" : false,
      "id_str" : "103616372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493023204051410944\/6b1nPcOU_normal.jpeg",
      "id" : 103616372,
      "verified" : false
    }
  },
  "id" : 341914880183504896,
  "created_at" : "2013-06-04 13:50:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341914617045467136",
  "text" : "\u4E00\u4EBA\u5C45\u9152\u5C4B\u306F(\u307B\u3068\u3093\u3069)\u304A\u9152\u98F2\u3081\u306A\u3044\u90FD\u5408\u4E0A\u3042\u307E\u308A\u597D\u307E\u3057\u304F\u306A\u3044\u306A\u30FC",
  "id" : 341914617045467136,
  "created_at" : "2013-06-04 13:49:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341914158339616768",
  "geo" : { },
  "id_str" : "341914471305990144",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u56DE\u308B\u3084\u3064\u306A\u3089\u305F\u3076\u3093\u4F59\u88D5[\u56DE\u3089\u306A\u3044\u306E\u306F\u91D1\u92AD\u7684\u306B\u2026]",
  "id" : 341914471305990144,
  "in_reply_to_status_id" : 341914158339616768,
  "created_at" : "2013-06-04 13:48:57 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341913956744560644",
  "geo" : { },
  "id_str" : "341914321099563008",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3046\u30FC\u3093\u3001\u6700\u8FD1\u306F\u30EC\u30F3\u30BF\u30EB\u306B\u51FA\u308B\u306E\u3082\u65E9\u304B\u3063\u305F\u308A\u3059\u308B\u306E\u3067\u3064\u3044\u2026",
  "id" : 341914321099563008,
  "in_reply_to_status_id" : 341913956744560644,
  "created_at" : "2013-06-04 13:48:21 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341913761243860993",
  "text" : "\u4E00\u4EBA\u713C\u8089\u3068\u4E00\u4EBA\u6620\u753B\u3001\u3042\u3068\u306A\u306B\u304B\u9762\u767D\u3044(\u3084\u3063\u3066\u306A\u3044)\u4E00\u4EBAhogehoge\u306F\u3042\u308B\u304B\u306A\u3041",
  "id" : 341913761243860993,
  "created_at" : "2013-06-04 13:46:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341913402639278080",
  "text" : "\u30B5\u30DD\u30FC\u30C8\u306E\u9023\u7D61\u958B\u59CB\u304C9:30\u3067\u30012\u9650\u304C\u3042\u308B\u304B\u308910:15\u306B\u306F\u5BB6\u3092\u51FA\u306A\u304F\u3061\u3083\u3044\u3051\u306A\u304F\u3066\u3001\u3046\u30FC\u3093\u2026",
  "id" : 341913402639278080,
  "created_at" : "2013-06-04 13:44:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341912704283463680",
  "text" : "\u6620\u753B\u306B\u3064\u3044\u3066\u306F\u4E00\u90E8\u306E\u3072\u3063\u3069\u3044\u4F5C\u54C1\u3092\u9664\u3044\u3066\u306A\u306B\u898B\u3066\u3082\u305D\u3053\u305D\u3053\u9762\u767D\u3044\u3068\u601D\u3063\u3061\u3083\u3046\u982D\u3057\u3066\u308B\u304B\u3089\u3042\u308B\u610F\u5473\u5F97\u306A\u306E\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 341912704283463680,
  "created_at" : "2013-06-04 13:41:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341912380051185664",
  "text" : "\u604B\u4EBA\u306B\u3064\u3044\u3066\u306F\u30CE\u30FC\u30B3\u30E1\u30F3\u30C8\u3067(",
  "id" : 341912380051185664,
  "created_at" : "2013-06-04 13:40:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 3, 15 ],
      "id_str" : "146090085",
      "id" : 146090085
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 17, 27 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341912313277845504",
  "text" : "RT @modestrella: @end313124 \u72EC\u308A\u3002\u304B\u604B\u4EBA\u3068\u3002\u3053\u3046\u8003\u3048\u308B\u3068\u3069\u306E\u5F62\u614B\u3082\u697D\u3057\u3044\u306A\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "341911529794457600",
    "geo" : { },
    "id_str" : "341912129479258112",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u72EC\u308A\u3002\u304B\u604B\u4EBA\u3068\u3002\u3053\u3046\u8003\u3048\u308B\u3068\u3069\u306E\u5F62\u614B\u3082\u697D\u3057\u3044\u306A\u3002",
    "id" : 341912129479258112,
    "in_reply_to_status_id" : 341911529794457600,
    "created_at" : "2013-06-04 13:39:38 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "protected" : false,
      "id_str" : "146090085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413056775756083200\/AuY1KCKa_normal.jpeg",
      "id" : 146090085,
      "verified" : false
    }
  },
  "id" : 341912313277845504,
  "created_at" : "2013-06-04 13:40:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341912302230073344",
  "text" : "\u4E00\u4EBA\u6620\u753B\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u304B\u3089\u3084\u3063\u3066\u898B\u305F\u3044\u3051\u3069\u3001\u5272\u9AD8\u611F\u3042\u308B\u3093\u3060\u3088\u306A\u30FC\u2026",
  "id" : 341912302230073344,
  "created_at" : "2013-06-04 13:40:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341911873467334658",
  "text" : "\u4ECA\u65E5\u96FB\u8A71\u3057\u3068\u304D\u3083\u3042\u826F\u304B\u3063\u305F\u3082\u306E\u30FC",
  "id" : 341911873467334658,
  "created_at" : "2013-06-04 13:38:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341911779573653504",
  "text" : "\u3053\u308A\u3083\u3042\u305F\u3076\u3093\u9811\u5F35\u3063\u3066\u3082\u3042\u308C\u3060\u3057\u3001\u660E\u65E5\u30B5\u30DD\u30FC\u30C8\u306B\u9023\u7D61\u3057\u3088\u3046\u2026",
  "id" : 341911779573653504,
  "created_at" : "2013-06-04 13:38:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341911394020646912",
  "geo" : { },
  "id_str" : "341911529794457600",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3075\u3060\u3093\u3072\u3068\u308A\u3067\u3059\uFF1F",
  "id" : 341911529794457600,
  "in_reply_to_status_id" : 341911394020646912,
  "created_at" : "2013-06-04 13:37:15 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341887066826752001",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 341887066826752001,
  "created_at" : "2013-06-04 12:00:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341883395443421184",
  "text" : "\u571F\u66DC\u3042\u305F\u308A\u304B\u3089\u7A81\u7136\u3064\u306A\u304C\u3089\u306A\u304F\u306A\u3063\u305F\u3093\u3060\u3088\u306A\u30FC\u3001\u3058\u3087\u3046\u3088\u308F\u3060\u3057\u3001\u539F\u56E0\u308F\u304B\u3089\u3093",
  "id" : 341883395443421184,
  "created_at" : "2013-06-04 11:45:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341883199808479234",
  "text" : "\u5BB6\u306E\u30CD\u30C3\u30C8\u304C\u7E4B\u304C\u3089\u306A\u3044\u8E0A\u308A",
  "id" : 341883199808479234,
  "created_at" : "2013-06-04 11:44:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341603829151825920",
  "text" : "\u3069\u3046\u3082RS\u3060\u3063\u305F\u3063\u307D\u3044",
  "id" : 341603829151825920,
  "created_at" : "2013-06-03 17:14:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341602883420168192",
  "text" : "\u3044\u3084\u3001\u50D5\u306E\u76EE\u306E\u524D\u3067\u8155\u76F8\u64B2\u3067\u53CB\u4EBA\u304C\u8155\u3092\u6298\u3063\u3066\u4EE5\u6765\u3069\u3046\u3082\u82E6\u624B",
  "id" : 341602883420168192,
  "created_at" : "2013-06-03 17:10:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341602567282909185",
  "text" : "@kotorin_phoenix \u53E3\u7B1B\u306E\u5272\u306B\u7D50\u69CB\u4E0A\u624B\u3067\u9A12\u97F3\u3063\u3066\u611F\u3058\u3058\u3083\u306A\u304B\u3063\u305F\u3067\u3059\u306D\u30FC",
  "id" : 341602567282909185,
  "created_at" : "2013-06-03 17:09:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341602375326392320",
  "text" : "\u50D5\u306E\u76EE\u306E\u524D\u3067\u8155\u76F8\u64B2\u3060\u3051\u306F\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
  "id" : 341602375326392320,
  "created_at" : "2013-06-03 17:08:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341602132803334145",
  "text" : "RS\u304B\u306A\uFF1F",
  "id" : 341602132803334145,
  "created_at" : "2013-06-03 17:07:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341602059096838144",
  "text" : "@kotorin_phoenix \u8A73\u3057\u304F\u306A\u3044\u306E\u3067\u308F\u304B\u308A\u307E\u305B\u3093\u304C\u6226\u95D8\u306EBGM\u3067\u3057\u305Fwww",
  "id" : 341602059096838144,
  "created_at" : "2013-06-03 17:07:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341600498371158016",
  "text" : "\u4F55\u3067\u6DF1\u591C\u306B\u5916\u304B\u3089\u805E\u3053\u3048\u308B\u53E3\u7B1B\u306E\u5B9F\u6CC1\u3057\u3066\u308B\u306E\u304B\u308F\u3051\u308F\u304B\u3089\u3093",
  "id" : 341600498371158016,
  "created_at" : "2013-06-03 17:01:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341600356649820160",
  "text" : "\u30DD\u30B1\u30E2\u30F3\u306EBGM\u304Bwww\u3053\u308Cwww",
  "id" : 341600356649820160,
  "created_at" : "2013-06-03 17:00:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341600003795603456",
  "text" : "\u66F2\u304C\u5909\u308F\u3063\u305F",
  "id" : 341600003795603456,
  "created_at" : "2013-06-03 16:59:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341598174147923969",
  "text" : "\u7B11\u70B9\u306E\u30C6\u30FC\u30DE\u9CF4\u308A\u6B62\u307E\u306A\u304F\u3066\u306C\u30FC\u3093",
  "id" : 341598174147923969,
  "created_at" : "2013-06-03 16:52:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341595752134483968",
  "text" : "\u5916\u3067\u7B11\u70B9\u306EBGM\u53E3\u7B1B\u5439\u3044\u3066\u308B\u3084\u3064\u3044\u3066\u8349\u4E0D\u53EF\u907F",
  "id" : 341595752134483968,
  "created_at" : "2013-06-03 16:42:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341591632812068864",
  "text" : "\u3053\u306E\u524D\u539F\u4ED8\u3067\u8D70\u3063\u3066\u308B\u6642\u306B\u7DD1\u306E\u5149\u304C\u30B5\u30C3\u3068\u8D70\u3063\u305F\u304B\u3089\u300C\u306A\u3093\u3060\u301CUFO\u304B\u301C\u300D\u4F4D\u306B\u601D\u3063\u3066\u3044\u305F\u304C\u30DB\u30BF\u30EB\u3060\u3063\u305F\u3053\u3068\u304C\u5224\u660E\u3057\u305F",
  "id" : 341591632812068864,
  "created_at" : "2013-06-03 16:26:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341590931776090112",
  "text" : "\u3048\u3093\u3069\u300C\u304A\u524D\u3001\u30B5\u30FC\u30AF\u30EB\u3067\u3082\u305D\u3093\u306A\u5909\u614B\u3063\u307D\u3044\u30AD\u30E3\u30E9\u306A\u306E\u304B\u300D\n\u53CB\u4EBA\u300C\u3046\u3093\u3001\u304B\u306A\u308A\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u4E0A\u306B\u4FEE\u6B63\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y\uFFE3",
  "id" : 341590931776090112,
  "created_at" : "2013-06-03 16:23:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341238945687957504",
  "text" : "\u3058\u3057\u3093\uFF1F",
  "id" : 341238945687957504,
  "created_at" : "2013-06-02 17:04:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341210156274688000",
  "text" : "333\u5186\u306E\u8CB7\u3044\u7269\u3092\u3057\u3066555\u5186\u3092\u51FA\u3057\u3066222\u5186\u3092\u53D7\u3051\u53D6\u3063\u305F\u3053\u306E\u6C17\u6301\u3061\u306F\u2026\u4E00\u4F53\u2026",
  "id" : 341210156274688000,
  "created_at" : "2013-06-02 15:10:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341162318354321409",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 341162318354321409,
  "created_at" : "2013-06-02 12:00:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340853397345419264",
  "text" : "\u3068\u3044\u3046\u304B\u30D5\u30E9\u30A4\u30D1\u30F3\u3063\u3066\u5BB6\u5177\u3058\u3083\u306A\u3044\u306A\uFF1F",
  "id" : 340853397345419264,
  "created_at" : "2013-06-01 15:32:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340844254513487874",
  "geo" : { },
  "id_str" : "340844402761138176",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u5B9F\u969B\u52DD\u3063\u305F\u4E8B\u306A\u3057",
  "id" : 340844402761138176,
  "in_reply_to_status_id" : 340844254513487874,
  "created_at" : "2013-06-01 14:56:52 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340844298159394817",
  "text" : "\u826F\u3044\u4EBA\u306A\u306E\u3067\u5618\u3092\u3064\u3051\u306A\u3044\u3093\u3067\u3059\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 340844298159394817,
  "created_at" : "2013-06-01 14:56:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340844144182300674",
  "text" : "\u30D5\u30A1\u30D6\u30D5\u30A3\u30D6\u306F\u3048\u3093\u3069\u3055\u3093\u975E\u5E38\u306B\u5F31\u3044\u306E\u3067\u2026",
  "id" : 340844144182300674,
  "created_at" : "2013-06-01 14:55:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 3, 12 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340844043313487872",
  "text" : "RT @kur_rage: \u4E00\u5E74\u524D\u306B\u3048\u3093\u3069\u3055\u3093\u306B\u306F\u3058\u3081\u3066\u304A\u4F1A\u3044\u3057\u305F\u3068\u304D\u3001\u6570\u5B57\u3057\u304B\u558B\u3089\u305A\u306B\u30D5\u30A1\u30D6\u30D5\u30A3\u30D6\u3084\u3063\u305F\u8A18\u61B6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.youtube.com\/watch?v=_8oxXbWE8AI\" rel=\"nofollow\"\u003E\u30B7\u30CA\u30D7\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340843947930812416",
    "text" : "\u4E00\u5E74\u524D\u306B\u3048\u3093\u3069\u3055\u3093\u306B\u306F\u3058\u3081\u3066\u304A\u4F1A\u3044\u3057\u305F\u3068\u304D\u3001\u6570\u5B57\u3057\u304B\u558B\u3089\u305A\u306B\u30D5\u30A1\u30D6\u30D5\u30A3\u30D6\u3084\u3063\u305F\u8A18\u61B6",
    "id" : 340843947930812416,
    "created_at" : "2013-06-01 14:55:04 +0000",
    "user" : {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "protected" : true,
      "id_str" : "1223342047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000156529724\/4b88df87fc3bf81618a6639b5c6e97fe_normal.jpeg",
      "id" : 1223342047,
      "verified" : false
    }
  },
  "id" : 340844043313487872,
  "created_at" : "2013-06-01 14:55:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340843313030651905",
  "text" : "\u30C6\u30F3\u30D7\u30EC\u306A\u3057\u3067\u3082\u558B\u308C\u308B\u3082\u3093(\u9707\u3048\u58F0)",
  "id" : 340843313030651905,
  "created_at" : "2013-06-01 14:52:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340843175725895680",
  "text" : "\u304F\u3089\u3052\u3055\u3093\u558B\u3089\u306A\u3044\u5370\u8C61\u5225\u306B\u306A\u3044[\u304C\u50D5\u304C\u4E00\u4EBA\u3067\u558B\u308A\u3059\u304E\u3066\u3044\u308B\u3060\u3051\u3067\u3042\u308B\u53EF\u80FD\u6027]",
  "id" : 340843175725895680,
  "created_at" : "2013-06-01 14:52:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340842591950094336",
  "text" : "\u56FA\u6709\u8A00\u8A9E\u306E\u53EF\u80FD\u6027",
  "id" : 340842591950094336,
  "created_at" : "2013-06-01 14:49:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340842438400819201",
  "geo" : { },
  "id_str" : "340842573222535169",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u30A2\u30C3\u30CF\u30A4",
  "id" : 340842573222535169,
  "in_reply_to_status_id" : 340842438400819201,
  "created_at" : "2013-06-01 14:49:36 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 3, 16 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340842516070936578",
  "text" : "RT @_primenumber: \u3048\u3093\u3069\u3055\u3093\u306F\u8B0E\u306E\u8A00\u8A9E\u3092\u3057\u3083\u3079\u3063\u3066\u3044\u308B\u5370\u8C61\u304C\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340842410332520448",
    "text" : "\u3048\u3093\u3069\u3055\u3093\u306F\u8B0E\u306E\u8A00\u8A9E\u3092\u3057\u3083\u3079\u3063\u3066\u3044\u308B\u5370\u8C61\u304C\u3042\u308B",
    "id" : 340842410332520448,
    "created_at" : "2013-06-01 14:48:57 +0000",
    "user" : {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "protected" : false,
      "id_str" : "86075525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829246455\/df79f6a468f8240ff902e4e4c9c324b5_normal.png",
      "id" : 86075525,
      "verified" : false
    }
  },
  "id" : 340842516070936578,
  "created_at" : "2013-06-01 14:49:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340842435540287488",
  "text" : "\u4E00\u65E5\u558B\u3089\u306A\u3044\u3068\u7FCC\u65E5\u558B\u308A\u3059\u304E\u308B\u8A71\u3057\u305F\u3089\u5168\u5426\u5B9A\u3055\u308C\u305F\u65B9\u306E\u3048\u3093\u3069\u3067\u3059\u3053\u3093\u3070\u3093\u308F",
  "id" : 340842435540287488,
  "created_at" : "2013-06-01 14:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340842066890354688",
  "geo" : { },
  "id_str" : "340842240786194432",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 tokyo\u3067\u3059",
  "id" : 340842240786194432,
  "in_reply_to_status_id" : 340842066890354688,
  "created_at" : "2013-06-01 14:48:17 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340841916272889859",
  "text" : "\u65B9\u8A00\u306F\u3042\u308B\u7A2E\u7FA8\u307E\u3057\u3044\u3068\u3053\u308D\u3042\u308B[\u306A\u3044\u3082\u306E\u30CD\u30C0\u30EA\u30FC]",
  "id" : 340841916272889859,
  "created_at" : "2013-06-01 14:47:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340841166079660034",
  "text" : "\u65B9\u8A00\u306A\u3044\u30DE\u30F3\u3060\u304B\u3089\u308F\u304B\u3089\u3093\u306E\u3060\u304C\u666E\u901A\u5B8C\u5168\u62B9\u6D88\u3063\u3066\u96E3\u3057\u3044\u306E\uFF1F",
  "id" : 340841166079660034,
  "created_at" : "2013-06-01 14:44:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 3, 12 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340841048215531520",
  "text" : "RT @kur_rage: \u65B9\u8A00\u5B8C\u5168\u306B\u62B9\u6D88\u3057\u3066\u8A71\u305B\u308B\u7CFB\u5973\u5B50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.youtube.com\/watch?v=_8oxXbWE8AI\" rel=\"nofollow\"\u003E\u30B7\u30CA\u30D7\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340840772112875521",
    "text" : "\u65B9\u8A00\u5B8C\u5168\u306B\u62B9\u6D88\u3057\u3066\u8A71\u305B\u308B\u7CFB\u5973\u5B50",
    "id" : 340840772112875521,
    "created_at" : "2013-06-01 14:42:27 +0000",
    "user" : {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "protected" : true,
      "id_str" : "1223342047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000156529724\/4b88df87fc3bf81618a6639b5c6e97fe_normal.jpeg",
      "id" : 1223342047,
      "verified" : false
    }
  },
  "id" : 340841048215531520,
  "created_at" : "2013-06-01 14:43:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340839951853817856",
  "text" : "\u90AA\u5FF5\u304C\u2026\u3068\u304B\u8A00\u3063\u3066\u308B\u5F8C\u8F29\u304C\u5C45\u305F\u304B\u3089\u300C\u90AA\u5FF5\u3058\u3083\u306D\u3093\u3058\u3083\u300D\u3068\u8A00\u3063\u3066\u7A7A\u6C17\u3092\u51CD\u3089\u305B\u308B=\u30B8\u30C4",
  "id" : 340839951853817856,
  "created_at" : "2013-06-01 14:39:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340838666450636801",
  "geo" : { },
  "id_str" : "340839120978980865",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u52AA\u529B\u3059\u308B\u3057\u304B\u306A\u3044\u306E\u306B\u306D\u3047\u2026[\u81EA\u6212]",
  "id" : 340839120978980865,
  "in_reply_to_status_id" : 340838666450636801,
  "created_at" : "2013-06-01 14:35:53 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340838975449206785",
  "text" : "\u3068\u306F\u3044\u3048\u304A\u4E16\u8F9E\u306B\u3082\u6357\u3089\u306A\u3044",
  "id" : 340838975449206785,
  "created_at" : "2013-06-01 14:35:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340838873418575873",
  "text" : "\u4F11\u65E5\u306E\u697D\u3057\u307F\u65B9\n\u8D77\u304D\u307E\u3059 ( \u25E0\u203F\u25E0 ) \n\u9069\u5F53\u306B\u98DF\u3079\u307E\u3059 ( \u25E0\u203F\u25E0 ) \n\u672C\u3092\u8AAD\u307F\u307E\u3059 ( \u25E0\u203F\u25E0 ) \n\u6642\u3005\u4F11\u61A9\u3057\u307E\u3059 (\u00B4\uFF65\u203F\uFF65\uFF40)\n\u4E4F\u3057\u3044\uFF01\uFF01 \u270C('\u03C9'\u270C )\u4E09\u270C('\u03C9')\u270C\u4E09( \u270C'\u03C9')\u270C",
  "id" : 340838873418575873,
  "created_at" : "2013-06-01 14:34:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340837817871638530",
  "text" : "\u305F\u3076\u3093\u52AA\u529B\u305B\u305A\u306B\u7D50\u679C\u6B8B\u3057\u305F\u3044\u304F\u3089\u3044\u306E\u30EF\u30AC\u30DE\u30DE",
  "id" : 340837817871638530,
  "created_at" : "2013-06-01 14:30:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340837713345409024",
  "text" : "\u5C31\u6D3B\u305B\u305A\u306B\u5C31\u8077\u3057\u305F\u3044",
  "id" : 340837713345409024,
  "created_at" : "2013-06-01 14:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340837229096218626",
  "text" : "\u30E1\u30AC\u30CD\u5916\u3057\u3066\u9AEA\u4E0B\u308D\u3059\u3068\u4F55\u3082\u898B\u3048\u306A\u304F\u306A\u308B\u7A0B\u5EA6\u306B\u524D\u9AEA\u304C\u90AA\u9B54",
  "id" : 340837229096218626,
  "created_at" : "2013-06-01 14:28:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340832922158387200",
  "text" : "\u9069\u5F53\u3055\u306F\u6587\u5B57\u306B\u3059\u308B\u3068\u306A\u2026[\u53E3\u982D\u306A\u3089\u62BC\u3057\u5207\u308C\u308B]",
  "id" : 340832922158387200,
  "created_at" : "2013-06-01 14:11:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340832077350060032",
  "text" : "( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 340832077350060032,
  "created_at" : "2013-06-01 14:07:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340831389131878400",
  "geo" : { },
  "id_str" : "340831592945684481",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5143\u3005\u306E\u7F75\u5012\u3082\u9069\u5F53\u3060\u304C\u30D5\u30A9\u30ED\u30FC\u3082\u9069\u5F53\u3060\u306A\uFF1F",
  "id" : 340831592945684481,
  "in_reply_to_status_id" : 340831389131878400,
  "created_at" : "2013-06-01 14:05:58 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340831369540296704",
  "text" : "\u8F9B\u8FA3\u30A5\uFF01\u8F9B\u8FA3\u30A5\uFF01\uFF01",
  "id" : 340831369540296704,
  "created_at" : "2013-06-01 14:05:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340831029101207552",
  "geo" : { },
  "id_str" : "340831301705797632",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30A2\u30C3\u30CF\u30A4",
  "id" : 340831301705797632,
  "in_reply_to_status_id" : 340831029101207552,
  "created_at" : "2013-06-01 14:04:49 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340830673076113409",
  "text" : "\u4EE3\u30C8\u30DD\u306E\u5149\u3001\u5B8C\u5168\u306B\u72EC\u308A\u6B69\u304D\u3057\u3066\u308B",
  "id" : 340830673076113409,
  "created_at" : "2013-06-01 14:02:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340829781371281409",
  "geo" : { },
  "id_str" : "340830112054394880",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank ( \u00B4_\u309D\uFF40)\u30CB\u30E3\u30FC\u30F3",
  "id" : 340830112054394880,
  "in_reply_to_status_id" : 340829781371281409,
  "created_at" : "2013-06-01 14:00:05 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340829856805814273",
  "text" : "\u570F\/\u8AD6\u306FCT\u3068\u66F8\u304F\u6587\u5316\u3042\u3093\u307E\u308A\u306A\u3044\u3051\u3069\u697D\u3060\u304B\u3089\u4F7F\u304A\u3046\u304B\u3057\u3089",
  "id" : 340829856805814273,
  "created_at" : "2013-06-01 13:59:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340829454911807488",
  "text" : "\u5FC3\u3092\u75C5\u3093\u3060\u732B\u305F\u3061\u306E\u5FC3\u3092\u7652\u3059\u30D2\u30E5\u30FC\u30DE\u30F3\u30BB\u30E9\u30D4\u30FC\u306E\u30D2\u30E5\u30FC\u30DE\u30F3\u5F79\u3084\u308A\u305F\u3044",
  "id" : 340829454911807488,
  "created_at" : "2013-06-01 13:57:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340800057626488833",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 340800057626488833,
  "created_at" : "2013-06-01 12:00:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340789266802155520",
  "text" : "yatex\u6D3E\u3068auctex\u6D3E\u306E\u6297\u4E89\u306F\u4F59\u308A\u805E\u304B\u306A\u3044",
  "id" : 340789266802155520,
  "created_at" : "2013-06-01 11:17:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340627249520865281",
  "geo" : { },
  "id_str" : "340765704796110848",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u3042\u308A\u304C\u3068\uFF01\uFF01",
  "id" : 340765704796110848,
  "in_reply_to_status_id" : 340627249520865281,
  "created_at" : "2013-06-01 09:44:09 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340764141490941952",
  "text" : "\u7A7A\u8179of the end",
  "id" : 340764141490941952,
  "created_at" : "2013-06-01 09:37:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nicovideo.jp\/\" rel=\"nofollow\"\u003Eniconico \u30CB\u30B3\u30EC\u30DD\u9023\u643A\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sm20989025",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/wVOc7lJDQb",
      "expanded_url" : "http:\/\/nico.ms\/sm20989025",
      "display_url" : "nico.ms\/sm20989025"
    } ]
  },
  "geo" : { },
  "id_str" : "340521085441294336",
  "text" : "[My List] \u3010\u6771\u65B9MMD\u3011\u30D1\u30C1\u30E5\u30EA\u30FC\u75C5\u306B\u4F0F\u3059 http:\/\/t.co\/wVOc7lJDQb #sm20989025",
  "id" : 340521085441294336,
  "created_at" : "2013-05-31 17:32:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340510981199372289",
  "geo" : { },
  "id_str" : "340511279418572800",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u3060\u3044\u305F\u3044twitter\u306E\u77E5\u308A\u5408\u3044\u3063\u3066\u9762\u8B58\u306A\u3044\u65B9\u304C\u591A\u3044\u3093\u3060\u305C\uFF1F",
  "id" : 340511279418572800,
  "in_reply_to_status_id" : 340510981199372289,
  "created_at" : "2013-05-31 16:53:10 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340510846516084737",
  "geo" : { },
  "id_str" : "340511098606333952",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u307E\u3041\u305D\u3046\u306A\u3093\u3067\u3059\u3051\u3069\u306D(\u4E00\u5EA6\u307F\u304B\u307F\u30683\u4EBA\u3067\u3054\u98EF\u3067\u3082\u884C\u304D\u305F\u3044\u3082\u306E\u3067\u3059\u304C)",
  "id" : 340511098606333952,
  "in_reply_to_status_id" : 340510846516084737,
  "created_at" : "2013-05-31 16:52:26 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340509988978049025",
  "text" : "\u5C11\u306A\u304F\u3068\u3082\u77E5\u308A\u5408\u3044\u306E\u77E5\u308A\u5408\u3044\u30EC\u30D9\u30EB\u3067\u76F8\u5F53\u30AB\u30D0\u30FC\u3067\u304D\u3066\u3044\u308B",
  "id" : 340509988978049025,
  "created_at" : "2013-05-31 16:48:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340509807985430528",
  "text" : "\u5927\u5B66\u5185\u306B\u7167\u6E96\u7D5E\u308C\u3070\u30D5\u30A9\u30ED\u30EF\u30FC\u3068\u30EA\u30A2\u30EB(\u306E\u307F\u3082\u53EF)\u306E\u77E5\u308A\u5408\u3044\u5408\u308F\u305B\u305F\u30893step\u304F\u3089\u3044\u3042\u308C\u3070\u4EFB\u610F\u306E\u4EBA\u9593\u306B\u884C\u304D\u5F53\u305F\u308A\u305D\u3046",
  "id" : 340509807985430528,
  "created_at" : "2013-05-31 16:47:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340509370834104320",
  "geo" : { },
  "id_str" : "340509531027148800",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u3042\u30FC\u3042\u30FC\u306A\u308B\u307B\u3069\u3002\u307E\u3059\u307E\u3059\u72ED\u3044\u4E16\u9593\u3067\u3059\u306D\u3047\u3002",
  "id" : 340509531027148800,
  "in_reply_to_status_id" : 340509370834104320,
  "created_at" : "2013-05-31 16:46:13 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340509077123788800",
  "text" : "\u898B\u305F\u76EE\u3088\u308A\u5F37\u3044\u3064\u306A\u304C\u308Akamo",
  "id" : 340509077123788800,
  "created_at" : "2013-05-31 16:44:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340508638756106241",
  "geo" : { },
  "id_str" : "340508980784816129",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u30B5\u30FC\u30AF\u30EB\u306E\u5143\u90E8\u9577:end\u3001\u30B5\u30FC\u30AF\u30EB\u306E\u73FE\u90E8\u9577:\u307F\u304B\u307F \u306E\u69CB\u56F3\u3067\u3059",
  "id" : 340508980784816129,
  "in_reply_to_status_id" : 340508638756106241,
  "created_at" : "2013-05-31 16:44:02 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340501230352744451",
  "text" : "stsmath\u304C\u3044\u306A\u304F\u306A\u3063\u305F\u3089\u307E\u3055\u306B\u300C\u795E\u306F\u6B7B\u3093\u3060\u300D\u72B6\u614B\u306B\u306A\u308B",
  "id" : 340501230352744451,
  "created_at" : "2013-05-31 16:13:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340501072437202944",
  "text" : "\u3064\u3044\u6D88\u3057\u306B\u306F\u89E6\u308C\u306A\u3044\u3079\u304D\u3068\u3044\u3046\u81EA\u5206\u30EB\u30FC\u30EB[\u81EA\u5206\u3082\u89E6\u308C\u306A\u3044\u3067\u6B32\u3057\u3044\u306A\uFF1F]",
  "id" : 340501072437202944,
  "created_at" : "2013-05-31 16:12:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340499980135571457",
  "geo" : { },
  "id_str" : "340500080845012992",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u308F\u304B\u308B",
  "id" : 340500080845012992,
  "in_reply_to_status_id" : 340499980135571457,
  "created_at" : "2013-05-31 16:08:40 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340499623259025408",
  "text" : "\u4E16\u9593\u304C\u72ED\u3059\u304E\u3066\u308F\u3051\u308F\u304B\u3089\u3093",
  "id" : 340499623259025408,
  "created_at" : "2013-05-31 16:06:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    }, {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 13, 27 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340499375564390400",
  "geo" : { },
  "id_str" : "340499519450017792",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 @coscos2coscos \u3042\u308C\u3001\u305D\u3053\u7E4B\u304C\u3063\u3066\u308B\u3093\u3067\u3059\u304B[\u610F\u5916]",
  "id" : 340499519450017792,
  "in_reply_to_status_id" : 340499375564390400,
  "created_at" : "2013-05-31 16:06:26 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340498966271627264",
  "geo" : { },
  "id_str" : "340499255141728257",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u30A2\u30FC\u30CF\u30A4\u30CF\u30A4\u30BD\u30FC\u30C0\u30CD\u30FC",
  "id" : 340499255141728257,
  "in_reply_to_status_id" : 340498966271627264,
  "created_at" : "2013-05-31 16:05:23 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340496504894681089",
  "text" : "\u5148\u6708\u306E\u30C6\u30FC\u30DE\u304C\u300C\u914D\u616E\u300D\u3060\u3063\u305F\u304B\u3089\u4ECA\u6708\u306E\u30C6\u30FC\u30DE\u306F\u300C\u723D\u3084\u304B\u3055\u300D\u306B\u3057\u3088\u3046\u304B[\u96E3\u3057\u3044]",
  "id" : 340496504894681089,
  "created_at" : "2013-05-31 15:54:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 0, 7 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340496187289374720",
  "geo" : { },
  "id_str" : "340496302922149888",
  "in_reply_to_user_id" : 50640629,
  "text" : "@igaris \u305D\u3046\u3044\u3046\u4EBA\u306F\u4E0D\u601D\u8B70\u3068\u5ACC\u308F\u308C\u306A\u3044\u306E\u3067\u3059\u3088\u3075\u3075\u3075",
  "id" : 340496302922149888,
  "in_reply_to_status_id" : 340496187289374720,
  "created_at" : "2013-05-31 15:53:39 +0000",
  "in_reply_to_screen_name" : "igaris",
  "in_reply_to_user_id_str" : "50640629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340495947043860482",
  "geo" : { },
  "id_str" : "340496194260307969",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u306B\u3083\u3093\u306D\u30FC",
  "id" : 340496194260307969,
  "in_reply_to_status_id" : 340495947043860482,
  "created_at" : "2013-05-31 15:53:13 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340495898830327808",
  "text" : "\u6B63\u78BA\u3058\u3083\u306A\u3044\u5909\u63DB[\u6027\u683C\u306A]",
  "id" : 340495898830327808,
  "created_at" : "2013-05-31 15:52:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340495776524406784",
  "text" : "\u305D\u308A\u3083\u3042\u540C\u3058\u6B63\u78BA\u306A\u3089\u898B\u305F\u76EE\u826F\u3044\u65B9\u304C\u5370\u8C61\u3044\u3044\u3067\u3057\u3087\u3046\u3088\u3001\u8F9B\u3044\u4E16\u306E\u4E2D\u3067\u3042\u308B",
  "id" : 340495776524406784,
  "created_at" : "2013-05-31 15:51:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340495379479011328",
  "geo" : { },
  "id_str" : "340495615488307200",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5370\u8C61\u306B\u306F\u4F9D\u308B\u304B\u3089\u306A\u2026[\u305F\u3060\u307E\u3041\u305D\u3046\u3044\u3046\u3053\u3068\u5E73\u6C17\u3067\u53E3\u306B\u51FA\u3059\u4EBA\u306F\u3059\u3067\u306B\u30A2\u30EC]",
  "id" : 340495615488307200,
  "in_reply_to_status_id" : 340495379479011328,
  "created_at" : "2013-05-31 15:50:55 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340495367923720192",
  "text" : "\uFF1F",
  "id" : 340495367923720192,
  "created_at" : "2013-05-31 15:49:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340495355626020864",
  "text" : "\u305D\u3046\u3044\u3046\u4EBA\u306B\u79C1\u306F\u306A\u308A\u305F\u3044",
  "id" : 340495355626020864,
  "created_at" : "2013-05-31 15:49:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340495198759034881",
  "text" : "\u53E3\u304C\u60AA\u304F\u3066\u3082\u8A00\u3063\u3066\u308B\u3053\u3068\u306F\u30A8\u30B0\u304F\u3066\u3082\u4E0D\u601D\u8B70\u3068\u723D\u3084\u304B\u306A\u4EBA\u306F\u3044\u308B\u304B\u3089\u306A\u30FC",
  "id" : 340495198759034881,
  "created_at" : "2013-05-31 15:49:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340495009298132993",
  "text" : "\u8A08\u7B97\u9AD8\u3044\u4EBA\u306F\u597D\u304D\u3067\u3059\u304C\u6027\u683C\u60AA\u3044\u4EBA\u306F\u591A\u5206\u5ACC\u60AA\u611F\u3092\u899A\u3048\u3055\u305B\u308B\u4EBA\u306A\u3093\u3060\u3068\u601D\u3046",
  "id" : 340495009298132993,
  "created_at" : "2013-05-31 15:48:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]