Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitaddict.net\/\" rel=\"nofollow\"\u003E\u4F9D\u5B58\u5EA6\u30C1\u30A7\u30C3\u30AF\u300Ctwitaddict\u300D\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hideaki sakai",
      "screen_name" : "hideaki_sakai",
      "indices" : [ 47, 61 ],
      "id_str" : "3024790712",
      "id" : 3024790712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitadd",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53463269255557120",
  "text" : "\u624B\u304C\u3079\u305F\u3079\u305F\u3059\u308B\u3088\u306D\u3002\u3046\u3093\u3002 \u79C1\u306F\u300C\u30AB\u30FC\u30EB Lv.21\u76F8\u5F53\u300D\u304F\u3089\u3044twitter\u306B\u4F9D\u5B58\u3057\u3066\u308B(@Hideaki_Sakai \u3068\u540C\u3058\u304F\u3089\u3044) http:\/\/twitaddict.net #twitadd",
  "id" : 53463269255557120,
  "created_at" : "2011-03-31 14:26:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53461285634965504",
  "text" : "RT @magokoro84: \u3053\u3044\u3064\u3089\u306B\u898B\u899A\u3048\u3042\u308B\u3084\u3064\u306F\u516C\u5F0FRT\nhttp:\/\/j.mp\/gJMWRD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53458497865650178",
    "text" : "\u3053\u3044\u3064\u3089\u306B\u898B\u899A\u3048\u3042\u308B\u3084\u3064\u306F\u516C\u5F0FRT\nhttp:\/\/j.mp\/gJMWRD",
    "id" : 53458497865650178,
    "created_at" : "2011-03-31 14:07:53 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 53461285634965504,
  "created_at" : "2011-03-31 14:18:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53445885706780672",
  "text" : "RT @galletti_bot: \u7ACB\u4F53\u5316\u3059\u308B\u306B\u306F\u97F3\u304C\u5FC5\u8981\u3060\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53445748209094656",
    "text" : "\u7ACB\u4F53\u5316\u3059\u308B\u306B\u306F\u97F3\u304C\u5FC5\u8981\u3060\u3002",
    "id" : 53445748209094656,
    "created_at" : "2011-03-31 13:17:14 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 53445885706780672,
  "created_at" : "2011-03-31 13:17:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nnm",
      "screen_name" : "noname_2nd",
      "indices" : [ 3, 14 ],
      "id_str" : "2182465429",
      "id" : 2182465429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53445809773084672",
  "text" : "RT @noname_2nd: \u3088\u304F\u4F5C\u3063\u305F\u306A\u3053\u308C\uFF57\uFF57\uFF57 \/ \u679D\u91CE\u5B98\u623F\u9577\u5B98\u306B\u7089\u5FC3\u878D\u89E3\u6B4C\u308F\u305B\u3066\u307F\u305F \u2010 \u30CB\u30B3\u30CB\u30B3\u52D5\u753B(\u539F\u5BBF) http:\/\/htn.to\/GZXZDM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hatena.ne.jp\/guide\/twitter\" rel=\"nofollow\"\u003EHatena\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53444407139123200",
    "text" : "\u3088\u304F\u4F5C\u3063\u305F\u306A\u3053\u308C\uFF57\uFF57\uFF57 \/ \u679D\u91CE\u5B98\u623F\u9577\u5B98\u306B\u7089\u5FC3\u878D\u89E3\u6B4C\u308F\u305B\u3066\u307F\u305F \u2010 \u30CB\u30B3\u30CB\u30B3\u52D5\u753B(\u539F\u5BBF) http:\/\/htn.to\/GZXZDM",
    "id" : 53444407139123200,
    "created_at" : "2011-03-31 13:11:54 +0000",
    "user" : {
      "name" : "\u306E\u306A\u30812nd",
      "screen_name" : "nnm_2nd",
      "protected" : false,
      "id_str" : "89732902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1953514860\/noname_dc40_normal.jpg",
      "id" : 89732902,
      "verified" : false
    }
  },
  "id" : 53445809773084672,
  "created_at" : "2011-03-31 13:17:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53444072341372928",
  "text" : "\u771F\u507D\u3092\u5BE9\u8B70",
  "id" : 53444072341372928,
  "created_at" : "2011-03-31 13:10:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53443893055860736",
  "text" : "\u30A8\u30A4\u30D7\u30EA\u30EB\u30D5\u30FC\u30EB\u3058\u3083\u306A\u304F\u3066\u3082\u3001\u6211\u3005\u306F\u5E38\u306B\u5618\u3092\u3064\u3044\u3066\u751F\u304D\u3066\u3044\u308B\u3002",
  "id" : 53443893055860736,
  "created_at" : "2011-03-31 13:09:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u307F\u304A\u30FC",
      "screen_name" : "gamioh",
      "indices" : [ 3, 10 ],
      "id_str" : "118347207",
      "id" : 118347207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53442944799227904",
  "text" : "RT @gamioh: \u77E5\u3063\u3066\u308B\u4EBA\u306F\u516C\u5F0FRT http:\/\/twitpic.com\/4fanic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53440310684024832",
    "text" : "\u77E5\u3063\u3066\u308B\u4EBA\u306F\u516C\u5F0FRT http:\/\/twitpic.com\/4fanic",
    "id" : 53440310684024832,
    "created_at" : "2011-03-31 12:55:37 +0000",
    "user" : {
      "name" : "\u304C\u307F\u304A\u30FC",
      "screen_name" : "gamioh",
      "protected" : false,
      "id_str" : "118347207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604203750706663424\/wA6xw3kx_normal.jpg",
      "id" : 118347207,
      "verified" : false
    }
  },
  "id" : 53442944799227904,
  "created_at" : "2011-03-31 13:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53426404305539072",
  "text" : "\u6587\u5B66\u5C11\u5973\u3001\u6570\u5B66\u30AC\u30FC\u30EB\u3063\u3066\u8A00\u3046\u3068\u3059\u3054\u304F\u3044\u3044\u30A4\u30E1\u30FC\u30B8\u3060\u3051\u308C\u3069\u3001\u6587\u5B66\u90E8\u7537\u5B50\u3001\u6570\u5B66\u30DC\u30FC\u30A4\u306B\u306A\u308B\u3068\u6D6E\u4E16\u96E2\u308C\u3057\u3066\u91CE\u66AE\u3063\u305F\u3044\u5370\u8C61\u304C\u3042\u308B\u306E\u306F\u306A\u305C\u3060\u308D\u3046\u304B\u3002",
  "id" : 53426404305539072,
  "created_at" : "2011-03-31 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53359079485214720",
  "text" : "\u3082\u3046\u4E94\u6642\u2026\u629C\u3051\u6BBB\u307F\u305F\u3044\u306A\u751F\u6D3B",
  "id" : 53359079485214720,
  "created_at" : "2011-03-31 07:32:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53310436191379457",
  "text" : "\u3084\u3063\u3068\u76EE\u304C\u899A\u3081\u305F",
  "id" : 53310436191379457,
  "created_at" : "2011-03-31 04:19:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53158611261730816",
  "text" : "\u30C8\u30B2\u30A2\u30EA\u30C8\u30B2\u30CA\u30B7\u30C8\u30B2\u30CF\u30E0\u30B7",
  "id" : 53158611261730816,
  "created_at" : "2011-03-30 18:16:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53158576105078784",
  "text" : "\u30AB\u30CE\u30A6\u30E2\u30D3\u30C3\u30AF\u30EA\u30DF\u30C8\u30AD\u30CF\u30CB\u30C9\u30D3\u30C3\u30AF\u30EA\u30B5\u30B5\u30AD\u30EA\u30E2\u30C9\u30AD",
  "id" : 53158576105078784,
  "created_at" : "2011-03-30 18:16:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53142218264944640",
  "geo" : { },
  "id_str" : "53143389092331520",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4FFA\u3082\u8155\u6642\u8A08\u306F\u5ACC\u3044\u3088\u3001\u30DD\u30B1\u30C3\u30C8\u306B\u5FCD\u3070\u305B\u3089\u308C\u308B\u3088\u3046\u306A\u6642\u8A08\u306A\u3089\u6301\u3061\u904B\u3093\u3067\u3082\u3044\u3044\u3051\u308C\u3069",
  "id" : 53143389092331520,
  "in_reply_to_status_id" : 53142218264944640,
  "created_at" : "2011-03-30 17:15:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53138036522881024",
  "text" : "\u3055\u3057\u3066\u545F\u3044\u3066\u308B\u81EA\u899A\u3082\u306A\u3044\u3057\u306A\u30FC\u3001\u6700\u8FD1\u306FRT\u306E\u304C\u591A\u3044\u304F\u3089\u3044\u3002",
  "id" : 53138036522881024,
  "created_at" : "2011-03-30 16:54:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53137947511369729",
  "text" : "\u81EA\u5206\u3092\u597D\u304D\u597D\u3093\u3067\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u308B\u77E5\u3089\u306A\u3044\u4EBA\u306F\u4E0D\u601D\u8B70\u3002\u3044\u3084\u3001\u3042\u308A\u304C\u305F\u3044\u3053\u3068\u3060\u3068\u306F\u601D\u3046\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 53137947511369729,
  "created_at" : "2011-03-30 16:54:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53135183490195456",
  "text" : "\u65E9\u53E3\u8A00\u8449\u306B\u3057\u3066\u306F\u51FA\u6765\u304C\u60AA\u3044\u3057\u3001\u305D\u3046\u3067\u3082\u306A\u3044\u306A\u3089\u8AAD\u307F\u306B\u304F\u3044\u3060\u3051\u304B\u30FC\u3002\u307E\u3041\u30C4\u30A4\u30C3\u30BF-\u306F\u30C1\u30E9\u30B7\u306E\u88CF\u3060\u3068\u4FE1\u3058\u308B\u79C1\u306F\u6C17\u306B\u3057\u306A\u3044\u3002",
  "id" : 53135183490195456,
  "created_at" : "2011-03-30 16:43:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53134885413601280",
  "text" : "\u3082\u3084\u3082\u3084\u3059\u308B\u3051\u3069\u307E\u3041\u4EBA\u3005\u306E\u3082\u3084\u3082\u3084\u3057\u305F\u584A\u3063\u3066\u3053\u3068\u3067\u3084\u3084\u3082\u3059\u308C\u3070\u306A\u3058\u3080\u3060\u308D\u3046\u3002",
  "id" : 53134885413601280,
  "created_at" : "2011-03-30 16:41:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53134639086305280",
  "text" : "\u30AF\u30E9\u30B9\u30BF\u3063\u3066\u5358\u8A9E\u306E\u610F\u5473\u3092\u3057\u3063\u304B\u308A\u63B4\u307F\u3042\u3050\u306D\u3066\u30B0\u30B0\u3063\u3066\u307F\u305F\u306E\u306F\u3044\u3044\u3051\u308C\u3069\u7D50\u5C40\u660E\u78BA\u306A\u5B9A\u7FA9\u306F\u306A\u3044\u3063\u3066\u8A00\u308F\u308C\u305F\u3002",
  "id" : 53134639086305280,
  "created_at" : "2011-03-30 16:40:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53133543487979520",
  "text" : "\u305D\u3046\u3058\u3083\u306A\u304F\u3066\u3082\u5FAE\u7A4D\u304B\u7DDA\u5F62\u304B\u4F4D\u76F8\u30FB\u96C6\u5408\u3092\u3082\u3046\u5C11\u3057\u3065\u3064\u3067\u3082\u6D88\u5316\u3057\u3066\u304A\u304F\u3079\u304D\u3060\u3063\u305F\u3041\u3001\u3063\u3066\u53CD\u7701\u3057\u3066\u307F\u308B\u3002",
  "id" : 53133543487979520,
  "created_at" : "2011-03-30 16:36:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53133232853622785",
  "text" : "\u4F11\u307F\u304C\u7D42\u308F\u308A\u306B\u8FD1\u3065\u304F\u5EA6\u306B\u3082\u3063\u3068\u8AAD\u66F8\u3057\u3066\u304A\u3051\u3070\u3088\u304B\u3063\u305F\u3068\u601D\u3046\u3002\u6BCE\u56DE\u3060\u304B\u3089\u6163\u308C\u3063\u3053\u3060\u3051\u308C\u3069\u3002",
  "id" : 53133232853622785,
  "created_at" : "2011-03-30 16:35:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53111513505992704",
  "text" : "@koketomi \u5225\u306B\u30CD\u30C3\u30C8\u4E0A\u3067\u52DF\u96C6\u3057\u305F\u308F\u3051\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u3069\u306D\u30FC\u3002\u307E\u3041\u3044\u3044\u3051\u3069\uFF57\uFF57",
  "id" : 53111513505992704,
  "created_at" : "2011-03-30 15:09:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53111353992425472",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u82B1\u7269\u8A9E\u8AAD\u3093\u3060\u3002\u5FCD\u91CE\u3082\u5FCD\u3061\u3083\u3093\u3082\u64AB\u5B50\u3082\u51FA\u3066\u3053\u306A\u304B\u3063\u305F\u3051\u3069\u3001\u8C9D\u6728\u304C\u30C7\u30EC\u305F\u306E\u306F\u826F\u304B\u3063\u305F\u3002",
  "id" : 53111353992425472,
  "created_at" : "2011-03-30 15:08:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53110676322910208",
  "text" : "\u3068\u3001\u307E\u3041\u66F8\u3044\u305F\u3068\u3053\u308D\u3067\u5F97\u3089\u308C\u308B\u3082\u306E\u3067\u3082\u306A\u3044\u3051\u308C\u3069\u30FC",
  "id" : 53110676322910208,
  "created_at" : "2011-03-30 15:05:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53110620232495104",
  "text" : "\u6570\u5B66\u3092\uFF08\u8DA3\u5473\u3068\u3057\u3066\u3082\uFF09\u7406\u89E3\u3057\u3066\u304F\u308C\u3066\u8A00\u8449\u904A\u3073\u306B\u3064\u304D\u3042\u3063\u3066\u304F\u308C\u3066\u3001\u9EBB\u96C0\u304C\u5206\u304B\u308B\u53CB\u4EBA\u304C\u6B32\u3057\u3044\u3001\u7537\u5973\u554F\u308F\u305A\u3002",
  "id" : 53110620232495104,
  "created_at" : "2011-03-30 15:05:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52943063118659584",
  "text" : "\u6628\u591C\u98F2\u3093\u3060\uFF08\u3068\u601D\u3044\u8FBC\u3093\u3067\u3044\u305F\uFF09\u306F\u305A\u306E\u9320\u5264\u304C\u76EE\u306E\u524D\u306B\u30FB\u30FB\u30FB\u901A\u308A\u3067\u671D\u304B\u3089\u9F3B\u304C\u3072\u3069\u3044\u308F\u3051\u3060\u3002",
  "id" : 52943063118659584,
  "created_at" : "2011-03-30 03:59:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52769439405453312",
  "geo" : { },
  "id_str" : "52942180964237312",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8FD4\u4FE1\u9045\u304F\u3066\u3054\u3081\u3093\u3088\u3002\u4ED6\u306B\u304B\u3076\u3063\u3066\u306A\u3051\u308C\u3070\u53D6\u308B\uFF01",
  "id" : 52942180964237312,
  "in_reply_to_status_id" : 52769439405453312,
  "created_at" : "2011-03-30 03:56:14 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52766298337329152",
  "geo" : { },
  "id_str" : "52767450751709184",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u89E3\u6790\u5B66\u306E\u4E00\u5206\u91CE\u3060\u3063\u305F\u304B\u306A\u3002\u30E9\u30A4\u30D7\u30CB\u30C3\u30C4\u304C\u66F8\u3044\u305F\u672C\u306E\u30BF\u30A4\u30C8\u30EB\u3060\u3063\u305F\u3088\u3046\u306A\u6C17\u3082\u3057\u305F\u3002",
  "id" : 52767450751709184,
  "in_reply_to_status_id" : 52766298337329152,
  "created_at" : "2011-03-29 16:21:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52766036025552896",
  "text" : "end\u306F\u300C\u3080\u300D\u3067\u306F\u3058\u307E\u308A\u300C\u304D\u300D\u3067\u7D42\u308F\u308B\u8A00\u8449\u3092\u6319\u3052\u3066\u304F\u3060\u3055\u3044\u3002 http:\/\/shindanmaker.com\/84106  \u300C\u7121\u9650\u5C0F\u89E3\u6790\uFF08\u3080\u3052\u3093\u3057\u3087\u3046\u304B\u3044\u305B\u304D\uFF09\u300D",
  "id" : 52766036025552896,
  "created_at" : "2011-03-29 16:16:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52718310692888577",
  "text" : "\u30AA\u30FC\u30E9\u30B9\u5B57\u4E00\u8272 \u4ECA\u65E5\u306F\u3064\u3044\u3066\u305F\u30FC\u3000http:\/\/tenhou.net\/0\/?log=2011032921gm-0009-3742-c8e9c918&tw=1",
  "id" : 52718310692888577,
  "created_at" : "2011-03-29 13:06:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52711883576311808",
  "text" : "\u7121\u53CC\u308F\u305A\u30FC\u3000http:\/\/tenhou.net\/0\/?log=2011032921gm-0009-3742-bd0eca92&tw=0",
  "id" : 52711883576311808,
  "created_at" : "2011-03-29 12:41:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52533503958581248",
  "text" : "\u306B\u3057\u3066\u3082\u5E03\u56E3\u3068\u6795\u304C\u5FC3\u5730\u597D\u304F\u3066\u51FA\u3089\u308C\u306A\u3044",
  "id" : 52533503958581248,
  "created_at" : "2011-03-29 00:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52531780544233472",
  "text" : "\u671D\u304B\u3089\u4F55\u3084\u3063\u3066\u3093\u3060\u304B\u3002",
  "id" : 52531780544233472,
  "created_at" : "2011-03-29 00:45:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52531711585689600",
  "text" : "\u5927\u7AF9\u6797\u548C\u4E86",
  "id" : 52531711585689600,
  "created_at" : "2011-03-29 00:45:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52381034968387585",
  "text" : "\u5DE6\u773C\u3060\u3051\u75D2\u3044",
  "id" : 52381034968387585,
  "created_at" : "2011-03-28 14:46:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52380811051286528",
  "text" : "\u307F\u3093\u306A\u30EA\u30A2\u5145\u3001\u975E\u30EA\u30A2\u5145\u3063\u3066\u3044\u3046\u3051\u3069\u3055\u3001\u5B9A\u7FA9\u304B\u3089\u3059\u308B\u3068\u53CB\u9054\u304C\u4E00\u4EBA\u3044\u308C\u3070\u305D\u308C\u306F\u3082\u3046\u30EA\u30A2\u5145\u306A\u3093\u3060\u3088\u3002\u8A00\u308F\u305B\u3093\u306A\u6065\u305A\u304B\u3057\u3044\u3002",
  "id" : 52380811051286528,
  "created_at" : "2011-03-28 14:45:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52286743499636736",
  "text" : "RT @Kaibun_bot: \u99AC\u9E7F\u3055\uFF01 \u59BB\u5B50\u306E\u3042\u308B\u8EAB\u3067\u3064\u3044\u884C\u3063\u3066\u307F\u308B \u3042\u306E\u5B50\u5F85\u3064\u9152\u5834 \uFF08\u3070\u304B\u3055\u3064\u307E\u3053\u306E\u3042\u308B\u307F\u3066\u3064\u3044\u3044\u3064\u3066\u307F\u308B\u3042\u306E\u3053\u307E\u3064\u3055\u304B\u3070\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 57, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52282797297106944",
    "text" : "\u99AC\u9E7F\u3055\uFF01 \u59BB\u5B50\u306E\u3042\u308B\u8EAB\u3067\u3064\u3044\u884C\u3063\u3066\u307F\u308B \u3042\u306E\u5B50\u5F85\u3064\u9152\u5834 \uFF08\u3070\u304B\u3055\u3064\u307E\u3053\u306E\u3042\u308B\u307F\u3066\u3064\u3044\u3044\u3064\u3066\u307F\u308B\u3042\u306E\u3053\u307E\u3064\u3055\u304B\u3070\uFF09 #kaibun",
    "id" : 52282797297106944,
    "created_at" : "2011-03-28 08:16:04 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 52286743499636736,
  "created_at" : "2011-03-28 08:31:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52238725006106625",
  "text" : "RT @tameninaru: \u5869\u3068\u7802\u7CD6\u3092\u540C\u3058\u91CF\u3060\u3051\u6DF7\u305C\u308B\u3068\u3057\u3087\u3063\u3071\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52233464686190592",
    "text" : "\u5869\u3068\u7802\u7CD6\u3092\u540C\u3058\u91CF\u3060\u3051\u6DF7\u305C\u308B\u3068\u3057\u3087\u3063\u3071\u3044",
    "id" : 52233464686190592,
    "created_at" : "2011-03-28 05:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 52238725006106625,
  "created_at" : "2011-03-28 05:20:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52231029204844544",
  "text" : "RT @galletti_bot: \u30D6\u30EB\u30FC\u30BF\u30B9\u3068\u30AB\u30B7\u30A6\u30B9\u304C\u30AB\u30A8\u30B5\u30EB\u3092\u6697\u6BBA\u3057\u305F\u304C\u3001\u305D\u306E\u3084\u308A\u304F\u3061\u3068\u304D\u305F\u3089\u3001\u307E\u3063\u305F\u304F\u30AB\u30A8\u30B5\u30EB\u306E\u6C17\u306B\u304F\u308F\u306A\u3044\u65B9\u6CD5\u3067\u3042\u3063\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52207635704987649",
    "text" : "\u30D6\u30EB\u30FC\u30BF\u30B9\u3068\u30AB\u30B7\u30A6\u30B9\u304C\u30AB\u30A8\u30B5\u30EB\u3092\u6697\u6BBA\u3057\u305F\u304C\u3001\u305D\u306E\u3084\u308A\u304F\u3061\u3068\u304D\u305F\u3089\u3001\u307E\u3063\u305F\u304F\u30AB\u30A8\u30B5\u30EB\u306E\u6C17\u306B\u304F\u308F\u306A\u3044\u65B9\u6CD5\u3067\u3042\u3063\u305F\u3002",
    "id" : 52207635704987649,
    "created_at" : "2011-03-28 03:17:24 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 52231029204844544,
  "created_at" : "2011-03-28 04:50:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30A7\u30B6\u30FC\u30DE\u30C3\u30D7 \u3055\u304F\u3089\u30C1\u30FC\u30E0",
      "screen_name" : "wm_sakura",
      "indices" : [ 3, 13 ],
      "id_str" : "104756178",
      "id" : 104756178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52230835096653824",
  "text" : "RT @wm_sakura: \u4EAC\u90FD\u5730\u65B9\u6C17\u8C61\u53F0\u306B\u3088\u308B\u3068\u4EAC\u90FD\u306E\u6A19\u672C\u6728\u3082\u4ECA\u671D\u306E\u6642\u70B9\u30673\u8F2A\u54B2\u3044\u3066\u3044\u308B\u305D\u3046\u3067\u3059\u3002\u5348\u5F8C\u306B\u3082\u3046\u4E00\u56DE\u89B3\u306B\u884C\u304F\u3068\u306E\u3053\u3068\u3002\u304D\u3087\u3046\u3001\u3042\u3059\u306E\u3046\u3061\u306B\u958B\u82B1\u306E\u767A\u8868\u306A\u308B\u304B\uFF1F\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52220058650411009",
    "text" : "\u4EAC\u90FD\u5730\u65B9\u6C17\u8C61\u53F0\u306B\u3088\u308B\u3068\u4EAC\u90FD\u306E\u6A19\u672C\u6728\u3082\u4ECA\u671D\u306E\u6642\u70B9\u30673\u8F2A\u54B2\u3044\u3066\u3044\u308B\u305D\u3046\u3067\u3059\u3002\u5348\u5F8C\u306B\u3082\u3046\u4E00\u56DE\u89B3\u306B\u884C\u304F\u3068\u306E\u3053\u3068\u3002\u304D\u3087\u3046\u3001\u3042\u3059\u306E\u3046\u3061\u306B\u958B\u82B1\u306E\u767A\u8868\u306A\u308B\u304B\uFF1F\uFF01",
    "id" : 52220058650411009,
    "created_at" : "2011-03-28 04:06:46 +0000",
    "user" : {
      "name" : "\u30A6\u30A7\u30B6\u30FC\u30DE\u30C3\u30D7 \u3055\u304F\u3089\u30C1\u30FC\u30E0",
      "screen_name" : "wm_sakura",
      "protected" : false,
      "id_str" : "104756178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719386637\/for-twitter_icon_sakura_normal.gif",
      "id" : 104756178,
      "verified" : false
    }
  },
  "id" : 52230835096653824,
  "created_at" : "2011-03-28 04:49:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51983683942498304",
  "text" : "RT @galletti_bot: \u5341\u4E94\u4EBA\u306E\u5360\u3044\u5E2B\u304C\u3044\u305F\u3002\u4E00\u4EBA\u304C\u6B7B\u3093\u3067\u5341\u56DB\u4EBA\u304C\u6B8B\u3055\u308C\u305F\u3068\u304D\u3001\u5F7C\u3089\u306F\u8846\u8B70\u3057\u3066\u3001\u81EA\u5206\u305F\u3061\u306E\u306A\u304B\u304B\u3089\u5341\u4E94\u4EBA\u76EE\u3092\u9078\u3093\u3060\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51965957027008513",
    "text" : "\u5341\u4E94\u4EBA\u306E\u5360\u3044\u5E2B\u304C\u3044\u305F\u3002\u4E00\u4EBA\u304C\u6B7B\u3093\u3067\u5341\u56DB\u4EBA\u304C\u6B8B\u3055\u308C\u305F\u3068\u304D\u3001\u5F7C\u3089\u306F\u8846\u8B70\u3057\u3066\u3001\u81EA\u5206\u305F\u3061\u306E\u306A\u304B\u304B\u3089\u5341\u4E94\u4EBA\u76EE\u3092\u9078\u3093\u3060\u3002",
    "id" : 51965957027008513,
    "created_at" : "2011-03-27 11:17:04 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 51983683942498304,
  "created_at" : "2011-03-27 12:27:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3046\u306B",
      "screen_name" : "xx17",
      "indices" : [ 3, 8 ],
      "id_str" : "74136791",
      "id" : 74136791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51954891584831488",
  "text" : "RT @xx17: \u300C\u306D\u3047\u30EF\u30AF\u30EF\u30AF\u3055\u3093\u3001\u4ECA\u65E5\u306F\u4F55\u3092\u4F5C\u308B\u306E\uFF1F\u306D\u3047\u3001\u30EF\u30AF\u30EF\u30AF\u3055\u300E\u30B6\u30B7\u30E5\u30C3\u300F\u2026\u3048\u3063\u2026\u30EF\u30AF\u2026\u3069\u3046\u2026\u3057\u2026\u3066\u2026\u300D\u3086\u3063\u304F\u308A\u3068\u5D29\u308C\u843D\u3061\u308B\u30B4\u30ED\u30EA\u3002\u3058\u308F\u308A\u3058\u308F\u308A\u3068\u5E83\u304C\u3063\u3066\u3044\u304F\u8840\u6E9C\u307E\u308A\u3092\u7121\u611F\u60C5\u306A\u773C\u3067\u898B\u3064\u3081\u306A\u304C\u3089\u30EF\u30AF\u30EF\u30AF\u3055\u3093\u304C\u545F\u3044\u305F\u306E\u306F\u300C\u305D\u3046\u3060\u306D\u2026\u30B4\u30ED\u30EA\u2026\u4ECA\u65E5\u306F\u30A2\u30EA\u30D0\u30A4\u3092\u4F5C\u308D\u3046\u304B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5606264633565184",
    "text" : "\u300C\u306D\u3047\u30EF\u30AF\u30EF\u30AF\u3055\u3093\u3001\u4ECA\u65E5\u306F\u4F55\u3092\u4F5C\u308B\u306E\uFF1F\u306D\u3047\u3001\u30EF\u30AF\u30EF\u30AF\u3055\u300E\u30B6\u30B7\u30E5\u30C3\u300F\u2026\u3048\u3063\u2026\u30EF\u30AF\u2026\u3069\u3046\u2026\u3057\u2026\u3066\u2026\u300D\u3086\u3063\u304F\u308A\u3068\u5D29\u308C\u843D\u3061\u308B\u30B4\u30ED\u30EA\u3002\u3058\u308F\u308A\u3058\u308F\u308A\u3068\u5E83\u304C\u3063\u3066\u3044\u304F\u8840\u6E9C\u307E\u308A\u3092\u7121\u611F\u60C5\u306A\u773C\u3067\u898B\u3064\u3081\u306A\u304C\u3089\u30EF\u30AF\u30EF\u30AF\u3055\u3093\u304C\u545F\u3044\u305F\u306E\u306F\u300C\u305D\u3046\u3060\u306D\u2026\u30B4\u30ED\u30EA\u2026\u4ECA\u65E5\u306F\u30A2\u30EA\u30D0\u30A4\u3092\u4F5C\u308D\u3046\u304B\u306A\u2026\u300D\u3060\u3063\u305F\u3068\u3044\u3046\u3002",
    "id" : 5606264633565184,
    "created_at" : "2010-11-19 13:00:12 +0000",
    "user" : {
      "name" : "\u3066\u3046\u306B",
      "screen_name" : "xx17",
      "protected" : false,
      "id_str" : "74136791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689515753\/73b137a6909da2776e8aed6f89076677_normal.png",
      "id" : 74136791,
      "verified" : false
    }
  },
  "id" : 51954891584831488,
  "created_at" : "2011-03-27 10:33:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51929456301981696",
  "text" : "\u3082\u3046\u5C11\u3057\u3067\u82B1\u7269\u8A9E\u304B\u30FC\u3002\u51FA\u8CBB\u304C\u304B\u3055\u3080\u306A\u3002",
  "id" : 51929456301981696,
  "created_at" : "2011-03-27 08:52:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51661209891651586",
  "geo" : { },
  "id_str" : "51661472064999424",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u308C\u3082\u4ECA\u4E00\u3064\u30B7\u30B9\u30C6\u30E0\u304C\u308F\u304B\u3093\u306A\u3044\u3093\u3060\u3051\u3069\u524D\u671F\u82F1\u8A9E\u8AAD\u89E3\u3068\u5F8C\u671F\u30D5\u30E9\u8A9E\u6587\u6CD5\u843D\u3057\u305F\u3093\u3060\u304C\u30B3\u30FC\u30EB\u3067\u3044\u3044\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 51661472064999424,
  "in_reply_to_status_id" : 51661209891651586,
  "created_at" : "2011-03-26 15:07:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51660298788155393",
  "geo" : { },
  "id_str" : "51660747834540032",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u3046\u306A\u306E\u304B\u30FC\u3002\u6570\u5B66\u306B\u52C9\u5F37\u907F\u3051\u308B\u306E\u306F\u52A9\u304B\u308B\u2190\u3063\u3066\u304B\u3042\u308C\u3088\u308A\u524D\u306B\u5B66\u6821\u884C\u304F\u5FC5\u8981\u306A\u3044\u3088\u306D\uFF1F",
  "id" : 51660747834540032,
  "in_reply_to_status_id" : 51660298788155393,
  "created_at" : "2011-03-26 15:04:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51659363085070336",
  "geo" : { },
  "id_str" : "51659766233182208",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \uFF4D\uFF4A\uFF4B\u3000\u3042\u3068\u6559\u8077\u3042\u308B\u304B\u3089\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u306E\u304B\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3093\u3060\u3088\u306D\u3000\u4E00\u822C\u6559\u990A\u306E\u4F59\u5270\u3082\u3042\u308A\u3060\u304C",
  "id" : 51659766233182208,
  "in_reply_to_status_id" : 51659363085070336,
  "created_at" : "2011-03-26 15:00:22 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51658696878600192",
  "geo" : { },
  "id_str" : "51659132763254784",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E00\u5207\u8003\u3048\u3066\u3044\u306A\u3044\u3068\u8A00\u3063\u3066\u3082\u7B11\u308F\u306A\u3044\u3067\u307B\u3057\u3044orz\u660E\u65E5\u3042\u305F\u308A\u8003\u3048\u3066\u307F\u308B\u3002",
  "id" : 51659132763254784,
  "in_reply_to_status_id" : 51658696878600192,
  "created_at" : "2011-03-26 14:57:51 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51657375496683520",
  "geo" : { },
  "id_str" : "51658422315266048",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u7406\u7CFB\u5973\u5B50\u300C\u865A\u6570\u5358\u4F4D\u4EE5\u5916\u306Ei\u304C\u305D\u3093\u3056\u3044\u3059\u308B\u306E\u304B\u3057\u3089\uFF1F\u300D\u304F\u3089\u3044\u8A00\u3063\u3066\u307B\u3057\u3044",
  "id" : 51658422315266048,
  "in_reply_to_status_id" : 51657375496683520,
  "created_at" : "2011-03-26 14:55:02 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51554963414978560",
  "geo" : { },
  "id_str" : "51555390600646656",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u30CD\u30C3\u30C8\u3067\u898B\u308C\u308B\u306A\u3089URL\u6559\u3048\u3066\u30FC",
  "id" : 51555390600646656,
  "in_reply_to_status_id" : 51554963414978560,
  "created_at" : "2011-03-26 08:05:37 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51298460518989824",
  "text" : "\u5BDD\u308B\u3088\u30FC",
  "id" : 51298460518989824,
  "created_at" : "2011-03-25 15:04:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3084\u3089\u7BA1",
      "screen_name" : "yarare_kanrinin",
      "indices" : [ 3, 19 ],
      "id_str" : "147471915",
      "id" : 147471915
    }, {
      "name" : "\u3084\u3089\u7BA1",
      "screen_name" : "yarare_kanrinin",
      "indices" : [ 24, 40 ],
      "id_str" : "147471915",
      "id" : 147471915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51293558489096192",
  "text" : "RT @yarare_kanrinin: RT @yarare_kanrinin: \u3010\u6B63\u5F0F\u6C7A\u5B9A\u3011\uFF13\u6708\uFF13\uFF11\u65E5\u767A\u58F2\u306E\u300E\u82B1\u7269\u8A9E\u300F\u306B\u300E\u50B7\u7269\u8A9E\u300F\u5287\u5834\u6620\u753B\u5316\u6C7A\u5B9A\u306E\u6587\u5B57\u304C\uFF01\uFF01\uFF5C\u3084\u3089\u304A\u3093\uFF01 http:\/\/bit.ly\/ikpod3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3084\u3089\u7BA1",
        "screen_name" : "yarare_kanrinin",
        "indices" : [ 3, 19 ],
        "id_str" : "147471915",
        "id" : 147471915
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51286366859964416",
    "text" : "RT @yarare_kanrinin: \u3010\u6B63\u5F0F\u6C7A\u5B9A\u3011\uFF13\u6708\uFF13\uFF11\u65E5\u767A\u58F2\u306E\u300E\u82B1\u7269\u8A9E\u300F\u306B\u300E\u50B7\u7269\u8A9E\u300F\u5287\u5834\u6620\u753B\u5316\u6C7A\u5B9A\u306E\u6587\u5B57\u304C\uFF01\uFF01\uFF5C\u3084\u3089\u304A\u3093\uFF01 http:\/\/bit.ly\/ikpod3",
    "id" : 51286366859964416,
    "created_at" : "2011-03-25 14:16:37 +0000",
    "user" : {
      "name" : "\u3084\u3089\u7BA1",
      "screen_name" : "yarare_kanrinin",
      "protected" : false,
      "id_str" : "147471915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472064869588422656\/3_rJm-Gp_normal.jpeg",
      "id" : 147471915,
      "verified" : false
    }
  },
  "id" : 51293558489096192,
  "created_at" : "2011-03-25 14:45:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51288328527556608",
  "text" : "\u300C\u6240\u9577\u3001TNP\u3063\u3066\u4F55\u306E\u7565\u306A\u3093\u3067\u3059\u304B\uFF1F\u300D \n\u300C\u300E\u697D\u3057\u3044 \u4EF2\u9593\u304C \u307D\u307D\u307D\u307D\u30FC\u3093\uFF01\u300F\u3060\uFF01\u300D",
  "id" : 51288328527556608,
  "created_at" : "2011-03-25 14:24:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51287866470440960",
  "text" : "\u5439\u3044\u305F",
  "id" : 51287866470440960,
  "created_at" : "2011-03-25 14:22:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51287818588274689",
  "text" : "Q\u7BC92003\u5E74\u306E\u8EFD\u91CF\u9244\u9AA8\u306E\u30A2\u30D1\u30FC\u30C8\u3063\u3066\u5730\u9707\u6765\u305F\u3089\u5D29\u308C\u3061\u3083\u3044\u307E\u3059\u304B\uFF1F\u4E00\u4EBA\u66AE\u3089\u3057\u3067\u3061\u3087\u3063\u3068\u5FC3\u914D\u306B\u306A\u3063\u3066\u304D\u307E\u3057\u305F \nA\u3088\u307B\u3069\u306E\u898F\u6A21\u306E\u5730\u9707\u3067\u306A\u3051\u308C\u3070\u5927\u4E08\u592B\u3060\u3068\u601D\u308F\u308C\u307E\u3059 \n\u7BC92003\u5E74\u306A\u3089\u6CD5\u9686\u5BFA\u3092\u8D85\u3048\u308B\u6B74\u53F2\u7684\u5EFA\u9020\u7269\u3067\u3059\u306E\u3067 \n\u6587\u5316\u8CA1\u4FDD\u8B77\u306E\u89B3\u70B9\u304B\u3089\u4F55\u304B\u3057\u3089\u306E\u4FDD\u8B77\u5BFE\u7B56\u304C\u53D6\u3089\u308C\u3066\u308B\u306F\u305A\u3067\u3059",
  "id" : 51287818588274689,
  "created_at" : "2011-03-25 14:22:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51281779247693824",
  "geo" : { },
  "id_str" : "51281978342912000",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u7D50\u5C40\u5BB6\u5EAD\u6559\u5E2B\u306A\u306E\u3067\u3059\u3002\u4E00\u4EBA\u306F\u512A\u79C0\u3067\u3044\u3044\u306E\u3067\u3059\u304C\u3082\u3046\u4E00\u4EBA\u306F\u2026\u304A\u5BDF\u3057\u304F\u3060\u3055\u3044\u3002",
  "id" : 51281978342912000,
  "in_reply_to_status_id" : 51281779247693824,
  "created_at" : "2011-03-25 13:59:11 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51280827228753920",
  "text" : "\u305F\u3044\u3066\u3044\u30D0\u30A4\u30C8\u5E30\u308A\u3067\u6301\u3063\u3066\u304D\u305F\u672C\u3092\u8AAD\u307F\u7D42\u3048\u3066\u308B\u3068\u3064\u3089\u3064\u3089\u3042\u308B\u3053\u3068\u306A\u3044\u3053\u3068\u66F8\u3044\u3066\u308B\u3068\u304D\u304C\u4E00\u756A\u3064\u3076\u3084\u3044\u3066\u3044\u308B\u6C17\u304C",
  "id" : 51280827228753920,
  "created_at" : "2011-03-25 13:54:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51279581671460866",
  "text" : "\u3053\u306E\u6642\u9593\u7D50\u69CBTL\u306B\u5F35\u308A\u4ED8\u3044\u3066\u3044\u308B\u3051\u308C\u3069\u3001\u81EA\u5206\u306E\u30C4\u30A4\u30FC\u30C8\u306B\u306F\u306A\u307F\u304C\u3042\u308B\u3088\u306A\u3041\u3001\u3068\u601D\u3046",
  "id" : 51279581671460866,
  "created_at" : "2011-03-25 13:49:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51277857527308288",
  "text" : "@koketomi \u4FFA\u3082\u3060",
  "id" : 51277857527308288,
  "created_at" : "2011-03-25 13:42:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51273835001032705",
  "geo" : { },
  "id_str" : "51274195207856128",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u30B5\u30FC\u30BB\u30F3m(_ _)m",
  "id" : 51274195207856128,
  "in_reply_to_status_id" : 51273835001032705,
  "created_at" : "2011-03-25 13:28:15 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51266501419859969",
  "geo" : { },
  "id_str" : "51266899669041152",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30B9\u30AB\u30A4\u30D7\u306E\u5C0E\u5165\u306F\u3069\u3046\u306A\u3063\u305F\u3057",
  "id" : 51266899669041152,
  "in_reply_to_status_id" : 51266501419859969,
  "created_at" : "2011-03-25 12:59:16 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51252891478016001",
  "text" : "RT @tameninaru: \u53E3\u88C2\u3051\u5973\u306B\u51FA\u304F\u308F\u3057\u305F\u3089\u3001\u3079\u3063\u7532\u98F4\u3092\u3042\u3052\u308B\u3068\u826F\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51236901188935680",
    "text" : "\u53E3\u88C2\u3051\u5973\u306B\u51FA\u304F\u308F\u3057\u305F\u3089\u3001\u3079\u3063\u7532\u98F4\u3092\u3042\u3052\u308B\u3068\u826F\u3044",
    "id" : 51236901188935680,
    "created_at" : "2011-03-25 11:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 51252891478016001,
  "created_at" : "2011-03-25 12:03:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51186849695285248",
  "text" : "\u4ECA\u65E5\u3082\u307E\u305F\u4E00\u65E5\u304C\u7121\u70BA\u306B\u904E\u304E\u3066\u3044\u304F\u3002\u3002\u3002",
  "id" : 51186849695285248,
  "created_at" : "2011-03-25 07:41:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51149479285493760",
  "text" : "\u8AAD\u66F8\u304B\u306A\u30FC",
  "id" : 51149479285493760,
  "created_at" : "2011-03-25 05:12:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50916000400547840",
  "text" : "RT @s__tech: \u4FFA\u306E\u30BF\u30FC\u30F3\uFF01\u6210\u7E3E\u8868\u3092\u30C9\u30ED\u30FC\uFF01\u4E0A\u304B\u3089\u9806\u306B\u4E0D\u53EF\u3001\u53EF\u3001\u53EF\u3001\u4E0D\u53EF\u3001\u4E0D\u53EF\u3001\u4E0D\u53EF\u3001\u826F\u3001\u4E0D\u53EF\u3001\u512A\u3001\u53EF\u3001\u4E0D\u53EF\uFF01\u3088\u3063\u3066\u5358\u4F4D\u6570\u57FA\u6E96\u5024\u672A\u6E80\u306B\u3088\u308A\u7559\u5E74\u6C7A\u5B9A\uFF01\u6559\u52D9\u8AB2\u304B\u3089\u5B9F\u5BB6\u306B\u7559\u5E74\u3057\u305F\u3068\u306E\u901A\u77E5\uFF01\u30BF\u30FC\u30F3\u30A8\u30F3\u30C9\u3060\uFF01\n\u89AA\u306E\u30BF\u30FC\u30F3\uFF01\u307E\u305A\u6FC0\u6012\uFF01\u4ED5\u9001\u308A\u3092\u30AB\u30C3\u30C8\uFF01\u300C\u9032\u7D1A\u3059\u308B\u307E\u3067\u5E30\u3063\u3066\u304F\u3093 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50905027363090433",
    "text" : "\u4FFA\u306E\u30BF\u30FC\u30F3\uFF01\u6210\u7E3E\u8868\u3092\u30C9\u30ED\u30FC\uFF01\u4E0A\u304B\u3089\u9806\u306B\u4E0D\u53EF\u3001\u53EF\u3001\u53EF\u3001\u4E0D\u53EF\u3001\u4E0D\u53EF\u3001\u4E0D\u53EF\u3001\u826F\u3001\u4E0D\u53EF\u3001\u512A\u3001\u53EF\u3001\u4E0D\u53EF\uFF01\u3088\u3063\u3066\u5358\u4F4D\u6570\u57FA\u6E96\u5024\u672A\u6E80\u306B\u3088\u308A\u7559\u5E74\u6C7A\u5B9A\uFF01\u6559\u52D9\u8AB2\u304B\u3089\u5B9F\u5BB6\u306B\u7559\u5E74\u3057\u305F\u3068\u306E\u901A\u77E5\uFF01\u30BF\u30FC\u30F3\u30A8\u30F3\u30C9\u3060\uFF01\n\u89AA\u306E\u30BF\u30FC\u30F3\uFF01\u307E\u305A\u6FC0\u6012\uFF01\u4ED5\u9001\u308A\u3092\u30AB\u30C3\u30C8\uFF01\u300C\u9032\u7D1A\u3059\u308B\u307E\u3067\u5E30\u3063\u3066\u304F\u3093\u306A\u300D\u3068\u4E00\u8A00\uFF01\n\u4FFA\u306E\u30BF\u30FC\u30F3\uFF01\u571F\u4E0B\u5EA7\uFF01",
    "id" : 50905027363090433,
    "created_at" : "2011-03-24 13:01:18 +0000",
    "user" : {
      "name" : "\u307D\u3093\u3061\u3087(\u5C4D)",
      "screen_name" : "poncho_ex",
      "protected" : false,
      "id_str" : "193714241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458993132080607232\/6-nBX_kj_normal.jpeg",
      "id" : 193714241,
      "verified" : false
    }
  },
  "id" : 50916000400547840,
  "created_at" : "2011-03-24 13:44:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50910476363759616",
  "text" : "RT @NHK_PR: \u3048\u30FC\u3063\u3068\u3001\u795E\u306B\u3064\u3044\u3066\u306E\u3054\u8CEA\u554F\u306B\u306F\u304A\u7B54\u3048\u81F4\u3057\u304B\u306D\u307E\u3059\u3002\u4F55\u5352\u3054\u5BB9\u8D66\u4E0B\u3055\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50910238483820544",
    "text" : "\u3048\u30FC\u3063\u3068\u3001\u795E\u306B\u3064\u3044\u3066\u306E\u3054\u8CEA\u554F\u306B\u306F\u304A\u7B54\u3048\u81F4\u3057\u304B\u306D\u307E\u3059\u3002\u4F55\u5352\u3054\u5BB9\u8D66\u4E0B\u3055\u3044\u3002",
    "id" : 50910238483820544,
    "created_at" : "2011-03-24 13:22:01 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 50910476363759616,
  "created_at" : "2011-03-24 13:22:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "\u3082\u3063\u3061\uFF5E",
      "screen_name" : "mocchy007",
      "indices" : [ 34, 44 ],
      "id_str" : "117256918",
      "id" : 117256918
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 79, 86 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "\u307E\u3053\u3063\u3061\u3083\u3093@\u307E\u3063\u304D\u3043",
      "screen_name" : "mako32",
      "indices" : [ 87, 94 ],
      "id_str" : "118270700",
      "id" : 118270700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50892534171451392",
  "text" : "RT @NHK_PR: \u3075\u3001\u4E0D\u899A\u2026(&gt;\u0414&lt; \uFF1B) RT @mocchy007: \u30AB\u30C3\u30B3\u3044\u3044\u306A\uFF01\u3068\u601D\u3063\u305F\u3051\u3069\u75DB\u6068\u306E\u30DF\u30B9\u767A\u898B\u3002\u3067\u3082\u305D\u3053\u304C\u597D\u304D\u3002 RT @NHK_PR @mako32 \u5909\u5316\u7403\u306A\u3069\u3044\u308A\u307E\u305B\u3093\u3002\u76F4\u7403\u3067\u300C\u3042\u305F\u306A\u304C\u597D\u304D\u3067\u3059\u3001\u5927\u597D\u304D\u3067\u3059\u300D\u3068\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3082\u3063\u3061\uFF5E",
        "screen_name" : "mocchy007",
        "indices" : [ 22, 32 ],
        "id_str" : "117256918",
        "id" : 117256918
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 67, 74 ],
        "id_str" : "93311525",
        "id" : 93311525
      }, {
        "name" : "\u307E\u3053\u3063\u3061\u3083\u3093@\u307E\u3063\u304D\u3043",
        "screen_name" : "mako32",
        "indices" : [ 75, 82 ],
        "id_str" : "118270700",
        "id" : 118270700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50892323592212483",
    "text" : "\u3075\u3001\u4E0D\u899A\u2026(&gt;\u0414&lt; \uFF1B) RT @mocchy007: \u30AB\u30C3\u30B3\u3044\u3044\u306A\uFF01\u3068\u601D\u3063\u305F\u3051\u3069\u75DB\u6068\u306E\u30DF\u30B9\u767A\u898B\u3002\u3067\u3082\u305D\u3053\u304C\u597D\u304D\u3002 RT @NHK_PR @mako32 \u5909\u5316\u7403\u306A\u3069\u3044\u308A\u307E\u305B\u3093\u3002\u76F4\u7403\u3067\u300C\u3042\u305F\u306A\u304C\u597D\u304D\u3067\u3059\u3001\u5927\u597D\u304D\u3067\u3059\u300D\u3068\u3002",
    "id" : 50892323592212483,
    "created_at" : "2011-03-24 12:10:50 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 50892534171451392,
  "created_at" : "2011-03-24 12:11:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50882484535181312",
  "text" : "\u5BDD\u5F85\u6708\u3002\u3053\u308C\u306F\u7720\u3044\u7406\u7531\u306B\u4F7F\u3048\u308B\u30C3(\u30AD\u30EA\u30C3",
  "id" : 50882484535181312,
  "created_at" : "2011-03-24 11:31:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50878256005648384",
  "text" : "@ayu167 \u5FEB\u9069\u30FC\u3002\u753B\u9762\u306B\u65B0\u3057\u3044\u306E\u3092\u8868\u793A\u3057\u3066\u304F\u308C\u308B\u306E\u306F\u4FBF\u5229\u306D\u30FC\u3002",
  "id" : 50878256005648384,
  "created_at" : "2011-03-24 11:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50877756187230208",
  "text" : "\u307E\u305F\u307C\u3093\u3084\u308A\u3057\u3066\u3044\u308B\u306E\u306F\u70AC\u71F5\u306E\u6E29\u3082\u308A\u306E\u305B\u3044\u304B\u3001\u305D\u308C\u3068\u3082\u3084\u3063\u3071\u308A\u85AC\u306E\u305B\u3044\u306A\u306E\u304B\u3002",
  "id" : 50877756187230208,
  "created_at" : "2011-03-24 11:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50877033475080192",
  "text" : "@ayu167 \u5510\u7A81\u904E\u304E\u3066\u7B11\u3063\u305F",
  "id" : 50877033475080192,
  "created_at" : "2011-03-24 11:10:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50859392651886592",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u305F\u3089\u76EE\u304C\u899A\u3081\u305F\uFF01\u306F\u305A\uFF01 \u3067\u3082\u3053\u306E\u6642\u9593\u306B\u76EE\u304C\u899A\u3081\u3066\u3044\u3044\u306E\u304B\u306A\u3041\u3002",
  "id" : 50859392651886592,
  "created_at" : "2011-03-24 09:59:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50852795837980672",
  "text" : "\u663C\u5BDD\u3057\u305F\u3051\u3069\u307E\u3060\u30DD\u30EF\u30DD\u30EF\u3057\u3066\u308B\u2026\u5BDD\u4E0D\u8DB3\u3067\u3082\u306A\u3044\u3057\u306A\u30FC\u3002\u4E00\u5FDC\u82B1\u7C89\u75C7\u306E\u85AC\u306F\u7720\u304F\u306A\u308B\u3089\u3057\u3044\u3051\u3069\u3001\u666E\u6BB5\u5E73\u6C17\u3060\u3057\u3002",
  "id" : 50852795837980672,
  "created_at" : "2011-03-24 09:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50767332984889344",
  "text" : "\u771F\u663C\u9593\u306A\u306E\u306B\u7720\u6C17\u304C\u2026\u70AC\u71F5\u306E\u6E29\u3082\u308A\u30A7\u2026",
  "id" : 50767332984889344,
  "created_at" : "2011-03-24 03:54:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50762232405049345",
  "text" : "\u82B1\u7C89\u75C7\u2192\u304F\u3057\u3083\u307F\u2192\u5507\u907F\u3051\u308B orz",
  "id" : 50762232405049345,
  "created_at" : "2011-03-24 03:33:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50588583823810562",
  "text" : "\u7A4D\u5206\u3057\u3066\u305F\u3089\u3053\u3093\u306A\u6642\u9593\u3060\u3002\u5BDD\u308B\u3088\u30FC\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 50588583823810562,
  "created_at" : "2011-03-23 16:03:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 9, 20 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50575316875350016",
  "text" : "\u304F\u3057\u3083\u307F\u3082\u30FCRT @magokoro84: \u9F3B\u3065\u307E\u308A\u3072\u3069\u3044\u306A\u3046",
  "id" : 50575316875350016,
  "created_at" : "2011-03-23 15:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50574686999953408",
  "text" : "\u9F3B\u6C34\u304C\u30EA\u30D5\u30EC\u30AF\u30B7\u30E7\u30F3\uFF08\u6DB2\u72B6\u5316\u73FE\u8C61\uFF09",
  "id" : 50574686999953408,
  "created_at" : "2011-03-23 15:08:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50565105762574336",
  "text" : "\u3053\u306E\u524D\u8A00\u3063\u3066\u305F\u30C4\u30A4\u30C3\u30BF-\u5C02\u7528\u30D6\u30E9\u30A6\u30B6\uFF08\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\uFF09\u5C0E\u5165\u3057\u3066\u307F\u305F\u30FC\u3002\u65B0\u9BAE\u3002",
  "id" : 50565105762574336,
  "created_at" : "2011-03-23 14:30:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50551378648637441",
  "geo" : { },
  "id_str" : "50554030937735168",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3046\u3093\u3001\u30B7\u30E5\u30EC\u30EA\u30F3\u30AC\u30FC\u65B9\u7A0B\u5F0F\u3002\u304B\u3058\u308C\u308B\u306A\u3089\u304B\u3058\u308A\u305F\u3044\u306D\u3047\u3002",
  "id" : 50554030937735168,
  "in_reply_to_status_id" : 50551378648637441,
  "created_at" : "2011-03-23 13:46:34 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50550558196645888",
  "geo" : { },
  "id_str" : "50550859972612096",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30B7\u30E5\u30EC\u30EA\u30F3\u30AC\u30FC\uFF01",
  "id" : 50550859972612096,
  "in_reply_to_status_id" : 50550558196645888,
  "created_at" : "2011-03-23 13:33:58 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50547852421775360",
  "text" : "\u671D\u85AC\u98F2\u307F\u640D\u306A\u3063\u305F\u305B\u3044\u3067\u9F3B\u3084\u3089\u76EE\u3084\u3089\u6B8B\u5FF5\u306A\u8ABF\u5B50",
  "id" : 50547852421775360,
  "created_at" : "2011-03-23 13:22:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50547497965326336",
  "text" : "\u3057\u304B\u3057\u51FA\u7248\u793E\u304C\u6697\u9ED2\u901A\u4FE1\u56E3\u3001\u771F\u5B9F\u306E\u307F\u3092\u8A18\u8FF0\u3059\u308B\u4F1A\u3063\u3066\u306A\u3093\u306A\u306E\u3055\u3002",
  "id" : 50547497965326336,
  "created_at" : "2011-03-23 13:20:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50546778046611456",
  "text" : "\u98FE\u3063\u3068\u304F\u4ED6\u306B\u7528\u9014\u304C\u898B\u5F53\u305F\u3089\u306A\u3044\u3051\u3069\uFF13\uFF11\uFF14\u5186\u3001\uFF12\uFF17\uFF11\u5186\u306A\u3089\u307E\u3041\u3044\u3044\u304B\u306A\u3063\u3066",
  "id" : 50546778046611456,
  "created_at" : "2011-03-23 13:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50546528238051329",
  "text" : "\u5186\u5468\u7387\u767E\u4E07\u6841\u8868\u3068\u81EA\u7136\u5BFE\u6570\u767E\u4E07\u6841\u8868\u3092\u751F\u5354\u3067\u6CE8\u6587\u3057\u305F\u30FC",
  "id" : 50546528238051329,
  "created_at" : "2011-03-23 13:16:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50495058641813505",
  "text" : "\u306B\u3057\u3066\u3082\u5E30\u308A\u306E\u96FB\u8ECA\u306F\u624B\u6301\u3061\u7121\u6C99\u6C70\u2026\u3002\u6570\u5B66\u30AC\u30FC\u30EB\u3092\u6301\u3063\u3066\u304F\u308B\u3079\u304D\u3060\u3063\u305F\u304B\u306A\u3002",
  "id" : 50495058641813505,
  "created_at" : "2011-03-23 09:52:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50494829041430528",
  "text" : "\u30A2\u30AF\u30ED\u30A4\u30C9\u6BBA\u3057\u8AAD\u4E86\u3002\u5947\u4F5C\u306A\u308A\u3002",
  "id" : 50494829041430528,
  "created_at" : "2011-03-23 09:51:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50414318554054656",
  "text" : "RT @tameninaru: \u304A\u91C8\u8FE6\u69D8\u306F\u3001\u30AB\u30C8\u30EA\u30C3\u30AF\u306B\u3088\u3063\u3066\u300C\u8056\u4EBA\u300D\u306B\u5217\u305B\u3089\u308C\u3066\u3044\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50376224303886336",
    "text" : "\u304A\u91C8\u8FE6\u69D8\u306F\u3001\u30AB\u30C8\u30EA\u30C3\u30AF\u306B\u3088\u3063\u3066\u300C\u8056\u4EBA\u300D\u306B\u5217\u305B\u3089\u308C\u3066\u3044\u308B\u3002",
    "id" : 50376224303886336,
    "created_at" : "2011-03-23 02:00:02 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 50414318554054656,
  "created_at" : "2011-03-23 04:31:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 45, 52 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50413886381371392",
  "text" : "RT @NHK_PR: \u3068\u3042\u308B\u79D1\u5B66\u3067\u52D5\u3044\u3066\u3044\u307E\u3059\u3002 RT @tentou_mushi7: @NHK_PR \u30C1\u30AF\u30BF\u30AF\u3055\u3093\u306F\u304A\u663C\u306F\u4F55\u3092\u98DF\u3079\u308B\u306E\u3067\u3059\u304B\uFF1F\u3068\u3044\u3046\u304B\u4F55\u3067\u52D5\u3044\u3066\u3044\u308B\u306E\u3067\u3059\u304B\uFF1F\u30BC\u30F3\u30DE\u30A4\uFF1F\u96FB\u6C60\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 33, 40 ],
        "id_str" : "93311525",
        "id" : 93311525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50410436591497216",
    "text" : "\u3068\u3042\u308B\u79D1\u5B66\u3067\u52D5\u3044\u3066\u3044\u307E\u3059\u3002 RT @tentou_mushi7: @NHK_PR \u30C1\u30AF\u30BF\u30AF\u3055\u3093\u306F\u304A\u663C\u306F\u4F55\u3092\u98DF\u3079\u308B\u306E\u3067\u3059\u304B\uFF1F\u3068\u3044\u3046\u304B\u4F55\u3067\u52D5\u3044\u3066\u3044\u308B\u306E\u3067\u3059\u304B\uFF1F\u30BC\u30F3\u30DE\u30A4\uFF1F\u96FB\u6C60\uFF1F",
    "id" : 50410436591497216,
    "created_at" : "2011-03-23 04:15:59 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 50413886381371392,
  "created_at" : "2011-03-23 04:29:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50209136784322560",
  "text" : "twitter\u7528\u306E\u30D6\u30E9\u30A6\u30B6\u306E\u5C0E\u5165\u3092\u691C\u8A0E\u3057\u3064\u3064\u304A\u4F11\u307F\u306A\u3055\u3044",
  "id" : 50209136784322560,
  "created_at" : "2011-03-22 14:56:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50201273181552641",
  "geo" : { },
  "id_str" : "50204768429281280",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u4EEE\u514D\u3082\u672C\u514D\u3082\u4E00\u767A\u5408\u683C\u3067\u3057\u305F\u3001\u3068\u66F4\u306B\u30CF\u30FC\u30C9\u30EB\u3092\u4E0A\u3052\u3066\u307F\u305F\u308A\u3002",
  "id" : 50204768429281280,
  "in_reply_to_status_id" : 50201273181552641,
  "created_at" : "2011-03-22 14:38:44 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50154127396835328",
  "text" : "RT @galletti_bot: \u30A2\u30EC\u30AD\u30B5\u30F3\u30C0\u30FC\u5927\u738B\u306F\u3001\u305D\u306E\u6B7B\u306B\u5148\u7ACB\u3064\u3053\u3068\u4E8C\u5341\u4E00\u5E74\u524D\u306B\u6BD2\u6BBA\u3055\u308C\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50154026058256384",
    "text" : "\u30A2\u30EC\u30AD\u30B5\u30F3\u30C0\u30FC\u5927\u738B\u306F\u3001\u305D\u306E\u6B7B\u306B\u5148\u7ACB\u3064\u3053\u3068\u4E8C\u5341\u4E00\u5E74\u524D\u306B\u6BD2\u6BBA\u3055\u308C\u305F\u3002",
    "id" : 50154026058256384,
    "created_at" : "2011-03-22 11:17:06 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 50154127396835328,
  "created_at" : "2011-03-22 11:17:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C7\u30FC\u30D6\u30FB\u30B9\u30DA\u30AF\u30BF\u30FC ",
      "screen_name" : "dave_spector",
      "indices" : [ 3, 16 ],
      "id_str" : "25991694",
      "id" : 25991694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50112469317857280",
  "text" : "RT @dave_spector: \u3053\u306E\u6642\u671F\u3053\u305D\u3088\u304F\u300C\u7A7A\u6C17\u3092\u8AAD\u3081\u300D\u3068\u8A00\u308F\u308C\u307E\u3059\u304C\u3001\u7A7A\u6C17\u306F\u5438\u3046\u3082\u306E\u3060\u3068\u601D\u3044\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50104297488252928",
    "text" : "\u3053\u306E\u6642\u671F\u3053\u305D\u3088\u304F\u300C\u7A7A\u6C17\u3092\u8AAD\u3081\u300D\u3068\u8A00\u308F\u308C\u307E\u3059\u304C\u3001\u7A7A\u6C17\u306F\u5438\u3046\u3082\u306E\u3060\u3068\u601D\u3044\u307E\u3059\u3002",
    "id" : 50104297488252928,
    "created_at" : "2011-03-22 07:59:30 +0000",
    "user" : {
      "name" : "\u30C7\u30FC\u30D6\u30FB\u30B9\u30DA\u30AF\u30BF\u30FC ",
      "screen_name" : "dave_spector",
      "protected" : false,
      "id_str" : "25991694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1002003570\/________normal.jpg",
      "id" : 25991694,
      "verified" : true
    }
  },
  "id" : 50112469317857280,
  "created_at" : "2011-03-22 08:31:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50098532329328640",
  "geo" : { },
  "id_str" : "50101020554043392",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u4E00\u5E74\u4F7F\u3063\u3066\u3082\u9593\u9055\u3048\u3046\u308B\u3053\u3068\u3082\u8003\u3048\u305F\u30B7\u30B9\u30C6\u30E0\u306B\u3057\u3066\u6B32\u3057\u3044\u306A\u3002",
  "id" : 50101020554043392,
  "in_reply_to_status_id" : 50098532329328640,
  "created_at" : "2011-03-22 07:46:28 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50061878096957440",
  "text" : "RT @NISIOISIN_BOT: \u3071\u306A\u3044\u306E\u3002\u3053\u306E\u308F\u3063\u304B\u72B6\u306E\u98DF\u3079\u7269\u3001\u30DE\u30B8\u3067\u307E\u3044\u3046\u30FC\u3002\u6B63\u306B\u7518\u5473\u306E\u8A70\u307E\u3063\u305F\u6307\u8F2A\u306E\u5B9D\u77F3\u7BB1\u3058\u3083",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50050745780805632",
    "text" : "\u3071\u306A\u3044\u306E\u3002\u3053\u306E\u308F\u3063\u304B\u72B6\u306E\u98DF\u3079\u7269\u3001\u30DE\u30B8\u3067\u307E\u3044\u3046\u30FC\u3002\u6B63\u306B\u7518\u5473\u306E\u8A70\u307E\u3063\u305F\u6307\u8F2A\u306E\u5B9D\u77F3\u7BB1\u3058\u3083",
    "id" : 50050745780805632,
    "created_at" : "2011-03-22 04:26:42 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 50061878096957440,
  "created_at" : "2011-03-22 05:10:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49850580461551616",
  "text" : "\u5BDD\u308B \u304A\u4F11\u307F",
  "id" : 49850580461551616,
  "created_at" : "2011-03-21 15:11:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49837554626859008",
  "geo" : { },
  "id_str" : "49838026070835200",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u79C1\u306F\u542B\u307E\u308C\u3066\u3044\u307E\u3059\u3067\u3057\u3087\u3046\u304B\u30FB\u30FB\u30FB\uFF1F",
  "id" : 49838026070835200,
  "in_reply_to_status_id" : 49837554626859008,
  "created_at" : "2011-03-21 14:21:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49833971512643584",
  "geo" : { },
  "id_str" : "49836318276059136",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4E2D\u7ACB\u3068\u8A00\u308F\u308C\u307E\u3057\u305F\u3002\u30CB\u30E5\u30FC\u30C8\u30E9\u30EB\u306B\u9650\u308A\u307E\u3059\u3002\u30E1\u30E1\u307F\u305F\u3044\u306B\uFF57",
  "id" : 49836318276059136,
  "in_reply_to_status_id" : 49833971512643584,
  "created_at" : "2011-03-21 14:14:38 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49830824488611840",
  "geo" : { },
  "id_str" : "49833990651248640",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u6587\u6CD5\u7684\u306B\u306F\u4EF0\u308B\u901A\u308A\u307F\u305F\u3044\u3002\u3067\u3082\u307E\u3041\u691C\u7D22\u304B\u3051\u305F\u3089\u82F1\u8A9E\u306E\u30B5\u30A4\u30C8\u3061\u3089\u307B\u3089\u5F15\u3063\u304B\u304B\u308B\u3057\u826F\u3044\u304B\u306A\u2015\u3063\u3066\u2190\u3000\u3067\u3082\u6C17\u3065\u304B\u306A\u304B\u3063\u305F\u304B\u3089\u6B32\u3057\u3044\u6307\u6458\u3002\u3042\u308A\u304C\u3068\u3046\u3002",
  "id" : 49833990651248640,
  "in_reply_to_status_id" : 49830824488611840,
  "created_at" : "2011-03-21 14:05:23 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49830124010471424",
  "geo" : { },
  "id_str" : "49830564391432192",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3042\u306E\u554F\u984C\u306F\u7570\u5E38\u3067\u3059\u304B\u3089\uFF57\uFF57",
  "id" : 49830564391432192,
  "in_reply_to_status_id" : 49830124010471424,
  "created_at" : "2011-03-21 13:51:47 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49830461203169280",
  "text" : "\u307E\u3041\u6C17\u304C\u5411\u3044\u305F\u3089\u3084\u3063\u3066\u307F\u3088\u3046\u3002Let's do it as I want.",
  "id" : 49830461203169280,
  "created_at" : "2011-03-21 13:51:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49829396445544448",
  "geo" : { },
  "id_str" : "49829780232749056",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3084\u3089\u306A\u3044\u3068\u8870\u3048\u305D\u3046\u3060\u304B\u3089\u3067\u3059\u3002",
  "id" : 49829780232749056,
  "in_reply_to_status_id" : 49829396445544448,
  "created_at" : "2011-03-21 13:48:40 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49829025299968000",
  "text" : "\u3053\u3046\u3044\u3046\u3064\u3076\u3084\u304D\u306E\u5F62\u5F0F\u3063\u3066\u3069\u3046\u306A\u3093\u3060\u308D\u3002",
  "id" : 49829025299968000,
  "created_at" : "2011-03-21 13:45:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49828791643668481",
  "text" : "\u3042\u3001\u3067\u3082\u30A2\u30DB\u306A\u30DF\u30B9\u306A\u3089\u3053\u3063\u305D\u308A\u6307\u6458\u3057\u3066\u304F\u308C\u306A\u3044\u3068\u52C9\u5F37\u306B\u306A\u3089\u306A\u3044\u304B\u3082\u3002\u3000But when I have a big foolish mistake,please tell me and correct that for me.",
  "id" : 49828791643668481,
  "created_at" : "2011-03-21 13:44:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49828392031354880",
  "text" : "\u52E2\u3044\u3067\u545F\u3044\u3066\u308B\u304B\u3089\u6587\u6CD5\u306E\u30DF\u30B9\u3068\u304B\u3042\u3093\u307E\u308A\u53E9\u304B\u306A\u3044\u3067\u307B\u3057\u3044\u306A\u3002I tweet without thinking deeply,please don't criticize grammatical mistakes.",
  "id" : 49828392031354880,
  "created_at" : "2011-03-21 13:43:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49826465751109632",
  "text" : "\u306A\u3093\u304B\u4ECA\u65E5\u306F\u5999\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u306B\u5F35\u308A\u4ED8\u3044\u3066\u3044\u305F\u3044\u6C17\u5206\u3060\u306A\u3002Somehow,I feel like keeping looking Twitter now.",
  "id" : 49826465751109632,
  "created_at" : "2011-03-21 13:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49824782237188096",
  "geo" : { },
  "id_str" : "49825619395092480",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u3001\u30A6\u30A9\u30C3\u30AB\u5165\u3063\u3066\u308B\u30E2\u30B9\u30B3\u30DF\u30E5\u30FC\u30EB\u98F2\u3093\u3058\u3083\u3063\u305F\uFF57\u5927\u4E08\u592B\u304B\u306A\uFF57\uFF57\uFF57",
  "id" : 49825619395092480,
  "in_reply_to_status_id" : 49824782237188096,
  "created_at" : "2011-03-21 13:32:08 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49824377210019840",
  "text" : "How can I deal with these empty bottles?",
  "id" : 49824377210019840,
  "created_at" : "2011-03-21 13:27:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49823809053802497",
  "text" : "\u30D3\u30F3\u3063\u3066\u3069\u3046\u3084\u3063\u3066\u51E6\u5206\u3057\u305F\u3089\u3044\u3044\u3093\u3060\u308D",
  "id" : 49823809053802497,
  "created_at" : "2011-03-21 13:24:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49822926983274497",
  "text" : "\u3053\u306E\u30B5\u30A4\u30C8\u3067\uFF08\u5FC5\u305A\u3057\u3082\u8A13\u7DF4\u3055\u308C\u3066\u306A\u3044\u304B\u3082\u3057\u308C\u306A\u3044\uFF09\u30CD\u30A4\u30C6\u30A3\u30D6\u306E\u6DFB\u524A\u304C\u53D7\u3051\u3089\u308C\u308B\u3089\u3057\u3044\u3002\u305F\u3081\u3057\u306B\u3061\u3087\u3063\u3068\u4F7F\u3063\u3066\u307F\u3088\u3046\u304B\u306A\u3002http:\/\/lang-8.com\/",
  "id" : 49822926983274497,
  "created_at" : "2011-03-21 13:21:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49820781760360449",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3068\u304D\u3069\u304D\u82F1\u8A9E\u3067\u30C4\u30A4\u30FC\u30C8\u3057\u3066\u307F\u3088\u3046\u304B\u3057\u3089\u30FC\uFF1F",
  "id" : 49820781760360449,
  "created_at" : "2011-03-21 13:12:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49820129772580864",
  "geo" : { },
  "id_str" : "49820656812032000",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3044\u3048\u3044\u3048\u3002\u3053\u3093\u306A\u3053\u3068\u3067\u3088\u3051\u308C\u3070\u3044\u3064\u3067\u3082\u3002",
  "id" : 49820656812032000,
  "in_reply_to_status_id" : 49820129772580864,
  "created_at" : "2011-03-21 13:12:24 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49819945403551744",
  "text" : "\u305D\u30FC\u3044\u3084\u672C\u5C4B\u3067\u300C\u30C4\u30A4\u30C3\u30BF\u2015\u3067\u82F1\u8A9E\u5B66\u7FD2\uFF08\u30AD\u30EA\u30C3\u300D\u898B\u305F\u3044\u306A\u306E\u3092\u898B\u304B\u3051\u305F\u3051\u3069\u3069\u3046\u3084\u3093\u306E\u304B\u306D\u3002\u82F1\u4F5C\u6587\u3082\u3063\u3068\u3067\u304D\u3066\u3082\u640D\u306F\u306A\u3044\u3093\u3060\u3051\u3069\u3002",
  "id" : 49819945403551744,
  "created_at" : "2011-03-21 13:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49818243241750528",
  "geo" : { },
  "id_str" : "49818840095395842",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3068\u306D\u3055\u3093\u3002\u305D\u3046\u3044\u3084\u81EA\u5206\u3082\u6700\u521D\u8AAD\u3081\u306A\u304B\u3063\u305F\u308F\u3002\u914D\u616E\u304C\u8DB3\u3089\u306A\u304F\u3066\u3054\u3081\u3093\u3088\u30FC\u3002",
  "id" : 49818840095395842,
  "in_reply_to_status_id" : 49818243241750528,
  "created_at" : "2011-03-21 13:05:11 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49817969068486656",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3000\u3054\u3081\u3093\u88DC\u8DB3\u3000\u5200\u79B0\u3055\u3093\u306F\u5927\u962A\u6821\u306E\u4EBA\u3060\u304B\u3089\u4EAC\u5927\u30AF\u30E9\u30B9\u3057\u304B\u6301\u3063\u3066\u306A\u3044\u304B\u3082\u77E5\u3089\u3093",
  "id" : 49817969068486656,
  "created_at" : "2011-03-21 13:01:44 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49816909914439680",
  "geo" : { },
  "id_str" : "49817568667635712",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u82F1\u8A9E\u306A\u3089\u5200\u79B0\u3055\u3093\u304B\u5E45\u3055\u3093\u304C\u30AA\u30B9\u30B9\u30E1\u3001\u65E5\u672C\u53F2\u306F\u3088\u3046\u77E5\u3089\u3093\u3051\u3069\u56FD\u8A9E\u3084\u3063\u305F\u3089\u6674\u5C71\u3055\u3093\u304C\u3044\u3044\u611F\u3058\u3002\u53E4\u6587\u306A\u3089\u6C60\u7530\u4FEE\u306A\u3093\u3068\u304B\u3001\u6F22\u6587\u306A\u3089\u4E09\u68EE\u3055\u3093\u3002\uFF54\uFF4B\u4FFA\u304C\u7FD2\u3063\u305F\u4EBA\u3005\u3060\u3051\u3069\u3002",
  "id" : 49817568667635712,
  "in_reply_to_status_id" : 49816909914439680,
  "created_at" : "2011-03-21 13:00:08 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49816343993778176",
  "geo" : { },
  "id_str" : "49816848887324673",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306A\u3093\u3067\u305D\u3093\u306A\u306B\u65E9\u8D77\u304D\u3092\uFF1F",
  "id" : 49816848887324673,
  "in_reply_to_status_id" : 49816343993778176,
  "created_at" : "2011-03-21 12:57:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49814573963952128",
  "text" : "\u590F\u306F\u3046\u3060\u3046\u3060\u3001\u79CB\u306F\u7761\u7720\u306E\u79CB\u3001\u51AC\u306F\u51AC\u7720\u3002\u7D20\u6674\u3089\u3057\u304D\u65E5\u672C\u306E\u56DB\u5B63\u3002",
  "id" : 49814573963952128,
  "created_at" : "2011-03-21 12:48:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49813809677860864",
  "text" : "\u6625\u7720\u6681\u3092\u899A\u3048\u305A",
  "id" : 49813809677860864,
  "created_at" : "2011-03-21 12:45:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49801073585700864",
  "text" : "\u3084\u3063\u3071\u30B8\u30F3\u30B8\u30E3\u30FC\u30A8\u30FC\u30EB\u306F\u8F9B\u53E3\u306B\u9650\u308B\u3002",
  "id" : 49801073585700864,
  "created_at" : "2011-03-21 11:54:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49799982798221313",
  "geo" : { },
  "id_str" : "49800684828237824",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3044\u3084\u30014\u6708\u304B\u3089\u306E\u7A7A\u6C17\u3067\u3059\u3002\u307E\u3060\u6587\u91CE\u5148\u8F29\u3068\u304B\u6771\u4EAC\u3089\u3057\u3044\u3067\u3059\u3057\u3002",
  "id" : 49800684828237824,
  "in_reply_to_status_id" : 49799982798221313,
  "created_at" : "2011-03-21 11:53:03 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49799051524325376",
  "geo" : { },
  "id_str" : "49799455142191104",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3093\u30FC\u307E\u3060\u7686\u3055\u3093\u306E\u6642\u9593\u5272\u3068\u304B\u78BA\u5B9A\u3057\u3066\u306A\u3044\u3093\u3067\u305D\u308C\u898B\u3066\u6C7A\u3081\u306A\u304A\u3059\u611F\u3058\u3067\u3059\u304B\u306D\u3002\u5F53\u9762\u306F\u4ECA\u307E\u3067\u901A\u308A\u3067\u3002",
  "id" : 49799455142191104,
  "in_reply_to_status_id" : 49799051524325376,
  "created_at" : "2011-03-21 11:48:09 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49444546651750400",
  "geo" : { },
  "id_str" : "49798769075699712",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u304A\u59C9\u3055\u3093\u30A2\u30AB\u30A6\u30F3\u30C8\u4F5C\u308A\u306A\u304A\u3057\u307E\u3057\u305F\uFF1F",
  "id" : 49798769075699712,
  "in_reply_to_status_id" : 49444546651750400,
  "created_at" : "2011-03-21 11:45:26 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49796393728094208",
  "geo" : { },
  "id_str" : "49797424214052864",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4ECA\u898B\u307E\u3059\uFF57\u898B\u3066\u306A\u304B\u3063\u305F\uFF57",
  "id" : 49797424214052864,
  "in_reply_to_status_id" : 49796393728094208,
  "created_at" : "2011-03-21 11:40:05 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49796234000609281",
  "text" : "\u30E2\u30B9\u30B3\u30DF\u30E5\u30FC\u30EB\u3063\u3066\u30E2\u30B9\u30B3\u30FB\u30DF\u30E5\u30FC\u30EB\u306A\u306E\u306D\uFF57",
  "id" : 49796234000609281,
  "created_at" : "2011-03-21 11:35:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49792813063356416",
  "text" : "RT @galletti_bot: \u795E\u5B98\u305F\u308B\u3082\u306E\u3001\u6B7B\u4EBA\u3068\u51FA\u4F1A\u3048\u3070\u57CB\u846C\u306E\u3068\u3082\u3092\u3059\u308B\u7FA9\u52D9\u304C\u3042\u3063\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49791620656275456",
    "text" : "\u795E\u5B98\u305F\u308B\u3082\u306E\u3001\u6B7B\u4EBA\u3068\u51FA\u4F1A\u3048\u3070\u57CB\u846C\u306E\u3068\u3082\u3092\u3059\u308B\u7FA9\u52D9\u304C\u3042\u3063\u305F\u3002",
    "id" : 49791620656275456,
    "created_at" : "2011-03-21 11:17:02 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 49792813063356416,
  "created_at" : "2011-03-21 11:21:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49658165637287936",
  "text" : "RT @tameninaru: \u65E5\u672C\u3059\u3044\u304B\u5272\u308A\u5354\u4F1A\u306B\u3088\u308B\u3068\u3001\u3059\u3044\u304B\u5272\u308A\u306F\u300C\u68D2\u306E\u9577\u3055\u306F1.2m\u4EE5\u5185\u3001\u3059\u3044\u304B\u3068\u306E\u8DDD\u96E2\u306F9.15m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49485366339706881",
    "text" : "\u65E5\u672C\u3059\u3044\u304B\u5272\u308A\u5354\u4F1A\u306B\u3088\u308B\u3068\u3001\u3059\u3044\u304B\u5272\u308A\u306F\u300C\u68D2\u306E\u9577\u3055\u306F1.2m\u4EE5\u5185\u3001\u3059\u3044\u304B\u3068\u306E\u8DDD\u96E2\u306F9.15m",
    "id" : 49485366339706881,
    "created_at" : "2011-03-20 15:00:05 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 49658165637287936,
  "created_at" : "2011-03-21 02:26:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "\u25C6jW0G5w",
      "screen_name" : "LesVanillaIce",
      "indices" : [ 35, 49 ],
      "id_str" : "15621879",
      "id" : 15621879
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 51, 58 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49379821955973120",
  "text" : "RT @NHK_PR: N=\u30CA\u30AB\u30CE\u3000H=\u30D2\u30C8\u30CA\u30C9\u3000K=\u30A4\u30CA\u30A4  RT @lesvanillaice: @NHK_PR \u3058\u3083NHK\u3063\u3066\u4F55\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u25C6jW0G5w",
        "screen_name" : "LesVanillaIce",
        "indices" : [ 23, 37 ],
        "id_str" : "15621879",
        "id" : 15621879
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 39, 46 ],
        "id_str" : "93311525",
        "id" : 93311525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49379343020990465",
    "text" : "N=\u30CA\u30AB\u30CE\u3000H=\u30D2\u30C8\u30CA\u30C9\u3000K=\u30A4\u30CA\u30A4  RT @lesvanillaice: @NHK_PR \u3058\u3083NHK\u3063\u3066\u4F55\uFF1F",
    "id" : 49379343020990465,
    "created_at" : "2011-03-20 07:58:47 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 49379821955973120,
  "created_at" : "2011-03-20 08:00:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49276335415246848",
  "text" : "\u3093\u30FC\u6628\u65E5\u306E\u591C\u85AC\u98F2\u307F\u5FD8\u308C\u305F\u304B\u30FC\u3002\u9F3B\u3068\u76EE\u3068\u3061\u3087\u3063\u3068\u3064\u3089\u3044\u3002",
  "id" : 49276335415246848,
  "created_at" : "2011-03-20 01:09:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49078035898580992",
  "text" : "\u3067\u3082\u50B7\u306F\u697D\u3057\u307F\u3002",
  "id" : 49078035898580992,
  "created_at" : "2011-03-19 12:01:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49077957163089920",
  "text" : "\u8CDE\u5473\u30AD\u30B9\u30B7\u30E7\u30C3\u30C8\u3082\u4E0D\u5B89\u3002\u5FCD\u306F\u826F\u3044\u306B\u3057\u3066\u3082\u30AD\u30B9\u30B7\u30E7\u30C3\u30C8\u306F\u30FB\u30FB\u30FB",
  "id" : 49077957163089920,
  "created_at" : "2011-03-19 12:01:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49077736962142208",
  "text" : "\u4F70\u7269\u8A9E\u805E\u3044\u3066\u307F\u305F\u3002\u3068\u308A\u3048\u305A\u6708\u706B\u3061\u3083\u3093\u306E\u4E2D\u306E\u4EBA\u306B\u7D0D\u5F97\u304C\u3044\u304B\u306A\u3044\u3002",
  "id" : 49077736962142208,
  "created_at" : "2011-03-19 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49076957920497664",
  "text" : "@koketomi \u3046\u3061\u306F\u30D3\u30FC\u30EB\u51B7\u3048\u3066\u308B\u305E\uFF57\uFF57",
  "id" : 49076957920497664,
  "created_at" : "2011-03-19 11:57:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49067255367081984",
  "text" : "RT @Kaibun_bot: \u6570\u5B66\u3068\u7406\u79D1\u3070\u304B\u308A\u89E3\u304F\u30AC\u30A6\u30B9\u3000\uFF08\u3059\u3046\u304C\u304F\u3068\u308A\u304B\u3070\u304B\u308A\u3068\u304F\u304C\u3046\u3059\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 32, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49066634157101056",
    "text" : "\u6570\u5B66\u3068\u7406\u79D1\u3070\u304B\u308A\u89E3\u304F\u30AC\u30A6\u30B9\u3000\uFF08\u3059\u3046\u304C\u304F\u3068\u308A\u304B\u3070\u304B\u308A\u3068\u304F\u304C\u3046\u3059\uFF09 #kaibun",
    "id" : 49066634157101056,
    "created_at" : "2011-03-19 11:16:11 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 49067255367081984,
  "created_at" : "2011-03-19 11:18:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49022424095793152",
  "text" : "\u5BDD\u306A\u3044\u305E\u30FC",
  "id" : 49022424095793152,
  "created_at" : "2011-03-19 08:20:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49022376687570944",
  "text" : "\u307E\u305A\u3044\u6628\u65E5\u3068\u540C\u3058\u3088\u3046\u306A\u7720\u6C17\u304C\u30FB\u30FB\u30FB\u3002\u30C7\u30B8\u30E3\u30F4\u30E5\u2026\u3002",
  "id" : 49022376687570944,
  "created_at" : "2011-03-19 08:20:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30F3\u30B5\u30A4\u30AF\u30ED\u30DA\u30C7\u30A3\u30A2BOT\u65E5\u672C\u8A9E\u7248",
      "screen_name" : "AnsaiBot",
      "indices" : [ 3, 12 ],
      "id_str" : "72766956",
      "id" : 72766956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48700190361796608",
  "text" : "RT @AnsaiBot: \u30D3\u30EA\u30E4\u30FC\u30C9 http:\/\/bit.ly\/hZU6lI \u30D3\u30EA\u30E4\u30FC\u30C9\u3068\u306F\u7269\u7406\u5B66\u3001\u53CA\u3073\u529B\u5B66\u3092\u6975\u3081\u305F\u8005\u304C\u8003\u6848\u3057\u305F\u30B9\u30DD\u30FC\u30C4\u3067\u3042\u308B\u3002\u30D3\u30EA\u30E4\u30FC\u30C9\u306B\u306F\u3044\u304F\u3064\u304B\u5F62\u5F0F\u304C\u3042\u308B\u304C\u3044\u305A\u308C\u3082\u8907\u96D1\u3067\u3001\u30EF\u30F3\u30B2\u30FC\u30E0\u884C\u3046\u305F\u3081\u306B\u5FC5\u8981\u306A\u77E5\u8B58\u3060\u3051\u3067\u3082\u9AD8\u6821\u7269\u7406\u5B66\u6559\u5E2B\u7A0B\u5EA6\u306E\u77E5\u8B58\u91CF\u304C\u5FC5\u8981\u3067\u3042\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/mohayonao\/mohayonao-bot\" rel=\"nofollow\"\u003Emohayonao-bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48693067728949248",
    "text" : "\u30D3\u30EA\u30E4\u30FC\u30C9 http:\/\/bit.ly\/hZU6lI \u30D3\u30EA\u30E4\u30FC\u30C9\u3068\u306F\u7269\u7406\u5B66\u3001\u53CA\u3073\u529B\u5B66\u3092\u6975\u3081\u305F\u8005\u304C\u8003\u6848\u3057\u305F\u30B9\u30DD\u30FC\u30C4\u3067\u3042\u308B\u3002\u30D3\u30EA\u30E4\u30FC\u30C9\u306B\u306F\u3044\u304F\u3064\u304B\u5F62\u5F0F\u304C\u3042\u308B\u304C\u3044\u305A\u308C\u3082\u8907\u96D1\u3067\u3001\u30EF\u30F3\u30B2\u30FC\u30E0\u884C\u3046\u305F\u3081\u306B\u5FC5\u8981\u306A\u77E5\u8B58\u3060\u3051\u3067\u3082\u9AD8\u6821\u7269\u7406\u5B66\u6559\u5E2B\u7A0B\u5EA6\u306E\u77E5\u8B58\u91CF\u304C\u5FC5\u8981\u3067\u3042\u308B\u3002",
    "id" : 48693067728949248,
    "created_at" : "2011-03-18 10:31:46 +0000",
    "user" : {
      "name" : "\u30A2\u30F3\u30B5\u30A4\u30AF\u30ED\u30DA\u30C7\u30A3\u30A2BOT\u65E5\u672C\u8A9E\u7248",
      "screen_name" : "AnsaiBot",
      "protected" : false,
      "id_str" : "72766956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2154714127\/AnsaiBot_normal.png",
      "id" : 72766956,
      "verified" : false
    }
  },
  "id" : 48700190361796608,
  "created_at" : "2011-03-18 11:00:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48687299252330496",
  "text" : "\u70AC\u71F5\u3067\u539F\u56E0\u4E0D\u660E\u306E\u7720\u6C17\u306B\u8972\u308F\u308C\u306690\u5206\u307B\u3069\u5BDD\u3066\u3057\u307E\u3063\u305F\u3002",
  "id" : 48687299252330496,
  "created_at" : "2011-03-18 10:08:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48568886790066176",
  "text" : "RT @Kaibun_bot: \u300C\u9C3B\u3001\u30B9\u30A4\u30AB\u3001\u80E1\u9EBB\u3001\u30BF\u30B3\u3001\u30BF\u30DE\u30B4\u2026\u8CB7\u3044\u904E\u304E\u306A\u3046\uFF01\u300D\u3000(\u3046\u306A\u304E\u3059\u3044\u304B\u3054\u307E\u305F\u3053\u305F\u307E\u3054\u304B\u3044\u3059\u304E\u306A\u3046) #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48568280780259329",
    "text" : "\u300C\u9C3B\u3001\u30B9\u30A4\u30AB\u3001\u80E1\u9EBB\u3001\u30BF\u30B3\u3001\u30BF\u30DE\u30B4\u2026\u8CB7\u3044\u904E\u304E\u306A\u3046\uFF01\u300D\u3000(\u3046\u306A\u304E\u3059\u3044\u304B\u3054\u307E\u305F\u3053\u305F\u307E\u3054\u304B\u3044\u3059\u304E\u306A\u3046) #kaibun",
    "id" : 48568280780259329,
    "created_at" : "2011-03-18 02:15:55 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 48568886790066176,
  "created_at" : "2011-03-18 02:18:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48407435190349824",
  "text" : "\u5BDD\u308B\u304B\u306A\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 48407435190349824,
  "created_at" : "2011-03-17 15:36:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48405502757052416",
  "geo" : { },
  "id_str" : "48405834421649409",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 Yahoo\u77E5\u6075\u888B\u3067\u7B54\u3048\u805E\u304F\u3057\u304B\u306A\u3044\u306A\uFF57\uFF57\uFF57",
  "id" : 48405834421649409,
  "in_reply_to_status_id" : 48405502757052416,
  "created_at" : "2011-03-17 15:30:24 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48404153923403776",
  "geo" : { },
  "id_str" : "48404998081613824",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6388\u696D\u306A\u3046\u30FC\u3063\u3066\u306D\uFF57\uFF57",
  "id" : 48404998081613824,
  "in_reply_to_status_id" : 48404153923403776,
  "created_at" : "2011-03-17 15:27:05 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48403438031212545",
  "text" : "\u3042\u305D\u3076\u3093\u5B66\u90E8\u3058\u3083\u53B3\u3057\u3044\u3088\u306D\u3002\u3046\u3093\u3002",
  "id" : 48403438031212545,
  "created_at" : "2011-03-17 15:20:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48403242874437632",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u65B0\u520A\u51FA\u3066\u308B\u306E\u304B\u30FC\u3002\u6B32\u3057\u3044\u306A\u3002\u3042\u3093\u306A\u540C\u7D1A\u751F\u3084\u3089\u5F8C\u8F29\u304C\u307B\u3057\u3044\u3082\u306E\u3067\u3059\u3002\u7537\u5973\u554F\u308F\u305A\u3002",
  "id" : 48403242874437632,
  "created_at" : "2011-03-17 15:20:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48402113121878016",
  "text" : "\u3042\u306A\u305F\u306F\u3000\u30B3\u30F3\u30C6\u30A3\u30CB\u30E5\u30FC\u3000\u3067\u304D\u306A\u3044\u306E\u3055\uFF01",
  "id" : 48402113121878016,
  "created_at" : "2011-03-17 15:15:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48402020373245952",
  "text" : "\u5E30\u3063\u3066\u304D\u305F\u65E5\u306F\u6E29\u304B\u304B\u3063\u305F\u306E\u306B\u3001\u6628\u65E5\u304A\u3068\u3068\u3044\u3068\u96EA\u3063\u3066\u306A\u3093\u306A\u306E\u3055\u3002",
  "id" : 48402020373245952,
  "created_at" : "2011-03-17 15:15:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48401472920100864",
  "text" : "\u30D0\u30A4\u30C8\u304C\u3042\u308B\u3068\u751F\u6D3B\u30EA\u30BA\u30E0\u304C\u5D29\u308C\u308B\u3063\u3066\u3069\u3046\u306A\u306E\u3055\u3002",
  "id" : 48401472920100864,
  "created_at" : "2011-03-17 15:13:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3055\u3089\u304E",
      "screen_name" : "kisaragi24",
      "indices" : [ 3, 14 ],
      "id_str" : "63324952",
      "id" : 63324952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48260956412841984",
  "text" : "RT @kisaragi24: \u300C\u4FFA\u304C\u300D\u3063\u3066\u3044\u3046\u3068\n\u300C\u4FFA\u304C\u300D\u3063\u3066\u3044\u3046\u3002\n\n\u300C\u4FFA\u3082\u300D\u3063\u3066\u3044\u3046\u3068\n\u300C\u4FFA\u3082\u300D\u3063\u3066\u3044\u3046\u3002\n\n\u305D\u3046\u3057\u3066\u3001\u3042\u3068\u3067\n\u3055\u307F\u3057\u304F\u306A\u3063\u3066\u3001\n\n\u300C\u3058\u3083\u3001\u4FFA\u304C\u300D\u3063\u3066\u3044\u3046\u3068\n\u300C\u3069\u3046\u305E\u3001\u3069\u3046\u305E\u300D\u3063\u3066\u3044\u3046\u3002\n\n\u3053\u3060\u307E\u3067\u3057\u3087\u3046\u304B\u3001\n\u3044\u3044\u3048\u3001\u4E0A\u5CF6\u3067\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48217547249684480",
    "text" : "\u300C\u4FFA\u304C\u300D\u3063\u3066\u3044\u3046\u3068\n\u300C\u4FFA\u304C\u300D\u3063\u3066\u3044\u3046\u3002\n\n\u300C\u4FFA\u3082\u300D\u3063\u3066\u3044\u3046\u3068\n\u300C\u4FFA\u3082\u300D\u3063\u3066\u3044\u3046\u3002\n\n\u305D\u3046\u3057\u3066\u3001\u3042\u3068\u3067\n\u3055\u307F\u3057\u304F\u306A\u3063\u3066\u3001\n\n\u300C\u3058\u3083\u3001\u4FFA\u304C\u300D\u3063\u3066\u3044\u3046\u3068\n\u300C\u3069\u3046\u305E\u3001\u3069\u3046\u305E\u300D\u3063\u3066\u3044\u3046\u3002\n\n\u3053\u3060\u307E\u3067\u3057\u3087\u3046\u304B\u3001\n\u3044\u3044\u3048\u3001\u4E0A\u5CF6\u3067\u3059\u3002",
    "id" : 48217547249684480,
    "created_at" : "2011-03-17 03:02:13 +0000",
    "user" : {
      "name" : "\u304D\u3055\u3089\u304E",
      "screen_name" : "kisaragi24",
      "protected" : false,
      "id_str" : "63324952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3766244007\/1d4271d49de50ac73be0cafecb908e75_normal.jpeg",
      "id" : 63324952,
      "verified" : false
    }
  },
  "id" : 48260956412841984,
  "created_at" : "2011-03-17 05:54:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48229893963661312",
  "text" : "RT @NHK_PR: N=\u30CA\u30AB\u30CE\u3000H=\u30D2\u30C8\u30CA\u30C9\u3000K=\u30A4\u30CA\u30A4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48226988611207168",
    "text" : "N=\u30CA\u30AB\u30CE\u3000H=\u30D2\u30C8\u30CA\u30C9\u3000K=\u30A4\u30CA\u30A4",
    "id" : 48226988611207168,
    "created_at" : "2011-03-17 03:39:44 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 48229893963661312,
  "created_at" : "2011-03-17 03:51:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "indices" : [ 3, 12 ],
      "id_str" : "161910608",
      "id" : 161910608
    }, {
      "name" : "kosuke",
      "screen_name" : "kosuke_nc",
      "indices" : [ 49, 59 ],
      "id_str" : "113835509",
      "id" : 113835509
    }, {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "indices" : [ 61, 70 ],
      "id_str" : "161910608",
      "id" : 161910608
    }, {
      "name" : "\u4E09\u68EE\u3059\u305A\u3053 4\/8 2nd\u30A2\u30EB\u30D0\u30E0\u767A\u58F2\uFF01",
      "screen_name" : "mimori_suzuko",
      "indices" : [ 71, 85 ],
      "id_str" : "114700374",
      "id" : 114700374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48034963324534784",
  "text" : "RT @izugyoza: \u306A\uFF01\u51C4\u3044\uFF014\u4EBA\u4E26\u3076\u3068\u30EA\u30EA\u2026\u30EA\u30EA\u30FC\u2026\u2026\u767E\u5408\uFF01\uFF01\u611F\u52D5\u3057\u305F(\u309C\u25BD\u309C) RT @kosuke_nc: @izugyoza @mimori_suzuko \u3044\u3064\u305E\u3084\u306E\u5199\u771F\u306E\u3088\u3046\u306B\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA\u306E\u56DB\u4EBA\u3067\u5DDD\u2026\u3058\u3083\u306A\u3044\u30E6\u30EA\u2026\u3067\u3082\u306A\u3044\u3001\u30EA\u30EA\u306E\u5B57\u306B\u306A\u3063\u3066\u3059\u3084\u3059\u3084\u3068 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kosuke",
        "screen_name" : "kosuke_nc",
        "indices" : [ 35, 45 ],
        "id_str" : "113835509",
        "id" : 113835509
      }, {
        "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
        "screen_name" : "izugyoza",
        "indices" : [ 47, 56 ],
        "id_str" : "161910608",
        "id" : 161910608
      }, {
        "name" : "\u4E09\u68EE\u3059\u305A\u3053 4\/8 2nd\u30A2\u30EB\u30D0\u30E0\u767A\u58F2\uFF01",
        "screen_name" : "mimori_suzuko",
        "indices" : [ 57, 71 ],
        "id_str" : "114700374",
        "id" : 114700374
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48033631347818496",
    "text" : "\u306A\uFF01\u51C4\u3044\uFF014\u4EBA\u4E26\u3076\u3068\u30EA\u30EA\u2026\u30EA\u30EA\u30FC\u2026\u2026\u767E\u5408\uFF01\uFF01\u611F\u52D5\u3057\u305F(\u309C\u25BD\u309C) RT @kosuke_nc: @izugyoza @mimori_suzuko \u3044\u3064\u305E\u3084\u306E\u5199\u771F\u306E\u3088\u3046\u306B\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA\u306E\u56DB\u4EBA\u3067\u5DDD\u2026\u3058\u3083\u306A\u3044\u30E6\u30EA\u2026\u3067\u3082\u306A\u3044\u3001\u30EA\u30EA\u306E\u5B57\u306B\u306A\u3063\u3066\u3059\u3084\u3059\u3084\u3068\u304A\u3084\u3059\u307F\u306B\u306A\u3063\u3066\u3044\u308B\u56F3\u3092\u60F3\u50CF\u3057\u307E\u3057\u305F",
    "id" : 48033631347818496,
    "created_at" : "2011-03-16 14:51:24 +0000",
    "user" : {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "protected" : false,
      "id_str" : "161910608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607820959492370432\/IgL617FR_normal.png",
      "id" : 161910608,
      "verified" : false
    }
  },
  "id" : 48034963324534784,
  "created_at" : "2011-03-16 14:56:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48030122707656704",
  "geo" : { },
  "id_str" : "48030647293448192",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5185\u51FA\u8840\u304B\u3002\u306F\u3055\u3093\u3060\u308A\u3059\u308B\u3068\u306A\u308B\u306D\u3002\u3068\u3066\u3082\u75DB\u304B\u3063\u305F\u8A18\u61B6\u304C\u3002\u3002\u3002\u304A\u5927\u4E8B\u306B\u3002",
  "id" : 48030647293448192,
  "in_reply_to_status_id" : 48030122707656704,
  "created_at" : "2011-03-16 14:39:33 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48017341400887296",
  "text" : "\u30CA\u30DE\u30BA\u4ED5\u4E8B\u3057\u3059\u304E\u3060\u3088\u306D\u3002\u3046\u3093\u3002",
  "id" : 48017341400887296,
  "created_at" : "2011-03-16 13:46:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48017189118296064",
  "text" : "\u6709\u9802\u5929\u5909\u2026\u8981\u77F3\u3092\u6253\u3061\u8FBC\u307F\u307E\u3057\u3087\u3046\u3002",
  "id" : 48017189118296064,
  "created_at" : "2011-03-16 13:46:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47816406120665089",
  "text" : "\u6625\u3046\u3089\u3089\u3001\u3068\u306F\u884C\u304B\u306A\u3055\u305D\u3046\u306A\u6C17\u6E29\u2026\u3002\u65E9\u8D77\u304D\u306E\u7FD2\u6163\u306F\u88CF\u76EE\u306B\u51FA\u3066\u308B\u304B\u306A\u3002",
  "id" : 47816406120665089,
  "created_at" : "2011-03-16 00:28:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47800506818633729",
  "text" : "RT @Kaibun_bot: \u624B\u4F1D\u3046\u3088\u3000\u4F55\u5EA6\u3082\u3000\u3069\u3093\u306A\u7528\u3060\u3063\u3066\u3000\uFF08\u3066\u3064\u3060\u3046\u3088\u306A\u3093\u3069\u3082\u3069\u3093\u306A\u3088\u3046\u3060\u3064\u3066\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 37, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47798249939156992",
    "text" : "\u624B\u4F1D\u3046\u3088\u3000\u4F55\u5EA6\u3082\u3000\u3069\u3093\u306A\u7528\u3060\u3063\u3066\u3000\uFF08\u3066\u3064\u3060\u3046\u3088\u306A\u3093\u3069\u3082\u3069\u3093\u306A\u3088\u3046\u3060\u3064\u3066\uFF09 #kaibun",
    "id" : 47798249939156992,
    "created_at" : "2011-03-15 23:16:05 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 47800506818633729,
  "created_at" : "2011-03-15 23:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30B5\u30AB\u4E00\u56DB\u56DB\u56DB\u56DB\u53F7",
      "screen_name" : "misaka_14444_no",
      "indices" : [ 3, 19 ],
      "id_str" : "160826189",
      "id" : 160826189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47798065276534784",
  "text" : "RT @misaka_14444_no: \u65E5\u672C\u30E6\u30CB\u30BB\u30D5\u306EURL\u3092\u30AF\u30EA\u30C3\u30AF\u3057\u305F\u3089\u3001\u300C\u8B66\u544A\uFF01\uFF1A\u8A55\u4FA1\u306E\u4F4E\u3044\u30B5\u30A4\u30C8\u3067\u3059\u3002\u4FE1\u983C\u6027\uFF1A\u60AA\u3044\u300D\u3068\u51FA\u307E\u3057\u305F\u3001\u3055\u3059\u304C\u706B\u72D0\u3055\u3093\u3067\u3059\u306D\u3001\u3068\u30DF\u30B5\u30AB\u306F\u95A2\u5FC3\u3057\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47674699483840513",
    "text" : "\u65E5\u672C\u30E6\u30CB\u30BB\u30D5\u306EURL\u3092\u30AF\u30EA\u30C3\u30AF\u3057\u305F\u3089\u3001\u300C\u8B66\u544A\uFF01\uFF1A\u8A55\u4FA1\u306E\u4F4E\u3044\u30B5\u30A4\u30C8\u3067\u3059\u3002\u4FE1\u983C\u6027\uFF1A\u60AA\u3044\u300D\u3068\u51FA\u307E\u3057\u305F\u3001\u3055\u3059\u304C\u706B\u72D0\u3055\u3093\u3067\u3059\u306D\u3001\u3068\u30DF\u30B5\u30AB\u306F\u95A2\u5FC3\u3057\u307E\u3059\u3002",
    "id" : 47674699483840513,
    "created_at" : "2011-03-15 15:05:08 +0000",
    "user" : {
      "name" : "\u30DF\u30B5\u30AB\u4E00\u56DB\u56DB\u56DB\u56DB\u53F7",
      "screen_name" : "misaka_14444_no",
      "protected" : false,
      "id_str" : "160826189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3022759737\/f7f7fdd1e52e9816c704681a04064fca_normal.gif",
      "id" : 160826189,
      "verified" : false
    }
  },
  "id" : 47798065276534784,
  "created_at" : "2011-03-15 23:15:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u007B\u767D,\u9ED2\u007D\u306E\u30AB\u30D4\u30D0\u30E9\u306E\u5DE6\u968F\u4F34\u53F3\u968F\u4F34",
      "screen_name" : "ainsophyao",
      "indices" : [ 3, 14 ],
      "id_str" : "111618734",
      "id" : 111618734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47792779291668481",
  "text" : "RT @ainsophyao: \u5C11\u3057\u524D\u306B\u3001\u5FAE\u7A4D\u5206\u3092\u6559\u3048\u3066\u3082\u4ED5\u65B9\u306A\u3044\u3001\u547D\u306B\u95A2\u308F\u308B\u5206\u5B50\u751F\u7269\u5B66\u3092\u6559\u3048\u308D\u3068\u4E3B\u5F35\u3057\u305F\u6771\u4EAC\u5973\u5B50\u533B\u306E\u5148\u751F\u304C\u3001\u73FE\u5728\u3001\u653E\u5C04\u7DDA\u91CF\u306E\u7A4D\u5206\u304C\u3067\u304D\u306C\u305F\u3081\u306B\u751F\u547D\u306E\u5371\u6A5F\u306B\u3055\u3089\u3055\u308C\u3066\u3044\u308B\u3053\u3068\u3092\u5973\u5B66\u751F\u3068\u5171\u306B\u751A\u3060\u907A\u61BE\u306B\u601D\u3063\u3066\u3044\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47562456964399104",
    "text" : "\u5C11\u3057\u524D\u306B\u3001\u5FAE\u7A4D\u5206\u3092\u6559\u3048\u3066\u3082\u4ED5\u65B9\u306A\u3044\u3001\u547D\u306B\u95A2\u308F\u308B\u5206\u5B50\u751F\u7269\u5B66\u3092\u6559\u3048\u308D\u3068\u4E3B\u5F35\u3057\u305F\u6771\u4EAC\u5973\u5B50\u533B\u306E\u5148\u751F\u304C\u3001\u73FE\u5728\u3001\u653E\u5C04\u7DDA\u91CF\u306E\u7A4D\u5206\u304C\u3067\u304D\u306C\u305F\u3081\u306B\u751F\u547D\u306E\u5371\u6A5F\u306B\u3055\u3089\u3055\u308C\u3066\u3044\u308B\u3053\u3068\u3092\u5973\u5B66\u751F\u3068\u5171\u306B\u751A\u3060\u907A\u61BE\u306B\u601D\u3063\u3066\u3044\u308B\u3002",
    "id" : 47562456964399104,
    "created_at" : "2011-03-15 07:39:08 +0000",
    "user" : {
      "name" : "\u007B\u767D,\u9ED2\u007D\u306E\u30AB\u30D4\u30D0\u30E9\u306E\u5DE6\u968F\u4F34\u53F3\u968F\u4F34",
      "screen_name" : "ainsophyao",
      "protected" : false,
      "id_str" : "111618734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943744194\/_960_960_normal.JPG",
      "id" : 111618734,
      "verified" : false
    }
  },
  "id" : 47792779291668481,
  "created_at" : "2011-03-15 22:54:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30F3\u30E1\u30EB\uFF20\u9019\u3044\u3088\u308BKGB",
      "screen_name" : "Hal_Rommel",
      "indices" : [ 3, 14 ],
      "id_str" : "87667618",
      "id" : 87667618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47649967833235456",
  "text" : "RT @Hal_Rommel: \u65B0\u305F\u306A\u5358\u4F4D\u3092\u8003\u3048\u305F\u3002\u9023\u7D9A\u8D77\u5E8A\u6642\u9593\u306E\u5358\u4F4D\u3060\u3002\u3053\u308C\u306F\u300C\u679D\u91CE\u300D\u3067\u8868\u3057\u3001\u8A18\u53F7\u306FE\u3067\u8868\u8A18\u3059\u308B\u3002\u3002\u7528\u4F8B\u3068\u3057\u3066\u306F\u300C\u3048\u30FC\u30DE\u30B8\u3084\u3070\u3044\u306A\u30FC\u4FFA\u4ECA\u65E55\u679D\u91CE\u3060\u3088\u30FC\uFF57\uFF57\uFF57\uFF57\u300D\u300C\u304A\u524D\u306A\u3093\u3066\u304B\u308F\u3044\u3044\u65B9\u3060\u3063\u3066\u4FFA\u306A\u3093\u30668\u679D\u91CE\u3060\u305C\u30FC\uFF57\uFF57\uFF57\uFF57\u300D\u3000\u306A\u3069\u306E\u3088\u3046\u306B\u4F7F\u7528\u3059\u308B\u30021\u679D\u91CE\uFF1D4\u6642 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47639973100388352",
    "text" : "\u65B0\u305F\u306A\u5358\u4F4D\u3092\u8003\u3048\u305F\u3002\u9023\u7D9A\u8D77\u5E8A\u6642\u9593\u306E\u5358\u4F4D\u3060\u3002\u3053\u308C\u306F\u300C\u679D\u91CE\u300D\u3067\u8868\u3057\u3001\u8A18\u53F7\u306FE\u3067\u8868\u8A18\u3059\u308B\u3002\u3002\u7528\u4F8B\u3068\u3057\u3066\u306F\u300C\u3048\u30FC\u30DE\u30B8\u3084\u3070\u3044\u306A\u30FC\u4FFA\u4ECA\u65E55\u679D\u91CE\u3060\u3088\u30FC\uFF57\uFF57\uFF57\uFF57\u300D\u300C\u304A\u524D\u306A\u3093\u3066\u304B\u308F\u3044\u3044\u65B9\u3060\u3063\u3066\u4FFA\u306A\u3093\u30668\u679D\u91CE\u3060\u305C\u30FC\uFF57\uFF57\uFF57\uFF57\u300D\u3000\u306A\u3069\u306E\u3088\u3046\u306B\u4F7F\u7528\u3059\u308B\u30021\u679D\u91CE\uFF1D4\u6642\u9593\u9023\u7D9A\u8D77\u5E8A\u3067\u3042\u308B\u3002",
    "id" : 47639973100388352,
    "created_at" : "2011-03-15 12:47:09 +0000",
    "user" : {
      "name" : "\u30ED\u30F3\u30E1\u30EB\uFF20\u9019\u3044\u3088\u308BKGB",
      "screen_name" : "Hal_Rommel",
      "protected" : false,
      "id_str" : "87667618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519518050643496960\/XTGODCuG_normal.jpeg",
      "id" : 87667618,
      "verified" : false
    }
  },
  "id" : 47649967833235456,
  "created_at" : "2011-03-15 13:26:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47637601175339008",
  "text" : "\u6771\u4EAC\u4E00\u90E8\u505C\u96FB\u3057\u3066\u305F\u3093\u304B\u306D\u3002\u9003\u3052\u5207\u3063\u305F\uFF08\uFF1F\uFF09\u304B\uFF1F",
  "id" : 47637601175339008,
  "created_at" : "2011-03-15 12:37:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47637226489790464",
  "text" : "\u3042\u308C\u3001\u3082\u304621\u6642\u307E\u308F\u3063\u3066\u308B\u306E\u304B\u30FC\u3002",
  "id" : 47637226489790464,
  "created_at" : "2011-03-15 12:36:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47636983429861377",
  "text" : "\u306A\u3093\u304B\u3044\u308D\u3044\u308Dbot\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u307F\u305F\u3002\u56DE\u6587bot\u3068\u304B\u30C4\u30DC\u3060\u3063\u305F\u3002",
  "id" : 47636983429861377,
  "created_at" : "2011-03-15 12:35:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47623633694228480",
  "text" : "\u5730\u4E2D\u6D77\u306E\u5CF6\u3005\u306F\u3059\u3079\u3066\u30B7\u30C1\u30EA\u30A2\u5CF6\u3088\u308A\u3082\u5927\u304D\u3044\u304B\u3001\u3042\u308B\u3044\u306F\u5C0F\u3055\u3044\u304B\u306E\u3069\u3061\u3089\u304B\u3067\u3059\u3002",
  "id" : 47623633694228480,
  "created_at" : "2011-03-15 11:42:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "\u305F\u307E\u82E5\u982D\/\u3084\u3055\u3057\u3044\u30DE\u30C3\u30B9\u30B0\u30DE",
      "screen_name" : "tamawakagashira",
      "indices" : [ 26, 42 ],
      "id_str" : "185651192",
      "id" : 185651192
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 44, 51 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47547892126326784",
  "text" : "RT @NHK_PR: \u5927\u4E08\u592B\u3060\u3001\u554F\u984C\u306A\u3044\u3002 RT @tamawakagashira: @NHK_PR \u305D\u306E\u8A9E\u5C3E\u306F\u826F\u3044\u3093\u3067\u3059\u304B\u3001NHK\u7684\u306B\uFF57\uFF57\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u305F\u307E\u82E5\u982D\/\u3084\u3055\u3057\u3044\u30DE\u30C3\u30B9\u30B0\u30DE",
        "screen_name" : "tamawakagashira",
        "indices" : [ 14, 30 ],
        "id_str" : "185651192",
        "id" : 185651192
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 32, 39 ],
        "id_str" : "93311525",
        "id" : 93311525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47543554276458496",
    "text" : "\u5927\u4E08\u592B\u3060\u3001\u554F\u984C\u306A\u3044\u3002 RT @tamawakagashira: @NHK_PR \u305D\u306E\u8A9E\u5C3E\u306F\u826F\u3044\u3093\u3067\u3059\u304B\u3001NHK\u7684\u306B\uFF57\uFF57\uFF57",
    "id" : 47543554276458496,
    "created_at" : "2011-03-15 06:24:01 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 47547892126326784,
  "created_at" : "2011-03-15 06:41:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47513565833334784",
  "text" : "only my railgun\u8074\u304D\u3064\u3064\u79FB\u52D5\u4E2D\u3002\u3042\u3068\uFF12\uFF10\u5206\u307B\u3069\u3067\u4EAC\u90FD\u3060\u3002",
  "id" : 47513565833334784,
  "created_at" : "2011-03-15 04:24:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47483673079062528",
  "text" : "@koketomi \u307E\u3041\u8272\u3005\u307B\u3063\u305F\u3089\u304B\u3057\u3067\u6765\u3061\u3083\u3063\u3066\u305F\u304B\u3089\u306A\u30FC\u3002\u57CB\u3081\u5408\u308F\u305B\u306A\u304F\u3066\u306F\u3002",
  "id" : 47483673079062528,
  "created_at" : "2011-03-15 02:26:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47480378436489216",
  "text" : "\u6771\u4EAC\u99C5\u306E\u30A8\u30EC\u30D9\u30FC\u30BF\u30FC\u6B62\u307E\u3063\u3066\u305F\u306E\u306B\u306F\u53C2\u3063\u305F\u3002\u3057\u3083\u30FC\u306A\u3044\u304C\u3002",
  "id" : 47480378436489216,
  "created_at" : "2011-03-15 02:12:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47480094817656832",
  "text" : "\u3068\u306F\u8A00\u3048\u505C\u96FB\u304B\u3089\u306F\u9003\u308C\u3089\u308C\u305D\u3046\u3067\u4F55\u3088\u308A\u3002",
  "id" : 47480094817656832,
  "created_at" : "2011-03-15 02:11:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47479937803882496",
  "text" : "\u65B0\u5E79\u7DDA\u306A\u3046\u30FC\u3002\u5B50\u9023\u308C\u591A\u3057\u3002\u307E\u3041\u304A\u4F11\u307F\u3084\u3057\u306A\u3041\u3002",
  "id" : 47479937803882496,
  "created_at" : "2011-03-15 02:11:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "\u308C\u304A\u3066\u3093",
      "screen_name" : "carp1god",
      "indices" : [ 102, 111 ],
      "id_str" : "210101492",
      "id" : 210101492
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 113, 120 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47479056668700672",
  "text" : "RT @NHK_PR: \u306F\u3044\u3002\u30B4\u30ED\u30EA\u306F\u6C17\u6301\u3061\u306E\u3084\u3055\u3057\u3044\u30015\u6B73\u306E\u30AF\u30DE\u306E\u7537\u306E\u5B50\u3067\u3059\u3002\u305F\u3060\u3057\u3001\u30EF\u30AF\u30EF\u30AF\u3055\u3093\u306E\u3044\u3046\u3053\u3068\u3092\u3042\u307E\u308A\u805E\u304B\u305A\u306B\u52DD\u624B\u306A\u3053\u3068\u3092\u3059\u308B\u305F\u3081\u3001\u5931\u6557\u3070\u304B\u308A\u3057\u3066\u3044\u307E\u3059\u3002\u306A\u304A\u3001\u4E2D\u306E\u4EBA\u306A\u3069\u3044\u307E\u305B\u3093\u3002 RT @carp1god: @NHK_PR \u4E2D\u306E\u4EBA\u3001\u30B4\u30ED\u30EA\u3063\u3066\u718A\u3067\u3059\u304B\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u308C\u304A\u3066\u3093",
        "screen_name" : "carp1god",
        "indices" : [ 90, 99 ],
        "id_str" : "210101492",
        "id" : 210101492
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 101, 108 ],
        "id_str" : "93311525",
        "id" : 93311525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47452072626487296",
    "text" : "\u306F\u3044\u3002\u30B4\u30ED\u30EA\u306F\u6C17\u6301\u3061\u306E\u3084\u3055\u3057\u3044\u30015\u6B73\u306E\u30AF\u30DE\u306E\u7537\u306E\u5B50\u3067\u3059\u3002\u305F\u3060\u3057\u3001\u30EF\u30AF\u30EF\u30AF\u3055\u3093\u306E\u3044\u3046\u3053\u3068\u3092\u3042\u307E\u308A\u805E\u304B\u305A\u306B\u52DD\u624B\u306A\u3053\u3068\u3092\u3059\u308B\u305F\u3081\u3001\u5931\u6557\u3070\u304B\u308A\u3057\u3066\u3044\u307E\u3059\u3002\u306A\u304A\u3001\u4E2D\u306E\u4EBA\u306A\u3069\u3044\u307E\u305B\u3093\u3002 RT @carp1god: @NHK_PR \u4E2D\u306E\u4EBA\u3001\u30B4\u30ED\u30EA\u3063\u3066\u718A\u3067\u3059\u304B\uFF1F",
    "id" : 47452072626487296,
    "created_at" : "2011-03-15 00:20:30 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 47479056668700672,
  "created_at" : "2011-03-15 02:07:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47306641762299904",
  "geo" : { },
  "id_str" : "47307558528102400",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u30FC\u305C\u30FC\u3066\u30FC\uFF57\uFF57",
  "id" : 47307558528102400,
  "in_reply_to_status_id" : 47306641762299904,
  "created_at" : "2011-03-14 14:46:15 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47294387872464896",
  "text" : "@koketomi \u5E30\u5B85\u96E3\u6C11\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 47294387872464896,
  "created_at" : "2011-03-14 13:53:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47236294690078721",
  "text" : "RT @kussytessy: \u6B63\u76F4\u3001\u300C\u3055\u3059\u304C\u4EAC\u5927\u751F\u3002\u982D\u304C\u3044\u3044\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u3088\u308A\u3001\u300C\u3055\u3059\u304C\u4EAC\u5927\u751F\u3002\u30DE\u30B8\u30AD\u30C1\u300D\u3063\u3066\u8A00\u308F\u308C\u305F\u65B9\u304C\u5B09\u3057\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/market.android.com\/details?id=jp.rsn.meganecase\" rel=\"nofollow\"\u003E\u30E1\u30AC\u30CD\u30B1\u30A8\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47231231108186112",
    "text" : "\u6B63\u76F4\u3001\u300C\u3055\u3059\u304C\u4EAC\u5927\u751F\u3002\u982D\u304C\u3044\u3044\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u3088\u308A\u3001\u300C\u3055\u3059\u304C\u4EAC\u5927\u751F\u3002\u30DE\u30B8\u30AD\u30C1\u300D\u3063\u3066\u8A00\u308F\u308C\u305F\u65B9\u304C\u5B09\u3057\u3044\u3002",
    "id" : 47231231108186112,
    "created_at" : "2011-03-14 09:42:57 +0000",
    "user" : {
      "name" : "DEAD END",
      "screen_name" : "7ksts",
      "protected" : false,
      "id_str" : "96237218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593483929\/091227_0015_0001_normal.jpg",
      "id" : 96237218,
      "verified" : false
    }
  },
  "id" : 47236294690078721,
  "created_at" : "2011-03-14 10:03:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47235690223763456",
  "text" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u66F0\u304F",
  "id" : 47235690223763456,
  "created_at" : "2011-03-14 10:00:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47235622485762049",
  "text" : "\u300C\u7A7A\u60F3\u306F\u3001\u77E5\u8B58\u3088\u308A\u3082\u91CD\u8981\u3067\u3042\u308B\u3002\u77E5\u8B58\u306B\u306F\u9650\u754C\u304C\u3042\u308B\u304C\u3001\u7A7A\u60F3\u306F\u4E16\u754C\u3059\u3089\u5305\u307F\u8FBC\u3080\u300D",
  "id" : 47235622485762049,
  "created_at" : "2011-03-14 10:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47235447516176384",
  "text" : "\u300C\u8ABF\u3079\u3089\u308C\u308B\u3082\u306E\u3092\u3001\u3044\u3061\u3044\u3061\u899A\u3048\u3066\u304A\u304F\u5FC5\u8981\u306A\u3069\u306A\u3044\u300D",
  "id" : 47235447516176384,
  "created_at" : "2011-03-14 09:59:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47233891509092352",
  "text" : "\u305D\u3057\u3066\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u306E\u8A95\u751F\u65E5\u304A\u3081\u3067\u3068\u3046\u3002",
  "id" : 47233891509092352,
  "created_at" : "2011-03-14 09:53:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47233702350172160",
  "text" : "\u3042\u3001\u03C0\u306E\u65E5\u304A\u3081\u3067\u3068\u3046\u3002",
  "id" : 47233702350172160,
  "created_at" : "2011-03-14 09:52:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47197202266849280",
  "text" : "\u3082\u3046\u5C11\u3057\u306E\u63FA\u308C\u306B\u306F\u6163\u308C\u3066\u3057\u307E\u3063\u305F\u306A\u3002\u4E0D\u8B39\u614E\u304B\u3082\u3060\u304C\u3002",
  "id" : 47197202266849280,
  "created_at" : "2011-03-14 07:27:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47094484210696192",
  "text" : "\u3069\u3046\u3084\u3063\u3066\u5E30\u308D\u3046",
  "id" : 47094484210696192,
  "created_at" : "2011-03-14 00:39:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 3, 18 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AirReitaisai",
      "indices" : [ 36, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46766834355142657",
  "text" : "RT @kanoto_hitsuji: \u4ECA\u3001\u30A8\u30A2\u4F8B\u5927\u796D\u304C\uFF01\u30A2\u30C4\u30A4\uFF01\uFF01\uFF01 #AirReitaisai",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AirReitaisai",
        "indices" : [ 16, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "46754275384242176",
    "text" : "\u4ECA\u3001\u30A8\u30A2\u4F8B\u5927\u796D\u304C\uFF01\u30A2\u30C4\u30A4\uFF01\uFF01\uFF01 #AirReitaisai",
    "id" : 46754275384242176,
    "created_at" : "2011-03-13 02:07:42 +0000",
    "user" : {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "protected" : false,
      "id_str" : "112678195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000133370705\/7e4c0c7ed3e9f2e926e0bd5bb2b7bca8_normal.jpeg",
      "id" : 112678195,
      "verified" : false
    }
  },
  "id" : 46766834355142657,
  "created_at" : "2011-03-13 02:57:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46743489819582464",
  "text" : "\u6687\u3060\u306A\u30FC\u3002",
  "id" : 46743489819582464,
  "created_at" : "2011-03-13 01:24:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46399747015180288",
  "text" : "\u5B9F\u5BB6\u304C\u697D\u3057\u3044\u3053\u3068\u306B\u306A\u3063\u3066\u306A\u304D\u3083\u3044\u3044\u3051\u3069\u306D\u3047\u3002",
  "id" : 46399747015180288,
  "created_at" : "2011-03-12 02:38:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46399534624022528",
  "text" : "\u5E30\u5B85\u306A\u3046\u30FC\u3002\u751F\u304D\u3066\u307E\u3059\u3002",
  "id" : 46399534624022528,
  "created_at" : "2011-03-12 02:38:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u3060\u304B",
      "screen_name" : "hodaka29",
      "indices" : [ 3, 12 ],
      "id_str" : "58736712",
      "id" : 58736712
    }, {
      "name" : "Ma bebe  Meena",
      "screen_name" : "Meena35",
      "indices" : [ 20, 28 ],
      "id_str" : "113958643",
      "id" : 113958643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46096477621207040",
  "text" : "RT @hodaka29: \u62E1\u6563 RT @Meena35: \u304A\u9858\u3044\u3060\u304B\u3089\u3053\u3093\u306A\u3068\u304D\u306B\u30C6\u30EC\u30D3\u5C40\u306E\u4EBA\u30D8\u30EA\u30B3\u30D7\u30BF\u30FC\u98DB\u3070\u3055\u306A\u3044\u3067\u304F\u3060\u3055\u3044\uFF01\u795E\u6238\u3067\u306F\u304F\u305A\u308C\u305F\u5BB6\u3067\u751F\u304D\u57CB\u3081\u306B\u306A\u3063\u305F\u4EBA\u306E\u58F0\u304C\u805E\u3053\u3048\u306A\u304B\u3063\u305F\u308A\u3059\u308B\u3053\u3068\u304C\u3042\u3063\u305F\u306E\u3067\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ma bebe  Meena",
        "screen_name" : "Meena35",
        "indices" : [ 6, 14 ],
        "id_str" : "113958643",
        "id" : 113958643
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "46091256706764800",
    "text" : "\u62E1\u6563 RT @Meena35: \u304A\u9858\u3044\u3060\u304B\u3089\u3053\u3093\u306A\u3068\u304D\u306B\u30C6\u30EC\u30D3\u5C40\u306E\u4EBA\u30D8\u30EA\u30B3\u30D7\u30BF\u30FC\u98DB\u3070\u3055\u306A\u3044\u3067\u304F\u3060\u3055\u3044\uFF01\u795E\u6238\u3067\u306F\u304F\u305A\u308C\u305F\u5BB6\u3067\u751F\u304D\u57CB\u3081\u306B\u306A\u3063\u305F\u4EBA\u306E\u58F0\u304C\u805E\u3053\u3048\u306A\u304B\u3063\u305F\u308A\u3059\u308B\u3053\u3068\u304C\u3042\u3063\u305F\u306E\u3067\u3002",
    "id" : 46091256706764800,
    "created_at" : "2011-03-11 06:13:06 +0000",
    "user" : {
      "name" : "\u307B\u3060\u304B",
      "screen_name" : "hodaka29",
      "protected" : false,
      "id_str" : "58736712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1393210014\/hodaka29_normal.jpg",
      "id" : 58736712,
      "verified" : false
    }
  },
  "id" : 46096477621207040,
  "created_at" : "2011-03-11 06:33:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46091248817278976",
  "text" : "@koketomi \u8ECA\u3067\u884C\u304F\u3001\u5927\u4E08\u592B\u3060\u3001\u554F\u984C\u306A\u3044\u3002",
  "id" : 46091248817278976,
  "created_at" : "2011-03-11 06:13:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "indices" : [ 3, 16 ],
      "id_str" : "96289411",
      "id" : 96289411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46090829684678656",
  "text" : "RT @d_v_osorezan: \u307F\u3093\u306A\u5730\u9707\u304C\u8D77\u304D\u305F\u3068\u304D\u306E\u5BFE\u5FDC\u306F\u300C\u304A\u304B\u3057\u300D\u3082\u3057\u304F\u306F\u300C\u304A\u304B\u3057\u3082\u300D\u3067\u7FD2\u3063\u3066\u305F\u3068\u601D\u3046\u3051\u3069\u3001\u3044\u307E\u306F\u300C\u304A\u304B\u3057\u3082\u3064\u300D\u304C\u30B9\u30BF\u30F3\u30C0\u30FC\u30C9\u3060\u304B\u3089\u306D\u3002\u3064\u307E\u308A\u3000\n\u304A\uFF1A\u62BC\u3055\u306A\u3044\u3000\u3000\n\u304B\uFF1A\u99C6\u3051\u306A\u3044\u3000\u3000\n\u3057\uFF1A\u558B\u3089\u306A\u3044\u3000\u3000\n\u3082\uFF1A\u623B\u3089\u306A\u3044\u3000\u3000\n\u3064\uFF1A\u30C4\u30A4\u30FC\u30C8\u306A\u3093\u304B\u3057\u3066\u3093\u3058\u3083 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44366537246777344",
    "text" : "\u307F\u3093\u306A\u5730\u9707\u304C\u8D77\u304D\u305F\u3068\u304D\u306E\u5BFE\u5FDC\u306F\u300C\u304A\u304B\u3057\u300D\u3082\u3057\u304F\u306F\u300C\u304A\u304B\u3057\u3082\u300D\u3067\u7FD2\u3063\u3066\u305F\u3068\u601D\u3046\u3051\u3069\u3001\u3044\u307E\u306F\u300C\u304A\u304B\u3057\u3082\u3064\u300D\u304C\u30B9\u30BF\u30F3\u30C0\u30FC\u30C9\u3060\u304B\u3089\u306D\u3002\u3064\u307E\u308A\u3000\n\u304A\uFF1A\u62BC\u3055\u306A\u3044\u3000\u3000\n\u304B\uFF1A\u99C6\u3051\u306A\u3044\u3000\u3000\n\u3057\uFF1A\u558B\u3089\u306A\u3044\u3000\u3000\n\u3082\uFF1A\u623B\u3089\u306A\u3044\u3000\u3000\n\u3064\uFF1A\u30C4\u30A4\u30FC\u30C8\u306A\u3093\u304B\u3057\u3066\u3093\u3058\u3083\u306D\u3048\u3088\u30D0\u30AB",
    "id" : 44366537246777344,
    "created_at" : "2011-03-06 11:59:41 +0000",
    "user" : {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "protected" : false,
      "id_str" : "96289411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3457427933\/e9c1859b77927509e49bcdd8ea328bdb_normal.jpeg",
      "id" : 96289411,
      "verified" : false
    }
  },
  "id" : 46090829684678656,
  "created_at" : "2011-03-11 06:11:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46089795021185026",
  "text" : "\u663C\u5BDD\u3057\u3066\u305F\u306E\u306B\u8D77\u3053\u3055\u308C\u305F\u3002",
  "id" : 46089795021185026,
  "created_at" : "2011-03-11 06:07:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46049427923804160",
  "text" : "\u7ACB\u5DDD\u99C5\u524D\u306A\u3046\u30FC\u3002\u307E\u308B\u3067\u5B66\u5712\u90FD\u5E02\uFF08\u7B11\uFF09",
  "id" : 46049427923804160,
  "created_at" : "2011-03-11 03:26:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u84BC\u304D\u30D0\u30A4\u30AA\u30CB\u30C3\u30AF\u30DF\u30E4\u305E\u30461\/8192",
      "screen_name" : "miyazoman",
      "indices" : [ 3, 13 ],
      "id_str" : "129171677",
      "id" : 129171677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45500404007583744",
  "text" : "RT @miyazoman: \u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u4E00\u5FDC\u516C\u306E\u5834\u3068\u3044\u3046\u540D\u76EE\u306A\u306E\u3067\u3001\u767A\u8A00\u8005\u306F\u8CAC\u4EFB\u3092\u3082\u3064\u3079\u304D\u3060\u3068\u3044\u3046\u8AD6\u8ABF\u306F\u89E3\u308B\u3002\u6700\u3082\u3060\u3002\u3060\u304C\u540C\u6642\u306B\u30CD\u30C3\u30C8\u306E\u60C5\u5831\u306B\u306F\u53D6\u6368\u9078\u629E\u6A29\u304C\u5E38\u306B\u81EA\u5206\u306B\u3042\u308B\u3068\u3044\u3046\u3053\u3068\u3092\u68DA\u306B\u6319\u3052\u306A\u3044\u3067\u6B32\u3057\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45497178151591936",
    "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u4E00\u5FDC\u516C\u306E\u5834\u3068\u3044\u3046\u540D\u76EE\u306A\u306E\u3067\u3001\u767A\u8A00\u8005\u306F\u8CAC\u4EFB\u3092\u3082\u3064\u3079\u304D\u3060\u3068\u3044\u3046\u8AD6\u8ABF\u306F\u89E3\u308B\u3002\u6700\u3082\u3060\u3002\u3060\u304C\u540C\u6642\u306B\u30CD\u30C3\u30C8\u306E\u60C5\u5831\u306B\u306F\u53D6\u6368\u9078\u629E\u6A29\u304C\u5E38\u306B\u81EA\u5206\u306B\u3042\u308B\u3068\u3044\u3046\u3053\u3068\u3092\u68DA\u306B\u6319\u3052\u306A\u3044\u3067\u6B32\u3057\u3044\u3002",
    "id" : 45497178151591936,
    "created_at" : "2011-03-09 14:52:27 +0000",
    "user" : {
      "name" : "\u84BC\u304D\u30D0\u30A4\u30AA\u30CB\u30C3\u30AF\u30DF\u30E4\u305E\u30461\/8192",
      "screen_name" : "miyazoman",
      "protected" : false,
      "id_str" : "129171677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525707221707915264\/Qxqa4AeG_normal.jpeg",
      "id" : 129171677,
      "verified" : false
    }
  },
  "id" : 45500404007583744,
  "created_at" : "2011-03-09 15:05:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45472456982540288",
  "geo" : { },
  "id_str" : "45473172681785344",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u7D50\u69CB\u30D5\u30A1\u30F3\u3060\u304C\u81EA\u5206\u304B\u3089\u306F\u5E03\u6559\u3057\u306A\u3044\u3002\u3067\u3082\u307E\u3041\u8208\u5473\u304C\u3042\u308B\u306A\u3089\u305C\u3072\u305C\u3072\uFF57",
  "id" : 45473172681785344,
  "in_reply_to_status_id" : 45472456982540288,
  "created_at" : "2011-03-09 13:17:03 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45471009943453696",
  "geo" : { },
  "id_str" : "45471724283764736",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u3084\u3001\u6771\u65B9\u3067\u5408\u3063\u3066\u308B\u3088\u3002\u3082\u3068\u3082\u3068\u30B7\u30E5\u30FC\u30C6\u30A3\u30F3\u30B0\u306A\u3093\u3060\u3051\u3069\u4F5C\u8005\u304C\u97F3\u697D\u4F5C\u308A\u305F\u304F\u3066\u8DA3\u5473\u3067\u30B2\u30FC\u30E0\u4F5C\u3063\u305F\u304B\u3089\u97F3\u697D\u306E\u30AF\u30AA\u30EA\u30C6\u30A3\u30FC\u304C\u9AD8\u3044\u306E\u3055\u3002\u30C1\u30EB\u30CE\u306E(ry\u306F\u96FB\u6CE2\u3060\u3051\u3069\u306D\u30FC",
  "id" : 45471724283764736,
  "in_reply_to_status_id" : 45471009943453696,
  "created_at" : "2011-03-09 13:11:18 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45470643734577152",
  "geo" : { },
  "id_str" : "45470884466655232",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30A2\u30CB\u30E1\u3067\u306F\u306A\u304F\u3066\u3068\u3042\u308B\u30B2\u30FC\u30E0\u306EBGM\u306E\u30A2\u30EC\u30F3\u30B8\u306A\u306E\u3067\u3059",
  "id" : 45470884466655232,
  "in_reply_to_status_id" : 45470643734577152,
  "created_at" : "2011-03-09 13:07:58 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45365069961375745",
  "geo" : { },
  "id_str" : "45368029953003520",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u304A\u3081\u3067\u3068\u3046\uFF01\uFF01\uFF01\uFF01",
  "id" : 45368029953003520,
  "in_reply_to_status_id" : 45365069961375745,
  "created_at" : "2011-03-09 06:19:15 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45306941626527744",
  "text" : "\u672C\u514D\u5408\u683C\u306A\u3046\u30FC",
  "id" : 45306941626527744,
  "created_at" : "2011-03-09 02:16:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45121495223115776",
  "geo" : { },
  "id_str" : "45128625552490496",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u76F8\u5909\u308F\u3089\u305A\u56FD\u7ACB\u7D44\u7121\u8996\u306E\u884C\u4E8B\u65E5\u7A0B\u2026\u6D41\u77F3\u3067\u3059\u306D^^",
  "id" : 45128625552490496,
  "in_reply_to_status_id" : 45121495223115776,
  "created_at" : "2011-03-08 14:27:57 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45089732664901632",
  "text" : "\u5409\u7965\u5BFA\u306A\u3046\u30FC\u3002\uFF15\u6642\uFF13\uFF10\u5206\u306B\u81EA\u7136\u306B\u76EE\u304C\u899A\u3081\u305F\u79C1\u306B\u306F\u3082\u3046\u7720\u3044\u3002",
  "id" : 45089732664901632,
  "created_at" : "2011-03-08 11:53:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44563133192212480",
  "geo" : { },
  "id_str" : "44564250475245568",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5909\u306A\u30D5\u30E9\u30B0\u3092\u7ACB\u3066\u308B\u3093\u3058\u3083\u3042\u308A\u307E\u305B\u3093\uFF01",
  "id" : 44564250475245568,
  "in_reply_to_status_id" : 44563133192212480,
  "created_at" : "2011-03-07 01:05:19 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44309587507150849",
  "text" : "\u30EA\u30FC\u30C1 \u5E73\u548C \u4E00\u901A \u6E05\u4E00 \u4E00\u76C3\u53E3 \u30C9\u30E9\u30C9\u30E9",
  "id" : 44309587507150849,
  "created_at" : "2011-03-06 08:13:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "indices" : [ 3, 17 ],
      "id_str" : "199329343",
      "id" : 199329343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42855663881166848",
  "text" : "RT @Satomii_Opera: \u4F1A\u8B70\u5BA4\u306E\u86CD\u5149\u706F\u3092\u63DB\u3048\u3066\u3044\u308B\u6700\u4E2D\u3001\u4E00\u4EBA\u306A\u306E\u3092\u3044\u3044\u3053\u3068\u306B\u300C\u30D6\u30A5\u30F3\u300D\u300C\u30D6\u30A5\u30F3\u300D\u3068\u86CD\u5149\u706F\u3092\u30E9\u30A4\u30C8\u30BB\u30FC\u30D0\u30FC\u306B\u898B\u7ACB\u3066\u3066\u7DE9\u304F\u632F\u308A\u56DE\u3057\u3066\u305F\u3093\u3060\u3051\u3069\u3001\u3044\u3064\u306E\u9593\u306B\u304B\u4E0A\u53F8\u304C\u4F1A\u8B70\u5BA4\u306E\u5165\u53E3\u304B\u3089\u3053\u3061\u3089\u3092\u898B\u3066\u3044\u305F\u306E\u3067\u56FA\u307E\u3063\u305F\u3089\u3001\u300C\u3069\u3046\u3057\u305F\u3002\u5FC3\u3092\u4E71\u3059\u306A\u3002\u30D5\u30A9\u30FC\u30B9\u306E\u529B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42811461780779008",
    "text" : "\u4F1A\u8B70\u5BA4\u306E\u86CD\u5149\u706F\u3092\u63DB\u3048\u3066\u3044\u308B\u6700\u4E2D\u3001\u4E00\u4EBA\u306A\u306E\u3092\u3044\u3044\u3053\u3068\u306B\u300C\u30D6\u30A5\u30F3\u300D\u300C\u30D6\u30A5\u30F3\u300D\u3068\u86CD\u5149\u706F\u3092\u30E9\u30A4\u30C8\u30BB\u30FC\u30D0\u30FC\u306B\u898B\u7ACB\u3066\u3066\u7DE9\u304F\u632F\u308A\u56DE\u3057\u3066\u305F\u3093\u3060\u3051\u3069\u3001\u3044\u3064\u306E\u9593\u306B\u304B\u4E0A\u53F8\u304C\u4F1A\u8B70\u5BA4\u306E\u5165\u53E3\u304B\u3089\u3053\u3061\u3089\u3092\u898B\u3066\u3044\u305F\u306E\u3067\u56FA\u307E\u3063\u305F\u3089\u3001\u300C\u3069\u3046\u3057\u305F\u3002\u5FC3\u3092\u4E71\u3059\u306A\u3002\u30D5\u30A9\u30FC\u30B9\u306E\u529B\u3092\u4FE1\u3058\u308D\u300D\u3068\u3060\u3051\u8A00\u3063\u3066\u7ACB\u3061\u53BB\u3063\u305F\u306E\u3067\u60DA\u308C\u305D\u3046\u3002",
    "id" : 42811461780779008,
    "created_at" : "2011-03-02 05:00:22 +0000",
    "user" : {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "protected" : false,
      "id_str" : "199329343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212059931\/satomii_opera_normal.jpg",
      "id" : 199329343,
      "verified" : false
    }
  },
  "id" : 42855663881166848,
  "created_at" : "2011-03-02 07:56:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "indices" : [ 3, 14 ],
      "id_str" : "161635350",
      "id" : 161635350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42750622360928256",
  "text" : "RT @kisalantis: \u884C\u653F\u304C\uFF08\u306F\u3044\uFF01\uFF09\u5F37\u5236\u3092\uFF08\u306F\u3044\uFF01\uFF09\u304B\u30FC\u3051\u30FC\u3066\u30FC\u304D\u30FC\u305F\u30FC\uFF08\u8A00\uFF01\u8AD6\uFF01\u5F3E\uFF01\u5727\uFF01\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42748972397363201",
    "text" : "\u884C\u653F\u304C\uFF08\u306F\u3044\uFF01\uFF09\u5F37\u5236\u3092\uFF08\u306F\u3044\uFF01\uFF09\u304B\u30FC\u3051\u30FC\u3066\u30FC\u304D\u30FC\u305F\u30FC\uFF08\u8A00\uFF01\u8AD6\uFF01\u5F3E\uFF01\u5727\uFF01\uFF09",
    "id" : 42748972397363201,
    "created_at" : "2011-03-02 00:52:03 +0000",
    "user" : {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "protected" : false,
      "id_str" : "161635350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451385034910347265\/OhkVStyG_normal.jpeg",
      "id" : 161635350,
      "verified" : false
    }
  },
  "id" : 42750622360928256,
  "created_at" : "2011-03-02 00:58:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3061\u3085\u30FC\u3071\u3093",
      "screen_name" : "Chu_pan",
      "indices" : [ 3, 11 ],
      "id_str" : "99324807",
      "id" : 99324807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42462568207360000",
  "text" : "RT @Chu_pan: \u65E9\u7A32\u7530\u3084\u6771\u5927\u3092\u8A2A\u554F\u3057\u3066\u601D\u3046\u3053\u3068\u306F\u3001\u4EAC\u5927\u306B\u306F\u672A\u77E5\u306E\u30A8\u30CD\u30EB\u30AE\u30FC\u304C\u5145\u6E80\u3057\u3066\u308B\u3068\u3044\u3046\u3053\u3068\u3002\u7ACB\u3066\u770B\u677F\u3001\u304F\u3073\u304F\u3073\u30AB\u30D5\u30A7\u3001\u5409\u7530\u5BEE\u3001\u718A\u91CE\u5BEE\u3001\u30EB\u30CD\u6A2A\u306E\u65E7BOX\u68DF\u306A\u3093\u304B\u306B\u307F\u3089\u308C\u308B\u7121\u99C4\u611F\u3053\u305D\u4EAC\u5927\u3002\u5165\u8A66\u5F53\u65E5\u306B\u624B\u4F5C\u308A\u306E\u50CF\u3092\u4E8C\u3064\u3082\u51FA\u3057\u3066\u3001\u98F4\u3061\u3083\u3093\u914D\u3063\u3066\u53D7\u9A13\u751F\u3092\u5FDC\u63F4\u3059\u308B\u3059\u3066\u304D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crouto.com\/teewee\" rel=\"nofollow\"\u003ETeewee\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42133149823537152",
    "text" : "\u65E9\u7A32\u7530\u3084\u6771\u5927\u3092\u8A2A\u554F\u3057\u3066\u601D\u3046\u3053\u3068\u306F\u3001\u4EAC\u5927\u306B\u306F\u672A\u77E5\u306E\u30A8\u30CD\u30EB\u30AE\u30FC\u304C\u5145\u6E80\u3057\u3066\u308B\u3068\u3044\u3046\u3053\u3068\u3002\u7ACB\u3066\u770B\u677F\u3001\u304F\u3073\u304F\u3073\u30AB\u30D5\u30A7\u3001\u5409\u7530\u5BEE\u3001\u718A\u91CE\u5BEE\u3001\u30EB\u30CD\u6A2A\u306E\u65E7BOX\u68DF\u306A\u3093\u304B\u306B\u307F\u3089\u308C\u308B\u7121\u99C4\u611F\u3053\u305D\u4EAC\u5927\u3002\u5165\u8A66\u5F53\u65E5\u306B\u624B\u4F5C\u308A\u306E\u50CF\u3092\u4E8C\u3064\u3082\u51FA\u3057\u3066\u3001\u98F4\u3061\u3083\u3093\u914D\u3063\u3066\u53D7\u9A13\u751F\u3092\u5FDC\u63F4\u3059\u308B\u3059\u3066\u304D\u306A\u5927\u5B66\u3067\u3059\u3002\u304A\u3044\u3067\u3084\u3059\u3002",
    "id" : 42133149823537152,
    "created_at" : "2011-02-28 08:05:00 +0000",
    "user" : {
      "name" : "\u3061\u3085\u30FC\u3071\u3093",
      "screen_name" : "Chu_pan",
      "protected" : false,
      "id_str" : "99324807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524213104498855936\/EHS-GFYv_normal.jpeg",
      "id" : 99324807,
      "verified" : false
    }
  },
  "id" : 42462568207360000,
  "created_at" : "2011-03-01 05:53:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]