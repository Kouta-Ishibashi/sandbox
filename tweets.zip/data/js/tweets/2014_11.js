Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539060560004800512",
  "text" : "(\u89AA\u6307\u3092\u7ACB\u3066\u306A\u304C\u3089\u6EB6\u9271\u7089\u306B\u6C88\u3093\u3067\u3044\u304F)",
  "id" : 539060560004800512,
  "created_at" : "2014-11-30 14:17:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538574590184665088",
  "text" : "\u53F3\u304B\u3089\u3082\u3089\u3063\u305F\u4ED5\u4E8B\u3092\u3001\u305D\u306E\u307E\u307E\u5DE6\u306B\u6D41\u3059\u4EBA",
  "id" : 538574590184665088,
  "created_at" : "2014-11-29 06:06:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538574487386476545",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 538574487386476545,
  "created_at" : "2014-11-29 06:05:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538574466649817088",
  "text" : "\u6052\u7B49\u5199\u50CF\u306F\u3059\u3054\u3044\u3001\u3081\u3063\u3061\u3083\u591A\u304F\u306E\u6027\u8CEA\u3092\u4FDD\u3063\u3066\u304F\u308C\u308B\uFF01\u5927\u304D\u304F\u306A\u3063\u305F\u3089\u6052\u7B49\u5199\u50CF\u306B\u306A\u308A\u305F\u3044\uFF01",
  "id" : 538574466649817088,
  "created_at" : "2014-11-29 06:05:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538543274911211520",
  "geo" : { },
  "id_str" : "538544543289712640",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 3-401\u306A",
  "id" : 538544543289712640,
  "in_reply_to_status_id" : 538543274911211520,
  "created_at" : "2014-11-29 04:06:39 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538291669473296386",
  "text" : "\u4EF6\u306E\u5B66\u751F\u8A3C\u3001\u706B\u306E\u4E2D\u306B\u6295\u3052\u8FBC\u3080\u3057\u304B\u306A\u3044",
  "id" : 538291669473296386,
  "created_at" : "2014-11-28 11:21:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538269254642966528",
  "text" : "\u6B4C\u821E\u4F0E\u63DA\u3052\u3068\u7384\u7C73\u8336\u306E\u5727\u5012\u7684\u30B7\u30CA\u30B8\u30FC(\u304A\u3044\u3057\u3044)",
  "id" : 538269254642966528,
  "created_at" : "2014-11-28 09:52:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538255133088284673",
  "text" : "\u7269\u4E8B\u306E\u90FD\u5408\u306E\u3044\u3044\u90E8\u5206\u3060\u3051\u3092\u5207\u308A\u53D6\u3063\u3066\u90FD\u5408\u306E\u826F\u304F\u89E3\u91C8\u3059\u308B\u3068\u90FD\u5408\u304C\u826F\u304F\u306A\u308B\u305E\u3044",
  "id" : 538255133088284673,
  "created_at" : "2014-11-28 08:56:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538253938844114947",
  "text" : "\u6696\u623F\u3058\u3083\u306A\u304F\u3066\u51B7\u623F\u3067\u3042\u308B\u4EEE\u8AAC",
  "id" : 538253938844114947,
  "created_at" : "2014-11-28 08:51:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538252698726850560",
  "text" : "\u80CC\u304C\u9AD8\u3044\u4EBA\u306F\u80CC\u304C\u9AD8\u3044\u3063\u3066\u8A00\u3046\u3068\u5F53\u305F\u308A\u524D\u3060\u308D\u3063\u3066\u53F1\u3089\u308C\u308B\u306E\u306B\u77E5\u3063\u3066\u308B\u4EBA\u306F\u77E5\u3063\u3066\u308B\u3063\u3066\u8A00\u3063\u3066\u3082\u53F1\u3089\u308C\u306A\u3044\u306E",
  "id" : 538252698726850560,
  "created_at" : "2014-11-28 08:46:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538247379657306113",
  "text" : "\u5730\u7403\u3088\u308A\u5916\u306B\u3042\u308C\u3070\u30B0\u30ED\u30FC\u30D0\u30EB\uFF1F\uFF1F\uFF1F",
  "id" : 538247379657306113,
  "created_at" : "2014-11-28 08:25:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538247244646850561",
  "text" : "\u6708\u306F\u30BF\u30D5\u3067\u30B0\u30ED\u30FC\u30D0\u30EB\uFF1F",
  "id" : 538247244646850561,
  "created_at" : "2014-11-28 08:25:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538246486467682304",
  "text" : "\u30BF\u30D5(\u7269\u7406)",
  "id" : 538246486467682304,
  "created_at" : "2014-11-28 08:22:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538246453173313537",
  "text" : "\u3042\u305A\u304D\u30D0\u30FC\u306F\u30BF\u30D5\u3060\u3068\u601D\u3046\u3093\u3067\u3059\u3051\u3069",
  "id" : 538246453173313537,
  "created_at" : "2014-11-28 08:22:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538246030592966656",
  "text" : "\u30E4\u30EF\u3067\u30ED\u30FC\u30AB\u30EB\u306A\u4EBA\u6750\u3068\u3057\u3066",
  "id" : 538246030592966656,
  "created_at" : "2014-11-28 08:20:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538245886082420736",
  "text" : "\u30B8\u30D0\u30CB\u30E3\u30F3\u304C\u79CB\u540D\u306B\u8ABF\u5F8B\u3055\u308C\u308B\u6642\u306E\u753B\u50CF\u4E0B\u3055\u3044",
  "id" : 538245886082420736,
  "created_at" : "2014-11-28 08:19:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538245336897028096",
  "text" : "\u6D77\u5916\u306A\u3089\u3070\u30B0\u30ED\u30FC\u30D0\u30EB\u3001\u3068\u304B\u3044\u3046\u66B4\u8AD6",
  "id" : 538245336897028096,
  "created_at" : "2014-11-28 08:17:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538243724971503616",
  "text" : "\"\u30B9\u30FC\u30D1\u30FC\u30B0\u30ED\u30FC\u30D0\u30EB\u304A\u305B\u3093\u3079\u3044\"\u98DF\u3079\u305F\u3055\u3001\u3067\u306F\u306A\u304F\u3066\"\u30B9\u30FC\u30D1\u30FC\u30B0\u30ED\u30FC\u30D0\u30EB\u304A\u305B\u3093\u3079\u3044\u98DF\u3079\u305F\u3055\"\u306A\u3093\u3067\u3059\u3088\u306D",
  "id" : 538243724971503616,
  "created_at" : "2014-11-28 08:11:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u306C\u3044\u30C8\u30A5\u30FC\u30F3",
      "screen_name" : "0_u0",
      "indices" : [ 0, 5 ],
      "id_str" : "62833617",
      "id" : 62833617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538243111650988033",
  "geo" : { },
  "id_str" : "538243528350892032",
  "in_reply_to_user_id" : 62833617,
  "text" : "@0_u0 \u30AA\u30E9\u30F3\u30C0\u3068\u304B\u30ED\u30FC\u30AB\u30EB\u3067\u306F\u2026(?)",
  "id" : 538243528350892032,
  "in_reply_to_status_id" : 538243111650988033,
  "created_at" : "2014-11-28 08:10:31 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538242884391018497",
  "text" : "\u30B9\u30FC\u30D1\u30FC\u30B0\u30ED\u30FC\u30D0\u30EB\u304A\u305B\u3093\u3079\u3044\u98DF\u3079\u305F\u3055",
  "id" : 538242884391018497,
  "created_at" : "2014-11-28 08:07:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538242497130921984",
  "text" : "mvp",
  "id" : 538242497130921984,
  "created_at" : "2014-11-28 08:06:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538241872896851968",
  "text" : "\u306E\u8EAB\u304C\u27A1\u306E\u307F\u304C",
  "id" : 538241872896851968,
  "created_at" : "2014-11-28 08:03:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538241820166070272",
  "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u3068\u6388\u696D\u3001\u4E21\u7ACB\u3067\u304D\u308B\u4EBA\u9593\u306E\u8EAB\u304C\u5F37\u3044\u4EBA\u9593\u3060(?)",
  "id" : 538241820166070272,
  "created_at" : "2014-11-28 08:03:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538241555421593601",
  "text" : "\u304F\u305D\u308A\u3077\u306E\u3088\u304B\u3093",
  "id" : 538241555421593601,
  "created_at" : "2014-11-28 08:02:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538241360466157568",
  "text" : "\u306C\u308C\u305B\u3093\u3079\u3044\u3068\u304B\u3001\u3044\u3044\u3088\u306D",
  "id" : 538241360466157568,
  "created_at" : "2014-11-28 08:01:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538241055993262080",
  "text" : "\u304A\u305B\u3093\u3079\u3044\u98DF\u3079\u305F\u3044",
  "id" : 538241055993262080,
  "created_at" : "2014-11-28 08:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537990943543001090",
  "text" : "\u30E1\u30BF\u306A\u8996\u70B9\u3092\u6301\u3066\u306A\u3044\u4EBA\u306F\u30A2\u30EC\u3060\u3051\u3069\u30E1\u30BF\u30E1\u30BF\u306A\u4EBA\u3082\u3084\u306F\u308A\u30A2\u30EC\u306A\u3093\u3060\u3088\u306A\u2026",
  "id" : 537990943543001090,
  "created_at" : "2014-11-27 15:26:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537968090261094400",
  "geo" : { },
  "id_str" : "537968326656262144",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30CD\u30BF\u5143\u304B\u3089\u7523\u5730\u76F4\u9001\u3060\u304B\u3089\u306A",
  "id" : 537968326656262144,
  "in_reply_to_status_id" : 537968090261094400,
  "created_at" : "2014-11-27 13:56:58 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537967595228372992",
  "geo" : { },
  "id_str" : "537968034317471744",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u3084\u3041\u53CB\u4EBA",
  "id" : 537968034317471744,
  "in_reply_to_status_id" : 537967595228372992,
  "created_at" : "2014-11-27 13:55:49 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537966984114098176",
  "geo" : { },
  "id_str" : "537967140427399169",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u53D6\u308A\u6271\u3044\u306B\u3064\u3044\u3066\u201D\u201D\u201D\u7121\u7C8B\u201D\u201D\u201D\u306A\u8F29\u304C\u591A\u3059\u304E\u308B",
  "id" : 537967140427399169,
  "in_reply_to_status_id" : 537966984114098176,
  "created_at" : "2014-11-27 13:52:15 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537966581058248704",
  "geo" : { },
  "id_str" : "537966649085681664",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3059\u3067\u306B\uFF08\u30B9\u30AF\u30B7\u30E7\u3060\u304C\uFF09\u898B\u3066\u60B2\u3057\u3044\u6C17\u6301\u3061\u306B\u306A\u3063\u305F",
  "id" : 537966649085681664,
  "in_reply_to_status_id" : 537966581058248704,
  "created_at" : "2014-11-27 13:50:18 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537966358080663554",
  "text" : "\u7D50\u5A5A\u3067\u304D\u306A\u3044\u4EBA\u3092\uFF10\u306B\uFF08\u306A\u308B\u307E\u3067\u6BBA\u3057\u7D9A\u3051\u308B\uFF09",
  "id" : 537966358080663554,
  "created_at" : "2014-11-27 13:49:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537966227763625984",
  "text" : "\u4E16\u754C\u306E\u4EFB\u610F\u306E\u3082\u306E\u304C\u304A\u3082\u3057\u308D\u304F\u306A\u3089\u306A\u3044\u305F\u3081\u306E\u30B7\u30B9\u30C6\u30E0\u306A\u306E\u304B\u3082\u3057\u308C\u306A\u3044\uFF08\uFF1F\uFF09",
  "id" : 537966227763625984,
  "created_at" : "2014-11-27 13:48:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537966091956273154",
  "text" : "\u304A\u3082\u3057\u308D\u3044\u3082\u306E\uFF0C\u6D41\u884C\u3063\u305F\u308A\u30A2\u30A6\u30C8\u30D7\u30C3\u30C8\u3057\u305F\u9014\u7AEF\u306B\u305D\u306E\u304A\u3082\u3057\u308D\u3055\u3092\u5931\u3046\u3053\u3068\u304C\u307E\u307E\u3042\u308B\u3051\u3069\u306A\u3093\u306A\u3093\u3060",
  "id" : 537966091956273154,
  "created_at" : "2014-11-27 13:48:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/cNXtFBuXtN",
      "expanded_url" : "https:\/\/www.google.co.jp\/search?q=%E7%9F%B3%E7%AD%8D&espv=2&es_sm=121&tbm=isch&tbo=u&source=univ&sa=X&ei=5Sp3VKCwJ-OymAXllIHQCQ&ved=0CDQQsAQ&biw=1299&bih=656",
      "display_url" : "google.co.jp\/search?q=%E7%9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537965443441389569",
  "text" : "\u3053\u3093\u306A\u3093 https:\/\/t.co\/cNXtFBuXtN",
  "id" : 537965443441389569,
  "created_at" : "2014-11-27 13:45:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537965298209402880",
  "text" : "\u937E\u4E73\u6D1E\u3068\u304B\u306B\u3042\u308B\u305F\u3051\u306E\u3053\u307F\u305F\u3044\u306A\u5F62\u3057\u305F\u77F3\u306A",
  "id" : 537965298209402880,
  "created_at" : "2014-11-27 13:44:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537965229468971008",
  "text" : "\u30DC\u30C9\u30B2\u3068\u304B\u3084\u3063\u3066\u308B\u3068\u304D\u306B\u3088\u304F\u300C\u5E2D\u9806\u300D\u3063\u3066\u5358\u8A9E\u304C\u98DB\u3073\u4EA4\u3046\u3093\u3060\u3051\u3069\u305D\u306E\u305F\u3073\u306B\u300C\u77F3\u7B4D\u300D\u304C\u982D\u3092\u3088\u304E\u308B\u3093\u3060\u3051\u3069\u3053\u308C\u3063\u3066\u30C8\u30EA\u30D3\u30A2\u306B\u306A\u308A\u307E\u305B\u3093\u304B",
  "id" : 537965229468971008,
  "created_at" : "2014-11-27 13:44:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537964535282286594",
  "text" : "\u5F62\u3060\u3051\u305D\u308C\u3063\u307D\u304F\u3066\u4E2D\u8EAB\u304C\u307E\u3063\u305F\u304F\u7684\u306F\u305A\u308C\u306A\u3082\u306E\u3092\u7F85\u5217\u3059\u308B\u306E\u3059\u304D",
  "id" : 537964535282286594,
  "created_at" : "2014-11-27 13:41:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537964327337070592",
  "text" : "\u305F\u306E\u3057\u3044\u304B\u3044\u308F",
  "id" : 537964327337070592,
  "created_at" : "2014-11-27 13:41:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537964303853166592",
  "text" : "\u53CB\u4EBA\u300C\u3054\u98EF\u98DF\u3079\u305F\u3089\u7720\u304F\u306A\u3063\u305F\u306A\u3041\u300D\n\u5148\u8F29\u300C\u8179\u306E\u76AE\u304C\u5F35\u308B\u3068\u76EE\u306E\u76AE\u304C\u5F1B\u3080\u3063\u3066\u8A00\u3046\u3088\u306D\u301C\u300D\n\u53CB\u4EBA\u300C\uFF1F\uFF1F\uFF1F\uFF08\u805E\u3044\u305F\u3053\u3068\u7121\u3044\u306A\u30FC\uFF09\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u30EA\u30F3\u30B4\u304C\u8D64\u304F\u306A\u308B\u3068\u533B\u8005\u304C\u9752\u304F\u306A\u308B\u3063\u3066\u8A00\u3046\u3088\u306D\u301C\u300D\n\u53CB\u4EBA\u300C\uFF01\uFF1F\uFF01\uFF1F\uFF01\uFF1F\u300D",
  "id" : 537964303853166592,
  "created_at" : "2014-11-27 13:40:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537962748529758209",
  "text" : "\u901F\u5EA6\u304C\u52A0\u901F\u5EA6\u7684\u306B\u52A0\u901F\u3057\u3066\u308B\u3001\u3053\u3093\u306A\u306B\u982D\u60AA\u305D\u3046\u306A\u6587\u5B57\u5217\u306F\u3042\u3093\u307E\u308A\u306A\u3044",
  "id" : 537962748529758209,
  "created_at" : "2014-11-27 13:34:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537962668653428736",
  "text" : "\u30B3\u30F3\u30C6\u30F3\u30C4\u6D88\u8CBB\u306E\u901F\u5EA6\u304C\u52A0\u901F\u5EA6\u7684\u306B\u52A0\u901F\u3057\u3066\u308B\u3057\u3001\u305D\u306E\u3046\u3061\u30B3\u30F3\u30C6\u30F3\u30C4\u304C\u751F\u307F\u51FA\u3055\u308C\u308B\u524D\u306B\u6D88\u8CBB\u3055\u308C\u5207\u308B\u306B\u9055\u3044\u306A\u3044",
  "id" : 537962668653428736,
  "created_at" : "2014-11-27 13:34:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537961850822873088",
  "geo" : { },
  "id_str" : "537961935505858560",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u7BA1\u7406\u8005\u306A\u306E\u306B\u6A29\u9650\u304C\u306A\u3044(?)",
  "id" : 537961935505858560,
  "in_reply_to_status_id" : 537961850822873088,
  "created_at" : "2014-11-27 13:31:34 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537961600502624259",
  "text" : "\u4E0A\u66F8\u304D\u4FDD\u5B58\u3082\u5225\u540D\u4FDD\u5B58\u3082\u306A\u3044",
  "id" : 537961600502624259,
  "created_at" : "2014-11-27 13:30:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537961537361559552",
  "text" : "\u604B\u611B\u306B\u95A2\u3059\u308B\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA\u304C\u306A\u3044(\u5B8C)",
  "id" : 537961537361559552,
  "created_at" : "2014-11-27 13:30:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537961304137289728",
  "text" : "\u80BA\u304C\u51B7\u305F\u3044\u7A7A\u6C17\u306B\u3046\u3049\u30A9\u30F3\u3063\u3066\u306A\u3063\u3066\u30AD\u30E5\u30FC\u3063\u3066\u306A\u308B\u306E(\u4F1D\u308F\u308C)",
  "id" : 537961304137289728,
  "created_at" : "2014-11-27 13:29:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537958818705969152",
  "text" : "\u30D5\u30ED\u30C3\u30B0\u3067\u306F\u306A\u3044",
  "id" : 537958818705969152,
  "created_at" : "2014-11-27 13:19:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537958766772113409",
  "text" : "\u5BD2\u3044\u4E2D\u304B\u3048\u308B",
  "id" : 537958766772113409,
  "created_at" : "2014-11-27 13:18:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537958703178080256",
  "text" : "\u672C\u97F3\u3068\u5EFA\u524D\u3092\u9593\u9055\u3048\u308B\u306E\u697D\u3057\u3044",
  "id" : 537958703178080256,
  "created_at" : "2014-11-27 13:18:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537958369722507265",
  "geo" : { },
  "id_str" : "537958637897928705",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u79C1\u304C\u4EBA\u671B\u3060(\u307E\u308F\u308A\u306E\u4EBA\u9593\u306B\u6075\u307E\u308C\u3066\u3044\u308B\u3060\u3051\u3067\u3059\u3088\u30FC)",
  "id" : 537958637897928705,
  "in_reply_to_status_id" : 537958369722507265,
  "created_at" : "2014-11-27 13:18:28 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537958300709449729",
  "text" : "\u4EBA\u671B\u304C\u670D\u3092\u7740\u3066\u6B69\u3044\u3066\u3044\u308B\u3068\u601D\u3063\u305F\u3089\u79C1\u3060\u3063\u305F",
  "id" : 537958300709449729,
  "created_at" : "2014-11-27 13:17:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537957976003186688",
  "text" : "\u52B9\u7387\u53A8\u3060\u304B\u3089\u30DD\u30C3\u30C8\u306B\u6C34\u3044\u308C\u3066\u6CB8\u304B\u3057\u3066\u304B\u3089\u5E30\u308B",
  "id" : 537957976003186688,
  "created_at" : "2014-11-27 13:15:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537957707286736897",
  "text" : "\u305F\u306E\u3057\u3044\u304B\u3044\u308F\u3001\u3075\u3075\u3075\u3075\u3075",
  "id" : 537957707286736897,
  "created_at" : "2014-11-27 13:14:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537957665448542209",
  "text" : "\u308F\u304B\u308A\u3084\u3059\u3044\u304C\u610F\u5473\u306E\u306A\u3044\u4F1A\u8A71",
  "id" : 537957665448542209,
  "created_at" : "2014-11-27 13:14:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537910408569307136",
  "text" : "\u4E8C\u56DE\u30B9\u30FC\u30D1\u30FC\u3063\u3066\u306F\u3044\u308B\u306E",
  "id" : 537910408569307136,
  "created_at" : "2014-11-27 10:06:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537910339132616704",
  "text" : "\u30B9\u30FC\u30D1\u30FC\u30B0\u30ED\u30FC\u30D0\u30EB\u30B9\u30FC\u30D1\u30FC\u30AB\u30EA\u30D5\u30E9\u30B8\u30EA\u30B9\u30C6\u30A3\u30C3\u30AF\u30A8\u30AF\u30B9\u30D4\u30A2\u30EA\u30C9\u30FC\u30B7\u30E3\u30B9",
  "id" : 537910339132616704,
  "created_at" : "2014-11-27 10:06:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537910005685440513",
  "text" : "\u30B9\u30FC\u30D1\u30FC\u30B0\u30ED\u30FC\u30D0\u30EB\u307B\u3052 #",
  "id" : 537910005685440513,
  "created_at" : "2014-11-27 10:05:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537439973733974018",
  "text" : "\u4E94\u5104\u5E74\u3076\u308A\u306B\u56FA\u3044\u516B\u30C4\u6A4B\u98DF\u3079\u3066\u308B(\u304A\u3044\u3057\u3044)",
  "id" : 537439973733974018,
  "created_at" : "2014-11-26 02:57:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537277101330554880",
  "text" : "\u697D\u3057\u3044\u65E5\u3005\u3060\u3063\u305F\u2026",
  "id" : 537277101330554880,
  "created_at" : "2014-11-25 16:10:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537184802995052544",
  "text" : "\u6765\u5E74\u3082\u81EA\u7136\u306B\u884C\u304F\u6D41\u308C\u306B\u306A\u3063\u3066\u308B\u2026",
  "id" : 537184802995052544,
  "created_at" : "2014-11-25 10:03:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5341\u6708\u514E@\u6700\u9AD8\u306E\u590F",
      "screen_name" : "nekaya_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "271979824",
      "id" : 271979824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537184633842962432",
  "geo" : { },
  "id_str" : "537184740483162112",
  "in_reply_to_user_id" : 271979824,
  "text" : "@nekaya_bot \u3042\u30FC\u3001\u3042\u308B\u3068\u52A9\u304B\u308A\u307E\u3059\u306D",
  "id" : 537184740483162112,
  "in_reply_to_status_id" : 537184633842962432,
  "created_at" : "2014-11-25 10:03:17 +0000",
  "in_reply_to_screen_name" : "nekaya_bot",
  "in_reply_to_user_id_str" : "271979824",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5341\u6708\u514E@\u6700\u9AD8\u306E\u590F",
      "screen_name" : "nekaya_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "271979824",
      "id" : 271979824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537184215700213760",
  "geo" : { },
  "id_str" : "537184363406848001",
  "in_reply_to_user_id" : 271979824,
  "text" : "@nekaya_bot \u7A7A\u6E2F\u304B\u3089\u672D\u5E4C\u306B\u3080\u304B\u3063\u3066\u308B",
  "id" : 537184363406848001,
  "in_reply_to_status_id" : 537184215700213760,
  "created_at" : "2014-11-25 10:01:47 +0000",
  "in_reply_to_screen_name" : "nekaya_bot",
  "in_reply_to_user_id_str" : "271979824",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537182069109956608",
  "text" : "\u65E7\u652F\u914D\u8005\u306E\u30AD\u30E3\u30ED\u30EB\u304C\u982D\u304B\u3089\u96E2\u308C\u306A\u3044\u6642\u304C\u3042\u308B",
  "id" : 537182069109956608,
  "created_at" : "2014-11-25 09:52:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537180432517722112",
  "text" : "\u5317\u6D77\u9053\u3001\u5BA4\u5185\u6691\u3044\u3057\u5BA4\u5916\u5BD2\u3044",
  "id" : 537180432517722112,
  "created_at" : "2014-11-25 09:46:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537175019005022210",
  "geo" : { },
  "id_str" : "537175126333071360",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u306F\u3041",
  "id" : 537175126333071360,
  "in_reply_to_status_id" : 537175019005022210,
  "created_at" : "2014-11-25 09:25:05 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537172627656171521",
  "geo" : { },
  "id_str" : "537172851116109824",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u4ECA\u65E5\u6301\u3063\u3066\u304F\u5143\u6C17\u306F\u306A\u3044\u3088",
  "id" : 537172851116109824,
  "in_reply_to_status_id" : 537172627656171521,
  "created_at" : "2014-11-25 09:16:02 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537172326840680448",
  "geo" : { },
  "id_str" : "537172437150887936",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u305D\u3046\u306A\u3093\u3067\u3059\u304B\u2026",
  "id" : 537172437150887936,
  "in_reply_to_status_id" : 537172326840680448,
  "created_at" : "2014-11-25 09:14:23 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537172218191417344",
  "geo" : { },
  "id_str" : "537172392108244992",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u3068\u308A\u306B\u3053\u3044(?)",
  "id" : 537172392108244992,
  "in_reply_to_status_id" : 537172218191417344,
  "created_at" : "2014-11-25 09:14:13 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537172267222827008",
  "text" : "\u80CC\u306B\u8179\u306F\u5909\u3048\u3089\u308C\u306C\u306E\u3058\u3083",
  "id" : 537172267222827008,
  "created_at" : "2014-11-25 09:13:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537172209618272257",
  "text" : "\u305D\u3057\u3066\u5B89\u3044\u30D2\u30B3\u30FC\u30AD\u306F\u4F53\u304C\u75B2\u308C\u308B\u306E\u3058\u3083",
  "id" : 537172209618272257,
  "created_at" : "2014-11-25 09:13:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537171919921897472",
  "geo" : { },
  "id_str" : "537172109089177600",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u589C\u843D\u304B\u306A\uFF1F",
  "id" : 537172109089177600,
  "in_reply_to_status_id" : 537171919921897472,
  "created_at" : "2014-11-25 09:13:05 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537172045545496577",
  "text" : "\u65B0\u5343\u6B73\u3001\u5BD2\u3044",
  "id" : 537172045545496577,
  "created_at" : "2014-11-25 09:12:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537171093019049984",
  "text" : "\u3075\u3058\u3061\u3083\u304F\u3057\u305F\u308F\u3051\u3067\u306F\u306A\u3044",
  "id" : 537171093019049984,
  "created_at" : "2014-11-25 09:09:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537171054926364672",
  "text" : "\u3076\u3058\u3061\u3083\u304F\u308A\u304F\u3057\u305F",
  "id" : 537171054926364672,
  "created_at" : "2014-11-25 09:08:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537140932764659712",
  "text" : "\u3072\u3053\u30FC\u304D\u306B\u306E\u3063\u3066\u304B\u3048\u308B",
  "id" : 537140932764659712,
  "created_at" : "2014-11-25 07:09:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537075988698382336",
  "geo" : { },
  "id_str" : "537076406723686400",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u300C\u4F55\u8A00\u3063\u3066\u3093\u3060\u3053\u3044\u3064...\u300D(\u4F55\u8A00\u3063\u3066\u3093\u3060)",
  "id" : 537076406723686400,
  "in_reply_to_status_id" : 537075988698382336,
  "created_at" : "2014-11-25 02:52:48 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 0, 9 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537075824030011392",
  "geo" : { },
  "id_str" : "537076096504578048",
  "in_reply_to_user_id" : 2306283966,
  "text" : "@tenapyon \u706B\u66DC\u65E5\u306B\u3042\u3063\u3066\u306F\u3053\u308C\u3092\u8A31\u53EF\u3059\u308B\u3001\u3068\u7B2C\u4E8C\u6761\u306B\u6761\u6587\u304C\u3042\u308A\u307E\u3059",
  "id" : 537076096504578048,
  "in_reply_to_status_id" : 537075824030011392,
  "created_at" : "2014-11-25 02:51:34 +0000",
  "in_reply_to_screen_name" : "tenapyon",
  "in_reply_to_user_id_str" : "2306283966",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537075071634771969",
  "geo" : { },
  "id_str" : "537075152379322368",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u304A\u571F\u7523\u306F\u307E\u304B\u305B\u308D\u30FC(\u30D0\u30EA\u30D0\u30EA",
  "id" : 537075152379322368,
  "in_reply_to_status_id" : 537075071634771969,
  "created_at" : "2014-11-25 02:47:49 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537074760702652416",
  "geo" : { },
  "id_str" : "537075088370044928",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u4E09\u6761\u306F\u306D\u3001\u4E2D\u4EAC\u533A",
  "id" : 537075088370044928,
  "in_reply_to_status_id" : 537074760702652416,
  "created_at" : "2014-11-25 02:47:34 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537073847535538176",
  "text" : "\u3088\u3057",
  "id" : 537073847535538176,
  "created_at" : "2014-11-25 02:42:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537073814903877632",
  "text" : "\u4E09\u6761\u306B\u53C2\u4E0A",
  "id" : 537073814903877632,
  "created_at" : "2014-11-25 02:42:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537073766845534208",
  "text" : "\u4E09\u6761\u306B\u3001\u3069\u3046\u3057\u305F\u3068\u601D\u3046\uFF1F",
  "id" : 537073766845534208,
  "created_at" : "2014-11-25 02:42:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537063386387709953",
  "geo" : { },
  "id_str" : "537063474329690113",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u3042\u307E\u308A\u624B\u4F1D\u3048\u306A\u304F\u3066\u7533\u3057\u8A33 of the world",
  "id" : 537063474329690113,
  "in_reply_to_status_id" : 537063386387709953,
  "created_at" : "2014-11-25 02:01:25 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537062811810021376",
  "geo" : { },
  "id_str" : "537063186554290178",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u5DE6\u306E\u306F\u305F\u3076\u3093\u5099\u54C1(\u305F\u3076\u3093)",
  "id" : 537063186554290178,
  "in_reply_to_status_id" : 537062811810021376,
  "created_at" : "2014-11-25 02:00:16 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536715621640048640",
  "text" : "\u30B3\u30DF\u30FC\u304C\u7169\u3044",
  "id" : 536715621640048640,
  "created_at" : "2014-11-24 02:59:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536548469473677313",
  "geo" : { },
  "id_str" : "536557982884966400",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u304A\u3084\u3059\u307F",
  "id" : 536557982884966400,
  "in_reply_to_status_id" : 536548469473677313,
  "created_at" : "2014-11-23 16:32:46 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536516480221736960",
  "text" : "\u307E\u3063\u3001\u307E\u3063",
  "id" : 536516480221736960,
  "created_at" : "2014-11-23 13:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536458909200822272",
  "text" : "@desole_mi \u307B\u3093\u306E\u308A\u9045\u308C\u307E\u3059",
  "id" : 536458909200822272,
  "created_at" : "2014-11-23 09:59:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536425917250142208",
  "geo" : { },
  "id_str" : "536425955313451008",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536425955313451008,
  "in_reply_to_status_id" : 536425917250142208,
  "created_at" : "2014-11-23 07:48:08 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536407305055502336",
  "text" : "\u540D\u72B6\u3057\u96E3\u3044\u5100\u5F0F\u304C\u884C\u308F\u308C\u3066\u3044\u308B #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536407305055502336,
  "created_at" : "2014-11-23 06:34:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 9, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536406436004118529",
  "text" : "\u3060\u3044\u305F\u3044\u3042\u3063\u3066\u308B #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536406436004118529,
  "created_at" : "2014-11-23 06:30:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 3, 19 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536406408980221952",
  "text" : "RT @yurariandnorari: \u5171\u5317\u3067\u30AB\u30EB\u30C8\u56E3\u4F53\u304C\u96C6\u4F1A\u3092\u958B\u3044\u3066\u3044\u308B\u304B\u3089\u3001\u3046\u3063\u304B\u308A\u5165\u3089\u306A\u3044\u3088\u3046\u306B\u6C17\u3092\u3064\u3051\u3066\u3002\u4EFB\u610F\u306E\u5024\u6BB5\u3067\u8B0E\u306E\u30C9\u30EA\u30F3\u30AF\u3092\u58F2\u308A\u3064\u3051\u3066\u304F\u308B\u4E0A\u306B\u3001\u6559\u7956\u306B\u5411\u3051\u3066\u72C2\u6C17\u306B\u6E80\u3061\u305F\u8A93\u3044\u306E\u8A00\u8449\u3092\u5BA3\u8A93\u3055\u305B\u3089\u308C\u308B\n\n\u62E1\u6563\u5E0C\u671B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "536406268332621824",
    "text" : "\u5171\u5317\u3067\u30AB\u30EB\u30C8\u56E3\u4F53\u304C\u96C6\u4F1A\u3092\u958B\u3044\u3066\u3044\u308B\u304B\u3089\u3001\u3046\u3063\u304B\u308A\u5165\u3089\u306A\u3044\u3088\u3046\u306B\u6C17\u3092\u3064\u3051\u3066\u3002\u4EFB\u610F\u306E\u5024\u6BB5\u3067\u8B0E\u306E\u30C9\u30EA\u30F3\u30AF\u3092\u58F2\u308A\u3064\u3051\u3066\u304F\u308B\u4E0A\u306B\u3001\u6559\u7956\u306B\u5411\u3051\u3066\u72C2\u6C17\u306B\u6E80\u3061\u305F\u8A93\u3044\u306E\u8A00\u8449\u3092\u5BA3\u8A93\u3055\u305B\u3089\u308C\u308B\n\n\u62E1\u6563\u5E0C\u671B",
    "id" : 536406268332621824,
    "created_at" : "2014-11-23 06:29:54 +0000",
    "user" : {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "protected" : true,
      "id_str" : "136960189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3426265315\/a47b474b23b0d97bf084e80c2181c199_normal.jpeg",
      "id" : 136960189,
      "verified" : false
    }
  },
  "id" : 536406408980221952,
  "created_at" : "2014-11-23 06:30:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536406051864600577",
  "text" : "TL\u5236\u5727\u7CFB\u30A4\u30D9\u30F3\u30C8 #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536406051864600577,
  "created_at" : "2014-11-23 06:29:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u771F\u7530",
      "screen_name" : "zzzzrh",
      "indices" : [ 0, 7 ],
      "id_str" : "114961544",
      "id" : 114961544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536405314090713088",
  "geo" : { },
  "id_str" : "536405865327108097",
  "in_reply_to_user_id" : 114961544,
  "text" : "@zzzzrh \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405865327108097,
  "in_reply_to_status_id" : 536405314090713088,
  "created_at" : "2014-11-23 06:28:18 +0000",
  "in_reply_to_screen_name" : "zzzzrh",
  "in_reply_to_user_id_str" : "114961544",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3050\u3057\u3085\u3050\u3057\u3085",
      "screen_name" : "moiaia",
      "indices" : [ 0, 7 ],
      "id_str" : "126934587",
      "id" : 126934587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404929812774913",
  "geo" : { },
  "id_str" : "536405649823789056",
  "in_reply_to_user_id" : 126934587,
  "text" : "@moiaia \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405649823789056,
  "in_reply_to_status_id" : 536404929812774913,
  "created_at" : "2014-11-23 06:27:27 +0000",
  "in_reply_to_screen_name" : "moiaia",
  "in_reply_to_user_id_str" : "126934587",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404919075364864",
  "geo" : { },
  "id_str" : "536405627300376576",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01 \uFF01",
  "id" : 536405627300376576,
  "in_reply_to_status_id" : 536404919075364864,
  "created_at" : "2014-11-23 06:27:22 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DhiArk",
      "screen_name" : "dhi_ark",
      "indices" : [ 0, 8 ],
      "id_str" : "116467602",
      "id" : 116467602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404903141208064",
  "geo" : { },
  "id_str" : "536405544882302976",
  "in_reply_to_user_id" : 116467602,
  "text" : "@dhi_ark \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405544882302976,
  "in_reply_to_status_id" : 536404903141208064,
  "created_at" : "2014-11-23 06:27:02 +0000",
  "in_reply_to_screen_name" : "dhi_ark",
  "in_reply_to_user_id_str" : "116467602",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404866902409216",
  "geo" : { },
  "id_str" : "536405501852938241",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405501852938241,
  "in_reply_to_status_id" : 536404866902409216,
  "created_at" : "2014-11-23 06:26:52 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5DE5\u5834\u9577",
      "screen_name" : "koujou_chou",
      "indices" : [ 0, 12 ],
      "id_str" : "236004185",
      "id" : 236004185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404816247795712",
  "geo" : { },
  "id_str" : "536405466176180224",
  "in_reply_to_user_id" : 236004185,
  "text" : "@koujou_chou \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405466176180224,
  "in_reply_to_status_id" : 536404816247795712,
  "created_at" : "2014-11-23 06:26:43 +0000",
  "in_reply_to_screen_name" : "koujou_chou",
  "in_reply_to_user_id_str" : "236004185",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feru",
      "screen_name" : "Feru54604",
      "indices" : [ 0, 10 ],
      "id_str" : "78560756",
      "id" : 78560756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404801777459201",
  "geo" : { },
  "id_str" : "536405435369017345",
  "in_reply_to_user_id" : 78560756,
  "text" : "@Feru54604 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405435369017345,
  "in_reply_to_status_id" : 536404801777459201,
  "created_at" : "2014-11-23 06:26:36 +0000",
  "in_reply_to_screen_name" : "Feru54604",
  "in_reply_to_user_id_str" : "78560756",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404798719803392",
  "geo" : { },
  "id_str" : "536405416540774400",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405416540774400,
  "in_reply_to_status_id" : 536404798719803392,
  "created_at" : "2014-11-23 06:26:31 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3056\u3079\u3059",
      "screen_name" : "Elizabeth_H_01",
      "indices" : [ 0, 15 ],
      "id_str" : "323566206",
      "id" : 323566206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404797750915072",
  "geo" : { },
  "id_str" : "536405371057745920",
  "in_reply_to_user_id" : 323566206,
  "text" : "@Elizabeth_H_01 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405371057745920,
  "in_reply_to_status_id" : 536404797750915072,
  "created_at" : "2014-11-23 06:26:21 +0000",
  "in_reply_to_screen_name" : "Elizabeth_H_01",
  "in_reply_to_user_id_str" : "323566206",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3057\u3083\u3053",
      "screen_name" : "nashacom",
      "indices" : [ 0, 9 ],
      "id_str" : "90918872",
      "id" : 90918872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404797524410369",
  "geo" : { },
  "id_str" : "536405352040787968",
  "in_reply_to_user_id" : 90918872,
  "text" : "@nashacom \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405352040787968,
  "in_reply_to_status_id" : 536404797524410369,
  "created_at" : "2014-11-23 06:26:16 +0000",
  "in_reply_to_screen_name" : "nashacom",
  "in_reply_to_user_id_str" : "90918872",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404795414683648",
  "geo" : { },
  "id_str" : "536405335779467266",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405335779467266,
  "in_reply_to_status_id" : 536404795414683648,
  "created_at" : "2014-11-23 06:26:12 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404784148803584",
  "geo" : { },
  "id_str" : "536405315034419200",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405315034419200,
  "in_reply_to_status_id" : 536404784148803584,
  "created_at" : "2014-11-23 06:26:07 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u3093\u3055\u304F",
      "screen_name" : "nun_tya_ku",
      "indices" : [ 0, 11 ],
      "id_str" : "524020583",
      "id" : 524020583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404782185840641",
  "geo" : { },
  "id_str" : "536405294901755904",
  "in_reply_to_user_id" : 524020583,
  "text" : "@nun_tya_ku \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405294901755904,
  "in_reply_to_status_id" : 536404782185840641,
  "created_at" : "2014-11-23 06:26:02 +0000",
  "in_reply_to_screen_name" : "nun_tya_ku",
  "in_reply_to_user_id_str" : "524020583",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3063\u3053@\u3073\u3058\u3093\u306B\u306A\u308A\u305F\u3044",
      "screen_name" : "kikko_34a",
      "indices" : [ 0, 10 ],
      "id_str" : "1008547748",
      "id" : 1008547748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404780986298368",
  "geo" : { },
  "id_str" : "536405276849496064",
  "in_reply_to_user_id" : 1008547748,
  "text" : "@kikko_34a \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405276849496064,
  "in_reply_to_status_id" : 536404780986298368,
  "created_at" : "2014-11-23 06:25:58 +0000",
  "in_reply_to_screen_name" : "kikko_34a",
  "in_reply_to_user_id_str" : "1008547748",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3081\u3044\u3058\u3093@\u3081\u3044\u3058\u3093",
      "screen_name" : "meijin56",
      "indices" : [ 0, 9 ],
      "id_str" : "138650695",
      "id" : 138650695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404780814315521",
  "geo" : { },
  "id_str" : "536405253944389632",
  "in_reply_to_user_id" : 138650695,
  "text" : "@meijin56 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405253944389632,
  "in_reply_to_status_id" : 536404780814315521,
  "created_at" : "2014-11-23 06:25:53 +0000",
  "in_reply_to_screen_name" : "meijin56",
  "in_reply_to_user_id_str" : "138650695",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404779589566465",
  "geo" : { },
  "id_str" : "536405236160528384",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405236160528384,
  "in_reply_to_status_id" : 536404779589566465,
  "created_at" : "2014-11-23 06:25:48 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3063\u3069\u30FC",
      "screen_name" : "ido_d",
      "indices" : [ 0, 6 ],
      "id_str" : "335231130",
      "id" : 335231130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404776892645376",
  "geo" : { },
  "id_str" : "536405219211374592",
  "in_reply_to_user_id" : 335231130,
  "text" : "@ido_d \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405219211374592,
  "in_reply_to_status_id" : 536404776892645376,
  "created_at" : "2014-11-23 06:25:44 +0000",
  "in_reply_to_screen_name" : "ido_d",
  "in_reply_to_user_id_str" : "335231130",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404775315587073",
  "geo" : { },
  "id_str" : "536405199586197504",
  "in_reply_to_user_id" : 547547290,
  "text" : "@oPAKILIFEo \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405199586197504,
  "in_reply_to_status_id" : 536404775315587073,
  "created_at" : "2014-11-23 06:25:40 +0000",
  "in_reply_to_screen_name" : "kussy_tessy",
  "in_reply_to_user_id_str" : "547547290",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3057\u30FC",
      "screen_name" : "oPAKILAo",
      "indices" : [ 0, 9 ],
      "id_str" : "547544213",
      "id" : 547544213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404775286226944",
  "geo" : { },
  "id_str" : "536405181395517440",
  "in_reply_to_user_id" : 547544213,
  "text" : "@oPAKILAo \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405181395517440,
  "in_reply_to_status_id" : 536404775286226944,
  "created_at" : "2014-11-23 06:25:35 +0000",
  "in_reply_to_screen_name" : "oPAKILAo",
  "in_reply_to_user_id_str" : "547544213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u3067\u3082\u307F\u306A\u307F\u3093",
      "screen_name" : "37min_",
      "indices" : [ 0, 7 ],
      "id_str" : "544825981",
      "id" : 544825981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404774443184128",
  "geo" : { },
  "id_str" : "536405157139845120",
  "in_reply_to_user_id" : 544825981,
  "text" : "@37min_ \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405157139845120,
  "in_reply_to_status_id" : 536404774443184128,
  "created_at" : "2014-11-23 06:25:30 +0000",
  "in_reply_to_screen_name" : "37min_",
  "in_reply_to_user_id_str" : "544825981",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D14\u3061\u3083\u3093",
      "screen_name" : "ahh_Jun",
      "indices" : [ 0, 8 ],
      "id_str" : "91919197",
      "id" : 91919197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404773444915200",
  "geo" : { },
  "id_str" : "536405135832801280",
  "in_reply_to_user_id" : 91919197,
  "text" : "@ahh_Jun \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405135832801280,
  "in_reply_to_status_id" : 536404773444915200,
  "created_at" : "2014-11-23 06:25:24 +0000",
  "in_reply_to_screen_name" : "ahh_Jun",
  "in_reply_to_user_id_str" : "91919197",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404773142929410",
  "geo" : { },
  "id_str" : "536405118225117184",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405118225117184,
  "in_reply_to_status_id" : 536404773142929410,
  "created_at" : "2014-11-23 06:25:20 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u307F\u306A\u3061\u3083\u3093",
      "screen_name" : "rumichang",
      "indices" : [ 0, 10 ],
      "id_str" : "242763253",
      "id" : 242763253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404771670745089",
  "geo" : { },
  "id_str" : "536405097064845312",
  "in_reply_to_user_id" : 242763253,
  "text" : "@rumichang \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405097064845312,
  "in_reply_to_status_id" : 536404771670745089,
  "created_at" : "2014-11-23 06:25:15 +0000",
  "in_reply_to_screen_name" : "rumichang",
  "in_reply_to_user_id_str" : "242763253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tencuss",
      "screen_name" : "tencuss",
      "indices" : [ 0, 8 ],
      "id_str" : "184510823",
      "id" : 184510823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404769770713088",
  "geo" : { },
  "id_str" : "536405079557799936",
  "in_reply_to_user_id" : 184510823,
  "text" : "@tencuss \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405079557799936,
  "in_reply_to_status_id" : 536404769770713088,
  "created_at" : "2014-11-23 06:25:11 +0000",
  "in_reply_to_screen_name" : "tencuss",
  "in_reply_to_user_id_str" : "184510823",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404766629187585",
  "geo" : { },
  "id_str" : "536405056325554176",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405056325554176,
  "in_reply_to_status_id" : 536404766629187585,
  "created_at" : "2014-11-23 06:25:06 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404764796264448",
  "geo" : { },
  "id_str" : "536405036658466817",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405036658466817,
  "in_reply_to_status_id" : 536404764796264448,
  "created_at" : "2014-11-23 06:25:01 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5341\u6708\u514E@\u6700\u9AD8\u306E\u590F",
      "screen_name" : "nekaya_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "271979824",
      "id" : 271979824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404763244367872",
  "geo" : { },
  "id_str" : "536405016106377217",
  "in_reply_to_user_id" : 271979824,
  "text" : "@nekaya_bot \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536405016106377217,
  "in_reply_to_status_id" : 536404763244367872,
  "created_at" : "2014-11-23 06:24:56 +0000",
  "in_reply_to_screen_name" : "nekaya_bot",
  "in_reply_to_user_id_str" : "271979824",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404763202428928",
  "geo" : { },
  "id_str" : "536404996955176963",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536404996955176963,
  "in_reply_to_status_id" : 536404763202428928,
  "created_at" : "2014-11-23 06:24:51 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404761298219008",
  "geo" : { },
  "id_str" : "536404976034017280",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536404976034017280,
  "in_reply_to_status_id" : 536404761298219008,
  "created_at" : "2014-11-23 06:24:46 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3084\u30BF\u30B3\u30B9(\u261D \u055E\u0A0A \u055E)\u261D",
      "screen_name" : "miya_tacos",
      "indices" : [ 0, 11 ],
      "id_str" : "747261714",
      "id" : 747261714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404761017208832",
  "geo" : { },
  "id_str" : "536404954215219202",
  "in_reply_to_user_id" : 747261714,
  "text" : "@miya_tacos \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536404954215219202,
  "in_reply_to_status_id" : 536404761017208832,
  "created_at" : "2014-11-23 06:24:41 +0000",
  "in_reply_to_screen_name" : "miya_tacos",
  "in_reply_to_user_id_str" : "747261714",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536404760371273728",
  "geo" : { },
  "id_str" : "536404931905728512",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 536404931905728512,
  "in_reply_to_status_id" : 536404760371273728,
  "created_at" : "2014-11-23 06:24:36 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536404766352371712",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30FB\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046 #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536404766352371712,
  "created_at" : "2014-11-23 06:23:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 7, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536404597758124033",
  "text" : "\u305F\u3044\u304D\u305F\u3044\u304D #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536404597758124033,
  "created_at" : "2014-11-23 06:23:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536403547361771520",
  "text" : "\uFF85\uFF6F\uFF7C\uFF6C\uFF67\uFF67\uFF67\uFF67\uFF67\uFF71\uFF67\uFF67\uFF67 #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536403547361771520,
  "created_at" : "2014-11-23 06:19:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 30, 39 ],
      "id_str" : "137961719",
      "id" : 137961719
    }, {
      "name" : "\u304D\u3063\u3053@\u3073\u3058\u3093\u306B\u306A\u308A\u305F\u3044",
      "screen_name" : "kikko_34a",
      "indices" : [ 40, 50 ],
      "id_str" : "1008547748",
      "id" : 1008547748
    }, {
      "name" : "\u7D14\u3061\u3083\u3093",
      "screen_name" : "ahh_Jun",
      "indices" : [ 51, 59 ],
      "id_str" : "91919197",
      "id" : 91919197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/3Z4ncaa34A",
      "expanded_url" : "https:\/\/foursquare.com\/end313124\/checkin\/54717c3d498ee1b452f91996?s=vlXLvPEiUJ8V1P1_P8PILPsw56Q&ref=tw",
      "display_url" : "foursquare.com\/end313124\/chec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536403428160061440",
  "text" : "#\u3084\u308B\u3081\u3053\u3042 (@ \u4EAC\u90FD\u5927\u5B66 \u5409\u7530\u5357\u7DCF\u5408\u9928 \u5171\u531735 w\/ @pankashi @kikko_34a @ahh_jun) https:\/\/t.co\/3Z4ncaa34A",
  "id" : 536403428160061440,
  "created_at" : "2014-11-23 06:18:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536400956355670016",
  "text" : "\u8001\u5BB3\u7387\u306E\u9AD8\u3055\u2026 #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536400956355670016,
  "created_at" : "2014-11-23 06:08:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536400349372751872",
  "text" : "15\u6642\u306B\u306A\u308A\u307E\u3057\u305F\u304C\u30B0\u30ED\u30FC\u30D0\u30EB\u30CA\u30B7\u30E3\u30B3\u30BF\u30A4\u30E0\u306E\u3058\u3055\u304C\u3042\u308B\u306E\u3067\u4F1A\u5834\u306F\u307E\u306015:00\u3058\u3083\u306A\u3044 #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536400349372751872,
  "created_at" : "2014-11-23 06:06:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u308B\u3081\u3053\u3042",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536399923919339520",
  "text" : "\u305F\u3044\u3080\u3089\u3044\u3093\u3059\u307D\u3044\u3089\u30FC #\u3084\u308B\u3081\u3053\u3042",
  "id" : 536399923919339520,
  "created_at" : "2014-11-23 06:04:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536398480684511233",
  "text" : "\u306A\u3057\u3083\u3053\u5F85\u3061",
  "id" : 536398480684511233,
  "created_at" : "2014-11-23 05:58:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536358736936202240",
  "text" : "\u30A6\u30A3\u30C3\u30B7\u30E5\u30EA\u30B9\u30C8\u3060\u304B\u3089\u304B\u306A\u2026",
  "id" : 536358736936202240,
  "created_at" : "2014-11-23 03:21:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536358692539478016",
  "text" : "\u307E\u305B\u308A\u3055\u3093\u306E\u30A6\u30A3\u30C3\u30B7\u30E5\u30EA\u30B9\u30C8\u3001\u8981\u3089\u306A\u3055\u305D\u3046\u306A\u3082\u306E\u304C\u5165\u3063\u3066\u306A\u3044",
  "id" : 536358692539478016,
  "created_at" : "2014-11-23 03:20:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536356915702267905",
  "text" : "\u3084\u308B\u3081\u3053\u3042\u3001TL\u307F\u308B\u9650\u308A\u5D50\u306E\u524D\u306E\u9759\u3051\u3055",
  "id" : 536356915702267905,
  "created_at" : "2014-11-23 03:13:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/orYjdKBYIl",
      "expanded_url" : "http:\/\/4sq.com\/11IMPIn",
      "display_url" : "4sq.com\/11IMPIn"
    } ]
  },
  "geo" : { },
  "id_str" : "536354850771308544",
  "text" : "\u3046\u3049\u30A9\u30F3 (@ \u30AD\u30C3\u30C1\u30F3\u3054\u308A\u3089 in \u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/orYjdKBYIl",
  "id" : 536354850771308544,
  "created_at" : "2014-11-23 03:05:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536339585341485056",
  "text" : "\u3084\u308B\u3081\u3053\u3042\u3001\u3054\u98EF\u98DF\u3079\u305F\u3089\u5411\u304B\u3044\u307E\u3059",
  "id" : 536339585341485056,
  "created_at" : "2014-11-23 02:04:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536206640836403202",
  "text" : "\u5C0F\u6CC9\u3055\u3093\u3068\u5168\u304F\u4F3C\u305F\u3088\u3046\u306A\u601D\u8003\u56DE\u8DEF\u3092\u3057\u3066\u308B(\u50D5\u306F\u663C\u3067\u3059\u304C)",
  "id" : 536206640836403202,
  "created_at" : "2014-11-22 17:16:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536205793419210753",
  "text" : "\u5C0F\u5B664\u5E74\u751F\u306E\u3075\u308A\u3092\u3057\u305D\u3073\u308C\u3066\u71C3\u3048\u4E0A\u304C\u3063\u305FNPO\u6CD5\u4EBA(\u7B11)\u304C\u5B58\u5728\u3059\u308B\u3089\u3057\u3044\u306A\uFF1F",
  "id" : 536205793419210753,
  "created_at" : "2014-11-22 17:13:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536204799138484225",
  "geo" : { },
  "id_str" : "536205074897190912",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u30A8\u30B3\u30ED\u30B8\u30FC\u3001\u3055\u306A\u304C\u3089\u30C4\u30AD\u30B8",
  "id" : 536205074897190912,
  "in_reply_to_status_id" : 536204799138484225,
  "created_at" : "2014-11-22 17:10:26 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536204323487621120",
  "geo" : { },
  "id_str" : "536204402713845760",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u30A8\u30B3\u3067\u3059\u306D",
  "id" : 536204402713845760,
  "in_reply_to_status_id" : 536204323487621120,
  "created_at" : "2014-11-22 17:07:46 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536203971652636672",
  "geo" : { },
  "id_str" : "536204021766176768",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u751F\u304D\u3066\u3044\u306A\u3051\u308C\u3070\uFF1F",
  "id" : 536204021766176768,
  "in_reply_to_status_id" : 536203971652636672,
  "created_at" : "2014-11-22 17:06:15 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536202138058104833",
  "geo" : { },
  "id_str" : "536202271999021057",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u3088\u3063\u307D\u3069\u5834\u6240\u3092\u77E5\u3089\u308C\u305F\u304F\u306A\u3044\u3068\u898B\u3048\u307E\u3059\u306D\u2026",
  "id" : 536202271999021057,
  "in_reply_to_status_id" : 536202138058104833,
  "created_at" : "2014-11-22 16:59:18 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536201184151744512",
  "geo" : { },
  "id_str" : "536201245652815872",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u5618",
  "id" : 536201245652815872,
  "in_reply_to_status_id" : 536201184151744512,
  "created_at" : "2014-11-22 16:55:13 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536200714091913216",
  "geo" : { },
  "id_str" : "536200895914971139",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u5143\u306E(?)\u3068\u5408\u308F\u305B\u30663\u901A\u308A\u3067\u3059\u306D\u3001\u8AA4\u89E3\u3092\u3068\u3066\u3082\u62DB\u304D\u3084\u3059\u3044\u8868\u73FE\u3067\u3042\u308B\u3053\u3068\u304C\u308F\u304B\u308B",
  "id" : 536200895914971139,
  "in_reply_to_status_id" : 536200714091913216,
  "created_at" : "2014-11-22 16:53:50 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536200273505439746",
  "geo" : { },
  "id_str" : "536200435032276993",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u4E8C\u6761\u99C5\u306B\u3042\u308Band\u3089\u3044 \u3067\u306F",
  "id" : 536200435032276993,
  "in_reply_to_status_id" : 536200273505439746,
  "created_at" : "2014-11-22 16:52:00 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536200112889135104",
  "geo" : { },
  "id_str" : "536200180362534912",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u4EFB\u305B\u308D",
  "id" : 536200180362534912,
  "in_reply_to_status_id" : 536200112889135104,
  "created_at" : "2014-11-22 16:50:59 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536199978994401280",
  "geo" : { },
  "id_str" : "536200049542193152",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u306A\u308B\u307B\u3069\u5931\u793C\u3057\u305F",
  "id" : 536200049542193152,
  "in_reply_to_status_id" : 536199978994401280,
  "created_at" : "2014-11-22 16:50:28 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536199503867416576",
  "geo" : { },
  "id_str" : "536199634029277184",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u3068\u3093\u3068\u3093\uFF1F",
  "id" : 536199634029277184,
  "in_reply_to_status_id" : 536199503867416576,
  "created_at" : "2014-11-22 16:48:49 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536018596258791425",
  "text" : "\u3084\u308B\u3081\u3053\u3042",
  "id" : 536018596258791425,
  "created_at" : "2014-11-22 04:49:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535813571137900545",
  "text" : "\u306E\u306A\u3061\u3083\u3093\u60C5\u5831\u51E6\u7406\u90E8\u306F\uFF1F",
  "id" : 535813571137900545,
  "created_at" : "2014-11-21 15:14:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535810300071522305",
  "text" : "\u4ECA\u5E74\u306F\u60C5\u5831\u51E6\u7406\u90E8\u3082\u6D3B\u52D5\u3057\u3066\u306A\u3044\u306E\u304B\u306A\uFF1F",
  "id" : 535810300071522305,
  "created_at" : "2014-11-21 15:01:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535809804875227136",
  "text" : "\u305B\u3063\u304B\u304FTRPG\u306B\u8208\u5473\u304C\u51FA\u3066\u304D\u305F\u304B\u3089TRPG\u7814\u3092\u8997\u3044\u3066\u307F\u3088\u3046\u3068\u601D\u3063\u305F\u304C\u4F01\u753B\u3057\u3066\u306A\u3044\u3063\u307D\u3044\u306A\uFF1F",
  "id" : 535809804875227136,
  "created_at" : "2014-11-21 14:59:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535771248991535105",
  "text" : "\u3068\u3044\u3046\u304B\u3001\u8131\u51FA\u3057\u305F\u4EBA\u9593\u306F\u6B8B\u6570\u306B\u6570\u3048\u3066\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u3060\u308D\u3046\u304B",
  "id" : 535771248991535105,
  "created_at" : "2014-11-21 12:26:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535770838851538944",
  "text" : "\u6DF1\u304D\u3082\u306E",
  "id" : 535770838851538944,
  "created_at" : "2014-11-21 12:24:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535770398189551616",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 535770398189551616,
  "created_at" : "2014-11-21 12:23:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535770383983464449",
  "text" : "\u30AB\u30A8\u30EB\u304C\u558B\u308B\u306A\u3069\u3068\u3044\u3046\u975E\u73FE\u5B9F\u7684\u306A\u4E16\u754C\u3092\u76EE\u306E\u5F53\u305F\u308A\u306B\u3057\u3066\u3057\u307E\u3063\u305F\u5343\u5C0B\u306FSAN\u30C1\u30A7\u30C3\u30AF\u3067\u3059",
  "id" : 535770383983464449,
  "created_at" : "2014-11-21 12:23:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535769899931406338",
  "text" : "\u5927\u5BCC\u8C6A\u4EBA\u72FC\u3001\u8FD1\u5E74\u7A00\u306B\u898B\u308B\u30AF\u30BD\u30B2\u30FC\u3060\u3063\u305F",
  "id" : 535769899931406338,
  "created_at" : "2014-11-21 12:21:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535647723462987777",
  "text" : "\u30B5\u30D6\u30A6\u30A7\u30A4\u5BC4\u308B\u3060\u308D",
  "id" : 535647723462987777,
  "created_at" : "2014-11-21 04:15:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535644929871986688",
  "geo" : { },
  "id_str" : "535645017344200706",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u307E\u3057\u305F",
  "id" : 535645017344200706,
  "in_reply_to_status_id" : 535644929871986688,
  "created_at" : "2014-11-21 04:04:58 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535644862561796096",
  "text" : "\u5B9F\u969B\u6628\u65E5\u306E\u591C\u306E\u982D\u75DB\u306F\u4ECA\u5E74\u6700\u60AA\u306E\u3082\u306E\u3060\u3063\u305F\u3057\u306A(\u3067\u3082\u9EBB\u96C0\u306F\u3067\u304D\u305F)",
  "id" : 535644862561796096,
  "created_at" : "2014-11-21 04:04:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535644542695784448",
  "text" : "\u75B2\u308C\u3066\u305F\u306E\u304B10\u6642\u9593\u4EE5\u4E0A\u5BDD\u3066\u3057\u307E\u3063\u3066\u306A\u2026",
  "id" : 535644542695784448,
  "created_at" : "2014-11-21 04:03:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535638747560161280",
  "text" : "\u3044\u307E\u304A\u304D\u305F",
  "id" : 535638747560161280,
  "created_at" : "2014-11-21 03:40:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535410927860871168",
  "geo" : { },
  "id_str" : "535412975125811200",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u306F\u3042\u304F",
  "id" : 535412975125811200,
  "in_reply_to_status_id" : 535410927860871168,
  "created_at" : "2014-11-20 12:42:55 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535400971858223104",
  "text" : "@desole_mi \u8A73\u7D30\u9069\u5F53\u306B\u9023\u7D61\u3057\u3066\u304F\u3060\u3055\u308C\u30FC",
  "id" : 535400971858223104,
  "created_at" : "2014-11-20 11:55:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535400695575228416",
  "text" : "\u307F\u305E\u308C\u934B\u3001\u305B\u3063\u304B\u304F\u3060\u3057\u53C2\u52A0\u8868\u660E\u3057\u305F\u3051\u3069",
  "id" : 535400695575228416,
  "created_at" : "2014-11-20 11:54:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535380646349127682",
  "text" : "\u706B\u3092\u898B\u306B\u6765\u305F",
  "id" : 535380646349127682,
  "created_at" : "2014-11-20 10:34:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u5927\u30DE\u30A4\u30B3\u30F3\u30AF\u30E9\u30D6(KMC)",
      "screen_name" : "KMC_JP",
      "indices" : [ 3, 10 ],
      "id_str" : "123825505",
      "id" : 123825505
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/KMC_JP\/status\/534727997371084800\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/QnPOluVEQF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2u8R7jCUAAee4L.jpg",
      "id_str" : "534727997001977856",
      "id" : 534727997001977856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2u8R7jCUAAee4L.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1824,
        "resize" : "fit",
        "w" : 2432
      } ],
      "display_url" : "pic.twitter.com\/QnPOluVEQF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/Hh0CR8gmu6",
      "expanded_url" : "http:\/\/kmc.hatenablog.jp\/entry\/2014\/11\/19\/002055",
      "display_url" : "kmc.hatenablog.jp\/entry\/2014\/11\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535380400621645825",
  "text" : "RT @KMC_JP: \u660E\u65E5\u304B\u308911\u6708\u796D\u3060\uFF01\uFF01\uFF01 KMC\u306E\u30D6\u30FC\u30B9\u306F\u5171\u531731\u3067\u3059\uFF01\uFF01\uFF01 \u30D6\u30FC\u30B9\u8A73\u7D30\u306F\u30D6\u30ED\u30B0\u3092\uFF01\uFF01 http:\/\/t.co\/Hh0CR8gmu6 http:\/\/t.co\/QnPOluVEQF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/KMC_JP\/status\/534727997371084800\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/QnPOluVEQF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2u8R7jCUAAee4L.jpg",
        "id_str" : "534727997001977856",
        "id" : 534727997001977856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2u8R7jCUAAee4L.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1824,
          "resize" : "fit",
          "w" : 2432
        } ],
        "display_url" : "pic.twitter.com\/QnPOluVEQF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/Hh0CR8gmu6",
        "expanded_url" : "http:\/\/kmc.hatenablog.jp\/entry\/2014\/11\/19\/002055",
        "display_url" : "kmc.hatenablog.jp\/entry\/2014\/11\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535378211228495872",
    "text" : "\u660E\u65E5\u304B\u308911\u6708\u796D\u3060\uFF01\uFF01\uFF01 KMC\u306E\u30D6\u30FC\u30B9\u306F\u5171\u531731\u3067\u3059\uFF01\uFF01\uFF01 \u30D6\u30FC\u30B9\u8A73\u7D30\u306F\u30D6\u30ED\u30B0\u3092\uFF01\uFF01 http:\/\/t.co\/Hh0CR8gmu6 http:\/\/t.co\/QnPOluVEQF",
    "id" : 535378211228495872,
    "created_at" : "2014-11-20 10:24:47 +0000",
    "user" : {
      "name" : "\u4EAC\u5927\u30DE\u30A4\u30B3\u30F3\u30AF\u30E9\u30D6(KMC)",
      "screen_name" : "KMC_JP",
      "protected" : false,
      "id_str" : "123825505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580304900761870336\/z8hXFyOB_normal.jpg",
      "id" : 123825505,
      "verified" : false
    }
  },
  "id" : 535380400621645825,
  "created_at" : "2014-11-20 10:33:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/H8u31ymvsN",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/535258358056357888",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535368493911138304",
  "geo" : { },
  "id_str" : "535368824858497024",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 https:\/\/t.co\/H8u31ymvsN",
  "id" : 535368824858497024,
  "in_reply_to_status_id" : 535368493911138304,
  "created_at" : "2014-11-20 09:47:29 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535368396875919361",
  "geo" : { },
  "id_str" : "535368630788055040",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u70B9\u706B\u304C19\u664230\u5206\u3068\u304B\u305D\u3093\u306A\u3093\u3060\u3063\u305F\u3057\u3086\u3063\u304F\u308A\u3067\u3082\u3001\u50D5\u306F\u3044\u307E\u306Fs2s\u306E\u3068\u3053\u308D\u3067\u3046\u3060\u3046\u3060\u3057\u3066\u308B",
  "id" : 535368630788055040,
  "in_reply_to_status_id" : 535368396875919361,
  "created_at" : "2014-11-20 09:46:42 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535368358934245376",
  "text" : "\u3053\u3082\u308A\u3093\u3001\u3081\u3063\u3061\u3087\u4ED5\u4E8B\u65E9\u3044",
  "id" : 535368358934245376,
  "created_at" : "2014-11-20 09:45:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535368081837522944",
  "geo" : { },
  "id_str" : "535368245901918208",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u30AD\u30E3\u30F3\u30D7\u30D5\u30A1\u30A4\u30A2\u7684\u306A\u306E\u304C\u3042\u308B\u304B\u3089\u306A\u304C\u3081\u306B\u3044\u3053\u3046\u304B\u306A\u30FC\u3068",
  "id" : 535368245901918208,
  "in_reply_to_status_id" : 535368081837522944,
  "created_at" : "2014-11-20 09:45:11 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535367810847739904",
  "geo" : { },
  "id_str" : "535367929374576640",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u706B\u3092\u898B\u306B\u884C\u3053\u3046",
  "id" : 535367929374576640,
  "in_reply_to_status_id" : 535367810847739904,
  "created_at" : "2014-11-20 09:43:55 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535366895508000769",
  "text" : "\u306A\u3093\u306B\u3082\u8003\u3048\u305A\u306B\u73FE\u5730(\u7DCF\u4EBA\u5730\u4E0B)\u306B\u3044\u308B",
  "id" : 535366895508000769,
  "created_at" : "2014-11-20 09:39:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535366287648509953",
  "text" : "\u4E00\u8A00\u601D\u3063\u305F\u3053\u3068\u3092\u8A00\u3046\u3053\u3068\u3067\u5927\u91CF\u306E\u4ED5\u4E8B\u3092\u524A\u6E1B\u3057\u305F\u304B\u3089\u5049\u3044",
  "id" : 535366287648509953,
  "created_at" : "2014-11-20 09:37:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535312945824407553",
  "geo" : { },
  "id_str" : "535313042079092736",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u90E8\u5C4B\u306E\u524D\u307E\u3067\u6765\u307E\u3057\u305F\u30FC",
  "id" : 535313042079092736,
  "in_reply_to_status_id" : 535312945824407553,
  "created_at" : "2014-11-20 06:05:49 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535312381052600321",
  "geo" : { },
  "id_str" : "535312663966781440",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u4ECA\u65E5\u306F\u6728\u66DC\u3067\u3059\u3051\u3069\u2026\uFF1F",
  "id" : 535312663966781440,
  "in_reply_to_status_id" : 535312381052600321,
  "created_at" : "2014-11-20 06:04:19 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535311836472569857",
  "geo" : { },
  "id_str" : "535312073920491522",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \uFF1F\u8A08\u7B97\u6A5F\u5BA4\u3063\u3066\u5165\u308C\u306A\u3044\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 535312073920491522,
  "in_reply_to_status_id" : 535311836472569857,
  "created_at" : "2014-11-20 06:01:58 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535311075076358144",
  "geo" : { },
  "id_str" : "535311170840694784",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u2026\u3068\u308A\u3042\u3048\u305A\u8A2A\u306D\u3066\u3082\uFF1F",
  "id" : 535311170840694784,
  "in_reply_to_status_id" : 535311075076358144,
  "created_at" : "2014-11-20 05:58:23 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535310668891566080",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u3044\u307E\u9662\u751F\u5BA4\u306B\u3044\u307E\u3059\u304B\uFF1F",
  "id" : 535310668891566080,
  "created_at" : "2014-11-20 05:56:23 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535281574959276032",
  "geo" : { },
  "id_str" : "535285566967783424",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank 15\u6642\u304B\u3089\u3044\u306A\u3044\u3093\u3060\u3088\u306D\u2026\u5E30\u3063\u3066\u6765\u3066\u304B\u3089\u306B\u3057\u3088\u3046\u304B\u306A",
  "id" : 535285566967783424,
  "in_reply_to_status_id" : 535281574959276032,
  "created_at" : "2014-11-20 04:16:38 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pomme doux et bon",
      "screen_name" : "deninigi",
      "indices" : [ 0, 9 ],
      "id_str" : "186463462",
      "id" : 186463462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535274853759066112",
  "geo" : { },
  "id_str" : "535275352877453312",
  "in_reply_to_user_id" : 186463462,
  "text" : "@deninigi \u5317\u897F\u306B",
  "id" : 535275352877453312,
  "in_reply_to_status_id" : 535274853759066112,
  "created_at" : "2014-11-20 03:36:03 +0000",
  "in_reply_to_screen_name" : "deninigi",
  "in_reply_to_user_id_str" : "186463462",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pomme doux et bon",
      "screen_name" : "deninigi",
      "indices" : [ 0, 9 ],
      "id_str" : "186463462",
      "id" : 186463462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535274398643535873",
  "geo" : { },
  "id_str" : "535274747333214208",
  "in_reply_to_user_id" : 186463462,
  "text" : "@deninigi \u4ECA\u306F\u767E\u4E07\u904D\u306B\u5411\u304B\u3063\u3066\u308B\u3001\u306A\u306B\u305F\u3079\u3088\u3063\u304B",
  "id" : 535274747333214208,
  "in_reply_to_status_id" : 535274398643535873,
  "created_at" : "2014-11-20 03:33:39 +0000",
  "in_reply_to_screen_name" : "deninigi",
  "in_reply_to_user_id_str" : "186463462",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pomme doux et bon",
      "screen_name" : "deninigi",
      "indices" : [ 0, 9 ],
      "id_str" : "186463462",
      "id" : 186463462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535274012444602368",
  "geo" : { },
  "id_str" : "535274267017879552",
  "in_reply_to_user_id" : 186463462,
  "text" : "@deninigi \u4ECA\u306F\u904A\u3073\u306B\u6765\u3066\u308B",
  "id" : 535274267017879552,
  "in_reply_to_status_id" : 535274012444602368,
  "created_at" : "2014-11-20 03:31:44 +0000",
  "in_reply_to_screen_name" : "deninigi",
  "in_reply_to_user_id_str" : "186463462",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pomme doux et bon",
      "screen_name" : "deninigi",
      "indices" : [ 0, 9 ],
      "id_str" : "186463462",
      "id" : 186463462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535273499628032000",
  "geo" : { },
  "id_str" : "535273889882841088",
  "in_reply_to_user_id" : 186463462,
  "text" : "@deninigi \u306A\u306B\u304B\u305F\u3079\u306B\u3044\u3053\u3046",
  "id" : 535273889882841088,
  "in_reply_to_status_id" : 535273499628032000,
  "created_at" : "2014-11-20 03:30:14 +0000",
  "in_reply_to_screen_name" : "deninigi",
  "in_reply_to_user_id_str" : "186463462",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pomme doux et bon",
      "screen_name" : "deninigi",
      "indices" : [ 0, 9 ],
      "id_str" : "186463462",
      "id" : 186463462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535272627116326912",
  "geo" : { },
  "id_str" : "535272772482899969",
  "in_reply_to_user_id" : 186463462,
  "text" : "@deninigi 3\u9650\u306A\u3093\u304B\u3042\u308B\uFF1F",
  "id" : 535272772482899969,
  "in_reply_to_status_id" : 535272627116326912,
  "created_at" : "2014-11-20 03:25:48 +0000",
  "in_reply_to_screen_name" : "deninigi",
  "in_reply_to_user_id_str" : "186463462",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pomme doux et bon",
      "screen_name" : "deninigi",
      "indices" : [ 0, 9 ],
      "id_str" : "186463462",
      "id" : 186463462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535271695917907968",
  "geo" : { },
  "id_str" : "535272261263949825",
  "in_reply_to_user_id" : 186463462,
  "text" : "@deninigi \u304A\u3072\u308B\u305F\u3079\u305F\uFF1F",
  "id" : 535272261263949825,
  "in_reply_to_status_id" : 535271695917907968,
  "created_at" : "2014-11-20 03:23:46 +0000",
  "in_reply_to_screen_name" : "deninigi",
  "in_reply_to_user_id_str" : "186463462",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535270745543151616",
  "text" : "\u524D\u591C\u796D\u3001\u706B\u304C\u3042\u308B\u306E\u304B",
  "id" : 535270745543151616,
  "created_at" : "2014-11-20 03:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535262941285597184",
  "geo" : { },
  "id_str" : "535263057648578560",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3058\u3083\u3042\u5B9F\u969B\u306E\u958B\u5834\u306F\u3042\u3055\u3063\u3066\u671D\u306B\u306A\u308B\u306E\u304B",
  "id" : 535263057648578560,
  "in_reply_to_status_id" : 535262941285597184,
  "created_at" : "2014-11-20 02:47:12 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535262523432251392",
  "geo" : { },
  "id_str" : "535262857966125057",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u4ECA\u65E5\u306E\u653E\u8AB2\u5F8C\u306B\u306A\u3093\u304B\u3042\u308B\u306E\uFF1F\u6E96\u5099\u7684\u306A\uFF1F",
  "id" : 535262857966125057,
  "in_reply_to_status_id" : 535262523432251392,
  "created_at" : "2014-11-20 02:46:24 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535261818202390528",
  "text" : "\u3067\u3082\u307E\u3041\u307B\u3046\u3058\u8336\u30E9\u30C6\u307F\u305F\u3044\u306A\u611F\u3058\u306B\u8ABF\u6574\u3059\u308C\u3070\u7F8E\u5473\u3057\u3044\u304B\u3082\u306D",
  "id" : 535261818202390528,
  "created_at" : "2014-11-20 02:42:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 0, 9 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    }, {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 10, 20 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535261164994052096",
  "geo" : { },
  "id_str" : "535261716699811840",
  "in_reply_to_user_id" : 2306283966,
  "text" : "@tenapyon @noumisoko \u3055\u3059\u304C\u306B\u611B\u305B\u306A\u3055\u305D\u3046\u3067\u3059\u2026",
  "id" : 535261716699811840,
  "in_reply_to_status_id" : 535261164994052096,
  "created_at" : "2014-11-20 02:41:52 +0000",
  "in_reply_to_screen_name" : "tenapyon",
  "in_reply_to_user_id_str" : "2306283966",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u305A\u3042\u305A",
      "screen_name" : "azuazut",
      "indices" : [ 0, 8 ],
      "id_str" : "294104006",
      "id" : 294104006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535261425279979520",
  "geo" : { },
  "id_str" : "535261593857044480",
  "in_reply_to_user_id" : 294104006,
  "text" : "@azuazut \u3057\u307E\u3059\u3088\u30FC\u3001\u5F53\u65E5\u884C\u3051\u308B\u304B\u306F\u307E\u3060\u672A\u5B9A\u3067\u3059\u3051\u3069",
  "id" : 535261593857044480,
  "in_reply_to_status_id" : 535261425279979520,
  "created_at" : "2014-11-20 02:41:23 +0000",
  "in_reply_to_screen_name" : "azuazut",
  "in_reply_to_user_id_str" : "294104006",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535260892225888256",
  "geo" : { },
  "id_str" : "535260947120533504",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u732B\u306F\u611B\u3055\u308C\u308B\u306E\u304C\u7FA9\u52D9",
  "id" : 535260947120533504,
  "in_reply_to_status_id" : 535260892225888256,
  "created_at" : "2014-11-20 02:38:49 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535260143525441536",
  "geo" : { },
  "id_str" : "535260491887943680",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u70CF\u3068\u540C\u3058\u304F\u3089\u3044\u611B\u3057\u3066\u308B",
  "id" : 535260491887943680,
  "in_reply_to_status_id" : 535260143525441536,
  "created_at" : "2014-11-20 02:37:00 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535259822414127104",
  "geo" : { },
  "id_str" : "535259902491361280",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u5272\u308A\u3068\u305D\u3046\u3044\u3046\u3068\u3053\u308D\u3042\u308A\u307E\u3059\u306D",
  "id" : 535259902491361280,
  "in_reply_to_status_id" : 535259822414127104,
  "created_at" : "2014-11-20 02:34:40 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535259677429624833",
  "text" : "\u70CF\u9F8D\u8336\u3082\u9CE5\u9F8D\u8336\u3082\u5E73\u7B49\u306B\u611B\u3059\u308B\u5FC3\u3092\u6301\u3063\u3066\u308B",
  "id" : 535259677429624833,
  "created_at" : "2014-11-20 02:33:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535259434155769857",
  "text" : "\u8840\u4E2D\u3086\u3086\u5F0F\u6FC3\u5EA6",
  "id" : 535259434155769857,
  "created_at" : "2014-11-20 02:32:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535259363477581824",
  "text" : "\u8840\u4E2D\u70CF\u9F8D\u8336\u6FC3\u5EA6\u306F\u767E\u6B69\u8B72\u3063\u3066\u308F\u304B\u3089\u306A\u3044\u3067\u3082\u306A\u3044\u3051\u3069\u8840\u4E2D\u3086\u3086\u5F0F\u306F\u6FC3\u5EA6\u306F\u672C\u5F53\u306B\u610F\u5473\u4E0D\u660E",
  "id" : 535259363477581824,
  "created_at" : "2014-11-20 02:32:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535258473567506432",
  "text" : "\u65E5\u9803\u304B\u3089\u70CF\u9F8D\u8336\u3092\u98F2\u3093\u3067\u3044\u308C\u3070\u6C17\u3065\u3051\u305F\u306F\u305A",
  "id" : 535258473567506432,
  "created_at" : "2014-11-20 02:28:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535258358056357888",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u304C\u4EAC\u90FD\u5165\u308A\u3057\u3066\u308B\u306E\u306B\u6C17\u3065\u304B\u306A\u3044\u4EBA\u3001\u660E\u3089\u304B\u306B\u8840\u4E2D\u70CF\u9F8D\u8336\u6FC3\u5EA6\u304C\u4F4E\u3044",
  "id" : 535258358056357888,
  "created_at" : "2014-11-20 02:28:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535257938638958592",
  "geo" : { },
  "id_str" : "535258080586366976",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6628\u591C\u306B\u306D\u30FC\u3001\u90E8\u5C4B\u756A\u3060\u3051\u304A\u305B\u30FC\u3066(\u3042\u308C\u306A\u3089DM\u3067\u30FC)",
  "id" : 535258080586366976,
  "in_reply_to_status_id" : 535257938638958592,
  "created_at" : "2014-11-20 02:27:25 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535257583515623425",
  "geo" : { },
  "id_str" : "535257669980807168",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u904A\u3073\u306B(?)\u884C\u3063\u3066\u3044\u3044\u3067\u3059\u304B",
  "id" : 535257669980807168,
  "in_reply_to_status_id" : 535257583515623425,
  "created_at" : "2014-11-20 02:25:47 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535257430817775616",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4ECA\u65E5\u306F\u9662\u751F\u5BA4\u306B\u3044\u307E\u3059\u3067\u3059\u304B\uFF1F",
  "id" : 535257430817775616,
  "created_at" : "2014-11-20 02:24:50 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535250598481117185",
  "text" : "\u5F37\u3044\u5730\u9707\u3001\u5F31\u3044\u5730\u9707\u3001\u305D\u3093\u306A\u306E\u4EBA\u306E\u304B\u3063\u3066",
  "id" : 535250598481117185,
  "created_at" : "2014-11-20 01:57:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535249349841006593",
  "text" : "\u3042\u3052\u3066\u3082\u3044\u306A\u3044\u8DB3\u3092\u53D6\u308A\u8A00\u3044\u304C\u304B\u308A\u3092\u3064\u3051\u308B\u30D7\u30ED\u3068\u3057\u3066\u306F\u30D1\u30E9\u30CE\u30A4\u30A2\u3084\u308A\u305F\u3059\u304E\u308B\u3067\u3057\u3087",
  "id" : 535249349841006593,
  "created_at" : "2014-11-20 01:52:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535249213324800001",
  "text" : "\u30A2\u30EB\u30D5\u30A1\u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9\u306E\u591A\u7FA9\u6027\u306A",
  "id" : 535249213324800001,
  "created_at" : "2014-11-20 01:52:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    }, {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 12, 20 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535248556786212864",
  "geo" : { },
  "id_str" : "535248730963079169",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 @bagirom \u540D\u72B6\u3057\u96E3\u3044\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u30A2\u30C8\u30B9\u30D5\u30A3\u30A2\u2026",
  "id" : 535248730963079169,
  "in_reply_to_status_id" : 535248556786212864,
  "created_at" : "2014-11-20 01:50:16 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535248539132391424",
  "text" : "@Kyo_Hiiragi \u306A\u3093\u306E\u305F\u3081\u306E\u30EB\u30EB\u30D6\u306A\u3093\u3060\u2026\u2026",
  "id" : 535248539132391424,
  "created_at" : "2014-11-20 01:49:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535248406286176258",
  "text" : "@Kyo_Hiiragi \u306A\u308B\u307B\u3069\u3001NF\u671F\u9593\u4E2D\u306B\u3084\u308B\u30A2\u30A4\u30C7\u30A3\u30A2\u306F\u306A\u3044\u306E\u304B",
  "id" : 535248406286176258,
  "created_at" : "2014-11-20 01:48:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    }, {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 12, 20 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535247965380939776",
  "geo" : { },
  "id_str" : "535248173464567810",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 @bagirom \u3067\u3082\u307E\u3041\u8208\u5473\u3092\u6301\u3063\u3066\u3069\u3093\u306A\u3082\u3093\u304B\u306F\u7406\u89E3\u3057\u305F\u3051\u3069\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u72B6\u614B\u3060\u304B\u3089\u3084\u308A\u305F\u3044\u306E\u3067\u3059",
  "id" : 535248173464567810,
  "in_reply_to_status_id" : 535247965380939776,
  "created_at" : "2014-11-20 01:48:03 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535248010729758721",
  "text" : "\u5B8C\u74A7\u3067\u5E78\u798F\u306A\u72C2\u4FE1\u8005",
  "id" : 535248010729758721,
  "created_at" : "2014-11-20 01:47:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535247912327217154",
  "text" : "@Kyo_Hiiragi \u9069\u5F53\u306B\u30E1\u30F3\u30D0\u30FC\u8A98\u3063\u3066\u3084\u308D\u3046",
  "id" : 535247912327217154,
  "created_at" : "2014-11-20 01:47:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535247683796348928",
  "text" : "@Kyo_Hiiragi \u3084\u308D\u3046(?)",
  "id" : 535247683796348928,
  "created_at" : "2014-11-20 01:46:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    }, {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 9, 20 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535246313752113154",
  "geo" : { },
  "id_str" : "535246742116380674",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom @Maleic1618 \u3060",
  "id" : 535246742116380674,
  "in_reply_to_status_id" : 535246313752113154,
  "created_at" : "2014-11-20 01:42:22 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535244186564722688",
  "text" : "\u3054\u3061\u3046\u3055\u3001\u6BD2\u304C\u306A\u3055\u3059\u304E\u3066\u9000\u5C48\u611F",
  "id" : 535244186564722688,
  "created_at" : "2014-11-20 01:32:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535244036119220226",
  "text" : "@Kyo_Hiiragi \u3054\u3061\u3046\u3055\u306F\u50D5\u306B\u306F\u9000\u5C48\u3067\u3057\u305F\u306D\u2026\u304D\u3093\u30E2\u30B6\u306F\u307E\u3060\u898B\u308C\u305F\u3051\u3069\u2026",
  "id" : 535244036119220226,
  "created_at" : "2014-11-20 01:31:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535243570656325635",
  "text" : "@Kyo_Hiiragi \u3053\u306E\u30B7\u30FC\u30F3\u306F\u76EE\u3067\u30DC\u30B1\u3066\u308B\u3088\u3046\u306A\u30B7\u30FC\u30F3\u3060\u304B\u3089\u304B\u306A\u308A\u7279\u6B8A\u304B\u306A\u3001\u3067\u3082\u3086\u3086\u5F0F\u306F\u76EE\u306E\u8868\u73FE\u306F\u5168\u4F53\u7684\u306B\u73CD\u3057\u3044\u306E\u304C\u591A\u3044\u304B\u3082",
  "id" : 535243570656325635,
  "created_at" : "2014-11-20 01:29:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535242874057924608",
  "text" : "@Kyo_Hiiragi \u300C\u76EE\uFF01\u306A\u3093\u3060\u76EE\uFF01\u300D\u3063\u3066\u30C4\u30C3\u30B3\u30DF\u304C\u5165\u308B",
  "id" : 535242874057924608,
  "created_at" : "2014-11-20 01:27:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/535242565080338432\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/otiembEKnF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B22QRuKIAAE5k2t.png",
      "id_str" : "535242564849631233",
      "id" : 535242564849631233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22QRuKIAAE5k2t.png",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/otiembEKnF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535242565080338432",
  "text" : "http:\/\/t.co\/otiembEKnF",
  "id" : 535242565080338432,
  "created_at" : "2014-11-20 01:25:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535116695539421184",
  "geo" : { },
  "id_str" : "535239369733705729",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u306F\u3044",
  "id" : 535239369733705729,
  "in_reply_to_status_id" : 535116695539421184,
  "created_at" : "2014-11-20 01:13:04 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535107995286253568",
  "text" : "\u4EBA\u8108\u3068\u304B\u3044\u3046\u306E\u3001\u4EBA\u8108\u3092\u4F7F\u3046\u305F\u3081\u306B\u5E83\u3052\u308B\u306E\u306F\u672C\u672B\u8EE2\u5012\u3068\u3044\u3046\u304B\u306A\u3093\u3068\u3044\u3046\u304B",
  "id" : 535107995286253568,
  "created_at" : "2014-11-19 16:31:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535107545606533120",
  "text" : "\u304B\u3064\u3066\u305D\u306E\u4EBA\u306B\u306F\u4EBA\u8108\u304C\u3042\u3063\u305F\u304C\u6226\u524D\u306B\u3042\u3089\u304B\u305F\u6398\u308A\u5C3D\u304F\u3057\u3066\u3057\u307E\u3044\u4ECA\u3067\u306F\u307B\u3068\u3093\u3069\u6B8B\u3063\u3066\u3044\u306A\u3044",
  "id" : 535107545606533120,
  "created_at" : "2014-11-19 16:29:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535105450950156289",
  "text" : "\u5B66\u90E8\u306E\u53CB\u4EBA\u306E\u8FD1\u6CC1\u5831\u544A\u3092\u805E\u304F\u306E\u697D\u3057\u3044",
  "id" : 535105450950156289,
  "created_at" : "2014-11-19 16:20:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535102436659036160",
  "geo" : { },
  "id_str" : "535103911594438656",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u3067\u3063\u304B\u3044\u3067\u3059",
  "id" : 535103911594438656,
  "in_reply_to_status_id" : 535102436659036160,
  "created_at" : "2014-11-19 16:14:48 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/535100657561128960\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/Ja8HRGZG1a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B20PNn3CQAAkc8t.png",
      "id_str" : "535100657439490048",
      "id" : 535100657439490048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B20PNn3CQAAkc8t.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Ja8HRGZG1a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535100657561128960",
  "text" : "\u901A\u308A\u3067\u6696\u304B\u3044 http:\/\/t.co\/Ja8HRGZG1a",
  "id" : 535100657561128960,
  "created_at" : "2014-11-19 16:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/535100605199437824\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/agfZWEBGZm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B20PKk0CEAA-Nm2.png",
      "id_str" : "535100605081980928",
      "id" : 535100605081980928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B20PKk0CEAA-Nm2.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/agfZWEBGZm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535100605199437824",
  "text" : "\u306A\u308B\u307B\u3069 http:\/\/t.co\/agfZWEBGZm",
  "id" : 535100605199437824,
  "created_at" : "2014-11-19 16:01:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535100191368421376",
  "text" : "\u3055\u304B\u306E\u307C\u3089\u308C\u6C0F\u306B\u305D\u3059\u3046\u3066\u308B",
  "id" : 535100191368421376,
  "created_at" : "2014-11-19 16:00:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535099889193975808",
  "geo" : { },
  "id_str" : "535099986464083968",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u5909\u306A\u8A00\u8449\u9063\u3044\u3057\u3066\u308B\u306E\u306F\u6211\u3005\u306A\u306E\u3067(\u30DE\u30B8\u30EC\u30B9)",
  "id" : 535099986464083968,
  "in_reply_to_status_id" : 535099889193975808,
  "created_at" : "2014-11-19 15:59:13 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535099812954120193",
  "text" : "\u307F\u305F\u3044\u306A\u4F1A\u8A71",
  "id" : 535099812954120193,
  "created_at" : "2014-11-19 15:58:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535099791894532098",
  "text" : "\u300C\u3053\u306E\u90E8\u5C4B\u4EBA\u6A29\u3042\u308B?\u300D\n\u300C\uFF1F\uFF1F\uFF1F\u300D\n\u300C\u3042\u3001Wi-Fi\u3042\u308B\uFF1F\u300D\n\u300C\u3042\u3001\u3042\u308B\u3088(\u306A\u3093\u3060\u3044\u307E\u306E)\u300D",
  "id" : 535099791894532098,
  "created_at" : "2014-11-19 15:58:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535099337039036416",
  "text" : "@\u306E\u306A\u3061\u3083\u3093 \u4F8B\u306E\u30A4\u30E4\u30EA\u30F3\u30B0(?)\u7528\u610F\u3057\u3068\u3044\u3066\u30FC",
  "id" : 535099337039036416,
  "created_at" : "2014-11-19 15:56:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535098105310347265",
  "text" : "\u3086\u3086\u5F0F",
  "id" : 535098105310347265,
  "created_at" : "2014-11-19 15:51:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535075713640960001",
  "geo" : { },
  "id_str" : "535077503304347649",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \uFF8F\uFF80\u2026\uFF76\uFF74\uFF85\uFF76\uFF6F\uFF80\u2026",
  "id" : 535077503304347649,
  "in_reply_to_status_id" : 535075713640960001,
  "created_at" : "2014-11-19 14:29:52 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535075360178593792",
  "text" : "\u90E8\u5BA4\u8997\u3044\u3066\u307F\u3088\u3046",
  "id" : 535075360178593792,
  "created_at" : "2014-11-19 14:21:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535070989290192897",
  "text" : "\u6B69\u304F\u306E\u306F\u305D\u308C\u306A\u308A\u306B\u597D\u304D\u3060\u3051\u3069\u52B9\u7387\u304C\u60AA\u3059\u304E\u308B",
  "id" : 535070989290192897,
  "created_at" : "2014-11-19 14:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535070910403731458",
  "text" : "\u5E38\u3005\u601D\u3046\u3051\u3069\u4EBA\u9593\u3001\u79FB\u52D5\u306B\u4E0D\u5411\u304D\u3059\u304E\u308B",
  "id" : 535070910403731458,
  "created_at" : "2014-11-19 14:03:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535070398723788800",
  "text" : "\u4EBA\u9593\u3001\u79FB\u52D5\u3059\u308B\u3060\u3051\u3067\u7D50\u69CB\u75B2\u308C\u308B\u306E\u3058\u3083",
  "id" : 535070398723788800,
  "created_at" : "2014-11-19 14:01:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535059413837438977",
  "text" : "\u6587\u8108\u3067\u5224\u65AD\u3067\u304D\u306A\u304F\u306A\u3063\u305F\u6642\u6DF7\u6C8C\u304C\u8A2A\u308C\u4EBA\u985E\u306F\u6EC5\u3073\u308B",
  "id" : 535059413837438977,
  "created_at" : "2014-11-19 13:17:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535059202125729792",
  "text" : "\u6587\u8108\u3067\u5224\u65AD\u3067\u304D\u308B\u306A\u3089\u591A\u5C11\u306E\u8A18\u53F7\u306E\u6FEB\u7528\u306F\u8A31\u305B\u308B",
  "id" : 535059202125729792,
  "created_at" : "2014-11-19 13:17:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535058900911812609",
  "geo" : { },
  "id_str" : "535059072165216256",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u307E\u3041\u6587\u8108\u3067\u5206\u304B\u3089\u306A\u3044\u6642\u306F\u3061\u3083\u3093\u3068\u66F8\u304F\u3057\u306A\u3041\u2026",
  "id" : 535059072165216256,
  "in_reply_to_status_id" : 535058900911812609,
  "created_at" : "2014-11-19 13:16:38 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535058755461734400",
  "text" : "\u81EA\u5206\u3057\u304B\u8AAD\u307E\u306A\u3044\u30CE\u30FC\u30C8\u3060\u3068func\u307F\u305F\u3044\u306A\u5FAE\u5999\u306A\u7565\u3057\u65B9\u3057\u3061\u3083\u3046",
  "id" : 535058755461734400,
  "created_at" : "2014-11-19 13:15:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535058090467405824",
  "text" : "fcn\u306F\u5148\u751F\u304C\u4F7F\u3046\u306A\u30FC",
  "id" : 535058090467405824,
  "created_at" : "2014-11-19 13:12:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535057716520038400",
  "text" : "complex\u306F\u8907\u4F53\u308F\u304B\u308B",
  "id" : 535057716520038400,
  "created_at" : "2014-11-19 13:11:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535057499485769728",
  "geo" : { },
  "id_str" : "535057608340549633",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u306D\u3044\u3070\u30FC\u3075\u3063\u3069",
  "id" : 535057608340549633,
  "in_reply_to_status_id" : 535057499485769728,
  "created_at" : "2014-11-19 13:10:49 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535057218500976642",
  "text" : "cpx\u3068\u304Bcpt\u3068\u304Bmfd\u3068\u304Bnbd\u3068\u304B",
  "id" : 535057218500976642,
  "created_at" : "2014-11-19 13:09:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535057059872399360",
  "text" : "proof\u306E\u4ED6\u306Bconfirm\u3082\u4F7F\u3046\u3093\u3060\u3051\u3069\u30DE\u30A4\u30CA\u30FC\u3063\u307D\u3044",
  "id" : 535057059872399360,
  "created_at" : "2014-11-19 13:08:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535056551539515392",
  "text" : "\u3066\u3046\u308C\u306F\u9045\u304F\u307E\u3067\u3084\u3063\u3066\u306A\u3044",
  "id" : 535056551539515392,
  "created_at" : "2014-11-19 13:06:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535053533460975619",
  "geo" : { },
  "id_str" : "535053703913279488",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3048\u3063\u3078\u3093",
  "id" : 535053703913279488,
  "in_reply_to_status_id" : 535053533460975619,
  "created_at" : "2014-11-19 12:55:18 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535053253822529537",
  "geo" : { },
  "id_str" : "535053369203625985",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u4ECA\u95A2\u7A7A\u304B\u3089\u5411\u304B\u3063\u3066\u308B\u30D0\u30B9",
  "id" : 535053369203625985,
  "in_reply_to_status_id" : 535053253822529537,
  "created_at" : "2014-11-19 12:53:58 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 0, 14 ],
      "id_str" : "205210585",
      "id" : 205210585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535052671023988736",
  "geo" : { },
  "id_str" : "535052966504316928",
  "in_reply_to_user_id" : 205210585,
  "text" : "@yasuhitoakita \u3093\u30FC\u3001\u5730\u7406\u7684\u306B\u96E3\u3057\u3044\u304B\u3082\u3067\u3059\u2026",
  "id" : 535052966504316928,
  "in_reply_to_status_id" : 535052671023988736,
  "created_at" : "2014-11-19 12:52:22 +0000",
  "in_reply_to_screen_name" : "yasuhitoakita",
  "in_reply_to_user_id_str" : "205210585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 0, 14 ],
      "id_str" : "205210585",
      "id" : 205210585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535052141870579713",
  "geo" : { },
  "id_str" : "535052238473793536",
  "in_reply_to_user_id" : 205210585,
  "text" : "@yasuhitoakita \u521D\u8033\u3067\u3059\u304C\u65B0\u3057\u3044\u304A\u5E97\u3067\u3059\uFF1F",
  "id" : 535052238473793536,
  "in_reply_to_status_id" : 535052141870579713,
  "created_at" : "2014-11-19 12:49:29 +0000",
  "in_reply_to_screen_name" : "yasuhitoakita",
  "in_reply_to_user_id_str" : "205210585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535051961301602304",
  "text" : "\u524D\u56DE\u884C\u304D\u305D\u3073\u308C\u305F\u3057\u306B\u307C\u3067\u3082\u826F\u3044\u304B\u306A\u3063\u3066\u8840\u8FF7\u3044",
  "id" : 535051961301602304,
  "created_at" : "2014-11-19 12:48:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535051781642792961",
  "geo" : { },
  "id_str" : "535051860650893312",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u306A\u308B\u307B\u3069\u2026",
  "id" : 535051860650893312,
  "in_reply_to_status_id" : 535051781642792961,
  "created_at" : "2014-11-19 12:47:59 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535048945290846208",
  "geo" : { },
  "id_str" : "535049126820335616",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u8D64\u798F\u826F\u3055\u2026",
  "id" : 535049126820335616,
  "in_reply_to_status_id" : 535048945290846208,
  "created_at" : "2014-11-19 12:37:07 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535048044501143552",
  "text" : "\u767E\u4E07\u904D\u754C\u9688\u306724\u6642\u304F\u3089\u3044\u307E\u3067\u3084\u3063\u3066\u308B\u3054\u98EF\u5C4B\u3055\u3093\u3001\u3069\u3053\u304C\u3042\u308B\u3060\u308D\u3046\u304B\u2026",
  "id" : 535048044501143552,
  "created_at" : "2014-11-19 12:32:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535040586307207169",
  "text" : "\u9154\u3044\u305D\u3046\u3060\u3057\u96E2\u8131",
  "id" : 535040586307207169,
  "created_at" : "2014-11-19 12:03:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535040367951740928",
  "text" : "\u7A7A\u6E2F\u306E\u4EBA\u53E3\u611F\u3068\u3044\u3046\u304B\u306A\u3093\u3068\u3044\u3046\u304B\u597D\u304D",
  "id" : 535040367951740928,
  "created_at" : "2014-11-19 12:02:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535039995606597632",
  "geo" : { },
  "id_str" : "535040256123207680",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u3046\u3080\u3001\u3088\u308D\u3057\u304F",
  "id" : 535040256123207680,
  "in_reply_to_status_id" : 535039995606597632,
  "created_at" : "2014-11-19 12:01:52 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535039700843520001",
  "geo" : { },
  "id_str" : "535039804543488000",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u7D50\u69CB\u8FD1\u6240(?)",
  "id" : 535039804543488000,
  "in_reply_to_status_id" : 535039700843520001,
  "created_at" : "2014-11-19 12:00:04 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535039721756303360",
  "text" : "\u81EA\u8EE2\u8ECA\u306E\u6A5F\u52D5\u529B\u304C\u306A\u3044\u304B\u3089\u306A\u2026\u307E\u3041NF\u306E\u9593\u306F\u3080\u3057\u308D\u90AA\u9B54\u304B",
  "id" : 535039721756303360,
  "created_at" : "2014-11-19 11:59:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535039186596667392",
  "geo" : { },
  "id_str" : "535039568680984576",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u3044\u3084\u3001\u5F15\u3063\u8D8A\u3057\u305F\u308A\u3057\u3066\u306A\u3051\u308C\u3070\u5927\u4E08\u592B\u3060\u3088",
  "id" : 535039568680984576,
  "in_reply_to_status_id" : 535039186596667392,
  "created_at" : "2014-11-19 11:59:08 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535038864180510720",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u304B\u3093\u304F\u3046\u306B\u3064\u3044\u305F\u3002\u304D\u3087\u3046\u3068\u306B\u3080\u304B\u3046\u3088\u3002",
  "id" : 535038864180510720,
  "created_at" : "2014-11-19 11:56:20 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535038504770613248",
  "text" : "\u53BB\u5E74\u3001\u304B\u3078\u308F\u306C\u3081\u3067\u306A\u3093\u306E\u8E8A\u8E87\u3044\u3082\u306A\u304F\u30DB\u30E2\u30ED\u30B8\u30FC\u306E\u30BC\u30DF\u304C\u884C\u308F\u308C\u3066\u305F\u306E\u3001\u51B7\u9759\u306B\u8003\u3048\u3066\u3081\u3063\u3061\u3083\u9762\u767D\u3044",
  "id" : 535038504770613248,
  "created_at" : "2014-11-19 11:54:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535038147243954176",
  "text" : "\u672D\u5E4C\u304B\u3089\u65B0\u5343\u6B73\u307E\u3067\u306E\u96FB\u8ECA\u3068\u3044\u3044\u7A7A\u6E2F\u304B\u3089\u4EAC\u90FD\u307E\u3067\u306E\u30D0\u30B9\u3068\u3044\u3044\u30BF\u30A4\u30DF\u30F3\u30B0\u826F\u904E\u304E\u3066\u3042\u308C",
  "id" : 535038147243954176,
  "created_at" : "2014-11-19 11:53:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535037683379085312",
  "text" : "\u30D0\u30B9\u306E\u4E57\u308A\u7D99\u304E\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u304C\u3088\u904E\u304E\u3066\u4EAC\u90FD\u571F\u7523\u3082\u8CB7\u3048\u306A\u3044www",
  "id" : 535037683379085312,
  "created_at" : "2014-11-19 11:51:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535034772326584321",
  "geo" : { },
  "id_str" : "535035196647563264",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u516B\u6A4B\u3067\u3044\u3044\uFF1F",
  "id" : 535035196647563264,
  "in_reply_to_status_id" : 535034772326584321,
  "created_at" : "2014-11-19 11:41:46 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535034897354616832",
  "text" : "\u6C17\u3065\u3051\u307011\u6642\u3059\u304E\u306B\u671D\u663C\u4E00\u7DD2\u306E\u3054\u98EF\u3092\u98DF\u3079\u305F\u304D\u308A\u3060\u306A",
  "id" : 535034897354616832,
  "created_at" : "2014-11-19 11:40:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535034730463252480",
  "text" : "\u7740\u9678\u3001\u5589\u4E7E\u3044\u305F\u304A\u8179\u6E1B\u3063\u305F\u6691",
  "id" : 535034730463252480,
  "created_at" : "2014-11-19 11:39:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535010230942187521",
  "geo" : { },
  "id_str" : "535034509859627009",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u901A\u308A\u8D8A\u3057\u3066\u95A2\u897F\u306B\u3001\u305D\u308C\u3068\u3082\u304A\u524D\u304C\u95A2\u897F\u306B\u3044\u308B\u30D1\u30BF\u30FC\u30F3\u304B\uFF1F",
  "id" : 535034509859627009,
  "in_reply_to_status_id" : 535010230942187521,
  "created_at" : "2014-11-19 11:39:02 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534999182914760704",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u3072\u3053\u3046\u304D\u306E\u308A\u307E\u3059",
  "id" : 534999182914760704,
  "created_at" : "2014-11-19 09:18:39 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534999085149741056",
  "text" : "\u304D\u306A\u3044\u3082\u30FC\u3069",
  "id" : 534999085149741056,
  "created_at" : "2014-11-19 09:18:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534991201141682177",
  "geo" : { },
  "id_str" : "534996790563463169",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u306A\u306B\u305D\u308C\u3064\u3089\u3044",
  "id" : 534996790563463169,
  "in_reply_to_status_id" : 534991201141682177,
  "created_at" : "2014-11-19 09:09:09 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534989891264724992",
  "text" : "@\u5404\u4F4D \u6B8B\u5FF5\u3060\u304C\u304A\u571F\u7523\u3092\u8CB7\u3046\u6642\u9593 is \u306A\u3044",
  "id" : 534989891264724992,
  "created_at" : "2014-11-19 08:41:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534972919416229888",
  "geo" : { },
  "id_str" : "534987303140065280",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u3044\u3048\u30FC\u3044\uFF01",
  "id" : 534987303140065280,
  "in_reply_to_status_id" : 534972919416229888,
  "created_at" : "2014-11-19 08:31:27 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534972435825561600",
  "text" : "\u65B0\u5343\u6B73\u3078\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 534972435825561600,
  "created_at" : "2014-11-19 07:32:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534864555386892289",
  "text" : "\u3064\u307E\u308A\u5BD2\u3044",
  "id" : 534864555386892289,
  "created_at" : "2014-11-19 00:23:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534864535866597376",
  "text" : "\u5BD2\u3059\u304E\u308B\u5BD2\u3055\u304C\u5BD2\u304F\u3066\u5BD2\u3044",
  "id" : 534864535866597376,
  "created_at" : "2014-11-19 00:23:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534719665767845888",
  "text" : "\u898B\u308B\u305F\u3073\u306B\u7B11\u3046\u8B0E\u30DA\u30FC\u30B8",
  "id" : 534719665767845888,
  "created_at" : "2014-11-18 14:47:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/RMtQN5kvIm",
      "expanded_url" : "http:\/\/www.geocities.jp\/tomoatomi\/raira0001.htm",
      "display_url" : "geocities.jp\/tomoatomi\/rair\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534719613708161025",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u7A7A http:\/\/t.co\/RMtQN5kvIm",
  "id" : 534719613708161025,
  "created_at" : "2014-11-18 14:47:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534718185707012098",
  "text" : "\u5341\u5206\u306B\u5927\u91CF\u306E\u7DBF\u306F\u5341\u5206\u306B\u5C11\u91CF\u306E\u9244\u3088\u308A\u91CD\u3044(\u7DBF\u306F\u5341\u5206\u306B\u5927\u91CF\u306B\u3042\u3063\u3066\u3001\u9244\u306F\u5341\u5206\u306B\u5C11\u91CF\u3057\u304B\u306A\u3044\u304B\u3089)",
  "id" : 534718185707012098,
  "created_at" : "2014-11-18 14:42:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534717926658437123",
  "text" : "\u91D1\u306F\u547D\u3088\u308A\u3082\u91CD\u3044(\u547D\u306F\u8CEA\u91CF\u3092\u6301\u305F\u306A\u3044\u305F\u3081)",
  "id" : 534717926658437123,
  "created_at" : "2014-11-18 14:41:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534716917391437825",
  "geo" : { },
  "id_str" : "534717053937004545",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u826F\u8CEA\u306A\u610F\u5473\u4E0D\u660E\u3055\u3067\u3042\u308B",
  "id" : 534717053937004545,
  "in_reply_to_status_id" : 534716917391437825,
  "created_at" : "2014-11-18 14:37:34 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534716586804772864",
  "text" : "f(x)=\u306D\u3080\u306D\u3080\u306B\u3083\u3093\u3053\u3001\u534A\u65E5\u304A\u304D\u304F\u3089\u3044\u306B\u982D\u3092\u99C6\u3051\u5DE1\u308B\u306E\u3084\u3081\u305F\u3044",
  "id" : 534716586804772864,
  "created_at" : "2014-11-18 14:35:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534714740354740224",
  "geo" : { },
  "id_str" : "534714844226678784",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3081\u3063\u3063\u3061\u3087\u9060\u3044",
  "id" : 534714844226678784,
  "in_reply_to_status_id" : 534714740354740224,
  "created_at" : "2014-11-18 14:28:48 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534714576177078272",
  "text" : "\u5589\u4E7E\u304F\u3060\u308D\uFF1F\u70CF\u9F8D\u8336\u98F2\u3080\u3060\u308D\uFF1F",
  "id" : 534714576177078272,
  "created_at" : "2014-11-18 14:27:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534714442336854016",
  "text" : "\u725B\u30BF\u30F3\u3092\u304A\u304B\u305A\u306B\u7B39\u304B\u307E\u3092\u98DF\u3079\u305F\u3044",
  "id" : 534714442336854016,
  "created_at" : "2014-11-18 14:27:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534712056541245440",
  "text" : "\u4ED9\u53F0\u3001\"\"\"\u6BD4\u8F03\u7684\"\"\"\u8FD1\u3044",
  "id" : 534712056541245440,
  "created_at" : "2014-11-18 14:17:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534682393391542272",
  "text" : "\u6839\u6027\u8AD6\u8005\u304C\u51FA\u6765\u4E0A\u304C\u308B",
  "id" : 534682393391542272,
  "created_at" : "2014-11-18 12:19:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534682306946945024",
  "text" : "\u306A\u3093\u3067\u3082\u6C17\u306E\u305B\u3044\u306B\u3059\u308B",
  "id" : 534682306946945024,
  "created_at" : "2014-11-18 12:19:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534682136104558593",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 534682136104558593,
  "created_at" : "2014-11-18 12:18:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534682123743920128",
  "text" : "\u8AB0\u3082\u304A\u3057\u3048\u3066\u304F\u308C\u306A\u3044\u306E\u3067\u3082\u3046\u3053\u306E\u969B\u83EF\u6C0F\u3067\u3082\u3044\u3044\u3093\u3067\u6559\u3048\u3066\u304F\u3060\u3055\u3044",
  "id" : 534682123743920128,
  "created_at" : "2014-11-18 12:18:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534681362582626304",
  "text" : "\u83EF\u6C0F\u3058\u3083\u306A\u304F\u3066\u6442\u6C0F\u3067\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 534681362582626304,
  "created_at" : "2014-11-18 12:15:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534681185654292480",
  "text" : "\u4EAC\u90FD\u3001\u4ECA\u4F55\u5EA6\u3067\u3059\u304B?",
  "id" : 534681185654292480,
  "created_at" : "2014-11-18 12:15:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534680357296013313",
  "text" : "\u307E\u305A\u306F\u30B3\u30BF\u30C4\u304B\u3089\u51FA\u308B\u3068\u3053\u308D\u304B\u3089\u306F\u3058\u3081\u3088\u3046",
  "id" : 534680357296013313,
  "created_at" : "2014-11-18 12:11:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534679986083336193",
  "text" : "\u305A\u3082\u3082\u3082\u3082\u3082\u3082",
  "id" : 534679986083336193,
  "created_at" : "2014-11-18 12:10:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534679828838895616",
  "text" : "\u8377\u9020\u308A\u3001\u3057\u307E\u3057\u3087",
  "id" : 534679828838895616,
  "created_at" : "2014-11-18 12:09:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534679489993654272",
  "text" : "\u91CE\u751F\u751F\u7269\u3092\u6BBA\u3055\u306A\u3044\u4EBA\u3001\u4EBA\u3082\u91CE\u751F\u751F\u7269\u3060\u3057\u5BFF\u547D\u3092\u8FCE\u3048\u308B\u524D\u306B\u4E0D\u8001\u4E0D\u6B7B\u306B\u306A\u308B\u4EE5\u5916\u306E\u9053\u304C\u6B8B\u3055\u308C\u3066\u306A\u3044",
  "id" : 534679489993654272,
  "created_at" : "2014-11-18 12:08:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534661898466099201",
  "text" : "\u8840\u4E2D\u3086\u3086\u5F0F\u6FC3\u5EA6",
  "id" : 534661898466099201,
  "created_at" : "2014-11-18 10:58:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534655243682738177",
  "geo" : { },
  "id_str" : "534655432162152448",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3046\u304A\u30FC\u3001\u3081\u3063\u3061\u3083\u5B09\u3057\u3044\u3067\u3059\u3001\u3088\u308D\u3057\u304F\u3067\u3059",
  "id" : 534655432162152448,
  "in_reply_to_status_id" : 534655243682738177,
  "created_at" : "2014-11-18 10:32:43 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534653983961260032",
  "geo" : { },
  "id_str" : "534654440381227008",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3093\u30FC\u3001\u30EB\u30EB\u30D6\u306F\u5171\u540C\u8CFC\u5165\u8005\u3068\u304B\u304C\u3044\u308C\u3070\u7D50\u69CB\u4E57\u308A\u6C17\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u2026\u4F55\u3092\u3084\u308B\u306E\u304B\u306F\u52D5\u753B\u3067\u898B\u3048\u308B\u90E8\u5206\u306B\u3064\u3044\u3066\u306F\u7406\u89E3\u3057\u3066\u308B(\u306F\u305A)\u3067\u3057",
  "id" : 534654440381227008,
  "in_reply_to_status_id" : 534653983961260032,
  "created_at" : "2014-11-18 10:28:46 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534653939585536000",
  "geo" : { },
  "id_str" : "534654140203270144",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u6765\u9031\u306E\u706B\u66DC\u304B\u306A\uFF1F",
  "id" : 534654140203270144,
  "in_reply_to_status_id" : 534653939585536000,
  "created_at" : "2014-11-18 10:27:35 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534653520671043584",
  "geo" : { },
  "id_str" : "534654002751746050",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3044\u304F\u3064\u304B\u898B\u899A\u3048\u304C\u3042\u308B\u7269\u3082\u3042\u308A\u305D\u3046\u3067\u3059\u304C\u3058\u308F\u3058\u308F\u898B\u3066\u884C\u304D\u307E\u3059\u3001\u3042\u308A\u304C\u3068\u3046",
  "id" : 534654002751746050,
  "in_reply_to_status_id" : 534653520671043584,
  "created_at" : "2014-11-18 10:27:02 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534653890638008321",
  "text" : "\u6301\u3064\u3079\u304D\u8005\u306F\uFF8C\uFF68\uFF6E\uFF6E\uFF9C\uFF70\u3060\u306A\u30FC\u3063\u30665\u5104\u56DE\u304F\u3089\u3044\u601D\u3046",
  "id" : 534653890638008321,
  "created_at" : "2014-11-18 10:26:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534653291863347200",
  "geo" : { },
  "id_str" : "534653471916445696",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3042\u30FC\u539F\u4F5C\u306F\u5168\u96C6\u3092\u624B\u306B\u5165\u308C\u3066\u3058\u308F\u3058\u308F\u8AAD\u3093\u3067\u308B\u3093\u3067\u3059\u3051\u3069\u306D\u2026\u30EB\u30EB\u30D6\u306F\u9AD8\u3044(\u9AD8\u3044)",
  "id" : 534653471916445696,
  "in_reply_to_status_id" : 534653291863347200,
  "created_at" : "2014-11-18 10:24:55 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534652304931053568",
  "geo" : { },
  "id_str" : "534652690014273537",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u50D5\u306E\u5834\u5408\u5B8C\u7D50\u6E08\u307F\u30EA\u30F3\u30AF\u3092\u518D\u751F\u6570\u9806\u3068\u304B\u3067\u4E0A\u304B\u3089\u898B\u3066\u308B\u306E\u3067\u3059\u304C\u3001\u304B\u306A\u308A\u30AF\u30AA\u30EA\u30C6\u30A3\u9AD8\u304B\u3063\u305F\u3067\u3059\u306D\u3002\u30AA\u30F3\u30E9\u30A4\u30F3\u3067\u51FA\u6765\u308B\u306A\u3089\u662F\u975E\u3084\u3063\u3066\u307F\u305F\u3044\u3067\u3059(\u30EB\u30EB\u30D6\u3055\u3048\u306A\u3044\u521D\u5FC3\u8005)",
  "id" : 534652690014273537,
  "in_reply_to_status_id" : 534652304931053568,
  "created_at" : "2014-11-18 10:21:49 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534651925447188481",
  "geo" : { },
  "id_str" : "534652086412013568",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u6700\u8FD1\u4EBA\u306B\u52D5\u753B\u3092\u52E7\u3081\u3089\u308C\u3066\u3059\u3054\u3044\u52E2\u3044\u3067\u898B\u3066\u307E\u3059\u30FC\u3001\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u3051\u3069\u3081\u3063\u3061\u3083\u3084\u3063\u3066\u307F\u305F\u3044",
  "id" : 534652086412013568,
  "in_reply_to_status_id" : 534651925447188481,
  "created_at" : "2014-11-18 10:19:25 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534651454531702785",
  "text" : "\u982D\u306E\u60AA\u3055\u306E\u7D20\u6674\u3089\u3057\u3055\u3001\u3068\u3044\u3046\u30D5\u30EC\u30FC\u30BA\u306E\u982D\u306E\u60AA\u3055\u306E\u7D20\u6674\u3089\u3057\u3055\u3088",
  "id" : 534651454531702785,
  "created_at" : "2014-11-18 10:16:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534651328803258369",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 534651328803258369,
  "created_at" : "2014-11-18 10:16:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534651312395153408",
  "text" : "\u300C\u4EBA\u9593\u8B83\u6B4C\u306F\u201C\u982D\u306E\u60AA\u3055\u201D\u306E\u8B83\u6B4C\u30C3\uFF01\uFF01\u4EBA\u9593\u306E\u7D20\u6674\u3089\u3057\u3055\u306F\u982D\u306E\u60AA\u3055\u306E\u7D20\u6674\u3089\u3057\u3055\uFF01\uFF01\u3044\u304F\u3089\u8CE2\u304F\u3066\u3082\u3053\u3044\u3064\u3089\u30BE\u30F3\u30D3\u306F\u201C\u982D\u306E\u60AA\u3055\u201D\u3092\u77E5\u3089\u3093\uFF01\u300D",
  "id" : 534651312395153408,
  "created_at" : "2014-11-18 10:16:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534649812914675713",
  "geo" : { },
  "id_str" : "534650232995209216",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u3042\u305F\u307E\u308F\u308B\u305D\u3046",
  "id" : 534650232995209216,
  "in_reply_to_status_id" : 534649812914675713,
  "created_at" : "2014-11-18 10:12:03 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534649483405955073",
  "text" : "\u30D6\u30ED\u30C3\u30AF\u304B\u3089\u306E\u30D6\u30ED\u30C3\u30AF\u89E3\u9664\u3067\u5931\u793C\u3057\u305F",
  "id" : 534649483405955073,
  "created_at" : "2014-11-18 10:09:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/534649290962907136\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/y4Khd9stKH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2t0sn-CUAIXiKV.jpg",
      "id_str" : "534649290765783042",
      "id" : 534649290765783042,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2t0sn-CUAIXiKV.jpg",
      "sizes" : [ {
        "h" : 301,
        "resize" : "fit",
        "w" : 280
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 280
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 280
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/y4Khd9stKH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534649290962907136",
  "text" : "\u7D75\u306B\u63CF\u3044\u305F\u3088\u3046\u306A\u610F\u8B58\u306E\u9AD8\u3044\u4EBA\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u305F http:\/\/t.co\/y4Khd9stKH",
  "id" : 534649290962907136,
  "created_at" : "2014-11-18 10:08:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534647443422318592",
  "text" : "\u307E\u3063\u3001\u307E\u3063",
  "id" : 534647443422318592,
  "created_at" : "2014-11-18 10:00:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534634999530520576",
  "geo" : { },
  "id_str" : "534646505877938176",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u3046\u3080",
  "id" : 534646505877938176,
  "in_reply_to_status_id" : 534634999530520576,
  "created_at" : "2014-11-18 09:57:14 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534632149714890752",
  "text" : "\u660E\u65E5\u306E\u98DB\u884C\u6A5F\u3001\u9593\u306B\u5408\u3046\u306E\u304B\u3081\u3063\u3061\u3083\u4E0D\u5B89",
  "id" : 534632149714890752,
  "created_at" : "2014-11-18 09:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/534631099087876096\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/IzUSYh6iRb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2tkJuCCAAAVP_H.jpg",
      "id_str" : "534631098911686656",
      "id" : 534631098911686656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2tkJuCCAAAVP_H.jpg",
      "sizes" : [ {
        "h" : 343,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IzUSYh6iRb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534619284324888577",
  "geo" : { },
  "id_str" : "534631099087876096",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 http:\/\/t.co\/IzUSYh6iRb",
  "id" : 534631099087876096,
  "in_reply_to_status_id" : 534619284324888577,
  "created_at" : "2014-11-18 08:56:01 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534576081638936576",
  "text" : "\u30A4\u30A4\u30CF\u30CA\u30B7",
  "id" : 534576081638936576,
  "created_at" : "2014-11-18 05:17:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534352612129112064",
  "geo" : { },
  "id_str" : "534352801644556289",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5358\u4F4D\u3092\u53D6\u308B\u306E\u306F\u7C21\u5358\u3060\u304C\u305D\u308C\u306F\u305D\u308C\u3068\u3057\u3066\u30CB\u30E3\u30FC\u30F3\u8AD6\u306E\u9053\u306F\u9577\u304F\u967A\u3057\u3044",
  "id" : 534352801644556289,
  "in_reply_to_status_id" : 534352612129112064,
  "created_at" : "2014-11-17 14:30:10 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534352246553604096",
  "geo" : { },
  "id_str" : "534352407711342592",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u307F\u304B\u3093\u304B\u30A2\u30A4\u30B9\u306E\u4E8C\u629E",
  "id" : 534352407711342592,
  "in_reply_to_status_id" : 534352246553604096,
  "created_at" : "2014-11-17 14:28:36 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534351818977849344",
  "geo" : { },
  "id_str" : "534352073475649536",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5F8C\u671F\u306F\u5BD2\u3044\u304B\u3089\u70AC\u71F5\u3067\u4E38\u304F\u306A\u308B\u5B9F\u7FD2\u304C\u304A\u3059\u3059\u3081",
  "id" : 534352073475649536,
  "in_reply_to_status_id" : 534351818977849344,
  "created_at" : "2014-11-17 14:27:16 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534349720638861317",
  "geo" : { },
  "id_str" : "534349908505944064",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3048\u3063\u3001\u5F15\u304D\u7D99\u304E\u306E\u6B04\u306B\u30C1\u30A7\u30C3\u30AF\u3064\u3044\u3066\u306A\u304B\u3063\u305F\u3063\u3066\u62C5\u5F53\u306E\u4EBA\u304C\u8A00\u3063\u3066\u305F\u3088",
  "id" : 534349908505944064,
  "in_reply_to_status_id" : 534349720638861317,
  "created_at" : "2014-11-17 14:18:40 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534347345035403264",
  "geo" : { },
  "id_str" : "534347543648276483",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30CB\u30E3\u30FC\u30F3\u8AD6\u306F\u306D\u3001\u6DF1\u304F\u3066\u91CD\u3044",
  "id" : 534347543648276483,
  "in_reply_to_status_id" : 534347345035403264,
  "created_at" : "2014-11-17 14:09:16 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/AfeIQuHcCE",
      "expanded_url" : "http:\/\/shindanmaker.com\/423222",
      "display_url" : "shindanmaker.com\/423222"
    } ]
  },
  "geo" : { },
  "id_str" : "534240991855656961",
  "text" : "end313124\u300C\uFF8E\uFF69\uFF71\uFF8A\uFF6F\uFF8A\uFF8A\uFF6B\uFF69\uFF8E\uFF69\uFF71www\uFF8E\uFF69\uFF71www\uFF8E\uFF69\uFF71\u300D http:\/\/t.co\/AfeIQuHcCE",
  "id" : 534240991855656961,
  "created_at" : "2014-11-17 07:05:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533906631629631489",
  "text" : "\u751F\u304D\u3066\u3044\u308B\uFF0C\u3068\u3044\u3046\u30D7\u30ED\u30D1\u30C6\u30A3\uFF0C\u5358\u4F53\u306B\u5206\u5272\u3055\u308C\u308B\u3068\u58CA\u308C\u308B",
  "id" : 533906631629631489,
  "created_at" : "2014-11-16 08:57:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 9, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533906357653479424",
  "text" : "\u5358\u4F53\u5206\u5272\u3055\u308C\u305F\u4EBA #\u4EBA",
  "id" : 533906357653479424,
  "created_at" : "2014-11-16 08:56:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533906316025020416",
  "text" : "RT @koizumi_fifty: \u3059\u3079\u3066\u306E\u4EBA\u9593\u306F\u5358\u4F53\u306B\u5206\u5272\u3059\u308B\u3068\u6B7B\u306C\uFF08triangulation conjecture\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533900647947464705",
    "text" : "\u3059\u3079\u3066\u306E\u4EBA\u9593\u306F\u5358\u4F53\u306B\u5206\u5272\u3059\u308B\u3068\u6B7B\u306C\uFF08triangulation conjecture\uFF09",
    "id" : 533900647947464705,
    "created_at" : "2014-11-16 08:33:28 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 533906316025020416,
  "created_at" : "2014-11-16 08:55:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533906164614852610",
  "text" : "\u9F20\u306F\u9F20\u3092\u547C\u3076",
  "id" : 533906164614852610,
  "created_at" : "2014-11-16 08:55:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533885124337610752",
  "text" : "\u30EB\u30C9\u30EB\u30D5\u3068\u30AF\u30BD\u307F\u305F\u3044\u306A\u8A3A\u65AD\u306E\u5B58\u5728\u3092\u601D\u3044\u51FA\u3057\u3066\u3057\u307E\u3063\u3066\u306A",
  "id" : 533885124337610752,
  "created_at" : "2014-11-16 07:31:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/AfeIQuHcCE",
      "expanded_url" : "http:\/\/shindanmaker.com\/423222",
      "display_url" : "shindanmaker.com\/423222"
    } ]
  },
  "geo" : { },
  "id_str" : "533884992493846528",
  "text" : "end313124\u300C\uFF8A\uFF6F\uFF8A\uFF8A\uFF6B\uFF69www\uFF8E\uFF69\uFF71\uFF8C\uFF67\uFF70\uFF6F\uFF8C\uFF67\uFF70\uFF6Fwww\uFF8A\uFF6F\uFF8A\uFF8A\uFF6B\uFF69\u300D http:\/\/t.co\/AfeIQuHcCE",
  "id" : 533884992493846528,
  "created_at" : "2014-11-16 07:31:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533877466201206785",
  "text" : "\u30C6\u30AD\u30B9\u30C8\u30A8\u30C7\u30A3\u30BF\u304B\u3089Twitter\uFF0E\u826F\u3044\uFF0E",
  "id" : 533877466201206785,
  "created_at" : "2014-11-16 07:01:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533873181329588224",
  "text" : "\u6642\u9593\u304C\uFF0C\u3042\u3042",
  "id" : 533873181329588224,
  "created_at" : "2014-11-16 06:44:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533871474340151299",
  "text" : "\u30D6\u30E9\u30B8\u30EB\u306E\u9078\u624B\uFF0C\u5B58\u5728\u3055\u3048\u3057\u306A\u3044",
  "id" : 533871474340151299,
  "created_at" : "2014-11-16 06:37:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533870630395863040",
  "text" : "\u304A\u8336",
  "id" : 533870630395863040,
  "created_at" : "2014-11-16 06:34:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533869948632702976",
  "text" : "\u3057\u3085\u308A\u3093\u3077\u307E\u3093",
  "id" : 533869948632702976,
  "created_at" : "2014-11-16 06:31:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533869924842614784",
  "text" : "\u8766\u4EBA",
  "id" : 533869924842614784,
  "created_at" : "2014-11-16 06:31:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533869275396599808",
  "text" : "\u30C0\u30A4\u30B9\u30BB\u30C3\u30C8\u8CB7\u3063\u3066\u304D\u305F",
  "id" : 533869275396599808,
  "created_at" : "2014-11-16 06:28:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533810803174952960",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 533810803174952960,
  "created_at" : "2014-11-16 02:36:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533810789325340673",
  "text" : "\u79C1\u5973\u3060\u3051\u3069\u3001\u5317\u3068\u5357\u3092\u9593\u9055\u3048\u308B\u4EBA\u306F\u3061\u3087\u3063\u3068\u2026",
  "id" : 533810789325340673,
  "created_at" : "2014-11-16 02:36:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 6, 14 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533810483334107136",
  "text" : "\u65B9\u89D27\u7D1A( @killfar  )",
  "id" : 533810483334107136,
  "created_at" : "2014-11-16 02:35:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533806859136688128",
  "text" : "\u9045\u523B\u3059\u308B\u5974\u306F\u2026",
  "id" : 533806859136688128,
  "created_at" : "2014-11-16 02:20:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/5g6FZ4xnWA",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/533806571747168256",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "533806598116745216",
  "geo" : { },
  "id_str" : "533806757059891200",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar https:\/\/t.co\/5g6FZ4xnWA",
  "id" : 533806757059891200,
  "in_reply_to_status_id" : 533806598116745216,
  "created_at" : "2014-11-16 02:20:23 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 19, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533806167437225984",
  "geo" : { },
  "id_str" : "533806571747168256",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u9045\u523B\u3059\u308B\u4EBA #\u4EBA",
  "id" : 533806571747168256,
  "in_reply_to_status_id" : 533806167437225984,
  "created_at" : "2014-11-16 02:19:39 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533806254485823488",
  "text" : "\u8A00\u8449\u304C\u9673\u8150\u5316\u3059\u308B\u901F\u5EA6\u3088\u308A\u65B0\u3057\u3044\u8A00\u3044\u56DE\u3057\u304C\u751F\u307E\u308C\u308B\u901F\u5EA6\u304C\u65E9\u304F\u3066\u826F\u304B\u3063\u305F(?)",
  "id" : 533806254485823488,
  "created_at" : "2014-11-16 02:18:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533805915472793600",
  "text" : "\u8CB4\u91CD\u306A\u304A\u8A71\u611F\u8B1D\u3001\u6A2A\u304B\u3089\u5931\u793C",
  "id" : 533805915472793600,
  "created_at" : "2014-11-16 02:17:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533805800691490816",
  "text" : "\u6C17\u9063\u3044\u306E\u8A00\u8449\u304C\u30C6\u30F3\u30D7\u30EC\u5316\u3001\u9673\u8150\u5316\u3059\u308B\u4F8B\u3001\u6563\u898B\u3055\u308C\u308B",
  "id" : 533805800691490816,
  "created_at" : "2014-11-16 02:16:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/533577130215370754\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/uOb2uhGdRc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2elkqMCUAAHGaQ.jpg",
      "id_str" : "533577130085339136",
      "id" : 533577130085339136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2elkqMCUAAHGaQ.jpg",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/uOb2uhGdRc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533577033213685760",
  "geo" : { },
  "id_str" : "533577130215370754",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar http:\/\/t.co\/uOb2uhGdRc",
  "id" : 533577130215370754,
  "in_reply_to_status_id" : 533577033213685760,
  "created_at" : "2014-11-15 11:07:55 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533576886400475136",
  "geo" : { },
  "id_str" : "533576931287908353",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u7518\u3044\u306A",
  "id" : 533576931287908353,
  "in_reply_to_status_id" : 533576886400475136,
  "created_at" : "2014-11-15 11:07:08 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533576778803998722",
  "geo" : { },
  "id_str" : "533576837612314627",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u5F53\u5206\u9811\u5F35\u308C\u308B",
  "id" : 533576837612314627,
  "in_reply_to_status_id" : 533576778803998722,
  "created_at" : "2014-11-15 11:06:46 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533576102258552832",
  "text" : "\u7D75\u306B\u63CF\u3044\u305F\u3088\u3046\u306A\u30EA\u30A2\u30EB\u30AF\u30BD\u30EA\u30D7\u3060\u3063\u305F\uFF08\u5B8C\uFF09",
  "id" : 533576102258552832,
  "created_at" : "2014-11-15 11:03:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533576019479785472",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u300C\u679C\u7269\u306E\u4E2D\u3067\u306F\u308A\u3093\u3054\u3063\u3066\u3042\u3093\u307E\u308A\u597D\u304D\u3058\u3083\u306A\u3044\u304B\u3082\u30FC\u300D\n\u304D\u308B\u3075\u3041\u300C\u304A\u308C\u305F\u307E\u3054\u3059\u304D\u300D\n\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u304A\u308C\u305F\u307E\u3054\u3059\u304D\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y^Y^Y\uFFE3",
  "id" : 533576019479785472,
  "created_at" : "2014-11-15 11:03:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533570573595467776",
  "text" : "\u30B7\u30FC\u30C4\u304C\u3042\u308B\u304B\u3089\u3044\u3044\u3082\u3093",
  "id" : 533570573595467776,
  "created_at" : "2014-11-15 10:41:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533570534567448576",
  "text" : "\u3082\u3046\u51AC\u3060\u3057\u6BDB\u5E03\u3044\u308B",
  "id" : 533570534567448576,
  "created_at" : "2014-11-15 10:41:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533568776210366464",
  "text" : "\u307E\u305B\u308A\u3055\u3093\u306E\u5DE5\u4F5C(?)\u3067\u3058\u308F\u3058\u308F\u4F38\u3073\u3066\u308B",
  "id" : 533568776210366464,
  "created_at" : "2014-11-15 10:34:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533568111207665665",
  "text" : "\u50D5\u3082\u305D\u3046\u601D\u3044\u307E\u3059",
  "id" : 533568111207665665,
  "created_at" : "2014-11-15 10:32:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533567993947500544",
  "text" : "\u89AA\u306B\u300C\u305D\u308C\u30B7\u30FC\u30C4\u3060\u3088\u300D\u3063\u3066\u8A00\u308F\u308C\u3066\u771F\u9854",
  "id" : 533567993947500544,
  "created_at" : "2014-11-15 10:31:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533567780784574464",
  "text" : "\u4E00\u65B9\u3048\u3093\u3069\u3055\u3093\u306F\u30B7\u30FC\u30C4\u3092\u6BDB\u5E03\u3060\u3068\u601D\u3063\u30663\u5E74\u4EE5\u4E0A\u4F7F\u3063\u3066\u308B\u304B\u3089\u9699\u306F\u306A\u3044",
  "id" : 533567780784574464,
  "created_at" : "2014-11-15 10:30:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30D0\u30F3\u30CC\u30FB\u30A4\u30C8\u30A6",
      "screen_name" : "Narizilla",
      "indices" : [ 3, 13 ],
      "id_str" : "13650632",
      "id" : 13650632
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Narizilla\/status\/533534485690589184\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/glpglp7mlb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2d-ya9CAAAWlKl.jpg",
      "id_str" : "533534485560557568",
      "id" : 533534485560557568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2d-ya9CAAAWlKl.jpg",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/glpglp7mlb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533567657144877057",
  "text" : "RT @Narizilla: \u306A\u3093\u3068\u3001\u9577\u5E74\u6BDB\u5E03\u306E\u4F7F\u3044\u65B9\u3092\u9593\u9055\u3048\u3066\u305F\u3088\uFF01 http:\/\/t.co\/glpglp7mlb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Narizilla\/status\/533534485690589184\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/glpglp7mlb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2d-ya9CAAAWlKl.jpg",
        "id_str" : "533534485560557568",
        "id" : 533534485560557568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2d-ya9CAAAWlKl.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/glpglp7mlb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533534485690589184",
    "text" : "\u306A\u3093\u3068\u3001\u9577\u5E74\u6BDB\u5E03\u306E\u4F7F\u3044\u65B9\u3092\u9593\u9055\u3048\u3066\u305F\u3088\uFF01 http:\/\/t.co\/glpglp7mlb",
    "id" : 533534485690589184,
    "created_at" : "2014-11-15 08:18:28 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30D0\u30F3\u30CC\u30FB\u30A4\u30C8\u30A6",
      "screen_name" : "Narizilla",
      "protected" : false,
      "id_str" : "13650632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000735263807\/8208a28c5fb4cb53c025c22277a01f6f_normal.jpeg",
      "id" : 13650632,
      "verified" : false
    }
  },
  "id" : 533567657144877057,
  "created_at" : "2014-11-15 10:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533552565011496961",
  "text" : "\u6B7B\u304C\u6700\u5F8C\u306B\u3084\u3063\u3066\u304F\u308B",
  "id" : 533552565011496961,
  "created_at" : "2014-11-15 09:30:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533551952450158592",
  "text" : "\u3093\u30FC\uFF0E\u3042\u30FC",
  "id" : 533551952450158592,
  "created_at" : "2014-11-15 09:27:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533538478114353152",
  "geo" : { },
  "id_str" : "533538539493789696",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u307E\u3041\u5730\u7406\u7684\u306B...\u306D",
  "id" : 533538539493789696,
  "in_reply_to_status_id" : 533538478114353152,
  "created_at" : "2014-11-15 08:34:35 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533538357565857794",
  "text" : "\u304B\u3064\u304B\u3064\u3068\u3093\u3068\u3093\uFF0E\u3088\u3044\uFF0E",
  "id" : 533538357565857794,
  "created_at" : "2014-11-15 08:33:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No dice plays God.",
      "screen_name" : "DicedontplayGod",
      "indices" : [ 0, 16 ],
      "id_str" : "2706785280",
      "id" : 2706785280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533274158847643649",
  "geo" : { },
  "id_str" : "533274334718988290",
  "in_reply_to_user_id" : 2706785280,
  "text" : "@DicedontplayGod \u4F7F\u3063\u3066\u308B\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306B\u3088\u3063\u3066\u3082\u9055\u3046\u3060\u308D\u3046\u3051\u3069\uFF0C\u540C\u6642\u306B\u8907\u6570\u5217\u3067\u898B\u308C\u308B\u3082\u306E\u3082\u3042\u308B\u3057\uFF0C\u30AA\u30B9\u30B9\u30E1\u30FC",
  "id" : 533274334718988290,
  "in_reply_to_status_id" : 533274158847643649,
  "created_at" : "2014-11-14 15:04:43 +0000",
  "in_reply_to_screen_name" : "DicedontplayGod",
  "in_reply_to_user_id_str" : "2706785280",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533273629224497153",
  "text" : "\u77E5\u8B58\u304C\u305D\u3082\u305D\u3082\u66D6\u6627\u306A\u306E\u306B\u4ED5\u5165\u308C\u305F\u6642\u671F\u304C\u6614\u904E\u304E\u3066\u304A\u307C\u308D\u304A\u307C\u308D\u3057\u3066\u308B",
  "id" : 533273629224497153,
  "created_at" : "2014-11-14 15:01:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533273503974170625",
  "text" : "\u7A7A\u306E\u5883\u754C\u3063\u3066\u3042\u308C\u3060\u3063\u3051\u9752\u5B50\u306E\u7E4B\u304C\u308A\u3067\u3042\u308C\u3060\u3063\u305F\u3063\u3051",
  "id" : 533273503974170625,
  "created_at" : "2014-11-14 15:01:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533273128558800896",
  "text" : "\u3042\uFF0C\u50D5\u306F\u683C\u30B2\u30FC\u306C\u308B\u306C\u308B\u52E2\u3060\u3063\u305F\u306E\u3067\uFF0C\u3055\u3063\u3071\u308A\u3067\u3059\u3051\u3069\u306D",
  "id" : 533273128558800896,
  "created_at" : "2014-11-14 14:59:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533272837482479616",
  "text" : "\u5C11\u306A\u304F\u3068\u3082\u30A2\u30CB\u30E1\u7248\u306B\u30EC\u30F3\u3068\u304B\u30EF\u30E9\u30AD\u30A2\u3068\u304B\u51FA\u3066\u3053\u306A\u304B\u3063\u305F\u304D\u304C\u3059\u308B\uFF0E",
  "id" : 533272837482479616,
  "created_at" : "2014-11-14 14:58:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533272732608114688",
  "text" : "\u30E1\u30EB\u30D6\u30E9\u3067\u30EC\u30F3\u3092\u4F7F\u3063\u3066\u305F\u3093\u3060\u3051\u3069\u6708\u59EB\u3063\u3066\u8A00\u3063\u305F\u3089\u3069\u3053\u307E\u3067\uFF1F\u30CD\u30ED\u30AB\u30AA\u30B9\uFF08\u3060\u3063\u305F\u3051\uFF1F\uFF09\u307E\u3067\uFF1F",
  "id" : 533272732608114688,
  "created_at" : "2014-11-14 14:58:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1000\u5186\u501F\u308A\u3066\u3044\u308B:\u56DE\u7DDA\u4E0D\u8981\u30B5\u30FC\u30D3\u30B9\u89E3",
      "screen_name" : "lastcat_",
      "indices" : [ 0, 9 ],
      "id_str" : "173891634",
      "id" : 173891634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533272277010227200",
  "geo" : { },
  "id_str" : "533272448406257665",
  "in_reply_to_user_id" : 173891634,
  "text" : "@lastcat_ \u3067\u3057\u3087\u3046\u306D\u3047\uFF0E\u60F0\u6027\u3067\u898B\u307E\u3057\u305F\u304C\u3072\u3069\u304B\u3063\u305F\uFF0E",
  "id" : 533272448406257665,
  "in_reply_to_status_id" : 533272277010227200,
  "created_at" : "2014-11-14 14:57:14 +0000",
  "in_reply_to_screen_name" : "lastcat_",
  "in_reply_to_user_id_str" : "173891634",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533272253706690560",
  "geo" : { },
  "id_str" : "533272339056558081",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30A2\u30CB\u30E1\u7248\u306F\u30D5\u30A1\u30F3\u304C\u7121\u304B\u3063\u305F\u3053\u3068\u306B\u3057\u3066\u3044\u308B\u306E\u3067\uFF0C\u898B\u306A\u3044\u307B\u3046\u304C\u5409\u3067\u3059",
  "id" : 533272339056558081,
  "in_reply_to_status_id" : 533272253706690560,
  "created_at" : "2014-11-14 14:56:48 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No dice plays God.",
      "screen_name" : "DicedontplayGod",
      "indices" : [ 0, 16 ],
      "id_str" : "2706785280",
      "id" : 2706785280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533272127999205376",
  "geo" : { },
  "id_str" : "533272257754173440",
  "in_reply_to_user_id" : 2706785280,
  "text" : "@DicedontplayGod \u30A2\u30AB\u30A6\u30F3\u30C8\u5206\u3051\u308B\u304B\u30EA\u30B9\u30C8\u4F5C\u308B\u306E\u304C\u3088\u3044\u304B\u3082\uFF0E\uFF0E\uFF0E",
  "id" : 533272257754173440,
  "in_reply_to_status_id" : 533272127999205376,
  "created_at" : "2014-11-14 14:56:28 +0000",
  "in_reply_to_screen_name" : "DicedontplayGod",
  "in_reply_to_user_id_str" : "2706785280",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533272005429059584",
  "text" : "\u6708\u59EB\uFF0C\u30DE\u30F3\u30AC\u3082\u3042\u308B\u306E\u304B\uFF0E\uFF08\u30A2\u30CB\u30E1\u306F\u898B\u305F\uFF0C\u307F\u305F\u3051\u3069\uFF09",
  "id" : 533272005429059584,
  "created_at" : "2014-11-14 14:55:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533270849067835393",
  "text" : "\u4E0B\u3089\u306A\u3044\u3053\u3068\u5927\u597D\u304D\u306A\u3093\u3060\u6587\u53E5\u3042\u308B\u304B",
  "id" : 533270849067835393,
  "created_at" : "2014-11-14 14:50:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533267574763433984",
  "text" : "\u30D1\u30B8\u30E3\u30DE\u306E\u4E0B\u306B\u666E\u6BB5\u7740\u3092\u7740\u3066\u3044\u308B\u30B9\u30BF\u30A4\u30EB\u304C\u60F3\u5B9A\u3055\u308C\u308B\uFF0E\u307F\u305F\u3044\u306A\uFF0E",
  "id" : 533267574763433984,
  "created_at" : "2014-11-14 14:37:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533267472434991104",
  "text" : "\u307F\u305F\u3044\u306A\u8A71\u3057\u3066\u305F\uFF0E",
  "id" : 533267472434991104,
  "created_at" : "2014-11-14 14:37:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533267456144314368",
  "text" : "\u3042\u3068\n\u30AF\u30EA\u30B9\u30DE\u30B9\u304C\u4ECA\u5E74\u3082\u3084\u3063\u3066\u304F\u308B\u2190\u308F\u304B\u308B\n\u30D1\u30B8\u30E3\u30DE\u3092\u8131\u3044\u3060\u3089\u51FA\u304B\u3051\u3088\u3046\u2190\u308F\u304B\u3089\u306A\u3044",
  "id" : 533267456144314368,
  "created_at" : "2014-11-14 14:37:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533267317627432960",
  "text" : "\u6B7B\u306C\u307E\u3067\uFF0C\u304C\u629C\u3051\u3066\u305F",
  "id" : 533267317627432960,
  "created_at" : "2014-11-14 14:36:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533267265022464000",
  "text" : "\u5E73\u5E38\u904B\u8EE2",
  "id" : 533267265022464000,
  "created_at" : "2014-11-14 14:36:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533267243975450626",
  "text" : "\u53BB\u5E74\u306E\u30AF\u30EA\u30B9\u30DE\u30B9\u524D\u5F8C\uFF0C\u4F55\u3057\u3066\u305F\uFF0E\u307F\u305F\u3044\u306A\u4F1A\u8A71\u304B\u3089Twilog\u3092\u6F01\u3063\u3066\u307F\u305F\u304C\u300C\u4EBA\u3092\u3042\u305A\u304D\u30D0\u30FC\u3067\u6BB4\u308B\u3068\u6B7B\u306C\u300D\u307F\u305F\u3044\u306A\u3053\u3068\u3057\u304B\u8A00\u3063\u3066\u306A\u304B\u3063\u305F",
  "id" : 533267243975450626,
  "created_at" : "2014-11-14 14:36:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533142688627830784",
  "geo" : { },
  "id_str" : "533164500665368576",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u3044\u3084\u3001\u6765\u9031\u306E\u4E88\u5B9A\u3060\u3063\u305F\u3093\u3060\u3051\u3069\u3001\u518D\u6765\u9031\u306B\u4F38\u3073\u305F",
  "id" : 533164500665368576,
  "in_reply_to_status_id" : 533142688627830784,
  "created_at" : "2014-11-14 07:48:17 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "intgrllllllllll",
      "indices" : [ 0, 16 ],
      "id_str" : "288580970",
      "id" : 288580970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533077906436550656",
  "geo" : { },
  "id_str" : "533078052826148865",
  "in_reply_to_user_id" : 288580970,
  "text" : "@intgrllllllllll \u6628\u65E5\u306E\u304A\u663C\u307E\u3067\u5E95\u307E\u3067\u5BD2\u304F\u306A\u304B\u3063\u305F\u3093\u3067\u3059\u304C\u306D...",
  "id" : 533078052826148865,
  "in_reply_to_status_id" : 533077906436550656,
  "created_at" : "2014-11-14 02:04:46 +0000",
  "in_reply_to_screen_name" : "intgrllllllllll",
  "in_reply_to_user_id_str" : "288580970",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "intgrllllllllll",
      "indices" : [ 0, 16 ],
      "id_str" : "288580970",
      "id" : 288580970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533076463969239040",
  "geo" : { },
  "id_str" : "533076556516585472",
  "in_reply_to_user_id" : 288580970,
  "text" : "@intgrllllllllll \u672D\u5E4C\u306F\u3084\u3070\u3044",
  "id" : 533076556516585472,
  "in_reply_to_status_id" : 533076463969239040,
  "created_at" : "2014-11-14 01:58:49 +0000",
  "in_reply_to_screen_name" : "intgrllllllllll",
  "in_reply_to_user_id_str" : "288580970",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533076049903357952",
  "text" : "\u5916\uFF0C\u3059\u3054\u3044\u96EA\u306A\u3093\u3067\u3059\u304C\uFF0C\u8AB0\u304C\u8CAC\u4EFB\u53D6\u3063\u3066\u304F\u308C\u308B\u3093\u3060",
  "id" : 533076049903357952,
  "created_at" : "2014-11-14 01:56:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532896867223232513",
  "text" : "\u98DB\u3076\u306E\u3092\u3084\u3081\u3066\uFF0C\u304A\u523A\u8EAB\u9B5A\u306B\u6539\u540D\u3057\u3066\u6B32\u3057\u3044",
  "id" : 532896867223232513,
  "created_at" : "2014-11-13 14:04:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532896775372161024",
  "text" : "\u30C8\u30D3\u30A6\u30AA\uFF0C\u98DB\u3076\u3088\u308A\u304A\u523A\u8EAB\u306B\u306A\u3063\u3066\u304F\u308C\u305F\u307B\u3046\u304C\u50D5\u306F\u3046\u308C\u3057\u3044",
  "id" : 532896775372161024,
  "created_at" : "2014-11-13 14:04:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532896614340259840",
  "text" : "\u30EB\u30FC\u30E9\u4F7F\u3044\u305F\u3059\u304E\u3066",
  "id" : 532896614340259840,
  "created_at" : "2014-11-13 14:03:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532895306665308161",
  "geo" : { },
  "id_str" : "532895588384116737",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u3042\u30FC\uFF0C\u30D0\u30A4\u30AA\u30EA\u30CA\u30FC\u306E\u7537\u306E\u5B50\u304C\u51FA\u3066\u304F\u308B\u3084\u3064\u3067\u3059\u306D\uFF0E\u6700\u5F8C\u306E\u30B7\u30FC\u30F3\u3067\u30E0\u30BF\u304C\u89AA\u6307\u3092\u7ACB\u3066\u3066\u6EB6\u9271\u7089\u306B\u6C88\u3093\u3067\u3044\u304F\u30B7\u30FC\u30F3\u306F\u6D99\u306A\u3057\u306B\u306F\u898B\u3089\u308C\u306A\u304B\u3063\u305F\u3067\u3059\u306D\uFF0E",
  "id" : 532895588384116737,
  "in_reply_to_status_id" : 532895306665308161,
  "created_at" : "2014-11-13 13:59:43 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532895326051397632",
  "text" : "\u305D\u3046\u3044\u3048\u3070\uFF0C\u4ECA\u65E5\u304D\u308B\u3075\u3041\u6765\u306A\u304B\u3063\u305F\u3051\u3069\uFF0C\u6765\u308B\u8AAD\u307F\u3067\u5348\u524D\u4E2D\u306B\u30B3\u30C3\u30D7\u306B\u6C37\u5165\u308C\u3066\u3057\u307E\u3063\u305F\uFF0E\u3054\u3081\u3093\uFF0E",
  "id" : 532895326051397632,
  "created_at" : "2014-11-13 13:58:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532895066075852801",
  "geo" : { },
  "id_str" : "532895131670552577",
  "in_reply_to_user_id" : 155546700,
  "text" : "@noumisoko \u8033\u304C\uFF0C\u30D1\u30D5\u30A7\u306B\uFF0C\u3067\u3057\u305F",
  "id" : 532895131670552577,
  "in_reply_to_status_id" : 532895066075852801,
  "created_at" : "2014-11-13 13:57:54 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532894890355486720",
  "geo" : { },
  "id_str" : "532895066075852801",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u305D\u308C\u306B\u6BD4\u3079\u3066\u8033\u306B\u30D1\u30D5\u30A7\u304C\u8A70\u307E\u308B\u3053\u3068\u3063\u3066\u5C11\u306A\u305D\u3046\u3067\u3059\u306D",
  "id" : 532895066075852801,
  "in_reply_to_status_id" : 532894890355486720,
  "created_at" : "2014-11-13 13:57:39 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532894319162556417",
  "text" : "\u533B\u5B66\u306B\u95A2\u308F\u308B\u4EBA\u9593\u3068\u300C\u8033\u306B\u30D1\u30D5\u30A7\u304C\u8A70\u3081\u3089\u308C\u305F\u3089\u30E4\u30D0\u30A4\u300D\uFF0C\u307F\u305F\u3044\u306A\u8A71\u3057\u3066\u308B\u306E\uFF0C\u6211\u306A\u304C\u3089\u982D\u308F\u308B\u3044",
  "id" : 532894319162556417,
  "created_at" : "2014-11-13 13:54:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532893915624386561",
  "geo" : { },
  "id_str" : "532894059585474562",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u5965\u306E\u307B\u3046\u307E\u3067\u884C\u3063\u305F\u3089\u3084\u3070\u3044\u3093\u3058\u3083\u306A\u3044\u3067\u3059\u304B",
  "id" : 532894059585474562,
  "in_reply_to_status_id" : 532893915624386561,
  "created_at" : "2014-11-13 13:53:39 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532889397515915264",
  "geo" : { },
  "id_str" : "532893698791440384",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u8033\u306B\u8A70\u307E\u3063\u3066\u8033\u9F3B\u79D1\u306B\u884C\u3063\u3066\u7D4C\u7DEF\u3092\u8AAC\u660E\u3059\u308B\u306E\uFF0C\u7D1B\u308C\u3082\u306A\u304F\u7F70\u30B2\u30FC\u30E0",
  "id" : 532893698791440384,
  "in_reply_to_status_id" : 532889397515915264,
  "created_at" : "2014-11-13 13:52:13 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532888890017722369",
  "geo" : { },
  "id_str" : "532889020670291968",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30D1\u30D5\u30A7\u98DF\u3079\u305F\u3044",
  "id" : 532889020670291968,
  "in_reply_to_status_id" : 532888890017722369,
  "created_at" : "2014-11-13 13:33:37 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532888453814296576",
  "geo" : { },
  "id_str" : "532888516699496448",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u624B\u306F\u3069\u3046\u3057\u305F\u3089",
  "id" : 532888516699496448,
  "in_reply_to_status_id" : 532888453814296576,
  "created_at" : "2014-11-13 13:31:37 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532888448269422592",
  "text" : "\u8033\u306E\u4E0B\uFF1F\u984E\u306E\u4ED8\u3051\u6839\uFF1F\u304C\u51B7\u305F\u3044\u305F\u3044",
  "id" : 532888448269422592,
  "created_at" : "2014-11-13 13:31:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532888375561158657",
  "text" : "\u624B\u888B\u3088\u308A\u8033\u3042\u3066\u304C\u6B32\u3057\u3044",
  "id" : 532888375561158657,
  "created_at" : "2014-11-13 13:31:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532888022295928834",
  "text" : "\u3042\u3063\u305F\u304B\u3044\u3089\u30FC\u3081\u3093\uFF01",
  "id" : 532888022295928834,
  "created_at" : "2014-11-13 13:29:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532887427828813825",
  "text" : "\u5927\u5730\u306B\u8A66\u3055\u308C\u308B\u51AC\u304C\u59CB\u307E\u3063\u305F\u2026",
  "id" : 532887427828813825,
  "created_at" : "2014-11-13 13:27:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532887256902545410",
  "text" : "\u70AC\u71F5\u3041\uFF01",
  "id" : 532887256902545410,
  "created_at" : "2014-11-13 13:26:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532886823832276994",
  "text" : "\u80BA\u304C\u51B7\u305F\u3044",
  "id" : 532886823832276994,
  "created_at" : "2014-11-13 13:24:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/532884353349468160\/photo\/1",
      "indices" : [ 2, 24 ],
      "url" : "http:\/\/t.co\/iqmqbTBsC4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Uvft6CQAAdYUh.jpg",
      "id_str" : "532884352858734592",
      "id" : 532884352858734592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Uvft6CQAAdYUh.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/iqmqbTBsC4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532884353349468160",
  "text" : "\u3046 http:\/\/t.co\/iqmqbTBsC4",
  "id" : 532884353349468160,
  "created_at" : "2014-11-13 13:15:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/532884194750234625\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/nCeqkqOx0G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2UvWgbCEAAmCh7.jpg",
      "id_str" : "532884194620215296",
      "id" : 532884194620215296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2UvWgbCEAAmCh7.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/nCeqkqOx0G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532884194750234625",
  "text" : "\u5916\u306B\u51FA\u305F\u3089\u96EA\u56FD\u3060\u3063\u305F\u8F9B\u3044 http:\/\/t.co\/nCeqkqOx0G",
  "id" : 532884194750234625,
  "created_at" : "2014-11-13 13:14:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532846097287221248",
  "text" : "\u96EA\u306B\u81EA\u6478\u3089\u308C\u308B\u3068\u8F9B\u3044",
  "id" : 532846097287221248,
  "created_at" : "2014-11-13 10:43:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532842403749560320",
  "text" : "\u61B6\u6E2C\u3068\u4FFA\u30B9\u30C8\u30FC\u30EA\u30FC\u3060\u3051\u3067\u6975\u7AEF\u306A\u4E8B\u8A00\u3046\u4EBA\u9593\u306B\u306F\u306A\u308A\u305F\u304F\u306A\u3044\u305E\u3044",
  "id" : 532842403749560320,
  "created_at" : "2014-11-13 10:28:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532842248979755008",
  "geo" : { },
  "id_str" : "532842323160227840",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u61B6\u6E2C\u3067\u6975\u7AEF\u306A\u4E8B\u8A00\u308F\u306A\u304D\u3083\u826F\u3044\u306E\u3067\u306F",
  "id" : 532842323160227840,
  "in_reply_to_status_id" : 532842248979755008,
  "created_at" : "2014-11-13 10:28:04 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532842121313525761",
  "text" : "\u5B9F\u60C5\u304C\u3088\u304F\u5206\u304B\u3089\u306A\u3044\u6642\u306B\u306F\u767A\u8A00\u3057\u306A\u3044\u306E\u304C\u5409\u3058\u3083",
  "id" : 532842121313525761,
  "created_at" : "2014-11-13 10:27:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532840849281781760",
  "text" : "\u706B\u3092\u653E\u3061\u305F\u3044",
  "id" : 532840849281781760,
  "created_at" : "2014-11-13 10:22:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532840614497239041",
  "text" : "\u5B58\u5728\u3068\u5168\u79F0\u306E\u533A\u5225\u304C\u3064\u304B\u306A\u3044\u6709\u8C61\u7121\u8C61",
  "id" : 532840614497239041,
  "created_at" : "2014-11-13 10:21:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532839670145507330",
  "text" : "\u7D44\u307F\u5408\u308F\u305B\u7206\u767A\u306B\u5DFB\u304D\u8FBC\u307E\u308C\u3066\u7206\u6B7B",
  "id" : 532839670145507330,
  "created_at" : "2014-11-13 10:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532824240693575680",
  "text" : "\u306A\u3093\u3068\u304B\u308C\u3044\u3093\u3055\u3093\u3092\uFF08\u5F62\u5F0F\u7684\u306B\uFF09\u4E3B\u50AC\u306B\u636E\u3048\u3066\uFF0C\u5B9F\u52D9\u306F\u4ED6\u306E\u4EBA\u304C\u3084\u308C\u3070\u3044\u3044\u3093\u3060\u3088",
  "id" : 532824240693575680,
  "created_at" : "2014-11-13 09:16:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532821765748035586",
  "text" : "\u4EBA\u306F\u6642\u3068\u3057\u3066\uFF0C\u30DD\u30A4\u30F3\u30C8\u30AB\u30FC\u30C9\u306E\u5974\u96B7\u306B\u306A\u308B\uFF0E",
  "id" : 532821765748035586,
  "created_at" : "2014-11-13 09:06:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532820848244043776",
  "geo" : { },
  "id_str" : "532820978905006080",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u3084\u308B\u3081\u3053\u3042\u306E\u69D8\u5B50\u6B21\u7B2C\u304B\u306A...",
  "id" : 532820978905006080,
  "in_reply_to_status_id" : 532820848244043776,
  "created_at" : "2014-11-13 09:03:15 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532820245614850048",
  "geo" : { },
  "id_str" : "532820658468569088",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u6CCA\u307E\u308A\u8FBC\u307F\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B",
  "id" : 532820658468569088,
  "in_reply_to_status_id" : 532820245614850048,
  "created_at" : "2014-11-13 09:01:58 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532819982548086785",
  "geo" : { },
  "id_str" : "532820112189829120",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u5E97\u756A\u3092\u3057\u306A\u304F\u3066\u3082\u5341\u5206\u3075\u308C\u3042\u3048\u308B\u3068\u601D\u3046\u306E\u3067\u3059\u304C\u305D\u308C\u306F",
  "id" : 532820112189829120,
  "in_reply_to_status_id" : 532819982548086785,
  "created_at" : "2014-11-13 08:59:48 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532814103513812993",
  "geo" : { },
  "id_str" : "532814216105709569",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u306A\u3093\u306E\u4ED5\u4E8B\u3082\u306A\u3044\uFF0E\u5B8C\u5168\u30B2\u30B9\u30C8\u3067\u3059\u305C\uFF0E\uFF08\u5BBF\u306F\u78BA\u4FDD\u3067\u304D\u307E\u3057\u305F\u30FC\uFF09",
  "id" : 532814216105709569,
  "in_reply_to_status_id" : 532814103513812993,
  "created_at" : "2014-11-13 08:36:22 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532814033917714432",
  "geo" : { },
  "id_str" : "532814061990211584",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u884C\u304F",
  "id" : 532814061990211584,
  "in_reply_to_status_id" : 532814033917714432,
  "created_at" : "2014-11-13 08:35:46 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532813989177073664",
  "text" : "pepper\u541B\uFF0C\u3081\u3063\u3061\u3083\u4F1A\u3044\u305F\u3044",
  "id" : 532813989177073664,
  "created_at" : "2014-11-13 08:35:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532813879638626304",
  "text" : "\u307B\u3068\u3093\u3069\u3044\u306A\u3044\uFF08\u5C11\u3057\u3044\u308B\uFF09",
  "id" : 532813879638626304,
  "created_at" : "2014-11-13 08:35:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532813590558810113",
  "text" : "\u53BB\u5E74\u306F\u305D\u3093\u306A\u3093\u3060\u3063\u305F\u3051\u3069\u4ECA\u5E74\u306F\u3069\u3046\u306A\u3093\u3060\u308D\uFF08\u77E5\u3089\u306C\uFF09",
  "id" : 532813590558810113,
  "created_at" : "2014-11-13 08:33:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532813528051097600",
  "text" : "s2s\uFF0CNF\u3067\u5FC5\u8981\u3068\u3055\u308C\u308B\u4EBA\u9593\u306E\u6570\u306B\u5BFE\u3057\u3066NF\u306B\u3084\u308B\u6C17\u306E\u3042\u308B\u4EBA\u9593\u304C\u5C11\u306A\u3044",
  "id" : 532813528051097600,
  "created_at" : "2014-11-13 08:33:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532812498890547200",
  "text" : "\u306F\u3044",
  "id" : 532812498890547200,
  "created_at" : "2014-11-13 08:29:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532781622970433537",
  "geo" : { },
  "id_str" : "532781663197990912",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u305D\u308C\u306A\u2026",
  "id" : 532781663197990912,
  "in_reply_to_status_id" : 532781622970433537,
  "created_at" : "2014-11-13 06:27:01 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532780333557481472",
  "text" : "\u30B5\u30F3\u30BF\u3055\u3093\u306B\u4EFB\u610F\u306E\u4F4D\u76F8\u7A7A\u9593\u3092\u4F5C\u308C\u308B\u7C98\u571F\u8CB0\u3044\u305F\u3044",
  "id" : 532780333557481472,
  "created_at" : "2014-11-13 06:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532732705834672129",
  "geo" : { },
  "id_str" : "532732947585966080",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u7CF8\u3053\u3093\u306B\u3083\u304F\u828B\u304B\u3089\u4F5C\u3089\u308C\u3066\u308B\u306B\u6C7A\u307E\u3063\u3066\u3044\u307E\u3059",
  "id" : 532732947585966080,
  "in_reply_to_status_id" : 532732705834672129,
  "created_at" : "2014-11-13 03:13:27 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u307F\u306A\u3061\u3083\u3093",
      "screen_name" : "rumichang",
      "indices" : [ 0, 10 ],
      "id_str" : "242763253",
      "id" : 242763253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532732324241084418",
  "geo" : { },
  "id_str" : "532732608598114305",
  "in_reply_to_user_id" : 242763253,
  "text" : "@rumichang \u4E00\u5FDC\u82F1\u8A9E\u3067\u308299\u2103\/210F\u3063\u3066\u66F8\u3044\u3066\u3042\u308A\u307E\u3059\u306D",
  "id" : 532732608598114305,
  "in_reply_to_status_id" : 532732324241084418,
  "created_at" : "2014-11-13 03:12:06 +0000",
  "in_reply_to_screen_name" : "rumichang",
  "in_reply_to_user_id_str" : "242763253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532731895981678592",
  "text" : "\u7FFB\u8A33\u3053\u3093\u306B\u3083\u304F\u3063\u3066\u7FFB\u8A33\u3053\u3093\u306B\u3083\u304F\u828B\u304B\u3089\u51FA\u6765\u308B\u308F\u3051\u3060\u3088\u306D",
  "id" : 532731895981678592,
  "created_at" : "2014-11-13 03:09:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532730416734556162",
  "text" : "3(3)\u5206\u304C\u3058\u308F\u308A\u3059\u304E\u308B(\u3058\u308F\u308A\u3059\u304E\u308B)",
  "id" : 532730416734556162,
  "created_at" : "2014-11-13 03:03:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532730204209168384",
  "geo" : { },
  "id_str" : "532730256218537984",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u305F\u3076\u3093\u9AD8\u3044\u3084\u3064",
  "id" : 532730256218537984,
  "in_reply_to_status_id" : 532730204209168384,
  "created_at" : "2014-11-13 03:02:45 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532730198303588352",
  "text" : "\u82F1\u8A9E\u306E\u65B9\u304C\u308F\u304B\u308A\u3084\u3059\u3044\u306D",
  "id" : 532730198303588352,
  "created_at" : "2014-11-13 03:02:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532730155634941952",
  "text" : "\u6B8B\u57FA\u304C\u63D0\u4F9B\u3059\u308B\u6E96\u5099\u843D\u3061\u308B\u3068\u307E\u3067\u306F3(3)\u5206\u5F85\u3061\u307E\u3059\u3002",
  "id" : 532730155634941952,
  "created_at" : "2014-11-13 03:02:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/532729979147390977\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/8NuX6FsUWU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2SjF9hIIAAdfwr.jpg",
      "id_str" : "532729978744741888",
      "id" : 532729978744741888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2SjF9hIIAAdfwr.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/8NuX6FsUWU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532729979147390977",
  "text" : "\u30A4\u30F3\u30C9\u30CD\u30B7\u30A2\u306E\u304A\u571F\u7523\u306E\u30B3\u30FC\u30D2\u30FC(\u30B8\u30E3\u30B3\u30A6\u732B\u304C\u3044\u3063\u305F\u3093\u98DF\u3079\u305F\u3084\u3064)\u3082\u3089\u3063\u305F\u3051\u3069\u88CF\u306E\u548C\u8A33\u304C\u30A8\u30AD\u30B5\u30A4\u30C8\u3081\u3044\u3066\u3066\u3042\u308C http:\/\/t.co\/8NuX6FsUWU",
  "id" : 532729979147390977,
  "created_at" : "2014-11-13 03:01:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532728885406744576",
  "geo" : { },
  "id_str" : "532729047722119168",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u306A\u308B\u307B\u3069",
  "id" : 532729047722119168,
  "in_reply_to_status_id" : 532728885406744576,
  "created_at" : "2014-11-13 02:57:57 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532728128083202048",
  "text" : "\u5929\u6C17\u96EA\u3063\u3066\u5225\u540D\u3042\u308B\u306E\u304B\u306A",
  "id" : 532728128083202048,
  "created_at" : "2014-11-13 02:54:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532499220364660737",
  "text" : "\u8339\u3067\u4E8C\u5341\u9762\u4F53",
  "id" : 532499220364660737,
  "created_at" : "2014-11-12 11:44:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532496196904841216",
  "text" : "KAGEROU",
  "id" : 532496196904841216,
  "created_at" : "2014-11-12 11:32:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532495036814864384",
  "geo" : { },
  "id_str" : "532495067521376257",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u306F\u3044",
  "id" : 532495067521376257,
  "in_reply_to_status_id" : 532495036814864384,
  "created_at" : "2014-11-12 11:28:12 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532494796573528064",
  "geo" : { },
  "id_str" : "532494851665698816",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u3055\u3059\u304C\u306B\u634F\u9020\u306FNG",
  "id" : 532494851665698816,
  "in_reply_to_status_id" : 532494796573528064,
  "created_at" : "2014-11-12 11:27:20 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532491906752589824",
  "geo" : { },
  "id_str" : "532491957855997952",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU \u304B\u308F\u3044\u3044...",
  "id" : 532491957855997952,
  "in_reply_to_status_id" : 532491906752589824,
  "created_at" : "2014-11-12 11:15:50 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532491777706430465",
  "text" : "\uFF96\uFF96\uFF96\uFF96\u30A2\u30AB\u30A6\u30F3\u30E8\uFF0C\u30D5\u30E7\u30E8\u30FC\u3057\u3066\u308B\u306E\u306B\u3057\u3070\u3089\u304F\u898B\u3066\u306A\u304B\u3063\u305F\u306A\uFF0E",
  "id" : 532491777706430465,
  "created_at" : "2014-11-12 11:15:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532491291204919297",
  "geo" : { },
  "id_str" : "532491481806667776",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU \u516C\u5B89\u3068\u304B\u6765\u3066\u3082\u731B\u7363\u304C\u3084\u3063\u3064\u3051\u3066\u304F\u308C\u305D\u3046",
  "id" : 532491481806667776,
  "in_reply_to_status_id" : 532491291204919297,
  "created_at" : "2014-11-12 11:13:57 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532491308217020416",
  "text" : "\uFF8A\uFF70\uFF72",
  "id" : 532491308217020416,
  "created_at" : "2014-11-12 11:13:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532491226008670208",
  "geo" : { },
  "id_str" : "532491281738379264",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \uFF71\uFF6F\uFF8A\uFF72",
  "id" : 532491281738379264,
  "in_reply_to_status_id" : 532491226008670208,
  "created_at" : "2014-11-12 11:13:09 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/532491250574696448\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rfMkFpPviK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2PJ9MpCQAMpTdr.png",
      "id_str" : "532491234162393091",
      "id" : 532491234162393091,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2PJ9MpCQAMpTdr.png",
      "sizes" : [ {
        "h" : 317,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 317
      } ],
      "display_url" : "pic.twitter.com\/rfMkFpPviK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532491250574696448",
  "text" : "http:\/\/t.co\/rfMkFpPviK",
  "id" : 532491250574696448,
  "created_at" : "2014-11-12 11:13:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532490907300265984",
  "geo" : { },
  "id_str" : "532491047633301506",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u30CF\u30A4\uFF01\uFF01\uFF01",
  "id" : 532491047633301506,
  "in_reply_to_status_id" : 532490907300265984,
  "created_at" : "2014-11-12 11:12:13 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532490930805161985",
  "geo" : { },
  "id_str" : "532491000145379328",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU OU\u30B5\u30FC\u30AB\u30B9\u96C6\u56E3\u304B\u306A",
  "id" : 532491000145379328,
  "in_reply_to_status_id" : 532490930805161985,
  "created_at" : "2014-11-12 11:12:02 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532490907300265984",
  "geo" : { },
  "id_str" : "532490947037130752",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u30CF\u30A4\uFF01",
  "id" : 532490947037130752,
  "in_reply_to_status_id" : 532490907300265984,
  "created_at" : "2014-11-12 11:11:49 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532490842561187840",
  "geo" : { },
  "id_str" : "532490874169483264",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u306F\u3044\u306F\u3044",
  "id" : 532490874169483264,
  "in_reply_to_status_id" : 532490842561187840,
  "created_at" : "2014-11-12 11:11:32 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532490846315094016",
  "text" : "\u305D\u3046\u304B\u3053\u308C\u3082\u4E00\u8F2A\u8ECA\u304B",
  "id" : 532490846315094016,
  "created_at" : "2014-11-12 11:11:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 3, 16 ],
      "id_str" : "86075525",
      "id" : 86075525
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 18, 28 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/S9G4LyuW7e",
      "expanded_url" : "http:\/\/www.kohnan-eshop.com\/img\/goods\/S\/4522831982059.jpg",
      "display_url" : "kohnan-eshop.com\/img\/goods\/S\/45\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532490836974395392",
  "text" : "RT @_primenumber: @end313124 http:\/\/t.co\/S9G4LyuW7e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/S9G4LyuW7e",
        "expanded_url" : "http:\/\/www.kohnan-eshop.com\/img\/goods\/S\/4522831982059.jpg",
        "display_url" : "kohnan-eshop.com\/img\/goods\/S\/45\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "532490651841998849",
    "geo" : { },
    "id_str" : "532490742975852544",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 http:\/\/t.co\/S9G4LyuW7e",
    "id" : 532490742975852544,
    "in_reply_to_status_id" : 532490651841998849,
    "created_at" : "2014-11-12 11:11:00 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "protected" : false,
      "id_str" : "86075525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829246455\/df79f6a468f8240ff902e4e4c9c324b5_normal.png",
      "id" : 86075525,
      "verified" : false
    }
  },
  "id" : 532490836974395392,
  "created_at" : "2014-11-12 11:11:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532490742975852544",
  "geo" : { },
  "id_str" : "532490785946468352",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u305D\u3063\u3061\u3058\u3083\u306D\u3047",
  "id" : 532490785946468352,
  "in_reply_to_status_id" : 532490742975852544,
  "created_at" : "2014-11-12 11:11:11 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 10, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532490750714331137",
  "text" : "\u4E00\u8F2A\u8ECA\u3067\u901A\u5B66\u3059\u308B\u4EBA #\u4EBA",
  "id" : 532490750714331137,
  "created_at" : "2014-11-12 11:11:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532490651841998849",
  "text" : "\u4E00\u8F2A\u8ECA\u3068\u304B\u8A00\u3046\u306E\u4E45\u3005\u306B\u4E57\u308A\u305F\u3059\u304E\u308B",
  "id" : 532490651841998849,
  "created_at" : "2014-11-12 11:10:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532490282520965120",
  "geo" : { },
  "id_str" : "532490429745213441",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u305D\u3046\u3044\u3048\u3070\uFF96\uFF96\uFF96\uFF96\uFF72\uFF96\u306A\u3093\u304B\u3084\u3089\u306A\u3044\u3093\u3067\u3059\u304BNF",
  "id" : 532490429745213441,
  "in_reply_to_status_id" : 532490282520965120,
  "created_at" : "2014-11-12 11:09:46 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532490090212126720",
  "geo" : { },
  "id_str" : "532490177449439232",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u7766\u6708\u3055\u3093\u306E\u4F01\u753B\u3063\u307D\u3044\u3067\u3059",
  "id" : 532490177449439232,
  "in_reply_to_status_id" : 532490090212126720,
  "created_at" : "2014-11-12 11:08:46 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532490054845730816",
  "text" : "\u96E2\u6563\u4F4D\u76F8\u3068\u304B\u3058\u3083\u306A\u3044\u306E\uFF08\u9069\u5F53\uFF09",
  "id" : 532490054845730816,
  "created_at" : "2014-11-12 11:08:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532489645217439745",
  "geo" : { },
  "id_str" : "532489708320735234",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 ClosedYo",
  "id" : 532489708320735234,
  "in_reply_to_status_id" : 532489645217439745,
  "created_at" : "2014-11-12 11:06:54 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532489667556282369",
  "text" : "\u6765\u308B\u304B\u306A\u3063\u3066\u601D\u3063\u305F\u304B\u3089\u5148\u306B\u6253\u3063\u3066\u304A\u3044\u305F",
  "id" : 532489667556282369,
  "created_at" : "2014-11-12 11:06:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532489614292836353",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u306F\u3044",
  "id" : 532489614292836353,
  "created_at" : "2014-11-12 11:06:31 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532489492746092544",
  "geo" : { },
  "id_str" : "532489562807734272",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u306F\u3044",
  "id" : 532489562807734272,
  "in_reply_to_status_id" : 532489492746092544,
  "created_at" : "2014-11-12 11:06:19 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532489540322066432",
  "text" : "\u300C\u7F36\u3092\u8E74\u3063\u305F\u3068\u601D\u3063\u305F\u3089\u4FFA\u304C\u8ECA\u306B\u8E74\u3089\u308C\u3066\u3044\u305F\u300D",
  "id" : 532489540322066432,
  "created_at" : "2014-11-12 11:06:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532489443609804801",
  "text" : "\u7F36\u3092\u8E74\u308D\u3046\u3068\u3057\u305F\u7D50\u679C\uFF0C\u8ECA\u306B\u8E74\u3089\u308C\u305F\u3053\u30FC\u3084\u541B\u306E\u30A8\u30D4\u30BD\u30FC\u30C9\u304C\u9762\u767D\u3059\u304E\u3066\u6642\u3005\u601D\u3044\u51FA\u3057\u3066\u7B11\u3046",
  "id" : 532489443609804801,
  "created_at" : "2014-11-12 11:05:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4ECA\u6708\u306E\u30C6\u30FC\u30DE",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532488996497018880",
  "text" : "\u4ECA\u6708\u306E\u30C6\u30FC\u30DE \u300C\u300C\u306F\u3044\u300D\u3067\u5E83\u304C\u308B\u305F\u306E\u3057\u3044\u304B\u3044\u308F\u300D #\u4ECA\u6708\u306E\u30C6\u30FC\u30DE",
  "id" : 532488996497018880,
  "created_at" : "2014-11-12 11:04:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7766\u6708\u30FE\uFF08\u30FB\u03C9\u30FB\u273F\uFF09\u30CE",
      "screen_name" : "owlmutsuki",
      "indices" : [ 0, 11 ],
      "id_str" : "283993563",
      "id" : 283993563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532488743270113280",
  "geo" : { },
  "id_str" : "532488768905678849",
  "in_reply_to_user_id" : 283993563,
  "text" : "@owlmutsuki \u306F\u3044",
  "id" : 532488768905678849,
  "in_reply_to_status_id" : 532488743270113280,
  "created_at" : "2014-11-12 11:03:10 +0000",
  "in_reply_to_screen_name" : "owlmutsuki",
  "in_reply_to_user_id_str" : "283993563",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7766\u6708\u30FE\uFF08\u30FB\u03C9\u30FB\u273F\uFF09\u30CE",
      "screen_name" : "owlmutsuki",
      "indices" : [ 0, 11 ],
      "id_str" : "283993563",
      "id" : 283993563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532488613376708608",
  "geo" : { },
  "id_str" : "532488682112958465",
  "in_reply_to_user_id" : 283993563,
  "text" : "@owlmutsuki \u540D\u524D\u304C",
  "id" : 532488682112958465,
  "in_reply_to_status_id" : 532488613376708608,
  "created_at" : "2014-11-12 11:02:49 +0000",
  "in_reply_to_screen_name" : "owlmutsuki",
  "in_reply_to_user_id_str" : "283993563",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532488613611569153",
  "text" : "\u300C\u306F\u3044\u300D\u3060\u3051\u3067\u4F1A\u8A71\u3059\u308B\u306E\u3053\u308C\u306A\u3093\u304B\u65E2\u8996\u611F\u3042\u308B\u3068\u601D\u3063\u305F\u3089\u3042\u308C\u3060\u300CYo\u300D\u3060",
  "id" : 532488613611569153,
  "created_at" : "2014-11-12 11:02:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532488503381082112",
  "geo" : { },
  "id_str" : "532488539812802560",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u306F\u3044",
  "id" : 532488539812802560,
  "in_reply_to_status_id" : 532488503381082112,
  "created_at" : "2014-11-12 11:02:15 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532488402159931392",
  "text" : "\u5C11\u5B50\u9AD8\u9F62\u5316\u4E3C\u98DF\u3079\u305F\u304F\u306A\u3055\u3059\u304E\u308B...",
  "id" : 532488402159931392,
  "created_at" : "2014-11-12 11:01:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532488250208694272",
  "text" : "\u4E3B\u306B\u50D5\u306E\u305B\u3044\u3060",
  "id" : 532488250208694272,
  "created_at" : "2014-11-12 11:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532488199826710530",
  "text" : "\u306A\u3093\u3060\u3053\u306E\u3084\u308A\u3068\u308A",
  "id" : 532488199826710530,
  "created_at" : "2014-11-12 11:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3093\u3058\u3047",
      "screen_name" : "f_tangent",
      "indices" : [ 0, 10 ],
      "id_str" : "199687003",
      "id" : 199687003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532488053500047360",
  "geo" : { },
  "id_str" : "532488174925144064",
  "in_reply_to_user_id" : 199687003,
  "text" : "@f_tangent \u8B1D\u308B\u306A\uFF0E\u81EA\u52D5\u8ECA\u4E8B\u6545\u3068\u304B\u3060\u3068\u4E0B\u624B\u306B\u8B1D\u308B\u3068\u8CAC\u4EFB\u53D6\u3089\u306A\u3044\u3068\u3044\u3051\u306A\u304F\u306A\u308B\u305E\uFF0E",
  "id" : 532488174925144064,
  "in_reply_to_status_id" : 532488053500047360,
  "created_at" : "2014-11-12 11:00:48 +0000",
  "in_reply_to_screen_name" : "f_tangent",
  "in_reply_to_user_id_str" : "199687003",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3093\u3058\u3047",
      "screen_name" : "f_tangent",
      "indices" : [ 0, 10 ],
      "id_str" : "199687003",
      "id" : 199687003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532487934264344576",
  "geo" : { },
  "id_str" : "532487986550542336",
  "in_reply_to_user_id" : 199687003,
  "text" : "@f_tangent \u308F\u304B\u308C\u3070\u3088\u308D\u3057\u3044",
  "id" : 532487986550542336,
  "in_reply_to_status_id" : 532487934264344576,
  "created_at" : "2014-11-12 11:00:03 +0000",
  "in_reply_to_screen_name" : "f_tangent",
  "in_reply_to_user_id_str" : "199687003",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532487538296905729",
  "text" : "\u300C\u306F\u3044\u300D\u3067\u5E83\u304C\u308B\u305F\u306E\u3057\u3044\u304B\u3044\u308F",
  "id" : 532487538296905729,
  "created_at" : "2014-11-12 10:58:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3093\u3058\u3047",
      "screen_name" : "f_tangent",
      "indices" : [ 0, 10 ],
      "id_str" : "199687003",
      "id" : 199687003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532487431572815874",
  "geo" : { },
  "id_str" : "532487475415879680",
  "in_reply_to_user_id" : 199687003,
  "text" : "@f_tangent \u306F\u3044",
  "id" : 532487475415879680,
  "in_reply_to_status_id" : 532487431572815874,
  "created_at" : "2014-11-12 10:58:01 +0000",
  "in_reply_to_screen_name" : "f_tangent",
  "in_reply_to_user_id_str" : "199687003",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532487164903190528",
  "text" : "\u304F\u305D\u308A\u3077\u304A\u3076\u3056\u3044\u3084\u30FC",
  "id" : 532487164903190528,
  "created_at" : "2014-11-12 10:56:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3093\u3058\u3047",
      "screen_name" : "f_tangent",
      "indices" : [ 0, 10 ],
      "id_str" : "199687003",
      "id" : 199687003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532486870022635521",
  "geo" : { },
  "id_str" : "532486917326004227",
  "in_reply_to_user_id" : 199687003,
  "text" : "@f_tangent \u30B5\u30A4\u30AF\u30ED\u30F3",
  "id" : 532486917326004227,
  "in_reply_to_status_id" : 532486870022635521,
  "created_at" : "2014-11-12 10:55:48 +0000",
  "in_reply_to_screen_name" : "f_tangent",
  "in_reply_to_user_id_str" : "199687003",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532486227635613696",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u306A\u3041...",
  "id" : 532486227635613696,
  "created_at" : "2014-11-12 10:53:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532483096352796672",
  "geo" : { },
  "id_str" : "532483160647290880",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30B5\u30E8\u30CA\u30E9\uFF01\uFF01\uFF01",
  "id" : 532483160647290880,
  "in_reply_to_status_id" : 532483096352796672,
  "created_at" : "2014-11-12 10:40:53 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532482913757974528",
  "geo" : { },
  "id_str" : "532483004099084290",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u5927\u62B5\u306E\u3082\u306E\u306F\u7206\u767A\u3059\u308B",
  "id" : 532483004099084290,
  "in_reply_to_status_id" : 532482913757974528,
  "created_at" : "2014-11-12 10:40:15 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532482823374905345",
  "text" : "\u3088\u304F\u8003\u3048\u305F\u3089\u30A2\u30EB\u30D5\u30A1\u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9\u3082\u7206\u767A\u3082\u6570\u5B66\u7528\u8A9E\u304B\u3088...",
  "id" : 532482823374905345,
  "created_at" : "2014-11-12 10:39:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532482473246982144",
  "geo" : { },
  "id_str" : "532482641698648064",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u8907\u4F53\u3058\u3083\u306A\u3044\u307B\u3046\u306E\u30A2\u30EB\u30D5\u30A1\u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9",
  "id" : 532482641698648064,
  "in_reply_to_status_id" : 532482473246982144,
  "created_at" : "2014-11-12 10:38:49 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532482250370080769",
  "text" : "\u5730\u8535\u3067\u5B8C\u5168\u7279\u5B9A\u611F\u306A...",
  "id" : 532482250370080769,
  "created_at" : "2014-11-12 10:37:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532482199073734656",
  "text" : "\u30C8\u306E\u5B57\u8DEF\u3067\u30D4\u30F3\u3068\u304F\u308B",
  "id" : 532482199073734656,
  "created_at" : "2014-11-12 10:37:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532481975588642816",
  "text" : "\u81EA\u8EE2\u8ECA\uFF0C\u30A2\u30EB\u30D5\u30A1\u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9\u4E26\u306B\u7206\u767A\u3057\u3084\u3059\u304F\u4F5C\u308C\u3070\u3044\u3044",
  "id" : 532481975588642816,
  "created_at" : "2014-11-12 10:36:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532481450965090304",
  "text" : "\u304F\u3089\u5BFF\u53F8\u30AA\u30D520\u3068\u304B\u306A\u3089\u884C\u304D\u305F\u304B\u3063\u305F\uFF08\u524D\u591C\u796D\uFF1F\uFF09",
  "id" : 532481450965090304,
  "created_at" : "2014-11-12 10:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532472430946549760",
  "geo" : { },
  "id_str" : "532472472184963072",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u308F\u304B\u308B...",
  "id" : 532472472184963072,
  "in_reply_to_status_id" : 532472430946549760,
  "created_at" : "2014-11-12 09:58:24 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532472357147779073",
  "text" : "\u6BD4\u8F03\u3068\u3044\u3046\u884C\u70BA\u3082\u706B\u306E\u524D\u306B\u306F\u7121\u529B\u306A\u306E\u3058\u3083",
  "id" : 532472357147779073,
  "created_at" : "2014-11-12 09:57:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532472270975807488",
  "text" : "\u706B\u3068\u4EBA\u9593\u3092\u5929\u79E4\u306B\u8F09\u305B\u308B\u3068\uFF0C\u5929\u79E4\u304C\u71C3\u3048\u308B",
  "id" : 532472270975807488,
  "created_at" : "2014-11-12 09:57:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532472092780797952",
  "geo" : { },
  "id_str" : "532472164847333376",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u7D76\u5BFE\u706B\u306E\u65B9\u304C\u5F37\u3044",
  "id" : 532472164847333376,
  "in_reply_to_status_id" : 532472092780797952,
  "created_at" : "2014-11-12 09:57:11 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532471907258359808",
  "text" : "\u8033\u304B\u3089\u51FA\u3066\u304F\u308B\u30BF\u30B3\uFF0C\u78BA\u5B9F\u306B\u305D\u306E\u4EBA\u9593\u306E\u4F53\u3092\u4E57\u3063\u53D6\u3063\u3066\u3044\u308B\u611F\u3058\u304C\u6016\u3044",
  "id" : 532471907258359808,
  "created_at" : "2014-11-12 09:56:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532471741130362880",
  "text" : "\u8033\u304B\u3089\u30BF\u30B3\u304C\u51FA\u3066\u304F\u308B\u307B\u3069\u805E\u3044\u305F\u53F0\u8A5E\u300C\u8A9E\u5B66\u306F\u65E9\u3081\u306B\u7247\u4ED8\u3051\u308D\u300D",
  "id" : 532471741130362880,
  "created_at" : "2014-11-12 09:55:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532471384035700736",
  "geo" : { },
  "id_str" : "532471589153959937",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi 3\u56DE\u751F\u524D\u671F\u307E\u3067\u6B8B\u3063\u3066\u305F\u50D5\u304C\u8A00\u3046\u306E\u3082\u30A2\u30EC\u3060\u3051\u3069\u8A9E\u5B66\u306F\u65E9\u304F\u606F\u306E\u6839\u3092\u6B62\u3081\u3066\u304A\u3044\u305F\u65B9\u304C...",
  "id" : 532471589153959937,
  "in_reply_to_status_id" : 532471384035700736,
  "created_at" : "2014-11-12 09:54:54 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532471383591100416",
  "text" : "\u30A8\u30EB\u30B7\u30E3\u30C0\u30A4\uFF0CPV\u3060\u3051\u3067\u76DB\u308A\u4E0A\u304C\u3063\u3066\uFF0C\u672C\u7DE8\u304C\u51FA\u305F\u3042\u3068\u3082PV\u3060\u3051\u304C\u751F\u304D\u6B8B\u3063\u305F\u611F\u3058\u304C\u3059\u308B",
  "id" : 532471383591100416,
  "created_at" : "2014-11-12 09:54:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532470991637590016",
  "text" : "Call\uFF0C\u50D5\u306E\u4E16\u4EE3\u3088\u308A\u5F8C\u308D\u304C\u53B3\u3057\u304F\u306A\u3063\u305F\u3068\u805E\u3044\u3066\u300C\uFF7E\uFF6A\uFF6A\uFF6A\uFF6A\uFF6A\uFF8C\uFF6F\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\u300D\u3063\u3066\u306A\u3063\u305F",
  "id" : 532470991637590016,
  "created_at" : "2014-11-12 09:52:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532470729149661184",
  "geo" : { },
  "id_str" : "532470846988623873",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u521D\u3081\u304B\u3089\u30AC\u30A4\u30C0\u30F3\u30B9\u306E\u8A00\u3046\u3053\u3068\u3092\u805E\u3044\u3066\u3044\u308C\u3070...\u306A",
  "id" : 532470846988623873,
  "in_reply_to_status_id" : 532470729149661184,
  "created_at" : "2014-11-12 09:51:57 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532469754678632448",
  "text" : "\u3069\u3046\u307F\u3066\u3082\u96E8\u3067\u3059\uFF0C\u672C\u5F53\u306B\u6709\u96E3\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF0E",
  "id" : 532469754678632448,
  "created_at" : "2014-11-12 09:47:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532336056893333504",
  "text" : "\u3053\u3063\u3061\u306F\u7279\u306B\u63FA\u308C\u3066\u306A\u3044\u306A",
  "id" : 532336056893333504,
  "created_at" : "2014-11-12 00:56:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532336023380832256",
  "text" : "\u3086\u308C\uFF1F",
  "id" : 532336023380832256,
  "created_at" : "2014-11-12 00:56:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532192108627513345",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u8857",
  "id" : 532192108627513345,
  "created_at" : "2014-11-11 15:24:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532191626764881920",
  "geo" : { },
  "id_str" : "532191690287624193",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa 45\u5104\u5E74\u306B\u306F\u9060\u304F\u53CA\u3070\u306C",
  "id" : 532191690287624193,
  "in_reply_to_status_id" : 532191626764881920,
  "created_at" : "2014-11-11 15:22:41 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532191424171630592",
  "text" : "\u9806\u8ABF\u306B\u50D5\u306E\u306A\u304B\u306E\"\"\"\u8001\u5BB3\"\"\"\u304C\u80B2\u3063\u3066\u3044\u308B\u306E\u3092\u611F\u3058\u3066\u8F9B\u3044",
  "id" : 532191424171630592,
  "created_at" : "2014-11-11 15:21:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532191170005172224",
  "geo" : { },
  "id_str" : "532191262841905152",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u51FA\u3066\u305F\u306D\u3001\u3042\u308C\u3082\u6614\u306E\u30C9\u30E9\u30DE\u3060\u306A\u2026",
  "id" : 532191262841905152,
  "in_reply_to_status_id" : 532191170005172224,
  "created_at" : "2014-11-11 15:20:59 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532190885283258369",
  "geo" : { },
  "id_str" : "532191044993941504",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa Dr.\u30B3\u30C8\u30FC\u8A3A\u7642\u6240",
  "id" : 532191044993941504,
  "in_reply_to_status_id" : 532190885283258369,
  "created_at" : "2014-11-11 15:20:07 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532190673538002944",
  "geo" : { },
  "id_str" : "532190714738638850",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u547D\u306E\u7802\u6F20\u3078",
  "id" : 532190714738638850,
  "in_reply_to_status_id" : 532190673538002944,
  "created_at" : "2014-11-11 15:18:48 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532190080937390080",
  "text" : "\u3082\u3046\u305A\u3044\u3076\u3093\u524D\u306A\u3093\u3060\u306A\u2026(\u9060\u3044\u76EE)",
  "id" : 532190080937390080,
  "created_at" : "2014-11-11 15:16:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532189999177818112",
  "text" : "\u6C11\u55B6\u5316\u3059\u308B\u30DD\u30B9\u30C8\u30AA\u30D5\u30A3\u30B9",
  "id" : 532189999177818112,
  "created_at" : "2014-11-11 15:15:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532189791400374272",
  "text" : "\u7269\u9A12\u3060",
  "id" : 532189791400374272,
  "created_at" : "2014-11-11 15:15:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532189722261471232",
  "text" : "\u592A\u6975\u62F3\u3067\u8001\u4EBA\u3092\u4E00\u4EBA\u846C\u308C\u3070\u5B9F\u969B\u3082\u3046\u305D\u306E\u8001\u4EBA\u306F\u8EE2\u5012\u3057\u306A\u3044\u3057\u3001\u8EE2\u5012\u3059\u308B\u30EA\u30B9\u30AF\u3092\u6E1B\u3089\u305B\u308B",
  "id" : 532189722261471232,
  "created_at" : "2014-11-11 15:14:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532189016343326721",
  "geo" : { },
  "id_str" : "532189438344826880",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u4FFA\u306F\u30CB\u30E3\u30FC\u30F3\u306E\u8A71\u3092\u3057\u3066\u3044\u308B\u3093\u3060",
  "id" : 532189438344826880,
  "in_reply_to_status_id" : 532189016343326721,
  "created_at" : "2014-11-11 15:13:44 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532188640617562112",
  "text" : "\u672C\u5F53\u306B\u826F\u3044\u30CB\u30E3\u30FC\u30F3\u3068\u305D\u3046\u3067\u306A\u3044\u30CB\u30E3\u30FC\u30F3\u3092\u898B\u5206\u3051\u308B\u7279\u6B8A\u306A\u8A13\u7DF4",
  "id" : 532188640617562112,
  "created_at" : "2014-11-11 15:10:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532187843901128705",
  "geo" : { },
  "id_str" : "532188345317605376",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30CB\u30E3\u30FC\u30F3\u6027\u306B\u7FF3\u308A\u3092\u611F\u3058\u307E\u3059\u3057\u3001\u4E0D\u5B8C\u5168\u306A\u30CB\u30E3\u30FC\u30F3\u3067\u3042\u308B\u3053\u3068\u304C\u4F3A\u3048\u307E\u3059\u3002\u3069\u3053\u3067\u53D6\u308C\u305F\u30CB\u30E3\u30FC\u30F3\u3067\u3059\u304B\uFF1F\u65B0\u9BAE\u306A\u7269\u3067\u3059\u304B\uFF1F",
  "id" : 532188345317605376,
  "in_reply_to_status_id" : 532187843901128705,
  "created_at" : "2014-11-11 15:09:23 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532187653936926721",
  "text" : "\u732B\u3068\u306E\u89E6\u308C\u5408\u3044\u304C\u6025\u52D9",
  "id" : 532187653936926721,
  "created_at" : "2014-11-11 15:06:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532187137714556930",
  "text" : "\u3064\u307E\u308B\u3068\u3053\u308D\u30DD\u30FC\u30AF\u30B9\u30C6\u30FC\u30AD\u3068\u304B\u98DF\u3079\u305F\u3044",
  "id" : 532187137714556930,
  "created_at" : "2014-11-11 15:04:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532186786676482048",
  "text" : "\u5546\u54C1\u3060\u304B\u3089\u6709\u511F\u3058\u3083\u3093\u306D",
  "id" : 532186786676482048,
  "created_at" : "2014-11-11 15:03:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532186729780768768",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 532186729780768768,
  "created_at" : "2014-11-11 15:02:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532186714052108288",
  "text" : "\u304A\u6E6F\u3092\u6CE8\u3044\u30673\u5206\u5F85\u3063\u305F\u5F8C\u306B\u304B\u304D\u6DF7\u305C\u308B\u3068\u7121\u511F\u306E\u611B\u304C\u51FA\u6765\u4E0A\u304C\u308B\u5546\u54C1\u3068\u304B\u4F5C\u3063\u305F\u3089\u826F\u3044\u306E\u306B\u3001\u306A\u3093\u3067\u306A\u3044\u3093\u3060",
  "id" : 532186714052108288,
  "created_at" : "2014-11-11 15:02:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532186107849367553",
  "text" : "\u771F\u9762\u76EE\u306B\u751F\u6D3B\u3057\u3066\u308B\u4EBA\u306F\u5272\u5F15\u3068\u304B\u306B\u3057\u3066\u307B\u3057\u3044",
  "id" : 532186107849367553,
  "created_at" : "2014-11-11 15:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532186010969333760",
  "text" : "\u771F\u9762\u76EE\u306B\u751F\u6D3B\u3057\u3066\u3066\u3082\u6020\u60F0\u306B\u751F\u6D3B\u3057\u3066\u3066\u3082\u304A\u8179\u6E1B\u308B\u3057\u7269\u3092\u8CB7\u3046\u3068\u304A\u91D1\u304C\u7121\u304F\u306A\u308B\u306E\u3001\u672C\u5F53\u306B\u7406\u4E0D\u5C3D\u306A\u30B7\u30B9\u30C6\u30E0\u3060",
  "id" : 532186010969333760,
  "created_at" : "2014-11-11 15:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532155987944157186",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 532155987944157186,
  "created_at" : "2014-11-11 13:00:49 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532154935748468736",
  "text" : "\u30ED\u30A4\u30BA\u306E\u30B7\u30E5\u30C8\u30FC\u30EC\u30F3\u98DF\u3079\u3066\u307F\u305F\u3044",
  "id" : 532154935748468736,
  "created_at" : "2014-11-11 12:56:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532154323933728768",
  "text" : "\u30C8\u30C3\u30DD",
  "id" : 532154323933728768,
  "created_at" : "2014-11-11 12:54:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532153987504414720",
  "text" : "\u306C\u30FC\u3093\u3063\u3066",
  "id" : 532153987504414720,
  "created_at" : "2014-11-11 12:52:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532153397198061568",
  "text" : "\u3084\u3055\u3044\u3089\u30FC\u306C\u3093\u3092\u305F\u3079\u305F",
  "id" : 532153397198061568,
  "created_at" : "2014-11-11 12:50:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532129977798361088",
  "text" : "\u60B2\u3057\u3044\u54C0\u3057\u3055\u304C\u3042\u3063\u3066\u304B\u306A\u3057\u3044",
  "id" : 532129977798361088,
  "created_at" : "2014-11-11 11:17:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532129756448174080",
  "text" : "\uFF8F\uFF80\u2026\uFF7C\uFF92\uFF7E\uFF85\uFF76\uFF6F\uFF80\u2026",
  "id" : 532129756448174080,
  "created_at" : "2014-11-11 11:16:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532099229544497152",
  "text" : "\u4E09\u6B21\u5143\u306E\u7D75\u304C\u4E0A\u624B\u306B\u66F8\u3051\u306A\u3044\u304B\u3089\u7C98\u571F\u3068\u304B\u6B32\u3057\u3044",
  "id" : 532099229544497152,
  "created_at" : "2014-11-11 09:15:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532040973547614209",
  "geo" : { },
  "id_str" : "532057436572487681",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u3075\u3089\u3063\u3068\u8CB7\u3046\u306B\u306F\u9AD8\u3044",
  "id" : 532057436572487681,
  "in_reply_to_status_id" : 532040973547614209,
  "created_at" : "2014-11-11 06:29:12 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531997732714471424",
  "text" : "\u3055\u3063\u304D\u306E\u767A\u8A00\u3092\u8AAD\u307E\u308C\u3066\u3044\u305F\u304B\u306E\u3088\u3046\u306B\u53CB\u4EBA\u304C\u30C8\u30C3\u30DD\u306E\u5927\u7BB1\u8CB7\u3063\u3066\u304D\u3066\u3066\u7B11\u3046",
  "id" : 531997732714471424,
  "created_at" : "2014-11-11 02:31:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531988504733970433",
  "text" : "\u9996\u3068\u304B\u80A9\uFF0C\u307B\u3093\u3068\u3046\u306B\u4E0D\u81EA\u7531\u306A\u30C7\u30D0\u30A4\u30B9\u3060\u3068\u601D\u3046",
  "id" : 531988504733970433,
  "created_at" : "2014-11-11 01:55:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531988092303859712",
  "text" : "\u30C8\u30C3\u30DD\u306F\u7D50\u69CB\u3059\u304D\u3059\u304D",
  "id" : 531988092303859712,
  "created_at" : "2014-11-11 01:53:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531988047143768064",
  "text" : "\u30DD\u30C3\u30AD\u30FC\u3068\u3044\u3046\u304A\u83D3\u5B50\uFF0C\u5225\u306B\u5ACC\u3044\u306B\u306A\u308B\u307B\u3069\u306E\u5370\u8C61\u3082\u306A\u3044\u304C\uFF0C\u304B\u3068\u8A00\u3063\u3066\u308F\u3056\u308F\u3056\u8CB7\u3063\u3066\u98DF\u3079\u308B\u307B\u3069\u597D\u304D\u3067\u3082\u306A\u3044",
  "id" : 531988047143768064,
  "created_at" : "2014-11-11 01:53:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531987368949977088",
  "text" : "\u4EBA\u9593\uFF0C\u3053\u3068\u3054\u3068\u304F\u5F37\u6B32\u3067\u3042\u308B",
  "id" : 531987368949977088,
  "created_at" : "2014-11-11 01:50:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531961510075965440",
  "text" : "\u307E\u3063",
  "id" : 531961510075965440,
  "created_at" : "2014-11-11 00:08:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8003\u3048\u308B\u30AB\u30EF\u30BA\u304F\u3093",
      "screen_name" : "MrBoilingFrog",
      "indices" : [ 0, 14 ],
      "id_str" : "599102449",
      "id" : 599102449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531843307551219712",
  "geo" : { },
  "id_str" : "531843759298707456",
  "in_reply_to_user_id" : 599102449,
  "text" : "@MrBoilingFrog \u30DE\u30B8\u30EC\u30B9\u3057\u3066\u6765\u305F\u3084\u3064\u304C\u3044\u305F\u3089\u300C\u78BA\u304B\u306B\u7C73\u304B\u3089\u304A\u304B\u3086\u306F\u4F5C\u3089\u308C\u308B\u3051\u3069\u3001\u7C73\u3068\u304A\u304B\u3086\u306F\u9055\u3046\u7269\u3060\u308D\u300D\u307F\u305F\u3044\u306A\u610F\u5473\u4E0D\u660E\u306A\u3053\u3068\u8A00\u3046\u3068\u30E6\u30FC\u30E2\u30A2\u306E\u30BB\u30F3\u30B9\u304C\u306A\u3044\u53CB\u4EBA\u3092\u3075\u308B\u3044\u306B\u304B\u3051\u3089\u308C\u3066\u4E00\u77F3\u4E8C\u9CE5",
  "id" : 531843759298707456,
  "in_reply_to_status_id" : 531843307551219712,
  "created_at" : "2014-11-10 16:20:08 +0000",
  "in_reply_to_screen_name" : "MrBoilingFrog",
  "in_reply_to_user_id_str" : "599102449",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8003\u3048\u308B\u30AB\u30EF\u30BA\u304F\u3093",
      "screen_name" : "MrBoilingFrog",
      "indices" : [ 0, 14 ],
      "id_str" : "599102449",
      "id" : 599102449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531842638341627905",
  "geo" : { },
  "id_str" : "531842966541709312",
  "in_reply_to_user_id" : 599102449,
  "text" : "@MrBoilingFrog \u3053\u306E\u90E8\u5C4B\u306B\u3001\u7C73\u6CE5\u68D2\u304C\u3044\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3001\u3068\u304B\u81F3\u3063\u3066\u771F\u9762\u76EE\u306B\u76F8\u8AC7\u8ABF\u3067\u66F8\u3044\u305F\u3089\u826F\u3044",
  "id" : 531842966541709312,
  "in_reply_to_status_id" : 531842638341627905,
  "created_at" : "2014-11-10 16:16:59 +0000",
  "in_reply_to_screen_name" : "MrBoilingFrog",
  "in_reply_to_user_id_str" : "599102449",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/RMtQN5kvIm",
      "expanded_url" : "http:\/\/www.geocities.jp\/tomoatomi\/raira0001.htm",
      "display_url" : "geocities.jp\/tomoatomi\/rair\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531842409986936833",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u7A7A http:\/\/t.co\/RMtQN5kvIm",
  "id" : 531842409986936833,
  "created_at" : "2014-11-10 16:14:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531842370631766016",
  "text" : "\u50D5\u3082\u5BDD\u307E\u3059\u304B\u306D",
  "id" : 531842370631766016,
  "created_at" : "2014-11-10 16:14:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8003\u3048\u308B\u30AB\u30EF\u30BA\u304F\u3093",
      "screen_name" : "MrBoilingFrog",
      "indices" : [ 0, 14 ],
      "id_str" : "599102449",
      "id" : 599102449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531842087939866625",
  "geo" : { },
  "id_str" : "531842235847815168",
  "in_reply_to_user_id" : 599102449,
  "text" : "@MrBoilingFrog \u305D\u3053\u306B\u7A7A\u6C17\u306B\u3042\u308F\u306A\u3044\u9762\u767D\u3044\u6295\u7A3F\u3092\u6295\u3052\u8FBC\u3080\u3053\u3068\u3067\u6587\u5B57\u901A\u308A\u4E00\u77F3\u3092\u6295\u3058\u308B\u306E\u3060",
  "id" : 531842235847815168,
  "in_reply_to_status_id" : 531842087939866625,
  "created_at" : "2014-11-10 16:14:04 +0000",
  "in_reply_to_screen_name" : "MrBoilingFrog",
  "in_reply_to_user_id_str" : "599102449",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531841375960956929",
  "text" : "\u50D5\u3082\u8A00\u308F\u308C\u305F\u306A\u3041\u3063\u3066\u601D\u3044\u306A\u304C\u3089\u3064\u3044\u547C\u5438\u3057\u3061\u3083\u3046\u3068\u601D\u3046",
  "id" : 531841375960956929,
  "created_at" : "2014-11-10 16:10:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531841156208803840",
  "geo" : { },
  "id_str" : "531841255085330432",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u307E\u30FC\u306D\u30FC",
  "id" : 531841255085330432,
  "in_reply_to_status_id" : 531841156208803840,
  "created_at" : "2014-11-10 16:10:11 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531841216128643072",
  "text" : "\u307F\u3093\u306A\u697D\u3057\u3044\u4F1A\u8A717\u6BB5",
  "id" : 531841216128643072,
  "created_at" : "2014-11-10 16:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 3, 12 ],
      "id_str" : "205621330",
      "id" : 205621330
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531841156577898496",
  "text" : "RT @sio_puyo: @end313124 \u3068\u308A\u3042\u3048\u305A\u547C\u5438\u3068\u304B\u3057\u307E\u3059",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "531840843531841537",
    "geo" : { },
    "id_str" : "531841124424359938",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u3068\u308A\u3042\u3048\u305A\u547C\u5438\u3068\u304B\u3057\u307E\u3059",
    "id" : 531841124424359938,
    "in_reply_to_status_id" : 531840843531841537,
    "created_at" : "2014-11-10 16:09:39 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "protected" : false,
      "id_str" : "205621330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592977078686846976\/5l9QrsY1_normal.png",
      "id" : 205621330,
      "verified" : false
    }
  },
  "id" : 531841156577898496,
  "created_at" : "2014-11-10 16:09:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 19, 29 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531841144347308033",
  "text" : "RT @koizumi_fifty: @end313124 \u8A00\u308F\u308C\u305F\u306A\u3041\uFF5E\u3001\u3063\u3066\u601D\u3044\u307E\u3059",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "531840843531841537",
    "geo" : { },
    "id_str" : "531841099300483074",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u8A00\u308F\u308C\u305F\u306A\u3041\uFF5E\u3001\u3063\u3066\u601D\u3044\u307E\u3059",
    "id" : 531841099300483074,
    "in_reply_to_status_id" : 531840843531841537,
    "created_at" : "2014-11-10 16:09:33 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 531841144347308033,
  "created_at" : "2014-11-10 16:09:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531840843531841537",
  "text" : "\u30C1\u30E7\u30B3\u30D1\u30A4\u3068\u304A\u558B\u308A\u3067\u304D\u308B\u4EBA\u990A\u6210\u6559\u5BA4\uFF0C\u50D5\u304C\u76EE\u306B\u3057\u305F\u3053\u3068\u306A\u3044\u3060\u3051\u3067\u65E5\u672C\u5404\u5730\u306B\u904D\u5728\u3059\u308B\u3063\u3066\u8A00\u3063\u305F\u3089\uFF0C\u3069\u3046\u3057\u307E\u3059\uFF1F",
  "id" : 531840843531841537,
  "created_at" : "2014-11-10 16:08:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531840319302537216",
  "geo" : { },
  "id_str" : "531840584395137024",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30C1\u30E7\u30B3\u30D1\u30A4\u3063\u3066\u4E00\u6642\u671F\u5317\u671D\u9BAE\u3067\u901A\u8CA8\u307F\u305F\u3044\u306B\u306A\u3063\u3066\u307E\u3057\u305F\u3088\u306D\u305D\u3046\u3044\u3048\u3070",
  "id" : 531840584395137024,
  "in_reply_to_status_id" : 531840319302537216,
  "created_at" : "2014-11-10 16:07:31 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531840159998701568",
  "text" : "20\u5E74\u4EE5\u4E0A\u751F\u304D\u3066\u304D\u305F\u3051\u3069\u201D\u30C1\u30E7\u30B3\u30D1\u30A4\u3068\u304A\u558B\u308A\u3067\u304D\u308B\u4EBA\u990A\u6210\u6559\u5BA4\u201D\u306A\u3093\u3066\u6587\u5B57\u5217\u306F\u521D\u3081\u3066\u76EE\u306B\u3057\u305F",
  "id" : 531840159998701568,
  "created_at" : "2014-11-10 16:05:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531839812148285440",
  "geo" : { },
  "id_str" : "531839990896943104",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30C1\u30E7\u30B3\u30D1\u30A4\u3068\u558B\u308C\u308B\u306A\u3089\u30C1\u30E7\u30B3\u30D1\u30A4\u3068\u304A\u558B\u308A\u3067\u304D\u308B\u4EBA\u990A\u6210\u6559\u5BA4\u306E\u5148\u751F\u306B\u306A\u308B\u3068\u826F\u3044\u3067\u3059\u3088\uFF0E\u7A00\u6709\u306A\u4EBA\u6750\u3067\u3059\u304B\u3089\uFF0E",
  "id" : 531839990896943104,
  "in_reply_to_status_id" : 531839812148285440,
  "created_at" : "2014-11-10 16:05:09 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531839388800401408",
  "geo" : { },
  "id_str" : "531839607214571520",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u9577\u304F\u697D\u3057\u3081\u305D\u3046\u306A\u30B3\u30F3\u30C6\u30F3\u30C4\u3060...TRPG\u3082\u65E5\u306B\u65E5\u306B\u3084\u308A\u305F\u307F\u304C\u9AD8\u307E\u308B\u3070\u304B\u308A\u3060\uFF0E",
  "id" : 531839607214571520,
  "in_reply_to_status_id" : 531839388800401408,
  "created_at" : "2014-11-10 16:03:38 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531839323893559297",
  "geo" : { },
  "id_str" : "531839379912667136",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30C1\u30E7\u30B3\u30D1\u30A4\u306E\u6C17\u6301\u3061\u3082\u8003\u3048\u306A\u3044\u3067\u7D50\u5A5A\u306A\u3093\u3066\u51FA\u6765\u306A\u3044",
  "id" : 531839379912667136,
  "in_reply_to_status_id" : 531839323893559297,
  "created_at" : "2014-11-10 16:02:43 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531838673621647360",
  "geo" : { },
  "id_str" : "531839013540200448",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u305D\u3093\u306A\u306B\u597D\u304D\u306A\u3089\u7D50\u5A5A\u3057\u3066\u3057\u307E\u3048\uFF08\uFF1F\uFF09",
  "id" : 531839013540200448,
  "in_reply_to_status_id" : 531838673621647360,
  "created_at" : "2014-11-10 16:01:16 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531838730240151553",
  "geo" : { },
  "id_str" : "531838828839833601",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u6B63\u89E3\uFF01\uFF08\u305B\u3044\u304B\u3044\u306E\u304A\u3068\uFF09",
  "id" : 531838828839833601,
  "in_reply_to_status_id" : 531838730240151553,
  "created_at" : "2014-11-10 16:00:32 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531838610857664512",
  "text" : "\u9006\u3063\u3066\u305D\u3063\u3061\u3058\u3083\u306A\u3044\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 531838610857664512,
  "created_at" : "2014-11-10 15:59:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531838552129036288",
  "text" : "\u30DF\u30FC\u30C8\u30D1\u30A4\u307F\u305F\u3044\u306A\u306E\u306B\u304B\u3058\u3089\u308C\u305F\u3068\u601D\u3063\u305F\u3089\u30C1\u30E7\u30B3\u30D1\u30A4\u306B\u304B\u3058\u3089\u308C\u3066\u305F\u6642\u306E\u6C17\u6301\u3061",
  "id" : 531838552129036288,
  "created_at" : "2014-11-10 15:59:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531838473141878784",
  "text" : "\u9006\u3082\u3057\u3093\u3069\u3044",
  "id" : 531838473141878784,
  "created_at" : "2014-11-10 15:59:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531838448043167747",
  "text" : "\u30DF\u30FC\u30C8\u30D1\u30A4\u3060\u3068\u601D\u3063\u3066\u9F67\u3063\u305F\u3089\u30C1\u30E7\u30B3\u30D1\u30A4\u3060\u3063\u305F\u6642\u306E\u6C17\u6301\u3061",
  "id" : 531838448043167747,
  "created_at" : "2014-11-10 15:59:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531838123437613056",
  "geo" : { },
  "id_str" : "531838353595854848",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3064\u307E\u308A\u6F5C\u6C34\u8266\u3092\u671F\u5F85\u3057\u3066\u88F8\u306E\u5973\u306E\u5B50\u3092\u898B\u308B\u306E\u3068\uFF0C\u88F8\u306E\u5973\u306E\u5B50\u3092\u307F\u3066\u6F5C\u6C34\u8266\u3092\u898B\u308B\u306E\u3067\u306F\u3069\u3061\u3089\u304C\u826F\u3044\u304B\u307F\u305F\u3044\u306A\u8A71\u3067\u3059\uFF08\uFF1F\uFF09",
  "id" : 531838353595854848,
  "in_reply_to_status_id" : 531838123437613056,
  "created_at" : "2014-11-10 15:58:39 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531837637984677888",
  "geo" : { },
  "id_str" : "531837736068460545",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u9006\u3088\u308A\u3044\u3044\u306E\u3067\u306F",
  "id" : 531837736068460545,
  "in_reply_to_status_id" : 531837637984677888,
  "created_at" : "2014-11-10 15:56:12 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/531837343762620417\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/73Nx9VPFAH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2F3PwJCEAIjsoB.png",
      "id_str" : "531837343510958082",
      "id" : 531837343510958082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2F3PwJCEAIjsoB.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/73Nx9VPFAH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531837343762620417",
  "text" : "\u305F\u306E\u3057\u3044\u304B\u3044\u308F http:\/\/t.co\/73Nx9VPFAH",
  "id" : 531837343762620417,
  "created_at" : "2014-11-10 15:54:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531836346164203520",
  "text" : "\u3068\u306F\u8A00\u3048\u50D5\u304C\u5F8C\u3092\u5F15\u304B\u306A\u3044\u3088\u3046\u306A\u3082\u306E\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u3060\u3051\u306E\u53EF\u80FD\u6027\u3082\u3042\u308B\u306E\u3067\u6162\u5FC3\u3057\u306A\u3044\u307B\u3046\u304C\u826F\u3044\u3063\u307D\u3044",
  "id" : 531836346164203520,
  "created_at" : "2014-11-10 15:50:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531836052323840000",
  "text" : "\u201D\u3042\u3093\u307E\u308A\u4EBA\u201D",
  "id" : 531836052323840000,
  "created_at" : "2014-11-10 15:49:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531835593714450432",
  "geo" : { },
  "id_str" : "531835711373070336",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u5FC5\u8981\u6761\u4EF6\u3067\u3059\u304B\u306D",
  "id" : 531835711373070336,
  "in_reply_to_status_id" : 531835593714450432,
  "created_at" : "2014-11-10 15:48:09 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531835380866097152",
  "geo" : { },
  "id_str" : "531835508641382400",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u5C11\u306A\u304F\u3068\u3082\u5F8C\u3092\u5F15\u304F\u3088\u3046\u306A\u3082\u306E\u3067\u306F\u306A\u3044\u3068\u81EA\u8CA0\u3057\u3066\u3044\u307E\u3059",
  "id" : 531835508641382400,
  "in_reply_to_status_id" : 531835380866097152,
  "created_at" : "2014-11-10 15:47:20 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531835423715123200",
  "text" : "\u4E94\u5104\u4EBA\u8A2D\u5B9A\u3067\u5272\u3068\u5341\u5206\u3060\u3057\u4E94\u5104\u4E00\u4EBA\u3068\u304B\u30E9\u30B9\u30C8\u30AA\u30FC\u30C0\u30FC\u304B\u3088",
  "id" : 531835423715123200,
  "created_at" : "2014-11-10 15:47:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531835200611704834",
  "text" : "\u3042\u3042\u307E\u305F\u8B02\u308F\u308C\u306E\u306A\u3044\u8A2D\u5B9A\u304C\u8FFD\u52A0\u3055\u308C\u3066\u3044\u304F\u4E88\u611F\u304C",
  "id" : 531835200611704834,
  "created_at" : "2014-11-10 15:46:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531834756220993536",
  "text" : "\u5B50\u4F9B\u3092\u76F4\u306B\u717D\u3089\u306A\u304F\u3066\u3082\u50D5\u304C\u8AB0\u304B\u3092\u717D\u308B\u69D8\u5B50\u3092\u5B50\u4F9B\u306F\u304D\u3063\u3068\u898B\u3066\u308B\u3057\u4E0A\u624B\u306A\u717D\u308A\u3092\u8EAB\u306B\u3064\u3051\u3066\u6B32\u3057\u3044\u3068\u601D\u3046",
  "id" : 531834756220993536,
  "created_at" : "2014-11-10 15:44:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531834273817300994",
  "text" : "\u30DE\u30B8\u3067\u81EA\u5206\u306E\u5B50\u4F9B\u3053\u3093\u306A\u611F\u3058\u306B\u306A\u308A\u305D\u3046\u3067\u697D\u3057\u307F\uFF08\uFF1F\uFF09",
  "id" : 531834273817300994,
  "created_at" : "2014-11-10 15:42:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531833943360675841",
  "geo" : { },
  "id_str" : "531834088659750913",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u5927\u4EBA\u300C\u3046\u3061\u306F\u3046\u3061\uFF01\u3088\u305D\u306F\u3088\u305D\uFF01\u300D\n\u5B50\u4F9B\u300C\u81EA\u660E\u3067\u306F\uFF1F\u300D",
  "id" : 531834088659750913,
  "in_reply_to_status_id" : 531833943360675841,
  "created_at" : "2014-11-10 15:41:42 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531833824108224512",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u306E\u80CC\u4E2D\uFF0C\u80B2\u5150\u306B\u306F\u78BA\u5B9F\u306B\u60AA\u5F71\u97FF\u3060\u304B\u3089\u306D\uFF0E\u5B50\u4F9B\u304C\u300C\u81EA\u660E\u3067\u306F\uFF1F\u300D\u3068\u304B\u8A00\u3044\u51FA\u3059\u3088",
  "id" : 531833824108224512,
  "created_at" : "2014-11-10 15:40:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531833371811266561",
  "text" : "\u9762\u63A5\u306B\u307E\u3067\u3044\u3051\u306A\u3044\u3068\u30B2\u30FC\u30E0\u304C\u59CB\u307E\u3089\u306A\u3044",
  "id" : 531833371811266561,
  "created_at" : "2014-11-10 15:38:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531833304379428864",
  "text" : "\u5C31\u8077\u6D3B\u52D5\uFF0C\u9762\u63A5\u5B98\u3068\u9762\u767D\u3044\u3084\u308A\u3068\u308A\u3092\u3059\u308B\u30B2\u30FC\u30E0\u3060\u3068\u601D\u3063\u3066\u308B\u7BC0\u304C\u3042\u308B\u304B\u3089\u3053\u306E\u307E\u307E\u3060\u3068\u30E4\u30D0\u30A4",
  "id" : 531833304379428864,
  "created_at" : "2014-11-10 15:38:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531832997926821888",
  "text" : "\u305D\u3082\u305D\u3082\u30C6\u30EC\u30D3\u7121\u3044\u304B\u3089\u3081\u3063\u305F\u306B\u304A\u3057\u3083\u3079\u308A\u3057\u306A\u3044\u3051\u3069",
  "id" : 531832997926821888,
  "created_at" : "2014-11-10 15:37:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531832957472755714",
  "text" : "\u30C6\u30EC\u30D3\u3068\u304A\u3057\u3083\u3079\u308A\u3059\u308B\u6642\u306F\u5927\u62B5\u300C\u81EA\u660E\u3067\u306F\uFF1F\u300D\u3068\u300C\u5F37\u3044\u4E3B\u5F35\u3060\u300D\u3067\u4E8B\u8DB3\u308A\u308B",
  "id" : 531832957472755714,
  "created_at" : "2014-11-10 15:37:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531832686927568896",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 531832686927568896,
  "created_at" : "2014-11-10 15:36:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531832677695897600",
  "text" : "\u307F\u305F\u3044\u306A\u306E\u3084\u308A\u305F\u3044",
  "id" : 531832677695897600,
  "created_at" : "2014-11-10 15:36:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531832636314877952",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u300C\u50D5\u306F\u4ED6\u4EBA\u306B\u5F71\u97FF\u3092\u4E0E\u3048\u3089\u308C\u308B\u306B\u3093\u3052\u3093\u3067\u3059\uFF01\uFF01\uFF01\u300D\n\u9762\u63A5\u5B98\u300C\u5177\u4F53\u7684\u306B\u306F\uFF1F\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u50D5\u306E\u5468\u308A\u306E\u4EBA\u304C\u307F\u3093\u306A\u201D\u81EA\u660E\u3067\u306F\uFF1F\u201D\u304B\u201D\u5F37\u3044\u4E3B\u5F35\u3060\u201D\u304B\u305D\u308C\u4EE5\u5916\u306E\u8A00\u8449\u3092\u767A\u3059\u308B\u3088\u3046\u306B\u306A\u308A\u307E\u3057\u305F\u300D\n\u9762\u63A5\u5B98\u300C\u81EA\u660E\u3067\u306F\uFF1F\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u307B\u3089\u306D\u300D",
  "id" : 531832636314877952,
  "created_at" : "2014-11-10 15:35:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531831891993690112",
  "text" : "\u306B\uFF0E\uFF0E\uFF0E\u4EBA\u9593\u8AB0\u3057\u3082\u304A\u4E92\u3044\u5F71\u97FF\u3057\u3042\u3063\u3066\u751F\u304D\u3066\u308B\u304B\u3089...\uFF08\u9707\u3048\u58F0\uFF09",
  "id" : 531831891993690112,
  "created_at" : "2014-11-10 15:32:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531831601324249088",
  "text" : "\uFF08\u826F\u3044\u5F71\u97FF\u3060\u306A\u3093\u3066\u8AB0\u304C\u8A00\u3063\u305F\uFF09",
  "id" : 531831601324249088,
  "created_at" : "2014-11-10 15:31:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531831516683182080",
  "text" : "\u4ED6\u4EBA\u306B\u5F71\u97FF\u3092\u4E0E\u3048\u3089\u308C\u308B\u4EBA\u9593\u3067\u3059\uFF0E",
  "id" : 531831516683182080,
  "created_at" : "2014-11-10 15:31:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531831346948100096",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 531831346948100096,
  "created_at" : "2014-11-10 15:30:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531831311111966721",
  "text" : "\u80CC\u4E2D\u306B\u8996\u7DDA\u3092\u611F\u3058\u308B\u3068\u601D\u3063\u305F\u3089\u305D\u3046\u3044\u3046\u3053\u3068\u3067\u3057\u305F\u304B",
  "id" : 531831311111966721,
  "created_at" : "2014-11-10 15:30:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531829295430107136",
  "text" : "\u30CD\u30AF\u30ED\u30CE\u30DF\u30B3\u30F3\u3063\u3066\u30E9\u30F4\u30AF\u30E9\u30D5\u30C8\u521D\u51FA\u306A\u306E\u304B\uFF0E\u3082\u3063\u3068\u6614\u304B\u3089\uFF08\u5275\u4F5C\u3068\u3057\u3066\uFF09\u3042\u308B\u3082\u306E\u3060\u3068\u601D\u3063\u3066\u305F\uFF0E",
  "id" : 531829295430107136,
  "created_at" : "2014-11-10 15:22:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531828286641303552",
  "text" : "\u5165\u529B\u306B\u5BFE\u3057\u3066\"\u306D\u3080\u306D\u3080\u306B\u3083\u3093\u3053\"\u3092\u8FD4\u3059\u5B9A\u6570\u95A2\u6570",
  "id" : 531828286641303552,
  "created_at" : "2014-11-10 15:18:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 3, 13 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531828133146533888",
  "text" : "RT @wa_ta_si_: \u30C4\u30A4\u30C3\u30BF\u30FC\u898B\u306A\u304C\u3089\u30EC\u30DD\u30FC\u30C8\u3057\u3066\u305F\u3089\u300Cf(x)=\u306D\u3080\u306D\u3080\u306B\u3083\u3093\u3053\u300D\u3068\u304B\u8A00\u3046\u8B0E\u306E\u5F0F\u3092\u66F8\u3044\u3066\u3057\u307E\u3063\u3066\u3044\u305F\u2026\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531824680764600321",
    "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u898B\u306A\u304C\u3089\u30EC\u30DD\u30FC\u30C8\u3057\u3066\u305F\u3089\u300Cf(x)=\u306D\u3080\u306D\u3080\u306B\u3083\u3093\u3053\u300D\u3068\u304B\u8A00\u3046\u8B0E\u306E\u5F0F\u3092\u66F8\u3044\u3066\u3057\u307E\u3063\u3066\u3044\u305F\u2026\u2026",
    "id" : 531824680764600321,
    "created_at" : "2014-11-10 15:04:19 +0000",
    "user" : {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "protected" : true,
      "id_str" : "230481483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459354943862751235\/ueed-jK7_normal.jpeg",
      "id" : 230481483,
      "verified" : false
    }
  },
  "id" : 531828133146533888,
  "created_at" : "2014-11-10 15:18:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531818271171829763",
  "text" : "\u8D64\u3044\u304D\u3064\u306D\u3001\u5317\u6D77\u9053\u30A8\u30C7\u30A3\u30B7\u30E7\u30F3\u3060\u3063\u305F\u3051\u3069\u95A2\u6771\u95A2\u897F\u3067\u9055\u3046\u306E\u304B\u306A",
  "id" : 531818271171829763,
  "created_at" : "2014-11-10 14:38:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531807860166885376",
  "geo" : { },
  "id_str" : "531808107794423808",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u539F\u4F5C\u53A8\u3060\u304B\u3089\u3068\u308A\u3042\u3048\u305A\u30E9\u30F4\u30AF\u30E9\u30D5\u30C8\u5168\u96C6\u3092\u7AEF\u304B\u3089\u8AAD\u3093\u3067\u308B\u3093\u3060\u304C\u3001\u305D\u308C\u304C\u7D42\u308F\u3063\u3066\u76EE\u306B\u7559\u307E\u3063\u305F\u3089\u898B\u3066\u307F\u3088\u3046",
  "id" : 531808107794423808,
  "in_reply_to_status_id" : 531807860166885376,
  "created_at" : "2014-11-10 13:58:28 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531807319634374656",
  "geo" : { },
  "id_str" : "531807421237178368",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u305D\u308C\u306F\u30AF\u30C8\u30A5\u30EB\u30D5\u795E\u8A71\u4F5C\u54C1\u306A\u306E\u304B\u2026",
  "id" : 531807421237178368,
  "in_reply_to_status_id" : 531807319634374656,
  "created_at" : "2014-11-10 13:55:44 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531806646222086144",
  "text" : "\u30AF\u30C8\u30A5\u30EB\u30D5\u795E\u8A71\u4F5C\u54C1\u3063\u3066\u3069\u3053\u307E\u3067\u304C\u542B\u307E\u308C\u308B\u3093\u3060\u2026",
  "id" : 531806646222086144,
  "created_at" : "2014-11-10 13:52:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 0, 9 ],
      "id_str" : "134141604",
      "id" : 134141604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531799465733001216",
  "geo" : { },
  "id_str" : "531800195428659200",
  "in_reply_to_user_id" : 134141604,
  "text" : "@nf_spitz \u3046\u3080\u3001\u7533\u3057\u8FBC\u3093\u3060",
  "id" : 531800195428659200,
  "in_reply_to_status_id" : 531799465733001216,
  "created_at" : "2014-11-10 13:27:01 +0000",
  "in_reply_to_screen_name" : "nf_spitz",
  "in_reply_to_user_id_str" : "134141604",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 0, 9 ],
      "id_str" : "134141604",
      "id" : 134141604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531799196517425152",
  "geo" : { },
  "id_str" : "531799389346357248",
  "in_reply_to_user_id" : 134141604,
  "text" : "@nf_spitz \u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01\u3042\u308A\u304C\u3068",
  "id" : 531799389346357248,
  "in_reply_to_status_id" : 531799196517425152,
  "created_at" : "2014-11-10 13:23:49 +0000",
  "in_reply_to_screen_name" : "nf_spitz",
  "in_reply_to_user_id_str" : "134141604",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 0, 9 ],
      "id_str" : "134141604",
      "id" : 134141604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531798521087664129",
  "geo" : { },
  "id_str" : "531798803485949952",
  "in_reply_to_user_id" : 134141604,
  "text" : "@nf_spitz \u8A73\u3057\u304F",
  "id" : 531798803485949952,
  "in_reply_to_status_id" : 531798521087664129,
  "created_at" : "2014-11-10 13:21:29 +0000",
  "in_reply_to_screen_name" : "nf_spitz",
  "in_reply_to_user_id_str" : "134141604",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531795059906076673",
  "text" : "\u304A\u305F\u3063\u3057\u3083\u3067\u30FC\uFF08\u5E30\u308B\uFF09",
  "id" : 531795059906076673,
  "created_at" : "2014-11-10 13:06:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531794669819019264",
  "text" : "\u30D6\u30E9\u30B8\u30EB\u306E\u9078\u624B\u306B\u9078\u3070\u308C\u305F\u3093\u3067\u3059\u304B\uFF1F\u3063\u3066\u805E\u304D\u305F\u3044",
  "id" : 531794669819019264,
  "created_at" : "2014-11-10 13:05:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531794411273728000",
  "text" : "\u53E9\u3044\u3066\u304B\u3076\u3063\u3066\u4E8C\u56DE\u624B\u3092\u53E9\u3044\u3066\uFF08ry \u3082\u3084\u3063\u3066\u307B\u3057\u3044",
  "id" : 531794411273728000,
  "created_at" : "2014-11-10 13:04:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531794133728235520",
  "geo" : { },
  "id_str" : "531794292818186240",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3042\u308C\u306F\u5468\u77E5\u3060\u3051\u3059\u308C\u3070\u307B\u3068\u3093\u3069\u6E96\u5099\u3044\u3089\u306A\u3044\u306E\u3067\u306F",
  "id" : 531794292818186240,
  "in_reply_to_status_id" : 531794133728235520,
  "created_at" : "2014-11-10 13:03:34 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531793827124629506",
  "geo" : { },
  "id_str" : "531793914101899269",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u4E8C\u56DE\uFF08ry \u3068\u304B\u3084\u3089\u306A\u3044\u306E\uFF1F",
  "id" : 531793914101899269,
  "in_reply_to_status_id" : 531793827124629506,
  "created_at" : "2014-11-10 13:02:04 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531793702293737472",
  "geo" : { },
  "id_str" : "531793759919304704",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u4ECA\u5E74\u306F\u4F55\u3084\u308B\u306E",
  "id" : 531793759919304704,
  "in_reply_to_status_id" : 531793702293737472,
  "created_at" : "2014-11-10 13:01:27 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531793063580938242",
  "text" : "\u6211\u306A\u304C\u3089\u3072\u3069\u3044",
  "id" : 531793063580938242,
  "created_at" : "2014-11-10 12:58:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531793032845074433",
  "text" : "Q.\u3069\u3046\u307F\u3066\u3082\u7CBE\u795E\u5206\u88C2\u75C5\u306E\u4EBA\u9593\u304C\u4F1A\u8A71\u3092\u4ED5\u639B\u3051\u3066\u304D\u305F\u6642\u306E\u5BFE\u51E6\u6CD5\u306B\u3064\u3044\u3066\n\nA.\u3053\u3061\u3089\u3082\u7CBE\u795E\u3092\u5206\u88C2\u3055\u305B\u30661\u5BFE1\u3067\u5404\u500B\u6483\u7834\u3059\u308B",
  "id" : 531793032845074433,
  "created_at" : "2014-11-10 12:58:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531792884849049601",
  "text" : "\u4F55\u3082\u8003\u3048\u3066\u306A\u3044\u306E\u306B\u304B\u304C\u304F\u307E\u3055\u3093\u3092\u609F\u3089\u305B\u305F\uFF08\u3048\u3063\u3078\u3093\uFF09",
  "id" : 531792884849049601,
  "created_at" : "2014-11-10 12:57:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531792670859878400",
  "geo" : { },
  "id_str" : "531792724005888002",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3059\u307F\u307E\u305B\u3093\uFF0C\u601D\u3044\u3064\u3044\u3061\u3083\u3063\u305F\u306E\u3067\u3064\u3044",
  "id" : 531792724005888002,
  "in_reply_to_status_id" : 531792670859878400,
  "created_at" : "2014-11-10 12:57:20 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531792353955049472",
  "geo" : { },
  "id_str" : "531792493847670784",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3053\u3061\u3089\u3082\u7CBE\u795E\u3092\u5206\u88C2\u3055\u305B\u30661\u5BFE1\u3067\u5404\u500B\u6483\u7834\u3059\u308B",
  "id" : 531792493847670784,
  "in_reply_to_status_id" : 531792353955049472,
  "created_at" : "2014-11-10 12:56:25 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531791747890688000",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u4E94\u5104\u4EBA\u4EEE\u8AAC\u3082\u3042\u308B\u3057\u591A\u5206\u5927\u4E08\u592B\u3060\u308D\u3046\uFF08\uFF1F\uFF09",
  "id" : 531791747890688000,
  "created_at" : "2014-11-10 12:53:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531791540813692929",
  "geo" : { },
  "id_str" : "531791644551413761",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u78BA\u304B\u306B...\u6C17\u3092\u3064\u3051\u307E\u3059\uFF0E",
  "id" : 531791644551413761,
  "in_reply_to_status_id" : 531791540813692929,
  "created_at" : "2014-11-10 12:53:02 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531791173199740928",
  "geo" : { },
  "id_str" : "531791362044096512",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u78BA\u304B\u306B\uFF0E\u3060\u304B\u3089\u4ECA\u307E\u3067\u523A\u3055\u308C\u3066\u306A\u3044\u3093\u3060\u306D\uFF0E",
  "id" : 531791362044096512,
  "in_reply_to_status_id" : 531791173199740928,
  "created_at" : "2014-11-10 12:51:55 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531791203960778752",
  "text" : "\u30D6\u30E9\u30B8\u30EB\u306E\u9078\u624B\u304C\u307B\u3068\u3093\u3069\u4F55\u3082\u3057\u306A\u3044\u3088\u3046\u306B\uFF0C\u7279\u6B8A\u306A\u8A13\u7DF4\u3092\u53D7\u3051\u305F\u733F\u306F\u6B86\u3069\u4F55\u3067\u3082\u51FA\u6765\u308B",
  "id" : 531791203960778752,
  "created_at" : "2014-11-10 12:51:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531790826435661825",
  "geo" : { },
  "id_str" : "531790972686843906",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u3048\u3093\u3069\u3055\u3093\u3092\u5F8C\u308D\u304B\u3089\u523A\u3059\u306B\u306F\u4F53\u529B\u304C\u3044\u308B\u304B\u3089\u4F53\u529B\u4F5C\u308A\u306E\u305F\u3081\u306B\u6669\u5FA1\u98EF\u306F\u98DF\u3079\u3066\u308B\u3093\u3058\u3083\u306A\u3044\u304B\u306A",
  "id" : 531790972686843906,
  "in_reply_to_status_id" : 531790826435661825,
  "created_at" : "2014-11-10 12:50:22 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531790695191683073",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u3092\u5F8C\u308D\u304B\u3089\u523A\u3059\u3053\u3068\u3060\u3051\u3092\u5B66\u3093\u3067\u80B2\u3063\u3066\u304D\u305F\u733F\u3068\u304B\u306B\u523A\u3055\u308C\u305F\u304F\u306A\u3044\u304B\u3089\u306D",
  "id" : 531790695191683073,
  "created_at" : "2014-11-10 12:49:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531790514916323328",
  "text" : "\u65E5\u3005\u300C\u733F\u3067\u3082\u5206\u304B\u308B\u300D\u3063\u3066\u733F\u3092\u5C0F\u99AC\u9E7F\u306B\u3057\u3064\u3065\u3051\u3066\u3044\u308B\u3057\uFF0C\u52D5\u7269\u5712\u306B\u8A00\u3063\u305F\u3068\u304D\u306B\u306F\u733F\u306B\u3054\u3081\u3093\u306A\u3055\u3044\u3059\u308B\u306E\u3092\u5FD8\u308C\u306A\u3044\u3088\u3046\u306B\u3057\u3066\u3044\u308B",
  "id" : 531790514916323328,
  "created_at" : "2014-11-10 12:48:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531790010291212288",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u306E\u30B7\u30E5\u30FC\u30EB\u30AE\u30E3\u30B0\u306A\u3093\u3066\uFF08\u3048\u3093\u3069\u3055\u3093\u306E\u30B7\u30E5\u30FC\u30EB\u30AE\u30E3\u30B0\u3092\u7406\u89E3\u3059\u308B\u3053\u3068\u3060\u3051\u3092\u5E7C\u5C11\u306E\u3053\u308D\u3088\u308A\u53E9\u304D\u8FBC\u307E\u308C\u7D9A\u3051\u3066\u80B2\u3063\u3066\u304D\u305F\uFF09\u733F\u3067\u3082\u308F\u304B\u308B",
  "id" : 531790010291212288,
  "created_at" : "2014-11-10 12:46:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531788985232670720",
  "geo" : { },
  "id_str" : "531789086579642368",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u65E9\u304F\u98DF\u3079\u306A\u3044\u3068\u51B7\u3081\u3061\u3083\u3046\u3088",
  "id" : 531789086579642368,
  "in_reply_to_status_id" : 531788985232670720,
  "created_at" : "2014-11-10 12:42:53 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531789046977032193",
  "text" : "\u3082\u3057\u304B\u3057\u3066\u6669\u5FA1\u98EF\u3063\u3066\u304A\u663C\u3054\u98EF\u306E\u591C\u30D0\u30FC\u30B8\u30E7\u30F3\u306A\u306E\u3067\u306F",
  "id" : 531789046977032193,
  "created_at" : "2014-11-10 12:42:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531788373342420992",
  "text" : "\u6669\u5FA1\u98EF\u3092\u201D\u201D\u201D\u773A\u3081\u308B\u201D\u201D\u201D\u5BB6\u65CF\u3082\uFF0C\u3084\u3063\u3071\u308A\u30E4\u30D0\u3044\u3068\u601D\u3046\u3093\u3060",
  "id" : 531788373342420992,
  "created_at" : "2014-11-10 12:40:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531788082551336960",
  "geo" : { },
  "id_str" : "531788268459659266",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u3067\u3082\uFF0C\u98DF\u3079\u308B\u3093\u3067\u3057\u3087\uFF1F",
  "id" : 531788268459659266,
  "in_reply_to_status_id" : 531788082551336960,
  "created_at" : "2014-11-10 12:39:38 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531787992914882560",
  "text" : "\u6669\u5FA1\u98EF\u3092\u76EE\u306E\u524D\u306B\u3057\u3066\u300C\u6669\u5FA1\u98EF\u3069\u3046\u3057\u3088\u3046\u2026\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3089\u5B8C\u5168\u306BSAN\u50240\u306E\u4EBA\u9593\u3067\u3057\u3087",
  "id" : 531787992914882560,
  "created_at" : "2014-11-10 12:38:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531787639934812161",
  "text" : "\u6669\u5FA1\u98EF\u3069\u3046\u3057\u3088\u3046...\u3068\u308A\u3042\u3048\u305A\u6295\u3052\u308B\u304B\n\u3068\u306F\u7D4C\u9A13\u4E0A\u306A\u3089\u306A\u3044\u6C17\u304C\u3059\u308B\u3093\u3060",
  "id" : 531787639934812161,
  "created_at" : "2014-11-10 12:37:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531787405758439427",
  "geo" : { },
  "id_str" : "531787517104623617",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u6669\u5FA1\u98EF\u306B\u98DF\u3079\u308B\u4EE5\u5916\u306E\u7528\u9014\u304C\u3042\u308B\u3093\u3067\u3059\u304B",
  "id" : 531787517104623617,
  "in_reply_to_status_id" : 531787405758439427,
  "created_at" : "2014-11-10 12:36:38 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531787293112033280",
  "text" : "\u5B9F\u9A13\u306E\u7D50\u679C\uFF0C\u30AD\u30E3\u30B9\u30BF\u30FC\u4ED8\u304D\u306E\u6905\u5B50\u306B\u5EA7\u3063\u3066\u3050\u308B\u3050\u308B\u56DE\u308B\u3068\u76EE\u304C\u56DE\u308A\u3084\u3059\u3044\u306E\u3067\u306F\u306A\u3044\u304B\u3068\u3044\u3046\u4EEE\u8AAC\u3092\u7ACB\u3066\u308B\u3053\u3068\u306B\u6210\u529F\u3057\u305F",
  "id" : 531787293112033280,
  "created_at" : "2014-11-10 12:35:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531785601826041856",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 531785601826041856,
  "created_at" : "2014-11-10 12:29:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531785592325947392",
  "text" : "\u30D0\u30D5\u30A1\u30EA\u30F3\u306F\u3082\u306F\u3084\u534A\u5206\u3082\u306A\u3044\uFF08\u5730\u5143\u306E\u30E4\u30AF\u30B6\u304C7\u5272\u304F\u3089\u3044\u6301\u3063\u3066\u3044\u3063\u3066\u3057\u307E\u3063\u305F\u305F\u3081\uFF09",
  "id" : 531785592325947392,
  "created_at" : "2014-11-10 12:28:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531785311781527552",
  "geo" : { },
  "id_str" : "531785408565104640",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u5DE5\u5834\u306B\u8A73\u3057\u3044\u3067\u3059\u306D",
  "id" : 531785408565104640,
  "in_reply_to_status_id" : 531785311781527552,
  "created_at" : "2014-11-10 12:28:16 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531784919601532928",
  "text" : "\u6B8B\u308A\u306E\u534A\u5206\u306F...",
  "id" : 531784919601532928,
  "created_at" : "2014-11-10 12:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531784888802750464",
  "text" : "\u30D0\u30D5\u30A1\u30EA\u30F3\u306E\u534A\u5206\u306F\uFF0C\u5DE5\u5834\u3067\u51FA\u6765\u3066\u3044\u308B",
  "id" : 531784888802750464,
  "created_at" : "2014-11-10 12:26:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531784627124334594",
  "text" : "\u4F1A\u8A71\u306E\u697D\u3057\u3044\u30C9\u30C3\u30B8\u30DC\u30FC\u30EB",
  "id" : 531784627124334594,
  "created_at" : "2014-11-10 12:25:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 26, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531783715886600192",
  "text" : "\u98DB\u884C\u6A5F\u304B\u3054\u3068\u98DB\u884C\u6A5F\u3042\u307F\u3092\u6301\u3063\u3066\u98DB\u884C\u6A5F\u3092\u53D6\u308A\u306B\u3044\u304F\u4EBA \uFF03\u4EBA",
  "id" : 531783715886600192,
  "created_at" : "2014-11-10 12:21:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531783457278394368",
  "text" : "\u3084\u308B\u3088\u3046\u306B\uFF0C\u306A",
  "id" : 531783457278394368,
  "created_at" : "2014-11-10 12:20:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531783382363947009",
  "text" : "\u5C0F\u5B66\u751F\u304C\u30BB\u30DF\u53D6\u308A\u3092\u3084\u308A\u3088\u3046\u306B\u306E\u3046\u3053\u3055\u3093\u306F\u98DB\u884C\u6A5F\u3092\u53D6\u308B",
  "id" : 531783382363947009,
  "created_at" : "2014-11-10 12:20:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531783140998533120",
  "text" : "\u30BD\u30D3\u30A8\u30C8\u30ED\u30B7\u30A2\u3060\uFF08\u65AD\u5B9A\uFF09",
  "id" : 531783140998533120,
  "created_at" : "2014-11-10 12:19:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531782449936621568",
  "text" : "\u6295\u3052\u6368\u3066\u3066\u3082\u623B\u3063\u3066\u304F\u308B\u30D6\u30FC\u30E1\u30E9\u30F3",
  "id" : 531782449936621568,
  "created_at" : "2014-11-10 12:16:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531782327249027072",
  "text" : "\u5F37\u3044\u5149\u304C\u5F37\u3044",
  "id" : 531782327249027072,
  "created_at" : "2014-11-10 12:16:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531781681322024963",
  "text" : "\uFF1F\u300C\u5C02\u9580\u306F\u6295\u3052\u6368\u3066\u308B\u3082\u306E\u300D",
  "id" : 531781681322024963,
  "created_at" : "2014-11-10 12:13:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531781142588829696",
  "text" : "\u60DC\u3057\u304F\u306A\u3044\uFF08\u672C\u5F53\u306F\u60DC\u3057\u3044\uFF09",
  "id" : 531781142588829696,
  "created_at" : "2014-11-10 12:11:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531781103405629440",
  "text" : "\u307C\u3093\u3084\u308A\u3068\u53E3\u3092\u3042\u3051\u308B\u30B9\u30AD\u30EB\u304C\u78E8\u304B\u308C\u305F\u3068\u601D\u3048\u3070",
  "id" : 531781103405629440,
  "created_at" : "2014-11-10 12:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531780684084305920",
  "text" : "\u307C\u3093\u3084\u308A\u3068\u53E3\u3092\u958B\u3051\u3066\u3044\u305F\u3060\u3051\u3060\u3063\u305F\u3042\u306E1\u5E74\u9593\u306B\u8272\u3005\u3084\u308C\u305F\u306E\u306B\u306A\u3041\u3063\u3066\u601D\u3046",
  "id" : 531780684084305920,
  "created_at" : "2014-11-10 12:09:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531780521164947457",
  "text" : "\u306B\u304C\u3044\u306E\u601D\u3044\u51FA\u306F\u8133\u304C\u8A18\u61B6\u304B\u3089\u6D88\u53BB\u3057\u305F",
  "id" : 531780521164947457,
  "created_at" : "2014-11-10 12:08:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531780133175062529",
  "text" : "\u767E\u8DB3\u306E\u8349\u978B",
  "id" : 531780133175062529,
  "created_at" : "2014-11-10 12:07:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youhei SASAKI",
      "screen_name" : "uwabami",
      "indices" : [ 0, 8 ],
      "id_str" : "7704022",
      "id" : 7704022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531778002611228675",
  "geo" : { },
  "id_str" : "531778360511172610",
  "in_reply_to_user_id" : 7704022,
  "text" : "@uwabami 24\u6761\u306E\u300C\u4E94\u576A\u300D\u3067\u7261\u86CE\u3068\u304B.\u30D5\u30A3\u30EC\u30F3\u30C4\u30A7\u3068\u304B\uFF0E",
  "id" : 531778360511172610,
  "in_reply_to_status_id" : 531778002611228675,
  "created_at" : "2014-11-10 12:00:15 +0000",
  "in_reply_to_screen_name" : "uwabami",
  "in_reply_to_user_id_str" : "7704022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531776926583492608",
  "text" : "\u3069\u3046\u3082\u4E2D\u9014\u534A\u7AEF\u5927\u81E3\u3067\u3059",
  "id" : 531776926583492608,
  "created_at" : "2014-11-10 11:54:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531776487070769152",
  "text" : "\u5E30\u5C5E\u610F\u8B58\u3068\u304B\u8A00\u3046\u5974\uFF0C\u5272\u3068\u5404\u3005\u306B\u306F\u5E0C\u8584\u304B\u3082\u3057\u308C\u306C",
  "id" : 531776487070769152,
  "created_at" : "2014-11-10 11:52:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531775157933588480",
  "text" : "\u3060\u3051\uFF0C\u3058\u3083\u30C0\u30E1\u3060\u306D",
  "id" : 531775157933588480,
  "created_at" : "2014-11-10 11:47:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531775107555790849",
  "text" : "\u3042\u3089\u3086\u308B\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u3092\u6D3B\u7528\u3059\u308B\u3060\u3051\u306E\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u304A\u3070\u3051\u306B\u306A\u308A\u305F\u3044",
  "id" : 531775107555790849,
  "created_at" : "2014-11-10 11:47:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531774808468361216",
  "text" : "\u82F1\u548C\u8F9E\u5178\u306B\u3064\u3044\u3066\u306F\u30A2\u30F3\u30BF\u30A4\u30B8\u30FC\u30CB\u30A2\u30B9\u306E\u7ACB\u5834",
  "id" : 531774808468361216,
  "created_at" : "2014-11-10 11:46:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531774396092780544",
  "text" : "hogehoge\u306B\u3064\u3044\u3066\u306F\u73FE\u5728\u8ABF\u67FB\u4E2D\u3067\u3042\u3063\u3066\uFF0C\u4E8B\u5B9F\u95A2\u4FC2\u304C\u660E\u3089\u304B\u306B\u306A\u308B\u307E\u3067\u306F\u30CF\u30C3\u30AD\u30EA\u3068\u3057\u305F\u3053\u3068\u3092\u7533\u3057\u4E0A\u3052\u308B\u3053\u3068\u306F\u51FA\u6765\u306A\u3044\u30E1\u30BD\u30C3\u30C9\uFF0C\u4F7F\u3044\u53E4\u3055\u308C\u3066\u306F\u3044\u308B\u3051\u3069\u4FBF\u5229",
  "id" : 531774396092780544,
  "created_at" : "2014-11-10 11:44:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531773868361273345",
  "geo" : { },
  "id_str" : "531774130949865473",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30CD\u30BF\u30A2\u30AB\u30A6\u30F3\u30C8\u3092\u540D\u4E57\u3063\u305F\u8A18\u61B6\u306F\u306A\u3044\uFF08\u30CD\u30BF\u30A2\u30AB\u30A6\u30F3\u30C8\u3067\u3042\u308B\u3068\u3044\u3046\u5B9F\u72B6\u306B\u3064\u3044\u3066\u306F\u73FE\u5728\u8ABF\u67FB\u4E2D\u3067\u3042\u3063\u3066\uFF0C\u4E8B\u5B9F\u95A2\u4FC2\u304C\u660E\u3089\u304B\u306B\u306A\u3063\u3066\u304B\u3089\u8A18\u8005\u4F1A\u898B\u3092\uFF08ry\uFF09",
  "id" : 531774130949865473,
  "in_reply_to_status_id" : 531773868361273345,
  "created_at" : "2014-11-10 11:43:27 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531773856348778496",
  "text" : "\u982D\u60AA\u3044\u7269\u8A00\u3044\u3060",
  "id" : 531773856348778496,
  "created_at" : "2014-11-10 11:42:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531773751692500992",
  "text" : "\u8EAB\u306B\u3064\u3051\u305F\u3068\u3053\u308D\u3067\u7121\u99C4\u3060\u3051\u3069",
  "id" : 531773751692500992,
  "created_at" : "2014-11-10 11:41:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531773724899278848",
  "text" : "\u3060\u3063\u3066\u91CD\u8981\u306A\u4E8B\u306F\u91CD\u8981\u306A\u308F\u3051\u3060\u304B\u3089\u52DD\u624B\u306B\u6BD4\u91CD\u304C\u91CD\u305F\u304F\u306A\u308B\u3051\u3069\u7121\u99C4\u306A\u4E8B\u306F\u7121\u99C4\u306A\u308F\u3051\u3060\u304B\u3089\u81EA\u5206\u3067\u6BD4\u91CD\u91CD\u304F\u3057\u306A\u3044\u3068\u8EAB\u306B\u3064\u304B\u306A\u3044\u3058\u3083\u3093",
  "id" : 531773724899278848,
  "created_at" : "2014-11-10 11:41:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531773428835942400",
  "text" : "\u6559\u990A\u3063\u3066\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3051\u3069\uFF0C\u7121\u99C4\u306A\u3053\u3068\u304B\u3089\u9806\u756A\u306B\u8EAB\u306B\u3064\u3051\u305F\u3089\u3044\u3064\u304B\u306F\u8EAB\u306B\u3064\u304F\u304B\u306A\u30FC\u3063\u3066",
  "id" : 531773428835942400,
  "created_at" : "2014-11-10 11:40:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531772919618097152",
  "text" : "\u4ECA\u65E5\u306F\u300C\u3055\u3080\u3044\u3055\u3080\u3044\u30DE\u30A6\u30F3\u30C6\u30F3\u304B\u3088\u300D\u3063\u3066\u8A00\u3046\u30C4\u30C3\u30B3\u30DF\u304C\u3042\u3063\u305F\u3088",
  "id" : 531772919618097152,
  "created_at" : "2014-11-10 11:38:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531772769231720448",
  "text" : "\u65E5\u5E38\u751F\u6D3B\u3068\u304B\u30C4\u30C3\u30B3\u30DF\u3068\u304B\u306E\u9006\u554F\u984C\u307F\u305F\u3044\u306A\u306E\u8003\u3048\u308B\u306E\u697D\u3057\u304F\u3066\u597D\u304D",
  "id" : 531772769231720448,
  "created_at" : "2014-11-10 11:38:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531772531439452161",
  "text" : "\u660E\u5BDF\u3063\u307D\u3044",
  "id" : 531772531439452161,
  "created_at" : "2014-11-10 11:37:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 3, 11 ],
      "id_str" : "203870045",
      "id" : 203870045
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 13, 23 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531772498333794304",
  "text" : "RT @bagirom: @end313124 \u6C34\u9053\u4E0D\u826F\u6642\u7528\u3002\u8CAF\u6C34\u69FD\u306B\u7D66\u6C34\u3057\u3064\u3001\u6C34\u3092\u6D41\u305B\u3070\u6D41\u308C\u308B\u3002\n\n\u305F\u3076\u3093\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/theworld09.com\/\" rel=\"nofollow\"\u003ETheWorld\u2800\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "531770199247044608",
    "geo" : { },
    "id_str" : "531770708070649856",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u6C34\u9053\u4E0D\u826F\u6642\u7528\u3002\u8CAF\u6C34\u69FD\u306B\u7D66\u6C34\u3057\u3064\u3001\u6C34\u3092\u6D41\u305B\u3070\u6D41\u308C\u308B\u3002\n\n\u305F\u3076\u3093\u3002",
    "id" : 531770708070649856,
    "in_reply_to_status_id" : 531770199247044608,
    "created_at" : "2014-11-10 11:29:51 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "protected" : false,
      "id_str" : "203870045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605496442384310274\/X9eZyMQt_normal.jpg",
      "id" : 203870045,
      "verified" : false
    }
  },
  "id" : 531772498333794304,
  "created_at" : "2014-11-10 11:36:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531772126156439552",
  "text" : "\u3055\u3063\u304D\u306E\u713C\u914E\u306E\u30DC\u30C8\u30EB\uFF0C\u4E2D\u8EAB\u6C34\u3060\u3063\u305F\u3063\u307D\u3044\u3067\u3059",
  "id" : 531772126156439552,
  "created_at" : "2014-11-10 11:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531771500588576768",
  "geo" : { },
  "id_str" : "531772066165293057",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u5302\u3044\u55C5\u3044\u3067\u304D\u305F\u3051\u3069\u5727\u5012\u7684\u306B\u6C34\u3060\u3063\u305F\uFF0E\u3054\u660E\u5BDF\uFF0E",
  "id" : 531772066165293057,
  "in_reply_to_status_id" : 531771500588576768,
  "created_at" : "2014-11-10 11:35:15 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531771646315474944",
  "text" : "\u78BA\u304B\u3081\u3066\u304F\u308B\u3088",
  "id" : 531771646315474944,
  "created_at" : "2014-11-10 11:33:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531771551549382656",
  "text" : "hogehoge is exists\u69CB\u6587\u3068hogehoge is nowhere\u69CB\u6587\u306E\u4F7F\u3044\u624B",
  "id" : 531771551549382656,
  "created_at" : "2014-11-10 11:33:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531771134065139712",
  "geo" : { },
  "id_str" : "531771321638608897",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u78BA\u304B\u3081\u3066\u306A\u3044...\uFF08\u3051\u3069\u713C\u914E\u306E\u5BB9\u5668\u306B\u900F\u660E\u306A\u6DB2\u4F53\u304C\u5165\u3063\u3066\u305F\u3089\u713C\u914E\u3060\u3068\u601D\u3046\u3088\u306D\uFF09",
  "id" : 531771321638608897,
  "in_reply_to_status_id" : 531771134065139712,
  "created_at" : "2014-11-10 11:32:17 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531770708070649856",
  "geo" : { },
  "id_str" : "531770994365440000",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u713C\u914E\u3067\u3042\u308B\u5FC5\u7136\u6027 is nowhere",
  "id" : 531770994365440000,
  "in_reply_to_status_id" : 531770708070649856,
  "created_at" : "2014-11-10 11:30:59 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531770306902257664",
  "text" : "\u70B9\u306E\u4F4D\u7F6E\u304C\u5909\u3060\u3063\u305F",
  "id" : 531770306902257664,
  "created_at" : "2014-11-10 11:28:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531770199247044608",
  "text" : "\u3086\u308B\u307C\uFF1A\u7537\u5B50\u30C8\u30A4\u30EC\u306E\u624B\u6D17\u3044\u5834\u306B\u30AF\u30BD\u5B89\u3044\u6D88\u6BD2\u6DB2\u307F\u305F\u3044\u306A\u713C\u914E\u306E4L\u304F\u3089\u3044\u306E\u30DC\u30C8\u30EB\u304C\u534A\u5206\u4F4D\u6B8B\u3063\u305F\u72B6\u614B\u3067\u653E\u7F6E\u3055\u308C\u3066\u3044\u308B\uFF0C\u4EF6\u306B\u3064\u3044\u3066\u306E\u7D0D\u5F97\u306E\u884C\u304F\u30B9\u30C8\u30FC\u30EA\u30FC",
  "id" : 531770199247044608,
  "created_at" : "2014-11-10 11:27:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kojima",
      "screen_name" : "t33f",
      "indices" : [ 0, 5 ],
      "id_str" : "14152394",
      "id" : 14152394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531767831684059137",
  "geo" : { },
  "id_str" : "531768277366603776",
  "in_reply_to_user_id" : 14152394,
  "text" : "@t33f \u5143\u30CD\u30BF\u304C\u591C\u6C7D\u8ECA\u306E\u7537\u3067\uFF0C\u30A8\u30C3\u30BB\u30A4\u306F\u5225\u306E\u4EBA\u304C\u30AA\u30DE\u30FC\u30B8\u30E5\u3068\u8A00\u3046\u304B\u5FF5\u982D\u306B\u304A\u3044\u3066\u66F8\u3044\u305F\u306E\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u304C\uFF0C\u5370\u8C61\u7684\u3067\u3059\u3088\u306D",
  "id" : 531768277366603776,
  "in_reply_to_status_id" : 531767831684059137,
  "created_at" : "2014-11-10 11:20:11 +0000",
  "in_reply_to_screen_name" : "t33f",
  "in_reply_to_user_id_str" : "14152394",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kojima",
      "screen_name" : "t33f",
      "indices" : [ 0, 5 ],
      "id_str" : "14152394",
      "id" : 14152394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531766823302078464",
  "geo" : { },
  "id_str" : "531766944274206720",
  "in_reply_to_user_id" : 14152394,
  "text" : "@t33f \u591C\u6C7D\u8ECA\u306E\u7537\u3067\u3059\u304B\u306D\uFF1F",
  "id" : 531766944274206720,
  "in_reply_to_status_id" : 531766823302078464,
  "created_at" : "2014-11-10 11:14:53 +0000",
  "in_reply_to_screen_name" : "t33f",
  "in_reply_to_user_id_str" : "14152394",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531758402360193024",
  "text" : "\u305F\u3060\u5F92\u306B\u70CF\u9F8D\u8336\u3068\u8A08\u7B97\u7528\u7D19\u3092\u6D88\u8CBB\u3059\u308B\u5B58\u5728",
  "id" : 531758402360193024,
  "created_at" : "2014-11-10 10:40:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531757969558364160",
  "text" : "\u50D5\u3082\u4F8B\u4F1A\u884C\u3051\u307E\u305B\u3093",
  "id" : 531757969558364160,
  "created_at" : "2014-11-10 10:39:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531755089644367873",
  "text" : "\u3061\u304E\u3063\u3066\u306F\u6295\u3052\u30FC\u3061\u304E\u3063\u3066\u306F\u6295\u3052\u30FC",
  "id" : 531755089644367873,
  "created_at" : "2014-11-10 10:27:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531752742218248192",
  "text" : "ill-defined\u304A\u3070\u3051",
  "id" : 531752742218248192,
  "created_at" : "2014-11-10 10:18:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531752472495149056",
  "text" : "\u7518\u3044\u30D1\u30F3\u3068\u304B\u98DF\u3079\u305F\u3044",
  "id" : 531752472495149056,
  "created_at" : "2014-11-10 10:17:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531742746873057280",
  "text" : "\u6628\u65E5\u898B\u305F\u52D5\u753B\u306E\u4F5C\u8005\u30A7...",
  "id" : 531742746873057280,
  "created_at" : "2014-11-10 09:38:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "indices" : [ 0, 15 ],
      "id_str" : "158991353",
      "id" : 158991353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531734723001737216",
  "geo" : { },
  "id_str" : "531734810436198401",
  "in_reply_to_user_id" : 158991353,
  "text" : "@sorayama_asobi \u3053\u306E\u8ABF\u5B50\u3067(?)\u9811\u5F35\u3063\u3066\u304F\u3060\u3055\u3044",
  "id" : 531734810436198401,
  "in_reply_to_status_id" : 531734723001737216,
  "created_at" : "2014-11-10 09:07:12 +0000",
  "in_reply_to_screen_name" : "sorayama_asobi",
  "in_reply_to_user_id_str" : "158991353",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531734383015628800",
  "text" : "\u7A7A\u5C71\u3055\u3093\u306E\u30D6\u30ED\u30B0\uFF0C\u8B0E\u306E\u52E2\u3044\u304C\u3042\u3063\u3066\u304A\u3082\u3057\u308D\u3044",
  "id" : 531734383015628800,
  "created_at" : "2014-11-10 09:05:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531693470637776896",
  "text" : "\u306D\u3053\u30FC\u306D\u3053\u30FC",
  "id" : 531693470637776896,
  "created_at" : "2014-11-10 06:22:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youhei SASAKI",
      "screen_name" : "uwabami",
      "indices" : [ 0, 8 ],
      "id_str" : "7704022",
      "id" : 7704022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531681257311043586",
  "geo" : { },
  "id_str" : "531681460860641280",
  "in_reply_to_user_id" : 7704022,
  "text" : "@uwabami \u3067\u3059\u3088\u306D...",
  "id" : 531681460860641280,
  "in_reply_to_status_id" : 531681257311043586,
  "created_at" : "2014-11-10 05:35:13 +0000",
  "in_reply_to_screen_name" : "uwabami",
  "in_reply_to_user_id_str" : "7704022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youhei SASAKI",
      "screen_name" : "uwabami",
      "indices" : [ 0, 8 ],
      "id_str" : "7704022",
      "id" : 7704022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531680607970271234",
  "geo" : { },
  "id_str" : "531680784445227008",
  "in_reply_to_user_id" : 7704022,
  "text" : "@uwabami \u50D5\u306F\u5317\u6D77\u9053\u306E\u51AC\u306F\u4ECA\u5E74\u304C\u521D\u3081\u3066\u306A\u306E\u3067\u6226\u3005\u6050\u3005\u3068\u3057\u3066\u3044\u307E\u3059\uFF0E\u6B63\u76F4\u4EAC\u90FD\u3082\u5341\u4E8C\u5206\u306B\u5BD2\u3044\u3068\u601D\u3044\u307E\u3059\u3051\u3069\uFF0C\u96EA\u306F\u3042\u307E\u308A\u964D\u3089\u306A\u3044\u3067\u3059\u3088\u306D\uFF0E",
  "id" : 531680784445227008,
  "in_reply_to_status_id" : 531680607970271234,
  "created_at" : "2014-11-10 05:32:31 +0000",
  "in_reply_to_screen_name" : "uwabami",
  "in_reply_to_user_id_str" : "7704022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youhei SASAKI",
      "screen_name" : "uwabami",
      "indices" : [ 0, 8 ],
      "id_str" : "7704022",
      "id" : 7704022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531679911988060160",
  "geo" : { },
  "id_str" : "531680067458322432",
  "in_reply_to_user_id" : 7704022,
  "text" : "@uwabami \u3048\u3048\u30FC...",
  "id" : 531680067458322432,
  "in_reply_to_status_id" : 531679911988060160,
  "created_at" : "2014-11-10 05:29:40 +0000",
  "in_reply_to_screen_name" : "uwabami",
  "in_reply_to_user_id_str" : "7704022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youhei SASAKI",
      "screen_name" : "uwabami",
      "indices" : [ 0, 8 ],
      "id_str" : "7704022",
      "id" : 7704022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531679708992110592",
  "geo" : { },
  "id_str" : "531679777418006528",
  "in_reply_to_user_id" : 7704022,
  "text" : "@uwabami \u96EA\u304C\u964D\u3089\u306A\u3044\u3068\u826F\u3044\u3067\u3059\u306D...",
  "id" : 531679777418006528,
  "in_reply_to_status_id" : 531679708992110592,
  "created_at" : "2014-11-10 05:28:31 +0000",
  "in_reply_to_screen_name" : "uwabami",
  "in_reply_to_user_id_str" : "7704022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youhei SASAKI",
      "screen_name" : "uwabami",
      "indices" : [ 0, 8 ],
      "id_str" : "7704022",
      "id" : 7704022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531679254883610624",
  "geo" : { },
  "id_str" : "531679348495876096",
  "in_reply_to_user_id" : 7704022,
  "text" : "@uwabami \u7814\u7A76\u96C6\u4F1A\u304B\u4F55\u304B\u3067\u3059\u304B\uFF1F",
  "id" : 531679348495876096,
  "in_reply_to_status_id" : 531679254883610624,
  "created_at" : "2014-11-10 05:26:49 +0000",
  "in_reply_to_screen_name" : "uwabami",
  "in_reply_to_user_id_str" : "7704022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531670541631885313",
  "text" : "\u4F4E\u6E29\uFF0C\u7C97\u633D\u304D\u306E\u30B3\u30FC\u30D2\u30FC\uFF0C\u3084\u306F\u308A\u826F\u3044",
  "id" : 531670541631885313,
  "created_at" : "2014-11-10 04:51:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531664855829200896",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8...",
  "id" : 531664855829200896,
  "created_at" : "2014-11-10 04:29:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531664790205124608",
  "text" : "\u3041\uFF0E\uFF0E\uFF0E\uFF0E\u3045....\u3041....",
  "id" : 531664790205124608,
  "created_at" : "2014-11-10 04:28:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531656022172004352",
  "text" : "\u304A\u524D\u3089\u307B\u3093\u3068\u3046\u306B\u5BB9\u6613\u306B\u611F\u60C5\u3092\u5931\u3046\u3088\u306A",
  "id" : 531656022172004352,
  "created_at" : "2014-11-10 03:54:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u76F8\u8EE2\u79FBP\uFF08\u5E02\u6C11\uFF09",
      "screen_name" : "phasetr",
      "indices" : [ 0, 8 ],
      "id_str" : "72528916",
      "id" : 72528916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531462877912129536",
  "geo" : { },
  "id_str" : "531463098427658241",
  "in_reply_to_user_id" : 72528916,
  "text" : "@phasetr \u56DE\u907F\u884C\u52D5\u306B\u306F\u81EA\u4FE1\u30A2\u30EA\u3067\u3059(?)",
  "id" : 531463098427658241,
  "in_reply_to_status_id" : 531462877912129536,
  "created_at" : "2014-11-09 15:07:31 +0000",
  "in_reply_to_screen_name" : "phasetr",
  "in_reply_to_user_id_str" : "72528916",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531437596019134464",
  "text" : "\u304B\u3057\u3071\u3093\u3061\u3083\u3093\u3057\u3070\u3089\u304F\u4F1A\u3063\u3066\u306A\u3044",
  "id" : 531437596019134464,
  "created_at" : "2014-11-09 13:26:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531437400229031936",
  "geo" : { },
  "id_str" : "531437481745334272",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u50D5\u3082\u884C\u304D\u307E\u3059\u304B\u3089\u4E45\u3005\u306B\u4F1A\u304A\u3046",
  "id" : 531437481745334272,
  "in_reply_to_status_id" : 531437400229031936,
  "created_at" : "2014-11-09 13:25:43 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/ysG4aAnWFr",
      "expanded_url" : "http:\/\/nf.la\/kikaku\/student\/okunai\/yosida.html",
      "display_url" : "nf.la\/kikaku\/student\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "531436538450567168",
  "geo" : { },
  "id_str" : "531436703668396032",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi http:\/\/t.co\/ysG4aAnWFr",
  "id" : 531436703668396032,
  "in_reply_to_status_id" : 531436538450567168,
  "created_at" : "2014-11-09 13:22:38 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531436349551677441",
  "text" : "MOW\u306E\u30C1\u30FC\u30BA\u306A\u308B\u3082\u306E\u3092\u98DF\u3079\u3066\u308B",
  "id" : 531436349551677441,
  "created_at" : "2014-11-09 13:21:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531436012019257346",
  "geo" : { },
  "id_str" : "531436073142870016",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u3058\u3076\u3093\u3067\u3055\u304B\u306E\u307C\u308C\uFF08\u3081\u3093\u3069\u3046\uFF09",
  "id" : 531436073142870016,
  "in_reply_to_status_id" : 531436012019257346,
  "created_at" : "2014-11-09 13:20:08 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531435664328241152",
  "geo" : { },
  "id_str" : "531435727364427778",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u9F3B\u8840\u306E\u4EBA\u3067\u3059",
  "id" : 531435727364427778,
  "in_reply_to_status_id" : 531435664328241152,
  "created_at" : "2014-11-09 13:18:45 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531435668480589824",
  "text" : "\u307F\u3093\u306A\u89B3\u6226\u3057\u305F\u304C\u308B\u3051\u3069\u53C2\u52A0\u3057\u308D\u3088\u611F",
  "id" : 531435668480589824,
  "created_at" : "2014-11-09 13:18:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C38\u7530[\u5947\u4EBA+6]",
      "screen_name" : "strangamo1986",
      "indices" : [ 3, 17 ],
      "id_str" : "127847997",
      "id" : 127847997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531435614902554624",
  "text" : "RT @strangamo1986: \u305B\u3063\u304B\u304F\u306E\u6700\u5F8C\u306E\u5E74\u306A\u306E\u3067\u3001\u300C\u624B\u3092\u53E9\u3044\u3066\u6E9C\u3081\u30FB\u653B\u6483\u30FB\u9632\u5FA1\u306E\u30DD\u30FC\u30BA\u3092\u53D6\u308B\u3084\u3064\u5927\u4F1A\u300D\u304C\u3042\u308B\u306A\u3089\u89B3\u6226\u3057\u306B\u884C\u304D\u305F\u3044\uFF08\uFF1F\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531434822057484288",
    "text" : "\u305B\u3063\u304B\u304F\u306E\u6700\u5F8C\u306E\u5E74\u306A\u306E\u3067\u3001\u300C\u624B\u3092\u53E9\u3044\u3066\u6E9C\u3081\u30FB\u653B\u6483\u30FB\u9632\u5FA1\u306E\u30DD\u30FC\u30BA\u3092\u53D6\u308B\u3084\u3064\u5927\u4F1A\u300D\u304C\u3042\u308B\u306A\u3089\u89B3\u6226\u3057\u306B\u884C\u304D\u305F\u3044\uFF08\uFF1F\uFF09",
    "id" : 531434822057484288,
    "created_at" : "2014-11-09 13:15:09 +0000",
    "user" : {
      "name" : "\u6C38\u7530[\u5947\u4EBA+6]",
      "screen_name" : "strangamo1986",
      "protected" : false,
      "id_str" : "127847997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1421394351\/ynagataorg_banner_normal.jpeg",
      "id" : 127847997,
      "verified" : false
    }
  },
  "id" : 531435614902554624,
  "created_at" : "2014-11-09 13:18:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531435303186075649",
  "text" : "NF\u3067\u4F1A\u3063\u305F\u4EBA\u306E\u8A8D\u8B58\u3067\u304D\u3066\u306A\u3055\u306A",
  "id" : 531435303186075649,
  "created_at" : "2014-11-09 13:17:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531435232474329088",
  "text" : "\u3068\u3044\u3046\u304B\u3068\u3082\u3059\u308B\u3068\u3042\u308B\u308B\u3055\u3093\u3068\u4F1A\u3063\u3066\u308B\u53EF\u80FD\u6027\u3042\u308B\u306E\u304B",
  "id" : 531435232474329088,
  "created_at" : "2014-11-09 13:16:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531434844299862017",
  "text" : "\u53BB\u5E74\u306F\u4F55\u306B\u3082\u63A7\u3048\u3066\u3044\u306A\u3044\u63A7\u3048\u5BA4\u3060\u3063\u305F\u3051\u3069\u4ECA\u5E74\u3082\u5F53\u305F\u308A\u969C\u308A\u306E\u306A\u3044\u611F\u3058\u3060",
  "id" : 531434844299862017,
  "created_at" : "2014-11-09 13:15:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u308B\u3061\u3083\u3093",
      "screen_name" : "R_ru",
      "indices" : [ 0, 5 ],
      "id_str" : "216737857",
      "id" : 216737857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531434499192537088",
  "geo" : { },
  "id_str" : "531434570596368384",
  "in_reply_to_user_id" : 216737857,
  "text" : "@R_ru \u306A\u308B\u307B\u3069\u3042\u308A\u304C\u3068\u3067\u3059",
  "id" : 531434570596368384,
  "in_reply_to_status_id" : 531434499192537088,
  "created_at" : "2014-11-09 13:14:09 +0000",
  "in_reply_to_screen_name" : "R_ru",
  "in_reply_to_user_id_str" : "216737857",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u308B\u3061\u3083\u3093",
      "screen_name" : "R_ru",
      "indices" : [ 0, 5 ],
      "id_str" : "216737857",
      "id" : 216737857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531434341797093376",
  "geo" : { },
  "id_str" : "531434383975010304",
  "in_reply_to_user_id" : 216737857,
  "text" : "@R_ru \u30BD\u30FC\u30B9\u306F\u3069\u3053\u3067\u3059\uFF1F",
  "id" : 531434383975010304,
  "in_reply_to_status_id" : 531434341797093376,
  "created_at" : "2014-11-09 13:13:25 +0000",
  "in_reply_to_screen_name" : "R_ru",
  "in_reply_to_user_id_str" : "216737857",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531434274176507904",
  "text" : "\u3068\u3044\u3046\u304BNF\u30D1\u30F3\u30D5\uFF0C\u666E\u901A\u306B\u624B\u306B\u5165\u3089\u306A\u3044\u3057\u8AB0\u304BPDF\u306B\u3057\u3066\u9001\u3063\u3066\u307B\u3057\u3044\u3088\u306D",
  "id" : 531434274176507904,
  "created_at" : "2014-11-09 13:12:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531433966239088640",
  "text" : "KUTLS\u2192\u304B\u3078\u308F\u306C\u3081\u2192\u3059\u3086\u3042\u306C\u2192\u3084\u308B\u3081\u3053\u3042 \u8108\u3005\u3068\u53D7\u3051\u7D99\u304C\u308C\u3066\u3044\u304F\u7CFB\u8B5C\u3092\u611F\u3058\u308B\uFF0E\uFF0E\uFF0E",
  "id" : 531433966239088640,
  "created_at" : "2014-11-09 13:11:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531433641977470978",
  "text" : "\u306A\u306B\u304C\u3088\u3057\u3088\u3057\u4F55\u3060\u304B\u3088\u304F\u308F\u304B\u3089\u3093",
  "id" : 531433641977470978,
  "created_at" : "2014-11-09 13:10:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531433604287455232",
  "text" : "\u3084\u308B\u3081\u3053\u3042\uFF0E\u305D\u3046\u3044\u3046\u540D\u524D\u306B\u306A\u3063\u305F\u306E\u304B\uFF0E\u3088\u3057\u3088\u3057\uFF0E",
  "id" : 531433604287455232,
  "created_at" : "2014-11-09 13:10:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531432783722196992",
  "text" : "\u70AC\u71F5\u3067\u30A2\u30A4\u30B9\u3092\u98DF\u3079\u308B\uFF01\uFF01\uFF01\uFF01",
  "id" : 531432783722196992,
  "created_at" : "2014-11-09 13:07:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531413673923710976",
  "text" : "\u72EC\u81EA\u306E\u8ABF\u3079\u306B\u3088\u3063\u3066\u53BB\u5E74\u3082\u3053\u306E\u65E5\u306B\u3060\u3057\u3066\u3044\u305F\u3089\u3057\u3044\u306E\u3067\u70AC\u71F5\u3092\u51FA\u3059\u3088",
  "id" : 531413673923710976,
  "created_at" : "2014-11-09 11:51:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531390808276996096",
  "text" : "\u30D7\u30EA\u30AF\u30E9\uFF0C\u76EE\u304C\u5927\u304D\u304F\u306A\u3063\u305F\u308A\u8DB3\u304C\u7D30\u304F\u306A\u3063\u305F\u308A\u3059\u308B\u306E\u306E\u5177\u5408\u3092\u78BA\u304B\u3081\u308B\u305F\u3081\u306B\uFF0C\u5E02\u677E\u6A21\u69D8\u306E\u30D1\u30CD\u30EB\u3092\u64AE\u3063\u305F\u3084\u3064\u3092\u898B\u3066\u307F\u305F\u3044",
  "id" : 531390808276996096,
  "created_at" : "2014-11-09 10:20:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531390211595317248",
  "text" : "\u9032\u6357\u3092\u7D5E\u308A\u51FA\u3059\u3068\uFF0C\u305D\u306E\u4E94\u5104\u500D\u304F\u3089\u3044\u306E\u6FB1\u304C\u51FA\u308B\u3057\uFF0C\u305D\u308C\u3092\u5410\u304D\u51FA\u3055\u306A\u3044\u3068\u3042\u305F\u307E\u304C\u304A\u304B\u3057\u304F\u306A\u3063\u3066\u6B7B\u306C",
  "id" : 531390211595317248,
  "created_at" : "2014-11-09 10:17:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531389923710861313",
  "text" : "\u3042\u30FC\uFF0C\u3042\u3068\u4F5C\u696D\u304C\u9032\u307E\u306A\u3044\u3053\u3068\u306E\u3064\u3089\u307F\u307F\u305F\u3044\u306A\u3082\u306E\uFF0C\u5168\u90E8Twitter\u306B\u6D41\u3057\u8FBC\u3080\u306E\uFF0C(\u5C11\u306A\u304F\u3068\u3082\u50D5\u306F)\u6C17\u6301\u3061\u306E\u9762\u306B\u304A\u3044\u3066\u697D\u306B\u306A\u3063\u305F\u306E\u3067\u304A\u3059\u3059\u3081\u3067\u3059\u306D",
  "id" : 531389923710861313,
  "created_at" : "2014-11-09 10:16:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531389454615715840",
  "text" : "\u8AB2\u984C\u306B\u5BFE\u3057\u3066\u624B\u304C\u52D5\u304B\u306A\u3044\u3053\u3068\u306E\u3057\u3093\u3069\u3055\u306A...",
  "id" : 531389454615715840,
  "created_at" : "2014-11-09 10:14:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531389386080780289",
  "text" : "@desole_mi \u3044\u3048\u30FC\uFF0C\u6708\u4E26\u307F\u306A\u3053\u3068\u3057\u304B\u8A00\u3048\u307E\u305B\u3093\u304C\uFF0C\u305D\u306E\u3064\u3089\u307F\u3068\u3066\u3082\u308F\u304B\u308A\u307E\u3059",
  "id" : 531389386080780289,
  "created_at" : "2014-11-09 10:14:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531388950712025088",
  "text" : "\u91C8\u8FE6\u306B\u8AAC\u6CD5\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2",
  "id" : 531388950712025088,
  "created_at" : "2014-11-09 10:12:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531388917509926912",
  "text" : "@desole_mi \u5206\u304B\u3063\u3066\u308B\u3053\u3068\u5206\u304B\u3089\u306A\u3044\u3053\u3068\u77E5\u308A\u305F\u3044\u3053\u3068\u307E\u3068\u3081\u305F\u3044\u3053\u3068\u7B49\u3005\u66F8\u304D\u51FA\u3057\u3066\u8089\u4ED8\u3051\u3057\u305F\u308A...\u3068\u304B\u3067\u3059\u304B\u306D\uFF08\u305D\u308C\u3053\u305D\u50D5\u3088\u308A\u305D\u306E\u3078\u3093\u306E\u30D7\u30ED\u30BB\u30B9\u306F\u8A73\u3057\u3044\u3067\u3057\u3087\u3046\u3057\u91C8\u8FE6\u306B\u8AAC\u6CD5\u611F\u3067\u3059\u304C\uFF09",
  "id" : 531388917509926912,
  "created_at" : "2014-11-09 10:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531388378323767298",
  "text" : "\u660E\u65E5\u3084\u308A\u307E\u3059",
  "id" : 531388378323767298,
  "created_at" : "2014-11-09 10:10:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531388364235087874",
  "text" : "\u660E\u65E5\u3084\u308D\u3046\u306F\u99AC\u9E7F\u91CE\u90CE\u3060",
  "id" : 531388364235087874,
  "created_at" : "2014-11-09 10:10:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531388248078036992",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u78BA\u8A8D\u306E\u3084\u308B\u6C17\u304C\u3067\u306A\u3044\uFF0E\u304A\u3046\u3061\u306B\u5E30\u3063\u3066\u3054\u98EF\u3092\u4F5C\u308B\uFF0E",
  "id" : 531388248078036992,
  "created_at" : "2014-11-09 10:10:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531388145548681218",
  "text" : "\u30D7\u30E9\u30F3A,B\u3068\u3042\u3063\u3066\u30D7\u30E9\u30F3A\u304C\u5B8C\u5168\u306B\u9813\u632B\u3057\u305F\u4ECAB\u3092\u78BA\u8A8D\u3057\u306A\u304D\u3083\u3044\u3051\u306A\u3044\u3093\u3060\u3051\u3069\uFF0CB\u3082\u9813\u632B\u3057\u305F\u3089\u8A70\u3080",
  "id" : 531388145548681218,
  "created_at" : "2014-11-09 10:09:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531387927960371200",
  "text" : "@desole_mi \u3068\u3066\u3082\u3088\u3044\u30D7\u30ED\u30BB\u30B9\u3060...",
  "id" : 531387927960371200,
  "created_at" : "2014-11-09 10:08:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531387799975378945",
  "text" : "\u5352\u8AD6\u88FD\u4F5C\u306B\u3042\u305F\u3063\u3066\uFF0Cemacs\u306B\u6163\u308C\u308B\u3053\u3068\u304C\u51FA\u6765\u305F\u306E\u306F\u5927\u304D\u306A\u53CE\u7A6B\u3067\u3042\u3063\u305F",
  "id" : 531387799975378945,
  "created_at" : "2014-11-09 10:08:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531387482919559168",
  "text" : "@desole_mi \u3042\u3068\u306F\u8EAB\u3092\u5207\u3089\u308C\u308B\u3088\u3046\u306A\u601D\u3044\u3092\u3057\u306A\u304C\u3089\u4EBA\u306B\u898B\u305B\u308B\u3053\u3068\u3067\u3059\u306D...",
  "id" : 531387482919559168,
  "created_at" : "2014-11-09 10:07:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531387363922964481",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 531387363922964481,
  "created_at" : "2014-11-09 10:06:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531387324253229056",
  "text" : "\u307E\u308F\u308A\u306E\u4EBA\u9593\u3068\u306E\u30A2\u30C9\u30D0\u30F3\u30C6\u30FC\u30B8\u304C\u3042\u308B\u3068\u3059\u308C\u3070\uFF0C\u8AD6\u6587\u4F5C\u6210\u306E\u30C6\u30F3\u30D7\u30EC\u7684\u306A\u4F5C\u6CD5\u7684\u306A\u90E8\u5206\u306B\u591A\u5C11\u306F\u901A\u3058\u3066\u3044\u308B\u3053\u3068\u3068\u2020\u95C7\u2020\u3092\u77E5\u3063\u3066\u3044\u308B\u3053\u3068\u304B\u306A",
  "id" : 531387324253229056,
  "created_at" : "2014-11-09 10:06:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531386942177280000",
  "text" : "\uFF08\u4FEE\u8AD6\u3067\u306F\u6B7B\u3092\u60F3\u8D77\u3057\u306A\u3044\u3088\u3046\u306B\u3057\u305F\u3044\uFF09",
  "id" : 531386942177280000,
  "created_at" : "2014-11-09 10:04:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531386835889430528",
  "text" : "\u5352\u8AD6\u306E\u9032\u6357\u3068\u304B\u6B7B\u3092\u60F3\u8D77\u3059\u308B",
  "id" : 531386835889430528,
  "created_at" : "2014-11-09 10:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531386699637477376",
  "text" : "@desole_mi \u50D5\u81EA\u8EAB\u306E\u7D4C\u9A13\u304B\u3089\u8A00\u3048\u308B\u3053\u3068\u3042\u3093\u307E\u308A\u306A\u3044\u306E\u3067\u3059\u304C\uFF0C\u8A00\u308F\u308C\u305F\u3053\u3068\u306F\u300C\u3068\u308A\u3042\u3048\u305A\u66F8\u304D\u3059\u3059\u3081\u308C\u3070\u4F55\u304B\u51FA\u3066\u304F\u308B\u300D\u300C\u76EE\u6B21\u3092\u4F5C\u6210\u3067\u304D\u308C\u30708\u5272\u306F\u7D42\u308F\u3063\u3066\u3044\u308B\u300D\u3067\u3059\u304B\u306D\uFF0E\u6587\u5316\u304C\u9055\u3046\u3067\u3057\u3087\u3046\u3057\u305D\u306E\u307E\u307E\u5F53\u3066\u306F\u307E\u308B\u304B\u306F\u5FAE\u5999\u3067\u3059\u304C\uFF0E",
  "id" : 531386699637477376,
  "created_at" : "2014-11-09 10:03:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531385908574953472",
  "text" : "@desole_mi \u3053\u306E\u6642\u671F\u306F\u305F\u3076\u3093\u6B7B\u306B\u305D\u3046\u306A\u308A\u306A\u304C\u3089\u6B7B\u3093\u3067\u307E\u3057\u305F\u306D\uFF0E\u50D5\u306F\u5B8C\u5168\u306B\u4E2D\u8EAB\u3082\u8A08\u753B\u306E\u7ACB\u3066\u65B9\u3082\u305A\u3055\u3093\u3060\u3063\u305F\u306E\u3067...",
  "id" : 531385908574953472,
  "created_at" : "2014-11-09 10:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531385366847053824",
  "text" : "@Kyo_Hiiragi \u305D\u306E\u3078\u3093\u3084\u3063\u3066\u305F\uFF08\u3084\u3063\u3066\u308B\uFF1F\uFF09\u3072\u3068\u77E5\u3063\u3066\u308B\u3051\u3069",
  "id" : 531385366847053824,
  "created_at" : "2014-11-09 09:58:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531385177029632000",
  "text" : "\u672C\u7B4B\u3068\u95A2\u4FC2\u306A\u3044\u4E8B\u9805\u304C\u6357\u308B\u6CD5\u5247",
  "id" : 531385177029632000,
  "created_at" : "2014-11-09 09:57:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531384938226929665",
  "text" : "\u3042\u30FC\uFF0C\u5BDD\u3066\u308B\u4EBA\u306D",
  "id" : 531384938226929665,
  "created_at" : "2014-11-09 09:56:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531384902801825795",
  "text" : "\u7121\u6148\u60B2\u3060\u304B\u3089\u96FB\u8ECA\u3067\u96A3\u306E\u4EBA\u304C\u3053\u3063\u3061\u306B\u5BC4\u308A\u304B\u304B\u308D\u3046\u3068\u3057\u305F\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u6025\u306B\u7ACB\u3061\u4E0A\u304C\u3063\u305F\u3053\u3068\u3042\u308B",
  "id" : 531384902801825795,
  "created_at" : "2014-11-09 09:56:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531384609221517312",
  "geo" : { },
  "id_str" : "531384657024000002",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u306B\u3052\u308B\u306E\u304C\u3068\u3066\u3082\u306F\u3084\u3044",
  "id" : 531384657024000002,
  "in_reply_to_status_id" : 531384609221517312,
  "created_at" : "2014-11-09 09:55:49 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531384359341654016",
  "geo" : { },
  "id_str" : "531384514258280449",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u3044\u3063\u305D\u307E\u3063\u305F\u304F\u4E0A\u624B\u304F\u884C\u304B\u306A\u3044\u65B9\u304C\uFF08\u6C17\u6301\u3061\u306E\u4E0A\u3067\u306F\uFF09\u697D\u306A\u3093\u3067\u3059\u3051\u3069\u306D",
  "id" : 531384514258280449,
  "in_reply_to_status_id" : 531384359341654016,
  "created_at" : "2014-11-09 09:55:15 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531384286499201024",
  "text" : "\u7D50\u69CB\u3044\u3044\u3068\u3053\u308D\u307E\u3067\u6765\u3066\u3044\u308B\uFF08\u306F\u305A\uFF09\u306A\u3093\u3060\u3051\u3069\u306A",
  "id" : 531384286499201024,
  "created_at" : "2014-11-09 09:54:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531384195394723840",
  "text" : "\u5B9A\u7FA9\u3057\u3066\u306Fill-defined\u3092\u78BA\u8A8D\u3057\u3066\u307E\u305F\u5B9A\u7FA9\u3057\u3066\u3092\u7E70\u308A\u8FD4\u3059\u4F5C\u696D\uFF0C\u7A74\u3092\u6398\u3063\u3066\u57CB\u3081\u3066\u307E\u305F\u7A74\u3092\u6398\u3063\u3066\u57CB\u3081\u308B\u4F5C\u696D\u306B\u4F3C\u3066\u3044\u308B",
  "id" : 531384195394723840,
  "created_at" : "2014-11-09 09:53:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531368780752891904",
  "text" : "Skypoyo",
  "id" : 531368780752891904,
  "created_at" : "2014-11-09 08:52:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531368702197760000",
  "text" : "\u65E9\u3081\u306B\u304B\u3048\u3063\u3066Skepoyo\u3068\u304B\u3059\u308B\u304B",
  "id" : 531368702197760000,
  "created_at" : "2014-11-09 08:52:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531368574913216512",
  "text" : "\u4E00\u65E5\u306E\u6700\u4F4E\u767A\u8A71\u91CF\u3092\u4E0B\u56DE\u308A\u305D\u3046\u3067\u3064\u3089\u3044",
  "id" : 531368574913216512,
  "created_at" : "2014-11-09 08:51:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531359407641092096",
  "text" : "\u30EC\u30C8\u30ED\u30B9\u30DA\u30AF\u30C6\u30A3\u30D6\u672D\u5E4C\u3063\u3066\u306A\u3093\u304B\u3042\u3063\u305F\u3088\u306D",
  "id" : 531359407641092096,
  "created_at" : "2014-11-09 08:15:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531359335788457984",
  "text" : "\u30EC\u30C8\u30ED\u30B9\u30DA\u30AF\u30C6\u30A3\u30D6\u4EAC\u90FD",
  "id" : 531359335788457984,
  "created_at" : "2014-11-09 08:15:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531357503489990656",
  "text" : "\u307B\u308D\u3073\u306E\u3068\u304D\u306F\u3061\u304B\u3044",
  "id" : 531357503489990656,
  "created_at" : "2014-11-09 08:07:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531347992121327616",
  "text" : "\u304A\u8336\u3067\u304A\u8336\u3092\u6FC1\u3059",
  "id" : 531347992121327616,
  "created_at" : "2014-11-09 07:30:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531347956113235969",
  "text" : "\u3053\u306E\u6642\u9593\u306B\u98F2\u3093\u3060\u3089\u30C0\u30E1\u306A\u6C17\u304C\u3059\u308B\u3051\u3069\u30B3\u30FC\u30D2\u30FC\u98F2\u307F\u305F\u3044...",
  "id" : 531347956113235969,
  "created_at" : "2014-11-09 07:29:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531343894651211776",
  "text" : "\u96FB\u6C17\u3064\u3051\u308B\u304B...",
  "id" : 531343894651211776,
  "created_at" : "2014-11-09 07:13:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531343754813124608",
  "text" : "\u3044\u308B\u3068\u304D\u306B\u96FB\u6C17\u6D88\u3057\u3066\u3044\u306A\u3044\u3068\u304D\u306B\u96FB\u6C17\u3064\u3051\u3063\u3071\u4EBA\u9593\u306A\u3093\u3060\u3051\u3069\uFF0C\u3053\u306E\u6642\u9593\u3067\u65E2\u306B\u3060\u3044\u3076\u6697\u3044",
  "id" : 531343754813124608,
  "created_at" : "2014-11-09 07:13:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531341567051567104",
  "text" : "\u3042\u308C\u30FC\u306A\u3093\u3060\u3063\u3051\uFF0E",
  "id" : 531341567051567104,
  "created_at" : "2014-11-09 07:04:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531341481844301824",
  "text" : "Una Nancy Owen",
  "id" : 531341481844301824,
  "created_at" : "2014-11-09 07:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/BmNXFga2UV",
      "expanded_url" : "http:\/\/recipe.rakuten.co.jp\/recipe\/1050008952\/",
      "display_url" : "recipe.rakuten.co.jp\/recipe\/1050008\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531332199790825472",
  "text" : "memomemo http:\/\/t.co\/BmNXFga2UV",
  "id" : 531332199790825472,
  "created_at" : "2014-11-09 06:27:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531319561262346240",
  "text" : "\uFF72\uFF72\uFF8A\uFF85\uFF7C",
  "id" : 531319561262346240,
  "created_at" : "2014-11-09 05:37:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C7\u30A4\u30EA\u30FCTOCANA",
      "screen_name" : "tocanailand",
      "indices" : [ 3, 15 ],
      "id_str" : "1724723306",
      "id" : 1724723306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/tOzFgqLI9z",
      "expanded_url" : "http:\/\/tocana.jp\/2014\/11\/post_5155.html",
      "display_url" : "tocana.jp\/2014\/11\/post_5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531319529700216832",
  "text" : "RT @tocanailand: \u300C\u516C\u5B89\u3092\u8210\u3081\u308B\u306A\u300D\u5143\u8B66\u8996\u5E81\u5211\u4E8B\u304C\u3001\u30A4\u30B9\u30E9\u30E0\u56FD\u9A12\u52D5\u5317\u5927\u751F\u3001\u4EAC\u5927\u62D8\u675F\u9A12\u52D5\u306B\u53CD\u8AD6\uFF01 http:\/\/t.co\/tOzFgqLI9z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tocana.jp\/\" rel=\"nofollow\"\u003EtocanaBot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/tOzFgqLI9z",
        "expanded_url" : "http:\/\/tocana.jp\/2014\/11\/post_5155.html",
        "display_url" : "tocana.jp\/2014\/11\/post_5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531223395078127616",
    "text" : "\u300C\u516C\u5B89\u3092\u8210\u3081\u308B\u306A\u300D\u5143\u8B66\u8996\u5E81\u5211\u4E8B\u304C\u3001\u30A4\u30B9\u30E9\u30E0\u56FD\u9A12\u52D5\u5317\u5927\u751F\u3001\u4EAC\u5927\u62D8\u675F\u9A12\u52D5\u306B\u53CD\u8AD6\uFF01 http:\/\/t.co\/tOzFgqLI9z",
    "id" : 531223395078127616,
    "created_at" : "2014-11-08 23:15:01 +0000",
    "user" : {
      "name" : "\u30C7\u30A4\u30EA\u30FCTOCANA",
      "screen_name" : "tocanailand",
      "protected" : false,
      "id_str" : "1724723306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000679097008\/0ce51b14e25a26303007f341f8cb043d_normal.jpeg",
      "id" : 1724723306,
      "verified" : false
    }
  },
  "id" : 531319529700216832,
  "created_at" : "2014-11-09 05:37:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531317726841540609",
  "text" : "\u8AB0\u304BBleach\u306E\n\u5589\u304C\u4E7E\u304F\uFF0D\u30FC\u30FC\n\u306E\u753B\u50CF\u304F\u3060\u3055\u3044",
  "id" : 531317726841540609,
  "created_at" : "2014-11-09 05:29:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531316517409787904",
  "text" : "\u304A\u308D\u304B\u306A\u4EBA\u9593\u306E\u65B9\u304C\u201D\u4F7F\u3048\u308B\u201D\u4EBA\u6750\u306A\u3093\u3060\u308D\u3046\u306A\u30FC\u3063\u3066",
  "id" : 531316517409787904,
  "created_at" : "2014-11-09 05:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531305771460333569",
  "text" : "\u30A8\u30DC\u30E9\u611F\u67D3\u8005\u306E\u3053\u3068\u30A8\u30DC\u30E9\u30FC\u3063\u3066\u547C\u3076\u306E\u3084\u3081\u306A\u3055\u3044",
  "id" : 531305771460333569,
  "created_at" : "2014-11-09 04:42:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531298859733893120",
  "text" : "\u30B5\u30D6\u30DE\u30EA\u30F3\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u30A4\u30F3\u30E6\u30A2\u30A6\u30A7\u30A4",
  "id" : 531298859733893120,
  "created_at" : "2014-11-09 04:14:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531297347381116928",
  "geo" : { },
  "id_str" : "531297590185168896",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u3042\u308A\u305D\u3046\u2026",
  "id" : 531297590185168896,
  "in_reply_to_status_id" : 531297347381116928,
  "created_at" : "2014-11-09 04:09:51 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531287156057067520",
  "text" : "\u5319\u306F\u6295\u3052\u3089\u308C\u305F",
  "id" : 531287156057067520,
  "created_at" : "2014-11-09 03:28:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531034859704037377",
  "text" : "\u308A\u3093\u3054\u3088\u308A\u306A\u3057\u304C\u597D\u304D",
  "id" : 531034859704037377,
  "created_at" : "2014-11-08 10:45:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531033491601772544",
  "text" : "\u3082\u3057\u304B\u3057\u3066\uFF1A\u706B\u306E\u524D\u306B\u306F\u7121\u529B",
  "id" : 531033491601772544,
  "created_at" : "2014-11-08 10:40:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531032996216729601",
  "text" : "\u5B89\u85E4\u308A\u3093\u3054",
  "id" : 531032996216729601,
  "created_at" : "2014-11-08 10:38:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531031875901325312",
  "text" : "\u96FB\u5B50\u30EC\u30F3\u30B8\u306B\u304A\u5BFF\u53F8\u3068\u304B\u5192\u6D9C\u7684\u3059\u304E\u308B...",
  "id" : 531031875901325312,
  "created_at" : "2014-11-08 10:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531030843225944064",
  "text" : "\u30A8\u30D3\u3068\u304B\u8A00\u3046\u751F\u304D\u7269\u4EBA\u9593\u304C\u98DF\u3079\u308B\u305F\u3081\u306B\u751F\u307E\u308C\u305F\u3068\u3057\u304B\u601D\u3048\u306A\u3044",
  "id" : 531030843225944064,
  "created_at" : "2014-11-08 10:29:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530878674375933952",
  "text" : "\u3093\u3042\u30FC( \u00B4_\u309D\uFF40)",
  "id" : 530878674375933952,
  "created_at" : "2014-11-08 00:25:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530671772660543489",
  "text" : "\u30CD\u30AE\u30C6\u30E3\u30A1\u30FC\u30CF\u30F3",
  "id" : 530671772660543489,
  "created_at" : "2014-11-07 10:43:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530594851784781825",
  "text" : "\u8FF8\u308B\u30DD\u30FC\u30C1\u30C9\u30A8\u30C3\u30B0\u98DF\u3079\u305F\u3055",
  "id" : 530594851784781825,
  "created_at" : "2014-11-07 05:37:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530570496882929664",
  "geo" : { },
  "id_str" : "530590676967120899",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u8A00\u3046\u6A29\u5229\u306F\u3042\u308B",
  "id" : 530590676967120899,
  "in_reply_to_status_id" : 530570496882929664,
  "created_at" : "2014-11-07 05:20:49 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530570254053683200",
  "text" : "\u3042\u30FC",
  "id" : 530570254053683200,
  "created_at" : "2014-11-07 03:59:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530570241491738624",
  "text" : "\u3042\u30FC\u3063\u3066\u3044\u3046\u306E\u306F\u56FD\u6C11\u5168\u54E1\u306B\u5E73\u7B49\u306B\u4E0E\u3048\u3089\u308C\u305F\u6A29\u5229\u3060\u304B\u3089\u306A\uFF0C\u4ECA\u65E5\u3082\u80F8\u3092\u5F35\u3063\u3066\u3042\u30FC\u3063\u3066\u8A00\u304A\u3046",
  "id" : 530570241491738624,
  "created_at" : "2014-11-07 03:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530544865549893632",
  "text" : "\u3053\u30FC\u3072\u30FC\u306E\u304A\u3044\u3057\u3055",
  "id" : 530544865549893632,
  "created_at" : "2014-11-07 02:18:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530538718386733057",
  "text" : "\u30AD\u30CE\u30B3\u306E\u30DD\u30BF\u30FC\u30B8\u30E5\u3067\u30C9\u30A4\u30C4\u98DF\u30D1\u30F3\u98DF\u3079\u308B\u671D\u3054\u306F\u3093",
  "id" : 530538718386733057,
  "created_at" : "2014-11-07 01:54:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/RMtQN5kvIm",
      "expanded_url" : "http:\/\/www.geocities.jp\/tomoatomi\/raira0001.htm",
      "display_url" : "geocities.jp\/tomoatomi\/rair\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530398092789420033",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u7A7A http:\/\/t.co\/RMtQN5kvIm",
  "id" : 530398092789420033,
  "created_at" : "2014-11-06 16:35:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530392247791931393",
  "text" : "\u30AD\u30C3\u30C1\u30F3\u3054\u308A\u3089\u306E\u30AB\u30EC\u30FC\u304C\u7F8E\u5473\u3057\u304F\u306A\u3044\u8A33\u304C\u306A\u3044",
  "id" : 530392247791931393,
  "created_at" : "2014-11-06 16:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530391514682097664",
  "text" : "\u30AD\u30C3\u30C1\u30F3\u3054\u308A\u3089\u3001\u5C0A\u3044",
  "id" : 530391514682097664,
  "created_at" : "2014-11-06 16:09:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530390903886602240",
  "text" : "\u3068\u308A\u3042\u3048\u305APL\u3068\u3057\u3066\u4F55\u56DE\u304B\u3084\u3063\u305F\u5F8C\u306BKP\u3092\u3084\u3063\u3066\u307F\u305F\u3044\u3082\u306E\u3060",
  "id" : 530390903886602240,
  "created_at" : "2014-11-06 16:07:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530390771174612993",
  "text" : "\u3084\u3063\u3071TRPG\u3084\u3063\u3066\u307F\u305F\u3044\u611F\u3060",
  "id" : 530390771174612993,
  "created_at" : "2014-11-06 16:06:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530390428416098305",
  "text" : "\u5373\u8208\u5287\u3092\u6210\u305B\u308B\u4EBA\u306B\u306A\u308A\u305F\u3044\u3001\u30A2\u30C9\u30EA\u30D6\u4EBA\u9593\u306B\u3002(\u307E\u305A\u306F\u771F\u9854\u3060)",
  "id" : 530390428416098305,
  "created_at" : "2014-11-06 16:05:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530389994209165312",
  "text" : "\u9762\u767D\u3051\u308C\u3070\u8A31\u3055\u308C\u308B",
  "id" : 530389994209165312,
  "created_at" : "2014-11-06 16:03:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530389396910903298",
  "geo" : { },
  "id_str" : "530389616868593664",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 (\u8AD6\u7406\u7684\u306B\u306F)\u5426\u5B9A\u51FA\u6765\u306A\u304F\u3066\u6B7B\u306C",
  "id" : 530389616868593664,
  "in_reply_to_status_id" : 530389396910903298,
  "created_at" : "2014-11-06 16:01:53 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530389091167129600",
  "text" : "\u4E3B\u4EBA\u516C\u304C\u6B7B\u306C\u3068\u3053\u308D\u304B\u3089\u59CB\u307E\u308B\u6F2B\u753B\u3001\u5370\u8C61\u6DF1\u3044\u5370\u8C61\u304C\u6DF1\u3044(\u30B5\u30F3\u30D7\u30EB\u4E8C\u3064\u306A)",
  "id" : 530389091167129600,
  "created_at" : "2014-11-06 15:59:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530388586139381760",
  "geo" : { },
  "id_str" : "530388667198496770",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u305D\u3046\u305D\u3046\u3001\u305D\u308C\u3067\u3059\u305D\u308C\u3067\u3059",
  "id" : 530388667198496770,
  "in_reply_to_status_id" : 530388586139381760,
  "created_at" : "2014-11-06 15:58:07 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530388565436284928",
  "text" : "\u6297\u3044\u3088\u3046\u304C\u306A\u3044\u611F\u3058",
  "id" : 530388565436284928,
  "created_at" : "2014-11-06 15:57:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530388361664397312",
  "text" : "\u73FE\u5B9F\u306F\u30DB\u30E9\u30FC",
  "id" : 530388361664397312,
  "created_at" : "2014-11-06 15:56:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530388172484509696",
  "text" : "@desole_mi \u30A2\u30A4\u30A8\u30A8\u30A8\u2026",
  "id" : 530388172484509696,
  "created_at" : "2014-11-06 15:56:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530387959418064896",
  "geo" : { },
  "id_str" : "530388118134743041",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary GPS",
  "id" : 530388118134743041,
  "in_reply_to_status_id" : 530387959418064896,
  "created_at" : "2014-11-06 15:55:56 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530388055287271424",
  "text" : "@desole_mi \u305D\u3044\u3046\u3048\u3070\u8A00\u308F\u308C\u3066\u8ABF\u3079\u3066\u3057\u3070\u3089\u304F\u8AAD\u3093\u3060\u3051\u3069\u305D\u3053\u306F\u304B\u3068\u306A\u3044\u30DB\u30E9\u30FC\u611F\u304C\u826F\u3044\u3067\u3059\u306D\uFF1F",
  "id" : 530388055287271424,
  "created_at" : "2014-11-06 15:55:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530387691649507328",
  "text" : "\u307E\u3041\u500B\u4EBA\u3092\u6307\u6A19\u306B\u306F\u3057\u306A\u3044\u3051\u3069\u306D",
  "id" : 530387691649507328,
  "created_at" : "2014-11-06 15:54:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530387613052444672",
  "text" : "\u50D5\u306FTL\u306E\u30A2\u30EC\u306A\u611F\u3058\u306E\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u3068\u304B\u3057\u3087\u3046\u3082\u306A\u3044RT\u3068\u304B\u306B\u30A4\u30E9\u3063\u3068\u6765\u305F\u3089\u75B2\u308C\u3066\u308B\u306A\u3041\u3063\u3066\u601D\u3046\u304B\u3089\u307E\u3041\u81EA\u8EAB\u306E\u72B6\u614B\u306E\u6307\u6A19\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u3092\u4F7F\u3046\u306E\u3092\u5F37\u304F\u5426\u5B9A\u51FA\u6765\u306A\u3044\u306A\uFF1F",
  "id" : 530387613052444672,
  "created_at" : "2014-11-06 15:53:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530386948309794816",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u306E\u30C4\u30A4\u30FC\u30C8\u3001\u7279\u5FB4\u304C\u3042\u308B\u8AAC\u304C\u3042\u308B\u306A\u3001\u3044\u3046\u306A\u308C\u3070\u3001\u3048\u3093\u3069\u3055\u3093\u306E\u30C4\u30A4\u30FC\u30C8\u307F\u305F\u3044\u306A\u611F\u3058\u2026",
  "id" : 530386948309794816,
  "created_at" : "2014-11-06 15:51:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530386439406505987",
  "geo" : { },
  "id_str" : "530386751064252416",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u50D5\u3092\u6307\u6A19\u306B\u3059\u308B\u306E\u3084\u3081\u3066\u8CB0\u3048\u307E\u3059\u304B(\u771F\u9854)",
  "id" : 530386751064252416,
  "in_reply_to_status_id" : 530386439406505987,
  "created_at" : "2014-11-06 15:50:30 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530386643136413696",
  "text" : "\u3088\u308D\u3057\u304F\u304A\u3064\u305F\u3048\u304F\u3060\u3057\u3042",
  "id" : 530386643136413696,
  "created_at" : "2014-11-06 15:50:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530385778061230080",
  "geo" : { },
  "id_str" : "530386002594906112",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u66F0\u304F\u3001\u8C5A\u8089\u306F\u91CE\u83DC\u306E\u56FD\u306B\u5E30\u5316\u3057\u305F\u5916\u56FD\u4EBA\u9078\u624B\u3067\u3001\u30BF\u30F3\u30E1\u30F3\u306B\u5165\u308B\u8C5A\u8089\u306F\u3001\u3082\u306F\u3084\u91CE\u83DC\u3067\u3042\u308B\u3001\u307F\u305F\u3044\u306A\u8A71\u3060\u3063\u305F(\u4F1D\u308F\u308C)",
  "id" : 530386002594906112,
  "in_reply_to_status_id" : 530385778061230080,
  "created_at" : "2014-11-06 15:47:31 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530385510204592129",
  "text" : "\u30B3\u30ED\u30C3\u30B1\u304C\u558B\u308B\u843D\u8A9E\u306E\u6795\u306F\u5B58\u5728\u3059\u308B",
  "id" : 530385510204592129,
  "created_at" : "2014-11-06 15:45:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530385349004914690",
  "text" : "\u50D5\u306F\u7261\u8823\u306B\u306F\u76EE\u304C\u306A\u3044\u3051\u3069\u7261\u8823\u306B\u306F\u76EE\u304C\u306A\u3044\u3093\u3060\u3088\u306A",
  "id" : 530385349004914690,
  "created_at" : "2014-11-06 15:44:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530385145589555200",
  "text" : "\u5C11\u306A\u304F\u3068\u3082\u8C5A\u8089\u306F\u558B\u308B(\u305F\u3060\u3057\u3055\u3044\u305F\u307E\u306B\u8089\u306F\u306A\u3044)",
  "id" : 530385145589555200,
  "created_at" : "2014-11-06 15:44:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530384783465914368",
  "geo" : { },
  "id_str" : "530385034771849216",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u306E\u4F5C\u8005\u304C\u66F8\u3044\u305F\u30A8\u30C3\u30BB\u30A4\u306B\u30BF\u30F3\u30E1\u30F3\u306E\u8A71\u304C\u3042\u3063\u3066\u3001\u30BF\u30F3\u30E1\u30F3\u306B\u3044\u308C\u308B\u524D\u306E\u91CE\u83DC\u3068\u8C5A\u8089\u304C\u304A\u3057\u3083\u3079\u308A\u3057\u3066\u308B\u30B7\u30FC\u30F3\u304C\u3042\u3063\u305F\u3088\uFF01",
  "id" : 530385034771849216,
  "in_reply_to_status_id" : 530384783465914368,
  "created_at" : "2014-11-06 15:43:41 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530384626619932673",
  "geo" : { },
  "id_str" : "530384817347895297",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u30D2\u30F3\u30C8:\u7261\u8823\u306B\u306F\u76EE\u304C\u306A\u3044",
  "id" : 530384817347895297,
  "in_reply_to_status_id" : 530384626619932673,
  "created_at" : "2014-11-06 15:42:49 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530384331252838400",
  "text" : "\u30D2\u30F3\u30C8:\u7261\u8823\u306F\u558B\u3089\u306A\u3044",
  "id" : 530384331252838400,
  "created_at" : "2014-11-06 15:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530384216584777728",
  "text" : "\u7261\u8823\u306E\u3053\u3068\u306F\u5927\u597D\u304D\u3060\u3051\u308C\u3069\u3001\u7261\u8823\u304C\u50D5\u306E\u3053\u3068\u3092\u597D\u304D\u304B\u3069\u3046\u304B\u306F\u5206\u304B\u3089\u306A\u3044\u304B\u3089\u306A\u3041(\u7261\u8823\u3068\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u3092\u53D6\u308B\u306E\u306F\u3068\u3066\u3082\u96E3\u3057\u3044)",
  "id" : 530384216584777728,
  "created_at" : "2014-11-06 15:40:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530383495453892609",
  "text" : "\u6804\u990A\u4FA1\u3068\u304B\u5165\u624B\u7D4C\u8DEF\u3068\u304B\u4E00\u5207\u306A\u3093\u306B\u3082\u8003\u616E\u305B\u305A\u306B\u3044\u3046\u3051\u3069\u6BCE\u65E5\u7261\u8823\u3060\u3051\u98DF\u3079\u3066\u751F\u304D\u305F\u3044",
  "id" : 530383495453892609,
  "created_at" : "2014-11-06 15:37:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530383238993166337",
  "text" : "\u666E\u6BB5\u304B\u3089\u7261\u8823\u98DF\u3079\u305F\u3044\u3068\u601D\u3044\u306A\u304C\u3089\u751F\u6D3B\u3057\u3066\u308B\u3057\u7261\u8823\u306E\u753B\u50CF\u3092\u307F\u305F\u7A0B\u5EA6\u3067\u6539\u3081\u3066\u7261\u8823\u3092\u98DF\u3079\u305F\u304F\u306A\u3063\u305F\u308A\u306F\u3057\u306A\u3044(\u3064\u3088\u3044)",
  "id" : 530383238993166337,
  "created_at" : "2014-11-06 15:36:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530382681272381440",
  "text" : "yassu\u541B\u306E\u30EA\u30D7\u30E9\u30A4\u3001\u5927\u62B5\u5618\u306F\u8A00\u3063\u3066\u306A\u3044\u3060\u3051\u3067\u7684\u5916\u308C\u306A\u2026",
  "id" : 530382681272381440,
  "created_at" : "2014-11-06 15:34:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530381878881050625",
  "geo" : { },
  "id_str" : "530382423050031105",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u6587\u8108\u3067\u8003\u3048\u308D",
  "id" : 530382423050031105,
  "in_reply_to_status_id" : 530381878881050625,
  "created_at" : "2014-11-06 15:33:18 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530381512248549376",
  "geo" : { },
  "id_str" : "530381664069746688",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u305D\u308C\u306A(\uFF84\uFF9E\uFF94",
  "id" : 530381664069746688,
  "in_reply_to_status_id" : 530381512248549376,
  "created_at" : "2014-11-06 15:30:17 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530381475124756480",
  "text" : "\u8FD4\u7B54\u306E\u6709\u7121\u306B\u95A2\u308F\u3089\u305A\u4F1A\u8A71\u3092\u3054\u308A\u62BC\u3057\u3059\u308B\u306E\u3001\u9762\u767D\u304F\u306A\u304B\u3063\u305F\u3089\u5730\u7344\u3060\u304C\u9762\u767D\u3044\u3068\u3044\u3046\u4E00\u70B9\u3067\u306E\u307F\u8A31\u3055\u308C\u308B\u884C\u70BA\u3060",
  "id" : 530381475124756480,
  "created_at" : "2014-11-06 15:29:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530381259478814720",
  "text" : "\"\u65E5\u9803\u306E\u884C\u3044\u30E1\u30BD\u30C3\u30C9\"\u3068\"\u5FC3\u304C\u6C5A\u3044\u4EBA\u30E1\u30BD\u30C3\u30C9\"\u306F\u4FBF\u5229",
  "id" : 530381259478814720,
  "created_at" : "2014-11-06 15:28:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530380610934562816",
  "text" : "\u3069\u3063\u3061\u3082\u30A2\u30EC\u3060\u3063\u305F",
  "id" : 530380610934562816,
  "created_at" : "2014-11-06 15:26:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530380570006540288",
  "text" : "\u53CB\u4EBA\u300C\u7720\u3044\u306A\u2026\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u65E5\u9803\u306E\u884C\u3044\u3067\u306F\uFF1F\u300D",
  "id" : 530380570006540288,
  "created_at" : "2014-11-06 15:25:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530380482374930432",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u300C\u7720\u3044\u306A\u2026\u300D\n\u53CB\u4EBA\u300C\u7720\u3044\u306E\u306F\u4F55\u306E\u305B\u3044\u3060\u3068\u601D\u3046\uFF1F\u300D\n\u53CB\u4EBA\u300C\u5996\u301C\u602A\u306E\u301C\u301C\uFF01\u305B\u3044\u306A\u306E\u306D\uFF01(\u305D\u3046\u306A\u306E\u306D\uFF01)\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u300D",
  "id" : 530380482374930432,
  "created_at" : "2014-11-06 15:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530380108775714816",
  "text" : "\u9662\u751F\u5BA4\u306E\u5F8C\u308D\u306E\u53CB\u4EBA\u304C\u5996\u602A\u30A6\u30A9\u30C3\u30C1\u306EOP\u306E\u602A\u7570\u306B\u53D6\u308A\u6191\u304B\u308C\u3066\u305F\u306A\u2026",
  "id" : 530380108775714816,
  "created_at" : "2014-11-06 15:24:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530321794050183171",
  "text" : "\u3042\u30FC",
  "id" : 530321794050183171,
  "created_at" : "2014-11-06 11:32:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530312488072409090",
  "text" : "\u50D5\u306F\u91CE\u83DC\u985E\u3092\u304F\u305F\u304F\u305F\u306B\u306A\u308B\u307E\u3067\u706B\u3092\u901A\u3059\u306E\u304C\u7D50\u69CB\u597D\u304D\u306A\u306E\u3067",
  "id" : 530312488072409090,
  "created_at" : "2014-11-06 10:55:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530312381016981505",
  "text" : "\u4E00\u4EBA\u934B\u3001\u826F\u3055\u304C\u3042\u308B\u3088\u306D",
  "id" : 530312381016981505,
  "created_at" : "2014-11-06 10:54:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530310973395988480",
  "text" : "\u8377\u7269\u304C\u5C4A\u304B\u306A\u3044\u3068\u304A\u98A8\u5442\u306F\u3044\u308C\u306A\u3044\uFF87\uFF70\uFF9D",
  "id" : 530310973395988480,
  "created_at" : "2014-11-06 10:49:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530309907208101888",
  "text" : "NF\u524D\u591C\u796D\u934B\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B",
  "id" : 530309907208101888,
  "created_at" : "2014-11-06 10:45:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530293893204422656",
  "text" : "\u30DD\u30FC\u30AF\u30D4\u30BF\u30AB",
  "id" : 530293893204422656,
  "created_at" : "2014-11-06 09:41:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530278021849047040",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u307F\u305F\u3044\u306A\u30B4\u30DF\u3082\u5358\u4F4D\u304C\u78BA\u5B9A\u3059\u308C\u3070\u30B4\u30DF\u307F\u305F\u3044\u306A\u30EC\u30DD\u30FC\u30C8\u306B\u30B8\u30E7\u30D6\u30C1\u30A7\u30F3\u30B8\u3059\u308B\u3058\u3083\u3093\uFF1F",
  "id" : 530278021849047040,
  "created_at" : "2014-11-06 08:38:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530277584102121473",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u3092\u3084\u3063\u3064\u3051\u3067\u3084\u3063\u3064\u3051\u305F\uFF08\u3084\u3063\u3064\u3051\u305F\uFF09",
  "id" : 530277584102121473,
  "created_at" : "2014-11-06 08:36:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530212184215666688",
  "text" : "\u4E94\u5104\u5E74\u3082\u7881\u77F3\u3092\u7F6E\u304F\u3060\u3051\u306E\u5358\u8ABF\u4F5C\u696D\u3092\u7D9A\u3051\u305F\u3089SAN\u5024\u524A\u308A\u5207\u3063\u3066\u767A\u72C2\u3059\u308B",
  "id" : 530212184215666688,
  "created_at" : "2014-11-06 04:16:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530210627772379137",
  "geo" : { },
  "id_str" : "530211863384977408",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u7881\u77F3\u304C\u3044\u3063\u3071\u3044\u5FC5\u8981\u3067\u3059\u306D",
  "id" : 530211863384977408,
  "in_reply_to_status_id" : 530210627772379137,
  "created_at" : "2014-11-06 04:15:33 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530205781962936320",
  "geo" : { },
  "id_str" : "530206126092996608",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u4E94\u5104\u5E74\u3068\u3044\u3046\u9577\u3044\u6B73\u6708\u304C\u904E\u304E\u2026\u305D\u3057\u3066\u3001\u591C\u304C\u660E\u3051\u305F\uFF01",
  "id" : 530206126092996608,
  "in_reply_to_status_id" : 530205781962936320,
  "created_at" : "2014-11-06 03:52:45 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530205478257573888",
  "text" : "\u7D75\u6587\u5B57\u3068\u304B\u3044\u3046\u3084\u3064\u4E94\u5104\u5E74\u3076\u308A\u306B\u4F7F\u3063\u305F",
  "id" : 530205478257573888,
  "created_at" : "2014-11-06 03:50:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u3063\u3077\u3059\uFF1D\u3080\u304E\u3085\u305F\u3093",
      "screen_name" : "Pappus_Mugyutan",
      "indices" : [ 0, 16 ],
      "id_str" : "2423639766",
      "id" : 2423639766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530205231330516993",
  "geo" : { },
  "id_str" : "530205408745365504",
  "in_reply_to_user_id" : 2423639766,
  "text" : "@Pappus_Mugyutan \u6B21\u306F0\u30F6\u6708\u5206\u3067\u6E08\u3080\u3088\u3046\u306B\u304C\u3093\u3070\u308C\uD83D\uDC4A",
  "id" : 530205408745365504,
  "in_reply_to_status_id" : 530205231330516993,
  "created_at" : "2014-11-06 03:49:54 +0000",
  "in_reply_to_screen_name" : "Pappus_Mugyutan",
  "in_reply_to_user_id_str" : "2423639766",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u3063\u3077\u3059\uFF1D\u3080\u304E\u3085\u305F\u3093",
      "screen_name" : "Pappus_Mugyutan",
      "indices" : [ 0, 16 ],
      "id_str" : "2423639766",
      "id" : 2423639766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530204923011420163",
  "geo" : { },
  "id_str" : "530205010332635136",
  "in_reply_to_user_id" : 2423639766,
  "text" : "@Pappus_Mugyutan \u5727\u529B\u306B\u5C48\u3057\u3066\u3057\u307E\u3063\u305F\u304B\u2026",
  "id" : 530205010332635136,
  "in_reply_to_status_id" : 530204923011420163,
  "created_at" : "2014-11-06 03:48:19 +0000",
  "in_reply_to_screen_name" : "Pappus_Mugyutan",
  "in_reply_to_user_id_str" : "2423639766",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u3063\u3077\u3059\uFF1D\u3080\u304E\u3085\u305F\u3093",
      "screen_name" : "Pappus_Mugyutan",
      "indices" : [ 0, 16 ],
      "id_str" : "2423639766",
      "id" : 2423639766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530204525458513920",
  "geo" : { },
  "id_str" : "530204768925265920",
  "in_reply_to_user_id" : 2423639766,
  "text" : "@Pappus_Mugyutan \u4E00\u30F6\u6708\u306E\u652F\u51FA\u3067\u6700\u3082\u5927\u304D\u304F\u78BA\u5B9F\u306B\u6301\u3063\u3066\u3044\u304B\u308C\u3061\u3083\u3046\u306E\u304C\u5BB6\u8CC3\u3060\u304B\u3089\u3001\u5BB6\u8CC3\u3055\u3048\u6211\u6162\u3067\u304D\u308C\u3070\u304B\u306A\u308A\u8D05\u6CA2\u3067\u304D\u308B\u3068\u601D\u3046\u3093\u3060\u3088\u306D",
  "id" : 530204768925265920,
  "in_reply_to_status_id" : 530204525458513920,
  "created_at" : "2014-11-06 03:47:22 +0000",
  "in_reply_to_screen_name" : "Pappus_Mugyutan",
  "in_reply_to_user_id_str" : "2423639766",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530202203282079745",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 530202203282079745,
  "created_at" : "2014-11-06 03:37:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530202135187558400",
  "text" : "\u79C1\u3001\u3042\u3052\u3089\u308C\u308B\u7269\u304C\u306A\u3044\u304B\u3089\u3001\u706B\u3092\u3064\u3051\u308B\u3088\uFF01",
  "id" : 530202135187558400,
  "created_at" : "2014-11-06 03:36:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530201264907231232",
  "text" : "\u5BB6\u8CC3\u6211\u61627\u7D1A\u3060\u304B\u3089\u6BCE\u6708\u6255\u3063\u3061\u3083\u3046",
  "id" : 530201264907231232,
  "created_at" : "2014-11-06 03:33:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530201107146870786",
  "text" : "\u3080\u304E\u3085\u305F\u3093\u4E8C\u30F6\u6708\u3082\u5BB6\u8CC3\u6211\u6162\u3057\u3066\u308B\u306E",
  "id" : 530201107146870786,
  "created_at" : "2014-11-06 03:32:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530198581873872896",
  "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u306F\u3088\u304F\u3042\u308B\u3053\u3068\u3060\u3051\u3069\u3001\u53E4\u3044\u30CD\u30BF\u3092\u3042\u305F\u304B\u3082\u65B0\u3057\u3044\u304B\u306E\u3088\u3046\u306B\u7D39\u4ECB\u3057\u3066\u308B\u3060\u3051\u306E\u30C4\u30A4\u30FC\u30C8\u304C\u4F55\u5343RT\u3068\u304B\u3055\u308C\u3066\u308B\u306E\u3092\u307F\u308B\u3068\u306A\u3093\u3068\u3082\u8A00\u3048\u306A\u3044\u5FC3\u5730\u304C\u3059\u308B",
  "id" : 530198581873872896,
  "created_at" : "2014-11-06 03:22:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530194115640578048",
  "text" : "\u5DE6\u80A9\u4EA4\u63DB\u30B5\u30FC\u30D3\u30B9",
  "id" : 530194115640578048,
  "created_at" : "2014-11-06 03:05:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530190648612102144",
  "text" : "\u5DE6\u80A9\u304C\u3046\u3049\u30A9\u30F3",
  "id" : 530190648612102144,
  "created_at" : "2014-11-06 02:51:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529828823026503680",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC \u30BB\u30DF\u30CA\u30FC \u30A4\u30F3 \u30D5\u30EC\u30A4\u30E0",
  "id" : 529828823026503680,
  "created_at" : "2014-11-05 02:53:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529828416694910976",
  "text" : "\u30BB\u30DF\u30CA\u30FC\u6E96\u5099RTA",
  "id" : 529828416694910976,
  "created_at" : "2014-11-05 02:51:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8003\u3048\u308B\u30AB\u30EF\u30BA\u304F\u3093",
      "screen_name" : "MrBoilingFrog",
      "indices" : [ 0, 14 ],
      "id_str" : "599102449",
      "id" : 599102449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529827996622786560",
  "geo" : { },
  "id_str" : "529828334465601536",
  "in_reply_to_user_id" : 599102449,
  "text" : "@MrBoilingFrog (\u3055\u3063\u304D\u5148\u751F\u304B\u3089pdf\u98DB\u3093\u3067\u6765\u305F\u50D5\u306F\u4ECA\u304B\u3089\u6E96\u5099\u3057\u307E\u3059)",
  "id" : 529828334465601536,
  "in_reply_to_status_id" : 529827996622786560,
  "created_at" : "2014-11-05 02:51:33 +0000",
  "in_reply_to_screen_name" : "MrBoilingFrog",
  "in_reply_to_user_id_str" : "599102449",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529822119832465408",
  "text" : "hogehoge\u3068\u3044\u3046\u30EF\u30FC\u30C9\u304C\u81EA\u79F0hogehoge\u304C\u8352\u3089\u3057\u56DE\u3063\u3066\u7121\u304C\u6B8B\u308B\u73FE\u8C61\u306E\u666E\u904D\u6027",
  "id" : 529822119832465408,
  "created_at" : "2014-11-05 02:26:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529821758119878656",
  "geo" : { },
  "id_str" : "529821967549882369",
  "in_reply_to_user_id" : 2562716629,
  "text" : "@Hen_Zai_4 \u81EA\u79F0\u307C\u3063\u3061()\u304C\u8352\u3089\u3057\u56DE\u3063\u3066\u4F55\u3082\u6B8B\u3089\u306A\u304B\u3063\u305F",
  "id" : 529821967549882369,
  "in_reply_to_status_id" : 529821758119878656,
  "created_at" : "2014-11-05 02:26:15 +0000",
  "in_reply_to_screen_name" : "4th_No_Fon",
  "in_reply_to_user_id_str" : "2562716629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529821563332227072",
  "text" : "RTA\u611F",
  "id" : 529821563332227072,
  "created_at" : "2014-11-05 02:24:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529800420583936000",
  "text" : "\u7D76\u4E16\u306E\u7F8E\u5C11\u5973\u3067\u3082\u9F3B\u6C34\u306F\u3061\u3083\u3093\u3068\u9F3B\u6C34\u306A\u3093\u3060\u3068\u601D\u3046\u3093\u3067\u3059\u3051\u3069(\u540D\u63A8\u7406)",
  "id" : 529800420583936000,
  "created_at" : "2014-11-05 01:00:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 0, 9 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529800132443652096",
  "geo" : { },
  "id_str" : "529800236474978305",
  "in_reply_to_user_id" : 2306283966,
  "text" : "@tenapyon \u305D\u308C\u306F\u305D\u308C\u3067\u77E5\u308A\u305F\u304F\u306A\u3044\u4E16\u754C\u3067\u3059\u306D\u2026",
  "id" : 529800236474978305,
  "in_reply_to_status_id" : 529800132443652096,
  "created_at" : "2014-11-05 00:59:54 +0000",
  "in_reply_to_screen_name" : "tenapyon",
  "in_reply_to_user_id_str" : "2306283966",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 0, 9 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529799481336676352",
  "geo" : { },
  "id_str" : "529799888662323200",
  "in_reply_to_user_id" : 2306283966,
  "text" : "@tenapyon \u9F3B\u6C34\u3068\u3044\u3046\u3060\u3051\u3067\u30A2\u30EC\u306A\u306E\u306B\u4F7F\u7528\u6E08\u307F\u3063\u3066\u8F2A\u3092\u304B\u3051\u3066\u5ACC\u306A\u611F\u3058\u3057\u307E\u3059\u306D",
  "id" : 529799888662323200,
  "in_reply_to_status_id" : 529799481336676352,
  "created_at" : "2014-11-05 00:58:31 +0000",
  "in_reply_to_screen_name" : "tenapyon",
  "in_reply_to_user_id_str" : "2306283966",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 0, 9 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529798961821777920",
  "geo" : { },
  "id_str" : "529799201807294467",
  "in_reply_to_user_id" : 2306283966,
  "text" : "@tenapyon \u3042\u308B\u7A0B\u5EA6\u7E8F\u3081\u3066\u5B87\u5B99\u306B\u98DB\u3070\u3059\u304F\u3089\u3044\u3057\u304B\u601D\u3044\u3064\u304B\u306A\u3044\u3067\u3059\u306D\u2026",
  "id" : 529799201807294467,
  "in_reply_to_status_id" : 529798961821777920,
  "created_at" : "2014-11-05 00:55:47 +0000",
  "in_reply_to_screen_name" : "tenapyon",
  "in_reply_to_user_id_str" : "2306283966",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529798643071471616",
  "text" : "\u5ACC\u3059\u304E\u308B\u306A",
  "id" : 529798643071471616,
  "created_at" : "2014-11-05 00:53:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529798619012931584",
  "text" : "\u96FB\u529B\u4F1A\u793E\u304C\u9F3B\u6C34\u3092\u8CB7\u3044\u53D6\u308B\u30B7\u30B9\u30C6\u30E0",
  "id" : 529798619012931584,
  "created_at" : "2014-11-05 00:53:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529798503036231680",
  "text" : "\u9F3B\u6C34\u3001\u7121\u9650\u306B\u51FA\u3066\u304F\u308B\u3088\u3046\u306B\u3057\u304B\u601D\u3048\u306A\u3044\u3057\u9F3B\u6C34\u3067\u767A\u96FB\u3057\u305F\u3089\u826F\u3044\u306E\u306B\u3063\u3066\u601D\u3046\u3093\u3060",
  "id" : 529798503036231680,
  "created_at" : "2014-11-05 00:53:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8003\u3048\u308B\u30AB\u30EF\u30BA\u304F\u3093",
      "screen_name" : "MrBoilingFrog",
      "indices" : [ 0, 14 ],
      "id_str" : "599102449",
      "id" : 599102449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529796623572815872",
  "geo" : { },
  "id_str" : "529796801352589313",
  "in_reply_to_user_id" : 599102449,
  "text" : "@MrBoilingFrog \u307B\u3068\u3093\u3069\u5168\u3066\u306E\u5358\u4F4D\u304C\u73FE\u5728\u306E\u4FA1\u5024\u306B\u63DB\u7B97\u3055\u308C\u3066\u308B",
  "id" : 529796801352589313,
  "in_reply_to_status_id" : 529796623572815872,
  "created_at" : "2014-11-05 00:46:15 +0000",
  "in_reply_to_screen_name" : "MrBoilingFrog",
  "in_reply_to_user_id_str" : "599102449",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8003\u3048\u308B\u30AB\u30EF\u30BA\u304F\u3093",
      "screen_name" : "MrBoilingFrog",
      "indices" : [ 0, 14 ],
      "id_str" : "599102449",
      "id" : 599102449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529794134471499781",
  "geo" : { },
  "id_str" : "529796360438951936",
  "in_reply_to_user_id" : 599102449,
  "text" : "@MrBoilingFrog \u30A2\u30AB\u30AE\u306E\u30A2\u30F3\u30B5\u30A4\u30AF\u30ED\u30DA\u30C7\u30A3\u30A2\u8AAD\u3093\u3060\uFF1F",
  "id" : 529796360438951936,
  "in_reply_to_status_id" : 529794134471499781,
  "created_at" : "2014-11-05 00:44:30 +0000",
  "in_reply_to_screen_name" : "MrBoilingFrog",
  "in_reply_to_user_id_str" : "599102449",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529792739873783810",
  "text" : "@Kyo_Hiiragi \u3044\u304F\u3088",
  "id" : 529792739873783810,
  "created_at" : "2014-11-05 00:30:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529633323455221760",
  "text" : "\u304D\u3085\u3046\u3079\u3048\u7684\u306A\u30A2\u30EC\u3068\u5951\u7D04\u3057\u3066\u73FE\u5728\u904E\u53BB\u672A\u6765\u3059\u3079\u3066\u306E\u5099\u4E2D\u936C\u3092\u6D88\u3057\u53BB\u308A\u305F\u3044",
  "id" : 529633323455221760,
  "created_at" : "2014-11-04 13:56:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529631817989488641",
  "text" : "\u5099\u4E2D\u936C\u77E5\u3063\u3066\u308B\u4EBA\u9593\uFF0C\u7121\u4EBA\u5CF6\u306B\u5099\u4E2D\u936C\u3060\u3051\u6301\u3063\u3066\u3044\u304F\u6CD5\u5F8B\u3068\u304B\u51FA\u6765\u308D",
  "id" : 529631817989488641,
  "created_at" : "2014-11-04 13:50:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529631394582913024",
  "text" : "\u5099\u4E2D\u936C\u3092\u77E5\u3063\u3066\u3044\u308B\u4EBA\u9593\u306B\u3060\u3051\u611F\u67D3\u3059\u308B\u30A4\u30F3\u30D5\u30EB\u30A8\u30F3\u30B6\u3068\u304B\u6D41\u884C\u308C",
  "id" : 529631394582913024,
  "created_at" : "2014-11-04 13:48:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529631047177093120",
  "geo" : { },
  "id_str" : "529631138440941569",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u308F\u304B\u308B\uFF5E",
  "id" : 529631138440941569,
  "in_reply_to_status_id" : 529631047177093120,
  "created_at" : "2014-11-04 13:47:58 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529630962708013056",
  "text" : "\u5099\u4E2D\u936C\u306A\u3093\u3066\u77E5\u3089\u306A\u3044\u304C\uFF0C\u5099\u4E2D\u936C\u3092\u77E5\u3063\u3066\u308B\u4EBA\u9593\u3092\u77E5\u3063\u3066\u3044\u308B",
  "id" : 529630962708013056,
  "created_at" : "2014-11-04 13:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529630463728443393",
  "text" : "\u300C\u3059\u304D\u306A\u306E\u306B\u3059\u304D\u3058\u3083\u306A\u3044\u300D\n\u300C\u5973\u5B50\u9AD8\u751F\u304B\u300D\n\u3063\u3066\u306E\u3082\u5999\u3061\u304F\u308A\u3093\u306A\u4F1A\u8A71\u3067\u3042\u308B\u3053\u3068\u3088",
  "id" : 529630463728443393,
  "created_at" : "2014-11-04 13:45:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529629500766576640",
  "geo" : { },
  "id_str" : "529629582744244225",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u76F8\u624B\u306E\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3092\u8003\u616E\u305B\u305A\u306B\u3059\u308B\u4F1A\u8A71 is \u697D\u3057\u3044",
  "id" : 529629582744244225,
  "in_reply_to_status_id" : 529629500766576640,
  "created_at" : "2014-11-04 13:41:47 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529629332411400193",
  "geo" : { },
  "id_str" : "529629421871722496",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \uFF1F\uFF1F\uFF1F",
  "id" : 529629421871722496,
  "in_reply_to_status_id" : 529629332411400193,
  "created_at" : "2014-11-04 13:41:08 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529629377055584256",
  "text" : "\u30B9\u30AB\u30FC\u30C8\u306E\u4E2D\u306B\u95C7\u304C\u5E83\u304C\u3063\u3066\u3044\u308B\u306E\uFF0C\u3069\u3046\u8003\u3048\u3066\u3082\u795E\u8A71\u751F\u7269",
  "id" : 529629377055584256,
  "created_at" : "2014-11-04 13:40:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529629077452247040",
  "text" : "\u30DE\u30B8\u30EC\u30B9\u304A\u306B\u3044\u3055\u3093",
  "id" : 529629077452247040,
  "created_at" : "2014-11-04 13:39:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529628939266695168",
  "geo" : { },
  "id_str" : "529629054652010496",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u3044\u3044\u3048\uFF0C\u7537\u5B50\u5927\u5B66\u9662\u751F\u3067\u3059\u3051\u3069\uFF0E\u77E5\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3063\u3051\uFF1F",
  "id" : 529629054652010496,
  "in_reply_to_status_id" : 529628939266695168,
  "created_at" : "2014-11-04 13:39:41 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529628901048217600",
  "text" : "\u3059\u304D\u306F\u3059\u304D\u3058\u3083\u306A\u3044",
  "id" : 529628901048217600,
  "created_at" : "2014-11-04 13:39:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529628885885784065",
  "text" : "A\u306FA\u3058\u3083\u306A\u3044",
  "id" : 529628885885784065,
  "created_at" : "2014-11-04 13:39:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529628699511902208",
  "geo" : { },
  "id_str" : "529628807662022656",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u3059\u304D\u306A\u306E\u306B\u3059\u304D\u3058\u3083\u306A\u3044",
  "id" : 529628807662022656,
  "in_reply_to_status_id" : 529628699511902208,
  "created_at" : "2014-11-04 13:38:42 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529628543894814720",
  "geo" : { },
  "id_str" : "529628620927426560",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u307E\u3041\u7F8E\u5473\u3057\u3044\u30A8\u30D4\u30BD\u30FC\u30C9\u3067\u3082\u3042\u308B\u3093\u3067\u3059\u3051\u3069\u306D\u30FC",
  "id" : 529628620927426560,
  "in_reply_to_status_id" : 529628543894814720,
  "created_at" : "2014-11-04 13:37:57 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529628001374191616",
  "geo" : { },
  "id_str" : "529628391838736385",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u307E\u3041\u5ACC\u306A\u30A8\u30D4\u30BD\u30FC\u30C9\u8A18\u61B6\u3068\u7D10\u3064\u3044\u3061\u3083\u3063\u305F\u3093\u3067\u5ACC\u3044\u3067\u3059\u306D",
  "id" : 529628391838736385,
  "in_reply_to_status_id" : 529628001374191616,
  "created_at" : "2014-11-04 13:37:03 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529628214943952896",
  "text" : "\u307E\u304B\u306A\u3044\u3055\u3093\u4ECA\u65E5\u30C6\u30F3\u30B7\u30E7\u30F3\u9AD8\u3044\u3067\u3059\u306D",
  "id" : 529628214943952896,
  "created_at" : "2014-11-04 13:36:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529628147675701248",
  "text" : "\u597D\u304D\u306A\u3082\u306E\uFF1A\u4F1D\u308F\u308A\u306B\u304F\u3044\u308F\u308A\u306B\u4F1D\u308F\u3063\u305F\u3068\u3053\u308D\u3067\u3042\u307E\u308A\u610F\u5473\u306E\u306A\u3044\u4F1A\u8A71\n\u5ACC\u3044\u306A\u3082\u306E\uFF1A\u8FB2\u5177\uFF08\u7279\u306B\u5099\u4E2D\u936C\uFF09",
  "id" : 529628147675701248,
  "created_at" : "2014-11-04 13:36:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529627668589735936",
  "geo" : { },
  "id_str" : "529627875129839616",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u936C\u307B\u3069\u3058\u3083\u306A\u3044\u3067\u3059\u304C\u3042\u307E\u308A\u3044\u3044\u5370\u8C61\u306F\u306A\u3044\u3067\u3059\u306D",
  "id" : 529627875129839616,
  "in_reply_to_status_id" : 529627668589735936,
  "created_at" : "2014-11-04 13:35:00 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529627744837984257",
  "text" : "\u3042\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u30CB\u30F3\u30B8\u30E3\u30BD\u30A6\u30EB\u304C\u6191\u4F9D\u3057\u3066\u305F\u3089\u30CE\u30A6\u30B0\u30B9\u30EC\u30A4\u30E4\u30FC\u306B\u306A\u308A\u304B\u306D\u306A\u3044\u4E8B\u4EF6\u3060\u3063\u305F",
  "id" : 529627744837984257,
  "created_at" : "2014-11-04 13:34:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529627364385234944",
  "geo" : { },
  "id_str" : "529627559827230721",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u3044\u3048\uFF0C\u8FB2\u5177\u306F\u5ACC\u3044\u306A\u306E\u3067\u3059",
  "id" : 529627559827230721,
  "in_reply_to_status_id" : 529627364385234944,
  "created_at" : "2014-11-04 13:33:44 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529627514683940865",
  "text" : "\u300C\u3059\u304D\u3084\u304D\u98DF\u3079\u305F\u3044\u3057\uFF0C\u4F5C\u308B\u304B\u300D\n\u300C\u92E4\u304B\u3089\u3067\u3059\u304B\uFF1F\u300D\n\u300C\u8FB2\u5177\u306F\u597D\u304D\u3058\u3083\u306A\u3044\u3093\u3067\u300D",
  "id" : 529627514683940865,
  "created_at" : "2014-11-04 13:33:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529627182960627713",
  "geo" : { },
  "id_str" : "529627246147805184",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u8FB2\u5177\u306F\u5168\u822C\u597D\u304D\u3058\u3083\u306A\u3044\u306E\u3067...",
  "id" : 529627246147805184,
  "in_reply_to_status_id" : 529627182960627713,
  "created_at" : "2014-11-04 13:32:30 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529626877770473473",
  "text" : "\u3059\u304D\u713C\u304D\u98DF\u3079\u305F\u3044\u304B\u3089\u660E\u65E5\u3042\u305F\u308A\u4F5C\u308B\u304B",
  "id" : 529626877770473473,
  "created_at" : "2014-11-04 13:31:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4ED6\u4EBA\u306E\u91D1\u3067\u8CB7\u3063\u305F\u30A2\u30A4\u30B9\u306F\u7F8E\u5473\u3044",
      "indices" : [ 16, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529626453529210880",
  "text" : "\u4ED6\u4EBA\u306E\u91D1\u3067\u8CB7\u3063\u305F\u30A2\u30A4\u30B9\u306F\u7F8E\u5473\u3044 #\u4ED6\u4EBA\u306E\u91D1\u3067\u8CB7\u3063\u305F\u30A2\u30A4\u30B9\u306F\u7F8E\u5473\u3044",
  "id" : 529626453529210880,
  "created_at" : "2014-11-04 13:29:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529626239317704705",
  "text" : "\u708E\u3068\u6C37\u304C\u3042\u308F\u3055\u308A\u6700\u5F37\u306B\u898B\u3048\u308B",
  "id" : 529626239317704705,
  "created_at" : "2014-11-04 13:28:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u716E\u8FBC\u307F\u30A2\u30A4\u30B9",
      "screen_name" : "nicomi_ice",
      "indices" : [ 0, 11 ],
      "id_str" : "271549396",
      "id" : 271549396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529625882780909568",
  "geo" : { },
  "id_str" : "529626166336839680",
  "in_reply_to_user_id" : 271549396,
  "text" : "@nicomi_ice \u3044\u3048\u3044\u3048\uFF1F",
  "id" : 529626166336839680,
  "in_reply_to_status_id" : 529625882780909568,
  "created_at" : "2014-11-04 13:28:12 +0000",
  "in_reply_to_screen_name" : "nicomi_ice",
  "in_reply_to_user_id_str" : "271549396",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529625706754367488",
  "geo" : { },
  "id_str" : "529625859838066690",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u96EA\u304C\u7A4D\u3082\u3063\u3066\u304D\u305F\u3089\u30EC\u30B7\u30D4\u3092\u6295\u3052\u3066\u3082\u3089\u304A\u3046",
  "id" : 529625859838066690,
  "in_reply_to_status_id" : 529625706754367488,
  "created_at" : "2014-11-04 13:26:59 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u716E\u8FBC\u307F\u30A2\u30A4\u30B9",
      "screen_name" : "nicomi_ice",
      "indices" : [ 0, 11 ],
      "id_str" : "271549396",
      "id" : 271549396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529625736009617408",
  "in_reply_to_user_id" : 271549396,
  "text" : "@nicomi_ice \u306A\u3093\u3060\u304B\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F\uFF08\uFF1F\uFF09",
  "id" : 529625736009617408,
  "created_at" : "2014-11-04 13:26:30 +0000",
  "in_reply_to_screen_name" : "nicomi_ice",
  "in_reply_to_user_id_str" : "271549396",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529625312615596033",
  "text" : "\u306A\u3093\u3060\u305D\u306E\u754C\u9688",
  "id" : 529625312615596033,
  "created_at" : "2014-11-04 13:24:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/phVrK0CRIS",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/529623864100155393",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529625277513465858",
  "text" : "\u716E\u8FBC\u307F\u30A2\u30A4\u30B9\u3055\u3093\u754C\u9688\u306BRT\u3055\u308C\u3066\u308B\u6A21\u69D8\uFF0E https:\/\/t.co\/phVrK0CRIS",
  "id" : 529625277513465858,
  "created_at" : "2014-11-04 13:24:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529624614498881536",
  "text" : "\u3088\u3044\u6A5F\u4F1A(?)\u3060\u3057\u30D5\u30A9\u30ED\u30FC\u3057\u305F",
  "id" : 529624614498881536,
  "created_at" : "2014-11-04 13:22:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529624282683285504",
  "text" : "\u307E\u3055\u304B\u306E\u30B9\u30AF\u30EA\u30FC\u30F3\u30CD\u30FC\u30E0\u300C\u716E\u8FBC\u307F\u30A2\u30A4\u30B9\u300D\u306E\u5B58\u5728\u3067\u3042\u308B",
  "id" : 529624282683285504,
  "created_at" : "2014-11-04 13:20:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/foeHevo32i",
      "expanded_url" : "https:\/\/twitter.com\/nicomi_ice\/status\/529624044727853056",
      "display_url" : "twitter.com\/nicomi_ice\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529624188735082496",
  "text" : "\u306A\u308B\u307B\u3069 https:\/\/t.co\/foeHevo32i",
  "id" : 529624188735082496,
  "created_at" : "2014-11-04 13:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529623919779520512",
  "geo" : { },
  "id_str" : "529624064386531328",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u6696\u623F\u306E\u304D\u3044\u305F\u90E8\u5C4B\u3067\u30C9\u30DF\u30CB\u30AA\u30F3\u3057\u306A\u304C\u3089\u98DF\u3079\u308B\u4ED6\u4EBA\u306E\u91D1\u3067\u8CB7\u3063\u305F\u30A2\u30A4\u30B9\u306F\u3046\u307E\u3044",
  "id" : 529624064386531328,
  "in_reply_to_status_id" : 529623919779520512,
  "created_at" : "2014-11-04 13:19:51 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529623879317073920",
  "text" : "\u305D\u3093\u306A\u3082\u306E\u306F\u306A\u3044",
  "id" : 529623879317073920,
  "created_at" : "2014-11-04 13:19:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529623864100155393",
  "text" : "\u716E\u8FBC\u307F\u30A2\u30A4\u30B9\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B",
  "id" : 529623864100155393,
  "created_at" : "2014-11-04 13:19:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529623461883154432",
  "text" : "\u6DF7\u305C\u308B\u3068\u4F38\u3073\u308B\u30A2\u30A4\u30B9\u3092\u304A\u6E6F\u306B\u6DF7\u305C\u308B\u8A66\u307F",
  "id" : 529623461883154432,
  "created_at" : "2014-11-04 13:17:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529623194206887936",
  "text" : "\u72A0\u7272\u306B\u306A\u3063\u305F\u306E\u3060...\u72A0\u7272\u306E\u72A0\u7272...\u305D\u306E\u72A0\u7272\u306B\u306A...",
  "id" : 529623194206887936,
  "created_at" : "2014-11-04 13:16:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529416374309777408",
  "geo" : { },
  "id_str" : "529622865222459392",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u3048\u3093\u3069\u3055\u3093\u306F\u521D\u96EA\u4E88\u5831\u30EC\u30FC\u30B9\u3067\u898B\u4E8B\u30C9\u30F3\u30D4\u30B7\u30E3\u3067\u5F53\u3066\u3066\u3066\u53CB\u4EBA\u306B\u30A2\u30A4\u30B9\u3092\u304A\u3054\u3063\u3066\u3082\u3089\u3063\u305F\u3088\uFF08\u4E80\u30EA\u30D7\uFF09",
  "id" : 529622865222459392,
  "in_reply_to_status_id" : 529416374309777408,
  "created_at" : "2014-11-04 13:15:05 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529568394555576320",
  "text" : "\u30DD\u30ED\u30ED\u30C3\u30AB",
  "id" : 529568394555576320,
  "created_at" : "2014-11-04 09:38:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529566389632122880",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 529566389632122880,
  "created_at" : "2014-11-04 09:30:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529566382048825344",
  "text" : "\u7A7A\u30E9\u30A4\u30AA\u30F3\u306F\u81EA\u660E\u306A\u30E9\u30A4\u30AA\u30F3\u3068\u3057\u3066\u3069\u3053\u306B\u3067\u3082\u5B58\u5728\u3059\u308B",
  "id" : 529566382048825344,
  "created_at" : "2014-11-04 09:30:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529566065001365504",
  "geo" : { },
  "id_str" : "529566275538657280",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 Emacs\u306F\u6016\u304F\u306A\u3044\u3051\u3069Emacs\u3092\u4F7F\u3046\u30E9\u30A4\u30AA\u30F3\u306E\u4E2D\u306B\u6016\u3044\u30E9\u30A4\u30AA\u30F3\u304C\u5B58\u5728\u3059\u308B",
  "id" : 529566275538657280,
  "in_reply_to_status_id" : 529566065001365504,
  "created_at" : "2014-11-04 09:30:13 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529566029244944385",
  "text" : "\u30A2\u30CB\u30E1\u306F\u6C17\u6301\u3061\u3088\u304F\u306A\u308B\u305F\u3081\u306E\u30C4\u30FC\u30EB\u3058\u3083\u306A\u3044\u3093\u3060\u3088",
  "id" : 529566029244944385,
  "created_at" : "2014-11-04 09:29:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529565947439235072",
  "geo" : { },
  "id_str" : "529565989231284224",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3042\u3063\u306F\u3044",
  "id" : 529565989231284224,
  "in_reply_to_status_id" : 529565947439235072,
  "created_at" : "2014-11-04 09:29:05 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529565744816590848",
  "geo" : { },
  "id_str" : "529565864027119616",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u5927\u62B5\u306E\u3082\u306E\u3092\u3044\u308C\u3066\u6210\u308A\u7ACB\u3064",
  "id" : 529565864027119616,
  "in_reply_to_status_id" : 529565744816590848,
  "created_at" : "2014-11-04 09:28:35 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529565636309962752",
  "text" : "\u305D\u3046\u3044\u3046\u610F\u5473\u3067\u30AD\u30EB\u306A\u3093\u3068\u304B\u30D9\u30A4\u306A\u3093\u3068\u304B\u3082\u671F\u5F85\u306F\u3057\u3066\u3044\u308B\uFF08\u898B\u308B\u7528\u610F\u306F\u306A\u3044\uFF09",
  "id" : 529565636309962752,
  "created_at" : "2014-11-04 09:27:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529565496799027200",
  "text" : "\u632F\u308A\u5207\u308C\u305F\u30AF\u30BD\u30A2\u30CB\u30E1\u306F\u597D\u304D",
  "id" : 529565496799027200,
  "created_at" : "2014-11-04 09:27:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529565334919847936",
  "geo" : { },
  "id_str" : "529565433435668480",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30AF\u30BD\u30A2\u30CB\u30E1\u3068\u3057\u3066\u671F\u5F85\u306F\u3057\u3066\u3044\u308B\uFF08\u898B\u308B\u7528\u610F\u304C\u3042\u308B\uFF09",
  "id" : 529565433435668480,
  "in_reply_to_status_id" : 529565334919847936,
  "created_at" : "2014-11-04 09:26:52 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529565348199014402",
  "text" : "\u60B2\u3057\u307F\u306B\u304F\u308C\u306A\u304C\u3089\u30C9\u30A4\u30C4\u98DF\u30D1\u30F3\u30C8\u30FC\u30B9\u30C8\u3057\u3066\u98DF\u3079\u308B",
  "id" : 529565348199014402,
  "created_at" : "2014-11-04 09:26:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529565110176456704",
  "geo" : { },
  "id_str" : "529565260957503488",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u76F8\u5909\u308F\u3089\u305A\u982D\u304A\u304B\u3057\u3044\u3042\u3044\u307E\u3044\u307F\u30FC",
  "id" : 529565260957503488,
  "in_reply_to_status_id" : 529565110176456704,
  "created_at" : "2014-11-04 09:26:11 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529564868718784512",
  "text" : "\u7A7A\u30EA\u30D7\u3068\u304B\u4E94\u5104\u5E74\u3076\u308A\u306B\u4F7F\u3063\u305F",
  "id" : 529564868718784512,
  "created_at" : "2014-11-04 09:24:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529564735276990465",
  "geo" : { },
  "id_str" : "529564793460371456",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20",
  "id" : 529564793460371456,
  "in_reply_to_status_id" : 529564735276990465,
  "created_at" : "2014-11-04 09:24:20 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529564651944546304",
  "text" : "\u307E\u3060\u9811\u5F35\u308B",
  "id" : 529564651944546304,
  "created_at" : "2014-11-04 09:23:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529564632537522176",
  "text" : "\u5931\u610F\u306E\u3046\u3061\u306B\u5E30\u5B85\u3057\u305F\u304F\u306A\u3063\u3066\u304D\u305F",
  "id" : 529564632537522176,
  "created_at" : "2014-11-04 09:23:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529563667247804416",
  "text" : "\u3042\u3070\u3070\u3070\u3070\u3070",
  "id" : 529563667247804416,
  "created_at" : "2014-11-04 09:19:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529563519184666624",
  "text" : "\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u98DF\u3079\u305F\u3044",
  "id" : 529563519184666624,
  "created_at" : "2014-11-04 09:19:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529547850112172032",
  "text" : "\u307F\u305F\u3044\u306A\u306E",
  "id" : 529547850112172032,
  "created_at" : "2014-11-04 08:17:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529547786547519488",
  "text" : "\u5B66\u751F\u300C\u793C\u72B6\u306F\u304A\u9905\u3067\u3057\u3087\u3046\u304B\u300D \n\u516C\u5B89\u300C\u3048\u3063\u300D \n\u5B66\u751F\u300C\u635C\u67FB\u793C\u72B6\u306F\u304A\u9905\u3067\u3057\u3087\u3046\u304B\u300D \n\u516C\u5B89\u300C\u3044\u3048\u3057\u308A\u307E\u305B\u3093\u300D \n\u5B66\u751F\u300C\u3048\u3063\u300D \n\u516C\u5B89\u300C\u3048\u3063\u300D \n\u5B66\u751F\u300C\u307E\u3060\u304A\u9905\u306B\u306A\u3063\u3066\u306A\u3044\u3068\u3044\u3046\u3053\u3068\u3067\u3057\u3087\u3046\u304B\u300D \n\u5B66\u751F\u300C\u3048\u3063\u300D \n\u516C\u5B89\u300C\u3048\u3063\u300D",
  "id" : 529547786547519488,
  "created_at" : "2014-11-04 08:16:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529546968947638272",
  "text" : "\u3067\u3082\u5E73\u548C\u306F\u793C\u72B6\u6301\u3063\u3066\u306A\u304B\u3063\u305F\u306E\u3067\u5927\u5B66\u3092\u8A2A\u308C\u305F\u3082\u306E\u306E\u4E2D\u306B\u306F\u5165\u308C\u307E\u305B\u3093\u3067\u3057\u305F\uFF08\u5B8C\uFF09",
  "id" : 529546968947638272,
  "created_at" : "2014-11-04 08:13:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529546750285987841",
  "text" : "\u516C\u5B89\u3068\u304A\u663C\u306B\u9A12\u3050\u4EBA\u305F\u3061\u3067\u5BFE\u6D88\u6EC5\u3057\u3066\u304F\u308C\u308B\u3068\u5E73\u548C\u304C\u8A2A\u308C\u308B",
  "id" : 529546750285987841,
  "created_at" : "2014-11-04 08:12:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529546065679106049",
  "text" : "ill-defined\u304A\u3070\u3051\u304C\u3044\u3063\u3071\u3044\u51FA\u3066\u304D\u3066\u3064\u3089\u3044",
  "id" : 529546065679106049,
  "created_at" : "2014-11-04 08:09:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529542972803538944",
  "text" : "\u30B3\u30B3\u30A2\u304C\u3042\u3093\u307E\u308A\u7518\u304F\u306A\u304B\u3063\u305F\u304B\u3089\u30E1\u30FC\u30D7\u30EB\u30B7\u30ED\u30C3\u30D7\u5165\u308C\u305F\u3089\u3068\u308A\u3042\u3048\u305A\u306F\u7518\u304F\u3066\u6E29\u304B\u3044\u3082\u306E\u306E\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u98F2\u307F\u7269\u304C\u51FA\u6765\u4E0A\u304C\u3063\u305F",
  "id" : 529542972803538944,
  "created_at" : "2014-11-04 07:57:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529524173169647616",
  "text" : "\u304A\u793C\u72B6",
  "id" : 529524173169647616,
  "created_at" : "2014-11-04 06:42:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529523738660700161",
  "geo" : { },
  "id_str" : "529523830734069760",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305F\u3076\u3093\uFF08\u5168\u54E1\u306B\u706B\u3092\u3064\u3051\u308B\u3079\u304D\u3060\uFF09",
  "id" : 529523830734069760,
  "in_reply_to_status_id" : 529523738660700161,
  "created_at" : "2014-11-04 06:41:33 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529523762966708224",
  "text" : "\u30B2\u30B8\u30E5\u30BF\u30EB\u30C8\u30FB\u30B3\u30E9\u30B9\u30D7",
  "id" : 529523762966708224,
  "created_at" : "2014-11-04 06:41:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529523660508254208",
  "text" : "\u4E8B\u6545\u306F\u4E8B\u6545\u3092\u4E8B\u6545\u3068\u8A8D\u8B58\u3057\u306A\u3044\u4EBA\u9593\u3057\u304B\u3044\u306A\u3051\u308C\u3070\u4E8B\u6545\u306B\u306A\u3089\u306A\u3044",
  "id" : 529523660508254208,
  "created_at" : "2014-11-04 06:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529523435383173121",
  "geo" : { },
  "id_str" : "529523549032030208",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u56F2\u3044\u304C\u4E8B\u6545\u3092\u201D\u96A0\u853D\u201D\u3059\u308B\u304B\u3089\u5927\u4E08\u592B",
  "id" : 529523549032030208,
  "in_reply_to_status_id" : 529523435383173121,
  "created_at" : "2014-11-04 06:40:26 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529521954827419648",
  "text" : "Emacs\u306F\u6016\u304F\u306A\u3044\u3051\u3069Emacs\u3092\u4F7F\u3046\u4EBA\u9593\u306E\u4E2D\u306B\u6016\u3044\u4EBA\u304C\u5B58\u5728\u3059\u308B",
  "id" : 529521954827419648,
  "created_at" : "2014-11-04 06:34:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529520618346016768",
  "text" : "\u306F\u3041\uFF0C\u3061\u3083\u3044\u3053\u3075\u3059\u304D\u30FC",
  "id" : 529520618346016768,
  "created_at" : "2014-11-04 06:28:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529518638596767744",
  "text" : "\u8B66\u5BDF\u304C\u5B66\u751F\u3092\u6349\u3048\u3088\u3046\u3068\u3059\u308B\u3068\u304D\uFF0C\u5B66\u751F\u3082\u307E\u305F\uFF0C\u8B66\u5BDF\u3092\u6349\u3048\u3088\u3046\u3068\u3059\u308B\u306E\u3060\uFF0E\u307F\u305F\u3044\u306A\u6848\u4EF6\uFF0E",
  "id" : 529518638596767744,
  "created_at" : "2014-11-04 06:20:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529517434965721088",
  "text" : "\u5727\u5012\u7684\u6C17\u306E\u305B\u3044",
  "id" : 529517434965721088,
  "created_at" : "2014-11-04 06:16:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529517374483877888",
  "text" : "\u516C\u5B89\u306B\u30DE\u30FC\u30AF\u3055\u308C\u308B\u6848\u4EF6\uFF0C\u8EAB\u8FD1\u306A\u6C17\u304C\u3057\u3066\u304F\u308B\u304B\u3089\u30A2\u30EC\u3060",
  "id" : 529517374483877888,
  "created_at" : "2014-11-04 06:15:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529516920119123968",
  "text" : "\u304C\u3059\u308B\uFF0E\u30AC\u30B9\u306F\u306A\u3044\uFF0E",
  "id" : 529516920119123968,
  "created_at" : "2014-11-04 06:14:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529516882663989248",
  "text" : "\u6C17\u306E\u629C\u3051\u305F\u30AC\u30E9\u30CA\uFF0C\u70AD\u9178\u304C\u3042\u308C\u3070\u3082\u3063\u3068\u7F8E\u5473\u3057\u3044\u306E\u306B\u306A\uFF0C\u307F\u305F\u3044\u306A\u5473\u30AC\u30B9\u308B",
  "id" : 529516882663989248,
  "created_at" : "2014-11-04 06:13:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529516519303045120",
  "geo" : { },
  "id_str" : "529516620595486721",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u3069\u3046\u307F\u3066\u3082\u30C9\u30A4\u30C4\u8A9E\u306A\u3093\u3067\u3059\u304C\u305D\u308C\u306F",
  "id" : 529516620595486721,
  "in_reply_to_status_id" : 529516519303045120,
  "created_at" : "2014-11-04 06:12:54 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/hh66cmtfsN",
      "expanded_url" : "https:\/\/twitter.com\/ac_k_y\/status\/529512258829684736",
      "display_url" : "twitter.com\/ac_k_y\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "529516026937880576",
  "geo" : { },
  "id_str" : "529516230730739712",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y https:\/\/t.co\/hh66cmtfsN",
  "id" : 529516230730739712,
  "in_reply_to_status_id" : 529516026937880576,
  "created_at" : "2014-11-04 06:11:22 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529515468168507392",
  "text" : "\u30C9\u30DF\u30CB\u30AA\u30F3\u3067\u6700\u521D\u306E\u4E8C\u30BF\u30FC\u30F3\u3067\u5DE5\u623F\u8CB7\u3063\u305F\u306E\u306B\u6C88\u3093\u3060\u6642\u306E\u50D5\u300C\u30B3\u30A6\u30DC\u30A6\u30A8\u30E9\u30FC\u30BA...\u300D",
  "id" : 529515468168507392,
  "created_at" : "2014-11-04 06:08:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529515332512137216",
  "text" : "\u30B3\u30A6\u30DC\u30A6\u30FB\u30A8\u30E9\u30FC\u30BA",
  "id" : 529515332512137216,
  "created_at" : "2014-11-04 06:07:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529514227740848128",
  "text" : "\u50D5\u306F\u92AD\u6E6F\u3092\u30B5\u30A6\u30CA\u5C4B\u3055\u3093\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u3057\u30C9\u30F3\u30B0\u30EA\u30FB\u30B3\u30F3\u30DA\u30C6\u30A3\u30B7\u30E7\u30F3\u3060\u3063\u305F",
  "id" : 529514227740848128,
  "created_at" : "2014-11-04 06:03:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529514050057560064",
  "text" : "\u5B66\u98DF\u3092\u30AB\u30EC\u30FC\u5C4B\u3055\u3093\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u30D1\u30B5\u30FC\u30B8\u30E5\u3068\u30DF\u30B9\u30BF\u30FC\u30C9\u30FC\u30CA\u30C3\u30C4\u3092\u30E1\u30ED\u30F3\u30BD\u30FC\u30C0\u5C4B\u3055\u3093\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u304F\u3063\u3061\u3093\u3071",
  "id" : 529514050057560064,
  "created_at" : "2014-11-04 06:02:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529512744303616001",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 529512744303616001,
  "created_at" : "2014-11-04 05:57:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529512729795510273",
  "text" : "\u8A00\u8AD6\u306E\u81EA\u7531 vs \u30E1\u30AB\u8A00\u8AD6\u306E\u81EA\u7531",
  "id" : 529512729795510273,
  "created_at" : "2014-11-04 05:57:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529512631753666560",
  "text" : "\u8A00\u8AD6\u306E\u81EA\u7531 vs \u8A00\u8449\u306E\u30C9\u30C3\u30C2\u30DC\u30FC\u30EB",
  "id" : 529512631753666560,
  "created_at" : "2014-11-04 05:57:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529512448986861568",
  "geo" : { },
  "id_str" : "529512520969490432",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u8A00\u8449\u306E\u30C9\u30C3\u30C2\u30DC\u30FC\u30EB\uFF01",
  "id" : 529512520969490432,
  "in_reply_to_status_id" : 529512448986861568,
  "created_at" : "2014-11-04 05:56:37 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529512340471808000",
  "geo" : { },
  "id_str" : "529512399980605440",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u305D\u306E\u306B\u3083\u3093\u306B\u3083\u3093\u8A00\u3046\u306E\u3084\u3081\u306A\u3055\u3044\uFF01",
  "id" : 529512399980605440,
  "in_reply_to_status_id" : 529512340471808000,
  "created_at" : "2014-11-04 05:56:08 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529512258829684736",
  "geo" : { },
  "id_str" : "529512312374194177",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u306B\u3083\u30FC\u3093",
  "id" : 529512312374194177,
  "in_reply_to_status_id" : 529512258829684736,
  "created_at" : "2014-11-04 05:55:47 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529511988032851968",
  "geo" : { },
  "id_str" : "529512144375521280",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u306B\u3083\u306B\u304C\u306B\u3083\u30FC\u3093\u3067\u3059\u304B\uFF01\u6065\u3092\u77E5\u308A\u306B\u3083\u3055\u3044\uFF01",
  "id" : 529512144375521280,
  "in_reply_to_status_id" : 529511988032851968,
  "created_at" : "2014-11-04 05:55:07 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529511963789783040",
  "text" : "\u3042\u30FC",
  "id" : 529511963789783040,
  "created_at" : "2014-11-04 05:54:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529511939940962304",
  "text" : "\u3042\u30FC\u3063\u3066\u3044\u3046\u306E\u306F\u56FD\u6C11\u5168\u54E1\u306B\u5E73\u7B49\u306B\u4E0E\u3048\u3089\u308C\u305F\u6A29\u5229\u3060\u304B\u3089\u306A\uFF0C\u4ECA\u65E5\u3082\u80F8\u3092\u5F35\u3063\u3066\u3042\u30FC\u3063\u3066\u8A00\u304A\u3046",
  "id" : 529511939940962304,
  "created_at" : "2014-11-04 05:54:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529501305107013634",
  "text" : "\u305A\u3044\u3076\u3093\u98A8\u304C\u5F37\u3044\u306A",
  "id" : 529501305107013634,
  "created_at" : "2014-11-04 05:12:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529479867822141440",
  "text" : "\u3053\u306E\u5BD2\u3044\u306E\u306B\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u98F2\u3093\u3067\u308B\u65B9\u306E\u3048\u3093\u3069",
  "id" : 529479867822141440,
  "created_at" : "2014-11-04 03:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529476748044292096",
  "text" : "\u81EA\u5206\u306E\u77E5\u3089\u306A\u3044\u3053\u3068\u304F\u3089\u3044\u77E5\u3063\u3066\u304A\u3051",
  "id" : 529476748044292096,
  "created_at" : "2014-11-04 03:34:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/RMtQN5kvIm",
      "expanded_url" : "http:\/\/www.geocities.jp\/tomoatomi\/raira0001.htm",
      "display_url" : "geocities.jp\/tomoatomi\/rair\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529302712660160512",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u7A7A http:\/\/t.co\/RMtQN5kvIm",
  "id" : 529302712660160512,
  "created_at" : "2014-11-03 16:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529302598021427202",
  "text" : "3\u65E5\u306B\u4E5D\u5DDE\u304B\u3089\u767A\u9001\u3055\u308C\u305F\u8377\u7269\u30014\u65E5\u306B\u672D\u5E4C\u306B\u5C4A\u304F\u306E\u304B\u306A(\u81EA\u4FE1\u306A\u3044)",
  "id" : 529302598021427202,
  "created_at" : "2014-11-03 16:02:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529302125616979968",
  "text" : "@desole_mi \u6642\u9593\u304C\u3042\u308B\u6642\u306B\u898B\u3066\u898B\u307E\u3059\u3001\u672C\u7DE8\u3063\u3066\u666E\u901A\u306B\u30A2\u30AF\u30BB\u30B7\u30D6\u30EB\u306A\u3093\u3067\u3059\u306D",
  "id" : 529302125616979968,
  "created_at" : "2014-11-03 16:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529301715112058880",
  "text" : "\u591A\u8DA3\u5473\u3060\u304B\u3089\u7121\u9650\u306B\u6642\u9593\u3064\u3076\u305B\u3066\u3084\u3070\u3044(\u91D1\u304C\u304B\u304B\u308B)",
  "id" : 529301715112058880,
  "created_at" : "2014-11-03 15:58:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529300364642631680",
  "text" : "\u30DF\u30C3\u30B7\u30E7\u30F3\u3061\u3083\u3093\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3044\u308B\u306E\u304B",
  "id" : 529300364642631680,
  "created_at" : "2014-11-03 15:53:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529300301518344193",
  "text" : "@desole_mi \u3056\u3063\u3068\u30B0\u30B0\u3063\u305F\u3060\u3051\u3067\u3059\u304C\u3001\u30CA\u30CB\u30B3\u30EC\u611F\u304C\u60AA\u304F\u306A\u3044\u3067\u3059\u306D(?)",
  "id" : 529300301518344193,
  "created_at" : "2014-11-03 15:53:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529299804128423936",
  "text" : "@desole_mi \u3060\u3044\u3076\u3084\u3070\u3044\u767A\u60F3\u3060(\u98A8\u90AA\u85AC)",
  "id" : 529299804128423936,
  "created_at" : "2014-11-03 15:51:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529299083618291712",
  "geo" : { },
  "id_str" : "529299575429820418",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u541B\u306E\u8A00\u3046\u901A\u308A\u3060\u3001\u8A02\u6B63\u3057\u3088\u3046\u3002\u81EA\u5206\u306E\u904E\u3061\u3092\u7D20\u76F4\u306B\u8A8D\u3081\u308B\u3053\u3068\u304C\u51FA\u6765\u306A\u3044\u4EBA\u9593\u306F\u4F55\u3092\u3084\u3063\u3066\u3082\u30C0\u30E1\u3002",
  "id" : 529299575429820418,
  "in_reply_to_status_id" : 529299083618291712,
  "created_at" : "2014-11-03 15:50:27 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529298550799089664",
  "geo" : { },
  "id_str" : "529298769498476544",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u4ED6\u4EBA\u306E\u305B\u3044\u306B\u3059\u308B\u306A\u3001\u5DF1\u306E\u904E\u3061\u3092\u8A8D\u3081\u3088(\u771F\u9854)",
  "id" : 529298769498476544,
  "in_reply_to_status_id" : 529298550799089664,
  "created_at" : "2014-11-03 15:47:15 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529298608399466496",
  "text" : "\u5049\u3044\u304B\u3089\u304A\u85AC\u3092\u98F2\u3080\u30DF\u30C3\u30B7\u30E7\u30F3\u3092\u601D\u3044\u51FA\u3057\u305F",
  "id" : 529298608399466496,
  "created_at" : "2014-11-03 15:46:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529298336549855233",
  "text" : "\u305D\u3082\u305D\u3082(\u975E)\u53EF\u7B97\u7121\u9650\u6642\u9593\u3063\u3066\u4F55\u306A\u3093\u3060\u2026",
  "id" : 529298336549855233,
  "created_at" : "2014-11-03 15:45:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529297957649006592",
  "geo" : { },
  "id_str" : "529298121369464833",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u3093\u3093www\u8DB3\u3057\u7B97\u3067\u3059\u304B\u306Awww\u6B63\u3057\u304F\u306F\"\u53EF\u7B97\"\u3067\u3059\u305Ewww",
  "id" : 529298121369464833,
  "in_reply_to_status_id" : 529297957649006592,
  "created_at" : "2014-11-03 15:44:40 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529297778598371329",
  "text" : "\u30E9\u30B9\u30DC\u30B9\u554F\u984C\u5358\u9A0E\u3067\u51FA\u305B\u306A\u3044\u3057\u691C\u8A3C\u3057\u3088\u3046\u304C\u306A\u3044",
  "id" : 529297778598371329,
  "created_at" : "2014-11-03 15:43:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529297595626057728",
  "text" : "\u304D\u308B\u3075\u3041\u6C0F\u3001\u30E9\u30B9\u30DC\u30B9\u7D1A\u306E\u554F\u984C\u3092\u6709\u9650\u6642\u9593\u3067\u89E3\u304D\u304D\u308B\u6C17\u914D\u304C\u306A\u3044",
  "id" : 529297595626057728,
  "created_at" : "2014-11-03 15:42:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 3, 11 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529297359402856448",
  "text" : "RT @killfar: \u96D1\u9B5A\u554F(\u96E3\u554F)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529297243526807552",
    "text" : "\u96D1\u9B5A\u554F(\u96E3\u554F)",
    "id" : 529297243526807552,
    "created_at" : "2014-11-03 15:41:11 +0000",
    "user" : {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "protected" : false,
      "id_str" : "300742004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600849929821507584\/hggkzScS_normal.png",
      "id" : 300742004,
      "verified" : false
    }
  },
  "id" : 529297359402856448,
  "created_at" : "2014-11-03 15:41:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529297297239064576",
  "text" : "\u771F\u4EBA\u9593\u3068\u304B\u3044\u3046\u30EF\u30FC\u30C9\u3001ill-defined\u3059\u304E\u3066\u8A71\u306B\u306A\u3089\u306A\u3044",
  "id" : 529297297239064576,
  "created_at" : "2014-11-03 15:41:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529296994422898688",
  "text" : "\u9662\u751F\u5BA4\u3067\u8B0E\u306E\u96D1\u9B5A\u554F\u307F\u305F\u3044\u306A\u306E\u6295\u3052\u5408\u3046\u6587\u5316\u304C\u751F\u307E\u308C\u3064\u3064\u3042\u308B\u304B\u3089\u904E\u53BB\u306E\u516C\u6F14\u306E\u96D1\u9B5A\u554F\u3092\u30E1\u30E2\u306A\u308A\u306A\u3093\u306A\u308A\u3057\u3066\u304A\u3051\u3070\u826F\u304B\u3063\u305F\u3068\u601D\u3063\u3066\u308B",
  "id" : 529296994422898688,
  "created_at" : "2014-11-03 15:40:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529295617852309506",
  "text" : "\u4EE5\u6765TRPG\u306E\u52D5\u753B\u3092\u898B\u6F01\u3063\u3066\u308B\u3051\u3069\u30D1\u30E9\u30CE\u30A4\u30A2\u306EGM\u3084\u308A\u305F\u3059\u304E\u308B\u3067\u3057\u3087",
  "id" : 529295617852309506,
  "created_at" : "2014-11-03 15:34:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529295244131434496",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u304F\u306A\u308B\u30B7\u30B9\u30C6\u30E0\u3068\u7720\u305F\u304F\u306A\u308B\u30B7\u30B9\u30C6\u30E0\u306E\u529F\u7F6A",
  "id" : 529295244131434496,
  "created_at" : "2014-11-03 15:33:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529294454302052353",
  "text" : "\u982D\u56DE\u3089\u306A\u3044(\u9996\u304C\u3042\u308B\u304B\u3089)",
  "id" : 529294454302052353,
  "created_at" : "2014-11-03 15:30:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529294189020733441",
  "text" : "\u9593\u9055\u3063\u305F\u3089\u3054\u3081\u3093\u306A\u3055\u3044\u3001\u5206\u304B\u3089\u306A\u304B\u3063\u305F\u3089\u308F\u304B\u308A\u307E\u305B\u3093",
  "id" : 529294189020733441,
  "created_at" : "2014-11-03 15:29:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529293968509382656",
  "text" : "\u919C\u3044\u53E3\u8AD6\u306F\u307F\u306B\u304F\u3044",
  "id" : 529293968509382656,
  "created_at" : "2014-11-03 15:28:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529220308385816576",
  "geo" : { },
  "id_str" : "529226325567881216",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u3053\u308F\u3044",
  "id" : 529226325567881216,
  "in_reply_to_status_id" : 529220308385816576,
  "created_at" : "2014-11-03 10:59:23 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/529209464843272194\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/Ppcyztn0tU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ghNEBCAAIgNbC.jpg",
      "id_str" : "529209464516116482",
      "id" : 529209464516116482,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ghNEBCAAIgNbC.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Ppcyztn0tU"
    } ],
    "hashtags" : [ {
      "text" : "\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529209464843272194",
  "text" : "#\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7 http:\/\/t.co\/Ppcyztn0tU",
  "id" : 529209464843272194,
  "created_at" : "2014-11-03 09:52:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529118799711043584",
  "text" : "\u3059\u3067\u306B\u4E8C\u4EBA\u3044\u308B\u3093\u3067\u3059\u304C\u305D\u308C\u306F",
  "id" : 529118799711043584,
  "created_at" : "2014-11-03 03:52:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529118595746234368",
  "text" : "\u3082\u3046\u3053\u308C\u96EA\u306A\u3093\u3058\u3083",
  "id" : 529118595746234368,
  "created_at" : "2014-11-03 03:51:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529109299025305600",
  "geo" : { },
  "id_str" : "529118529555935232",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u30D1\u30B5\u30FC\u30B8\u30E5\uFF0C\u304A\u524D\u3060\u3063\u305F\u306E\u304B\uFF0C\u3044\u3064\u3082\u5730\u9707\u3092\u6B62\u3081\u3066\u3044\u3066\u304F\u308C\u305F\u306E\u306F",
  "id" : 529118529555935232,
  "in_reply_to_status_id" : 529109299025305600,
  "created_at" : "2014-11-03 03:51:02 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529097922479013890",
  "text" : "\u3086\u308C",
  "id" : 529097922479013890,
  "created_at" : "2014-11-03 02:29:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/528947674989342720\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/fzDGsDpxW6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1czG4kCQAAuRtR.jpg",
      "id_str" : "528947674595082240",
      "id" : 528947674595082240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1czG4kCQAAuRtR.jpg",
      "sizes" : [ {
        "h" : 1149,
        "resize" : "fit",
        "w" : 808
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 853,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1149,
        "resize" : "fit",
        "w" : 808
      } ],
      "display_url" : "pic.twitter.com\/fzDGsDpxW6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528947674989342720",
  "text" : "\u72A0\u7272\u2026 http:\/\/t.co\/fzDGsDpxW6",
  "id" : 528947674989342720,
  "created_at" : "2014-11-02 16:32:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528911966090170369",
  "text" : "\u5207\u3063\u3066\u30B9\u30AD\u30E3\u30F3\u3057\u3066\u308B\u6642\u306B\u6C17\u3065\u3044\u305F\u3051\u3069\u30C7\u30FC\u30BF\u3067\u5927\u5207\u306B\u4FDD\u7BA1\u3059\u308C\u3070\u306A\u3093\u306E\u554F\u984C\u3082\u306A\u3044\u3001\u3044\u3044\u306D\uFF1F",
  "id" : 528911966090170369,
  "created_at" : "2014-11-02 14:10:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528911689270308864",
  "text" : "\u300C\u4FEE\u4E86\u3059\u308B\u307E\u3067\u5927\u5207\u306B\u4FDD\u7BA1\u3057\u3066\u4E0B\u3055\u3044\u300D\u3063\u3066\u66F8\u3044\u3066\u3042\u308B\u4FBF\u89A7\u3082\u3001\u706B\u306E\u524D\u306B\u306F\u7121\u529B\u306A\u3093\u3060\u305C",
  "id" : 528911689270308864,
  "created_at" : "2014-11-02 14:09:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528905687909167104",
  "text" : "\u3048\u3093\u3069\u90B8\u4E09\u5927\u7A4D\u3093\u8AAD\u30B7\u30EA\u30FC\u30BA\u306E\u4E00\u3064\u3001\u30A2\u30E9\u30D3\u30A2\u30F3\u30CA\u30A4\u30C8\u3092\u88C1\u65AD\u3057\u305F",
  "id" : 528905687909167104,
  "created_at" : "2014-11-02 13:45:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528905514827005953",
  "text" : "\u8AAD\u66F8\u306F\u8840\u8089\u306B\u306A\u308B\u304B\u3089\u2026(\u9707\u3048\u58F0)",
  "id" : 528905514827005953,
  "created_at" : "2014-11-02 13:44:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528871589878591490",
  "geo" : { },
  "id_str" : "528876588536848384",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u308F\u304B\u308A\u3059\u304E\u308B",
  "id" : 528876588536848384,
  "in_reply_to_status_id" : 528871589878591490,
  "created_at" : "2014-11-02 11:49:39 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528869729113366529",
  "text" : "\u3042\u30FC",
  "id" : 528869729113366529,
  "created_at" : "2014-11-02 11:22:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528869708888424448",
  "text" : "\u3042\u30FC\u3063\u3066\u3044\u3046\u306E\u306F\u56FD\u6C11\u5168\u54E1\u306B\u5E73\u7B49\u306B\u4E0E\u3048\u3089\u308C\u305F\u6A29\u5229\u3060\u304B\u3089\u306A\uFF0C\u4ECA\u65E5\u3082\u80F8\u3092\u5F35\u3063\u3066\u3042\u30FC\u3063\u3066\u8A00\u304A\u3046",
  "id" : 528869708888424448,
  "created_at" : "2014-11-02 11:22:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528869501580763136",
  "text" : "\u30BB\u30F3\u30B9\u30AA\u30D6\u30E6\u30FC\u30E2\u30A2\u3092\u8003\u3048\u3055\u305B\u3089\u308C\u308BSNS",
  "id" : 528869501580763136,
  "created_at" : "2014-11-02 11:21:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528860220131250178",
  "text" : "\u3068\u3044\u3046\u304B\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7\uFF0C2\u65E5\u76EE\u306B\u3057\u306650RT\u8FD1\u304F\u4F38\u3073\u3066\u308B\u306E\uFF0C\u30CF\u30FC\u30C9\u30EB\u3042\u304C\u308A\u3059\u304E\u3060\u3068\u601D\u3046\u306A\uFF1F",
  "id" : 528860220131250178,
  "created_at" : "2014-11-02 10:44:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528858955745722368",
  "text" : "\u9006\u8AAC",
  "id" : 528858955745722368,
  "created_at" : "2014-11-02 10:39:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528858366248878081",
  "text" : "\u9069\u6027\u3068\u304B\u8A00\u3046\u306E\u8003\u3048\u308C\u3070\u8003\u3048\u308B\u307B\u3069\u8003\u3048\u306A\u3044\u307B\u3046\u304C\u5E78\u305B\u4F55\u3058\u3083\u306A\u3044\u304B\u3068\u3044\u3046\u6C17\u304C\u3057\u3066\u3057\u307E\u3046",
  "id" : 528858366248878081,
  "created_at" : "2014-11-02 10:37:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528857844645244930",
  "geo" : { },
  "id_str" : "528857986463068161",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u6162\u5FC3\u3057\u306A\u3051\u308C\u3070\u826F\u3044\u306E\u3067\u3059\u304C\u4EBA\u9593\u7D50\u69CB\u6162\u5FC3\u3059\u308B\u306E\u3067...",
  "id" : 528857986463068161,
  "in_reply_to_status_id" : 528857844645244930,
  "created_at" : "2014-11-02 10:35:44 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528857671676342272",
  "text" : "\u50D5\u306F\u300C\u50D5\u306F\u6559\u5E2B\u306B\u5411\u3044\u3066\u3044\u308B\u300D\u307F\u305F\u3044\u306A\u6559\u5E2B\u306B\u6559\u308F\u308A\u305F\u304F\u306A\u3044\u3057\u300C\u50D5\u306F\u533B\u8005\u306B\u5411\u3044\u3066\u3044\u308B\u300D\u3068\u601D\u3063\u3066\u308B\u533B\u8005\u306B\u7F79\u308A\u305F\u304F\u306A\u3044\u3067\u3059",
  "id" : 528857671676342272,
  "created_at" : "2014-11-02 10:34:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528857454616932353",
  "text" : "\u81EA\u5206\u3067\u5411\u3044\u3066\u3044\u308B\u3068\u601D\u3046\u3082\u306E\u3092\u3084\u308B\u306E\uFF0C\u6016\u3044\u3067\u3057\u3087",
  "id" : 528857454616932353,
  "created_at" : "2014-11-02 10:33:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528856492359680000",
  "text" : "\u8239\u5CA1\u6E29\u6CC9\u306E\u3042\u3068\u306E\u30AC\u30ED\u306E\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u306E\u6D41\u308C\uFF0C\u3082\u3046\u4E8C\u5EA6\u3068\u3084\u308C\u306A\u3044\u3093\u3060\u308D\u3046\u306A\u3068\u601D\u3046\u306B\u3064\u3051\u3066\u61D0\u304B\u3057\u60B2\u3057\u3044",
  "id" : 528856492359680000,
  "created_at" : "2014-11-02 10:29:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528848564978348032",
  "text" : "\u5148\u8F29\u306B\u8336\u8449\u304C\u3042\u308B\u306E\u306B\u6025\u9808\u304C\u306A\u3044\u3053\u3068\u3092\u6307\u6458\u3055\u308C\u305F\u6642\u306B\u300C\u3070\uFF0C\u4E07\u4E8B\u4F11\u3059\u3067\u3059\u306D\u300D\u3063\u3066\u8A00\u3063\u305F\u306E\u4ECA\u3067\u3082\u308F\u308A\u3068\u5F8C\u6094\u3057\u3066",
  "id" : 528848564978348032,
  "created_at" : "2014-11-02 09:58:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528847881273237504",
  "geo" : { },
  "id_str" : "528848157547827200",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u3044\u3084\uFF0C\u8E0F\u307F\u3068\u3069\u307E\u308B\u3079\u304D\u3067\u3042\u308B\u3068\u8A00\u3046\u5224\u65AD\u3068\uFF0C\u5B9F\u969B\u306B\u8E0F\u307F\u3068\u3069\u307E\u308B\u304B\u306F\u7D50\u69CB\u72EC\u7ACB\u3060\u3088\u306D\u30FC\u898B\u305F\u3044\u306A\u8A71\u3067\u3059",
  "id" : 528848157547827200,
  "in_reply_to_status_id" : 528847881273237504,
  "created_at" : "2014-11-02 09:56:40 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528847716328038400",
  "text" : "\u304B\u3050\u3084\u59EB\u306F\u672C\u5F53\u306F\u6708\u306B\u5E30\u3063\u305F\u308F\u3051\u3058\u3083\u306A\u3044\u306E\u3067\u306F\uFF1F\u3063\u3066\u8A00\u308F\u308C\u305F\u6C17\u5206\u3060",
  "id" : 528847716328038400,
  "created_at" : "2014-11-02 09:54:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528847438950305794",
  "geo" : { },
  "id_str" : "528847560392183808",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u3055\u3041...",
  "id" : 528847560392183808,
  "in_reply_to_status_id" : 528847438950305794,
  "created_at" : "2014-11-02 09:54:18 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528847435724898304",
  "text" : "\u50D5\u3082\u8A00\u308F\u306A\u3044\u307B\u3046\u304C\u3044\u3044\u306A\u30FC\u3063\u3066\u601D\u3046\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3044\u30C0\u30B8\u30E3\u30EC\u8A00\u3063\u3061\u3083\u3046",
  "id" : 528847435724898304,
  "created_at" : "2014-11-02 09:53:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528847104987246593",
  "geo" : { },
  "id_str" : "528847163711688705",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u826F\u304B\u3063\u305F\u3067\u3059\u306D\uFF0C\u8E0F\u307F\u3068\u3069\u307E\u3063\u3066\uFF0E",
  "id" : 528847163711688705,
  "in_reply_to_status_id" : 528847104987246593,
  "created_at" : "2014-11-02 09:52:43 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528846912997163008",
  "text" : "\u300C\u4FFA\u306F\u304B\u3063\u3071\u5DFB\u304D\u306E\u8A71\u3092\u3057\u3066\u3044\u308B\u3093\u3060\u300D\u3063\u3066\u8A00\u3046\u3079\u304D\u3060\u3063\u305F\u306E\u304B",
  "id" : 528846912997163008,
  "created_at" : "2014-11-02 09:51:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528846753492000768",
  "text" : "\u304B\u3063\u3071\u5DFB\u304D\u306E\u8A71\u3057\u3066\u308B\u3068\u304D\u306B\u5800\u5317\u771F\u5E0C\u306E\u8A71\u59CB\u3081\u308B\u4EBA\u30E4\u30D0\u3044",
  "id" : 528846753492000768,
  "created_at" : "2014-11-02 09:51:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528846540794630145",
  "text" : "\u3042\u308C\u3067\u3082\u3042\u306E\u8A31\u53EF\u8A3C\u306F\u6CB3\u7AE5\u306B\u66B4\u884C\u3092\u52A0\u3048\u306A\u3044\u3053\u3068\u3092\u7D04\u675F\u3055\u305B\u3066\u305F\u6C17\u3082\u3059\u308B\u3057\uFF0C\u3042\u304F\u307E\u3067\u30DC\u30E9\u30F3\u30C6\u30A3\u30A2\u3068\u3057\u3066\u304B\u3063\u3071\u306B\u63E1\u3089\u308C\u3066\u3082\u3089\u3046\u3057\u304B\u306A\u3044\u306E\u304B",
  "id" : 528846540794630145,
  "created_at" : "2014-11-02 09:50:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528846331343679490",
  "text" : "\u6CB3\u7AE5\u62FF\u6355\u8A31\u53EF\u8A3C\u304C\u306A\u3044\u3068\u304B\u3063\u3071\u5DFB\u304D\u3092\u4F5C\u308C\u306A\u3044\u53EF\u80FD\u6027\u306B\u6C17\u3065\u3044\u3066\u3057\u307E\u3063\u305F",
  "id" : 528846331343679490,
  "created_at" : "2014-11-02 09:49:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528846135327064064",
  "geo" : { },
  "id_str" : "528846251488329728",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u304B\u3063\u3071\u5DFB\u304D\u306E\u5DFB\u304D\u629C\u304D\u306F...",
  "id" : 528846251488329728,
  "in_reply_to_status_id" : 528846135327064064,
  "created_at" : "2014-11-02 09:49:06 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528845791880675328",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 528845791880675328,
  "created_at" : "2014-11-02 09:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528845757126684672",
  "text" : "\u7AF9\u53D6\u7269\u8A9E\u3092\u8A3C\u660E\u3057\u308D\uFF0C\u3063\u3066\u8A00\u308F\u308C\u305F\u6C17\u5206\u3060",
  "id" : 528845757126684672,
  "created_at" : "2014-11-02 09:47:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 3, 13 ],
      "id_str" : "531198661",
      "id" : 531198661
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 15, 25 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528845654206840832",
  "text" : "RT @yassu0320: @end313124 \u554F: \u6307\u6570\u304C1\u3088\u308A\u5C0F\u3055\u3044\u7B49\u6BD4\u6570\u5217\u3067\u4E0A\u304B\u3089\u8A55\u4FA1\u3067\u304D\u308B\u9762\u7A4D\u3092\u3082\u3064\u3088\u3046\u306A\u3001\u7121\u9650\u52A0\u7B97\u500B\u306E\u3053\u3068\u306A\u308B\u53E3\u5185\u708E\u306E\u5217\u306F\u5B58\u5728\u3057\u306A\u3044\u3053\u3068\u3092\u793A\u305B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "528818513624842240",
    "geo" : { },
    "id_str" : "528845202509688834",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u554F: \u6307\u6570\u304C1\u3088\u308A\u5C0F\u3055\u3044\u7B49\u6BD4\u6570\u5217\u3067\u4E0A\u304B\u3089\u8A55\u4FA1\u3067\u304D\u308B\u9762\u7A4D\u3092\u3082\u3064\u3088\u3046\u306A\u3001\u7121\u9650\u52A0\u7B97\u500B\u306E\u3053\u3068\u306A\u308B\u53E3\u5185\u708E\u306E\u5217\u306F\u5B58\u5728\u3057\u306A\u3044\u3053\u3068\u3092\u793A\u305B",
    "id" : 528845202509688834,
    "in_reply_to_status_id" : 528818513624842240,
    "created_at" : "2014-11-02 09:44:56 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "protected" : false,
      "id_str" : "531198661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530419481680433152\/bA0D4cjv_normal.jpeg",
      "id" : 531198661,
      "verified" : false
    }
  },
  "id" : 528845654206840832,
  "created_at" : "2014-11-02 09:46:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528829946513199104",
  "text" : "JR\u306F\u4F01\u696D\u3067\u3042\u3063\u3066\u4E57\u308A\u7269\u3067\u306A\u3044",
  "id" : 528829946513199104,
  "created_at" : "2014-11-02 08:44:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528829880406781952",
  "text" : "\u30AB\u30C6\u30B4\u30EA\u30FC\u30DF\u30B9\u30C6\u30A4\u30AF7\u6BB5",
  "id" : 528829880406781952,
  "created_at" : "2014-11-02 08:44:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50\u3044\u305F\u308A\u3042\u2B50",
      "screen_name" : "_Italia3",
      "indices" : [ 0, 9 ],
      "id_str" : "510117176",
      "id" : 510117176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528827855388434432",
  "geo" : { },
  "id_str" : "528827934232952832",
  "in_reply_to_user_id" : 510117176,
  "text" : "@_Italia3 \u6C38\u9060\u306B\u4F1A\u3048\u306A\u3044\u306E\u3067\u306F",
  "id" : 528827934232952832,
  "in_reply_to_status_id" : 528827855388434432,
  "created_at" : "2014-11-02 08:36:19 +0000",
  "in_reply_to_screen_name" : "_Italia3",
  "in_reply_to_user_id_str" : "510117176",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528824041964965888",
  "text" : "\u4E8C\u6B21\u5143\u3068\u4E09\u6B21\u5143\uFF0C\u305F\u3076\u3093\u6B21\u5143\u304C\u9055\u3046\uFF0E\u9055\u3063\u305F\u3089\u3059\u307F\u307E\u305B\u3093\uFF0E",
  "id" : 528824041964965888,
  "created_at" : "2014-11-02 08:20:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528821334826971137",
  "text" : "\u305D\u308C\u3082\u3046\u53E3\u5916\u708E\u3060",
  "id" : 528821334826971137,
  "created_at" : "2014-11-02 08:10:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528821293840228353",
  "text" : "\u81EA\u660E\u306A\u53E3\u5185\u708E\u3068\u3057\u3066\u9762\u7A4D0\u306E\u53E3\u5185\u708E\u3092\u5B9A\u7FA9\u3059\u308B\u3068\u53E3\u5916\u306B\u3082\u53E3\u5185\u708E\u304C\u51FA\u6765\u308B\u306E\u3067\u306F",
  "id" : 528821293840228353,
  "created_at" : "2014-11-02 08:09:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528821001681764353",
  "text" : "\u3068\u3044\u3046\u304B\u53E3\u5185\u708E\u3063\u3066\u7ACB\u4F53\u7684\u3058\u3083\u306A\u3044\u304B\uFF0E\u4F53\u7A4D0\u3092\u8A00\u3046\u3079\u304D\u3067\u306F\u306A\u3044\u304B\uFF0E",
  "id" : 528821001681764353,
  "created_at" : "2014-11-02 08:08:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528820900993302528",
  "text" : "RT @: \u9762\u7A4D0\u306E\u53E3\u5185\u708E\u304C\u53EF\u7B97\u500B\u5B58\u5728\u3059\u308B\u53EF\u80FD\u6027\u306A\u3044\u306E\u304B.",
  "id" : 528820900993302528,
  "created_at" : "2014-11-02 08:08:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528819959191724032",
  "text" : "\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7\uFF0C\u307E\u30602\u65E5\u76EE\u3060\u3051\u3069\u4E00\u5B9A\u306E\u30AF\u30AA\u30EA\u30C6\u30A3\u3092\u4FDD\u3063\u3066\u308B\u611F\u3058\u3042\u308B\u3057\uFF0C\u666E\u6BB5\u3044\u304B\u306B\u30A4\u30A4\u30CF\u30CA\u30B7\u3092\u751F\u7523\u3057\u3066\u3044\u308B\u304B\u3092\u5B9F\u611F\u51FA\u6765\u308B",
  "id" : 528819959191724032,
  "created_at" : "2014-11-02 08:04:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/528818513624842240\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/lHwAx4KxyK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1a9otQCEAAgwJ8.jpg",
      "id_str" : "528818513301868544",
      "id" : 528818513301868544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1a9otQCEAAgwJ8.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/lHwAx4KxyK"
    } ],
    "hashtags" : [ {
      "text" : "\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528818513624842240",
  "text" : "#\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7 http:\/\/t.co\/lHwAx4KxyK",
  "id" : 528818513624842240,
  "created_at" : "2014-11-02 07:58:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 17, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528817601795747841",
  "text" : "\u53E3\u5185\u306B\u53EF\u7B97\u7121\u9650\u500B\u306E\u53E3\u5185\u708E\u304C\u3042\u308B\u4EBA #\u4EBA",
  "id" : 528817601795747841,
  "created_at" : "2014-11-02 07:55:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528805675812388864",
  "text" : "\uFF96\uFF96\uFF96\uFF96\uFF72\uFF96NF\u3067\u306A\u3093\u304B\u3084\u3089\u306A\u3044\u306E",
  "id" : 528805675812388864,
  "created_at" : "2014-11-02 07:07:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528801008323813376",
  "text" : "\u3054\u306B\u3087\u3054\u306B\u3087\u3054\u306B\u3087",
  "id" : 528801008323813376,
  "created_at" : "2014-11-02 06:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528793999604060161",
  "text" : "\u300C\u304A\u524D\u306F\u4F55\u3067\u3082\u77E5\u3063\u3066\u308B\u306A\u3041\u300D\n\u300C\u306A\u3093\u3067\u3082\u306F\u77E5\u3089\u306A\u3044\u304C\uFF0C\u304A\u524D\u3088\u308A\u306F\u306A\u300D",
  "id" : 528793999604060161,
  "created_at" : "2014-11-02 06:21:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528793038001172480",
  "text" : "\u300C\u8077\u696D\uFF1A\u30C9\u30E9\u30B4\u30F3\u300D\u306E\u9055\u548C\u611F",
  "id" : 528793038001172480,
  "created_at" : "2014-11-02 06:17:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528762696645111809",
  "text" : "\u5FC5\u305A\u3057\u3082\u304A\u3044\u3057\u3044\u3068\u306F\u9650\u3089\u306A\u3044\u725B\u4E73",
  "id" : 528762696645111809,
  "created_at" : "2014-11-02 04:17:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528735630813958144",
  "geo" : { },
  "id_str" : "528735855305699328",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306A\u308B\u307B\u3069\u3001\u30B3\u30F3\u30B5\u30FC\u30C8\u7684\u306A\u3042\u308C\uFF1F",
  "id" : 528735855305699328,
  "in_reply_to_status_id" : 528735630813958144,
  "created_at" : "2014-11-02 02:30:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528735204970479616",
  "geo" : { },
  "id_str" : "528735414824087554",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3046\u3075\u3001\u307E\u305F\u6765\u308B\u6642\u306F\u9023\u7D61\u3057\u3066\u304F\u308C\u30FC",
  "id" : 528735414824087554,
  "in_reply_to_status_id" : 528735204970479616,
  "created_at" : "2014-11-02 02:28:40 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528734298019758080",
  "geo" : { },
  "id_str" : "528734832717611008",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u672D\u5E4C\u306B\u3044\u308B\u306E\u304B",
  "id" : 528734832717611008,
  "in_reply_to_status_id" : 528734298019758080,
  "created_at" : "2014-11-02 02:26:22 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528492526383022080",
  "geo" : { },
  "id_str" : "528504662672961537",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u3042\u308C\u304B\u3089\u7D06\u4F59\u66F2\u6298\u3042\u3063\u305F\u3093\u3060\u2026\u307E\u305F\u8A98\u3046\u3088",
  "id" : 528504662672961537,
  "in_reply_to_status_id" : 528492526383022080,
  "created_at" : "2014-11-01 11:11:45 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528488017174855682",
  "text" : "\u60AA\u8CEA\u306A\u4E2D\u5B66\u751F\u3060\u3063\u305F\u304B\u3089\u306A\u3093\u3068\u304B\u30CA\u30EB\u30C9\u3067\u983C\u3093\u3060\u3053\u3068\u304C\u3042\u3063\u305F",
  "id" : 528488017174855682,
  "created_at" : "2014-11-01 10:05:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528487833950896128",
  "text" : "\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u306E\u30D0\u30F3\u30BA\u629C\u304D",
  "id" : 528487833950896128,
  "created_at" : "2014-11-01 10:04:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528487697107546112",
  "text" : "\u30AB\u30EA\u30D5\u30A9\u30EB\u30CB\u30A2\u30ED\u30FC\u30EB\u306E\u30AB\u30EA\u30D5\u30A9\u30EB\u30CB\u30A2\u629C\u304D",
  "id" : 528487697107546112,
  "created_at" : "2014-11-01 10:04:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528487479863570432",
  "text" : "\u30E2\u30C0\u30F3\u713C\u304D\u306E\uFF01\uFF01\uFF01\uFF01\u30E2\u30C0\u30F3\u629C\u304D\u3067\uFF01\uFF01\u304A\u9858\u3044\u3057\u307E\u3059\uFF01\uFF01\uFF01\uFF01",
  "id" : 528487479863570432,
  "created_at" : "2014-11-01 10:03:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528487117324693504",
  "text" : "\u4ECA\u9031\u306E\u304A\u597D\u307F\u713C\u304D\u98DF\u3079\u305F\u3055\u3092\u89E3\u6D88\u3059\u308B\u3079\u304F\u304A\u597D\u307F\u713C\u304D\u5C4B\u3055\u3093\u306B\u6765\u305F",
  "id" : 528487117324693504,
  "created_at" : "2014-11-01 10:02:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/528471898183589889\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/HAgc6gR3wG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1WCZCCCMAEUuy9.jpg",
      "id_str" : "528471897839644673",
      "id" : 528471897839644673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1WCZCCCMAEUuy9.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HAgc6gR3wG"
    } ],
    "hashtags" : [ {
      "text" : "\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528471898183589889",
  "text" : "#\u4ECA\u65E5\u306E\u30A4\u30A4\u30CF\u30CA\u30B7 http:\/\/t.co\/HAgc6gR3wG",
  "id" : 528471898183589889,
  "created_at" : "2014-11-01 09:01:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528361996249358336",
  "geo" : { },
  "id_str" : "528362131284975616",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u3060\u304B\u3089\u3069\u3063\u3061\u3067\u3082\u5927\u5DEE\u306A\u3044\u306E\u3067\u306F\u3068",
  "id" : 528362131284975616,
  "in_reply_to_status_id" : 528361996249358336,
  "created_at" : "2014-11-01 01:45:23 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528356276959334401",
  "geo" : { },
  "id_str" : "528359435773558784",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u3093\u30FC\u3001\u597D\u304D\u306A\u65B9\u3067\u3044\u3044\u306E\u3067\u306F",
  "id" : 528359435773558784,
  "in_reply_to_status_id" : 528356276959334401,
  "created_at" : "2014-11-01 01:34:40 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528202668078944257",
  "text" : "\uFF08\u8A00\u8A9E\u30B9\u30AD\u30EB\u304C\u4F4E\u3044\u4EBA\u304C\u3044\u308B\u306E\u306F\u3055\u3066\u304A\u3044\u3066\u3082\uFF09\u4EAC\u90FD\u306B\u3044\u305F\u6642\u3088\u308A\u201D\u7279\u5B9A\u306E\u30EF\u30FC\u30C9\u304C\u901A\u3058\u306A\u3044\u6848\u4EF6\u201D\u304C\u591A\u3044\u6C17\u304C\u3057\u3066\u77E5\u8B58\u306E\u504F\u308A\u3092\u611F\u3058\u308B",
  "id" : 528202668078944257,
  "created_at" : "2014-10-31 15:11:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528201476493955072",
  "text" : "\u97F3\u30B2\u30FC\u3084\u3089\u306A\u3044\u306E\u306B\u97F3\u30B2\u30FC\u7528\u8A9E\u77E5\u8B58\u3060\u3051\u304C\u624B\u5143\u306B\u3042\u308B\u4EBA\u751F\u3060\u3063\u305F",
  "id" : 528201476493955072,
  "created_at" : "2014-10-31 15:07:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528201245027078144",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u8EAB\u8FD1\u306A\u30E9\u30D6\u30E9\u30A4\u30D0\u30FC\u304C\u300C\u3053\u306E\u66F2\u51FA\u6765\u306A\u3044\u3088\u30FC\u300D\u307F\u305F\u3044\u306A\u3053\u3068\u8A00\u3063\u3066\u305F\u304B\u3089\u300C\u7C98\u7740\u304C\u8DB3\u308A\u306A\u3044\u306E\u3067\u306F\uFF1F\u300D\u3063\u3066\u717D\u3063\u305F\u3089\u201D\u7C98\u7740\u201D\u3068\u3044\u3046\u30EF\u30FC\u30C9\u304C\u901A\u3058\u306A\u304B\u3063\u305F\u3093\u3060\u3051\u3069\u3053\u308C\u306A\u3093\u3067",
  "id" : 528201245027078144,
  "created_at" : "2014-10-31 15:06:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528199780963340288",
  "text" : "\u3053\u306E\u969B\u307E\u3068\u3081\u3066\u53E4\u672C\u3067\u8CB7\u3063\u3066\u3057\u307E\u3046\u304B",
  "id" : 528199780963340288,
  "created_at" : "2014-10-31 15:00:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]