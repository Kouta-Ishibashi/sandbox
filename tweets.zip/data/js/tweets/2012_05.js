Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208166042000826369",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 208166042000826369,
  "created_at" : "2012-05-31 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208037440110329856",
  "text" : "\u30DE\u30C3\u30C4\u306A\u3046",
  "id" : 208037440110329856,
  "created_at" : "2012-05-31 03:29:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208037344098516993",
  "text" : "\u601D\u3048\u3070\u4E45\u3005\u306E",
  "id" : 208037344098516993,
  "created_at" : "2012-05-31 03:29:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208036379538620419",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u3092\u624B\u306B\u5165\u308C\u305F",
  "id" : 208036379538620419,
  "created_at" : "2012-05-31 03:25:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208024641082621952",
  "text" : "\u30EB\u30CD\u3067\u6570\u5B66\u30AC\u30FC\u30EB\u3042\u3063\u305F\u3089\u8CB7\u3063\u3066\u3053\u3088\u3046",
  "id" : 208024641082621952,
  "created_at" : "2012-05-31 02:38:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208023615269109763",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 208023615269109763,
  "created_at" : "2012-05-31 02:34:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207899610809778176",
  "text" : "\u4ECA\u3072\u3068\u3064",
  "id" : 207899610809778176,
  "created_at" : "2012-05-30 18:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207899414545702912",
  "text" : "\u3080\u3057\u308D\u4F55\u304B\u3092\u5480\u56BC\u3057\u305F\u3044",
  "id" : 207899414545702912,
  "created_at" : "2012-05-30 18:20:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207899350712590336",
  "text" : "\u7A7A\u8179\u3092\u8A34\u8A1F\u3059\u308B(\u8A34\u3048\u308B)",
  "id" : 207899350712590336,
  "created_at" : "2012-05-30 18:20:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207898873144934400",
  "text" : "\u53EF\u80FD\u306A\u30893\u9650\u3082",
  "id" : 207898873144934400,
  "created_at" : "2012-05-30 18:18:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207898791343427584",
  "text" : "4\u9650\u3055\u3048\u51FA\u308C\u308C\u3070\u3082\u3046\u3044\u3044\u3084",
  "id" : 207898791343427584,
  "created_at" : "2012-05-30 18:18:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207896041301884928",
  "geo" : { },
  "id_str" : "207896291651502080",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 207896291651502080,
  "in_reply_to_status_id" : 207896041301884928,
  "created_at" : "2012-05-30 18:08:33 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207895730197757952",
  "text" : "\u4E45\u3005\u306B\u30A4\u30E4\u30DB\u30F3\u3067\u97F3\u697D\u805E\u304D\u3064\u3064\u52C9\u5F37\u3057\u305F\u304C\u60AA\u304F\u306A\u3044\u306A",
  "id" : 207895730197757952,
  "created_at" : "2012-05-30 18:06:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207895509468315648",
  "text" : "\u4ECA\u6708\u307E\u3067\u306E\u30EC\u30DD\u30FC\u30C8\u3060\u3055\u306A",
  "id" : 207895509468315648,
  "created_at" : "2012-05-30 18:05:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3068\u3063\u3066\u3064\u3051\u305F\u3088\u3046\u306A\u5408\u7406\u5316",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207895132786274304",
  "text" : "\u76EE\u6A19\u306E\u76EE\u524D\u3067\u8AE6\u3081\u308B\u3053\u3068\u3067\u52A3\u7B49\u611F\u3068\u7F6A\u60AA\u611F\u3092\u6B8B\u3057\u3064\u3064\u8D77\u304D\u3066\u304B\u3089\u306E\u52C9\u5F37\u306B\u7E4B\u3052\u308B\u30D7\u30EC\u30A4\u30F3\u30B0 #\u3068\u3063\u3066\u3064\u3051\u305F\u3088\u3046\u306A\u5408\u7406\u5316",
  "id" : 207895132786274304,
  "created_at" : "2012-05-30 18:03:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207894728224686080",
  "text" : "\u306D\u3080\u3044\u3042\u305F\u307E\u3067\u306F\u96E3\u3057\u3044\u3068\u3044\u3046\u7D50\u8AD6\u3067\u3042\u3068\u534A\u30DA\u30FC\u30B8\u306F\u4ECA\u65E5\u8D77\u304D\u3066\u304B\u3089\u3084\u308B\u3053\u3068\u306B",
  "id" : 207894728224686080,
  "created_at" : "2012-05-30 18:02:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207893306217201664",
  "text" : "\u305D\u3053\u306B\u6570\u5F0F\u304C\u3042\u308B\u3067\uFF01",
  "id" : 207893306217201664,
  "created_at" : "2012-05-30 17:56:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207893240362450944",
  "text" : "\u300C\u25EF\u25EF\u304B\u3089\u300D\u3092\u60F3\u5B9A\u3055\u308C\u305Fbot\u306E\u3064\u3076\u3084\u304D\u304C\u300C\u25EF\u25EF\u3067\u300D\u3063\u3066\u3067\u308B\u305B\u3044\u3067\u95A2\u897F\u5F01\u3063\u307D\u3044",
  "id" : 207893240362450944,
  "created_at" : "2012-05-30 17:56:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207892448029065217",
  "text" : "\u304B\u3068\u8A00\u3063\u3066\u3044\u3061\u3044\u3061\u81EA\u5206\u3067\u5909\u63DB\u3059\u308B\u306E\u3082\u306A\u30FC\u30FB\u8A66\u9A13\u524D\u306B\u5ACC\u3005\u3084\u308B\u304B\u2026",
  "id" : 207892448029065217,
  "created_at" : "2012-05-30 17:53:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207892170164805632",
  "text" : "@kotorin_z \u304A\u3084\u3074\u3088\u306A\u3055\u3044\u307E\u305B",
  "id" : 207892170164805632,
  "created_at" : "2012-05-30 17:52:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207892119598272513",
  "text" : "@i_horse \u5168\u304F\u6301\u3063\u3066\u305D\u308C\u306A",
  "id" : 207892119598272513,
  "created_at" : "2012-05-30 17:51:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207892063264579584",
  "text" : "\u4F11\u8B1B\u306A\u3044(^^)(^^)(^^)",
  "id" : 207892063264579584,
  "created_at" : "2012-05-30 17:51:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207891812126425091",
  "text" : "TeX\u3092\u66F2\u304C\u308A\u306A\u308A\u306B\u3082\u4F7F\u3048\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u304B\u3089\u3042\u3093\u3042\u3093\u307E\u308A\u30EF\u30FC\u30C9\u4F7F\u308F\u306A\u3044\u2026\u3044\u3046\u307B\u3069TeX\u3092\u4F7F\u3044\u3053\u306A\u305B\u3066\u3044\u308B\u308F\u3051\u3067\u3082\u306A\u3044\u3051\u308C\u3069",
  "id" : 207891812126425091,
  "created_at" : "2012-05-30 17:50:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207891511868792832",
  "text" : "\u5B66\u90E8\u306E\u6559\u6388\u8CC7\u6599\u3092\u30EF\u30FC\u30C9\u30D5\u30A1\u30A4\u30EB\u3067\u914D\u308B\u3068\u304B\u2026\u2026\u2026",
  "id" : 207891511868792832,
  "created_at" : "2012-05-30 17:49:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207889491053125632",
  "text" : "\u3075\u3068\u601D\u3063\u305F\u3051\u3069[\u3086]\u3092\u30B8\u30A7\u30CD\u30EC\u30FC\u30BF\u30FC\u306B\u3057\u3066\u306A\u3093\u304B\u30D5\u30E9\u30AF\u30BF\u30EB\u3081\u3044\u305F\u3082\u306E\u3092\u4F5C\u308C\u306A\u3044\u3060\u308D\u3046\u304B",
  "id" : 207889491053125632,
  "created_at" : "2012-05-30 17:41:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207888943373488129",
  "text" : "OnlyMyRailgun\u306F\u6B4C\u3063\u3066\u3066\u697D\u3057\u3044",
  "id" : 207888943373488129,
  "created_at" : "2012-05-30 17:39:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207888503206461440",
  "text" : "\u4F1A\u54E1No.\u03B5",
  "id" : 207888503206461440,
  "created_at" : "2012-05-30 17:37:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207888224843075585",
  "text" : "\u30BC\u30FC\u30BF\u2026",
  "id" : 207888224843075585,
  "created_at" : "2012-05-30 17:36:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207886661919571968",
  "text" : "\u3055\u3063\u304D\u306E\u30CD\u30BF\u3069\u3046\u3057\u3066\u571F\u66DC\u306E\u591C\u307E\u3067\u3068\u3063\u3066\u304A\u3051\u304B\u3063\u305F\u306E\u304B",
  "id" : 207886661919571968,
  "created_at" : "2012-05-30 17:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207886126256619520",
  "text" : "\u610F\u56F3\u305B\u305A\u3044\u308D\u3044\u3068\u308D\u3075\u3041\u307C\u3089\u308C\u3066\u3044\u308B\u30FC",
  "id" : 207886126256619520,
  "created_at" : "2012-05-30 17:28:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885791458897920",
  "text" : "\u30B5\u30BF\u30C7\u30FC\u30CA\u30A4\u30C8\u30D5\u30A1\u30A4\u30D0\u30FC\uFF01",
  "id" : 207885791458897920,
  "created_at" : "2012-05-30 17:26:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885674601398273",
  "text" : "\u30B5\u30BF\u30C7\u30FC\u30CA\u7CF8",
  "id" : 207885674601398273,
  "created_at" : "2012-05-30 17:26:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885510079823873",
  "text" : "\u733F\u3082\u6728\u304B\u3089\u7CF8",
  "id" : 207885510079823873,
  "created_at" : "2012-05-30 17:25:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885421869404160",
  "text" : "@i_horse \u3071\u3089\u3071\u3089\u6F2B\u753B",
  "id" : 207885421869404160,
  "created_at" : "2012-05-30 17:25:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885350536884225",
  "text" : "\u99AC\u306E\u8033\u306B\u7CF8",
  "id" : 207885350536884225,
  "created_at" : "2012-05-30 17:25:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7570\u7269\u6DF7\u5165",
      "indices" : [ 7, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885245096263680",
  "text" : "\u307C\u305F\u9905\u304B\u3089\u7CF8 #\u7570\u7269\u6DF7\u5165",
  "id" : 207885245096263680,
  "created_at" : "2012-05-30 17:24:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885166335639553",
  "text" : "\u7D75\u306B\u63CF\u3044\u305F\u3088\u3046\u306B\u7CF8\u304C\u304D\u308C\u305F",
  "id" : 207885166335639553,
  "created_at" : "2012-05-30 17:24:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885100740919298",
  "text" : "\u7D50\u3093\u3067\u7E4B\u3044\u3067\u7D50\u3063\u3066\u7E4B\u3052\u308B",
  "id" : 207885100740919298,
  "created_at" : "2012-05-30 17:24:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207885034416386048",
  "text" : "\u96C6\u4E2D\u304C\u304D\u308C\u305F\u3088\u3046\u306B\u7CF8\u304C\u304D\u308C\u305F",
  "id" : 207885034416386048,
  "created_at" : "2012-05-30 17:23:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207882185263419392",
  "text" : "\u5727\u5012\u7684\u3082\u3046\u3053\u3093",
  "id" : 207882185263419392,
  "created_at" : "2012-05-30 17:12:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207877060381782018",
  "text" : "\u4FFA\u3053\u306E\u7BC0\u307E\u3068\u3081\u7D42\u3048\u305F\u3089\u3001\u7720\u308B\u3093\u3060\u2026\uFF01",
  "id" : 207877060381782018,
  "created_at" : "2012-05-30 16:52:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207876359622639617",
  "text" : "\u30EA\u30D7\u30E9\u30A4\u304D\u305F\u3089\u5FDC\u7B54\u3067\u304D\u308B\u3051\u3069TL\u306F\u898B\u3048\u306A\u3044\u3068\u3044\u3046\u7D20\u6575\u4ED5\u69D8",
  "id" : 207876359622639617,
  "created_at" : "2012-05-30 16:49:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207876228923932673",
  "text" : "4\u3064\u6307\u3067\u7E70\u308C\u3070Twitter\u3068\u6559\u79D1\u66F8\u304C\u5207\u308A\u66FF\u308F\u308B\u304B\u3089\u5371\u967A",
  "id" : 207876228923932673,
  "created_at" : "2012-05-30 16:48:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207875816950992896",
  "geo" : { },
  "id_str" : "207875977546702848",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u4E86\u89E3\u3067\u3059\u30FC",
  "id" : 207875977546702848,
  "in_reply_to_status_id" : 207875816950992896,
  "created_at" : "2012-05-30 16:47:49 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207872932289052672",
  "text" : "\u61D0\u304B\u3057\u3044\u97F3\u304C\u3059\u308B",
  "id" : 207872932289052672,
  "created_at" : "2012-05-30 16:35:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207872748989587456",
  "text" : "#nowplaying \uFF36\uFF4F\uFF49\uFF43\uFF45 - L'Arc\uFF5Een\uFF5ECiel",
  "id" : 207872748989587456,
  "created_at" : "2012-05-30 16:35:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207864810312962048",
  "text" : "\u8010\u3048\u305F\uFF1F",
  "id" : 207864810312962048,
  "created_at" : "2012-05-30 16:03:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207864686564216833",
  "text" : "\u307E\u306B\u3042\u308F\u305A",
  "id" : 207864686564216833,
  "created_at" : "2012-05-30 16:02:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207864629647511552",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 207864629647511552,
  "created_at" : "2012-05-30 16:02:44 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207862834086944770",
  "text" : "@ayu167 \u904B\u30B2\u30FC\u3060\u304B\u3089\uFF1F",
  "id" : 207862834086944770,
  "created_at" : "2012-05-30 15:55:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207862542113058817",
  "geo" : { },
  "id_str" : "207862734564491264",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u4ECA\u9031\u306F\u3061\u3083\u3093\u3068\u5165\u308C\u307E\u3059\u3088\u30FC",
  "id" : 207862734564491264,
  "in_reply_to_status_id" : 207862542113058817,
  "created_at" : "2012-05-30 15:55:12 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207862038108712960",
  "text" : "@ayu167 \u97F3\u30B2\u30FC\u6BD4",
  "id" : 207862038108712960,
  "created_at" : "2012-05-30 15:52:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207861798542655488",
  "geo" : { },
  "id_str" : "207861975882006529",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u884C\u3051\u307E\u3059\u3088\u30FC\u9375\u306F\u30D0\u30BA\u306B\u3042\u308A\u307E\u3059\uFF1F",
  "id" : 207861975882006529,
  "in_reply_to_status_id" : 207861798542655488,
  "created_at" : "2012-05-30 15:52:11 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207861356425252865",
  "text" : "\u9053\u5177\u3068\u304B\u8010\u4E45\u3068\u304B\u899A\u3048\u308B\u3053\u3068\u304C\u591A\u3059\u304E\u3066\u30A2\u30EC",
  "id" : 207861356425252865,
  "created_at" : "2012-05-30 15:49:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207860662041456641",
  "geo" : { },
  "id_str" : "207861138094952448",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u9069\u5F53\u306AV\u500B\u4F53\u3067A\u306B\u3075\u3063\u3066\u5927\u6280\u3067\u6BB4\u308B\u30B2\u30FC\u30E0\uFF1F",
  "id" : 207861138094952448,
  "in_reply_to_status_id" : 207860662041456641,
  "created_at" : "2012-05-30 15:48:51 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207860574258868224",
  "text" : "\u30DD\u30B1\u30E2\u30F3\u306E\u8A71\u3042\u308B\u7A0B\u5EA6\u308F\u304B\u308B\u3051\u3069\u5BFE\u6226\u3068\u304B\u5168\u7136\u3067\u304D\u306A\u3044\u3075\u3075\u3075",
  "id" : 207860574258868224,
  "created_at" : "2012-05-30 15:46:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207860229872947200",
  "geo" : { },
  "id_str" : "207860446131257346",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u50D5\u306F\u65B9\u6CD5\u8AD6\u3060\u3051\u5B66\u3093\u3067\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3068\u3053\u308D\u3067\u6B62\u307E\u3063\u3066\u3044\u307E\u3059",
  "id" : 207860446131257346,
  "in_reply_to_status_id" : 207860229872947200,
  "created_at" : "2012-05-30 15:46:06 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207860093281251328",
  "text" : "\u3082\u3057\u304B\u3057\u3066:\u30BC\u30DF\u306E\u6E96\u5099\u7D42\u308F\u3063\u3066\u306A\u3044",
  "id" : 207860093281251328,
  "created_at" : "2012-05-30 15:44:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207859610139377664",
  "geo" : { },
  "id_str" : "207859887345111043",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u30DD\u30B1\u30E2\u30F3\u3084\u308B\u3093\u3067\u3059\u304Bw",
  "id" : 207859887345111043,
  "in_reply_to_status_id" : 207859610139377664,
  "created_at" : "2012-05-30 15:43:53 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207761139168329729",
  "text" : "\u30DF\u30B9\u6570\u5B66\u30BF\u30FC\u30C9\u30FC\u30CA\u30C4\u306A\u3046",
  "id" : 207761139168329729,
  "created_at" : "2012-05-30 09:11:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207637598338940928",
  "text" : "\u8D77\u304D\u305F",
  "id" : 207637598338940928,
  "created_at" : "2012-05-30 01:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207441254185832450",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 207441254185832450,
  "created_at" : "2012-05-29 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207375364631179264",
  "text" : "\u3054\u308D\u3054\u308D\u30FC",
  "id" : 207375364631179264,
  "created_at" : "2012-05-29 07:38:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207374914246811648",
  "geo" : { },
  "id_str" : "207375231185195008",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u305F\u307E\u306B\u3042\u308A\u307E\u3059\u306D\u30FC\u3002\u5BDD\u574A\u3059\u308B\u5922\u898B\u3066\u8D77\u304D\u305F\u3089\u76EE\u899A\u307E\u3057\u306A\u308B\u524D\u3060\u3063\u305F\u307F\u305F\u3044\u306A",
  "id" : 207375231185195008,
  "in_reply_to_status_id" : 207374914246811648,
  "created_at" : "2012-05-29 07:38:02 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207374526705696768",
  "text" : "\u610F\u5473\u306A\u3093\u304B\u306A\u3044\u3088",
  "id" : 207374526705696768,
  "created_at" : "2012-05-29 07:35:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207374489443512320",
  "text" : "\u96E8\u8DB3\u3068\u6D77\u725B",
  "id" : 207374489443512320,
  "created_at" : "2012-05-29 07:35:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 3, 17 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/r13fRrm8",
      "expanded_url" : "http:\/\/bit.ly\/KMWt0M",
      "display_url" : "bit.ly\/KMWt0M"
    } ]
  },
  "geo" : { },
  "id_str" : "207374330915590145",
  "text" : "RT @riveriver4361: \u3053\u308C\u3001\u8A66\u5408\u4E2D\u306BTwitter\u3057\u3066\u305F\u3093\u3058\u3083\u306A\u304F\u3066\u3001Twitter\u4E2D\u306B\u8A66\u5408\u3057\u3066\u305F\u3093\u3058\u3083\u306A\u3044\u306E\uFF1F http:\/\/t.co\/r13fRrm8 \u30D0\u30EC\u30F3\u30C6\u30A3\u30F3\u8A66\u5408\u4E2D\u306BTwitter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/r13fRrm8",
        "expanded_url" : "http:\/\/bit.ly\/KMWt0M",
        "display_url" : "bit.ly\/KMWt0M"
      } ]
    },
    "geo" : { },
    "id_str" : "207374079085379584",
    "text" : "\u3053\u308C\u3001\u8A66\u5408\u4E2D\u306BTwitter\u3057\u3066\u305F\u3093\u3058\u3083\u306A\u304F\u3066\u3001Twitter\u4E2D\u306B\u8A66\u5408\u3057\u3066\u305F\u3093\u3058\u3083\u306A\u3044\u306E\uFF1F http:\/\/t.co\/r13fRrm8 \u30D0\u30EC\u30F3\u30C6\u30A3\u30F3\u8A66\u5408\u4E2D\u306BTwitter",
    "id" : 207374079085379584,
    "created_at" : "2012-05-29 07:33:27 +0000",
    "user" : {
      "name" : "\u306F\u3080\u592B",
      "screen_name" : "cricetusmhx2",
      "protected" : false,
      "id_str" : "320494295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597398263998779394\/jzh35zBq_normal.jpg",
      "id" : 320494295,
      "verified" : false
    }
  },
  "id" : 207374330915590145,
  "created_at" : "2012-05-29 07:34:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207373932561575936",
  "geo" : { },
  "id_str" : "207374186384072704",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax (\u305D\u308C\u306F\u4EE5\u4E0A\u306A\u3093\u3058\u3083\u2026)",
  "id" : 207374186384072704,
  "in_reply_to_status_id" : 207373932561575936,
  "created_at" : "2012-05-29 07:33:53 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 12, 28 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207373710536085504",
  "geo" : { },
  "id_str" : "207373985212661760",
  "in_reply_to_user_id" : 138430452,
  "text" : "\u3058\u3047\u308A\u30FC\u304B\u307F\u3085\u304B\u307F\u3085  @Jelly_in_a_tank  QT: \u3074\u3083\u308A\u30FC\u304D\u3083\u307F\u3085\u304D\u3083\u307F\u3085",
  "id" : 207373985212661760,
  "in_reply_to_status_id" : 207373710536085504,
  "created_at" : "2012-05-29 07:33:05 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207373149770219522",
  "geo" : { },
  "id_str" : "207373359149887488",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u6B63\u5E38\u3067\u3057\u3087\u3046",
  "id" : 207373359149887488,
  "in_reply_to_status_id" : 207373149770219522,
  "created_at" : "2012-05-29 07:30:36 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207342250190057473",
  "text" : "\u96E2\u8131\u3059\u308B\u304B\u96E8\u306F\u6B62\u3093\u3060\u304B\uFF1F",
  "id" : 207342250190057473,
  "created_at" : "2012-05-29 05:26:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207341423643725825",
  "geo" : { },
  "id_str" : "207341495576039425",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3046m\u305D\u306E\u65B9\u304C\u3044\u3044",
  "id" : 207341495576039425,
  "in_reply_to_status_id" : 207341423643725825,
  "created_at" : "2012-05-29 05:23:59 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207341071951335425",
  "geo" : { },
  "id_str" : "207341176825716737",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 mjk \u6559\u79D1\u66F8\u306A\u3089\u304A\u3044\u3066\u3063\u3066\u3082\u3044\u3044\u3093\u3060\u305C",
  "id" : 207341176825716737,
  "in_reply_to_status_id" : 207341071951335425,
  "created_at" : "2012-05-29 05:22:43 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207340734603464704",
  "geo" : { },
  "id_str" : "207340923615588352",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u628A\u63E1\u3057\u305F\u304C\u30E9\u30B9\u30C820\u5206\u629C\u3051\u308B\u3067",
  "id" : 207340923615588352,
  "in_reply_to_status_id" : 207340734603464704,
  "created_at" : "2012-05-29 05:21:43 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207340503677673472",
  "geo" : { },
  "id_str" : "207340599312007168",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u541B\u304C\u3044\u304B\u306A\u3044\u306A\u3089\u4F11\u8B1B\u8996\u91CE",
  "id" : 207340599312007168,
  "in_reply_to_status_id" : 207340503677673472,
  "created_at" : "2012-05-29 05:20:25 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207340431317540865",
  "text" : "\u4E0A\u304C\u3063\u305F\u308A\u4E0B\u304C\u3063\u305F\u308A\u304F\u3060\u3063\u305F\u308A\u306E\u307C\u3063\u305F\u308A",
  "id" : 207340431317540865,
  "created_at" : "2012-05-29 05:19:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207340239767867395",
  "geo" : { },
  "id_str" : "207340305870098432",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u632F\u52D5\u3057\u307E\u3059",
  "id" : 207340305870098432,
  "in_reply_to_status_id" : 207340239767867395,
  "created_at" : "2012-05-29 05:19:15 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207340102878371840",
  "text" : "\u4EBA\u305D\u3093\u306A\u306B\u304F\u308B\u306A\u3089\u767A\u8868\u610F\u6B32\u304C\u304C\u304C\u304C",
  "id" : 207340102878371840,
  "created_at" : "2012-05-29 05:18:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207339994979893250",
  "text" : "\u8ABF\u3079\u3066\u898B\u305F\u3089\u305F\u3060\u306E\u5B66\u751F\u5BEE\u3060\u3063\u305F\u307F\u305F\u3044",
  "id" : 207339994979893250,
  "created_at" : "2012-05-29 05:18:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207339550585008128",
  "text" : "\u5C0F\u5B66\u6821\u306E\u305D\u3070\u306B\u5927\u5B66\u5BEE\u3042\u3063\u305F\u3051\u3069\u3042\u308C\u306F\u3069\u3053\u306B\u5927\u5B66\u306E\u3060\u308D",
  "id" : 207339550585008128,
  "created_at" : "2012-05-29 05:16:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 0, 8 ],
      "id_str" : "351349087",
      "id" : 351349087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207338904506994688",
  "geo" : { },
  "id_str" : "207339324612685824",
  "in_reply_to_user_id" : 351349087,
  "text" : "@yasuand \u6771\u516B\u9053\u8DEF\u6CBF\u3044\u2026\u4F55\u3067\u3053\u3093\u306A\u3068\u3053\u308D\u306B",
  "id" : 207339324612685824,
  "in_reply_to_status_id" : 207338904506994688,
  "created_at" : "2012-05-29 05:15:21 +0000",
  "in_reply_to_screen_name" : "yasuand",
  "in_reply_to_user_id_str" : "351349087",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 0, 8 ],
      "id_str" : "351349087",
      "id" : 351349087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207338393342971904",
  "geo" : { },
  "id_str" : "207338832675352576",
  "in_reply_to_user_id" : 351349087,
  "text" : "@yasuand \u4E09\u9DF9\u5BEE\u3063\u3066\u3069\u306E\u8FBA\u306B\u3042\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 207338832675352576,
  "in_reply_to_status_id" : 207338393342971904,
  "created_at" : "2012-05-29 05:13:24 +0000",
  "in_reply_to_screen_name" : "yasuand",
  "in_reply_to_user_id_str" : "351349087",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207338592199122944",
  "text" : "\u96C6\u3044\u306F\u521D\u56DE\u304C\u6210\u529F\u3057\u305F\u3060\u3051\u306B\u671F\u5F85\u304C\u9AD8\u307E\u3063\u3066\u3044\u308B\u6A21\u69D8",
  "id" : 207338592199122944,
  "created_at" : "2012-05-29 05:12:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twipla.jp\" rel=\"nofollow\"\u003ETwiPla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3064\u3069\u3044\u7CFB\u30A4\u30D9\u30F3\u30C8\u7D39\u4ECBbot",
      "screen_name" : "sugakuto_osaka",
      "indices" : [ 0, 15 ],
      "id_str" : "481590089",
      "id" : 481590089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/Pehou0pN",
      "expanded_url" : "http:\/\/twipla.jp\/events\/24017",
      "display_url" : "twipla.jp\/events\/24017"
    } ]
  },
  "geo" : { },
  "id_str" : "207338196676247554",
  "in_reply_to_user_id" : 481590089,
  "text" : "@sugakuto_osaka \u53C2\u52A0\u3057\u307E\u3059\uFF01\u3053\u308C\u5B9A\u54E1100\u306A\u3093\u3067\u3059\u304B http:\/\/t.co\/Pehou0pN",
  "id" : 207338196676247554,
  "created_at" : "2012-05-29 05:10:52 +0000",
  "in_reply_to_screen_name" : "sugakuto_osaka",
  "in_reply_to_user_id_str" : "481590089",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8A00\u8449poker",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/eRleNvj6",
      "expanded_url" : "http:\/\/shindanmaker.com\/231842",
      "display_url" : "shindanmaker.com\/231842"
    } ]
  },
  "geo" : { },
  "id_str" : "207337843213860864",
  "text" : "\u300C\u4EF2\u9593\u300D\u300C\u6D77\u8FBA\u306E\u300D\u300C\u751F\u307E\u308C\u3082\u80B2\u3061\u3082\u300D\u300C\u5199\u771F\u300D\u300C\u84B8\u3057\u6691\u3044\u300D\u304B\u30893\u3064\u3092\u4E26\u3079\u3066 #\u8A00\u8449poker http:\/\/t.co\/eRleNvj6  \u84B8\u3057\u6691\u3044\u6D77\u8FBA\u306E\u5199\u771F\u96C6",
  "id" : 207337843213860864,
  "created_at" : "2012-05-29 05:09:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207335268955598848",
  "text" : "@_Mitsucaster_ \u4F55\u305D\u308C\u3044\u305F\u305D\u3046",
  "id" : 207335268955598848,
  "created_at" : "2012-05-29 04:59:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207334004276461570",
  "text" : "\u3050\u3072\u3083\u307A\u308D\u2026",
  "id" : 207334004276461570,
  "created_at" : "2012-05-29 04:54:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207333152765648897",
  "geo" : { },
  "id_str" : "207333421993832448",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3082\u3046\u306A\u3093\u3067\u3082\u3042\u308A(^^)(^^)(^^)(^^)(^^)",
  "id" : 207333421993832448,
  "in_reply_to_status_id" : 207333152765648897,
  "created_at" : "2012-05-29 04:51:54 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207332899308044288",
  "geo" : { },
  "id_str" : "207332945869029377",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3048",
  "id" : 207332945869029377,
  "in_reply_to_status_id" : 207332899308044288,
  "created_at" : "2012-05-29 04:50:01 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207332800913883137",
  "text" : "\u5B9F\u969B\u5148\u751F\u304Cwifi\u98DB\u3070\u3057\u3066\u305F\u308A\u51FA\u5E2D\u304C\u63B2\u793A\u677F\u3078\u306E\u30B3\u30E1\u30F3\u30C8\u306E\u66F8\u304D\u8FBC\u307F\u3060\u3063\u305F\u308A\u3044\u308D\u3044\u308D\u304A\u304B\u3057\u3044",
  "id" : 207332800913883137,
  "created_at" : "2012-05-29 04:49:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207332603940962306",
  "text" : "\u307C\u3001\u50D5\u306F\u60C5\u5831\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u793E\u4F1A\u8AD6\u306E\u6388\u696D\u306A\u306E\u3067\u3061\u3087\u3063\u3068\u5B9F\u8DF5\u7684\u306A\u8074\u8B1B\u30B9\u30BF\u30A4\u30EB\u3092\u3068\u3063\u3066\u3044\u308B\u3060\u3051\u3067\u3059\u3088(",
  "id" : 207332603940962306,
  "created_at" : "2012-05-29 04:48:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u81EA\u5DF1\u8A00\u53CA\u7684",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207332261526372354",
  "text" : "\u304A\u524D\u3089\u6F14\u7FD2\u306F\u3069\u3046\u3057\u305Fwww #\u81EA\u5DF1\u8A00\u53CA\u7684",
  "id" : 207332261526372354,
  "created_at" : "2012-05-29 04:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207331905476108289",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u3081\u3044\u305F\u4F55\u304B\u66F8\u304D\u7D42\u3048\u305F",
  "id" : 207331905476108289,
  "created_at" : "2012-05-29 04:45:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207331797095301120",
  "text" : "\u306F\u3044\u3001\u3053\u308C\u3067\u4E00\u4ED5\u4E8B\u304A\u3057\u307E\u3044\u3002",
  "id" : 207331797095301120,
  "created_at" : "2012-05-29 04:45:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207304041523449857",
  "text" : "\u96E8\u3068\u304B\u5BB3\u60AA(^^)(^^)(^^)",
  "id" : 207304041523449857,
  "created_at" : "2012-05-29 02:55:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207303788753731584",
  "text" : "\u96F7",
  "id" : 207303788753731584,
  "created_at" : "2012-05-29 02:54:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/NiVzAi1N",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=bagirom&c=end313124",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207125398201450499",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001bagirom\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002bagirom\u3055\u3093\u3084\u79C1\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3051\u308C\u3070\u767B\u9332\u3057\u3066\u30DE\u30C3\u30C1\u3059\u308B\u3068DM\u304C\u5C4A\u304D\u307E\u3059 http:\/\/t.co\/NiVzAi1N #gohantabeyo",
  "id" : 207125398201450499,
  "created_at" : "2012-05-28 15:05:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207026830014808066",
  "text" : "\u81F3\u8A00\u3060\u3063\u305F",
  "id" : 207026830014808066,
  "created_at" : "2012-05-28 08:33:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207026751338065920",
  "text" : "\u7406\u60F3\u6570\u306E\u30EA\u30BD\u30FC\u30B9",
  "id" : 207026751338065920,
  "created_at" : "2012-05-28 08:33:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207023887085613056",
  "geo" : { },
  "id_str" : "207024474187505665",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u8A00\u3046\u307B\u3069\u6570\u5B66\u7684\u3067\u306F\u306A\u3044\u3067\u3059\u3088\u30FC\u3002\u6570\u5B66\u306E\u8A71\u3067\u306F\u3042\u308A\u307E\u3059\u304C\u3002",
  "id" : 207024474187505665,
  "in_reply_to_status_id" : 207023887085613056,
  "created_at" : "2012-05-28 08:24:15 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207023535405801473",
  "geo" : { },
  "id_str" : "207023698467762177",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6587\u5B66\u90E8\u65B0\u9928\u7B2C6\u8B1B\u7FA9\u5BA4",
  "id" : 207023698467762177,
  "in_reply_to_status_id" : 207023535405801473,
  "created_at" : "2012-05-28 08:21:10 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207023363795861504",
  "geo" : { },
  "id_str" : "207023435350683648",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5B66\u90E8\u306E\u6388\u696D\u3067\u3059",
  "id" : 207023435350683648,
  "in_reply_to_status_id" : 207023363795861504,
  "created_at" : "2012-05-28 08:20:07 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207023362822774784",
  "text" : "\u3053\u308C\u306F\u2026\u30B9\u30C6\u30DE\uFF01",
  "id" : 207023362822774784,
  "created_at" : "2012-05-28 08:19:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207023246011416576",
  "text" : "\u77E5\u3089\u306A\u3044\u3075\u308A\u30B2\u30FC\u30E0w\u666E\u901A\u306B\u7D50\u57CE\u5148\u751F\u3063\u3066\u5358\u8A9E\u304C\u3075\u3075\u3075",
  "id" : 207023246011416576,
  "created_at" : "2012-05-28 08:19:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207022845879009281",
  "text" : "\u30AC\u30ED\u30A2\u7406\u8AD6\u306E\u8A71\u30FC\u30BF\u30A4\u30E0\u30EA\u30FC\uFF01",
  "id" : 207022845879009281,
  "created_at" : "2012-05-28 08:17:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207022423797796864",
  "text" : "\u540C\u5024\u985E\u30FC\u540C\u5024\u985E\u30FC",
  "id" : 207022423797796864,
  "created_at" : "2012-05-28 08:16:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207022081408372736",
  "text" : "\u306A\u305C\u304B\u30A4\u30C7\u30A2\u30EB\u3068\u52A0\u7FA4\u306E\u8A71\u306B\u3075\u3075\u3075\u3075",
  "id" : 207022081408372736,
  "created_at" : "2012-05-28 08:14:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207021649558650880",
  "text" : "\u3075\u3075\u3075\u3075\u3075\u3075",
  "id" : 207021649558650880,
  "created_at" : "2012-05-28 08:13:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u266A\u10E6\u309D\u25E1\u2579)\u30CE\u2661",
      "screen_name" : "hthtfire",
      "indices" : [ 3, 12 ],
      "id_str" : "313715415",
      "id" : 313715415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207021607359758336",
  "text" : "RT @hthtfire: \u4E09\u9DF9\u5BEE\u751F\u300C\u5409\u7965\u5BFA\u306B\u4F4F\u3093\u3067\u307E\u3059\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207021401314574336",
    "text" : "\u4E09\u9DF9\u5BEE\u751F\u300C\u5409\u7965\u5BFA\u306B\u4F4F\u3093\u3067\u307E\u3059\u300D",
    "id" : 207021401314574336,
    "created_at" : "2012-05-28 08:12:03 +0000",
    "user" : {
      "name" : "\u266A\u10E6\u309D\u25E1\u2579)\u30CE\u2661",
      "screen_name" : "hthtfire",
      "protected" : false,
      "id_str" : "313715415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3050105487\/096662a823fc3fd58c46b4cfc4976e24_normal.jpeg",
      "id" : 313715415,
      "verified" : false
    }
  },
  "id" : 207021607359758336,
  "created_at" : "2012-05-28 08:12:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207002385514643457",
  "text" : "\u25EF\u25EF\u306A\u3084\u3064\u306F\u307F\u3093\u306A\u305D\u3046\u8A00\u3046\u3093\u3060\u3088\uFF01\u3063\u3066\u306E\u304C\u6C4E\u7528\u6027\u304C\u9AD8\u304F\u3066\u304B\u3064\u982D\u304C\u60AA\u3044\u306E\u3067\u7A4D\u6975\u7684\u306B\u4F7F\u3063\u3066\u884C\u304F",
  "id" : 207002385514643457,
  "created_at" : "2012-05-28 06:56:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207002048015761408",
  "text" : "\u982D\u4EE5\u5916\u304C\u8EFD\u3044\u2026",
  "id" : 207002048015761408,
  "created_at" : "2012-05-28 06:55:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207001893002682368",
  "text" : "6\u6642\u9593\u304F\u3089\u3044\u3057\u304B\u5BDD\u3066\u306A\u3044\u304B\u3089\u306D\u3059\u304E\u3063\u3066\u3053\u3068\u306F\u306A\u3044\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u306A\u30FC\u3002\u3068\u308A\u3042\u3048\u305A\u4E0D\u5065\u5EB7\u306A\u306E\u306F\u4E8B\u5B9F\u3060\u304C\u3002",
  "id" : 207001893002682368,
  "created_at" : "2012-05-28 06:54:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207000892560519168",
  "text" : "\u6708\u672B\u307E\u3067\u306B\u30EC\u30DD\u30FC\u30C8\u4E00\u3064\u3067\u3063\u3061\u4E0A\u3052\u306A\u304D\u3083\u3058\u3083\u3093(",
  "id" : 207000892560519168,
  "created_at" : "2012-05-28 06:50:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207000205650964481",
  "text" : "\u304B\u307F\u306E\u305D\u3093\u3056\u3044\u306E\u3057\u3087\u3046\u3081\u3044\u306B\u306F\u3069\u3093\u306A\u307B\u3060\u3044\u304C\u3072\u3064\u3088\u3046\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 207000205650964481,
  "created_at" : "2012-05-28 06:47:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206999417847414784",
  "geo" : { },
  "id_str" : "206999709418663936",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary 3\u9650\u30928\u5272\u30D6\u30C3\u30C1\u3059\u308B\u7A0B\u5EA6\u306B\u306F\u5BDD\u3066\u305F\u3093\u3067\u3059\u3051\u3069\u306D\u3047\u3002\u9031\u306E\u958B\u5E55\u306B\u3057\u3066\u30EA\u30BA\u30E0\u304C\u9177\u3044\u3053\u3068\u306B",
  "id" : 206999709418663936,
  "in_reply_to_status_id" : 206999417847414784,
  "created_at" : "2012-05-28 06:45:51 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206999092969209857",
  "text" : "\u307C\u3093\u3084\u308A\u3068\u3057\u305F\u7720\u6C17\u2026\u5FC3\u5730\u60AA\u3057",
  "id" : 206999092969209857,
  "created_at" : "2012-05-28 06:43:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206997767745318912",
  "text" : "\u3082\u3057\u304B\u3057\u3066:\u6388\u696D\u304C\u3064\u307E\u3089\u306A\u3044",
  "id" : 206997767745318912,
  "created_at" : "2012-05-28 06:38:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206960208172425218",
  "text" : "\u30A2\u30A4\u30B3\u30F3\u304C\uFF1F",
  "id" : 206960208172425218,
  "created_at" : "2012-05-28 04:08:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/6xSSqcw1",
      "expanded_url" : "http:\/\/shindanmaker.com\/231548",
      "display_url" : "shindanmaker.com\/231548"
    } ]
  },
  "geo" : { },
  "id_str" : "206960001246429186",
  "text" : "\u30AE\u30E3\u30AE\u30E3\u57FA\u5E95\u306B\u8A00\u308F\u305B\u308C\u3070\uFF0Cend313124\u306F\u3072\u3058\u304D\u3067\u3059wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww http:\/\/t.co\/6xSSqcw1",
  "id" : 206960001246429186,
  "created_at" : "2012-05-28 04:08:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206912472291098626",
  "text" : "\u306B\u305D\u304D\u3093\u306B\u3044",
  "id" : 206912472291098626,
  "created_at" : "2012-05-28 00:59:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206910915428364289",
  "text" : "\u307E\u3076\u305F\u4EE5\u5916\u304C\u8EFD\u304F\u3066\u30E4\u30D0\u3044",
  "id" : 206910915428364289,
  "created_at" : "2012-05-28 00:53:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206909759213940736",
  "geo" : { },
  "id_str" : "206910231475781632",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u3059\u307F\u307E\u305B\u3093\n\u308F\u3056\u308F\u3056\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 206910231475781632,
  "in_reply_to_status_id" : 206909759213940736,
  "created_at" : "2012-05-28 00:50:18 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206838237522690048",
  "text" : "\u304A\u4F11\u307F\u306A\u3055\u3044",
  "id" : 206838237522690048,
  "created_at" : "2012-05-27 20:04:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206837695543132162",
  "geo" : { },
  "id_str" : "206837946962284545",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u3042\u3001\u3059\u307F\u307E\u305B\u3093TL\u306B\u3044\u305F\u306E\u3067\u3064\u3044",
  "id" : 206837946962284545,
  "in_reply_to_status_id" : 206837695543132162,
  "created_at" : "2012-05-27 20:03:04 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206837152171048963",
  "geo" : { },
  "id_str" : "206837817555423232",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u627F\u8A8D\u5F85\u3061\u3046\u3093\u306C\u3093\u3063\u3066\u51FA\u3066\u305F\u306E\u3067\u2026\u307E\u3041\u571F\u66DC\u65E5\u306F\u30D0\u30A4\u30C8\u306A\u306E\u3067\u53C2\u52A0\u4E0D\u53EF\u3067\u3059\u304C\u65E5\u66DC\u306A\u3089\u5927\u4E08\u592B\u3067\u3059\u3063\u3066\u3053\u3053\u3067\u4F1D\u3048\u3061\u3083\u3044\u307E\u3059",
  "id" : 206837817555423232,
  "in_reply_to_status_id" : 206837152171048963,
  "created_at" : "2012-05-27 20:02:33 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206836621981650944",
  "geo" : { },
  "id_str" : "206836778064297984",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u306F\u3044(\u305F\u3076\u3093)\u9055\u3046\u30A2\u30C9\u30EC\u30B9\u3067\u9001\u3063\u305F\u305B\u3044\u3060\u3068\u601D\u3046\u306E\u3067\u3059\u304C\u2026",
  "id" : 206836778064297984,
  "in_reply_to_status_id" : 206836621981650944,
  "created_at" : "2012-05-27 19:58:25 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206836601119191041",
  "text" : "5\u6642\u304B\u30894\u6642\u959330\u5206\u5BDD\u308B\u6240\u5B58",
  "id" : 206836601119191041,
  "created_at" : "2012-05-27 19:57:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206835601272614984",
  "geo" : { },
  "id_str" : "206835636223754241",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 206835636223754241,
  "in_reply_to_status_id" : 206835601272614984,
  "created_at" : "2012-05-27 19:53:53 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206835590551977986",
  "text" : "\u5BDD\u305F\u3044\u3057\u52C9\u5F37\u3057\u305F\u3044\u3057\u3054\u98EF\u98DF\u3079\u305F\u3044\u3057\u3082\u3046",
  "id" : 206835590551977986,
  "created_at" : "2012-05-27 19:53:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206835497966899202",
  "text" : "\u9AEA\u4E7E\u304B\u3057\u3066\u5BDD\u308B\u306E\u304C\u5065\u5168\u304B",
  "id" : 206835497966899202,
  "created_at" : "2012-05-27 19:53:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206834676483100673",
  "geo" : { },
  "id_str" : "206834918490259457",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u30E1\u30FC\u30EB\u9001\u3063\u305F\u3093\u3067\u3059\u304C\u5C4A\u3044\u3066\u3044\u306A\u3055\u305D\u3046\u306A\u306E\u3067\u30E1\u30FC\u30EA\u30B9\u306E\u78BA\u8A8D\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 206834918490259457,
  "in_reply_to_status_id" : 206834676483100673,
  "created_at" : "2012-05-27 19:51:02 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206834669839319040",
  "text" : "2\u9650\u306F\u3061\u3087\u3063\u3068\u51FA\u305F\u3044",
  "id" : 206834669839319040,
  "created_at" : "2012-05-27 19:50:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5371\u967A\u601D\u60F3",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206834607289667585",
  "text" : "\u305D\u3082\u305D\u3082\u5B66\u6821\u306B\u884C\u304F\u5FC5\u8981\u306F(ry #\u5371\u967A\u601D\u60F3",
  "id" : 206834607289667585,
  "created_at" : "2012-05-27 19:49:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206834397905829888",
  "text" : "\u9AEA\u4E7E\u304B\u306A\u3044\u3068\u306D\u308C\u306A\u3044\u3057\u306A\u3041",
  "id" : 206834397905829888,
  "created_at" : "2012-05-27 19:48:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206834307589869568",
  "text" : "\u7720\u308B\u3079\u304D\u304B\u5426\u304B",
  "id" : 206834307589869568,
  "created_at" : "2012-05-27 19:48:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206833211236548608",
  "text" : "\u4F55\u3084\u3089\u5916\u3067\u3074\u3088\u3074\u3088\u805E\u3053\u3048\u308B\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 206833211236548608,
  "created_at" : "2012-05-27 19:44:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/MEO7MEkJ",
      "expanded_url" : "http:\/\/twitpic.com\/9pvdeh",
      "display_url" : "twitpic.com\/9pvdeh"
    } ]
  },
  "geo" : { },
  "id_str" : "206724859248656384",
  "text" : "JordanBL... http:\/\/t.co\/MEO7MEkJ",
  "id" : 206724859248656384,
  "created_at" : "2012-05-27 12:33:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206716456602320896",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 206716456602320896,
  "created_at" : "2012-05-27 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206709789701582849",
  "text" : "\u30DE\u30C3\u30C9\u30AF\u30ED\u30C3\u30AF\u30A8\u30CA\u30B8\u30FC\u30B3\u30FC\u30E9\u306A\u3046",
  "id" : 206709789701582849,
  "created_at" : "2012-05-27 11:33:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206620622384664577",
  "text" : "\u30DE\u30B8\u65E2\u77E5\u3060\u3063\u305F",
  "id" : 206620622384664577,
  "created_at" : "2012-05-27 05:39:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206537186353487872",
  "text" : "\u80A9\u3053\u308A\u982D\u75DB\u306E\u30B3\u30F3\u30DC\u304C\u30B8\u30EF\u30B8\u30EF\u304F\u308B",
  "id" : 206537186353487872,
  "created_at" : "2012-05-27 00:07:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206419509433733122",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 206419509433733122,
  "created_at" : "2012-05-26 16:20:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inkmac",
      "screen_name" : "inkmac",
      "indices" : [ 0, 7 ],
      "id_str" : "985125344",
      "id" : 985125344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206410758890848258",
  "geo" : { },
  "id_str" : "206419347164504066",
  "in_reply_to_user_id" : 181108068,
  "text" : "@inkmac \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u30FC\u3059\u307F\u307E\u305B\u3093\u304C\u4E00\u56DE\u3067\u629C\u3051\u307E\u3059",
  "id" : 206419347164504066,
  "in_reply_to_status_id" : 206410758890848258,
  "created_at" : "2012-05-26 16:19:42 +0000",
  "in_reply_to_screen_name" : "citrusink",
  "in_reply_to_user_id_str" : "181108068",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206418998546542592",
  "text" : "\u3054\u3081\u3093\u306A\u3055\u3044\u4E00\u56DE\u3067\u7D42\u308F\u308A\u307E\u3059",
  "id" : 206418998546542592,
  "created_at" : "2012-05-26 16:18:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206418856242188288",
  "text" : "\u4E88\u5B9A\u8ABF\u548C\u3042\u3042\u3042\u3042\u3042\u3042\uFF01\uFF01\uFF01\uFF01",
  "id" : 206418856242188288,
  "created_at" : "2012-05-26 16:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206412553067315200",
  "text" : "\u4E8C\u629E\u305F\u3048\u305A",
  "id" : 206412553067315200,
  "created_at" : "2012-05-26 15:52:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206410934065971203",
  "text" : "\u3057\u308C\u3063\u3068",
  "id" : 206410934065971203,
  "created_at" : "2012-05-26 15:46:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206410551230865408",
  "text" : "\u65E5\u66DC\u65E5\u3063\u3066\u5927\u962A\u30B3\u30D4\u30FC\u3084\u3063\u3066\u3093\u306E\u304B\u306A\u3041\u30FB\u30FB\u30FB",
  "id" : 206410551230865408,
  "created_at" : "2012-05-26 15:44:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206385414968311808",
  "geo" : { },
  "id_str" : "206385465429983233",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u5727\u5012\u7684\u4E86\u89E3\uFF01",
  "id" : 206385465429983233,
  "in_reply_to_status_id" : 206385414968311808,
  "created_at" : "2012-05-26 14:05:04 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206385328423051264",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u660E\u65E5\u3063\u3066\u4F55\u6642\u306B\u3069\u3053\u306B\uFF1F",
  "id" : 206385328423051264,
  "created_at" : "2012-05-26 14:04:31 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206354050176913408",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 206354050176913408,
  "created_at" : "2012-05-26 12:00:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206259654597156864",
  "text" : "\u6577\u5C45\u3092\u4E0B\u3052\u308B\u62C5\u5F53 \u3048\u3093\u3069",
  "id" : 206259654597156864,
  "created_at" : "2012-05-26 05:45:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 3, 14 ],
      "id_str" : "348990022",
      "id" : 348990022
    }, {
      "name" : "\u68EE\u7530\u7D18\u5E73",
      "screen_name" : "kouheimorita",
      "indices" : [ 16, 29 ],
      "id_str" : "160230093",
      "id" : 160230093
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 44, 54 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206259655394078722",
  "text" : "RT @noukoknows: @kouheimorita \u3042\u3042\u3001\u305D\u3046\u3067\u3059\u3001\u4EAC\u5927\u79D1\u54F2\u306E @end313124 \u304F\u3093\u3068\u3044\u3046\u5B50\u3082\u904B\u55B6\u306B\u53C2\u52A0\u3057\u3066\u304F\u308C\u3066\u3044\u307E\u3057\u305F\u30FE(*\u00B4\u2200\uFF40*)\uFF89 \u306F\u3044\u3001\u3082\u3057\u304A\u6642\u9593\u306A\u3069\u306B\u4F59\u88D5\u3042\u308A\u307E\u3057\u305F\u3089\u305C\u3072\u304A\u3053\u3057\u304F\u3060\u3055\u3044\uFF5E\u3002\u8FD4\u4FE1\u3044\u305F\u3060\u304D\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u68EE\u7530\u7D18\u5E73",
        "screen_name" : "kouheimorita",
        "indices" : [ 0, 13 ],
        "id_str" : "160230093",
        "id" : 160230093
      }, {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 28, 38 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "206237567451009025",
    "geo" : { },
    "id_str" : "206239226617020416",
    "in_reply_to_user_id" : 160230093,
    "text" : "@kouheimorita \u3042\u3042\u3001\u305D\u3046\u3067\u3059\u3001\u4EAC\u5927\u79D1\u54F2\u306E @end313124 \u304F\u3093\u3068\u3044\u3046\u5B50\u3082\u904B\u55B6\u306B\u53C2\u52A0\u3057\u3066\u304F\u308C\u3066\u3044\u307E\u3057\u305F\u30FE(*\u00B4\u2200\uFF40*)\uFF89 \u306F\u3044\u3001\u3082\u3057\u304A\u6642\u9593\u306A\u3069\u306B\u4F59\u88D5\u3042\u308A\u307E\u3057\u305F\u3089\u305C\u3072\u304A\u3053\u3057\u304F\u3060\u3055\u3044\uFF5E\u3002\u8FD4\u4FE1\u3044\u305F\u3060\u304D\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
    "id" : 206239226617020416,
    "in_reply_to_status_id" : 206237567451009025,
    "created_at" : "2012-05-26 04:23:58 +0000",
    "in_reply_to_screen_name" : "kouheimorita",
    "in_reply_to_user_id_str" : "160230093",
    "user" : {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "protected" : true,
      "id_str" : "348990022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000720729836\/990edaf9c5011972665a60414d8f2569_normal.png",
      "id" : 348990022,
      "verified" : false
    }
  },
  "id" : 206259655394078722,
  "created_at" : "2012-05-26 05:45:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206042776431898624",
  "text" : "\u98DF\u3079\u305F\u3089\u5BDD\u308B\u3002\u98DF\u3079\u305F\u3089\u5BDD\u308B\u3002\u98DF\u3079\u305F\u3089\u5BDD\u308B\u3002",
  "id" : 206042776431898624,
  "created_at" : "2012-05-25 15:23:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meshiyosoi",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/TU6jjRh4",
      "expanded_url" : "http:\/\/shindanmaker.com\/80808",
      "display_url" : "shindanmaker.com\/80808"
    } ]
  },
  "geo" : { },
  "id_str" : "206042206216265729",
  "text" : "end313124\u306F\u305D\u3082\u305D\u3082\u30E1\u30B7\u304E\u3089\u3044\u3067\u3057\u305F #meshiyosoi http:\/\/t.co\/TU6jjRh4\n\u30D1\u30F3\u3092\u98DF\u3079\u308C\u3070\u3044\u3044\u3058\u3083\u306A\u3044",
  "id" : 206042206216265729,
  "created_at" : "2012-05-25 15:21:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206041547156897792",
  "text" : "\u5BB6\u306B\u98DF\u6750\u304C\u306A\u304B\u3063\u305F\u3093\u3060\u3088\uFF01",
  "id" : 206041547156897792,
  "created_at" : "2012-05-25 15:18:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206041508074369025",
  "text" : "\u8ABF\u7406\u304C\u697D\u3060\u304B\u3089\u304A\u7CA5\u306B\u3059\u308B\u3053\u3068\u306B\u3057\u305F\u3002\u8C6A\u83EF\u306B\u30DB\u30BF\u30C6\u306E\u8C9D\u67F1\u306E\u6C34\u716E\u7F36\u3092\u4F7F\u3046\u3088\uFF01",
  "id" : 206041508074369025,
  "created_at" : "2012-05-25 15:18:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206040110800711680",
  "text" : "\u3053\u306E\u6D41\u308C\u3067\u3084\u307E\u3060\u3061\u3083\u3093\u3092\u63A8\u3059",
  "id" : 206040110800711680,
  "created_at" : "2012-05-25 15:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "indices" : [ 3, 16 ],
      "id_str" : "310067164",
      "id" : 310067164
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u98DF\u30D1\u30F3\u5C11\u5973\u3084\u307E\u3060\u3061\u3083\u3093",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/JPlP4pX4",
      "expanded_url" : "http:\/\/bit.ly\/uXcd1j",
      "display_url" : "bit.ly\/uXcd1j"
    } ]
  },
  "geo" : { },
  "id_str" : "206040033285771266",
  "text" : "RT @_yamadachan_: \u98DF\u30D1\u30F3\u5C11\u5973\u3000\u3084\u307E\u3060\u3061\u3083\u3093\uFF01\uFF01\u3000bot\u3058\u3083\u306A\u3044\u3088\uFF01\u305C\u3072\u8A71\u3057\u304B\u3051\u3066\u306D\u301C\u2606\u3000\u30DB\u30FC\u30E0\u30DA\u30FC\u30B8\u3082\u3088\u308D\u3057\u304F\uFF01\u3000http:\/\/t.co\/JPlP4pX4\u3000#\u98DF\u30D1\u30F3\u5C11\u5973\u3084\u307E\u3060\u3061\u3083\u3093",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u98DF\u30D1\u30F3\u5C11\u5973\u3084\u307E\u3060\u3061\u3083\u3093",
        "indices" : [ 69, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/JPlP4pX4",
        "expanded_url" : "http:\/\/bit.ly\/uXcd1j",
        "display_url" : "bit.ly\/uXcd1j"
      } ]
    },
    "geo" : { },
    "id_str" : "206039730666741761",
    "text" : "\u98DF\u30D1\u30F3\u5C11\u5973\u3000\u3084\u307E\u3060\u3061\u3083\u3093\uFF01\uFF01\u3000bot\u3058\u3083\u306A\u3044\u3088\uFF01\u305C\u3072\u8A71\u3057\u304B\u3051\u3066\u306D\u301C\u2606\u3000\u30DB\u30FC\u30E0\u30DA\u30FC\u30B8\u3082\u3088\u308D\u3057\u304F\uFF01\u3000http:\/\/t.co\/JPlP4pX4\u3000#\u98DF\u30D1\u30F3\u5C11\u5973\u3084\u307E\u3060\u3061\u3083\u3093",
    "id" : 206039730666741761,
    "created_at" : "2012-05-25 15:11:14 +0000",
    "user" : {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "protected" : false,
      "id_str" : "310067164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585053686205775873\/EygeOjja_normal.jpg",
      "id" : 310067164,
      "verified" : false
    }
  },
  "id" : 206040033285771266,
  "created_at" : "2012-05-25 15:12:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "indices" : [ 3, 16 ],
      "id_str" : "310067164",
      "id" : 310067164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206040008866533377",
  "text" : "RT @_yamadachan_: \u4E00\u9031\u9593\u304A\u75B2\u308C\u3055\u307E\u301C\uFF01\u4F11\u307F\u306E\u65E5\u306F\u3069\u3093\u306A\u30D1\u30F3\u3092\u98DF\u3079\u3088\u3046\u304B\u306A\u301C\uFF3E\uFF3E\u2606",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "206039950091747328",
    "text" : "\u4E00\u9031\u9593\u304A\u75B2\u308C\u3055\u307E\u301C\uFF01\u4F11\u307F\u306E\u65E5\u306F\u3069\u3093\u306A\u30D1\u30F3\u3092\u98DF\u3079\u3088\u3046\u304B\u306A\u301C\uFF3E\uFF3E\u2606",
    "id" : 206039950091747328,
    "created_at" : "2012-05-25 15:12:06 +0000",
    "user" : {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "protected" : false,
      "id_str" : "310067164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585053686205775873\/EygeOjja_normal.jpg",
      "id" : 310067164,
      "verified" : false
    }
  },
  "id" : 206040008866533377,
  "created_at" : "2012-05-25 15:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 14, 25 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/ZBKw5RuB",
      "expanded_url" : "http:\/\/ja.wikipedia.org\/wiki\/%E5%B1%9E_(%E5%88%86%E9%A1%9E%E5%AD%A6)",
      "display_url" : "ja.wikipedia.org\/wiki\/%E5%B1%9E\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "206039611015823360",
  "geo" : { },
  "id_str" : "206039828662460416",
  "in_reply_to_user_id" : 349830212,
  "text" : "\u308C\u3093\u3053\u3093\u306E\u7AEF\u3063\u3053\u304B\u3068 QT @haguruma20: \u30AB\u30E9\u30D5\u30EB\u306A\u6817\u304C\u30AB\u30E9\u30D5\u30EB\u306A\u6817\u306B\u523A\u3055\u3063\u3066\u3044\u308B\u69D8\u306B\u3057\u304B\u898B\u3048\u306A\u3044 http:\/\/t.co\/ZBKw5RuB",
  "id" : 206039828662460416,
  "in_reply_to_status_id" : 206039611015823360,
  "created_at" : "2012-05-25 15:11:37 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206039711909822464",
  "text" : "\u30C9\u30FC\u30CA\u30C4\u306E\u7A74\u306F\u3001\u30C9\u30FC\u30CA\u30C4\u3092\u98DF\u3079\u7D42\u308F\u308B\u524D\u306B\u7121\u304F\u306A\u3063\u3061\u3083\u3046\u3093\u3060\u306A\u3041",
  "id" : 206039711909822464,
  "created_at" : "2012-05-25 15:11:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/SNKxG9Xp",
      "expanded_url" : "http:\/\/togetter.com\/li\/233820",
      "display_url" : "togetter.com\/li\/233820"
    } ]
  },
  "in_reply_to_status_id_str" : "206038691062358016",
  "geo" : { },
  "id_str" : "206039062438621184",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u5927\u6839\u306F\u751F\u3067\uFF01http:\/\/t.co\/SNKxG9Xp",
  "id" : 206039062438621184,
  "in_reply_to_status_id" : 206038691062358016,
  "created_at" : "2012-05-25 15:08:35 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 21, 32 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204925568087633920",
  "geo" : { },
  "id_str" : "206038465127792640",
  "in_reply_to_user_id" : 349830212,
  "text" : "\u30C9\u30FC\u30CA\u30C4\u306E\u7A74\u3092\u6B8B\u3059\u5B50\u4F9B\u305F\u3061\u306B(ry QT @haguruma20: \u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306B\u30D1\u30F3\u3092\u3082\u3089\u3063\u3066\u308B\u5B50\u4F9B\u9054\u306B\u3001\u300C\u6B8B\u3055\u305A\u98DF\u3079\u306A\u3055\u3044\uFF01\u300D\u3068\u8A00\u3063\u3066\u307E\u308F\u308A\u305F\u3044\u3002",
  "id" : 206038465127792640,
  "in_reply_to_status_id" : 204925568087633920,
  "created_at" : "2012-05-25 15:06:12 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206038152647950336",
  "text" : "\u30A2\u30E9\u30B8\u30F3\u3067\u30B8\u30E3\u30B9\u30DF\u30F3\u59EB\u304C\u98FC\u3063\u3066\u305F\u864E\u306E\u540D\u524D\u304C\u601D\u3044\u51FA\u305B\u306A\u3044\uFF01\uFF01\uFF01\uFF01",
  "id" : 206038152647950336,
  "created_at" : "2012-05-25 15:04:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206038088445722625",
  "text" : "\u3042\u3068\u306F\u7D05\u306E\u8C5A\u306E\u7528\u5FC3\u68D2\u306E\u30A2\u30E1\u30EA\u30AB\u91CE\u90CE\u306E\u540D\u524D\u306F\u300C\u30AB\u30FC\u30C1\u30B9\u300D",
  "id" : 206038088445722625,
  "created_at" : "2012-05-25 15:04:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206037948934795266",
  "text" : "\u30C8\u30FC\u30DE\u30B9\u306E\u99C5\u9577\u3055\u3093\u306E\u540D\u524D\u304C\u300C\u30C8\u30C3\u30D7\u30CF\u30E0\u30CF\u30C3\u30C8\u537F\u300D\u3060\u3063\u3066\u306E\u306F\u6B7B\u306C\u307E\u3067\u5FD8\u308C\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u601D\u3046",
  "id" : 206037948934795266,
  "created_at" : "2012-05-25 15:04:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206037813861421058",
  "text" : "\u9AD8\u6821\u306E\u6642\u6388\u696D\u4E2D\u306B\u601D\u3044\u51FA\u305B\u305D\u3046\u3067\u601D\u3044\u51FA\u305B\u305D\u3046\u306A\u30AD\u30E3\u30E9\u306E\u540D\u524D\u3092\u601D\u3044\u51FA\u3059\u5927\u4F1A\u3084\u3063\u3066\u305F",
  "id" : 206037813861421058,
  "created_at" : "2012-05-25 15:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206037396402339841",
  "geo" : { },
  "id_str" : "206037482284920832",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u7A7A\u8179\u3092\u3042\u304A\u308B\u306E\u3084\u3081\u3066\u304F\u3060\u3055\u3044\uFF01\uFF01\uFF01\uFF01",
  "id" : 206037482284920832,
  "in_reply_to_status_id" : 206037396402339841,
  "created_at" : "2012-05-25 15:02:18 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206037287140728832",
  "text" : "\u8CB4\u65B9\u306E\u30DD\u30B1\u30C3\u30C8\u306E\u4E2D\u306E\u3082\u306E\u306F\u306A\u306B\uFF1F",
  "id" : 206037287140728832,
  "created_at" : "2012-05-25 15:01:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206037246778941441",
  "text" : "\u8ACB\u6C42\u66F8\u30FC\u6C34\u5897\u3057\u3057\u3068\u3051\u3070\u3088\u304B\u3063\u305F\u30FC",
  "id" : 206037246778941441,
  "created_at" : "2012-05-25 15:01:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206037129132904450",
  "text" : "\u30B8\u30D6\u30EA\u306E\u5FAE\u5999\u306A\u30BB\u30EA\u30D5\u306E\u30C1\u30E7\u30A4\u30B9\u306B\u5B9A\u8A55\u306E\u3042\u308B\u3048\u3093\u3069\u3067\u3059",
  "id" : 206037129132904450,
  "created_at" : "2012-05-25 15:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206036871627816960",
  "text" : "\u534A\u5206\u81EA\u5206\u304C\u4F5C\u3063\u305F\u3093\u3060\u3051\u3069",
  "id" : 206036871627816960,
  "created_at" : "2012-05-25 14:59:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206036842968125440",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u3088\u3082\u3046\u306A\u3093\u3060\u3088\u3053\u306ETL",
  "id" : 206036842968125440,
  "created_at" : "2012-05-25 14:59:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206036401169502208",
  "geo" : { },
  "id_str" : "206036807719202818",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u305F\u304F\u3055\u3093\u3064\u304F\u3063\u3066\u51B7\u3084\u3059\u3068\u5727\u5012\u7684\u7F8E\u5473\u3057\u3055\u3002\u30A4\u30F3\u30B2\u30F3\u3068\u304B\u3057\u3057\u5510\u5165\u308C\u3066\u3082\u5727\u5012\u7684\u3002",
  "id" : 206036807719202818,
  "in_reply_to_status_id" : 206036401169502208,
  "created_at" : "2012-05-25 14:59:37 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206036578836033538",
  "text" : "\u3063\u3066\u30CD\u30BF\u601D\u3044\u3064\u3044\u305F\u3051\u3069\u30AB\u30F3\u30BF\u306E\u30BB\u30EA\u30D5\u304C\u5FAE\u5999\u3059\u304E\u3066\u3053\u308C\u4F1D\u308F\u308B\u306E\u304B\u306A",
  "id" : 206036578836033538,
  "created_at" : "2012-05-25 14:58:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206036481574305792",
  "text" : "\u30AB\u30F3\u30BF\u300C\u3076\u30FC\u3093\u300D\n\u304A\u3070\u3042\u3061\u3083\u3093\u300C\u9ED9\u308C\u5C0F\u50E7\uFF01\u300D",
  "id" : 206036481574305792,
  "created_at" : "2012-05-25 14:58:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206036112211312640",
  "text" : "3\u5E74\u304F\u3089\u3044\u9023\u7D61\u53D6\u3063\u3066\u306A\u304B\u3063\u305F\u53CB\u4EBA\u306B\u7A81\u7136\u96FB\u8A71\u3059\u308B\u904A\u3073\u304C\u697D\u3057\u304B\u3063\u305F\u3067\u3059\u3002",
  "id" : 206036112211312640,
  "created_at" : "2012-05-25 14:56:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206034589880295424",
  "text" : "A\u300C\u7ACB\u76F4\u300D\nB\u300C\u4ECA\u306A\u30898000\u70B9\u3092\u652F\u6255\u3055\u3048\u3059\u308C\u3070\u7279\u5225\u306B\u305D\u306E\u30EA\u30FC\u30C1\u3092\u53D6\u308A\u6D88\u305B\u308B\u3051\u3069\u3001\u3069\u3046\u3059\u308B\uFF1F\u300D\nA\u300C\u300D",
  "id" : 206034589880295424,
  "created_at" : "2012-05-25 14:50:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206034008272941057",
  "text" : "\u3053\u306E\u30DD\u30B9\u30C8\u306F\u4F38\u3073\u306A\u3044",
  "id" : 206034008272941057,
  "created_at" : "2012-05-25 14:48:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206033956594925568",
  "text" : "[\u30D6\u30EA\u30A2\u30F3\u30C6\u30A3\u30FC\u30BA\u3042\u308B\u3042\u308B]\u9AD8\u7D1A\u98DF\u30D1\u30F3\u306B\u624B\u304C\u4F38\u3073\u306A\u3044",
  "id" : 206033956594925568,
  "created_at" : "2012-05-25 14:48:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206033695130398721",
  "text" : "\u30D4\u30ED\u30B7\u30AD\u306E\u5177\u6750\u304C\u7121\u3044\u3068\u304D\u306F\u03BE\u304C\u03C6\u3067\u3082\u305D\u308C\u306F\u30D4\u30ED\u30B7\u30AD\u306A\u306E\u304B\u306A",
  "id" : 206033695130398721,
  "created_at" : "2012-05-25 14:47:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 8, 16 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206033471339110401",
  "text" : "\u6DF1\u591C\u55B6\u696D\uFF01RT @shigmax: \u3057\u3050\u307E\u3063\u304F\u3059\u90B8\u306E\u3079\u30CB\u30E5\u30FC\u30AB\u30C6\u30B4\u30EA\u30FC\u3092\u30D1\u30F3\u5C4B\u3055\u3093\u306B\u5909\u3048\u3088\u3046\u304B\u3068\u601D\u6848\u306A\u3046",
  "id" : 206033471339110401,
  "created_at" : "2012-05-25 14:46:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206033392351977472",
  "text" : "\u03BE\u306F\u03C6",
  "id" : 206033392351977472,
  "created_at" : "2012-05-25 14:46:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206033357321146368",
  "text" : "\u5C0F\u3055\u3044\u3053\u308D\u3069\u3046\u3044\u3046\u308F\u3051\u304B\u30D1\u30F3\u306E\u5302\u3044\u304C\u5927\u5ACC\u3044\u306A\u3054\u98EF\u3063\u5B50\u3067\u3057\u305F\u304C\u4ECA\u3068\u306A\u3063\u3066\u306F\u308F\u3041\u3044\u30D1\u30F3\u3048\u3093\u3069\u30D1\u30F3\u3060\u3044\u3059\u304D\u3063\u3066\u306A\u5177\u5408\u3067\u3059\u3057\u304A\u3059\u3057",
  "id" : 206033357321146368,
  "created_at" : "2012-05-25 14:45:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206032885994618880",
  "text" : "\u3055\u3063\u304D\u306E\u5317\u5C71\u306E\u30AB\u30D5\u30A7\u30B5\u30ED\u30F3wifi\u98DB\u3093\u3067\u308B\u3068\u304B\u6FC0\u71B1\u3059\u304E\u308B",
  "id" : 206032885994618880,
  "created_at" : "2012-05-25 14:44:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206032604078669824",
  "text" : "\u3042\u305D\u3053\u306E\u5375\u30B5\u30F3\u30C9\u306F\u5727\u5012\u7684\u7F8E\u5473\u3057\u3055",
  "id" : 206032604078669824,
  "created_at" : "2012-05-25 14:42:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206032391142244352",
  "geo" : { },
  "id_str" : "206032547828867073",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30D6\u30EA\u30A2\u30F3\u30C7\u30A3\u30FC\u30BA\u306F\u98DF\u30D1\u30F3\u306E\u5B89\u5B9A\u611F\u304C\u30E4\u30D0\u3044\u3067\u3059\u3002\u30B5\u30F3\u30C9\u30A4\u30C3\u30C1\u3082\u7F8E\u5473\u3057\u3044\u3002\u500B\u4EBA\u7684\u306B\u304A\u6C17\u306B\u5165\u308A\u306F\u30D4\u30ED\u30B7\u30AD\u3067\u3059\u304C\u304C\u304C",
  "id" : 206032547828867073,
  "in_reply_to_status_id" : 206032391142244352,
  "created_at" : "2012-05-25 14:42:41 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206032435098550272",
  "text" : "\u30D0\u30A4\u30C8\u7D42\u308A\u306B\u884C\u3063\u3066\u30823\u6642\u9593\u304F\u3089\u3044\u6226\u3048\u308B\u3075\u3075\u3075\uFF48",
  "id" : 206032435098550272,
  "created_at" : "2012-05-25 14:42:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206032212171304960",
  "text" : "\u4ECA\u65E5\u306F\u884C\u304B\u306A\u3044\u3051\u308C\u3069\u306D",
  "id" : 206032212171304960,
  "created_at" : "2012-05-25 14:41:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206032189324918784",
  "text" : "\u6DF1\u591C\u306E\u81EA\u7FD2\u30AB\u30D5\u30A7\uFF08\u4E00\u4EBA\uFF09\u30EF\u30F3\u30C1\u30E3\u30F3\u3042\u308B\u306A\u30FC\u3075\u3075\u3075\u3075\u3075",
  "id" : 206032189324918784,
  "created_at" : "2012-05-25 14:41:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/G6F1Tyhf",
      "expanded_url" : "http:\/\/www.cafesalon.com\/?mode=f1",
      "display_url" : "cafesalon.com\/?mode=f1"
    } ]
  },
  "geo" : { },
  "id_str" : "206032044361388032",
  "text" : "\u5317\u5C71\u306B2\u6642\u307E\u3067\u3084\u3063\u3066\u308B\u30AB\u30D5\u30A7\u30B5\u30ED\u30F3\u3092\u898B\u3064\u3051\u3066\u3057\u307E\u3063\u305F\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042http:\/\/t.co\/G6F1Tyhf",
  "id" : 206032044361388032,
  "created_at" : "2012-05-25 14:40:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206031465568407553",
  "geo" : { },
  "id_str" : "206031607818223617",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30B0\u30E9\u30F3\u30C7\u30A3\u30FC\u30EB\u3068\u3044\u3046\u4E0B\u9D28\u672C\u901A\u308A\u3092\u3061\u3087\u3063\u3068\u5317\u306B\u3044\u3063\u305F\u6240\u3067\u3059",
  "id" : 206031607818223617,
  "in_reply_to_status_id" : 206031465568407553,
  "created_at" : "2012-05-25 14:38:57 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206031071668748288",
  "geo" : { },
  "id_str" : "206031235292725248",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \uFF76\uFF9E\uFF80\uFF6F",
  "id" : 206031235292725248,
  "in_reply_to_status_id" : 206031071668748288,
  "created_at" : "2012-05-25 14:37:29 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206031154128752640",
  "text" : "\u8FD1\u6240\u306E\u7F8E\u5473\u3057\u3044\u3068\u601D\u3063\u3066\u3044\u305F\u30D1\u30F3\u5C4B\u3055\u3093\u304C\u98DF\u3079\u30ED\u30B0\u306E\u4EAC\u90FD\u306E\u30D1\u30F3\u5C4B\u30E9\u30F3\u30AD\u30F3\u30B0\uFF11\uFF10\uFF10\u30673\u4F4D\u3060\u3063\u305F\uFF57\uFF57\uFF57\uFF57",
  "id" : 206031154128752640,
  "created_at" : "2012-05-25 14:37:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206030818467000320",
  "text" : "\u6DF1\u591C\u55B6\u696D\u3057\u3066\u308B\u30D1\u30F3\u5C4B\u3055\u3093\u306A\u3055\u305D\u3046\u30FB\u30FB\u30FB",
  "id" : 206030818467000320,
  "created_at" : "2012-05-25 14:35:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/5NxJHDvX",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=suteneko1027&c=end313124",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206029751020822528",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001suteneko1027\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002suteneko1027\u3055\u3093\u3084\u79C1\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3051\u308C\u3070\u767B\u9332\u3057\u3066\u30DE\u30C3\u30C1\u3059\u308B\u3068DM\u304C\u5C4A\u304D\u307E\u3059 http:\/\/t.co\/5NxJHDvX #gohantabeyo",
  "id" : 206029751020822528,
  "created_at" : "2012-05-25 14:31:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206029193790767104",
  "text" : "\u4ECA\u98DF\u3079\u305F\u3044\u3093\u3060\u3088\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 206029193790767104,
  "created_at" : "2012-05-25 14:29:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206029167211446274",
  "text" : "\u305D\u308A\u3083\u3042\u65E9\u671D\u306E\u65B9\u304C\u30D1\u30F3\u306E\u30A4\u30E1\u30FC\u30B8\u306B\u306F\u3042\u3046\u3093\u3060\u3051\u308C\u3069",
  "id" : 206029167211446274,
  "created_at" : "2012-05-25 14:29:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206029072759918592",
  "text" : "\u591C\u4E2D\u306B\u3084\u3063\u3066\u308B\u30D1\u30F3\u5C4B\u3055\u3093\u3063\u3066\u306A\u3044\u306E\u304B\u306A",
  "id" : 206029072759918592,
  "created_at" : "2012-05-25 14:28:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206028621935165440",
  "text" : "\u30AF\u30EA\u30FC\u30E0\u30D1\u30F3\u306A\u3089\u66AB\u5B9A\u4E00\u4F4D\u3060\u305C",
  "id" : 206028621935165440,
  "created_at" : "2012-05-25 14:27:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206028520516882433",
  "text" : "\u3042\u305D\u3053\u306E\u30AC\u30FC\u30EA\u30C3\u30AF\u30D5\u30E9\u30F3\u30B9\u3068\u30AF\u30EA\u30FC\u30E0\u30D1\u30F3\u304C\u7F8E\u5473\u3057\u304F\u3066",
  "id" : 206028520516882433,
  "created_at" : "2012-05-25 14:26:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206028446080565248",
  "text" : "\u2026\u7B2C\u4E00\u30DB\u30C6\u30EB\u306E\u4E0B\u306B\u3042\u308B\u30D1\u30F3\u5C4B\u3055\u3093\u3068\u304B\u307E\u3060\u3042\u308B\u306E\u304B\u3057\u3089\u3093",
  "id" : 206028446080565248,
  "created_at" : "2012-05-25 14:26:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206028409904701441",
  "text" : "@nartakio \u5409\u7965\u5BFA\u306F\u79FB\u308A\u5909\u308F\u308A\u304C\u6FC0\u3057\u3044\u3067\u3059\u3088\u306D\u3047\u3001\u5E30\u7701\u3059\u308B\u305F\u3073\u9055\u3046\u304A\u5E97\u304C",
  "id" : 206028409904701441,
  "created_at" : "2012-05-25 14:26:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206028068240896000",
  "text" : "\u5409\u7965\u5BFA\u3068\u304B\u9AD8\u6821\u6642\u4EE3\u90319\u56DE\u306F\u884C\u3063\u3066\u305F\u308F(^^)(^^)(^^)(^^)(^^)\u5727\u5012\u7684\u61D0\u304B\u3057\u30B9\u30DD\u30C3\u30C8(^^)(^^)(^^)",
  "id" : 206028068240896000,
  "created_at" : "2012-05-25 14:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206027916033794049",
  "text" : "@nartakio \u30CA\u30DD\u30EA\u30BF\u30F3\u5C02\u9580\u5E97\u3063\u3066\u6700\u8FD1\u3067\u304D\u305F\u3093\u3067\u3059\uFF1F",
  "id" : 206027916033794049,
  "created_at" : "2012-05-25 14:24:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u307F\u3085\uFF20\u3006\u5207\u3053\u308F\u3044bot",
      "screen_name" : "fumitsuki_yuno",
      "indices" : [ 3, 18 ],
      "id_str" : "141162766",
      "id" : 141162766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206027684348837888",
  "text" : "RT @fumitsuki_yuno: \u5BAE\u5B50\u300C\u306D\u30FC\u3001\u306A\u3093\u304B\u3053\u306E\u300E\u3046\u30FC\uFF01\u306B\u3083\u30FC\uFF01\u300F\u3063\u3066\u6B4C\u3001\u3086\u306E\u3063\u3061\u306E\u58F0\u306B\u4F3C\u3066\u308B\u306D\u30FC\u300D\u3086\u306E\u300C\u3048\u3063\uFF1F\u305D\u3001\u305D\u3046\u304B\u306A\uFF1F\u300D\u306A\u305A\u306A\u300C\u3086\u306E\u5148\u8F29\u3068\u3001\u3082\u3046\u4E00\u4EBA\u3069\u3053\u304B\u3067\u2026\u3048\u3063\u3068\u2026\u5409\u91CE\u5C4B\u5148\u751F\uFF1F\u300D\u5BAE\u300C\u3086\u306E\u3063\u3061\u3044\u3064\u306E\u307E\u306B\u30FC\uFF01\u300D\u3086\u300C\u3048\u3063\u3068\u3001\u79C1\u899A\u3048\u304C\u306A\u3044\u3093\u3060\u3051\u3069\u2026\u300D\u4E43\u8389\u300C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205967404419923969",
    "text" : "\u5BAE\u5B50\u300C\u306D\u30FC\u3001\u306A\u3093\u304B\u3053\u306E\u300E\u3046\u30FC\uFF01\u306B\u3083\u30FC\uFF01\u300F\u3063\u3066\u6B4C\u3001\u3086\u306E\u3063\u3061\u306E\u58F0\u306B\u4F3C\u3066\u308B\u306D\u30FC\u300D\u3086\u306E\u300C\u3048\u3063\uFF1F\u305D\u3001\u305D\u3046\u304B\u306A\uFF1F\u300D\u306A\u305A\u306A\u300C\u3086\u306E\u5148\u8F29\u3068\u3001\u3082\u3046\u4E00\u4EBA\u3069\u3053\u304B\u3067\u2026\u3048\u3063\u3068\u2026\u5409\u91CE\u5C4B\u5148\u751F\uFF1F\u300D\u5BAE\u300C\u3086\u306E\u3063\u3061\u3044\u3064\u306E\u307E\u306B\u30FC\uFF01\u300D\u3086\u300C\u3048\u3063\u3068\u3001\u79C1\u899A\u3048\u304C\u306A\u3044\u3093\u3060\u3051\u3069\u2026\u300D\u4E43\u8389\u300C\u2026\u305D\u308C\u5358\u306B\u4E2D\u306E\u4EBA\u304C\u300D\u6C99\u82F1\u300C\u4E43\u8389\u3001\u305D\u308C\u4EE5\u4E0A\u306F\u3060\u3081\u300D",
    "id" : 205967404419923969,
    "created_at" : "2012-05-25 10:23:50 +0000",
    "user" : {
      "name" : "\u3075\u307F\u3085\uFF20\u3006\u5207\u3053\u308F\u3044bot",
      "screen_name" : "fumitsuki_yuno",
      "protected" : false,
      "id_str" : "141162766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607049340993937410\/2p0dVUgs_normal.jpg",
      "id" : 141162766,
      "verified" : false
    }
  },
  "id" : 206027684348837888,
  "created_at" : "2012-05-25 14:23:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206027641353019392",
  "text" : "OP\u3092\u6B4C\u3063\u3066\u3044\u308B\u306E\u306F\u3060\u308C\u304B\u306A\u30FC\uFF1F",
  "id" : 206027641353019392,
  "created_at" : "2012-05-25 14:23:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 3, 17 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206027173243523073",
  "text" : "RT @riveriver4361: \u3060\u3058\u3083\u308C\u8003\u3048\u3066\u304F\u308B\u308F(\u8A33\uFF1A\u98A8\u5442\u884C\u304F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "206026497784426498",
    "text" : "\u3060\u3058\u3083\u308C\u8003\u3048\u3066\u304F\u308B\u308F(\u8A33\uFF1A\u98A8\u5442\u884C\u304F",
    "id" : 206026497784426498,
    "created_at" : "2012-05-25 14:18:39 +0000",
    "user" : {
      "name" : "\u306F\u3080\u592B",
      "screen_name" : "cricetusmhx2",
      "protected" : false,
      "id_str" : "320494295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597398263998779394\/jzh35zBq_normal.jpg",
      "id" : 320494295,
      "verified" : false
    }
  },
  "id" : 206027173243523073,
  "created_at" : "2012-05-25 14:21:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206027122219819008",
  "text" : "\u304A\u98A8\u5442\u3044\u3063\u3068\u304D\u306A\u304C\u3089\u3086\u3063\u305F\u308A\u8003\u3048\u308C\u3070\u7121\u610F\u8B58\u306B\u9762\u767D\u3044\u30C0\u30B8\u30E3\u30EC\u304C\uFF1F",
  "id" : 206027122219819008,
  "created_at" : "2012-05-25 14:21:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206026509218091008",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u3082\u6D74\u3073\u3066\u306A\u304B\u3063\u305F\u3088\u3082\u3046",
  "id" : 206026509218091008,
  "created_at" : "2012-05-25 14:18:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206026365462523904",
  "text" : "\u3061\u3087\u3063\u3068\u3060\u3051\u98DF\u3079\u308B\u304B\u30FC\u672C\u5F53\u306B\u3061\u3087\u3063\u3068\u3060\u3051\u3060\u3051\u308C\u3069\u3002",
  "id" : 206026365462523904,
  "created_at" : "2012-05-25 14:18:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206026103779893248",
  "text" : "\u3057\u304B\u3057\u65E2\u306B\u7720\u3044\u304B\u3089\u65AD\u3063\u3066\u6B63\u89E3",
  "id" : 206026103779893248,
  "created_at" : "2012-05-25 14:17:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206025980266037249",
  "text" : "\u9EBB\u96C0\u8A98\u308F\u308C\u3066\u82E6\u6C41\u306E\u601D\u3044\u51FA\u65AD\u3063\u305F\u4ECATL\u306B\u6D41\u308C\u308B\u9EBB\u96C0\u7528\u8A9E\u304C\u3042\u3042\u3042\u3042\u3042\u3042",
  "id" : 206025980266037249,
  "created_at" : "2012-05-25 14:16:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206025580578213890",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u304A\u3086\u306F\u3093\u98DF\u3079\u3066\u306A\u3044\u3053\u3068\u306B\u304D\u304C\u3064\u3044\u305F",
  "id" : 206025580578213890,
  "created_at" : "2012-05-25 14:15:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206015912023822336",
  "text" : "\u4E94\u6642\u5B50\u3082\u51FA\u3066\u304D\u305F\uFF57\uFF57\uFF57",
  "id" : 206015912023822336,
  "created_at" : "2012-05-25 13:36:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206015268370132992",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u8CB7\u3063\u3066\u304D\u3066\u8AAD\u3093\u3067\u305F\u3089\u56DB\u6642\u5B50\u3055\u3093\u3063\u3066\u4EBA\u304C\u51FA\u3066\u304D\u305F\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 206015268370132992,
  "created_at" : "2012-05-25 13:34:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205799812438827008",
  "text" : "\u5C11\u3057\u5BD2\u3044",
  "id" : 205799812438827008,
  "created_at" : "2012-05-24 23:17:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205799780742479872",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 205799780742479872,
  "created_at" : "2012-05-24 23:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205680308853551104",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 205680308853551104,
  "created_at" : "2012-05-24 15:23:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205680156797444096",
  "text" : "\u3084\u307E\u3060\u3061\u3083\u3093\u307E\u3058\u3084\u307E\u3060",
  "id" : 205680156797444096,
  "created_at" : "2012-05-24 15:22:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "indices" : [ 3, 16 ],
      "id_str" : "310067164",
      "id" : 310067164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205680060529786880",
  "text" : "RT @_yamadachan_: \u307F\u3093\u306A\u3068\u3084\u307E\u3060\u3061\u3083\u3093\u306F\u3001\u30D1\u30F3\u53CB\u3060\u3088\uFF01\u2606",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205626927749402624",
    "text" : "\u307F\u3093\u306A\u3068\u3084\u307E\u3060\u3061\u3083\u3093\u306F\u3001\u30D1\u30F3\u53CB\u3060\u3088\uFF01\u2606",
    "id" : 205626927749402624,
    "created_at" : "2012-05-24 11:50:54 +0000",
    "user" : {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "protected" : false,
      "id_str" : "310067164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585053686205775873\/EygeOjja_normal.jpg",
      "id" : 310067164,
      "verified" : false
    }
  },
  "id" : 205680060529786880,
  "created_at" : "2012-05-24 15:22:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205629333245665280",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 205629333245665280,
  "created_at" : "2012-05-24 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205565883681218560",
  "geo" : { },
  "id_str" : "205566034193821696",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6700\u8FD1\u304B\u306A\u308A\u30DD\u30B9\u30C8\u6570\u6291\u3048\u3089\u308C\u3066\u308B\u306E\u3067\u3042\u308C\u3067\u3059\u304C\u3084\u3063\u3071\u308A\u2026\u306D\u3047",
  "id" : 205566034193821696,
  "in_reply_to_status_id" : 205565883681218560,
  "created_at" : "2012-05-24 07:48:56 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205564737210167296",
  "text" : "\u3044\u3084\u3053\u3063\u3061\u306E\u767A\u8A00\u304C\u7B52\u629C\u3051\u306A\u306E\u306F\u3044\u3044\u3093\u3060\u304C\u2026",
  "id" : 205564737210167296,
  "created_at" : "2012-05-24 07:43:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205564644075651072",
  "text" : "6\u4EBA\u3057\u304B\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u306A\u3044\u53CB\u4EBA\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u3066\u305F\u3093\u3060\u304C\u3053\u308C\u3044\u3044\u306E\u304B\u306A",
  "id" : 205564644075651072,
  "created_at" : "2012-05-24 07:43:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205528248958992384",
  "text" : "\u91CF\u5316\u5B50\n\u91CF\u5B50\u5316\n\u4F3C\u3066\u308B\uFF1F",
  "id" : 205528248958992384,
  "created_at" : "2012-05-24 05:18:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205525704459292672",
  "text" : "\u904A\u60F0\u306A\u4E8C\u5EA6\u5BDD",
  "id" : 205525704459292672,
  "created_at" : "2012-05-24 05:08:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u677Ebot",
      "screen_name" : "ev0lution249",
      "indices" : [ 3, 16 ],
      "id_str" : "572517303",
      "id" : 572517303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205525457205084160",
  "text" : "RT @ev0lution249: \u300C\u512A\u96C5\u306A\u9045\u523B\u300D\u3010\u3086\u3046\u304C\u306A\u3061\u3053\u304F\u3011 \u9045\u523B\u304C\u78BA\u5B9A\u3059\u308B\u3068\u9014\u7AEF\u306B\u300C\u3069\u3046\u305B\u9045\u523B\u3060\u3057\u300D\u306A\u3069\u3068\u7406\u89E3\u4E0D\u80FD\u306E\u958B\u304D\u76F4\u308A\u3092\u306F\u3058\u3081\u3001\u5404\u505C\u3067\u5EA7\u3063\u3066\u3044\u3063\u305F\u308A\u30B3\u30F3\u30D3\u30CB\u3067\u671D\u98DF\u3092\u7269\u8272\u3057\u305F\u308A\u59CB\u3081\u308B\u3053\u3068\u3002\u30AF\u30BA\u3067\u3042\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205503942573035520",
    "text" : "\u300C\u512A\u96C5\u306A\u9045\u523B\u300D\u3010\u3086\u3046\u304C\u306A\u3061\u3053\u304F\u3011 \u9045\u523B\u304C\u78BA\u5B9A\u3059\u308B\u3068\u9014\u7AEF\u306B\u300C\u3069\u3046\u305B\u9045\u523B\u3060\u3057\u300D\u306A\u3069\u3068\u7406\u89E3\u4E0D\u80FD\u306E\u958B\u304D\u76F4\u308A\u3092\u306F\u3058\u3081\u3001\u5404\u505C\u3067\u5EA7\u3063\u3066\u3044\u3063\u305F\u308A\u30B3\u30F3\u30D3\u30CB\u3067\u671D\u98DF\u3092\u7269\u8272\u3057\u305F\u308A\u59CB\u3081\u308B\u3053\u3068\u3002\u30AF\u30BA\u3067\u3042\u308B\u3002",
    "id" : 205503942573035520,
    "created_at" : "2012-05-24 03:42:12 +0000",
    "user" : {
      "name" : "\u9AD8\u677Ebot",
      "screen_name" : "ev0lution249",
      "protected" : false,
      "id_str" : "572517303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2195087430\/foxicon_normal.jpg",
      "id" : 572517303,
      "verified" : false
    }
  },
  "id" : 205525457205084160,
  "created_at" : "2012-05-24 05:07:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205460665320738816",
  "text" : "\u30B3\u30DB\u30E2\u30ED\u30B8\u30FC\u304B\u3068\u601D\u3063\u305F\uFF1F\u6B8B\u5FF5\uFF01\u30B3\u30B9\u30E2\u30ED\u30B8\u30FC\u3067\u3057\u305F\uFF01",
  "id" : 205460665320738816,
  "created_at" : "2012-05-24 00:50:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205434724422914048",
  "text" : "\u7121\u7406\u3084\u308A\u8D77\u304D\u305F \u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 205434724422914048,
  "created_at" : "2012-05-23 23:07:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205357057786916867",
  "text" : "\u4ECA\u65E5\u306F\u307E\u3068\u3082\u306B\u52D5\u304B\u306A\u3044\u3068\u8272\u3005\u30C0\u30E1\u3060\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 205357057786916867,
  "created_at" : "2012-05-23 17:58:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205356830610829312",
  "text" : "TeX\u3067(^^)\u3063\u3066\u53E9\u3044\u305F\u3089\u3046\u307E\u304F\u3044\u304B\u306A\u304B\u3063\u305F\u304B\u3089\u4E0D\u601D\u8B70\u306A\u529B\u3067\u304B\u304D\u6D88\u3055\u308C\u305F\u3093\u3060\u3068\u601D\u3046(^^)(^^)(^^)",
  "id" : 205356830610829312,
  "created_at" : "2012-05-23 17:57:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205329760459567104",
  "text" : "11\u884C11\u5217\u306E\u884C\u5217...(\u30B4\u30B4\u30B4\u30B4\u30B4",
  "id" : 205329760459567104,
  "created_at" : "2012-05-23 16:10:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205301371690434560",
  "text" : "\u8DB3\u75FA\u308C\u305F",
  "id" : 205301371690434560,
  "created_at" : "2012-05-23 14:17:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205145994969612288",
  "text" : "\u6628\u65E5\u4ECA\u65E5\u3068\u3059\u3054\u3044\u52E2\u3044\u3067\u30C0\u30E1\u4EBA\u9593\u3067\u3042\u308B",
  "id" : 205145994969612288,
  "created_at" : "2012-05-23 03:59:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205001035499061251",
  "text" : "@kotorin_z \u3067\u3001\u3067\u3059\u3088\u306D\u30FC(",
  "id" : 205001035499061251,
  "created_at" : "2012-05-22 18:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204998414679801857",
  "text" : "\u304B\u3001\u89E3\u6790\u5B66TL\u306F\u304A\u3001\u7D42\u308F\u3063\u3061\u3083\u3044\u307E\u3057\u305F\uFF1F",
  "id" : 204998414679801857,
  "created_at" : "2012-05-22 18:13:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204904497946959872",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 204904497946959872,
  "created_at" : "2012-05-22 12:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 20, 28 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/17CjRaMF",
      "expanded_url" : "http:\/\/4sq.com\/JkpwK7",
      "display_url" : "4sq.com\/JkpwK7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "204839319997923329",
  "text" : "\u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ\u00A0\u306B\u3044\u307E\u3059\u3002 w\/ @shigmax http:\/\/t.co\/17CjRaMF",
  "id" : 204839319997923329,
  "created_at" : "2012-05-22 07:41:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204816080751960064",
  "text" : "\u307E\u3054\u3053\u308D\u304C\u8A9E\u5B66\u306B\u6765\u306A\u3044\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 204816080751960064,
  "created_at" : "2012-05-22 06:08:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/5zPmtkOa",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/14?prefill=sigmapsi&c=end313124",
      "display_url" : "gohantabeyo.com\/nani\/14?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204742707254538242",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001sigmapsi\u3055\u3093\u304C\u3042\u3044\u305F\u3044\u305D\u3046\u3067\u3059\u3002sigmapsi\u3055\u3093\u3084\u79C1\u3068\u3042\u3044\u305F\u3051\u308C\u3070\u767B\u9332\u3057\u3066\u30DE\u30C3\u30C1\u3059\u308B\u3068DM\u304C\u5C4A\u304D\u307E\u3059 http:\/\/t.co\/5zPmtkOa #gohantabeyo",
  "id" : 204742707254538242,
  "created_at" : "2012-05-22 01:17:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204457293113344000",
  "text" : "6\u30DA\u30FC\u30B8\u306B\u6E21\u308B\u30CE\u30FC\u30C8\u3092\u8CC7\u6599\u3068\u3057\u3066\u307E\u3068\u3081\u30662\u6642\u9593\u306E\u767A\u8868\u306B\u53CE\u307E\u308B\u306E\u304B(^^)(^^)(^^)\u9069\u5B9C\u7AEF\u6298\u308B\u304B",
  "id" : 204457293113344000,
  "created_at" : "2012-05-21 06:23:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/kvzU6Pkj",
      "expanded_url" : "http:\/\/4sq.com\/La6rWZ",
      "display_url" : "4sq.com\/La6rWZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.026247, 135.78012773 ]
  },
  "id_str" : "204448921731338240",
  "text" : "\u4EAC\u90FD\u5927\u5B66\u4ED8\u5C5E\u56F3\u66F8\u9928\u4ED8\u5C5E24\u6642\u9593\u81EA\u7FD2\u5BA4\u00A0\u306B\u3044\u307E\u3059\u3002 (\u4EAC\u90FD\u5E02, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/kvzU6Pkj",
  "id" : 204448921731338240,
  "created_at" : "2012-05-21 05:49:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204447150711635968",
  "text" : "\u6FC3\u3044\u30B3\u30FC\u30D2\u30FC\u3068\u7518\u3044\u30C9\u30FC\u30CA\u30C4\u3068\u81EA\u4E3B\u4F11\u8B1B",
  "id" : 204447150711635968,
  "created_at" : "2012-05-21 05:42:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204425913566375936",
  "text" : "\u3061\u3087\u3063\u3068\u3070\u3063\u304B\u308A\u306D\u3059\u304E\u305F",
  "id" : 204425913566375936,
  "created_at" : "2012-05-21 04:18:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204382439123070977",
  "text" : "\u6559\u5BA4\u306B\u3064\u3044\u3066\u601D\u3044\u51FA\u3057\u305F",
  "id" : 204382439123070977,
  "created_at" : "2012-05-21 01:25:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204382437084643331",
  "text" : "\u666E\u901A\u306B1\u9650\u3082\u306E\u305E\u304B\u305A\u5E30\u3063\u3066\u305F\u3089\u826F\u304B\u3063\u305F",
  "id" : 204382437084643331,
  "created_at" : "2012-05-21 01:25:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204382427127349248",
  "text" : "\u4ECA\u304B\u3089\u5E30\u3063\u3066\u5BDD\u308B\u306E\u3082\u3042\u308A\u3060\u306A\u3053\u308A\u3083",
  "id" : 204382427127349248,
  "created_at" : "2012-05-21 01:25:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204382427144138752",
  "text" : "\u305D\u3046\u3044\u3084\u4E8C\u9650\u4F11\u8B1B\u304B",
  "id" : 204382427144138752,
  "created_at" : "2012-05-21 01:25:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204371632477839360",
  "text" : "\u7720\u6C17\u304C\u304C\u304C",
  "id" : 204371632477839360,
  "created_at" : "2012-05-21 00:42:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasutomo57jp",
      "screen_name" : "yasutomo57jp",
      "indices" : [ 3, 16 ],
      "id_str" : "9990482",
      "id" : 9990482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/LOSoRog6",
      "expanded_url" : "http:\/\/yfrog.com\/nwyg8yyj",
      "display_url" : "yfrog.com\/nwyg8yyj"
    } ]
  },
  "geo" : { },
  "id_str" : "204356970382245890",
  "text" : "RT @yasutomo57jp: \u90E8\u5206\u65E5\u98DF\u301C\u266A\uFF08\u30C9\u25CB\u3048\u3082\u3093\u304C\u9053\u5177\u3092\u51FA\u3059\u611F\u3058\u3067\uFF09  http:\/\/t.co\/LOSoRog6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/LOSoRog6",
        "expanded_url" : "http:\/\/yfrog.com\/nwyg8yyj",
        "display_url" : "yfrog.com\/nwyg8yyj"
      } ]
    },
    "geo" : { },
    "id_str" : "204356732187705345",
    "text" : "\u90E8\u5206\u65E5\u98DF\u301C\u266A\uFF08\u30C9\u25CB\u3048\u3082\u3093\u304C\u9053\u5177\u3092\u51FA\u3059\u611F\u3058\u3067\uFF09  http:\/\/t.co\/LOSoRog6",
    "id" : 204356732187705345,
    "created_at" : "2012-05-20 23:43:36 +0000",
    "user" : {
      "name" : "yasutomo57jp",
      "screen_name" : "yasutomo57jp",
      "protected" : false,
      "id_str" : "9990482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3019914938\/60e93d9af47d9ed763cf321bf08aa689_normal.png",
      "id" : 9990482,
      "verified" : false
    }
  },
  "id" : 204356970382245890,
  "created_at" : "2012-05-20 23:44:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204338484746534915",
  "geo" : { },
  "id_str" : "204338629085110273",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3086",
  "id" : 204338629085110273,
  "in_reply_to_status_id" : 204338484746534915,
  "created_at" : "2012-05-20 22:31:40 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204338247738990593",
  "text" : "\u30D0\u30EB\u30B9",
  "id" : 204338247738990593,
  "created_at" : "2012-05-20 22:30:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204336104827125762",
  "text" : "\u65E5\u8755\u304B\u3093\u3051\u30FC\u306D\u30FC\u3063w",
  "id" : 204336104827125762,
  "created_at" : "2012-05-20 22:21:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204316460305227776",
  "text" : "\u7D50\u69CB\u4EBA\u304C\u30B0\u30E9\u30A6\u30F3\u30C9\u65B9\u5411\u306B\u6D41\u308C\u3066\u884C\u304F\u306A\u30FC",
  "id" : 204316460305227776,
  "created_at" : "2012-05-20 21:03:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204316235201126400",
  "text" : "\u6CE8:6\u3058\u3057\u3085\u3046\u3054\u3046",
  "id" : 204316235201126400,
  "created_at" : "2012-05-20 21:02:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204315619632496642",
  "geo" : { },
  "id_str" : "204315917906219008",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 204315917906219008,
  "in_reply_to_status_id" : 204315619632496642,
  "created_at" : "2012-05-20 21:01:25 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204315294104166400",
  "text" : "\u30E2\u30F3\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 204315294104166400,
  "created_at" : "2012-05-20 20:58:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204315285455511553",
  "text" : "\u305D\u3057\u3066\u8AB0\u3082\u3044\u306A\u3044\u306E\u3060\u304C\u30FC\uFF1F",
  "id" : 204315285455511553,
  "created_at" : "2012-05-20 20:58:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204315278350364672",
  "text" : "\u306A\u306B\u306F\u3068\u3082\u3042\u308C\u30FC\uFF1F",
  "id" : 204315278350364672,
  "created_at" : "2012-05-20 20:58:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204309983108669441",
  "text" : "\u306A\u3093\u3084\u304B\u3093\u3084\u3067\u3061\u3083\u3093\u3068\u304A\u304D\u305F",
  "id" : 204309983108669441,
  "created_at" : "2012-05-20 20:37:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204179766574723073",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 204179766574723073,
  "created_at" : "2012-05-20 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204172559367933952",
  "text" : "\u4E00\u5FDC\uFF15\uFF1A\uFF13\uFF10\u4F4D\u306B\u76EE\u899A\u307E\u3057\u639B\u3051\u308B\u304B\u30FB\u30FB\u30FB\u30FB",
  "id" : 204172559367933952,
  "created_at" : "2012-05-20 11:31:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204172496180748288",
  "text" : "\u65E2\u306B\u7720\u3044\u304C\u65E5\u4ED8\u5909\u308B\u304F\u3089\u3044\u307E\u3067\u9811\u5F35\u308D\u3046",
  "id" : 204172496180748288,
  "created_at" : "2012-05-20 11:31:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204081316776509441",
  "text" : "9-1\u306E\u30B9\u30C8\u30E9\u30A4\u30AF\u306F\u5207\u306A\u3044",
  "id" : 204081316776509441,
  "created_at" : "2012-05-20 05:29:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/75t9Pq4E",
      "expanded_url" : "http:\/\/4sq.com\/JfH2iP",
      "display_url" : "4sq.com\/JfH2iP"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "204058925325238273",
  "text" : "\u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ\u00A0\u306B\u3044\u307E\u3059\u3002 (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/75t9Pq4E",
  "id" : 204058925325238273,
  "created_at" : "2012-05-20 04:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203893027977170947",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 203893027977170947,
  "created_at" : "2012-05-19 17:01:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203888612704649216",
  "text" : "\u89E3\u3051\u305F\uFF01\u30D3\u30D3\u3063\u3066\u6765\u305F\uFF01",
  "id" : 203888612704649216,
  "created_at" : "2012-05-19 16:43:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203883958197424129",
  "text" : "\u5727\u5012\u7684\u7406\u89E3\uFF01\uFF01\uFF01\uFF01",
  "id" : 203883958197424129,
  "created_at" : "2012-05-19 16:24:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203859568084779008",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u672C\u5F53\u306B\u96E2\u8131\u3002Tween\u843D\u3068\u3059\u3002\u307E\u305F\u306D\u3002",
  "id" : 203859568084779008,
  "created_at" : "2012-05-19 14:48:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 18, 25 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203857896776269825",
  "text" : "\u306E\u3046\u3053\u306F\u306A\u3093\u3067\u3082\u77E5\u3063\u3066\u308B\u306A\u3041 QT @tenapi: \u306E\u3046\u3053Nose\u3063\u3066\u3069\u3093\u306A\u9F3B\u306A\u306E\u304B\u306A\u3042",
  "id" : 203857896776269825,
  "created_at" : "2012-05-19 14:41:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203857316091670530",
  "text" : "\u65E5\u4ED8\u5909\u3063\u305F\u3089\u52C9\u5F37\u3059\u308B\u3088\u3002\u3002\u3002",
  "id" : 203857316091670530,
  "created_at" : "2012-05-19 14:39:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203856815316934656",
  "text" : "good!",
  "id" : 203856815316934656,
  "created_at" : "2012-05-19 14:37:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203856779359158272",
  "text" : "\u5927\u4F53\u300C\u3050\u3046\u300D\u306E\u5B57\u304C\u9055\u3046\u3002\u3050\u3046\u306E\u97F3\u3082\u3067\u306A\u3044\u3002",
  "id" : 203856779359158272,
  "created_at" : "2012-05-19 14:36:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203856463922331651",
  "text" : "\u5947\u9047\u3063\u3066\u8A00\u3046\u3051\u3069\u5947\u6570\u304B\u5076\u6570\u304B\u3063\u3066\u8A00\u308F\u308C\u305F\u3089\u3069\u3063\u3061\u304B\u3060\u3088\u306D\u3001\u3068\u601D\u3063\u305F\u304C\u5B9F\u6570\u3060\u3068\u305D\u3046\u3082\u3044\u304B\u306A\u304B\u3063\u305F\u3002\u5947\u9047\u3060\u3002",
  "id" : 203856463922331651,
  "created_at" : "2012-05-19 14:35:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BB\u30F3\u30B1\u30A4",
      "screen_name" : "a33554432",
      "indices" : [ 0, 10 ],
      "id_str" : "97614100",
      "id" : 97614100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203855964389126144",
  "geo" : { },
  "id_str" : "203856276193681410",
  "in_reply_to_user_id" : 97614100,
  "text" : "@a33554432 \u99C4\u6D12\u843D\u306F\u30AC\u30F3\u30AC\u30F3\u91CD\u306D\u3066\u304D\u3066\u304F\u3060\u3055\u3044\u306D\uFF57",
  "id" : 203856276193681410,
  "in_reply_to_status_id" : 203855964389126144,
  "created_at" : "2012-05-19 14:34:58 +0000",
  "in_reply_to_screen_name" : "a33554432",
  "in_reply_to_user_id_str" : "97614100",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203855677263839232",
  "text" : "\u8A00\u8449\u904A\u3073\u306E\u6307\u91DD\uFF08\u79C1\u5FC3\uFF09\n\uFF48\u306E\u97F3\u306F\u7121\u8996\u3057\u3066\u3082\u305D\u3093\u306A\u306B\u82E6\u3057\u304F\u306A\u3044\n\u3084\u3086\u3088\u306E\u5927\u304D\u3055\u306F\u4EA4\u63DB\u53EF\u80FD\n\u6FC1\u97F3\u534A\u6FC1\u97F3\u306F\u7740\u8131\u81EA\u7531\n\u8A00\u8449\u3067\u91CD\u306D\u306A\u304F\u3066\u3082\u95A2\u9023\u8A9E\u3067\u3082\n\u82F1\u8A9E\u306B\u5DEE\u3057\u66FF\u3048\u308B\n\n\u3068\u304B\u8A00\u3044\u3064\u3064\u9BAE\u5EA6\u3092\u512A\u5148\u3057\u3066\u601D\u3044\u3064\u3044\u305F\u3088\u3046\u306B\u3084\u308B\u306E\u304C\u4E00\u756A\u3044\u3044",
  "id" : 203855677263839232,
  "created_at" : "2012-05-19 14:32:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BB\u30F3\u30B1\u30A4",
      "screen_name" : "a33554432",
      "indices" : [ 0, 10 ],
      "id_str" : "97614100",
      "id" : 97614100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203854315771789315",
  "geo" : { },
  "id_str" : "203854898155106305",
  "in_reply_to_user_id" : 97614100,
  "text" : "@a33554432 \u7D20\u6570\u3092\u6570\u3048\u3088\u3046\u305C\uFF01",
  "id" : 203854898155106305,
  "in_reply_to_status_id" : 203854315771789315,
  "created_at" : "2012-05-19 14:29:29 +0000",
  "in_reply_to_screen_name" : "a33554432",
  "in_reply_to_user_id_str" : "97614100",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203854180333535232",
  "text" : "\u5E73\u6CC9\u3055\u3093\u6BCE\u56DE\u50D5\u306E\u5FC3\u306E\u58F0\u3092\u5148\u3093\u3058\u3066\u30DD\u30B9\u30C8\u3059\u308B\u306E\u3084\u3081\u3066\u307B\u3057\u3044\uFF57\uFF57\uFF57",
  "id" : 203854180333535232,
  "created_at" : "2012-05-19 14:26:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203853597316878339",
  "text" : "\u6CB8\u70B9\u304C\u4E0B\u304C\u3063\u3066\u3093",
  "id" : 203853597316878339,
  "created_at" : "2012-05-19 14:24:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3093\u305F\u308D\u30FC",
      "screen_name" : "x_kintaro_x",
      "indices" : [ 3, 15 ],
      "id_str" : "200090098",
      "id" : 200090098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203853473542979584",
  "text" : "RT @x_kintaro_x: \uFF90\uFF76\uFF82\uFF9E\uFF77\uFF93\u308E\u304A\u3087\u3044\u3060\u2026\u2026 \uFF72\uFF76\uFF80\uFF9E\uFF93\u3068\u3044\u3063\u3057\u3087\u306B\u2026\u2026 \uFF90\uFF76\uFF82\uFF9E\uFF77\uFF93\u308E\u2026\u2026\u306A\u304B\u307E\u307B\u3057\u3043\u306A\u3063\u3066\u3049\u3082\u3063\u3066\u2026\u2026\u3060\u304B\u3089\u2026\u2026\u3076\u3093\u308C\u3064\u3057\u3066\u2026\u2026\uFF8C\uFF74\uFF80\u3087\u2026\u2026 \u3067\u3082\u2026\u2026\uFF90\uFF84\uFF9E\uFF98\uFF91\uFF7C\u2026\u2026\u3042\u3043\u3064\u308E\u3069\u3045\u3076\u3064\u306E\u304F\u305B\u306B\u2026\u2026\u3088\u3045\u308A\u3087\u304F\u305F\u3043\u3082\u3063\u3066\u308B\u2026\u2026\u3067\u3082\u2026\u2026\uFF90\uFF76\uFF82\uFF9E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200236132536029185",
    "text" : "\uFF90\uFF76\uFF82\uFF9E\uFF77\uFF93\u308E\u304A\u3087\u3044\u3060\u2026\u2026 \uFF72\uFF76\uFF80\uFF9E\uFF93\u3068\u3044\u3063\u3057\u3087\u306B\u2026\u2026 \uFF90\uFF76\uFF82\uFF9E\uFF77\uFF93\u308E\u2026\u2026\u306A\u304B\u307E\u307B\u3057\u3043\u306A\u3063\u3066\u3049\u3082\u3063\u3066\u2026\u2026\u3060\u304B\u3089\u2026\u2026\u3076\u3093\u308C\u3064\u3057\u3066\u2026\u2026\uFF8C\uFF74\uFF80\u3087\u2026\u2026 \u3067\u3082\u2026\u2026\uFF90\uFF84\uFF9E\uFF98\uFF91\uFF7C\u2026\u2026\u3042\u3043\u3064\u308E\u3069\u3045\u3076\u3064\u306E\u304F\u305B\u306B\u2026\u2026\u3088\u3045\u308A\u3087\u304F\u305F\u3043\u3082\u3063\u3066\u308B\u2026\u2026\u3067\u3082\u2026\u2026\uFF90\uFF76\uFF82\uFF9E\uFF77\uFF93\u3068\uFF72\uFF76\uFF80\uFF9E\uFF93\u308E\u2026\u2026\u30BA\u30C3\u30C8\u85FB\u3060\u3087\u2026\u2026\uFF01\uFF01",
    "id" : 200236132536029185,
    "created_at" : "2012-05-09 14:49:48 +0000",
    "user" : {
      "name" : "\u304D\u3093\u305F\u308D\u30FC",
      "screen_name" : "x_kintaro_x",
      "protected" : false,
      "id_str" : "200090098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1803723065\/osamu_normal.jpg",
      "id" : 200090098,
      "verified" : false
    }
  },
  "id" : 203853473542979584,
  "created_at" : "2012-05-19 14:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203853199126437888",
  "text" : "\u9999\u5DDD\u306A\u306E\u306B\u305D\u3070\u3068\u306F\u3053\u308C\u3044\u304B\u306B",
  "id" : 203853199126437888,
  "created_at" : "2012-05-19 14:22:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 25, 32 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 51, 62 ],
      "id_str" : "455059629",
      "id" : 455059629
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 78, 88 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203853126544003074",
  "text" : "\u6BBF\u4E0B\u306E\u305D\u3070\u306B\u3042\u308A\u307E\u3059\uFF01\uFF08\u3046\u3069\u3093\u3058\u3083\u306A\u304F\u3066\uFF09 QT @tenapi: \u9999\u5DDD\u306E\u3042\u308A\u304B\u304C\u5206\u304B\u3089\u306A\u3044\u3002 RT @hrizm_math: \u5FB3\u5CF6\u3092\u8CB7\u3063\u3066\u5F97\u3057\u307E\u3002 RT @end313124 \u6F06\u9ED2\u306E\u56DB\u56FD #\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC",
  "id" : 203853126544003074,
  "created_at" : "2012-05-19 14:22:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203852505925431298",
  "text" : "@9110alice \u50D5\u3082\u3068\u3082\u3068\u7D50\u69CB\u597D\u304D\u306A\u3093\u3067\u3059\u3051\u3069\u306D",
  "id" : 203852505925431298,
  "created_at" : "2012-05-19 14:19:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203852255512903681",
  "text" : "\u3057\u3066\u304D\u3057\u3088\u3046\u3068\u304A\u3082\u3063\u305F\u3089\u4E88\u9632\u7DDA\u304C",
  "id" : 203852255512903681,
  "created_at" : "2012-05-19 14:18:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203852142912618497",
  "geo" : { },
  "id_str" : "203852219215380480",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u305D\u308C\u3067\u3059\u3088\uFF01",
  "id" : 203852219215380480,
  "in_reply_to_status_id" : 203852142912618497,
  "created_at" : "2012-05-19 14:18:51 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203851998783737856",
  "text" : "\u623F\u7DCF\u534A\u5CF6\u3067\u306E\u66B4\u8D70\u3092\u653E\u9001",
  "id" : 203851998783737856,
  "created_at" : "2012-05-19 14:17:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203851930118799360",
  "text" : "\u6F06\u9ED2\u306E\u56DB\u56FD\u3001\u4E5D\u5DDE\u3092\u6025\u8972\uFF01 #\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC",
  "id" : 203851930118799360,
  "created_at" : "2012-05-19 14:17:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC",
      "indices" : [ 6, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203851787566989312",
  "text" : "\u6F06\u9ED2\u306E\u56DB\u56FD #\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC",
  "id" : 203851787566989312,
  "created_at" : "2012-05-19 14:17:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203851636148412418",
  "text" : "#\u6709\u6816\u3078\u30C0\u30B8\u30E3\u30EC\u30B7\u30E3\u30EF\u30FC \u3068\u306F",
  "id" : 203851636148412418,
  "created_at" : "2012-05-19 14:16:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203851241665724416",
  "text" : "\u3044\u3061\u3058\u3085\u3046\u3072\u3083\u304F\u305B\u3093\u307E\u3093\u3075\u3075\u3075",
  "id" : 203851241665724416,
  "created_at" : "2012-05-19 14:14:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203851040137805826",
  "text" : "\u4E00\u5FDC\u5145\u5B9F\u98DB\u8E8D\u306F\u3042\u308C\u3069\u3082\u5C16\u5EA6\u3082\u6E80\u8DB3",
  "id" : 203851040137805826,
  "created_at" : "2012-05-19 14:14:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203850721198743552",
  "text" : "\u3055\u3066\u52C9\u5F37\u306B\u623B\u308B\u304B\u30FC\u6E80\u8DB3\u6E80\u8DB3",
  "id" : 203850721198743552,
  "created_at" : "2012-05-19 14:12:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203849902000840705",
  "text" : "\u306A\u305C\u3060\u308D\u3046\u30C4\u30E2\u5207\u308A\u3067\u624B\u304C\u9032\u3080\u82B1\u5CA1\u3055\u3093\u3092\u601D\u3044\u51FA\u3057\u305F",
  "id" : 203849902000840705,
  "created_at" : "2012-05-19 14:09:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 3, 9 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203849835915390977",
  "text" : "RT @alg_d: \u30B0\u30C3\u3068\u30AC\u30C3\u30C4\u30DD\u30FC\u30BA\u3057\u305F\u3060\u3051\u3067R\u3092\u6574\u5217\u3055\u305B\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "203745762780254208",
    "text" : "\u30B0\u30C3\u3068\u30AC\u30C3\u30C4\u30DD\u30FC\u30BA\u3057\u305F\u3060\u3051\u3067R\u3092\u6574\u5217\u3055\u305B\u305F\u3002",
    "id" : 203745762780254208,
    "created_at" : "2012-05-19 07:15:49 +0000",
    "user" : {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "protected" : false,
      "id_str" : "127940910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579632693668773888\/0Susg2n0_normal.jpg",
      "id" : 127940910,
      "verified" : false
    }
  },
  "id" : 203849835915390977,
  "created_at" : "2012-05-19 14:09:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203849741623246848",
  "text" : "\u3061\u3087\u3063\u3068\u99C4\u6D12\u843D\u306B\u91CD\u306D\u305F\u3060\u3051\u3067\u3053\u306E\u99C4\u6D12\u843D\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306F\u3055\u3059\u304C\u3060\u3063\u305F",
  "id" : 203849741623246848,
  "created_at" : "2012-05-19 14:09:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203848115185393665",
  "text" : "\u3053\u306E\u99C4\u6D12\u843D\u306E\u3054\u308A\u62BC\u3057\u306E\u611F\u3058\u306F\u540D\u6B8B\u60DC\u3057\u3044\u306A",
  "id" : 203848115185393665,
  "created_at" : "2012-05-19 14:02:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3084\u304B\u307E\u3057\u3044",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203847653602242561",
  "geo" : { },
  "id_str" : "203847995098271744",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u50D5\u304C\u3082\u3046\u3061\u3087\u3063\u3068\u3046\u307E\u3044\u3053\u3068\u8A00\u3048\u308C\u3070\u3044\u3044\u306E\u3067\u3059\u304C\u3001\u4ECA\u4E00\u3064\u305D\u306E\u3042\u305F\u308A\u306E\u529B\u304C\u5F31\u304F\u3066\u2026 \u305D\u3046\u30A6\u30A3\u30FC\u30AF\u30A8\u30F3\u30C9 #\u3084\u304B\u307E\u3057\u3044",
  "id" : 203847995098271744,
  "in_reply_to_status_id" : 203847653602242561,
  "created_at" : "2012-05-19 14:02:04 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203847125786824704",
  "text" : "\u53CE\u307E\u3063\u305F\u3088\u3046\u3060\u3057\u6025\u3044\u3067\u6F31\u3044\u3067\u6CE8\u3044\u3067\u3053\u3088\u3046",
  "id" : 203847125786824704,
  "created_at" : "2012-05-19 13:58:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203846118814126080",
  "geo" : { },
  "id_str" : "203846442442424320",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u4E00\u56DE\u3067\u601D\u3044\u3064\u3044\u3066\u3044\u305F\u3089\u3068\u601D\u3046\u3068\u8B0E\u306E\u9CE5\u808C\u3067\u3059\u306D\uFF57",
  "id" : 203846442442424320,
  "in_reply_to_status_id" : 203846118814126080,
  "created_at" : "2012-05-19 13:55:53 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203846125361434626",
  "text" : "\u6DFB\u524A\u304C\u5165\u3063\u3066\u609F\u3063\u305F\u6B63\u89E3",
  "id" : 203846125361434626,
  "created_at" : "2012-05-19 13:54:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 21, 28 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 51, 61 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203846023137857536",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u3092\u6CE8\u304E\u306B\u884C\u3051\u307E\u305B\u3093 \u3048\u3093\u3069 QT @tenapi: \u3010\u6DFB\u524A\u3011\u30B3\u30FC\u30D2\u30FC\u6CE8\u304E\u306B\u3044\u3051\u307E\u305B\u3093\u3069 RT @end313124: \u30CD\u30BF\u3063\u3066\u306E\u306F\u5C16\u5EA6\u3068\u9BAE\u5EA6\u304C\u5927\u4E8B\u3060\u304B\u3089\u30B3\u30FC\u30D2\u30FC\u3092\u6CE8\u304E\u306B\u3044\u3051\u306A\u3044\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 203846023137857536,
  "created_at" : "2012-05-19 13:54:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203845572845768705",
  "text" : "\u5727\u5012\u7684\u3075\u3075\u3075\u3075\u3075",
  "id" : 203845572845768705,
  "created_at" : "2012-05-19 13:52:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203845292804669440",
  "text" : "\u30CD\u30BF\u3063\u3066\u306E\u306F\u5C16\u5EA6\u3068\u9BAE\u5EA6\u304C\u5927\u4E8B\u3060\u304B\u3089\u30B3\u30FC\u30D2\u30FC\u3092\u6CE8\u304E\u306B\u3044\u3051\u306A\u3044\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 203845292804669440,
  "created_at" : "2012-05-19 13:51:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203845005339672577",
  "geo" : { },
  "id_str" : "203845100097372160",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u5927\u6CB3\u30C9\u30E9\u30DE\u306B\u51FA\u3066\u304D\u305F\uFF1F",
  "id" : 203845100097372160,
  "in_reply_to_status_id" : 203845005339672577,
  "created_at" : "2012-05-19 13:50:33 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 10, 21 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203844882979229696",
  "geo" : { },
  "id_str" : "203844975627223042",
  "in_reply_to_user_id" : 455059629,
  "text" : "\u8DA3\u5473\u306F\u534A\u8EAB\u6D74 QT @hrizm_math: \u4EEE\u9762\u30E9\u30A4\u30C0\u30FC\u30BF\u30A4\u30AC\u30FC\u300C\u306F\uFF5E\uFF5E\uFF5E\uFF5E\u3093\uFF01\u3057\u3093\uFF01\uFF01\u300D",
  "id" : 203844975627223042,
  "in_reply_to_status_id" : 203844882979229696,
  "created_at" : "2012-05-19 13:50:04 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203844172229251073",
  "text" : "\u306A\u3093\u3060\u3053\u306E\u30AE\u30E3\u30B0\u306B\u5BFE\u3059\u308B\u30CF\u30F3\u30B0\u30EA\u30FC\u7CBE\u795E\u30FB\u30FB\u30FB",
  "id" : 203844172229251073,
  "created_at" : "2012-05-19 13:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203843653582589953",
  "text" : "RT @Certain_Sanaas: \u30AD\u30BB\u30A4\/Tweeeeen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "203842645242556416",
    "text" : "\u30AD\u30BB\u30A4\/Tweeeeen",
    "id" : 203842645242556416,
    "created_at" : "2012-05-19 13:40:48 +0000",
    "user" : {
      "name" : "Sanaas",
      "screen_name" : "_Sanaas",
      "protected" : false,
      "id_str" : "176708934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520914212881567745\/58kXK_-E_normal.jpeg",
      "id" : 176708934,
      "verified" : false
    }
  },
  "id" : 203843653582589953,
  "created_at" : "2012-05-19 13:44:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203842953481961472",
  "text" : "\u73CD\u3057\u3044\u4EBA\u306BRT\u3055\u308C\u305F",
  "id" : 203842953481961472,
  "created_at" : "2012-05-19 13:42:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203842672601997312",
  "text" : "\u307C\u304F\u3082\u307F\u3084\u3084\u3055\u3093\u306B\u306F\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u3066\u307E\u305B\u3093(\uFF77\uFF98\uFF6F",
  "id" : 203842672601997312,
  "created_at" : "2012-05-19 13:40:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203842362185756673",
  "text" : "\u4E0B\u3089\u306C\u30AE\u30E3\u30B0\u3082\u91CD\u306D\u308B\u3053\u3068\u3067\u30E6\u30FC\u30E2\u30A2\u306B\u306A\u308B\u3002\u541B\u3082\u3082\u3063\u3068\u91CD\u306D\u3066\u3088\u3002",
  "id" : 203842362185756673,
  "created_at" : "2012-05-19 13:39:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203841197079396352",
  "text" : "\u3053\u308C\u30C0\u30E1\u3060\u306A\u3002\u30C0\u30E1\u3060\u3002",
  "id" : 203841197079396352,
  "created_at" : "2012-05-19 13:35:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 25, 32 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u306E\u3089\u3093\u3076\u308B",
      "screen_name" : "nolimbre",
      "indices" : [ 34, 43 ],
      "id_str" : "62256126",
      "id" : 62256126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203841168474251265",
  "text" : "\u305D\u306E\u30AF\u30B8\u30E9\u304C\u5420\u3048\u308B\u30AF\u30B8\u30E9\u3067\u9A5A\u3044\u305F\u300C\u307B\u3048\u30FC\u300D QT @tenapi: @nolimbre \u30AF\u30B8\u30E9\u3092\u6355\u307E\u3048\u3066\u9A5A\u3044\u305F\u300C\u307B\u3052\u30FC\u3063\u300D",
  "id" : 203841168474251265,
  "created_at" : "2012-05-19 13:34:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203840715443273729",
  "text" : "\u30AE\u30E3\u30B0\u306E\u91CD\u306D\u306F\u516C\u958B\u51E6\u5211\u3068\u6551\u6E08\u306E\u8AF8\u5203\u306E\u5263\u2026",
  "id" : 203840715443273729,
  "created_at" : "2012-05-19 13:33:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306E\u3089\u3093\u3076\u308B",
      "screen_name" : "nolimbre",
      "indices" : [ 18, 27 ],
      "id_str" : "62256126",
      "id" : 62256126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203840455757139969",
  "text" : "\u3053\u308C\u9762\u767D\u3044\u6C17\u304C(\u98E2\u9913)\u3059\u308B\uFF01 RT @nolimbre: \u9913\u6B7B\u3057\u305D\u3046\u306A\u4EBA\u3069\u3046\u3057\u306E\u71B1\u3044\u62B1\u64C1\u300C\u304C\u3057\u3063\u300D",
  "id" : 203840455757139969,
  "created_at" : "2012-05-19 13:32:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203837262901952512",
  "text" : "\u5727\u5012\u7684\u982D\u306E\u60AA\u3055\uFF01",
  "id" : 203837262901952512,
  "created_at" : "2012-05-19 13:19:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203837199291121664",
  "text" : "\u5727\u5012\u7684\u30EC\u30F3\u30B8\u3067\u30C1\u30F3\u3057\u305F\u304A\u597D\u307F\u713C\u304D\uFF01",
  "id" : 203837199291121664,
  "created_at" : "2012-05-19 13:19:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203837153439006720",
  "text" : "\u5727\u5012\u7684\u5E30\u5B85\uFF01\u5727\u5012\u7684\u7A7A\u8179\uFF01",
  "id" : 203837153439006720,
  "created_at" : "2012-05-19 13:18:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203817332445937664",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 203817332445937664,
  "created_at" : "2012-05-19 12:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203742865178898432",
  "text" : "\u51FA\u639B\u3051\u3088\u3046",
  "id" : 203742865178898432,
  "created_at" : "2012-05-19 07:04:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 12, 23 ],
      "id_str" : "229752118",
      "id" : 229752118
    }, {
      "name" : "\u8336\u67F1\u3055\u3093(\u304A\u4F11\u307F\u4E2D\u3067\u3059)",
      "screen_name" : "chabashirasan",
      "indices" : [ 24, 38 ],
      "id_str" : "472125109",
      "id" : 472125109
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 39, 49 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 61, 76 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 77, 85 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203711875400208384",
  "text" : ". @ispamgis @nisehorrrn @chabashirasan @Lisa_math @kotorin_z @G4_Hirano_chan @i_horse \u304A\u306F\u3088\u3046\u3042\u308A\u3067\u3057\u305F\u30FC\u30FC",
  "id" : 203711875400208384,
  "created_at" : "2012-05-19 05:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203706181888380930",
  "text" : "\u5C71\u7530\u3061\u3083\u3093\u30DE\u30B8\u5C71\u7530",
  "id" : 203706181888380930,
  "created_at" : "2012-05-19 04:38:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "indices" : [ 3, 16 ],
      "id_str" : "310067164",
      "id" : 310067164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203706046575951872",
  "text" : "RT @_yamadachan_: \u30D1\u30F3\u304F\u305A\u306E\u30AF\u30BA\u3068\u306A\u308A\u3066\uFF5E\u266A\u3000\u30D1\u30F3\u306B\u604B\u3057\u7D9A\u3051\u3088\u3046\uFF5E\u266A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "203705842330120192",
    "text" : "\u30D1\u30F3\u304F\u305A\u306E\u30AF\u30BA\u3068\u306A\u308A\u3066\uFF5E\u266A\u3000\u30D1\u30F3\u306B\u604B\u3057\u7D9A\u3051\u3088\u3046\uFF5E\u266A",
    "id" : 203705842330120192,
    "created_at" : "2012-05-19 04:37:12 +0000",
    "user" : {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "protected" : false,
      "id_str" : "310067164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585053686205775873\/EygeOjja_normal.jpg",
      "id" : 310067164,
      "verified" : false
    }
  },
  "id" : 203706046575951872,
  "created_at" : "2012-05-19 04:38:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203705989852172288",
  "text" : "\u305F\u3053\u713C\u304D\u7C89\u3067\u304A\u597D\u307F\u713C\u304D\u3081\u3044\u305F\u3082\u306E\u98DF\u3079\u305F",
  "id" : 203705989852172288,
  "created_at" : "2012-05-19 04:37:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203697426878562304",
  "text" : "\u6587\u7406\u306E\u5206\u96E2",
  "id" : 203697426878562304,
  "created_at" : "2012-05-19 04:03:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203690101321105410",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 203690101321105410,
  "created_at" : "2012-05-19 03:34:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203534079612825601",
  "text" : "\u6848\u5916\u306F\u304B\u3069\u3063\u305F\u306E\u3067\u3042\u308B\u3002\u7D50\u5C40\u3001\u591C\u306B\u81EA\u5B85\u3067\u3001\u3063\u3066\u306E\u304C\u4E00\u756A\u52B9\u7387\u304C\u826F\u3044\u306E\u304B\u306A\u3002",
  "id" : 203534079612825601,
  "created_at" : "2012-05-18 17:14:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203533879955566592",
  "text" : "\u00A74\u307E\u3067\u7D42\u3048\u305F\u306E\u3067\u5BDD\u308B\uFF01\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uFF01",
  "id" : 203533879955566592,
  "created_at" : "2012-05-18 17:13:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203527393036607489",
  "text" : "\u6109\u5FEB\u306B\u7D20\u6575\u306B\u3082\u3046\u4E00\u3064\u306E\u6761\u4EF6\u3092\u6E80\u305F\u3059\u3057\u304B\u306A\u3044\u305C",
  "id" : 203527393036607489,
  "created_at" : "2012-05-18 16:48:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203527230532493312",
  "text" : "\u3068\u3066\u3082\u3058\u3083\u306A\u3044\u304C4\u6642\u307E\u3067\u8D77\u304D\u3066\u308B\u81EA\u4FE1\u304C\u306A\u3044\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 203527230532493312,
  "created_at" : "2012-05-18 16:47:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6B7B\u4EA1\u30D5\u30E9\u30B0",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203526534282227712",
  "geo" : { },
  "id_str" : "203526695490306049",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u50D5\u306F\u8D77\u304D\u3089\u308C\u305F\u3089\u884C\u304D\u307E\u3059 #\u6B7B\u4EA1\u30D5\u30E9\u30B0",
  "id" : 203526695490306049,
  "in_reply_to_status_id" : 203526534282227712,
  "created_at" : "2012-05-18 16:45:20 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203524113585803265",
  "text" : "\u307E\u307E\u3068\u3044\u3046\u304B\u305F\u307E\u306B\u3001\u304B",
  "id" : 203524113585803265,
  "created_at" : "2012-05-18 16:35:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203523984166367233",
  "text" : "\u4E00\u65E5100\u306A\u3089\u81EA\u5206\u3067\u3082\u307E\u307E\u3042\u308B\u306A\u30FC(",
  "id" : 203523984166367233,
  "created_at" : "2012-05-18 16:34:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/G3IGKPup",
      "expanded_url" : "http:\/\/www.itmedia.co.jp\/news\/articles\/1205\/18\/news091.html",
      "display_url" : "itmedia.co.jp\/news\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203523878641868800",
  "text" : "RT @sanH_3983: \u300CTwitter\u306E\u305B\u3044\u3067\u7559\u5E74\u3057\u307E\u3057\u305F\u300D\u2015\u2015\u5973\u5B50\u5927\u751F\u304C\u8A9E\u308B\u201C\u30BD\u30FC\u30B7\u30E3\u30EB\u4F9D\u5B58\u201D (1\/2) - ITmedia \u30CB\u30E5\u30FC\u30B9 http:\/\/t.co\/G3IGKPup\n\u4E00\u65E5\uFF11\uFF10\uFF10\u30C4\u30A4\u30FC\u30C8\u3067\u7559\u5E74\u3060\u3063\u305F\u3089\u4FFA\u306F\u4E00\u4F53\u4F55\u6D6A\u3059\u308B\u3053\u3068\u306B\u306A\u308B\u3093\u3060\u3063\u3066\u3070\u3088\u30FB\u30FB\u30FB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/G3IGKPup",
        "expanded_url" : "http:\/\/www.itmedia.co.jp\/news\/articles\/1205\/18\/news091.html",
        "display_url" : "itmedia.co.jp\/news\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "203522523487408128",
    "text" : "\u300CTwitter\u306E\u305B\u3044\u3067\u7559\u5E74\u3057\u307E\u3057\u305F\u300D\u2015\u2015\u5973\u5B50\u5927\u751F\u304C\u8A9E\u308B\u201C\u30BD\u30FC\u30B7\u30E3\u30EB\u4F9D\u5B58\u201D (1\/2) - ITmedia \u30CB\u30E5\u30FC\u30B9 http:\/\/t.co\/G3IGKPup\n\u4E00\u65E5\uFF11\uFF10\uFF10\u30C4\u30A4\u30FC\u30C8\u3067\u7559\u5E74\u3060\u3063\u305F\u3089\u4FFA\u306F\u4E00\u4F53\u4F55\u6D6A\u3059\u308B\u3053\u3068\u306B\u306A\u308B\u3093\u3060\u3063\u3066\u3070\u3088\u30FB\u30FB\u30FB",
    "id" : 203522523487408128,
    "created_at" : "2012-05-18 16:28:45 +0000",
    "user" : {
      "name" : "3\u306EH",
      "screen_name" : "DJ_3H",
      "protected" : false,
      "id_str" : "457587293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603579806542757888\/IC1pmDPo_normal.jpg",
      "id" : 457587293,
      "verified" : false
    }
  },
  "id" : 203523878641868800,
  "created_at" : "2012-05-18 16:34:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203523851194339330",
  "text" : "\u3044\u3061\u306B\u3061",
  "id" : 203523851194339330,
  "created_at" : "2012-05-18 16:34:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203521585787830276",
  "text" : "\u3053\u308C\u4EE5\u4E0A\u306E\u30B3\u30FC\u30D2\u30FC\u306E\u6295\u4E0E\u306F\u306A\u3093\u304B\u826F\u304F\u306A\u3044\u6C17\u304C\u3059\u308B",
  "id" : 203521585787830276,
  "created_at" : "2012-05-18 16:25:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203521443965845505",
  "text" : "\u6625\u7720\u3093\uFF5E\u6681\u3092\uFF5E\u899A\u3048\u305A\u3045\u3045\u3045",
  "id" : 203521443965845505,
  "created_at" : "2012-05-18 16:24:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203521290001334272",
  "text" : "\u9019\u3044\u5BC4\u308B\u7720\u6C17",
  "id" : 203521290001334272,
  "created_at" : "2012-05-18 16:23:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203520248022966274",
  "text" : "TeX\u3067\u6253\u3061\u76F4\u3059\u4E88\u5B9A\u3060\u304C\u305D\u3063\u3061\u306E\u65B9\u304C\u91CD\u52B4\u50CD\u3063\u307D\u3044\u305E\u3053\u308C",
  "id" : 203520248022966274,
  "created_at" : "2012-05-18 16:19:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203520076362694656",
  "text" : "\u53F3\u306B\u7A74\u304C\u3042\u308B\u30DA\u30FC\u30B8\u304B\u3089\u4F7F\u3044\u59CB\u3081\u3066\u3044\u305F...",
  "id" : 203520076362694656,
  "created_at" : "2012-05-18 16:19:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203515273721032704",
  "text" : "\u6DBC\u3057\u3052\u3067\u826F\u3044",
  "id" : 203515273721032704,
  "created_at" : "2012-05-18 15:59:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203515236781797376",
  "text" : "\u4E45\u3005\u306B\u751A\u5E73\u53D6\u308A\u51FA\u3057\u3066\u8896\u3092\u901A\u3057\u3066\u898B\u305F\u304C\u5FC3\u5730\u826F\u3044",
  "id" : 203515236781797376,
  "created_at" : "2012-05-18 15:59:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203509477692022785",
  "text" : "\u96C6\u4E2D\u304D\u308C\u305F\u3057\u30B7\u30E3\u30EF\u30FC\u304B\u306A",
  "id" : 203509477692022785,
  "created_at" : "2012-05-18 15:36:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203506807656820737",
  "text" : "\u30EA\u30CB\u30A2\u30FC",
  "id" : 203506807656820737,
  "created_at" : "2012-05-18 15:26:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203503058972450817",
  "text" : "\u9811\u5F35\u308C\u3070\u65E9\u304F\u5BDD\u3089\u308C\u308B\u30B7\u30B9\u30C6\u30E0\u3075\u3075\u3075\u3075",
  "id" : 203503058972450817,
  "created_at" : "2012-05-18 15:11:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203502992694050818",
  "text" : "\u3088\u3057\u3001\u7D42\u4E86\u6761\u4EF6\u3092\u300Csection\uFF14\u306E\u7D42\u4E86\u300D\u3042\u308B\u3044\u306F\u300C\uFF14\u6642\u306B\u306A\u308B\u3053\u3068\u300D\u306B\u3057\u3088\u3046",
  "id" : 203502992694050818,
  "created_at" : "2012-05-18 15:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u72EC\u308A\u8A00",
      "indices" : [ 30, 34 ]
    }, {
      "text" : "\u72EC\u308A\u8A00\u3060\u3063\u3066\u3070",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203499944970158082",
  "text" : "\uFF08\u304F\u308F\u3057\u304F\u558B\u308C\u306A\u3044\u306A\u3089\u304A\u3082\u3057\u308D\u3055\u3092\u5302\u308F\u305B\u306A\u3044\u3067\u307B\u3057\u3044\u306A\u30FC\uFF09 #\u72EC\u308A\u8A00 #\u72EC\u308A\u8A00\u3060\u3063\u3066\u3070",
  "id" : 203499944970158082,
  "created_at" : "2012-05-18 14:59:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203499555696820225",
  "geo" : { },
  "id_str" : "203499604220715009",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u3046\u306A\u3001\u305D\u308C\u306F\u6B8B\u5FF5",
  "id" : 203499604220715009,
  "in_reply_to_status_id" : 203499555696820225,
  "created_at" : "2012-05-18 14:57:41 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203499265660682240",
  "geo" : { },
  "id_str" : "203499344048029696",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \uFF4B\uFF57\uFF53\uFF4B",
  "id" : 203499344048029696,
  "in_reply_to_status_id" : 203499265660682240,
  "created_at" : "2012-05-18 14:56:39 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203499175449604097",
  "text" : "\uFF14\u6642\u307E\u3067\u9811\u5F35\u3063\u3066\u304B\u3089\u5BDD\u308B\u3053\u3068\u306B\u3057\u3088\u3046",
  "id" : 203499175449604097,
  "created_at" : "2012-05-18 14:55:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203493980669870080",
  "text" : "\u7D42\u308A\u306E\u30A2\u30AB\u30A6\u30F3\u30C8end\u3067\u3059",
  "id" : 203493980669870080,
  "created_at" : "2012-05-18 14:35:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203483581899747328",
  "text" : "\u5727\u5012\u7684\u7406\u89E3\uFF01\u6DFB\u3048\u5B57\u304C\u3064\u3076\u308C\u3066\u8AAD\u3081\u306A\u304B\u3063\u305F\u304C\u9583\u3044\u3066\u304B\u3089\u306F\u30B9\u30A4\u30B9\u30A4\u3060\u3063\u305F\uFF01",
  "id" : 203483581899747328,
  "created_at" : "2012-05-18 13:54:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203481281244299265",
  "text" : "\u30D0\u30A4\u30AF\u306E\u514D\u8A31\u6B32\u3057\u3044\u3059\u3046\u304C\u304F\u5F92\u3044\u305F\u3089\u5408\u5BBF\u3068\u304B\u884C\u304D\u305F\u3044",
  "id" : 203481281244299265,
  "created_at" : "2012-05-18 13:44:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7D42\u672B\u3060\u3051\u306B",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203480817488502784",
  "text" : "\u308F\u3041\u3044\u9031\u672B\u3001\u3048\u3093\u3069\u9031\u672B\u5927\u597D\u304D #\u7D42\u672B\u3060\u3051\u306B\uFF1F",
  "id" : 203480817488502784,
  "created_at" : "2012-05-18 13:43:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203451014815285249",
  "geo" : { },
  "id_str" : "203477129906761729",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax 6\uFF1A30\u3067\u3059\u304C\u884C\u304D\u307E\u3059?",
  "id" : 203477129906761729,
  "in_reply_to_status_id" : 203451014815285249,
  "created_at" : "2012-05-18 13:28:22 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203476206425866240",
  "text" : "\u3044\u3063\u3071\u3044\u3044\u308C\u3066\u30EC\u30F3\u30C1\u30F3\u306E\u65B9\u304C\u697D\u306A\u3093\u3060\u3051\u308C\u3069\u306D\u30FC\u3002\u305D\u308C\u3067\u3082\u7D76\u5BFE\u30A4\u30F3\u30B9\u30BF\u30F3\u30C8\u3088\u308A\u306F\u7F8E\u5473\u3057\u3044\u306F\u305A\u3060\u304C\u3002",
  "id" : 203476206425866240,
  "created_at" : "2012-05-18 13:24:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203476088045846531",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u304C\u5727\u5012\u7684\u7F8E\u5473\u3057\u3044\u3051\u308C\u3069\u3084\u3063\u3071\u308A\u3044\u308C\u305F\u3066\u306E\u65B9\u304C\u7F8E\u5473\u3057\u3044",
  "id" : 203476088045846531,
  "created_at" : "2012-05-18 13:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203420065176100865",
  "text" : "\u30D0\u30A4\u30C8\u884C\u304F\u304B.",
  "id" : 203420065176100865,
  "created_at" : "2012-05-18 09:41:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203419966161170432",
  "text" : "\u5727\u5012\u7684\u4E0D\u7406\u89E3\u30C3...",
  "id" : 203419966161170432,
  "created_at" : "2012-05-18 09:41:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203417582349467648",
  "text" : "\u66FF\u82AF\u3042\u308B\u304B\u3089\u304A\u3063\u3051\u30FC\u3067\u3059\u3088",
  "id" : 203417582349467648,
  "created_at" : "2012-05-18 09:31:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203417441915781120",
  "text" : "\u30DC\u30FC\u30EB\u30DA\u30F3 \u3044\u305A \u30C7\u30C3\u30C9",
  "id" : 203417441915781120,
  "created_at" : "2012-05-18 09:31:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203394971242467328",
  "geo" : { },
  "id_str" : "203395825018220545",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u96C6\u307E\u3063\u3066\u3082\u96C6\u307E\u3093\u306A\u304F\u3066\u3082\uFF12\uFF11\uFF1A\uFF12\uFF10\u5206\u304F\u3089\u3044\u307E\u3067\u306B\u30E1\u30FC\u30EB\u304A\u9858\u3044\u3057\u307E\u3059\uFF08\u30C4\u30A4\u30C3\u30BF\u30FC\u3060\u3068\u898B\u306A\u3044\u304B\u3082\uFF09",
  "id" : 203395825018220545,
  "in_reply_to_status_id" : 203394971242467328,
  "created_at" : "2012-05-18 08:05:18 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203394714622377985",
  "text" : "\u725B\u4E73\u3068\u30C9\u30FC\u30CA\u30C4\u8CB7\u3063\u3066\u304D\u305F\u3002\uFF11\uFF18\u6642\u904E\u304E\u307E\u3067",
  "id" : 203394714622377985,
  "created_at" : "2012-05-18 08:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203391036574269441",
  "geo" : { },
  "id_str" : "203394570388635648",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u4ECA\u591C\uFF1F\u30D0\u30A4\u30C8\u7D42\u308F\u3063\u3066\u3044\u3063\u3066\uFF12\uFF12\u6642\u8FD1\u304F\u306A\u308A\u307E\u3059\u304C\u305D\u308C\u3067\u3082\u826F\u3044\u306A\u3089\u884C\u304D\u307E\u3059",
  "id" : 203394570388635648,
  "in_reply_to_status_id" : 203391036574269441,
  "created_at" : "2012-05-18 08:00:19 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203388644118110208",
  "text" : "\u88F3\u83EF\u623F\u306E\uFF12\uFF10%\u5F15\u304D\u3063\u3066\u3044\u3064\u307E\u3067\u306A\u3093\u3067\u3059\u304B\u306D",
  "id" : 203388644118110208,
  "created_at" : "2012-05-18 07:36:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203388147407654912",
  "geo" : { },
  "id_str" : "203388301992923136",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u305D\u308C\u306F\u300C\u307C\u304F\u306E\u304B\u3093\u304C\u3048\u305F\u3055\u3044\u304D\u3087\u3046\u306E\u96C6\u5408\u3068\u4F4D\u76F8\u300D\u306B\u306A\u308B\u5371\u967A\u304C",
  "id" : 203388301992923136,
  "in_reply_to_status_id" : 203388147407654912,
  "created_at" : "2012-05-18 07:35:24 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203387941152759809",
  "text" : "\u3042\u3001\u305D\u308C\u3063\u3066\u4E00\u4EBA\u4E00\u4EBA\u306B\u5408\u308F\u305B\u305F\u5B66\u7FD2\u30D7\u30ED\u30B0\u30E9\u30E0\u3046\u3093\u305F\u3089\u304B\u3093\u305F\u3089\u3060\u304B\u3089\u9032\u7814\u30BC\u30DF\u3067\u5927\u5B66\u6570\u5B66\u6271\u3063\u305F\u3089\u6700\u5F37\u306A\u3093\u3058\u3083",
  "id" : 203387941152759809,
  "created_at" : "2012-05-18 07:33:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203387588508266496",
  "geo" : { },
  "id_str" : "203387729709510656",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u732B\u306E\u8CE2\u3055\u306B\u4F9D\u5B58\u3057\u305D\u3046\u3060\u304B\u3089\u3048\u3093\u3069\u306B\u3082\u5206\u304B\u308B\u96C6\u5408\u3068\u4F4D\u76F8\u3068\u304B\u6B32\u3057\u3044\u3067\u3059",
  "id" : 203387729709510656,
  "in_reply_to_status_id" : 203387588508266496,
  "created_at" : "2012-05-18 07:33:08 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203382500456800257",
  "text" : "\u6700\u8FD1\u30AB\u30E9\u30AA\u30B1\u304B\u30D3\u30EA\u30E4\u30FC\u30C9\u304B\u3067\u8FF7\u3063\u3066\u30D3\u30EA\u30E4\u30FC\u30C9\u3092\u9078\u3093\u3067\u308B\u304B\u3089\u30AB\u30E9\u30AA\u30B1\u884C\u304D\u305F\u3044",
  "id" : 203382500456800257,
  "created_at" : "2012-05-18 07:12:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203382022973034497",
  "text" : "\uFF12\uFF15\u6642\u3068\u304B\u3063\u3066\u8868\u73FE\u306F\u5927\u5ACC\u3044\u3060\u3051\u308C\u3069",
  "id" : 203382022973034497,
  "created_at" : "2012-05-18 07:10:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203381971848663041",
  "text" : "\u65E5\u4ED8\u306E\u5883\u754C\u306B\u53B3\u3057\u3044\u3048\u3093\u3069\u3068\u3057\u3066\u306F\uFF11\uFF16\u6642\u8868\u8A18\u306E\u65B9\u304C\u8AA4\u89E3\u304C\u7121\u304F\u3066\u3044\u3044\u3068\u601D\u3046\u3093\u3060",
  "id" : 203381971848663041,
  "created_at" : "2012-05-18 07:10:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203380766258896896",
  "text" : "\u5348\u5F8C\uFF14\u6642\u306F\u3042\u304F\u307E\u3067\uFF11\uFF16\u6642",
  "id" : 203380766258896896,
  "created_at" : "2012-05-18 07:05:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203380605755461632",
  "text" : "\u5BB6\u3067\u30B3\u30FC\u30D2\u30FC\u714E\u308C\u308B\u3068\uFF11\uFF4C\u8FD1\u304F\u5165\u308C\u3066\u3057\u307E\u3046\u7656\u3084\u3081\u305F\u3044",
  "id" : 203380605755461632,
  "created_at" : "2012-05-18 07:04:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203255871206211585",
  "text" : "\u305D\u308C\u306F\u305D\u308C\u3068\u3057\u3066\u4E8C\u5EA6\u5BDD\u8996\u91CE",
  "id" : 203255871206211585,
  "created_at" : "2012-05-17 22:49:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203255701722775552",
  "text" : "\u76EE\u899A\u307E\u3057\u9CF4\u3063\u305F\uFF01(^^)(^^)(^^)",
  "id" : 203255701722775552,
  "created_at" : "2012-05-17 22:48:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203151027548073986",
  "text" : "\u3072\u308B\u306E\u307B\u30FC\u3057\u306B\u30FC\u306D\u304C\u3044\u3092\u3055\u3055\u3050\u306A\u30FC\u3089\u30FC",
  "id" : 203151027548073986,
  "created_at" : "2012-05-17 15:52:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203145410641010689",
  "text" : "@i_horse \u767A\u8868\u3057\u305F\u6B21\u306E\u9031\u306B\u62C5\u5F53\u3063\u3066\u3053\u3068\u306B\u306A\u308A\u307E\u3057\u305F\u30FC",
  "id" : 203145410641010689,
  "created_at" : "2012-05-17 15:30:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203145260732383233",
  "text" : "@i_horse \u3042\u3001\u6765\u9031\u306E\u6708\u66DC\u306E\u708A\u4E8B\u5F53\u756A\u76F8\u99AC\u3055\u3093\u306A\u306E\u3067\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 203145260732383233,
  "created_at" : "2012-05-17 15:29:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203144659596353536",
  "text" : "\u30DE\u30B8\u89E3\u3063\u3066\u308B",
  "id" : 203144659596353536,
  "created_at" : "2012-05-17 15:27:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B5\u30D6\u30A6\u30A7\u30A4\u7A63\u5B50",
      "screen_name" : "SubwayMinoriko",
      "indices" : [ 3, 18 ],
      "id_str" : "182772668",
      "id" : 182772668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203144622795538432",
  "text" : "RT @SubwayMinoriko: \u3042\u3001\u30AA\u30EA\u30FC\u30D6\u3068\u30D4\u30AF\u30EB\u30B9\u591A\u3081\u3067\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202790115762900992",
    "text" : "\u3042\u3001\u30AA\u30EA\u30FC\u30D6\u3068\u30D4\u30AF\u30EB\u30B9\u591A\u3081\u3067\uFF01",
    "id" : 202790115762900992,
    "created_at" : "2012-05-16 15:58:25 +0000",
    "user" : {
      "name" : "\u30B5\u30D6\u30A6\u30A7\u30A4\u7A63\u5B50",
      "screen_name" : "SubwayMinoriko",
      "protected" : false,
      "id_str" : "182772668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1182146485\/submin7_normal.PNG",
      "id" : 182772668,
      "verified" : false
    }
  },
  "id" : 203144622795538432,
  "created_at" : "2012-05-17 15:27:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203144588687446016",
  "text" : "\u30B5\u30D6\u30A6\u30A7\u30A4\u306F\u30AA\u30EA\u30FC\u30D6\u3068\u30D4\u30AF\u30EB\u30B9\u591A\u3081\u6D3E",
  "id" : 203144588687446016,
  "created_at" : "2012-05-17 15:26:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203092580282548224",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 203092580282548224,
  "created_at" : "2012-05-17 12:00:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203050909805191169",
  "text" : "\u307E\u305F\u65E9\u304B\u3063\u305F",
  "id" : 203050909805191169,
  "created_at" : "2012-05-17 09:14:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202987714444935168",
  "text" : "@koketomi Kwakiutl",
  "id" : 202987714444935168,
  "created_at" : "2012-05-17 05:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202947928199938048",
  "text" : "\u5F8C\u308D\u3057\u304B\u7A7A\u3044\u3066\u3044\u306A\u304B\u3063\u305F\u304C\u666E\u901A\u306B\u898B\u3048\u306A\u3044\u305C",
  "id" : 202947928199938048,
  "created_at" : "2012-05-17 02:25:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202945456945373186",
  "text" : "\u7A7A\u8179",
  "id" : 202945456945373186,
  "created_at" : "2012-05-17 02:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202932058115420160",
  "text" : "\u9045\u523B\u3057\u3066\u884C\u3053\u3046\u3001\u4ED5\u65B9\u3042\u308B\u307E\u3044",
  "id" : 202932058115420160,
  "created_at" : "2012-05-17 01:22:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202931672830836737",
  "text" : "\u3080\u3045\u9593\u306B\u5408\u308F\u306A\u3044",
  "id" : 202931672830836737,
  "created_at" : "2012-05-17 01:20:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202928360110829568",
  "text" : "\u80A9\u3053\u308A\u3067\u306E\u982D\u75DB\u3082\u5C11\u3005",
  "id" : 202928360110829568,
  "created_at" : "2012-05-17 01:07:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202925926516932608",
  "text" : "\u76EE\u899A\u307E\u3057\u304C\u4E8C\u65E5\u9023\u7D9A\u3067\u306A\u3089\u306A\u304B\u3063\u305F\u3093\u3060\u304C",
  "id" : 202925926516932608,
  "created_at" : "2012-05-17 00:58:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202780447233687552",
  "text" : "\u3086\u308B\u308A\u3068\u5E03\u56E3\u306B\u79FB\u3063\u3066\u52C9\u5F37\u3057\u306A\u304C\u3089\u5165\u7720\u3092\u56F3\u308B\u304B",
  "id" : 202780447233687552,
  "created_at" : "2012-05-16 15:20:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202778867394551810",
  "text" : "\u3053\u308C\u71B1\u3044\u306D\u3002\u30EF\u30F3\u30C1\u30E3\u30F3\u3042\u308B\u306D\u3002",
  "id" : 202778867394551810,
  "created_at" : "2012-05-16 15:13:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 3, 13 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/nBW6xWfI",
      "expanded_url" : "http:\/\/www.kyoto-u.ac.jp\/ja\/news_data\/h\/h1\/news4\/2012\/120802_1.htm",
      "display_url" : "kyoto-u.ac.jp\/ja\/news_data\/h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202778828962144256",
  "text" : "RT @piano2683: \u3010\u4EAC\u90FD\u5927\u5B66\u6570\u7406\u89E3\u6790\u7814\u7A76\u6240 \u6570\u5B66\u5165\u9580\u516C\u958B\u8B1B\u5EA7\u3011 http:\/\/t.co\/nBW6xWfI \u9762\u767D\u305D\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/nBW6xWfI",
        "expanded_url" : "http:\/\/www.kyoto-u.ac.jp\/ja\/news_data\/h\/h1\/news4\/2012\/120802_1.htm",
        "display_url" : "kyoto-u.ac.jp\/ja\/news_data\/h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "202778279755788288",
    "text" : "\u3010\u4EAC\u90FD\u5927\u5B66\u6570\u7406\u89E3\u6790\u7814\u7A76\u6240 \u6570\u5B66\u5165\u9580\u516C\u958B\u8B1B\u5EA7\u3011 http:\/\/t.co\/nBW6xWfI \u9762\u767D\u305D\u3046",
    "id" : 202778279755788288,
    "created_at" : "2012-05-16 15:11:23 +0000",
    "user" : {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "protected" : false,
      "id_str" : "441021193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2439592037\/z97ztbh7aipnifu1d20y_normal.jpeg",
      "id" : 441021193,
      "verified" : false
    }
  },
  "id" : 202778828962144256,
  "created_at" : "2012-05-16 15:13:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202778436987658242",
  "text" : "\u306A\u3093\u304B\u98EF\u4E88\u60F3\u306E\u306F\u3084\u3063\u3066\u308B\u3051\u3069\u306A\u3093\u306A\u3093\u3067\u3059\u304B\u306D",
  "id" : 202778436987658242,
  "created_at" : "2012-05-16 15:12:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202777912640929792",
  "text" : "\u8D77\u304D\u3089\u308C\u305F\u3089\u884C\u3053\u3046\u304B\u306A\u2026",
  "id" : 202777912640929792,
  "created_at" : "2012-05-16 15:09:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202777479281262594",
  "geo" : { },
  "id_str" : "202777589759213568",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u305D\u306E\u6642\u9593\u306B\u305D\u306E\u5834\u6240\u306B\u3044\u308B\u3053\u3068\u304C\u4F55\u3088\u308A\u5927\u5909\u306A\u6E96\u5099\u306A\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 202777589759213568,
  "in_reply_to_status_id" : 202777479281262594,
  "created_at" : "2012-05-16 15:08:39 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202776929533837312",
  "text" : "\u9006\u306B\u8003\u3048\u308B\u3093\u3060\u3001\u99C4\u6D12\u843D\u3092\u3044\u3044\u3001\u305D\u306E\u4EBA\u304C\u3069\u3093\u306A\u53CD\u5FDC\u3092\u793A\u3059\u304B\u3067\u3001\u305D\u306E\u4EBA\u306E\u5668\u304C\uFF08\uFF52\uFF59",
  "id" : 202776929533837312,
  "created_at" : "2012-05-16 15:06:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202776501589000193",
  "geo" : { },
  "id_str" : "202776602122272770",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u53D7\u4ED8\uFF1F\uFF1F",
  "id" : 202776602122272770,
  "in_reply_to_status_id" : 202776501589000193,
  "created_at" : "2012-05-16 15:04:44 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202776055797391361",
  "geo" : { },
  "id_str" : "202776116166004736",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u65E9\u671D\u3063\u3066\u306E\u306F\u2026\uFF1F",
  "id" : 202776116166004736,
  "in_reply_to_status_id" : 202776055797391361,
  "created_at" : "2012-05-16 15:02:48 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202775953015963649",
  "text" : "\uFF10\u6642\u306B\u305B\u307B\u30FC\u3068\u304B\u8352\u308C\u308B\u306D",
  "id" : 202775953015963649,
  "created_at" : "2012-05-16 15:02:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202775880525819905",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 202775880525819905,
  "created_at" : "2012-05-16 15:01:51 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306F\u306D",
      "screen_name" : "leteometro",
      "indices" : [ 0, 11 ],
      "id_str" : "1445583608",
      "id" : 1445583608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202775814469726209",
  "text" : "@leteometro \u5FAE\u7A4D\u306F\u60AA\u3044\u3053\u3068\u8A00\u308F\u306A\u3044\u304B\u3089\u51FA\u3066\u304A\u3044\u305F\u65B9\u304C\u3044\u3044\u305C\u30FC",
  "id" : 202775814469726209,
  "created_at" : "2012-05-16 15:01:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202774920156033024",
  "geo" : { },
  "id_str" : "202774978414907392",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u3044\u3064\u3069\u3053\uFF1F",
  "id" : 202774978414907392,
  "in_reply_to_status_id" : 202774920156033024,
  "created_at" : "2012-05-16 14:58:16 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5408\u5BBF\u3084\u3063\u305F\u3053\u3068\u306A\u3044",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202774637371854849",
  "text" : "\u3068\u3044\u3046\u304B\u4F01\u753B\u3059\u308B\u306A\u3089\u307E\u305A\u81EA\u5206\u306E\u30B5\u30FC\u30AF\u30EB\u306E\u5408\u5BBF\u306A\u306E\u3067\u306F\uFF1F #\u5408\u5BBF\u3084\u3063\u305F\u3053\u3068\u306A\u3044",
  "id" : 202774637371854849,
  "created_at" : "2012-05-16 14:56:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202773967117885441",
  "geo" : { },
  "id_str" : "202774194788900865",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u305D\u3082\u305D\u3082\u30B7\u30E3\u30EF\u30FC\u3060\u3051\u3063\u3066\u306E\u304C\u30FB\u30FB\u30FB",
  "id" : 202774194788900865,
  "in_reply_to_status_id" : 202773967117885441,
  "created_at" : "2012-05-16 14:55:10 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202773941155135489",
  "text" : "\u304F\u3063\u3061\u3093\u3071\u90B8\u306E\u7384\u95A2\u3063\u3066\u3042\u3093\u306A\u306B\u304D\u308C\u3044\u3060\u3063\u305F\u304B\u3057\u3089\u3093",
  "id" : 202773941155135489,
  "created_at" : "2012-05-16 14:54:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202773562564677632",
  "geo" : { },
  "id_str" : "202773762792374275",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u5C71\u5143\u3055\u3093\u304C\u300C\u306E\u3046\u3053\u3055\u3093\u300D\u3063\u3066\u8A00\u8449\u3092\u300C\u3066\u304A\u304F\u308C\u300D\u3068\u5B9A\u7FA9\u3057\u3066\u3044\u305F\u3058\u3083\u3042\u308A\u307E\u305B\u3093\u304B\uFF08",
  "id" : 202773762792374275,
  "in_reply_to_status_id" : 202773562564677632,
  "created_at" : "2012-05-16 14:53:27 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "indices" : [ 22, 35 ],
      "id_str" : "78523759",
      "id" : 78523759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202773421812224000",
  "geo" : { },
  "id_str" : "202773583716564992",
  "in_reply_to_user_id" : 78523759,
  "text" : "\u5FC3\u306F\u9032\u5316\u3059\u308B\u3088\uFF28\uFF2F\uFF34\uFF34\uFF2F \uFF2D\uFF2F\uFF34\uFF34\uFF2F QT @tatamin_ttmn: \u5F01\u5F53\u5C4B\u30B5\u30FC\u30AD\u30E5\u30EC\u30FC\u30B7\u30E7\u30F3",
  "id" : 202773583716564992,
  "in_reply_to_status_id" : 202773421812224000,
  "created_at" : "2012-05-16 14:52:44 +0000",
  "in_reply_to_screen_name" : "tatamin_ttmn",
  "in_reply_to_user_id_str" : "78523759",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202773277502996481",
  "text" : "\u6DF7\u6D74\u306F\u897F\u6D0B\u5316\u3059\u308B\u524D\u306E\u65E5\u672C\u3067\u306F\u4E3B\u6D41\u3060\u3063\u305F\u3093\u3058\u3083\u306A\u304B\u3063\u305F\u3063\u3051",
  "id" : 202773277502996481,
  "created_at" : "2012-05-16 14:51:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202773041510490113",
  "text" : "\u306E\u3046\u3053\u3055\u3093\u3082\u3059\u3067\u306B\u306E\u3046\u3053\u3055\u3093\u3063\u3066\u8A00\u3048\u3070\u3088\u304B\u3063\u305F\u306E\u304B",
  "id" : 202773041510490113,
  "created_at" : "2012-05-16 14:50:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 14, 25 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202772979074072576",
  "text" : "\u306E\u3046\u3053\u3055\u3093\u3082\u3059\u3067\u306B\u2026 RT @hrizm_math: \u5E73\u6CC9\u300C\u6E29\u6CC9\u3067\u30BB\u30DF\u30CA\u30FC\u3084\u308B\u3068\u3057\u3066\u6DF7\u6D74\u3058\u3083\u306A\u304D\u3083\u3044\u304B\u3093\u304B\u3089\u6DF7\u6D74\u306E\u98A8\u5442\u5C4B\u63A2\u3055\u306D\u3048\u3068\u306A\u3042\u3046\u3048\u3048\u3078\u3078\u3078\u3078\u3078h\u300D \u306D\u3053\u300C\u306E\u3046\u3053\u3055\u3093\uFF01\uFF01\u5E73\u6CC9\u3055\u3093\u304C\uFF01\uFF01\uFF01\u9F3B\u8840\u51FA\u3057\u3066\u5012\u308C\u307E\u3057\u305F\uFF01\uFF01\uFF01\u300D",
  "id" : 202772979074072576,
  "created_at" : "2012-05-16 14:50:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202772671161827329",
  "text" : "\u7D50\u5C40\u5C11\u4EBA\u6570\u306B\u7DE8\u6210\u3057\u76F4\u3057\u3066\u5E7E\u4F55\u3001\u89E3\u6790\u3001\u4EE3\u6570\u3001\u57FA\u790E\u8AD6\u3067\u30B0\u30EB\u30FC\u30D7\u5206\u3051\u3066\u90E8\u5C4B\u5206\u3051\u305F\u308A\u3057\u306A\u3044\u3068\u52C9\u5F37\u5408\u5BBF\u3058\u3083\u306A\u304F\u3066\u767A\u8868\u5408\u5BBF\u306B\u306A\u3063\u3061\u3083\u3046\u3088\u306D",
  "id" : 202772671161827329,
  "created_at" : "2012-05-16 14:49:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202772205589897216",
  "geo" : { },
  "id_str" : "202772437962735616",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u30B5\u30A6\u30CA\u306B\u767D\u677F\u3092\u5165\u308C\u308B\u3068\u2026\uFF1F",
  "id" : 202772437962735616,
  "in_reply_to_status_id" : 202772205589897216,
  "created_at" : "2012-05-16 14:48:11 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202772062413131776",
  "geo" : { },
  "id_str" : "202772195351605248",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u884C\u52D5\u7BC4\u56F2\u5E83\u3044\u5E83\u3044 \uFF08\u3067\u3082\u3042\u308A\u3060\u306A\uFF09",
  "id" : 202772195351605248,
  "in_reply_to_status_id" : 202772062413131776,
  "created_at" : "2012-05-16 14:47:13 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202772049066868736",
  "text" : "\u7D50\u5C40\u3064\u3069\u3044\u306E\u6642\u3068\u304A\u3093\u306A\u3058\u611F\u3058\u306B\u306A\u308A\u305D\u3046\u306A\u30FB\u30FB\u30FB",
  "id" : 202772049066868736,
  "created_at" : "2012-05-16 14:46:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202771957404549120",
  "text" : "\u3066\u304B\u6E29\u6570\u5B66\u6CC9\u3084\u308B\u3068\u3057\u3066\u898F\u6A21\u3068\u304B\u4E88\u7B97\u3068\u304B\u3075\u308F\u3063\u3075\u308F\u3057\u3059\u304E\u3060\u3088\u306D",
  "id" : 202771957404549120,
  "created_at" : "2012-05-16 14:46:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202771293853073411",
  "geo" : { },
  "id_str" : "202771403500564483",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u4E5D\u5DDE\u9650\u5B9A\u3059\u304B\uFF57\uFF57\uFF57",
  "id" : 202771403500564483,
  "in_reply_to_status_id" : 202771293853073411,
  "created_at" : "2012-05-16 14:44:04 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202771086742523905",
  "text" : "\u4E38\u6295\u3052\u3068\u304B\u8A00\u3044\u306A\u304C\u3089\u52C9\u5F37 \u5408\u5BBF\u3068\u304B\u3067\uFF47\uFF47\u3063\u3066\u308B\u81EA\u5206\u304C\u3044\u308B",
  "id" : 202771086742523905,
  "created_at" : "2012-05-16 14:42:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202770681304334338",
  "geo" : { },
  "id_str" : "202770794806394882",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u671D\u82E6\u624B\u306A\u306E\u306B\u65E9\u8D77\u304D\u3057\u3066\u7121\u7406\u77E2\u7406\u5165\u308A\u306B\u884C\u3063\u305F\u308A\u3068\u304B\u306F\u3057\u307E\u3059\u306D\uFF57",
  "id" : 202770794806394882,
  "in_reply_to_status_id" : 202770681304334338,
  "created_at" : "2012-05-16 14:41:39 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202770154269061122",
  "geo" : { },
  "id_str" : "202770261861347329",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u3042\u30FC\u5927\u304D\u306A\u6E6F\u8239\u306F\u5ACC\u3063\u3066\u4EBA\u306F\u7D50\u69CB\u3044\u308B\u304B\u3082\u3067\u3059\u306D\u3002",
  "id" : 202770261861347329,
  "in_reply_to_status_id" : 202770154269061122,
  "created_at" : "2012-05-16 14:39:32 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202769901146996737",
  "text" : "@kotorin_z \u5727\u5012\u7684\u4E38\u6295\u3052\u2026",
  "id" : 202769901146996737,
  "created_at" : "2012-05-16 14:38:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202769745995505665",
  "text" : "\u9EBB\u96C0\u3063\u3066\u610F\u5473\u3058\u3083\u306A\u304F\u3066\u306D\uFF57",
  "id" : 202769745995505665,
  "created_at" : "2012-05-16 14:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202769709702184962",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u5408\u5BBF\u6240\u307F\u305F\u3044\u306A\u306E\u7121\u3044\u306E\u304B\u306A\u3002\u30A4\u30E1\u30FC\u30B8\u306F\u54B2saki\u306E\u5408\u5BBF\u6240\uFF01",
  "id" : 202769709702184962,
  "created_at" : "2012-05-16 14:37:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202769419062091776",
  "geo" : { },
  "id_str" : "202769565946609664",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u6E29\u6CC9\u5ACC\u3044\u306A\u4EBA\u3063\u3066\u3042\u3093\u307E\u308A\u3044\u306A\u3044\u306E\u3067\u306F\u30FC\uFF1F",
  "id" : 202769565946609664,
  "in_reply_to_status_id" : 202769419062091776,
  "created_at" : "2012-05-16 14:36:46 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202769183660965890",
  "text" : "\u5E73\u6CC9\u306E\u6CC9\u306F\u6E29\u6CC9\u306E\u6CC9",
  "id" : 202769183660965890,
  "created_at" : "2012-05-16 14:35:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202769020917780480",
  "text" : "\u6E29\u6570\u5B66\u6CC9\uFF01\u308A\u3083\u304F\u3057\u3066\u5E73\u6CC9\u3060\uFF01",
  "id" : 202769020917780480,
  "created_at" : "2012-05-16 14:34:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202766230434754560",
  "text" : "\u30A4\u30B1\u30DC\u3063\u3066\u8A00\u3046\u3082\u3093\u306D",
  "id" : 202766230434754560,
  "created_at" : "2012-05-16 14:23:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202766148968779776",
  "text" : "\u6C60\u306B\u5C45\u305F\u3089\u6C60\u574A\u4E3B\u304B\u306A",
  "id" : 202766148968779776,
  "created_at" : "2012-05-16 14:23:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3082\u3057\u304B\u3057\u3066\u6CB3\u7AE5",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202766076633808896",
  "text" : "\u6D77\u574A\u4E3B\u304C\u5DDD\u306B\u5C45\u305F\u3089\u305D\u308C\u3082\u3046\u5DDD\u574A\u4E3B\u3060\u3088\u306D #\u3082\u3057\u304B\u3057\u3066\u6CB3\u7AE5",
  "id" : 202766076633808896,
  "created_at" : "2012-05-16 14:22:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202765944068648960",
  "text" : "\u6CB3\u7AE5\u304C\u6728\u306E\u4E0A\u306B\u5C45\u305F\u3089\u3082\u3046\u305D\u308C\u6CB3\u7AE5\u3058\u3083\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u306A",
  "id" : 202765944068648960,
  "created_at" : "2012-05-16 14:22:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202765750635741185",
  "text" : "\u6CB3\u7AE5\u3082\u6728\u304B\u3089\u843D\u3061\u308B\uFF1F",
  "id" : 202765750635741185,
  "created_at" : "2012-05-16 14:21:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202765596436340736",
  "text" : "\u5F18\u6CD5\u306E\u5DDD\u6D41\u308C\n\u610F\uFF1A\u6C34\u96E3\u4E8B\u6545",
  "id" : 202765596436340736,
  "created_at" : "2012-05-16 14:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202765194227744768",
  "text" : "\u99AC\u306E\u8033\u306B\u307C\u305F\u3082\u3061",
  "id" : 202765194227744768,
  "created_at" : "2012-05-16 14:19:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202764737287684097",
  "text" : "\u308F\u3041\u3044\u610F\u5473\u3042\u308A\u3052\u306A\u610F\u5473\u306E\u306A\u3044\u30DD\u30B9\u30C8\u3001\u3048\u3093\u3069\u610F\u5473\u3042\u308A\u3052\u306A\u610F\u5473\u306E\u306A\u3044\u30DD\u30B9\u30C8\u3060\u3044\u3059\u304D",
  "id" : 202764737287684097,
  "created_at" : "2012-05-16 14:17:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202764578143207425",
  "text" : "\u7279\u306B\u610F\u5473\u306F\u3042\u308A\u307E\u305B\u3093",
  "id" : 202764578143207425,
  "created_at" : "2012-05-16 14:16:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202764556920045570",
  "text" : "\u3042\u3048\u3066\u7A7A\u6C17\u3092\u8AAD\u307E\u306A\u3044\u80FD\u529B",
  "id" : 202764556920045570,
  "created_at" : "2012-05-16 14:16:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202763755585675265",
  "text" : "\u3042\u30FC\u3042\u30FC",
  "id" : 202763755585675265,
  "created_at" : "2012-05-16 14:13:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202755073401561088",
  "text" : "\u6700\u8FD1\u54F2\u5B66\u95A2\u9023\u3067\u30AB\u30C6\u30B4\u30EA\u30FC\u3063\u3066\u6587\u5B57\u5217\u3092\u898B\u305F\u308A\u805E\u3044\u305F\u308A\u3059\u308B\u305F\u3073\u306B\uFF8B\uFF9E\uFF78\uFF6F\u3063\u3066\u306A\u308B\u304B\u3089\u3082\u3046\u3042\u308C",
  "id" : 202755073401561088,
  "created_at" : "2012-05-16 13:39:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202754145361461249",
  "text" : "\u5C40\u6240\u7684\u81EA\u708A\u30AC\u30C1\u52E2",
  "id" : 202754145361461249,
  "created_at" : "2012-05-16 13:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202705077977362432",
  "geo" : { },
  "id_str" : "202706785142976512",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u308C\u306F\u7F8E\u5473\u3057\u3044\u306E\u304B",
  "id" : 202706785142976512,
  "in_reply_to_status_id" : 202705077977362432,
  "created_at" : "2012-05-16 10:27:18 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202673135827431427",
  "text" : "#11572",
  "id" : 202673135827431427,
  "created_at" : "2012-05-16 08:13:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202666958838177792",
  "text" : "S2S\u306E\u30EA\u30B9\u30C8\u306B\u3044\u305F\u4EBA\u7247\u3063\u7AEF\u304B\u3089\u30D5\u30A9\u30ED\u30FC\u3057\u305F\uFF08\u3063\u3066\u8A00\u3063\u3066\u3082\uFF17\u5272\u8FD1\u304F\u65E2\u306B\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u305F\u3093\u3060\u3051\u308C\u3069\uFF09",
  "id" : 202666958838177792,
  "created_at" : "2012-05-16 07:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202664297413881856",
  "text" : "\u3068\u8A00\u3046\u308F\u3051\u3067\u4E00\u6642\u304D\u3063\u305F\u304F",
  "id" : 202664297413881856,
  "created_at" : "2012-05-16 07:38:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202656134790778880",
  "text" : "23\u306F\u7D20\u6570",
  "id" : 202656134790778880,
  "created_at" : "2012-05-16 07:06:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202655686654562304",
  "text" : "\u30C7\u30AB\u30F3\u30B7\u30E7\u7BC0\u3068\u30B7\u30E5\u30EC\u30C7\u30A3\u30F3\u30AC\u30FC\u97F3\u982D\u3068\u7D20\u6570\u8E0A\u308A\u3068\u7A7A\u624B\u8E0A\u308A\u306E\u985E\u4F3C\u6027",
  "id" : 202655686654562304,
  "created_at" : "2012-05-16 07:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202655452729835520",
  "text" : "\u3072\u3055\u3073\u3055\u306B\u306B\u305B\u3072\u30FC\u3057\u305F\u6C17\u304C\u3059\u308B",
  "id" : 202655452729835520,
  "created_at" : "2012-05-16 07:03:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202655265303175169",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 202655265303175169,
  "created_at" : "2012-05-16 07:02:35 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202655189042331649",
  "text" : "\u6700\u8FD1\u3042\u307E\u308A\u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u304D\u3066\u306A\u304F\u3066\u30A2\u30EC",
  "id" : 202655189042331649,
  "created_at" : "2012-05-16 07:02:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202645930728620032",
  "text" : "\u30AB\u30C6\u30B4\u30EA\u30FC\u30DF\u30B9\u30C6\u30A4\u30AF...",
  "id" : 202645930728620032,
  "created_at" : "2012-05-16 06:25:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202568161608998912",
  "text" : "\u307E\u305F\u9593\u306B\u5408\u3046\u304B\u5FAE\u5999\u3060\u306A\u3041",
  "id" : 202568161608998912,
  "created_at" : "2012-05-16 01:16:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202417908708683776",
  "text" : "\u3046\u308F\u30FC\u697D\u3057\u305D\u3046\u306A\u306E\u306B\u660E\u65E5\u306F\u4F8B\u4F1A\u3044\u3051\u306A\u3044\u3063\u3066\u3044\u3046\u306D",
  "id" : 202417908708683776,
  "created_at" : "2012-05-15 15:19:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202407274919116802",
  "text" : "\u96A3\u306E\u90E8\u5C4B\u304C\u3046\u308B\u3055\u3044\u2026",
  "id" : 202407274919116802,
  "created_at" : "2012-05-15 14:37:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202406885947736064",
  "text" : "\u30AD\u30FC\u30DC\u30FC\u30C9\u5F0F\u6253\u3061\u8FBC\u307F\u3068\u30BF\u30C3\u30D7\u3068\u3069\u3063\u3061\u304C\u65E9\u3044\u304B\u306A",
  "id" : 202406885947736064,
  "created_at" : "2012-05-15 14:35:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202404253262819328",
  "text" : "\u30B9\u30AD\u30E3\u30F3\u3059\u308B\u306B\u306F\u3061\u3087\u3046\u3069\u3044\u3044\u304C",
  "id" : 202404253262819328,
  "created_at" : "2012-05-15 14:25:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202404231628599296",
  "text" : "\u658E\u85E4\u306E\u7DDA\u578B\u501F\u308A\u3066\u304D\u305F\u304C\u3053\u308C\u672C\u3068\u3057\u3066\u5B58\u5728\u3057\u3066\u3044\u308B\u30AE\u30EA\u30AE\u30EA\u3063\u3066\u611F\u3058\u306E\u307C\u308D\u3055\u3060\u306A",
  "id" : 202404231628599296,
  "created_at" : "2012-05-15 14:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202400744542973953",
  "text" : "fb\u59CB\u3081\u308B\u308F\u3093\u3061\u3083\u3093\uFF1F",
  "id" : 202400744542973953,
  "created_at" : "2012-05-15 14:11:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202367853331099650",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 202367853331099650,
  "created_at" : "2012-05-15 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202303433800286208",
  "geo" : { },
  "id_str" : "202305756211585024",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u516C\u5F0F\u4F11\u8B1B\u3060\u305C\u3044",
  "id" : 202305756211585024,
  "in_reply_to_status_id" : 202303433800286208,
  "created_at" : "2012-05-15 07:53:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k@ori.k...",
      "screen_name" : "chinchikurin48",
      "indices" : [ 0, 15 ],
      "id_str" : "3018640687",
      "id" : 3018640687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202300652506984448",
  "geo" : { },
  "id_str" : "202303229621579776",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurin48 \u6765\u308C\u308B\u6642\u306F\u305C\u3072\u305C\u3072\uFF01",
  "id" : 202303229621579776,
  "in_reply_to_status_id" : 202300652506984448,
  "created_at" : "2012-05-15 07:43:43 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202300440845623297",
  "text" : "\u305D\u308D\u305D\u308D\u8AB0\u304B\u304F\u308B\uFF1F(\u30C1\u30E9\u30C3",
  "id" : 202300440845623297,
  "created_at" : "2012-05-15 07:32:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202296857387466753",
  "geo" : { },
  "id_str" : "202300262998749185",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306F\u3044",
  "id" : 202300262998749185,
  "in_reply_to_status_id" : 202296857387466753,
  "created_at" : "2012-05-15 07:31:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/gujpsrFo",
      "expanded_url" : "http:\/\/4sq.com\/Jzl8oN",
      "display_url" : "4sq.com\/Jzl8oN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "202296720476995584",
  "text" : "4\u9650\u4F11\u8B1B\uFF01(^^)(^^)(^^) (@ \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ) http:\/\/t.co\/gujpsrFo",
  "id" : 202296720476995584,
  "created_at" : "2012-05-15 07:17:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202248843956465664",
  "text" : "\u3042\u3057\u304C\u306C\u308C\u3066\u3066\u304D\u3082\u3061\u308F\u308B\u3044",
  "id" : 202248843956465664,
  "created_at" : "2012-05-15 04:07:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3048\u308B",
      "screen_name" : "redreder",
      "indices" : [ 0, 9 ],
      "id_str" : "975441516",
      "id" : 975441516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202248050691936257",
  "geo" : { },
  "id_str" : "202248432352628737",
  "in_reply_to_user_id" : 238511036,
  "text" : "@redreder \u30CA\u30A4\u30B9\u30DE\u30C3\u30C9\uFF01",
  "id" : 202248432352628737,
  "in_reply_to_status_id" : 202248050691936257,
  "created_at" : "2012-05-15 04:05:58 +0000",
  "in_reply_to_screen_name" : "dctrmnd",
  "in_reply_to_user_id_str" : "238511036",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 93, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/dtMdgJkL",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti&c=end313124",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202209427024130049",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001omo_ti\u3055\u3093\u304C\u6570\u5B66\u3057\u305F\u3044\u305D\u3046\u3067\u3059\u3002omo_ti\u3055\u3093\u3084\u79C1\u3068\u6570\u5B66\u3057\u305F\u3051\u308C\u3070\u767B\u9332\u3057\u3066\u30DE\u30C3\u30C1\u3059\u308B\u3068DM\u304C\u5C4A\u304D\u307E\u3059 http:\/\/t.co\/dtMdgJkL #gohantabeyo",
  "id" : 202209427024130049,
  "created_at" : "2012-05-15 01:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202069045607006208",
  "text" : "\u30A8\u30D0\u30FC\u30CE\u30FC\u30C8\u4ECA\u4E00\u3064\u4F7F\u3044\u65B9\u304C\u306F\u3063\u304D\u308A\u308F\u304B\u3089\u306C",
  "id" : 202069045607006208,
  "created_at" : "2012-05-14 16:13:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3061\u3047\u308A\u30FC",
      "screen_name" : "che_rrrry",
      "indices" : [ 2, 12 ],
      "id_str" : "2859162751",
      "id" : 2859162751
    }, {
      "name" : "\u304B\u3048\u308B",
      "screen_name" : "redreder",
      "indices" : [ 13, 22 ],
      "id_str" : "975441516",
      "id" : 975441516
    }, {
      "name" : "Fumi O'Orient",
      "screen_name" : "fumieval",
      "indices" : [ 33, 42 ],
      "id_str" : "75975397",
      "id" : 75975397
    }, {
      "name" : "\u304C\u3043",
      "screen_name" : "GAi9112",
      "indices" : [ 43, 51 ],
      "id_str" : "169436782",
      "id" : 169436782
    }, {
      "name" : "\u3079\u306B\u3070\u306A\uFF201\u56DE\u751F",
      "screen_name" : "CcreticusL",
      "indices" : [ 52, 63 ],
      "id_str" : "407066804",
      "id" : 407066804
    }, {
      "name" : "\u304B\u307F\u3085",
      "screen_name" : "kamyuri96",
      "indices" : [ 64, 74 ],
      "id_str" : "311187890",
      "id" : 311187890
    }, {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 75, 83 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 84, 94 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202068943035314176",
  "text" : ". @che_rrrry @redreder @ispamgis @fumieval @GAi9112 @CcreticusL @kamyuri96 @i_horse @Lisa_math \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01\uFF08\u9045\uFF09",
  "id" : 202068943035314176,
  "created_at" : "2012-05-14 16:12:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202067029363138560",
  "geo" : { },
  "id_str" : "202068436816363520",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u3069\u3093\u306A\u98A8\u306B\u4F7F\u3063\u3066\u307E\u3059\uFF1F",
  "id" : 202068436816363520,
  "in_reply_to_status_id" : 202067029363138560,
  "created_at" : "2012-05-14 16:10:44 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202068109501272065",
  "text" : "\u5727\u5012\u7684\u4E45\u3057\u3076\u308A\u306B\u5E30\u5B85",
  "id" : 202068109501272065,
  "created_at" : "2012-05-14 16:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201994537483251714",
  "text" : "@Italiasan \u3055\u304B\u306A\u304C\u300C\u300C\u4ECA\u65E5\u306E\u6DF1\u591C\u304B\u660E\u65E5\u306E\u591C\u306B\u30B9\u30AB\u30A4\u30D7\u306B\u5165\u3063\u3066\u304F\u308C\u3068\u304B\u304A\u308A\u3093\u3055\u3093\u306B\u3064\u305F\u3048\u3066\u304F\u308C\u300D\u3068\u30A4\u30BF\u30EA\u30A2\u3055\u3093\u306B\u4F1D\u3048\u3066\u304F\u308C\u300D\u3068\u50D5\u306B\u4F1D\u3048\u3066\u304D\u307E\u3057\u305F\u3002",
  "id" : 201994537483251714,
  "created_at" : "2012-05-14 11:17:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201960461334364160",
  "text" : "@i_horse \u30B5\u30C3\u30AB\u30FCwwwwww",
  "id" : 201960461334364160,
  "created_at" : "2012-05-14 09:01:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201958317042573312",
  "text" : "\u30C7\u30A3\u30EA\u30AF\u30EC \u30EF\u30A4\u30EB\u30B7\u30E5\u30C8\u30E9\u30A6\u30B9 \u30AF\u30ED\u30CD\u30C3\u30AB\u30FC \u30EA\u30FC\u30DE\u30F3 \u30AC\u30A6\u30B9 \u30C7\u30C7\u30AD\u30F3\u30C8 \u30AF\u30E9\u30A4\u30F3 \u30D2\u30EB\u30D9\u30EB\u30C8 \u3059\u3054\u3044\u30E1\u30F3\u30D0\u30FC...",
  "id" : 201958317042573312,
  "created_at" : "2012-05-14 08:53:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DEAD END",
      "screen_name" : "7ksts",
      "indices" : [ 0, 6 ],
      "id_str" : "96237218",
      "id" : 96237218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201928520522399745",
  "geo" : { },
  "id_str" : "201928625283530752",
  "in_reply_to_user_id" : 96237218,
  "text" : "@7ksts \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 201928625283530752,
  "in_reply_to_status_id" : 201928520522399745,
  "created_at" : "2012-05-14 06:55:10 +0000",
  "in_reply_to_screen_name" : "7ksts",
  "in_reply_to_user_id_str" : "96237218",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201921932944351232",
  "text" : "16\u6642\u3067\u96E2\u8131\u3057\u3066\u56F3\u66F8\u9928\u884C\u304F\u304B",
  "id" : 201921932944351232,
  "created_at" : "2012-05-14 06:28:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201920811609759744",
  "geo" : { },
  "id_str" : "201920973606354944",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u5927\u4E08\u592B\u3067\u3059\u304B",
  "id" : 201920973606354944,
  "in_reply_to_status_id" : 201920811609759744,
  "created_at" : "2012-05-14 06:24:46 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201918720820527104",
  "text" : "\u30AB\u30C6\u30B4\u30EA\u30FC\u8AD6\u3063\u3066\u3082\u306E\u306E\u5206\u985E\u306E\u306F\u306A\u3057\u306A\u306E\u304B\u570F\u8AD6\u306A\u306E\u304B...",
  "id" : 201918720820527104,
  "created_at" : "2012-05-14 06:15:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201861239482224642",
  "geo" : { },
  "id_str" : "201915950595969024",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3054\u3081\u3093\u306A\u3055\u3044\u3002\u53C2\u52A0\u3057\u307E\u3059\u3002\u307E\u3060\u6559\u79D1\u66F8\u898B\u308C\u3066\u306A\u3044\u611F\u3058\u3067\u3059\u304C...\u65E5\u4ED8\u306F\u3044\u3064\u3067\u3057\u305F\u3063\u3051\u3002",
  "id" : 201915950595969024,
  "in_reply_to_status_id" : 201861239482224642,
  "created_at" : "2012-05-14 06:04:48 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201844499381620737",
  "text" : "\u3068\u306F\u3044\u3048\u65E2\u306B\u6559\u5BA4\u306B\u3044\u308B",
  "id" : 201844499381620737,
  "created_at" : "2012-05-14 01:20:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201844179842772992",
  "text" : "\u5727\u5012\u7684\u7720\u6C17",
  "id" : 201844179842772992,
  "created_at" : "2012-05-14 01:19:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201844057058713600",
  "text" : "\u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\u30CF\u30AD\u30BF\u30AF\u30B7\u30C6\u30AB\u30E9",
  "id" : 201844057058713600,
  "created_at" : "2012-05-14 01:19:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201643055403630592",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 201643055403630592,
  "created_at" : "2012-05-13 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201520796420685825",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 201520796420685825,
  "created_at" : "2012-05-13 03:54:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/JIDm7nK3",
      "expanded_url" : "http:\/\/4sq.com\/IXyeOB",
      "display_url" : "4sq.com\/IXyeOB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "201504734614532096",
  "text" : "\u958B\u3051\u305F (@ \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ) http:\/\/t.co\/JIDm7nK3",
  "id" : 201504734614532096,
  "created_at" : "2012-05-13 02:50:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201493582618693636",
  "geo" : { },
  "id_str" : "201494021888147456",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \uFF11\uFF12\u6642\u304B\u3089\u7528\u6642\u306A\u306E\u3067\uFF14\u6642\u9593\u3082\u5BDD\u308C\u306A\u3044\u3067\u3059\u3045\uFF08^^\uFF09\uFF08^^\uFF09\uFF08^^\uFF09\uFF08^^\uFF09\uFF08^^\uFF09",
  "id" : 201494021888147456,
  "in_reply_to_status_id" : 201493582618693636,
  "created_at" : "2012-05-13 02:08:13 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201493141860253697",
  "text" : "\u3053\u308A\u3083\u3042\u308B\u7A2E\uFF33\uFF12\uFF33\u306E\u4E8C\u6B21\u4F1A\u884C\u304B\u306A\u304F\u3066\u6B63\u89E3\u3060\u3063\u305F\u306A\u30FC\u3001\u884C\u304D\u305F\u304B\u3063\u305F\u3051\u3069",
  "id" : 201493141860253697,
  "created_at" : "2012-05-13 02:04:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201492980727685120",
  "geo" : { },
  "id_str" : "201493060977307648",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u304A\u304B\u3048\u308A\u306A\u3055\u3044\u304A\u3064\u304B\u308C\u3055\u307E\u3067\u3059",
  "id" : 201493060977307648,
  "in_reply_to_status_id" : 201492980727685120,
  "created_at" : "2012-05-13 02:04:23 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201492901056876544",
  "text" : "\u30B2\u30F3\u30B3\u30C4\u306F\u75DB\u3044\u306E\u306F\u4EEE\u8AAC\u306B\u3059\u304E\u306A\u3044\u306E\u304B\uFF57\uFF57\uFF57\u7D4C\u9A13\u7684\u306B\u306F\u771F\u3060\u3051\u3069\uFF57\uFF57\uFF57",
  "id" : 201492901056876544,
  "created_at" : "2012-05-13 02:03:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201492660538703873",
  "text" : "\u58F0\u512A\u3055\u3093\u7684\u306A\u610F\u5473\u5408\u3044\u3060\u3063\u305F\u306E\u304B\u3001\u306F\u305F\u307E\u305F\u30FB\u30FB\u30FB",
  "id" : 201492660538703873,
  "created_at" : "2012-05-13 02:02:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201492525951881216",
  "text" : "\u306A\u3093\u304B\u898B\u306B\u884C\u3063\u305F\u3089\u96A3\u306E\u4EBA\u306B\u300C\u79C1\u25CB\u25CB\u306E\u306A\u304B\u306E\u3072\u3068\u306A\u3093\u3067\u3059\u3088\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u5922\u3092\u898B\u305F\u3051\u3069\u306A\u3093\u3060\u3063\u305F\u3093\u3060\u308D",
  "id" : 201492525951881216,
  "created_at" : "2012-05-13 02:02:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306F\u306D",
      "screen_name" : "leteometro",
      "indices" : [ 0, 11 ],
      "id_str" : "1445583608",
      "id" : 1445583608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201491746461450240",
  "text" : "@leteometro \u5727\u5012\u7684\u304A\u5927\u4E8B\u306B\u2015",
  "id" : 201491746461450240,
  "created_at" : "2012-05-13 01:59:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201490168019034113",
  "text" : "\u76EE\u899A\u307E\u3057\u306A\u3057\u4E8C\u5EA6\u5BDD\u3057\u3066\u3053\u306E\u6642\u9593\u306A\u3089\u4E0A\u51FA\u6765\u3060\u305C",
  "id" : 201490168019034113,
  "created_at" : "2012-05-13 01:52:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201489585866420225",
  "text" : "\u304A\u306F\u3088\u3054\u3056\u307E\u3059",
  "id" : 201489585866420225,
  "created_at" : "2012-05-13 01:50:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201318931623968768",
  "geo" : { },
  "id_str" : "201320471323619328",
  "in_reply_to_user_id" : 91551881,
  "text" : "@t_uda \u3067\u3001\u3067\u3059\u3088\u306D\u30FC\uFF08",
  "id" : 201320471323619328,
  "in_reply_to_status_id" : 201318931623968768,
  "created_at" : "2012-05-12 14:38:35 +0000",
  "in_reply_to_screen_name" : "t_uda",
  "in_reply_to_user_id_str" : "91551881",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u306E\u4FE1\u5F92\u307E\u3093\u304C\u3093\uFF01",
      "screen_name" : "25manganum",
      "indices" : [ 0, 11 ],
      "id_str" : "400280435",
      "id" : 400280435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201315930893074432",
  "geo" : { },
  "id_str" : "201316172220731393",
  "in_reply_to_user_id" : 400280435,
  "text" : "@25manganum \u3064\u6C34\uFF13\uFF15\uFF2C\u70AD\u7D20\uFF12\uFF10\uFF4B\uFF47\u30A2\u30F3\u30E2\u30CB\u30A2\uFF14\uFF2C\u77F3\u7070\uFF11.\uFF15\uFF4B\uFF47\u30EA\u30F3\uFF18\uFF10\uFF10\uFF47\u5869\u5206\uFF12\uFF15\uFF10\uFF47\u785D\u77F3\uFF11\uFF10\uFF10\uFF47\u786B\u9EC4\uFF18\uFF10\uFF47\u30D5\u30C3\u7D20\uFF17.\uFF15\uFF47\u9244\uFF15\uFF47\u30B1\u30A4\u7D20\uFF13\uFF47\u305D\u306E\u4ED6\u5C11\u91CF\u306E\uFF11\uFF15\u306E\u5143\u7D20",
  "id" : 201316172220731393,
  "in_reply_to_status_id" : 201315930893074432,
  "created_at" : "2012-05-12 14:21:30 +0000",
  "in_reply_to_screen_name" : "25manganum",
  "in_reply_to_user_id_str" : "400280435",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201315653217566720",
  "text" : "\u306B\u305B\u307B\u306B\u899A\u3048\u3055\u305B\u305F\u3044\u306A\u3053\u308C\n\u5F7C\u5973\u6B32\u3057\u3044\u2192\u3064\u6C34\uFF13\uFF15\uFF2C\u70AD\u7D20\uFF12\uFF10\uFF4B\uFF47\u30A2\u30F3\u30E2\u30CB\u30A2\uFF14\uFF2C\u77F3\u7070\uFF11.\uFF15\uFF4B\uFF47\u30EA\u30F3\uFF18\uFF10\uFF10\uFF47\u5869\u5206\uFF12\uFF15\uFF10\uFF47\u785D\u77F3\uFF11\uFF10\uFF10\uFF47\u786B\u9EC4\uFF18\uFF10\uFF47\u30D5\u30C3\u7D20\uFF17.\uFF15\uFF47\u9244\uFF15\uFF47\u30B1\u30A4\u7D20\uFF13\uFF47\u305D\u306E\u4ED6\u5C11\u91CF\u306E\uFF11\uFF15\u306E\u5143\u7D20",
  "id" : 201315653217566720,
  "created_at" : "2012-05-12 14:19:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201315020963979264",
  "text" : "\u5869\u5206\u304C\u5186\u5206\u306B\u306A\u3063\u3066\u308B\u30FB\u30FB\u30FB",
  "id" : 201315020963979264,
  "created_at" : "2012-05-12 14:16:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5343\u53CD\u7530\u3048\u308B\u3068\u7D50\u5A5A\u3057\u305F\u3044",
      "screen_name" : "Xe_no",
      "indices" : [ 0, 6 ],
      "id_str" : "146107191",
      "id" : 146107191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201314068521418754",
  "geo" : { },
  "id_str" : "201314887207624704",
  "in_reply_to_user_id" : 146107191,
  "text" : "@Xe_no \u3064\u6C34\uFF13\uFF15\uFF2C\u70AD\u7D20\uFF12\uFF10\uFF4B\uFF47\u30A2\u30F3\u30E2\u30CB\u30A2\uFF14\uFF2C\u77F3\u7070\uFF11.\uFF15\uFF4B\uFF47\u30EA\u30F3\uFF18\uFF10\uFF10\uFF47\u5186\u5206\uFF12\uFF15\uFF10\uFF47\u785D\u77F3\uFF11\uFF10\uFF10\uFF47\u786B\u9EC4\uFF18\uFF10\uFF47\u30D5\u30C3\u7D20\uFF17.\uFF15\uFF47\u9244\uFF15\uFF47\u30B1\u30A4\u7D20\uFF13\uFF47\u305D\u306E\u4ED6\u5C11\u91CF\u306E\uFF11\uFF15\u306E\u5143\u7D20",
  "id" : 201314887207624704,
  "in_reply_to_status_id" : 201314068521418754,
  "created_at" : "2012-05-12 14:16:24 +0000",
  "in_reply_to_screen_name" : "Xe_no",
  "in_reply_to_user_id_str" : "146107191",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201313493486551040",
  "text" : "@kotorin_z \u79C1\u306B\u8DB3\u308A\u306A\u3044\u7269\u3001\u305D\u308C\u306F\uFF01\u77E5\u8B58\u3001\u6559\u990A\u3001\u6642\u9593\u3001\u81E8\u6A5F\u5FDC\u5909\u3055\u3001\u8CE2\u3055\uFF01\u305D\u3057\u3066\u4F55\u3088\u308A\u3082\u30FC\uFF01\u30EC\u30D1\u30FC\u30C8\u30EA\u30FC\u304C\u8DB3\u308A\u306A\u3044\uFF01\uFF01",
  "id" : 201313493486551040,
  "created_at" : "2012-05-12 14:10:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201312285745094656",
  "geo" : { },
  "id_str" : "201312426061336576",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u7DE8\u96C6\u3068\u8A00\u3046\u304B\u66F8\u304D\u8FBC\u307F\u3068\u8A00\u3046\u304B\u30E1\u30E2\u66F8\u304D\u3068\u8A00\u3046\u304B\u2026\u3044\u3084iPad\u3060\u3051\u3067\u52C9\u5F37\u51FA\u6765\u305F\u3089\u697D\u3060\u306A\u30FC\u3068",
  "id" : 201312426061336576,
  "in_reply_to_status_id" : 201312285745094656,
  "created_at" : "2012-05-12 14:06:37 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201312291898134529",
  "text" : "@kotorin_z \u305D\u3057\u3066\u540A\u308A\u4E0A\u308B\u4EA4\u901A\u8CBB\u2026",
  "id" : 201312291898134529,
  "created_at" : "2012-05-12 14:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201312030018379776",
  "geo" : { },
  "id_str" : "201312171429330945",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u7DE8\u96C6\u51FA\u6765\u308B\u306E\u3063\u3066\u305D\u3093\u306A\u306B\u591A\u304F\u306A\u3044\u3067\u3059\u3088\u306D\u3047",
  "id" : 201312171429330945,
  "in_reply_to_status_id" : 201312030018379776,
  "created_at" : "2012-05-12 14:05:36 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201311687469568000",
  "text" : "\u6709\u6599\u3067\u3082\u5168\u7136\u3044\u3044\u3093\u3060\u3051\u308C\u3069",
  "id" : 201311687469568000,
  "created_at" : "2012-05-12 14:03:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201311649699868672",
  "text" : "iPad\u3067\uFF50\uFF44\uFF46\u898B\u308B\u306E\u306B\u304A\u52E7\u3081\u306E\u30C4\u30FC\u30EB\u306F\u4F55\u3067\u3059\u304B\u306D\u3002\u7DE8\u96C6\u3068\u304B\u66F8\u304D\u8FBC\u307F\u307E\u3067\u3067\u304D\u305F\u3089\u5727\u5012\u7684\u306A\u3093\u3060\u304C\u3002",
  "id" : 201311649699868672,
  "created_at" : "2012-05-12 14:03:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201311388193398786",
  "text" : "\u7435\u7436\u6E56\u30BC\u30EA\u30FC\u3068\u304B\u6C34\u69FD\u30BC\u30EA\u30FC\u306E\u6BD4\u3058\u3083\u306A\u3044",
  "id" : 201311388193398786,
  "created_at" : "2012-05-12 14:02:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201311226859491328",
  "geo" : { },
  "id_str" : "201311306287030273",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u7435\u7436\u6E56\u3067\u30BC\u30EA\u30FC\u3092\u4F5C\u308B\uFF1F",
  "id" : 201311306287030273,
  "in_reply_to_status_id" : 201311226859491328,
  "created_at" : "2012-05-12 14:02:10 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201311158626566144",
  "text" : "\u8A71\u984C\u306B\u3064\u3044\u3066\u3044\u3051\u308B\u307B\u3069\u306E\u8A73\u3057\u3055\u306F\u306A\u3044\u306E\u3067\u7533\u3057\u8A33\u306A\u304B\u3063\u305F\u305C",
  "id" : 201311158626566144,
  "created_at" : "2012-05-12 14:01:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201311088162254850",
  "text" : "\u89E3\u304F\u306E\u304C\u9045\u3044\u751F\u5F92\u306B\u3046\u3063\u304B\u308A\u300C\u306A\u306B\u3088\u308A\u901F\u3055\u304C\u8DB3\u308A\u306A\u3044\u300D\u3063\u3066\u8A00\u3063\u305F\u3089\u300C\u3048\u3001\u30B9\u30AF\u30E9\u30A4\u30C9\u89E3\u308B\u3093\u3067\u3059\u304B\u5148\u751F\u300D\u3063\u3066\u8FD4\u3063\u3066\u304D\u3066\u5727\u5012\u7684\u3060\u3063\u305F",
  "id" : 201311088162254850,
  "created_at" : "2012-05-12 14:01:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201310510732427265",
  "text" : "\u3042\u30FC\u30A4\u30BF\u30EA\u30A2\u3055\u3093\u306E\u713C\u8089\u3082\u4ECA\u65E5\u3060\u3063\u305F\u306E\u304B\u305D\u3063\u3061\u3082\u3048\u3093\u3073\u3043\u30FC",
  "id" : 201310510732427265,
  "created_at" : "2012-05-12 13:59:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201310421188222977",
  "text" : "\u3067\u3082\u3067\u3082\u5FB9\u591C\u3067\u30B5\u30FC\u30AF\u30EB\u306E\u5927\u4F1A\u3068\u304B\u3044\u305F\u305F\u307E\u308C\u306C",
  "id" : 201310421188222977,
  "created_at" : "2012-05-12 13:58:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201310357669683200",
  "text" : "\u305D\u3057\u3066\uFF33\uFF12\uFF33\u306E\u4EBA\u305F\u3061\u304C\u30AB\u30E9\u30AA\u30B1\u697D\u3057\u305D\u3046\u3067\u3048\u3093\u3073\u3043\u30FC",
  "id" : 201310357669683200,
  "created_at" : "2012-05-12 13:58:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201310233983856642",
  "text" : "\u4E45\u3005\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u3057\u3066\u308B\u3063\u3066\u611F\u3058\u304C\u3059\u308B\u305C",
  "id" : 201310233983856642,
  "created_at" : "2012-05-12 13:57:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201310193689165824",
  "text" : "\u3082\u3057\u304B\u3057\u3066\uFF1A\u53EF\u63DB\uFF1F",
  "id" : 201310193689165824,
  "created_at" : "2012-05-12 13:57:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201310128933306368",
  "text" : "\u5375\u5165\u308A\u96CC\u682A\u304B\u3051\u3054\u306F\u3093\uFF1F",
  "id" : 201310128933306368,
  "created_at" : "2012-05-12 13:57:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201310100235886592",
  "text" : "\u96CC\u682A\u7092\u308A\u5375\u304B\u3051\u3054\u306F\u3093\u7F8E\u5473\u3057\u304B\u3063\u305F",
  "id" : 201310100235886592,
  "created_at" : "2012-05-12 13:57:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201309890264825857",
  "in_reply_to_user_id" : 91551881,
  "text" : "@t_uda \u660E\u65E5\u306E\u30AB\u30D5\u30A7\u6570\u5B66\u3061\u3087\u3063\u3068\u3044\u3051\u306A\u3055\u305D\u3046\u306A\u306E\u3067\u4E8C\u56DE\u76EE\u4EE5\u964D\u306E\u53C2\u52A0\u3067\u3082\u5927\u4E08\u592B\u3067\u3059\u304B\u306D",
  "id" : 201309890264825857,
  "created_at" : "2012-05-12 13:56:32 +0000",
  "in_reply_to_screen_name" : "t_uda",
  "in_reply_to_user_id_str" : "91551881",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201280652073644032",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 201280652073644032,
  "created_at" : "2012-05-12 12:00:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/dtMdgJkL",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti&c=end313124",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201081237220245505",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001omo_ti\u3055\u3093\u304C\u6570\u5B66\u3057\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u30DE\u30C3\u30C1\u3059\u308B\u3068DM\u304C\u5C4A\u304D\u307E\u3059 http:\/\/t.co\/dtMdgJkL #gohantabeyo",
  "id" : 201081237220245505,
  "created_at" : "2012-05-11 22:47:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200942387047051266",
  "text" : "\u30D0\u30FC\u30F3\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 200942387047051266,
  "created_at" : "2012-05-11 13:36:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200843926284926976",
  "text" : "\u6B21\u306E\u6388\u696D\u306F\u8EFD\u304F\u8997\u3044\u3066\u304B\u3089\u6C7A\u3081\u3088",
  "id" : 200843926284926976,
  "created_at" : "2012-05-11 07:04:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200841024761888769",
  "text" : "\u4F55\u3067\u4ECA\u65E5\u306F\u307E\u3068\u3082\u306B\u6559\u6750\u6301\u3063\u3066\u3053\u306A\u304B\u3063\u305F\u3093\u3060\u308D",
  "id" : 200841024761888769,
  "created_at" : "2012-05-11 06:53:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200830769034313729",
  "text" : "\u5E30\u5B85\u3082\u542B\u3081\u3066\u9078\u629E\u80A2\u306F3\u3064\u304B\u2026",
  "id" : 200830769034313729,
  "created_at" : "2012-05-11 06:12:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200830469829427200",
  "text" : "\u5E7E\u4F55\u3063\u307D\u3044\u4F55\u304B\u3060\u3063\u305F\u3068\u8A18\u61B6\u3057\u3066\u3044\u308B\u304C",
  "id" : 200830469829427200,
  "created_at" : "2012-05-11 06:11:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200830374107025408",
  "text" : "\u4ECA\u65E5\u306E\u73FE\u4EE3\u306E\u6570\u7406\u89E3\u6790\u306F\u30FC\uFF1F",
  "id" : 200830374107025408,
  "created_at" : "2012-05-11 06:11:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200830192401395712",
  "text" : "\u5E30\u5B85\u308F\u3093\u3061\u3083\u3093\u3060\u304C\u5E30\u3063\u305F\u3089\u51FA\u306A\u3044\u3060\u308D\u3046\u3057\u4E94\u773C\u5F85\u6A5F",
  "id" : 200830192401395712,
  "created_at" : "2012-05-11 06:10:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200812345516228610",
  "text" : "\u30AE\u30E3\u30AE\u30E3\u57FA\u5E95\u306E\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3092\u30AA\u30FC\u30D7\u30F3\u30B9\u30DA\u30FC\u30B9\u3067\u898B\u3066\u305F\u3089\u7B11\u3044\u304C\u3084\u3070\u3044",
  "id" : 200812345516228610,
  "created_at" : "2012-05-11 04:59:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "end313124_memo",
      "indices" : [ 21, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/7tdxpKPG",
      "expanded_url" : "http:\/\/d.hatena.ne.jp\/inouetakuya\/20100709\/1278634808",
      "display_url" : "d.hatena.ne.jp\/inouetakuya\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200808351817404416",
  "text" : "http:\/\/t.co\/7tdxpKPG #end313124_memo",
  "id" : 200808351817404416,
  "created_at" : "2012-05-11 04:43:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200792875825508353",
  "geo" : { },
  "id_str" : "200794012662251521",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5165\u308C\u308B\u3060\u3051\u3044\u308C\u3066\u898B\u3066\u5916\u3059\u3057(^^)(^^)(^^)",
  "id" : 200794012662251521,
  "in_reply_to_status_id" : 200792875825508353,
  "created_at" : "2012-05-11 03:46:37 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200792767419514880",
  "text" : "Echophone\u3044\u308C\u305F",
  "id" : 200792767419514880,
  "created_at" : "2012-05-11 03:41:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200792352141475841",
  "text" : "Tweetbird\u3082\u3044\u308C\u305F",
  "id" : 200792352141475841,
  "created_at" : "2012-05-11 03:40:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200791921579401216",
  "text" : "\u672C\u5BB6\u3063\u307D\u3044\u306E\u3044\u308C\u305F",
  "id" : 200791921579401216,
  "created_at" : "2012-05-11 03:38:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200791491357052929",
  "text" : "Soicha\u3044\u308C\u305F",
  "id" : 200791491357052929,
  "created_at" : "2012-05-11 03:36:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200555878695448577",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 200555878695448577,
  "created_at" : "2012-05-10 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200503352684060674",
  "text" : "\uFF33\uFF4B\uFF59\uFF50\uFF45\u306B\u30E1\u30C3\u30BB\u53E9\u304F\u3068\uFF13\u3064\u306E\u6A5F\u5668\u304C\u53CD\u5FDC\u3057\u3066\u306A\u306B\u3053\u308C\u72B6\u614B",
  "id" : 200503352684060674,
  "created_at" : "2012-05-10 08:31:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200501826154528768",
  "text" : "iphone\u3067\u306E\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306F\u305D\u3044\u3061\u3083\u5B89\u5B9A\u3067\u3059\u304B\u306D\u3047",
  "id" : 200501826154528768,
  "created_at" : "2012-05-10 08:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200498874312437760",
  "text" : "\u304A\u52E7\u3081\u306E\u30A2\u30D7\u30EA\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u306A",
  "id" : 200498874312437760,
  "created_at" : "2012-05-10 08:13:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200498839189331968",
  "text" : "iPhone\u8A2D\u5B9A\u7D42\u308F\u3063\u305F\uFF01",
  "id" : 200498839189331968,
  "created_at" : "2012-05-10 08:13:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200441756133765120",
  "text" : "\u3042\u3001\u306F\u3044",
  "id" : 200441756133765120,
  "created_at" : "2012-05-10 04:26:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "indices" : [ 0, 13 ],
      "id_str" : "78523759",
      "id" : 78523759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200440362936963073",
  "geo" : { },
  "id_str" : "200441138597986304",
  "in_reply_to_user_id" : 78523759,
  "text" : "@tatamin_ttmn \u7121\u8077\u306E\u5E97\u9577\u3068\u306F\u7D20\u6575\u306A",
  "id" : 200441138597986304,
  "in_reply_to_status_id" : 200440362936963073,
  "created_at" : "2012-05-10 04:24:26 +0000",
  "in_reply_to_screen_name" : "tatamin_ttmn",
  "in_reply_to_user_id_str" : "78523759",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "indices" : [ 0, 13 ],
      "id_str" : "78523759",
      "id" : 78523759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200440362936963073",
  "geo" : { },
  "id_str" : "200440462690095104",
  "in_reply_to_user_id" : 78523759,
  "text" : "@tatamin_ttmn \u6A5F\u7A2E\u5909\u3067\u3059",
  "id" : 200440462690095104,
  "in_reply_to_status_id" : 200440362936963073,
  "created_at" : "2012-05-10 04:21:44 +0000",
  "in_reply_to_screen_name" : "tatamin_ttmn",
  "in_reply_to_user_id_str" : "78523759",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200440399628730369",
  "text" : "\u3075\u3075\u3075\u3064\u3044\u306B\u30B9\u30DE\u30DB\u306B\u4E57\u308A\u63DB\u3048\u3075\u3075",
  "id" : 200440399628730369,
  "created_at" : "2012-05-10 04:21:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "indices" : [ 0, 13 ],
      "id_str" : "78523759",
      "id" : 78523759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200439148732100608",
  "geo" : { },
  "id_str" : "200440245328674816",
  "in_reply_to_user_id" : 78523759,
  "text" : "@tatamin_ttmn \u3075\u3064\u30AA\u30D5\u3084\u3063\u305F\u3042\u305F\u308A\u3067\u3059",
  "id" : 200440245328674816,
  "in_reply_to_status_id" : 200439148732100608,
  "created_at" : "2012-05-10 04:20:53 +0000",
  "in_reply_to_screen_name" : "tatamin_ttmn",
  "in_reply_to_user_id_str" : "78523759",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "indices" : [ 0, 13 ],
      "id_str" : "78523759",
      "id" : 78523759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200438079750803456",
  "geo" : { },
  "id_str" : "200438959678038016",
  "in_reply_to_user_id" : 78523759,
  "text" : "@tatamin_ttmn \u767E\u4E07\u904D\u3058\u3083\u306A\u3044\u3067\u3059\u3088\u306D\u30FC",
  "id" : 200438959678038016,
  "in_reply_to_status_id" : 200438079750803456,
  "created_at" : "2012-05-10 04:15:46 +0000",
  "in_reply_to_screen_name" : "tatamin_ttmn",
  "in_reply_to_user_id_str" : "78523759",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 0, 7 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200437350235516928",
  "geo" : { },
  "id_str" : "200437451599253506",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_key \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 200437451599253506,
  "in_reply_to_status_id" : 200437350235516928,
  "created_at" : "2012-05-10 04:09:47 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200437402769162240",
  "text" : "\u3082\u3057\u304B\u3057\u3066:\u30BF\u30BF\u30DF\u30F3\u3055\u3093\u306E\u304A\u5E97\u306B\u3044\u308B\uFF1F",
  "id" : 200437402769162240,
  "created_at" : "2012-05-10 04:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306E\u3063\u3061\uFF20\u95A2\u6771\u306E\u4EBA",
      "screen_name" : "Notchi_KT",
      "indices" : [ 0, 10 ],
      "id_str" : "121298858",
      "id" : 121298858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200415664530395136",
  "geo" : { },
  "id_str" : "200415882843914241",
  "in_reply_to_user_id" : 121298858,
  "text" : "@Notchi_KT \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 200415882843914241,
  "in_reply_to_status_id" : 200415664530395136,
  "created_at" : "2012-05-10 02:44:04 +0000",
  "in_reply_to_screen_name" : "Notchi_KT",
  "in_reply_to_user_id_str" : "121298858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200397484986597377",
  "text" : "\u30EA\u30D7\u30B7\u30C3\u30C4\u3066\u4E00\u767A\u5909\u63DB\u3067\u3053\u308C\u304B\u3088",
  "id" : 200397484986597377,
  "created_at" : "2012-05-10 01:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200397394255429634",
  "text" : "\u7406\u8B5C\u5931\u6D25\u9023\u7D9A",
  "id" : 200397394255429634,
  "created_at" : "2012-05-10 01:30:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200397103539826688",
  "text" : "\u306E\u3046\u3053\u3055\u3093\u304C\u306E\u3046\u3053\u3055\u3093\u3060\u3063\u305F",
  "id" : 200397103539826688,
  "created_at" : "2012-05-10 01:29:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 3, 15 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200396997621055488",
  "text" : "RT @hymathlogic: \u306E\u3046\u3053\u3055\u3093\n\u3010\u610F\u5473\u3011\u624B\u9045\u308C\n\u3010\u4F7F\u7528\u4F8B\u3011\u6628\u65E5\u30EC\u30DD\u30FC\u30C8\u3092\u66F8\u304D\u59CB\u3081\u305F\u304C\u306E\u3046\u3053\u3055\u3093\u3060\u3063\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200396785280221185",
    "text" : "\u306E\u3046\u3053\u3055\u3093\n\u3010\u610F\u5473\u3011\u624B\u9045\u308C\n\u3010\u4F7F\u7528\u4F8B\u3011\u6628\u65E5\u30EC\u30DD\u30FC\u30C8\u3092\u66F8\u304D\u59CB\u3081\u305F\u304C\u306E\u3046\u3053\u3055\u3093\u3060\u3063\u305F",
    "id" : 200396785280221185,
    "created_at" : "2012-05-10 01:28:11 +0000",
    "user" : {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "protected" : false,
      "id_str" : "295467216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439420014165106688\/B9GEeIe7_normal.jpeg",
      "id" : 295467216,
      "verified" : false
    }
  },
  "id" : 200396997621055488,
  "created_at" : "2012-05-10 01:29:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200396888674021377",
  "text" : "\u4E00\u9650\u3061\u3083\u3093\u3068\u51FA\u308C\u305F\u3051\u3069\u7A7A\u8179\u306710\u6642\u304F\u3089\u3044\u306B\u96E2\u8131\u3057\u305F\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u3053\u3061\u3089\u306B\u306A\u308A\u307E\u3059",
  "id" : 200396888674021377,
  "created_at" : "2012-05-10 01:28:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u308B\u3093 [\u6700\u7D42\u898F\u5236\u30A2\u30AB]",
      "screen_name" : "nisehorrrrrrrn",
      "indices" : [ 11, 26 ],
      "id_str" : "295218654",
      "id" : 295218654
    }, {
      "name" : "\u4E32\u7530 \u62D3\u7F8E",
      "screen_name" : "prelude_types",
      "indices" : [ 27, 41 ],
      "id_str" : "1368266268",
      "id" : 1368266268
    }, {
      "name" : "\u8336\u67F1\u3055\u3093(\u304A\u4F11\u307F\u4E2D\u3067\u3059)",
      "screen_name" : "chabashirasan",
      "indices" : [ 58, 72 ],
      "id_str" : "472125109",
      "id" : 472125109
    }, {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 73, 83 ],
      "id_str" : "157989076",
      "id" : 157989076
    }, {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 84, 94 ],
      "id_str" : "158645894",
      "id" : 158645894
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 95, 105 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200361546612879361",
  "text" : ".@ispamgis @nisehorrrrrrrn @Prelude_TypeS @2701ChocoLatte @chabashirasan @typekanon @eclair_15 @Lisa_math \u304A\u306F\u3088\u3046\u3042\u308A\u304C\u3068\u3046\u3067\u3057\u305F",
  "id" : 200361546612879361,
  "created_at" : "2012-05-09 23:08:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 1, 16 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 27, 35 ],
      "id_str" : "57847957",
      "id" : 57847957
    }, {
      "name" : "Ron kul",
      "screen_name" : "kul_Ron",
      "indices" : [ 36, 44 ],
      "id_str" : "2909728068",
      "id" : 2909728068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200361385241231360",
  "text" : ".@G4_Hirano_chan @ispamgis @ninetan @kuL_Ron @kotorin_z \u304A\u3084\u3059\u307F\u3069\u30FC\u3082\u3067\u3057\u305F\u30FC",
  "id" : 200361385241231360,
  "created_at" : "2012-05-09 23:07:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200360067978104832",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 200360067978104832,
  "created_at" : "2012-05-09 23:02:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200360021626851328",
  "text" : "\u305D\u3057\u3066\u76EE\u899A\u3081\u305F",
  "id" : 200360021626851328,
  "created_at" : "2012-05-09 23:02:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200358359545810944",
  "text" : "\u307E\u3069\u308D\u307F",
  "id" : 200358359545810944,
  "created_at" : "2012-05-09 22:55:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200259001252974592",
  "text" : "\u5BDD\u308B\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044zzz",
  "id" : 200259001252974592,
  "created_at" : "2012-05-09 16:20:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200258187268599808",
  "text" : "\u3042\u3068\u30E9\u30C6\u30F3\u8A9E\u306F\u5206\u6570\u3068\u304B\u306E\u6570\u5B57\u8868\u73FE\u304C\u51F6\u60AA\u3060\u3063\u305F\u3088\u3046\u306A\u8A18\u61B6\u304C",
  "id" : 200258187268599808,
  "created_at" : "2012-05-09 16:17:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200257907625967616",
  "text" : "\u3057\u304B\u3057\u30E9\u30C6\u30F3\u8A9E\u3067\u3042\u308B\u7A0B\u5EA6\u6587\u304C\u8AAD\u3081\u308B\u5727\u5012\u7684\u6587\u5B66\u5F92\u304C\u53CB\u4EBA\u306B\u3044\u3066\u5727\u5012\u7684",
  "id" : 200257907625967616,
  "created_at" : "2012-05-09 16:16:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200257064453414913",
  "geo" : { },
  "id_str" : "200257421480968192",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u306A\u3093\u304B\u7A81\u3063\u639B\u304B\u308B\u611F\u3058\u306B\u306A\u3063\u3061\u3083\u3063\u3066\u3054\u3081\u3093\u306A\u3055\u3044\u3067\u3057\u305F\u3002\u81EA\u5206\u3082\u9762\u767D\u3044\u3068\u601D\u3063\u3066\u3084\u3063\u3066\u305F\u3093\u3067\u9762\u767D\u307F\u306F\u308F\u304B\u308A\u307E\u3059\u3002",
  "id" : 200257421480968192,
  "in_reply_to_status_id" : 200257064453414913,
  "created_at" : "2012-05-09 16:14:24 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200257095772282880",
  "text" : "\u982D\u60AA\u3044\u306A",
  "id" : 200257095772282880,
  "created_at" : "2012-05-09 16:13:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u97FB\u4F9D\u5B58\u30E9\u30F3\u30C0\u30E0\u30CD\u30B9",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200257004139315201",
  "text" : "\u97FF\u304D\u3060\u3051\u306A\u3089\u5727\u5012\u7684\u306B\u826F\u3044\u304C\u3053\u308C\u3060\u3051\u3060\u3068\u610F\u5473\u5727\u5012\u7684\u4E0D\u660E #\u97FB\u4F9D\u5B58\u30E9\u30F3\u30C0\u30E0\u30CD\u30B9",
  "id" : 200257004139315201,
  "created_at" : "2012-05-09 16:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u97FB\u4F9D\u5B58\u30E9\u30F3\u30C0\u30E0\u30CD\u30B9",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200256895381020672",
  "text" : "#\u97FB\u4F9D\u5B58\u30E9\u30F3\u30C0\u30E0\u30CD\u30B9",
  "id" : 200256895381020672,
  "created_at" : "2012-05-09 16:12:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200256764178993152",
  "text" : "\u30E9\u30C6\u30F3\u8A9E\u306F\u683C\u3068\u304B\u8A9E\u5C3E\u5909\u5316\u306E\u591A\u3055\u3068\u8A9E\u9806\u306E(\u97FB\u4F9D\u5B58)\u30E9\u30F3\u30C0\u30E0\u30CD\u30B9\u304C\u5727\u5012\u7684\u3060\u3063\u305F",
  "id" : 200256764178993152,
  "created_at" : "2012-05-09 16:11:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200255766958063617",
  "geo" : { },
  "id_str" : "200256333231030272",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u4E00\u5FDC\u3001\u5F62\u4E0A\u3001\u5165\u9580\u306E\u6700\u5F8C\u307E\u3067\u89E6\u308C\u307E\u3057\u305F\u304C\u3001\u3082\u3046\u2026\u3082\u3046\u3002\u305F\u3060\u6570\u5B66\u3068\u304B\u306B\u4F7F\u308F\u308C\u3066\u308B\u7528\u8A9E\u3092\u4F7F\u3063\u3066\u7C21\u5358\u306A\u6587\u6CD5\u89E3\u8AAC\u3068\u304B\u306A\u3089\u9762\u767D\u3044\u304B\u3082\u3057\u308C\u307E\u305B\u3093\uFF01",
  "id" : 200256333231030272,
  "in_reply_to_status_id" : 200255766958063617,
  "created_at" : "2012-05-09 16:10:05 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 12, 23 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200255498300305409",
  "geo" : { },
  "id_str" : "200255652013154304",
  "in_reply_to_user_id" : 520458209,
  "text" : "\u30C0\u30A6\u30C8\uFF6B\uFF6B\uFF01\uFF01\uFF01 QT @Maleic1618: \u30E9\u30C6\u30F3\u8A9E\u3063\u3066\u6587\u6CD5\u3068\u304B\u9762\u5012\u306A\u306E\u306A\u3044\u304B\u3089\u697D\uFF57\uFF57\uFF57",
  "id" : 200255652013154304,
  "in_reply_to_status_id" : 200255498300305409,
  "created_at" : "2012-05-09 16:07:22 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200255072557477888",
  "geo" : { },
  "id_str" : "200255404167528448",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u6CE8:\u79C1\u306F\u5165\u3063\u3066\u3044\u307E\u305B\u3093",
  "id" : 200255404167528448,
  "in_reply_to_status_id" : 200255072557477888,
  "created_at" : "2012-05-09 16:06:23 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200255136528998400",
  "text" : "@yurily924 (^^)(^^)(^^)vv",
  "id" : 200255136528998400,
  "created_at" : "2012-05-09 16:05:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200254426869530624",
  "text" : "\u300C\u3082\u3046end\uFF1F\u300D\n\u300C\u306F\u3044\u3001end\u3067\u3059\u3002\u3059\u307F\u307E\u305B\u3093\u3002\u300D",
  "id" : 200254426869530624,
  "created_at" : "2012-05-09 16:02:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200254153161838593",
  "text" : "\u30C9\u30AD\u30C3",
  "id" : 200254153161838593,
  "created_at" : "2012-05-09 16:01:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u95A2\u30B8\u30E3\u30CB\u221E\u3046\u305Fbot",
      "screen_name" : "KJ8song_bot",
      "indices" : [ 3, 15 ],
      "id_str" : "238554514",
      "id" : 238554514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200254117749338112",
  "text" : "RT @KJ8song_bot: \u3082\u3046end\uFF1F\u3000\u4E57\u308A\u8FBC\u3093\u3060\u306E\u306FTRAIN\u3000\u884C\u304F\u5148\u306F\u672A\u77E5\u306A\u308B\u9053\u3000\u4E00\u4F53\u3069\u3053\u3078\u884C\u304F\u3000\uFF08\u767A\u8ECA\u30AA\u30FC\u30E9\u30A4\uFF09\u3000\uFF1AT.W.L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200234372614471680",
    "text" : "\u3082\u3046end\uFF1F\u3000\u4E57\u308A\u8FBC\u3093\u3060\u306E\u306FTRAIN\u3000\u884C\u304F\u5148\u306F\u672A\u77E5\u306A\u308B\u9053\u3000\u4E00\u4F53\u3069\u3053\u3078\u884C\u304F\u3000\uFF08\u767A\u8ECA\u30AA\u30FC\u30E9\u30A4\uFF09\u3000\uFF1AT.W.L",
    "id" : 200234372614471680,
    "created_at" : "2012-05-09 14:42:49 +0000",
    "user" : {
      "name" : "\u95A2\u30B8\u30E3\u30CB\u221E\u3046\u305Fbot",
      "screen_name" : "KJ8song_bot",
      "protected" : false,
      "id_str" : "238554514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606115025124626432\/W2TJ80oq_normal.jpg",
      "id" : 238554514,
      "verified" : false
    }
  },
  "id" : 200254117749338112,
  "created_at" : "2012-05-09 16:01:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200253467338604544",
  "text" : "\u4E00\u9650\u306B\u9593\u306B\u5408\u3046\u3088\u3046\u306B\u3059\u3063\u304D\u308A\u8D77\u304D\u3089\u308C\u308B\u30B9\u30AD\u30EB\u304C\u6B32\u3057\u3044",
  "id" : 200253467338604544,
  "created_at" : "2012-05-09 15:58:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200252786804404224",
  "text" : "S2S\u30E9\u30C6\u30F3\u8A9E\u8B1B\u7FA9\u3068\u304B\u3075\u3075\u3075",
  "id" : 200252786804404224,
  "created_at" : "2012-05-09 15:55:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u3068\u304D\u3057\u3093\uFF08\u3044\u304C\uFF09",
      "screen_name" : "igatoxin",
      "indices" : [ 0, 9 ],
      "id_str" : "562119750",
      "id" : 562119750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200187438994423809",
  "geo" : { },
  "id_str" : "200216109868257280",
  "in_reply_to_user_id" : 562119750,
  "text" : "@igatoxin \u3042\u3001\u3054\u3081\u3093\u306A\u3055\u3044\u3002\u304B\u306A\u308A\u9069\u5F53\u306B\u691C\u7D22\u304B\u3051\u3066\u5F15\u3063\u639B\u3051\u305F\u3082\u306E\u3060\u3063\u305F\u306E\u3067\u5168\u7136\u601D\u3044\u81F3\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u2026\u3002",
  "id" : 200216109868257280,
  "in_reply_to_status_id" : 200187438994423809,
  "created_at" : "2012-05-09 13:30:15 +0000",
  "in_reply_to_screen_name" : "igatoxin",
  "in_reply_to_user_id_str" : "562119750",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200148914740015104",
  "text" : "@ayu167 \u30CA\u30A4\u30B9\u30D0\u30FC\u30F3\uFF01",
  "id" : 200148914740015104,
  "created_at" : "2012-05-09 09:03:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200146159229079552",
  "text" : "\u713C\u304D\u9B5A\u3001\u5375\u713C\u304D\u3068\u708A\u304D\u7ACB\u3066\u3054\u306F\u3093\u3000\u3044\u3046\u3053\u3068\u306A\u3057",
  "id" : 200146159229079552,
  "created_at" : "2012-05-09 08:52:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3048\u3093\u3069\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200088139279241216",
  "text" : "#\u3048\u3093\u3069\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0",
  "id" : 200088139279241216,
  "created_at" : "2012-05-09 05:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200088112599277569",
  "text" : "RT @the_TQFT: \u570F\u5316\u3057\u3088\u3046\u305C!!!!!(^^)(^^)(^^)(^^)(^^)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200087806293458944",
    "text" : "\u570F\u5316\u3057\u3088\u3046\u305C!!!!!(^^)(^^)(^^)(^^)(^^)",
    "id" : 200087806293458944,
    "created_at" : "2012-05-09 05:00:25 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 200088112599277569,
  "created_at" : "2012-05-09 05:01:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200075845262520320",
  "text" : "\u3066\uFF53\u3066\uFF53",
  "id" : 200075845262520320,
  "created_at" : "2012-05-09 04:12:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200071562353836033",
  "text" : "\u3055\u3066\u3001\u52C9\u5F37\u3059\u308B\u304B",
  "id" : 200071562353836033,
  "created_at" : "2012-05-09 03:55:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200071277308948482",
  "text" : "\u30EA\u30A2\u5145\u304C\u53CB\u4EBA\u306E\u5199\u771F\u3068\u304B\u306B\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3059\u308B\u306E\u304C\u3060\u308B\u3044\u307F\u305F\u3044\u306A\u8A71\u3057\u3066\u305F\u304B\u3089\u6BBA\u4F10\u3068\u3057\u305F\uFF34L\u3067\u826F\u304B\u3063\u305F\u3068\u3061\u3087\u3063\u3068\u601D\u3063\u3066\u3044\u308B",
  "id" : 200071277308948482,
  "created_at" : "2012-05-09 03:54:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200070884692729858",
  "text" : "\u306A\u3093\u304B\u3053\u306E\u6587\u5B66\u90E8\u30E9\u30A6\u30F3\u30B8\u3067\u4EA4\u308F\u3055\u308C\u308B\u4F1A\u8A71\u8272\u3005\u6016\u3044\u3093\u3060\u304C",
  "id" : 200070884692729858,
  "created_at" : "2012-05-09 03:53:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarriageTheorem",
      "screen_name" : "MarriageTheorem",
      "indices" : [ 1, 17 ],
      "id_str" : "85303739",
      "id" : 85303739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/l18we6zP",
      "expanded_url" : "http:\/\/togetter.com\/li\/300588",
      "display_url" : "togetter.com\/li\/300588"
    } ]
  },
  "geo" : { },
  "id_str" : "200067418666713091",
  "text" : ".@MarriageTheorem \u3055\u3093\u306E\u300C\u591C\u4E2D\u306B\u7E70\u308A\u5E83\u3052\u3089\u308C\u305F\u305F\u304B\u3044\u968E\u3092\u76EE\u6307\u3059\u95D8\u3044\u300D\u3092\u304A\u6C17\u306B\u5165\u308A\u306B\u3057\u307E\u3057\u305F\u3002 http:\/\/t.co\/l18we6zP",
  "id" : 200067418666713091,
  "created_at" : "2012-05-09 03:39:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/l18we6zP",
      "expanded_url" : "http:\/\/togetter.com\/li\/300588",
      "display_url" : "togetter.com\/li\/300588"
    } ]
  },
  "geo" : { },
  "id_str" : "200067027858243586",
  "text" : "\u591C\u4E2D\u306B\u7E70\u308A\u5E83\u3052\u3089\u308C\u305F\u305F\u304B\u3044\u968E\u3092\u76EE\u6307\u3059\u95D8\u3044 http:\/\/t.co\/l18we6zP",
  "id" : 200067027858243586,
  "created_at" : "2012-05-09 03:37:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200066053282336770",
  "text" : "\u304F\u308B\u304F\u308B\u3061\u3083\u3093\u3055\u3093\u306A\u3089\u8010\u3048\u308B\uFF1F",
  "id" : 200066053282336770,
  "created_at" : "2012-05-09 03:33:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200065628374175744",
  "geo" : { },
  "id_str" : "200065738910867456",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u3042\u30FC\u3001\u307D\u3044\u3063\u3061\u3083\u307D\u3044\u3067\u3059\u304C\uFF08\u504F\u898B\uFF09",
  "id" : 200065738910867456,
  "in_reply_to_status_id" : 200065628374175744,
  "created_at" : "2012-05-09 03:32:43 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200065488980672512",
  "text" : "\u30BA\u30C3\u53CB\u3063\u3066\u5143\u30CD\u30BF\u4F55\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 200065488980672512,
  "created_at" : "2012-05-09 03:31:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200063350783217664",
  "text" : "\u5B66\u90E8\u30E9\u30A6\u30F3\u30B8\u306E\u306F\u3058\u3063\u3053\u3067\u76DB\u308A\u4E0A\u304C\u308B\u4F1A\u8A71\u3092\u5C3B\u76EE\u306B\u30CE\u30FC\u30C8\uFF30\uFF23\u3067\u3064\u3044\u3063\u305F\u3057\u3066\u308B\u306E\u304C\u79C1\u3067\u3059",
  "id" : 200063350783217664,
  "created_at" : "2012-05-09 03:23:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200062818358272002",
  "text" : "\u305F\u3044\u3078\u6570\u5B66\u3044\u3088\u3046\u30EF\u30F3\u30C1\u30E3\u30F3\uFF1F",
  "id" : 200062818358272002,
  "created_at" : "2012-05-09 03:21:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200062260549398528",
  "geo" : { },
  "id_str" : "200062441684598784",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u30CA\u30A4\u30B9\u30E2\u30F3\u30B9\u30BF\u30FC\uFF01",
  "id" : 200062441684598784,
  "in_reply_to_status_id" : 200062260549398528,
  "created_at" : "2012-05-09 03:19:37 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200062405793951745",
  "text" : "\u3042\u3046",
  "id" : 200062405793951745,
  "created_at" : "2012-05-09 03:19:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE\u6587",
      "indices" : [ 8, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200062079883952129",
  "text" : "\u4E0A\u6D77\u306E\u5357\u306E\u6D77\u4E0A #\u56DE\u6587",
  "id" : 200062079883952129,
  "created_at" : "2012-05-09 03:18:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200061885830270977",
  "text" : "\u4E0A\u6D77\u3058\u3083\u306A\u304F\u3066\u6D77\u4E0A\u306D\uFF01",
  "id" : 200061885830270977,
  "created_at" : "2012-05-09 03:17:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200061813084262401",
  "text" : "\u4F1A\u5834\u306F\u6D77\u4E0A\u3067\u3059\uFF01",
  "id" : 200061813084262401,
  "created_at" : "2012-05-09 03:17:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200061541586960384",
  "text" : "\u3088\u3057\u7E4B\u304C\u3063\u305F",
  "id" : 200061541586960384,
  "created_at" : "2012-05-09 03:16:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200061263781445633",
  "text" : "\u3053\u3053\u306F\u96FB\u6CE2\u5F31\u3044\u306A\u3041",
  "id" : 200061263781445633,
  "created_at" : "2012-05-09 03:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200060261741240320",
  "text" : "\u590F\u306B\u5E30\u7701\u3057\u305F\u3089\u6771\u4EAC\u306E\u6570\u5B66\u5F92\u306B\u4F1A\u3044\u305F\u3044\u306A",
  "id" : 200060261741240320,
  "created_at" : "2012-05-09 03:10:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200059748052242432",
  "text" : "\u8AB0\u304B\u7A7A\u6BCD\u307F\u305F\u3044\u306E\u3082\u3063\u3066\u306A\u3044\u306E",
  "id" : 200059748052242432,
  "created_at" : "2012-05-09 03:08:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 0, 10 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200059380056600577",
  "geo" : { },
  "id_str" : "200059523191406592",
  "in_reply_to_user_id" : 155546700,
  "text" : "@end313124 \uFF12\u9650\u306B\u51FA\u308B\u3079\u304D\u3060\u3063\u305F\u3093\u3060\u3088",
  "id" : 200059523191406592,
  "in_reply_to_status_id" : 200059380056600577,
  "created_at" : "2012-05-09 03:08:01 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200059380056600577",
  "text" : "\uFF13\u9650\u51FA\u308B\u3064\u3082\u308A\u306A\u304F\u3066\uFF14\u9650\u5185\u8077\u3057\u3066\uFF15\u9650\u65E9\u9000\u3059\u308B\u4E88\u5B9A\u306A\u3093\u3060\u3051\u3069\u4F55\u3057\u306B\u6765\u305F\u3093\u3060\u308D",
  "id" : 200059380056600577,
  "created_at" : "2012-05-09 03:07:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "indices" : [ 7, 14 ],
      "id_str" : "26393410",
      "id" : 26393410
    }, {
      "name" : "\u305F\u304BC\u30C9\u30A5\u30FC",
      "screen_name" : "hiroskii_mk2",
      "indices" : [ 16, 29 ],
      "id_str" : "247411674",
      "id" : 247411674
    }, {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 30, 41 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200058903466225664",
  "geo" : { },
  "id_str" : "200059061436297217",
  "in_reply_to_user_id" : 26393410,
  "text" : "\u6D77\u4E0A\uFF1F QT @tomo37: @hiroskii_mk2 @noukoknows \u95A2\u6771\u3068\u95A2\u897F\u3068\u6D77\u5916\u3001\u9593\u3092\u53D6\u3063\u3066\u3069\u3053\u306B\u3059\u308B\uFF1F",
  "id" : 200059061436297217,
  "in_reply_to_status_id" : 200058903466225664,
  "created_at" : "2012-05-09 03:06:11 +0000",
  "in_reply_to_screen_name" : "tomo37",
  "in_reply_to_user_id_str" : "26393410",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200056376859443201",
  "text" : "\u30AA\u30EA\u30FC\u30D6\u30AA\u30A4\u30E9\u30FC\u306E\u591A\u9762\u4F53\u5B9A\u7406",
  "id" : 200056376859443201,
  "created_at" : "2012-05-09 02:55:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200055902542364672",
  "text" : "\u5B66\u98DF\u306B\u30B3\u30ED\u30C3\u30B1\u305D\u3070\u306A\u3044\u304B\u3089\u304B\u3051\u305D\u3070\u3068\u30B3\u30ED\u30C3\u30B1\u3067\u98DF\u3079\u3066\u307F\u305F\u304C\u3084\u3063\u3071\u308A\u30B3\u30ED\u30C3\u30B1\u304C\u3061\u3083\u3093\u3068\u3057\u3066\u3061\u3083\u30C0\u30E1\u3060\u306A",
  "id" : 200055902542364672,
  "created_at" : "2012-05-09 02:53:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200031366199521281",
  "text" : "\u30CE\u30FC\u30C8\u306E\u8CA0\u50B5\u304C\u65E9\u304F\u3082\u7D20\u6575\u306A\u3053\u3068\u306B",
  "id" : 200031366199521281,
  "created_at" : "2012-05-09 01:16:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5168\u65E5\u672C\u3082\u3046\u7720\u308A\u305F\u3044\u5354\u4F1A",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200025361847816193",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059 #\u5168\u65E5\u672C\u3082\u3046\u7720\u308A\u305F\u3044\u5354\u4F1A",
  "id" : 200025361847816193,
  "created_at" : "2012-05-09 00:52:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200023783074045953",
  "text" : "\u5DE6\u76EE\u306E\u8996\u754C\u304C\u56FA\u5B9A\u3055\u308C\u308B\u3068\u3044\u3046\u5727\u5012\u7684\u5947\u5999\u306A\u5922\u3092\u898B\u305F",
  "id" : 200023783074045953,
  "created_at" : "2012-05-09 00:46:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200022051996700672",
  "text" : "\u3042\u3068\u306F\u96E8\u304C\u56F0\u308B\u3045\u3045",
  "id" : 200022051996700672,
  "created_at" : "2012-05-09 00:39:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u3068\u304D\u3057\u3093\uFF08\u3044\u304C\uFF09",
      "screen_name" : "igatoxin",
      "indices" : [ 0, 9 ],
      "id_str" : "562119750",
      "id" : 562119750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199967837136224257",
  "geo" : { },
  "id_str" : "200021866210000897",
  "in_reply_to_user_id" : 562119750,
  "text" : "@igatoxin \u4F55\u3092\u3067\u3057\u3087\u3046",
  "id" : 200021866210000897,
  "in_reply_to_status_id" : 199967837136224257,
  "created_at" : "2012-05-09 00:38:23 +0000",
  "in_reply_to_screen_name" : "igatoxin",
  "in_reply_to_user_id_str" : "562119750",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200021452815212545",
  "text" : "\u305D\u3057\u3066\u4F55\u3088\u308A\uFF01\u300C\u7761\u7720\u6642\u9593\u300D\u304C\u8DB3\u308A\u306A\u3044\uFF01",
  "id" : 200021452815212545,
  "created_at" : "2012-05-09 00:36:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199996151439704066",
  "text" : "\u306A\u3093\u304B\u3082\u3046\u4E8C\u5EA6\u5BDD\u3059\u308B\u305F\u3081\u306B\u65E9\u8D77\u304D\u3057\u3066\u3093\u3058\u3083\u306A\u3044\u304B",
  "id" : 199996151439704066,
  "created_at" : "2012-05-08 22:56:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199917893616541697",
  "text" : "@ayu167 \u5727\u5012\u7684\u81EA\u6BBA\u30B9\u30AD\u30EB(^^)(^^)(^^)(^^)(^^)",
  "id" : 199917893616541697,
  "created_at" : "2012-05-08 17:45:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199917415486849024",
  "text" : "@ayu167 \u539F\u4ED8\u306F\u975E\u5BFE\u5FDC",
  "id" : 199917415486849024,
  "created_at" : "2012-05-08 17:43:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199916825390235648",
  "text" : "\u7761\u7720\u3057\u306A\u304C\u3089\u4ED5\u4E8B\u3057\u306A\u304C\u3089\u52C9\u5F37\u3057\u306A\u304C\u3089\u3054\u98EF\u98DF\u3079\u306A\u304C\u3089\u304A\u98A8\u5442\u5165\u308A\u306A\u304C\u3089\u5358\u4F4D\u53D6\u308C\u306A\u304C\u3089\u904A\u3073\u306A\u304C\u3089\u79FB\u52D5\u3067\u304D\u308B\u30B9\u30AD\u30EB\u304C\u6B32\u3057\u3044",
  "id" : 199916825390235648,
  "created_at" : "2012-05-08 17:41:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199831144148119552",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 199831144148119552,
  "created_at" : "2012-05-08 12:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/kMTWhCir",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=akekasetei",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199772454204346368",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001akekasetei\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u30DE\u30C3\u30C1\u3059\u308B\u3068DM\u304C\u5C4A\u304D\u307E\u3059 http:\/\/t.co\/kMTWhCir #gohantabeyo",
  "id" : 199772454204346368,
  "created_at" : "2012-05-08 08:07:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/mb4sqjp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30A4\u30EB\u30D5\u30A9\u30FC\u30B9\u30AF\u30A8\u30A2\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/JAN94Ufy",
      "expanded_url" : "http:\/\/mb4sq.jp\/IGgOWL",
      "display_url" : "mb4sq.jp\/IGgOWL"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "199763012591165441",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ http:\/\/t.co\/JAN94Ufy",
  "id" : 199763012591165441,
  "created_at" : "2012-05-08 07:29:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 34 ],
      "url" : "https:\/\/t.co\/sMQjGGG2",
      "expanded_url" : "https:\/\/socio.k.kyoto-u.ac.jp\/sis",
      "display_url" : "socio.k.kyoto-u.ac.jp\/sis"
    } ]
  },
  "geo" : { },
  "id_str" : "199665188264349697",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella https:\/\/t.co\/sMQjGGG2 \u3042\u3069\u308C\u3059\u3069\u305E\u30FC",
  "id" : 199665188264349697,
  "created_at" : "2012-05-08 01:01:05 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5168\u65E5\u672C\u3082\u3046\u7720\u308A\u305F\u3044\u5354\u4F1A",
      "indices" : [ 4, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199635148092874754",
  "text" : "\u8D77\u304D\u305F #\u5168\u65E5\u672C\u3082\u3046\u7720\u308A\u305F\u3044\u5354\u4F1A",
  "id" : 199635148092874754,
  "created_at" : "2012-05-07 23:01:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199633882121912320",
  "text" : "\u3082\u305E\u3082\u305E",
  "id" : 199633882121912320,
  "created_at" : "2012-05-07 22:56:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u9078\u629E\u516C\u7406\u3061\u3083\u3093\u30DE\u30B8\u516C\u7406",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199490434475622400",
  "text" : "#\u9078\u629E\u516C\u7406\u3061\u3083\u3093\u30DE\u30B8\u516C\u7406",
  "id" : 199490434475622400,
  "created_at" : "2012-05-07 13:26:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 9, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199443191274012672",
  "text" : "\u304A\u75B2\u308C\u69D8\u3067\u3057\u305F\u30FC #s2s_seminar",
  "id" : 199443191274012672,
  "created_at" : "2012-05-07 10:18:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199443027381587968",
  "text" : "\u7A7A\u624B\u8E0A\u308A\u3001\u30B7\u30E5\u30EC\u30C7\u30A3\u30F3\u30AC\u30FC\u97F3\u982D\u3001\u30CA\u30C3\u30B7\u30E5\u5747\u8861\u97F3\u982D",
  "id" : 199443027381587968,
  "created_at" : "2012-05-07 10:18:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 9, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199442694458716160",
  "text" : "\u7A7A\u624B\u8E0A\u308A\uFF1F\uFF1F\uFF1F\uFF1F #s2s_seminar",
  "id" : 199442694458716160,
  "created_at" : "2012-05-07 10:16:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199442613038874626",
  "text" : "\u6E2C\u308A\u65B9\u3067\u6E2C\u5EA6\u304C\u5909\u308F\u3063\u3061\u3083\u3063\u305F\u3089\u307E\u305A\u3044 #s2s_seminar",
  "id" : 199442613038874626,
  "created_at" : "2012-05-07 10:16:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199442480154943489",
  "text" : "\u5B9F\u306F\u30EB\u30D9\u30FC\u30B0\u5916\u6E2C\u5EA6\u3068\u3044\u3046\u3082\u306E\u3060\u3063\u305F #s2s_seminar",
  "id" : 199442480154943489,
  "created_at" : "2012-05-07 10:16:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 4, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199442093255565313",
  "text" : "\u4EE5\u4E0A\uFF01 #s2s_seminar",
  "id" : 199442093255565313,
  "created_at" : "2012-05-07 10:14:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199442056798683136",
  "text" : "\u7D50\u5C40\u6700\u521D\u306B\u51FA\u3066\u304D\u305F\u95A2\u6570\u306E\u7A4D\u5206\u5024\u306F\uFF10\u306B\u306A\u308B\uFF01 #s2s_seminar",
  "id" : 199442056798683136,
  "created_at" : "2012-05-07 10:14:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199441871058124800",
  "text" : "\u4ECA\u306F[\uFF10\uFF0C\uFF11]\u3067\u8003\u3048\u305F\u3051\u3069\u3069\u3053\u3067\u3082\u4E00\u7DD2 #s2s_seminar",
  "id" : 199441871058124800,
  "created_at" : "2012-05-07 10:13:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 42, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199441754552938496",
  "text" : "\u3067\u305D\u308C\u306F\u30A4\u30D7\u30B7\u30ED\u30F3\u3092\u4F7F\u3063\u3066\u66F8\u3051\u308B\u306E\u3067\u30A4\u30D7\u30B7\u30ED\u30F3\u306F\u5E7E\u3089\u3067\u3082\u5C0F\u3055\u304F\u3067\u304D\u308B\u306E\u3067\u3001\uFF10\u306B\u306A\u308B #s2s_seminar",
  "id" : 199441754552938496,
  "created_at" : "2012-05-07 10:13:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199441541008343041",
  "text" : "\uFF08\u3053\u306E\u5206\u5272\u3092\u5B9F\u6CC1\u3059\u308B\u306E\u306F\u96E3\u3057\u3044\u305C\uFF09",
  "id" : 199441541008343041,
  "created_at" : "2012-05-07 10:12:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 42, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199441479922499585",
  "text" : "I_i\u3092\u4E0A\u624B\u306B\u88AB\u8986\u3059\u308B\u3088\u3046\u306B\u53D6\u3063\u3066\u304F\u308B\uFF08\u53D6\u308A\u65B9\u306F\u3053\u3046\u3001\u90FD\u5408\u826F\u304F\u3001\u3046\u307E\u3044\u3053\u3068\u8003\u3048\u308B\uFF09 #s2s_seminar",
  "id" : 199441479922499585,
  "created_at" : "2012-05-07 10:12:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199440872419495936",
  "text" : "\u53EF\u7B97\u3068\u306F\u81EA\u7136\u6570\u3068\u5BFE\u5FDC\u304C\u4ED8\u3051\u3089\u308C\u308B\u3082\u306E #s2s_seminar",
  "id" : 199440872419495936,
  "created_at" : "2012-05-07 10:09:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 7, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199440733122465793",
  "text" : "\u6709\u7406\u6570\u306F\u53EF\u7B97 #s2s_seminar",
  "id" : 199440733122465793,
  "created_at" : "2012-05-07 10:09:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199440643943170048",
  "text" : "\u5B9F\u306F\u2026\u300C\u03BC\uFF08Q\uFF09\uFF1D\uFF10\u300D\u3067\u3042\u308B #s2s_seminar",
  "id" : 199440643943170048,
  "created_at" : "2012-05-07 10:08:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 30, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199440446966075393",
  "text" : "\u3055\u3063\u304D\u306E\u95A2\u6570\u3092[\uFF10\u3001\uFF11]\u3067\u7A4D\u5206\u3059\u308B\u304C\u03BC\uFF08Q\uFF09\u3092\u8003\u3048\u308C\u3070\u7D20\u6575 #s2s_seminar",
  "id" : 199440446966075393,
  "created_at" : "2012-05-07 10:08:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199440137585831937",
  "text" : "\u305D\u306E\u6709\u9650\u500B\u306E\u88AB\u8986I_i\u306E\u9577\u3055\u306E\u5408\u8A08\u306E\u4E0B\u9650\u3067\u6E2C\u5EA6\u3092\u4E0E\u3048\u308B#s2s_seminar",
  "id" : 199440137585831937,
  "created_at" : "2012-05-07 10:06:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199439328101924864",
  "text" : "\u5C0F\u91CE\u5BFA\u300Ci\u306F\u81EA\u7136\u6570\u300D\n\u9ED2\u677F\u300Ci=1,2,3,\u2026\u30FB\u300D\n\n\u3056\u308F\u30FB\u30FB\u30FB\u3056\u308F\u30FB\u30FB\u30FB #s2s_seminar",
  "id" : 199439328101924864,
  "created_at" : "2012-05-07 10:03:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 30, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199439027491971072",
  "text" : "\u3068\u3073\u3068\u3073\u3067\u3082\u3044\u3044\u306E\u3067\u51FA\u6765\u308B\u3060\u3051\u5C0F\u3055\u3044\u3082\u306E\u3067\u8986\u3046\u3053\u3068\u3092\u8003\u3048\u308B #s2s_seminar",
  "id" : 199439027491971072,
  "created_at" : "2012-05-07 10:02:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199438862882308097",
  "text" : "\u533A\u9593\u3092\u534A\u958B\u533A\u9593\u3067\u8986\u3063\u3066\u3044\u304F #s2s_seminar",
  "id" : 199438862882308097,
  "created_at" : "2012-05-07 10:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199438716127805441",
  "text" : "\u3042\u3063\u3068\u3046\u3066\u304D\u3072\u3089\u3081\u304D",
  "id" : 199438716127805441,
  "created_at" : "2012-05-07 10:01:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199438662025478144",
  "text" : "\u30EB\u30D9\u30FC\u30B0\u300C\u6B63\u65B9\u5F62\u306E\u5927\u304D\u3055\u3070\u3089\u3070\u3089\u3067\u3082\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u306E\u300D #s2s_seminar",
  "id" : 199438662025478144,
  "created_at" : "2012-05-07 10:00:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199438344134983680",
  "text" : "\u3067\u3082\u30EB\u30D9\u30FC\u30B0\u901F\u5EA6\u306F\u9055\u3044\u307E\u3059 #s2s_seminar",
  "id" : 199438344134983680,
  "created_at" : "2012-05-07 09:59:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199438256113319940",
  "text" : "\u3067\u3082\u3053\u306E\u30B8\u30E7\u30EB\u30C0\u30F3\u6E2C\u5EA6\u306F\u6709\u7406\u6570\u3060\u3051\u3001\u307F\u305F\u3044\u306A\u3082\u306E\u306B\u306F\u5BFE\u5FDC\u3067\u304D\u306A\u3044 #s2s_seminar",
  "id" : 199438256113319940,
  "created_at" : "2012-05-07 09:59:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199438120582791168",
  "text" : "\uFF08\u5409\u7530\u5148\u751F\u304C\u8A00\u3063\u3066\u305F\u3053\u3068\u306E\u53D7\u3051\u58F2\u308A\u3067\u3059\u3057\uFF09",
  "id" : 199438120582791168,
  "created_at" : "2012-05-07 09:58:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199437992803315713",
  "text" : "\u30B8\u30E7\u30EB\u30C0\u30F3\u6E2C\u5EA6\u306F\u540C\u3058\u5927\u304D\u3055\u306E\u6B63\u65B9\u5F62\u3092\u4F7F\u3063\u3066\u6E2C\u308B\u3002\u7D30\u304B\u3044\u30BF\u30A4\u30EB\u3067\u6577\u304D\u8A70\u3081\u308B\u307F\u305F\u3044\u306A\u611F\u899A\uFF1F #s2s_seminar",
  "id" : 199437992803315713,
  "created_at" : "2012-05-07 09:58:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199437690209439744",
  "text" : "\u3053\u308C\u3060\u3051\u899A\u3048\u3066\u5E30\u308C\u3070\u5727\u5012\u7684 #s2s_seminar",
  "id" : 199437690209439744,
  "created_at" : "2012-05-07 09:57:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199437593820143616",
  "text" : "\u2605\u30EB\u30D9\u30FC\u30B0\u6E2C\u5EA6\u3092\u7528\u3044\u3066\u7A4D\u5206\u3059\u308B\u306E\u304C\u30EB\u30D9\u30FC\u30B0\u7A4D\u5206\u2605 #s2s_seminar",
  "id" : 199437593820143616,
  "created_at" : "2012-05-07 09:56:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 9, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199437449473171456",
  "text" : "\u30EB\u30D9\u30FC\u30B0\u7A4D\u5206\u3068\u306F #s2s_seminar",
  "id" : 199437449473171456,
  "created_at" : "2012-05-07 09:56:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "0\u306F\u81EA\u7136\u6570",
      "indices" : [ 11, 17 ]
    }, {
      "text" : "s2s_seminar",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199437244497534976",
  "text" : "\u8FFD\u4F38\uFF1A\u7A7A\u96C6\u5408\u306F\u6E2C\u5EA6\uFF10 #0\u306F\u81EA\u7136\u6570 #s2s_seminar",
  "id" : 199437244497534976,
  "created_at" : "2012-05-07 09:55:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199437047184891904",
  "text" : "\u975E\u8CA0\u6027\u3001\u5305\u542B\u3068\u5927\u304D\u3055\u306E\u95A2\u4FC2\u306E\u4FDD\u5B58\u3001\u52A3\u52A0\u6CD5\u6027 #s2s_seminar",
  "id" : 199437047184891904,
  "created_at" : "2012-05-07 09:54:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199436735585853441",
  "text" : "\u901F\u5EA6\u304C\u6E80\u305F\u3059\u3079\u304D\u6027\u8CEA\u3001\u6761\u4EF6 is \u4F55 #s2s_seminar",
  "id" : 199436735585853441,
  "created_at" : "2012-05-07 09:53:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199435817821810688",
  "text" : "\u4ECA\u5EA6\u306F\u7E26\u3058\u3083\u306A\u304F\u3066\u6A2A\u306B\u9811\u5F35\u3063\u3066\u5207\u3063\u3066\u307F\u3088\u3046 #s2s_seminar",
  "id" : 199435817821810688,
  "created_at" : "2012-05-07 09:49:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199435637663858688",
  "text" : "[\uFF10\uFF11]\u533A\u9593\u3067\u306F\u3069\u3046\u9811\u5F35\u3063\u3066\u3082S\u3001\uFF53\u306F\uFF11\u3001\uFF10\u306B\u306A\u3063\u3066\u3060\u3081#s2s_seminar",
  "id" : 199435637663858688,
  "created_at" : "2012-05-07 09:48:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199435399570001921",
  "text" : "\u30C7\u30A3\u30EA\u30AF\u30EC\u95A2\u6570\u306F\u3053\u308C\u3058\u3083\u3042\u7A4D\u5206\u3067\u304D\u306A\u3044 #s2s_seminar",
  "id" : 199435399570001921,
  "created_at" : "2012-05-07 09:47:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199435317651054592",
  "text" : "\u5404\u3005\u306E\u30EA\u30DF\u30C3\u30C8\u3092\u4E0A\u7A4D\u5206\u4E0B\u7A4D\u5206\u3068\u3059\u308B\u3001\u4E00\u81F4\u3057\u305F\u3089\u30EA\u30FC\u30DE\u30F3\u53EF\u7A4D\u5206\u3068\u306A\u3063\u3066\u7D20\u6575 #s2s_seminar",
  "id" : 199435317651054592,
  "created_at" : "2012-05-07 09:47:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199435114709663744",
  "text" : "\uFF08\u3053\u308C\u6625\u306B\u307E\u3068\u3081\u3066\u3084\u3063\u305F\u5974\u3060\uFF09",
  "id" : 199435114709663744,
  "created_at" : "2012-05-07 09:46:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199434984589770752",
  "text" : "\u5206\u5272S\u22BF\u3068\uFF53\u22BF\u3092\u5404\u3005\u306E\u533A\u9593\u306Esup\u3068inf\u3067\u6301\u3063\u3066\u304F\u308B #s2s_seminar",
  "id" : 199434984589770752,
  "created_at" : "2012-05-07 09:46:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199434542799527938",
  "text" : "@kotorin_z \u50D5\u3082\u521D\u3081\u3066\u51FA\u5E2D\u3057\u3066\u308B\u3093\u3067\u3059\u3051\u3069\u306D\uFF57",
  "id" : 199434542799527938,
  "created_at" : "2012-05-07 09:44:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199434266420064256",
  "geo" : { },
  "id_str" : "199434457881645056",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k \u5165\u9580\u7684\u306A\u8B1B\u7FA9\u3067\u3059\u306D\u30FC\u3002\u81EA\u4E3B\u30BC\u30DF\u30B5\u30FC\u30AF\u30EB\u307F\u305F\u3044\u306A\u306E\u3067\u5148\u8F29\u304C\u3084\u3063\u3066\u304F\u308C\u3066\u307E\u3059\u3002",
  "id" : 199434457881645056,
  "in_reply_to_status_id" : 199434266420064256,
  "created_at" : "2012-05-07 09:44:14 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199434311873732608",
  "text" : "\u30EA\u30FC\u30DE\u30F3\u7A4D\u5206\u306E\u53B3\u5BC6\u306A\u8AAC\u660E \u5206\u5272\u306E\u8A71 #s2s_seminar",
  "id" : 199434311873732608,
  "created_at" : "2012-05-07 09:43:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199434186526961665",
  "text" : "@kotorin_z S2S\u306E\u4F8B\u4F1A\u8B1B\u7FA9\u3067\u3059",
  "id" : 199434186526961665,
  "created_at" : "2012-05-07 09:43:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199434121045475328",
  "text" : "\u3053\u306E\u5B9A\u7FA9\u306F\u5727\u5012\u7684\u66D6\u6627\u3060\u304B\u3089\u306A\u3093\u3068\u304B\u3057\u3088\u3046 #s2s_seminar",
  "id" : 199434121045475328,
  "created_at" : "2012-05-07 09:42:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199434041420816384",
  "text" : "\u30EA\u30FC\u30DE\u30F3\u7A4D\u5206\u306F\u9577\u65B9\u5F62\u3067\u306E\u8FD1\u4F3C\u3067\u7A4D\u5206\u3057\u3066\u3044\u305F #s2s_seminar",
  "id" : 199434041420816384,
  "created_at" : "2012-05-07 09:42:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199433881324228609",
  "text" : "\u30C7\u30A3\u30EA\u30AF\u30EC\u95A2\u6570 #s2s_seminar",
  "id" : 199433881324228609,
  "created_at" : "2012-05-07 09:41:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 34, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199433815595290624",
  "text" : "\uFF46\uFF08\uFF58\uFF09\uFF1D\uFF11\uFF08\uFF58\u304C\u6709\u7406\u6570\uFF09\n    \uFF10\uFF08\uFF58\u306F\u7121\u7406\u6570\uFF09 \u3092\u7A4D\u5206\u3057\u305F\u3044 #s2s_seminar",
  "id" : 199433815595290624,
  "created_at" : "2012-05-07 09:41:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199433484756983808",
  "text" : "\u6559\u8077\u53D6\u3063\u305F\u304B\u3089\u304D\u3063\u3068\u4E0A\u624B\u3060\u308D\u3046\uFF08 #s2s_seminar",
  "id" : 199433484756983808,
  "created_at" : "2012-05-07 09:40:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199433409481801729",
  "text" : "\u5C0F\u91CE\u5BFA\u5148\u8F29\u306E\u8B1B\u7FA9\u30FC #s2s_seminar",
  "id" : 199433409481801729,
  "created_at" : "2012-05-07 09:40:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 6, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199433256842698752",
  "text" : "\u3067\u8B1B\u7FA9\u958B\u59CB #s2s_seminar",
  "id" : 199433256842698752,
  "created_at" : "2012-05-07 09:39:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199432940185321474",
  "text" : "\uFF08\u3067\u3082\u50D5\u306F\u6C34\u66DC\u65E5\u306F\u5FD9\u3057\u3044\u3075\u3075\u3075\uFF09",
  "id" : 199432940185321474,
  "created_at" : "2012-05-07 09:38:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199432873693028352",
  "text" : "\u6C34\u66DC\u3082\u8B1B\u7FA9\u3084\u3063\u305F\u3089\u307F\u3093\u306A\u767A\u8868\u3067\u304D\u308B\u304B\u3082 #s2s_seminar",
  "id" : 199432873693028352,
  "created_at" : "2012-05-07 09:37:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199432454891778049",
  "text" : "\u4E0A\u56DE\u751F\u306E\u8A71\u3092\u805E\u3044\u3066\u767A\u8868\u306E\u65B9\u6CD5\u3068\u304B\u3092\u5B66\u307C\u3046 #s2s_seminar",
  "id" : 199432454891778049,
  "created_at" : "2012-05-07 09:36:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199432286184292352",
  "text" : "\u307F\u3093\u306A\u767A\u8868\u3057\u3088\u3046\u305C\uFF01\u307F\u305F\u3044\u306A\u30E2\u30C1\u30D9\u30FC\u30B7\u30E7\u30F3 #s2s_seminar",
  "id" : 199432286184292352,
  "created_at" : "2012-05-07 09:35:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199431924803047426",
  "text" : "\u5206\u91CE\u6A2A\u65AD\u7684\u306B\u3044\u308D\u3044\u308D\u3084\u308B #s2s_seminar",
  "id" : 199431924803047426,
  "created_at" : "2012-05-07 09:34:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199431768410042368",
  "text" : "\u53BB\u5E74\u306E\u4F8B\u4F1A\u306F\u307B\u3068\u3093\u3069\u6570\u5B66\u30FB\u7269\u7406 #s2s_seminar",
  "id" : 199431768410042368,
  "created_at" : "2012-05-07 09:33:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199431658708021248",
  "text" : "\u6628\u5E74\u304B\u3089\u6708\u66DC\u306B\u3084\u3063\u3066\u308B\u8B1B\u7FA9\uFF08\u9069\u5F53\u306A\u4EBA\u3084\u308A\u305F\u3044\u4EBA\u3092\u6307\u540D\u3057\u3066\u3084\u3063\u3066\u3082\u3089\u3046\uFF09 #s2s_seminar",
  "id" : 199431658708021248,
  "created_at" : "2012-05-07 09:33:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199431356424536064",
  "text" : "\u4F8B\u4F1A\u8B1B\u7FA9\u3068\u306F\u4F55\u306A\u306E\u304B #s2s_seminar",
  "id" : 199431356424536064,
  "created_at" : "2012-05-07 09:31:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199430873362350080",
  "text" : "\uFF15\/\uFF17 \uFF33\uFF12\uFF33\u6708\u66DC\u4F8B\u4F1A \u8B1B\u7FA9 \u300C\u30EB\u30D9\u30FC\u30B0\u7A4D\u5206\u6E2C\u5EA6\u8AD6\u5165\u9580\u300D \uFF42\uFF59\u5C0F\u91CE\u5BFA\u5149 #s2s_seminar",
  "id" : 199430873362350080,
  "created_at" : "2012-05-07 09:30:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\uFF10\u306F\u81EA\u7136\u6570",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199430134443409408",
  "text" : "\u30D3\u30E9\u306E\u679A\u6570\u306F\u81EA\u7136\u6570 #\uFF10\u306F\u81EA\u7136\u6570",
  "id" : 199430134443409408,
  "created_at" : "2012-05-07 09:27:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199430021637607424",
  "text" : "RT @sa6v6co: \u4ECA\u5E74\u914D\u30D3\u30E9\u5C11\u306A\u3044\u3088\u306D\u3068\u79C1\u306B\u8A00\u308F\u308C\u3066\u3082\u79C1\u306F\u30D3\u30E9\u8CAC\u306A\u306E\u3067\u3069\u3046\u306B\u3082\u3067\u304D\u307E\u305B\u3093\uFF01\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199429925013426176",
    "text" : "\u4ECA\u5E74\u914D\u30D3\u30E9\u5C11\u306A\u3044\u3088\u306D\u3068\u79C1\u306B\u8A00\u308F\u308C\u3066\u3082\u79C1\u306F\u30D3\u30E9\u8CAC\u306A\u306E\u3067\u3069\u3046\u306B\u3082\u3067\u304D\u307E\u305B\u3093\uFF01\uFF01\uFF01",
    "id" : 199429925013426176,
    "created_at" : "2012-05-07 09:26:14 +0000",
    "user" : {
      "name" : "\u7B39\u5C71",
      "screen_name" : "sa6x6co",
      "protected" : true,
      "id_str" : "343205342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576269550359990273\/bGxUJpkZ_normal.png",
      "id" : 343205342,
      "verified" : false
    }
  },
  "id" : 199430021637607424,
  "created_at" : "2012-05-07 09:26:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30BC\u30DF\u30CA\u30FC\u30EB\u3068\u306F\u4F55\u3060\u3063\u305F\u306E\u304B",
      "indices" : [ 5, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199429764560338944",
  "text" : "\u81EA\u7FD2\u30BC\u30DF #\u30BC\u30DF\u30CA\u30FC\u30EB\u3068\u306F\u4F55\u3060\u3063\u305F\u306E\u304B",
  "id" : 199429764560338944,
  "created_at" : "2012-05-07 09:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199428634149257216",
  "text" : "\u5B9F\u6CC1\u306F\u3059\u3046\u304C\u304F\u5F92\u306E\u96C6\u3044\u4EE5\u6765\u304B\u30FC\uFF08",
  "id" : 199428634149257216,
  "created_at" : "2012-05-07 09:21:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_seminar",
      "indices" : [ 6, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199427788145557504",
  "text" : "\u5727\u5012\u7684\u5F85\u6A5F #s2s_seminar",
  "id" : 199427788145557504,
  "created_at" : "2012-05-07 09:17:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199427183951888384",
  "text" : "@i_horse \u3055\u304B\u306A\u90B8\u306B19\uFF1A30\u304F\u3089\u3044\u306B\u96C6\u5408\u3092\u4E88\u5B9A\u3067\u3002\u307E\u305F\u30EA\u30D7\u30E9\u30A4\u3092\u98DB\u3070\u3057\u307E\u3059\u3002",
  "id" : 199427183951888384,
  "created_at" : "2012-05-07 09:15:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199426981241163776",
  "text" : "S2S\u306E\u8B1B\u7FA9\u5F85\u6A5F",
  "id" : 199426981241163776,
  "created_at" : "2012-05-07 09:14:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199330873601044481",
  "geo" : { },
  "id_str" : "199332166646239234",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3069\u305E\u30FC",
  "id" : 199332166646239234,
  "in_reply_to_status_id" : 199330873601044481,
  "created_at" : "2012-05-07 02:57:46 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5727\u5012\u7684\u9583\u304D",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199330349443067905",
  "text" : "\u3044\u307E\u3059\u3050\uFF13\u9650\u306E\u6559\u5BA4\u306B\u884C\u3051\u3070\uFF11\u6642\u9593\u5BDD\u308C\u308B\uFF01 #\u5727\u5012\u7684\u9583\u304D",
  "id" : 199330349443067905,
  "created_at" : "2012-05-07 02:50:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5168\u65E5\u672C\u3082\u3046\u7720\u308A\u305F\u3044\u5354\u4F1A",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199329210454646785",
  "text" : "#\u5168\u65E5\u672C\u3082\u3046\u7720\u308A\u305F\u3044\u5354\u4F1A",
  "id" : 199329210454646785,
  "created_at" : "2012-05-07 02:46:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199326004794241024",
  "text" : "\u5727\u5012\u7684\u7720\u6C17\u7720\u6C17(^^)(^^)(^^)(^^)(^^)",
  "id" : 199326004794241024,
  "created_at" : "2012-05-07 02:33:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199319208012685312",
  "text" : "\u7720\u6C17\u3092\u5F15\u304D\u53D7\u3051\u308B\u30B9\u30AD\u30EB\u2192\u8AB0\u304C\u9069\u5F53\u306A\u30B9\u30AD\u30EB\u540D\u3092\u8003\u3048\u3066\u3042\u3052\u3066\u304F\u3060\u3055\u3044",
  "id" : 199319208012685312,
  "created_at" : "2012-05-07 02:06:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199318851773677568",
  "text" : "\u3048\u3001\u3061\u3047\u308A\u3043\u3055\u3093\u304C\u7720\u6C17\u5F15\u304D\u53D7\u3051\u3066\u304F\u308C\u308B\u306E\uFF1F",
  "id" : 199318851773677568,
  "created_at" : "2012-05-07 02:04:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199318526920622080",
  "text" : "\u5727\u5012\u7684\u7720\u6C17",
  "id" : 199318526920622080,
  "created_at" : "2012-05-07 02:03:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199304623117447168",
  "text" : "\u6700\u901F\u3045",
  "id" : 199304623117447168,
  "created_at" : "2012-05-07 01:08:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199304593375637504",
  "text" : "7\u5206\u3067\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u308C\u305F",
  "id" : 199304593375637504,
  "created_at" : "2012-05-07 01:08:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199106333604188160",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 199106333604188160,
  "created_at" : "2012-05-06 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199084938509828096",
  "geo" : { },
  "id_str" : "199089621014032385",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3048\u3093\u3069\u90B8\u3067\u3055\u304B\u306A\u304C\u9B5A\u3092\u98DF\u3079\u308B\u8A71\u3067\u3057\u305F",
  "id" : 199089621014032385,
  "in_reply_to_status_id" : 199084938509828096,
  "created_at" : "2012-05-06 10:53:59 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199075349185830912",
  "geo" : { },
  "id_str" : "199075417452331009",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u306F\u3044",
  "id" : 199075417452331009,
  "in_reply_to_status_id" : 199075349185830912,
  "created_at" : "2012-05-06 09:57:32 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199070560293109760",
  "geo" : { },
  "id_str" : "199071337082404864",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u7740\u3044\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u3092\uFF57\uFF57\uFF57\uFF57",
  "id" : 199071337082404864,
  "in_reply_to_status_id" : 199070560293109760,
  "created_at" : "2012-05-06 09:41:19 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199069471183339520",
  "geo" : { },
  "id_str" : "199070482669121536",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku 18\u6642\u96C6\u5408\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B",
  "id" : 199070482669121536,
  "in_reply_to_status_id" : 199069471183339520,
  "created_at" : "2012-05-06 09:37:56 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96A3\u306E\u3068\u306A\u308A",
      "screen_name" : "tonar_no_tonari",
      "indices" : [ 0, 16 ],
      "id_str" : "262045935",
      "id" : 262045935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199069039534948353",
  "geo" : { },
  "id_str" : "199069177946976257",
  "in_reply_to_user_id" : 262045935,
  "text" : "@tonar_no_tonari \u4EBA\u304C\u305F\u304F\u3055\u3093\u96C6\u307E\u308C\u308B\u3063\u3066\u3093\u306713\u65E5\u306E\u65E5\u66DC\u65E5\u306B\u3057\u3088\u3046\u304B\u3068\u3002",
  "id" : 199069177946976257,
  "in_reply_to_status_id" : 199069039534948353,
  "created_at" : "2012-05-06 09:32:45 +0000",
  "in_reply_to_screen_name" : "tonar_no_tonari",
  "in_reply_to_user_id_str" : "262045935",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96A3\u306E\u3068\u306A\u308A",
      "screen_name" : "tonar_no_tonari",
      "indices" : [ 0, 16 ],
      "id_str" : "262045935",
      "id" : 262045935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199068537409638401",
  "geo" : { },
  "id_str" : "199068616937836544",
  "in_reply_to_user_id" : 262045935,
  "text" : "@tonar_no_tonari \u3044\u3084\u3001\u8A08\u753B\u901A\u308A\u884C\u3063\u3066\u3088\u304B\u3063\u305F\u306A\u3041\u3068",
  "id" : 199068616937836544,
  "in_reply_to_status_id" : 199068537409638401,
  "created_at" : "2012-05-06 09:30:31 +0000",
  "in_reply_to_screen_name" : "tonar_no_tonari",
  "in_reply_to_user_id_str" : "262045935",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96A3\u306E\u3068\u306A\u308A",
      "screen_name" : "tonar_no_tonari",
      "indices" : [ 0, 16 ],
      "id_str" : "262045935",
      "id" : 262045935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199065969581244417",
  "geo" : { },
  "id_str" : "199066061570703360",
  "in_reply_to_user_id" : 262045935,
  "text" : "@tonar_no_tonari \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3075\u3075\u3075\u3075",
  "id" : 199066061570703360,
  "in_reply_to_status_id" : 199065969581244417,
  "created_at" : "2012-05-06 09:20:22 +0000",
  "in_reply_to_screen_name" : "tonar_no_tonari",
  "in_reply_to_user_id_str" : "262045935",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199061456367534080",
  "text" : "\u8A08 \u753B \u901A \u308A \uFF08\u3054\u98EF\u304C\u708A\u3051\u307E\u3057\u305F\uFF09",
  "id" : 199061456367534080,
  "created_at" : "2012-05-06 09:02:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199039810176942081",
  "geo" : { },
  "id_str" : "199039971431170048",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u5915\u65B9\u304B\u3089\u5225\u306E\u7D04\u675F\u304C\u3042\u3063\u305F\u306E\u3067\u30DE\u30B9\u30BF\u30FC\u304C\u6765\u3066\u3061\u3087\u3063\u3068\u3057\u305F\u3089\u96E2\u8131\u3057\u3061\u3083\u3044\u307E\u3057\u305F",
  "id" : 199039971431170048,
  "in_reply_to_status_id" : 199039810176942081,
  "created_at" : "2012-05-06 07:36:41 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199038687676346369",
  "text" : "\u5E30\u5B85",
  "id" : 199038687676346369,
  "created_at" : "2012-05-06 07:31:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/mb4sqjp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30A4\u30EB\u30D5\u30A9\u30FC\u30B9\u30AF\u30A8\u30A2\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/8Ejno9A2",
      "expanded_url" : "http:\/\/mb4sq.jp\/J8yhCE",
      "display_url" : "mb4sq.jp\/J8yhCE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "199004067811426305",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ http:\/\/t.co\/8Ejno9A2",
  "id" : 199004067811426305,
  "created_at" : "2012-05-06 05:14:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198959068294037504",
  "geo" : { },
  "id_str" : "198973610059235329",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u69CB\u3044\u307E\u305B\u3093\u3088\u30FC",
  "id" : 198973610059235329,
  "in_reply_to_status_id" : 198959068294037504,
  "created_at" : "2012-05-06 03:13:00 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198948053850402818",
  "geo" : { },
  "id_str" : "198948337804783616",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 13\u65E5\u3067\u3059\u306D\u3001\u305F\u3076\u3093\u3002\u307E\u305F\u9023\u7D61\u3057\u307E\u3059\u3002",
  "id" : 198948337804783616,
  "in_reply_to_status_id" : 198948053850402818,
  "created_at" : "2012-05-06 01:32:34 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron kul",
      "screen_name" : "kul_Ron",
      "indices" : [ 2, 10 ],
      "id_str" : "2909728068",
      "id" : 2909728068
    }, {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 21, 29 ],
      "id_str" : "57847957",
      "id" : 57847957
    }, {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 30, 39 ],
      "id_str" : "407863488",
      "id" : 407863488
    }, {
      "name" : "\u63D0\u7763\u306F\u3057\u3051\u3093*\u30D0\u30B1\u30C4\u5099\u84C4",
      "screen_name" : "hashiken716",
      "indices" : [ 40, 52 ],
      "id_str" : "100018219",
      "id" : 100018219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198947887529463808",
  "text" : ". @kuL_Ron @ispamgis @ninetan @phyzyuya @hashiken716 \u304A\u3084\u3059\u307F\u3042\u308A\u30FC\u3067\u3057\u305F",
  "id" : 198947887529463808,
  "created_at" : "2012-05-06 01:30:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198942223092551682",
  "text" : "\u8D77\u5E8A",
  "id" : 198942223092551682,
  "created_at" : "2012-05-06 01:08:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198811591427366912",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 198811591427366912,
  "created_at" : "2012-05-05 16:29:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198811570476810240",
  "text" : "\u76EE\u304C\u30DC\u30FC\u3063\u3068\u3057\u3066\u304D\u305F\u3057\u7247\u3065\u3051\u3082\u305D\u3053\u305D\u3053\u4E00\u6BB5\u843D\u7740\u3044\u305F\u3088\u3046\u306A\u611F\u3058\u306B\u306A\u3063\u305F\u3068\u8A00\u3048\u306A\u304F\u3082\u306A\u3044\u3057\u5E03\u56E3\u306B\u884C\u304F\u304B",
  "id" : 198811570476810240,
  "created_at" : "2012-05-05 16:29:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198809422540185600",
  "text" : "\u7406\u60F3\u8AD6\u5165\u9580\n\u73FE\u5B9F\u9589\u9580",
  "id" : 198809422540185600,
  "created_at" : "2012-05-05 16:20:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198807176188403715",
  "geo" : { },
  "id_str" : "198807346238062592",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u3042\u3001\u77E5\u3063\u3066\u3066\u826F\u304B\u3063\u305F\u3002\u3055\u3055\u3084\u304B\u306A\u5E78\u305B\u3002",
  "id" : 198807346238062592,
  "in_reply_to_status_id" : 198807176188403715,
  "created_at" : "2012-05-05 16:12:19 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4F1D\u308F\u308A\u306B\u304F\u3044\u30CD\u30BF",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198806590046998528",
  "geo" : { },
  "id_str" : "198806824407937024",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u672A\u6765\u3092\u62C5\u4FDD\u306B\u8CA8\u5E63\u3092\u767A\u884C\u3059\u308B\u9280\u884C\u304C\u3054\u306B\u3087\u3054\u306B\u3087 #\u4F1D\u308F\u308A\u306B\u304F\u3044\u30CD\u30BF",
  "id" : 198806824407937024,
  "in_reply_to_status_id" : 198806590046998528,
  "created_at" : "2012-05-05 16:10:15 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198806597651275781",
  "text" : "\u673A\u306E\u4E0A\u3060\u3051\u7DBA\u9E97\u306B\u3057\u3066\u5BDD\u3088\u3046",
  "id" : 198806597651275781,
  "created_at" : "2012-05-05 16:09:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198806090559918081",
  "text" : "\u3082\u30461\u6642\u56DE\u3063\u3066\u3093\u306E\u304B",
  "id" : 198806090559918081,
  "created_at" : "2012-05-05 16:07:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198805256895873024",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u305F\u304F\u3055\u3093\u670D\u3092\u6301\u3063\u3066\u3044\u308B\u3001\u3068\u5B63\u7BC0\u306E\u4EE3\u308F\u308A\u76EE\u6BCE\u306B\u601D\u3063\u3066\u3044\u308B\u6C17\u304C\u3059\u308B",
  "id" : 198805256895873024,
  "created_at" : "2012-05-05 16:04:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198804032930848771",
  "geo" : { },
  "id_str" : "198804135091507201",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u3054\u3081\u3093\u306A\u3055\u3044\u307E\u305F\u4ECA\u5EA6\u3067\uFF08\u3067\u3082\u7D76\u5BFE\u3084\u308A\u307E\u3057\u3087\u3046\uFF09",
  "id" : 198804135091507201,
  "in_reply_to_status_id" : 198804032930848771,
  "created_at" : "2012-05-05 15:59:34 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198801987465261057",
  "geo" : { },
  "id_str" : "198803834133417984",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u3042",
  "id" : 198803834133417984,
  "in_reply_to_status_id" : 198801987465261057,
  "created_at" : "2012-05-05 15:58:22 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198801648833937408",
  "text" : "\u4F55\u306F\u3068\u3082\u3042\u308C\u8863\u66FF\u3048\u304C\u7D42\u308F\u3089\u306A\u3044\u3068\u7720\u308C\u306C",
  "id" : 198801648833937408,
  "created_at" : "2012-05-05 15:49:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron kul",
      "screen_name" : "kul_Ron",
      "indices" : [ 2, 10 ],
      "id_str" : "2909728068",
      "id" : 2909728068
    }, {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 11, 23 ],
      "id_str" : "131048355",
      "id" : 131048355
    }, {
      "name" : "\u4E32\u7530 \u62D3\u7F8E",
      "screen_name" : "prelude_types",
      "indices" : [ 24, 38 ],
      "id_str" : "1368266268",
      "id" : 1368266268
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 39, 48 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u306A\u3063\u3064\u304D\u306E\u307F",
      "screen_name" : "downy_821",
      "indices" : [ 49, 59 ],
      "id_str" : "287541933",
      "id" : 287541933
    }, {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 70, 80 ],
      "id_str" : "441021193",
      "id" : 441021193
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 81, 91 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198801596631617536",
  "text" : ". @kuL_Ron @MaryMimiary @Prelude_TypeS @nisehorn @downy_821 @ispamgis @piano2683 @Lisa_math \u304A\u304B\u3042\u308A\u3057\u305F\u30FC",
  "id" : 198801596631617536,
  "created_at" : "2012-05-05 15:49:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198794058724941824",
  "text" : "\u8863\u66FF\u3048",
  "id" : 198794058724941824,
  "created_at" : "2012-05-05 15:19:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198791238256836608",
  "text" : "\u3074\u3088\u3074\u3088",
  "id" : 198791238256836608,
  "created_at" : "2012-05-05 15:08:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198789283971219457",
  "text" : "\u56DB\u6642\u3055\u3093\u66B4\u8D70\u6C17\u5473\u306A\u6C17\u304C\u3059\u308B\u306E\u3060\u3051\u308C\u3069\u5927\u4E08\u592B\u3060\u308D\u3046\u304B",
  "id" : 198789283971219457,
  "created_at" : "2012-05-05 15:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198788700816158720",
  "text" : "\u3046\u30FC\u308F\u30FC\u2026",
  "id" : 198788700816158720,
  "created_at" : "2012-05-05 14:58:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198784615056543745",
  "text" : "@Italiasan \u8FD4\u4E8B\u9045\u308C\u3066\u3054\u3081\u3093\u306A\u3055\u3044\u300220\u65E5\u610F\u5916\u4E0D\u53EF\u306A\u306E\u3067\u30C0\u30E1\u306A\u3089\u6C17\u306B\u306A\u3055\u3089\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u306A\u3002",
  "id" : 198784615056543745,
  "created_at" : "2012-05-05 14:42:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "sm6899470",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/t1EaBLsQ",
      "expanded_url" : "http:\/\/nico.ms\/sm6899470",
      "display_url" : "nico.ms\/sm6899470"
    } ]
  },
  "geo" : { },
  "id_str" : "198782540239220736",
  "text" : "\u6383\u9664\u305D\u3063\u3061\u306C\u3051\u3067\u58F0\u51FA\u3057\u3066\u7B11\u3063\u305F \u843D\u8A9E \u300C\u6642\u305D\u3070\u300D\u3000\u67F3\u5BB6\u55AC\u592A\u90CE   \u526F\u984C\u300C\u30B3\u30ED\u30C3\u30B1\u305D\u3070\u300D (33:17) #nicovideo #sm6899470 http:\/\/t.co\/t1EaBLsQ",
  "id" : 198782540239220736,
  "created_at" : "2012-05-05 14:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6DF1\u591C\u306E\u6383\u9664",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198779659326996481",
  "text" : "#\u6DF1\u591C\u306E\u6383\u9664",
  "id" : 198779659326996481,
  "created_at" : "2012-05-05 14:22:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 43, 53 ]
    }, {
      "text" : "sm8424563",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/NbKrAzJ2",
      "expanded_url" : "http:\/\/nico.ms\/sm8424563",
      "display_url" : "nico.ms\/sm8424563"
    } ]
  },
  "geo" : { },
  "id_str" : "198779559502548992",
  "text" : "\u3010\u60AA\u9B54\u3068\u3011Devil May Cry1-4\u8A70\u3081\u5408\u308F\u305B\u3010\u4F5C\u696D\u3057\u3088\u3046\u3011 (120:05) #nicovideo #sm8424563 http:\/\/t.co\/NbKrAzJ2",
  "id" : 198779559502548992,
  "created_at" : "2012-05-05 14:21:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3060\u304B\u3089\u306A\u3093\u3060",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198775714319843328",
  "text" : "\u30A8\u30B4\u30B5\u30FC\u30C1\u3067Grothendieck\u306E\u6587\u5B57\u5217\u306B\u3048\u3093\u3069\u304C\u3044\u308B\u3053\u3068\u304C\u5206\u304B\u3063\u305F #\u3060\u304B\u3089\u306A\u3093\u3060",
  "id" : 198775714319843328,
  "created_at" : "2012-05-05 14:06:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3068\u3063\u3066\u3064\u3051\u305F\u3088\u3046\u306A\u30D5\u30A9\u30ED\u30FC",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198772414585372672",
  "text" : "\u9ED9\u3063\u3066\u3044\u3066\u3082\u6C17\u3092\u4F7F\u308F\u306A\u3044\u306E\u306F\u7D20\u6575\u306A\u95A2\u4FC2\u3067\u3059\u3088\u306D #\u3068\u3063\u3066\u3064\u3051\u305F\u3088\u3046\u306A\u30D5\u30A9\u30ED\u30FC",
  "id" : 198772414585372672,
  "created_at" : "2012-05-05 13:53:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198772039757205504",
  "text" : "\u300C\u5BC4\u3063\u3066\u3063\u3066\u3082\u9ED9\u3089\u308C\u308B\u304B\u3089\u5408\u30B3\u30F3\u306A\u3093\u3066\u3057\u305F\u3053\u3068\u306A\u3044\u308F\u2026\u300D",
  "id" : 198772039757205504,
  "created_at" : "2012-05-05 13:52:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198771431021092864",
  "text" : "\u5E30\u5B85\u30A1\uFF01",
  "id" : 198771431021092864,
  "created_at" : "2012-05-05 13:49:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198771413639892993",
  "text" : "\u305D\u3057\u3066\u3048\u3093\u3069\u306F\u3044\u3048\u306B\u5230\u7740\u3057\u305F\u306E\u3067\u3059",
  "id" : 198771413639892993,
  "created_at" : "2012-05-05 13:49:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3054\u3081\u3093\u306A\u3055\u3044",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198770680072896512",
  "text" : "\u3046\u3063\u304B\u308A\u8133\u3063\u3066\u8A00\u3063\u3061\u3083\u3063\u305F\u304C\u8133\u306E\u4EBA\u3068\u8A00\u3046\u3079\u304D\u3060\u3063\u305F #\u3054\u3081\u3093\u306A\u3055\u3044",
  "id" : 198770680072896512,
  "created_at" : "2012-05-05 13:46:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 10, 26 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198770397846585344",
  "text" : "\u533B\u5B66\u90E8\u306E\u8133\u2026 RT @Jelly_in_a_tank: @YohjiGreat \u5973\uFF11\uFF08\u56DB\u6642\u3055\u3093\uFF09\u7537\uFF11\uFF10\uFF08\u7406\u5B66\u90E8\uFF9C\uFF97\uFF9C\uFF97\uFF09",
  "id" : 198770397846585344,
  "created_at" : "2012-05-05 13:45:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198769929321852928",
  "geo" : { },
  "id_str" : "198770169991020544",
  "in_reply_to_user_id" : 184844182,
  "text" : "@0_uda \u3042\u30FCS\u541B\u304C\u9023\u7D61\u5148\u77E5\u308A\u305F\u3044\u3089\u3057\u3044\u306E\u3067\u3059\u304C\u6559\u3048\u3061\u3083\u3063\u3066\u3044\u3044\u3067\u3057\u3087\u3046\u304B",
  "id" : 198770169991020544,
  "in_reply_to_status_id" : 198769929321852928,
  "created_at" : "2012-05-05 13:44:36 +0000",
  "in_reply_to_screen_name" : "0_uda",
  "in_reply_to_user_id_str" : "184844182",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198769863966212096",
  "text" : "\u306C\u308B\u306C\u308B\u6B69\u3044\u3066\u3044\u308B",
  "id" : 198769863966212096,
  "created_at" : "2012-05-05 13:43:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198769799126450177",
  "text" : "\u3082\u3046\u3061\u3087\u3044\u3067\u304A\u5BB6",
  "id" : 198769799126450177,
  "created_at" : "2012-05-05 13:43:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198769135142973440",
  "text" : "\u666E\u901A\u306Bzero order\u304B\u3068",
  "id" : 198769135142973440,
  "created_at" : "2012-05-05 13:40:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3067\u5375\uFF08\u9023\u7D9A\uFF09",
      "screen_name" : "takayukib",
      "indices" : [ 3, 13 ],
      "id_str" : "18113162",
      "id" : 18113162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "0\u306F\u81EA\u7136\u6570",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/iTJGgpGg",
      "expanded_url" : "http:\/\/twitpic.com\/9hkqpw",
      "display_url" : "twitpic.com\/9hkqpw"
    } ]
  },
  "geo" : { },
  "id_str" : "198768992339492864",
  "text" : "RT @takayukib: 0\u968E\u306E\u5199\u771F\u3042\u3063\u305F http:\/\/t.co\/iTJGgpGg #0\u306F\u81EA\u7136\u6570",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "0\u306F\u81EA\u7136\u6570",
        "indices" : [ 30, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 9, 29 ],
        "url" : "http:\/\/t.co\/iTJGgpGg",
        "expanded_url" : "http:\/\/twitpic.com\/9hkqpw",
        "display_url" : "twitpic.com\/9hkqpw"
      } ]
    },
    "geo" : { },
    "id_str" : "198740821502205953",
    "text" : "0\u968E\u306E\u5199\u771F\u3042\u3063\u305F http:\/\/t.co\/iTJGgpGg #0\u306F\u81EA\u7136\u6570",
    "id" : 198740821502205953,
    "created_at" : "2012-05-05 11:47:58 +0000",
    "user" : {
      "name" : "\u3086\u3067\u5375\uFF08\u9023\u7D9A\uFF09",
      "screen_name" : "takayukib",
      "protected" : false,
      "id_str" : "18113162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512086970223169536\/AovD4Xo5_normal.jpeg",
      "id" : 18113162,
      "verified" : false
    }
  },
  "id" : 198768992339492864,
  "created_at" : "2012-05-05 13:39:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198768645332144128",
  "text" : "\u7720\u308C\u308B\u4FEE\u58EB\u3068\u7720\u308C\u306A\u3044\u535A\u58EB",
  "id" : 198768645332144128,
  "created_at" : "2012-05-05 13:38:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3061\u3087\u3046",
      "screen_name" : "ichyo",
      "indices" : [ 3, 9 ],
      "id_str" : "64091783",
      "id" : 64091783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198768544584957953",
  "text" : "RT @ichyo: \u7720\u308C\u308B\u7345\u5B50\u3068\u7720\u308C\u306A\u3044\u7345\u5B50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198768347943403520",
    "text" : "\u7720\u308C\u308B\u7345\u5B50\u3068\u7720\u308C\u306A\u3044\u7345\u5B50",
    "id" : 198768347943403520,
    "created_at" : "2012-05-05 13:37:21 +0000",
    "user" : {
      "name" : "\u3044\u3061\u3087\u3046",
      "screen_name" : "ichyo",
      "protected" : false,
      "id_str" : "64091783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2257450221\/Donut_120x120_normal.gif",
      "id" : 64091783,
      "verified" : false
    }
  },
  "id" : 198768544584957953,
  "created_at" : "2012-05-05 13:38:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198768374367526912",
  "text" : "\u306F\u3001\u5EC3\u4EBA\u306A\u3093\u3066\u8A00\u3063\u3066\u306A\u3044\u3067\u3059\u3088(",
  "id" : 198768374367526912,
  "created_at" : "2012-05-05 13:37:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198768271938433027",
  "text" : "\u3042\u308B\u7A0B\u5EA6\u4EE5\u4E0A\u30C4\u30A4\u30C3\u30BF\u30FC\u306B\u5165\u308C\u8FBC\u3093\u3067\u308B\u4EBA\u306F\u3042\u307E\u308ATV\u898B\u306A\u3044\u3093\u3058\u3083\u2026",
  "id" : 198768271938433027,
  "created_at" : "2012-05-05 13:37:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30C6\u30EC\u30D3\u7121\u3044\u30AF\u30E9\u30B9\u30BF",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198767962344275969",
  "text" : "\u5FC5\u8981\u6027\u3092\u611F\u3058\u306A\u3044\u3093\u3060\u3088\u306A\u30FC #\u30C6\u30EC\u30D3\u7121\u3044\u30AF\u30E9\u30B9\u30BF",
  "id" : 198767962344275969,
  "created_at" : "2012-05-05 13:35:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5730\u30C7\u30B8\u30AB\u306E\u722A\u8DE1",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "\u30C6\u30EC\u30D3\u7121\u3044\u30AF\u30E9\u30B9\u30BF",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198767681099399168",
  "text" : "#\u5730\u30C7\u30B8\u30AB\u306E\u722A\u8DE1 #\u30C6\u30EC\u30D3\u7121\u3044\u30AF\u30E9\u30B9\u30BF",
  "id" : 198767681099399168,
  "created_at" : "2012-05-05 13:34:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198766572448395265",
  "geo" : { },
  "id_str" : "198767154898804736",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows @9110alice \u30C6\u30EC\u30D3\u306A\u3044\u30AF\u30E9\u30B9\u30BF",
  "id" : 198767154898804736,
  "in_reply_to_status_id" : 198766572448395265,
  "created_at" : "2012-05-05 13:32:37 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198765703371833344",
  "text" : "\u3068\u7406\u3042\u3048\u305A\u7406\u5B66\u90E8\u3060\u3088\u306A",
  "id" : 198765703371833344,
  "created_at" : "2012-05-05 13:26:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198765355873734656",
  "text" : "\u4E5D\u5927\u7406\u5B66\u90E8\u3075\u3075\u3075",
  "id" : 198765355873734656,
  "created_at" : "2012-05-05 13:25:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198765189573779457",
  "text" : "\u4ECA\u4E00\u56DE\u304B\u3089\u3084\u308A\u76F4\u305B\u305F\u3089\u3075\u3075\u3075",
  "id" : 198765189573779457,
  "created_at" : "2012-05-05 13:24:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198764820462444546",
  "text" : "\u9B45\u529B\u7684\u2026 RT @YohjiGreat: \u56DB\u6642\u3068\u4E00\u7DD2\u306B\u4E00\u56DE\u751F\u304B\u3089\u3084\u308A\u76F4\u305D\u3046\u3002",
  "id" : 198764820462444546,
  "created_at" : "2012-05-05 13:23:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3064\u306A\u307E\u3086",
      "screen_name" : "tunamayu_",
      "indices" : [ 3, 13 ],
      "id_str" : "201678362",
      "id" : 201678362
    }, {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 28, 36 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 51, 67 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 77, 87 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198764645874536448",
  "text" : "RT @tunamayu_: \u3072\u30FC\u307E\u308F\u308A\u306E\u305F\u306D\u30FC RT @i_horse: \u3060\u30FC\u3044\u3059\u304D\u306A\u306E\u306F\u30FC RT @Jelly_in_a_tank: \u30CF\u30E0\u592A\u90CE RT @end313124: tktk\u6B69\u3044\u3066\u5E30\u308B\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Feel like I been rid",
        "screen_name" : "i_horse",
        "indices" : [ 13, 21 ],
        "id_str" : "1689818772",
        "id" : 1689818772
      }, {
        "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
        "screen_name" : "Jelly_in_a_tank",
        "indices" : [ 36, 52 ],
        "id_str" : "138430452",
        "id" : 138430452
      }, {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 62, 72 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198759765034278912",
    "text" : "\u3072\u30FC\u307E\u308F\u308A\u306E\u305F\u306D\u30FC RT @i_horse: \u3060\u30FC\u3044\u3059\u304D\u306A\u306E\u306F\u30FC RT @Jelly_in_a_tank: \u30CF\u30E0\u592A\u90CE RT @end313124: tktk\u6B69\u3044\u3066\u5E30\u308B\u3088",
    "id" : 198759765034278912,
    "created_at" : "2012-05-05 13:03:15 +0000",
    "user" : {
      "name" : "\u3064\u306A\u307E\u3086",
      "screen_name" : "tunamayu_",
      "protected" : false,
      "id_str" : "201678362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499383206429224961\/0Aa4apdI_normal.jpeg",
      "id" : 201678362,
      "verified" : false
    }
  },
  "id" : 198764645874536448,
  "created_at" : "2012-05-05 13:22:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198764564614094848",
  "text" : "\u898B\u3066\u306A\u3044\u3046\u3061\u306B\u4F55\u3053\u308C\uFF57\uFF57\uFF57",
  "id" : 198764564614094848,
  "created_at" : "2012-05-05 13:22:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/mb4sqjp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30A4\u30EB\u30D5\u30A9\u30FC\u30B9\u30AF\u30A8\u30A2\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/i065zrTx",
      "expanded_url" : "http:\/\/mb4sq.jp\/KyvDW8",
      "display_url" : "mb4sq.jp\/KyvDW8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "198764246153183232",
  "text" : "\u5BC4\u3063\u305F\u3060\u3051 (@ \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ)  http:\/\/t.co\/i065zrTx",
  "id" : 198764246153183232,
  "created_at" : "2012-05-05 13:21:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198759432451129344",
  "text" : "tktk\u6B69\u3044\u3066\u5E30\u308B\u3088",
  "id" : 198759432451129344,
  "created_at" : "2012-05-05 13:01:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198743942450266112",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 198743942450266112,
  "created_at" : "2012-05-05 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198725268767125504",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3042\u30FC\u306A\u304B\u306A\u90B8\u306B\u304D\u3061\u3083\u3044\u307E\u3057\u305F",
  "id" : 198725268767125504,
  "created_at" : "2012-05-05 10:46:10 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/kMTWhCir",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=akekasetei",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198657184589025280",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001akekasetei\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002[\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059] http:\/\/t.co\/kMTWhCir #gohantabeyo",
  "id" : 198657184589025280,
  "created_at" : "2012-05-05 06:15:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\uFF10\u306F\u81EA\u7136\u6570",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/GToDyeny",
      "expanded_url" : "http:\/\/twitpic.com\/9hgsr5",
      "display_url" : "twitpic.com\/9hgsr5"
    } ]
  },
  "geo" : { },
  "id_str" : "198651499298033664",
  "text" : "#\uFF10\u306F\u81EA\u7136\u6570 http:\/\/t.co\/GToDyeny",
  "id" : 198651499298033664,
  "created_at" : "2012-05-05 05:53:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198628268172247040",
  "text" : "@Italiasan \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 198628268172247040,
  "created_at" : "2012-05-05 04:20:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198599314082234372",
  "text" : "\u50D5\u306F\u751F\u307E\u308C\u305F\u6642\u304B\u3089\u570F\u8AD6\u3092\u7406\u89E3\u3057\u3066\u306A\u3044 (\u306F\u307E\u308C\u305F\u304B\u3089\u3092\u3057\u3066\u306A\u3044)",
  "id" : 198599314082234372,
  "created_at" : "2012-05-05 02:25:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198597884285960194",
  "geo" : { },
  "id_str" : "198598095943114754",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u304A\u306F\u308A\u30FC\u3093",
  "id" : 198598095943114754,
  "in_reply_to_status_id" : 198597884285960194,
  "created_at" : "2012-05-05 02:20:50 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198597385830674432",
  "text" : "\u3088\u304F\u308F\u304B\u3063\u3066\u306A\u3044\u306E\u306B\u3084\u3081\u3088\u3046\u3084\u3081\u3088\u3046",
  "id" : 198597385830674432,
  "created_at" : "2012-05-05 02:18:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198597314531688448",
  "text" : "\u5C04\u5C04\u308A\u51FA\u308B(push out)",
  "id" : 198597314531688448,
  "created_at" : "2012-05-05 02:17:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198596957822922753",
  "text" : "\u3057\u3083",
  "id" : 198596957822922753,
  "created_at" : "2012-05-05 02:16:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3048\u3093\u3069\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198596210548944896",
  "text" : "RT @koizumi_fifty: #\u3048\u3093\u3069\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u3048\u3093\u3069\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198596110242152451",
    "text" : "#\u3048\u3093\u3069\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0",
    "id" : 198596110242152451,
    "created_at" : "2012-05-05 02:12:57 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 198596210548944896,
  "created_at" : "2012-05-05 02:13:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198596033603846145",
  "text" : "\u8607\u308B\u3074\u3088\u3074\u3088",
  "id" : 198596033603846145,
  "created_at" : "2012-05-05 02:12:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3053\u3068\u308A\u30D5\u30A7\u30CB\u30C3\u30AF\u30B9",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198595959360466944",
  "text" : "#\u3053\u3068\u308A\u30D5\u30A7\u30CB\u30C3\u30AF\u30B9",
  "id" : 198595959360466944,
  "created_at" : "2012-05-05 02:12:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198594977566167040",
  "text" : "\u4E3B\u4EBA\u516C\u306F\u3044\u30FC\u3061\u3083\u3093\u3001\u6247\u306B\u8FD1\u3044\u3088\u306A\u30A4\u30E1\u30FC\u30B8",
  "id" : 198594977566167040,
  "created_at" : "2012-05-05 02:08:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198594741464600577",
  "text" : "\u60B2\u9CF4\u4F1D\u8AAD\u307F\u7D42\u3048\u305F",
  "id" : 198594741464600577,
  "created_at" : "2012-05-05 02:07:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30A2\u30DB",
      "indices" : [ 18, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198590591209193474",
  "text" : "40\u5206\u3082\u65E9\u304F\u5F85\u3061\u5408\u308F\u305B\u5834\u6240\u306B\u7740\u3044\u305F #\u30A2\u30DB",
  "id" : 198590591209193474,
  "created_at" : "2012-05-05 01:51:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruinee",
      "screen_name" : "ruinee_",
      "indices" : [ 3, 11 ],
      "id_str" : "219701596",
      "id" : 219701596
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ruinee_\/status\/198022985775460354\/photo\/1",
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/g1MEY5go",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar-E2zzCMAE5S1d.jpg",
      "id_str" : "198022985779654657",
      "id" : 198022985779654657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar-E2zzCMAE5S1d.jpg",
      "sizes" : [ {
        "h" : 356,
        "resize" : "fit",
        "w" : 351
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g1MEY5go"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198590456349736961",
  "text" : "RT @ruinee_: \u30C1\u30EA\u3068\u30D6\u30E9\u30B8\u30EB\u3063\u3066\u88C5\u5099\u3067\u304D\u305D\u3046 http:\/\/t.co\/g1MEY5go",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ruinee_\/status\/198022985775460354\/photo\/1",
        "indices" : [ 16, 36 ],
        "url" : "http:\/\/t.co\/g1MEY5go",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar-E2zzCMAE5S1d.jpg",
        "id_str" : "198022985779654657",
        "id" : 198022985779654657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar-E2zzCMAE5S1d.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 351
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g1MEY5go"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198022985775460354",
    "text" : "\u30C1\u30EA\u3068\u30D6\u30E9\u30B8\u30EB\u3063\u3066\u88C5\u5099\u3067\u304D\u305D\u3046 http:\/\/t.co\/g1MEY5go",
    "id" : 198022985775460354,
    "created_at" : "2012-05-03 12:15:34 +0000",
    "user" : {
      "name" : "Ruinee",
      "screen_name" : "ruinee_",
      "protected" : false,
      "id_str" : "219701596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2274121784\/vmouh8usse3l2ixhnrqu_normal.jpeg",
      "id" : 219701596,
      "verified" : false
    }
  },
  "id" : 198590456349736961,
  "created_at" : "2012-05-05 01:50:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iris pe\u00F1a",
      "screen_name" : "iris1211",
      "indices" : [ 0, 9 ],
      "id_str" : "601994539",
      "id" : 601994539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198565001705955328",
  "geo" : { },
  "id_str" : "198568465488035841",
  "in_reply_to_user_id" : 199550192,
  "text" : "@iris1211 \u3093\u30FC\u6765\u3066\u3082\u304A\uFF4B\u3060\u3068\u601D\u3046\u3002\u6765\u305F\u304B\u3063\u305F\u3089\u305C\u3072\u304A\u3044\u3067\u3002",
  "id" : 198568465488035841,
  "in_reply_to_status_id" : 198565001705955328,
  "created_at" : "2012-05-05 00:23:06 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198551328786616321",
  "text" : "\u904A\u3073\u306B\u6765\u3066\u3044\u305F\u5F1F\u304C\u5E30\u3063\u305F\u304B\u3089\u5FC3\u7F6E\u304D\u306A\u304F\u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u304D\u308B\u305C",
  "id" : 198551328786616321,
  "created_at" : "2012-05-04 23:15:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198550304113967106",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 198550304113967106,
  "created_at" : "2012-05-04 23:10:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198550279132688385",
  "text" : "\u3074\u3088\u3074\u3088",
  "id" : 198550279132688385,
  "created_at" : "2012-05-04 23:10:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198550110316142592",
  "text" : "\u3053\u308C\u306F\u2026\uFF01",
  "id" : 198550110316142592,
  "created_at" : "2012-05-04 23:10:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198483856481988609",
  "geo" : { },
  "id_str" : "198543798517768193",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 OK",
  "id" : 198543798517768193,
  "in_reply_to_status_id" : 198483856481988609,
  "created_at" : "2012-05-04 22:45:04 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iris pe\u00F1a",
      "screen_name" : "iris1211",
      "indices" : [ 0, 9 ],
      "id_str" : "601994539",
      "id" : 601994539
    }, {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 10, 21 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198346358195896321",
  "geo" : { },
  "id_str" : "198429128062545920",
  "in_reply_to_user_id" : 199550192,
  "text" : "@iris1211 @haguruma20 \u3068\u308A\u3042\u3048\u305A\u5F85\u3061\u5408\u308F\u305B\u306E\u5834\u6240\u3068\u6642\u9593\u6C7A\u3081\u307E\u3057\u3087",
  "id" : 198429128062545920,
  "in_reply_to_status_id" : 198346358195896321,
  "created_at" : "2012-05-04 15:09:25 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198343343778967552",
  "geo" : { },
  "id_str" : "198344003085795328",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3058\u3083\u3042\u4F55\u51E6\u304B\u3067\u5F85\u3061\u5408\u308F\u305B\u3066\u304A\u663C\u3067\u3082\u98DF\u3079\u307E\u3059\uFF1F(\u3088\u304F\u8003\u3048\u305F\u3089\u5BB6\u77E5\u3089\u306A\u3044)",
  "id" : 198344003085795328,
  "in_reply_to_status_id" : 198343343778967552,
  "created_at" : "2012-05-04 09:31:10 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198317825507602432",
  "geo" : { },
  "id_str" : "198343104569409536",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u660E\u65E5\u306E\u5348\u524D\u3068\u304B\u5BB6\u306B\u3044\u307E\u3059\uFF1F(\u5BDD\u3066\u307E\u3059\u304B)",
  "id" : 198343104569409536,
  "in_reply_to_status_id" : 198317825507602432,
  "created_at" : "2012-05-04 09:27:35 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3056\u3079\u3059",
      "screen_name" : "Elizabeth_H_01",
      "indices" : [ 0, 15 ],
      "id_str" : "323566206",
      "id" : 323566206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198342748473004032",
  "geo" : { },
  "id_str" : "198342831864156160",
  "in_reply_to_user_id" : 323566206,
  "text" : "@Elizabeth_H_01 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 198342831864156160,
  "in_reply_to_status_id" : 198342748473004032,
  "created_at" : "2012-05-04 09:26:30 +0000",
  "in_reply_to_screen_name" : "Elizabeth_H_01",
  "in_reply_to_user_id_str" : "323566206",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30DE\u30F3\u30AC\u30F3",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198341336104054784",
  "geo" : { },
  "id_str" : "198342382457069568",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u305D\u306E\u30AE\u30E3\u30B0\u30018000\u70B9 #\u30DE\u30F3\u30AC\u30F3",
  "id" : 198342382457069568,
  "in_reply_to_status_id" : 198341336104054784,
  "created_at" : "2012-05-04 09:24:43 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198293290926358528",
  "geo" : { },
  "id_str" : "198314423302103040",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3042\u308A\u304C\u3068\u3046\uFF01 \u53D6\u308A\u306B\u884C\u304F is \u3069\u3053\u306B",
  "id" : 198314423302103040,
  "in_reply_to_status_id" : 198293290926358528,
  "created_at" : "2012-05-04 07:33:37 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/CS4kesMB",
      "expanded_url" : "http:\/\/twitpic.com\/9h0623",
      "display_url" : "twitpic.com\/9h0623"
    } ]
  },
  "geo" : { },
  "id_str" : "198259347250360321",
  "text" : "\u4F0F\u898B\u7A32\u8377\u5927\u793E\u306A\u3046 http:\/\/t.co\/CS4kesMB",
  "id" : 198259347250360321,
  "created_at" : "2012-05-04 03:54:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198235536836665345",
  "geo" : { },
  "id_str" : "198235723072147456",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30CA\u30A4\u30B9\u5C71\u5D0E\uFF01",
  "id" : 198235723072147456,
  "in_reply_to_status_id" : 198235536836665345,
  "created_at" : "2012-05-04 02:20:54 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198235462811398146",
  "text" : "\u9069\u5F53\u306B\u9069\u5207\u306B",
  "id" : 198235462811398146,
  "created_at" : "2012-05-04 02:19:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198234368878186496",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 198234368878186496,
  "created_at" : "2012-05-04 02:15:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198234342798008322",
  "text" : "\u306C\u308B\u3063\u3068\u8D77\u304D\u305F",
  "id" : 198234342798008322,
  "created_at" : "2012-05-04 02:15:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198083054332416000",
  "text" : "\u5927\u5909\u306A\u3053\u3068\u306B\u306A\u308B\u3093\u3058\u3083",
  "id" : 198083054332416000,
  "created_at" : "2012-05-03 16:14:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198082983880687618",
  "text" : "Siri\u306B\u306B\u305B\u307B\u30A8\u30F3\u30B8\u30F3\u5165\u308C\u305F\u3089\u2026",
  "id" : 198082983880687618,
  "created_at" : "2012-05-03 16:13:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "indices" : [ 3, 11 ],
      "id_str" : "20522410",
      "id" : 20522410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198082900766371840",
  "text" : "RT @halhorn: \u697D\u3057\u3044\u3051\u3069Siri\u3070\u304B\u3084\u3002\u97F3\u58F0\u8A8D\u8B58\u7387\u306F\u6050\u308D\u3057\u304F\u9AD8\u3044\u3002\u3051\u3069\u305D\u306E\u89E3\u91C8\u304C\u30C0\u30E1\u3002\u7B54\u3048\u3089\u308C\u306A\u3044\u3002\u306B\u305B\u307B\u30A8\u30F3\u30B8\u30F3\u3076\u3061\u3053\u3093\u3067\u3042\u3052\u3088\u3046\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198082676987670528",
    "text" : "\u697D\u3057\u3044\u3051\u3069Siri\u3070\u304B\u3084\u3002\u97F3\u58F0\u8A8D\u8B58\u7387\u306F\u6050\u308D\u3057\u304F\u9AD8\u3044\u3002\u3051\u3069\u305D\u306E\u89E3\u91C8\u304C\u30C0\u30E1\u3002\u7B54\u3048\u3089\u308C\u306A\u3044\u3002\u306B\u305B\u307B\u30A8\u30F3\u30B8\u30F3\u3076\u3061\u3053\u3093\u3067\u3042\u3052\u3088\u3046\u304B",
    "id" : 198082676987670528,
    "created_at" : "2012-05-03 16:12:45 +0000",
    "user" : {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "protected" : false,
      "id_str" : "20522410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550565137359204353\/hwjKwmzK_normal.jpeg",
      "id" : 20522410,
      "verified" : false
    }
  },
  "id" : 198082900766371840,
  "created_at" : "2012-05-03 16:13:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198079930779713536",
  "text" : "\u524D\u8005\u306F\u9AD8\u6821\u3067\u5F8C\u8005\u306F\u4E88\u5099\u6821\u3067",
  "id" : 198079930779713536,
  "created_at" : "2012-05-03 16:01:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198078642071412738",
  "text" : "\u99AC\u8077\u4EBA\u3063\u3066\u4F55\u3059\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 198078642071412738,
  "created_at" : "2012-05-03 15:56:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198078531031412737",
  "text" : "\u00D7\u99AC\u8077\u4EBA\n\u25CB\u99AC\u5546\u4EBA",
  "id" : 198078531031412737,
  "created_at" : "2012-05-03 15:56:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198077431834361856",
  "text" : "RT @the_TQFT: \u304A\u307F\u3042\u304D\u306E\u53E3\u7656\u304C\u300C\u30C1\u30E3\u30D1\u30C6\u30A3!!!\u300D\u3060\u3063\u305F\u5727\u5012\u7684\u61D0\u304B\u3057\u3044\u601D\u3044\u51FA(^^)(^^)(^^)\u516C\u5712\u3067\u6C34\u98F2\u307F\u5668\u306E\u6C34\u3092\u5674\u5C04\u3057\u3066\u3044\u305F\u3089\u3001\u304A\u307F\u3042\u304D\u306B\u6BB4\u3089\u308C\u3066\u6CE3\u3044\u305F\u306E\u3082\u5727\u5012\u7684\u61D0\u304B\u3057\u3044\u601D\u3044\u51FA(^^)(^^)(^^)wwwwwww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198077200837259264",
    "text" : "\u304A\u307F\u3042\u304D\u306E\u53E3\u7656\u304C\u300C\u30C1\u30E3\u30D1\u30C6\u30A3!!!\u300D\u3060\u3063\u305F\u5727\u5012\u7684\u61D0\u304B\u3057\u3044\u601D\u3044\u51FA(^^)(^^)(^^)\u516C\u5712\u3067\u6C34\u98F2\u307F\u5668\u306E\u6C34\u3092\u5674\u5C04\u3057\u3066\u3044\u305F\u3089\u3001\u304A\u307F\u3042\u304D\u306B\u6BB4\u3089\u308C\u3066\u6CE3\u3044\u305F\u306E\u3082\u5727\u5012\u7684\u61D0\u304B\u3057\u3044\u601D\u3044\u51FA(^^)(^^)(^^)wwwwwww",
    "id" : 198077200837259264,
    "created_at" : "2012-05-03 15:50:59 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 198077431834361856,
  "created_at" : "2012-05-03 15:51:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198076369991770113",
  "text" : "\u9AD8\u6821\u6642\u4EE3\u306F\u305F\u3060\u5B58\u5728\u3057\u3066\u3044\u307E\u3057\u305F\uFF1F",
  "id" : 198076369991770113,
  "created_at" : "2012-05-03 15:47:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u9AD8\u6821\u6642\u4EE3\u306A\u3093\u3066\u306A\u304B\u3063\u305F",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198076076335972353",
  "text" : "#\u9AD8\u6821\u6642\u4EE3\u306A\u3093\u3066\u306A\u304B\u3063\u305F",
  "id" : 198076076335972353,
  "created_at" : "2012-05-03 15:46:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198019169017532416",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 198019169017532416,
  "created_at" : "2012-05-03 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197923782256627713",
  "text" : "\u968E\u6BB5\u3057\u3093\u3069\u3044\u3041\u3041\u3041\u3041",
  "id" : 197923782256627713,
  "created_at" : "2012-05-03 05:41:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197922288811786240",
  "text" : "\u77E5\u6069\u9662\u306A\u3046",
  "id" : 197922288811786240,
  "created_at" : "2012-05-03 05:35:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197922151054061570",
  "text" : "@YohjiGreat \u304A\u304B\u3048\u308A\u306A\u3055\u3044",
  "id" : 197922151054061570,
  "created_at" : "2012-05-03 05:34:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 1, 9 ],
      "id_str" : "16929336",
      "id" : 16929336
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 10, 19 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 20, 30 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 42, 52 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197906277077229568",
  "text" : ".@shigmax @akeopyaa @nisehorrn @Italiasan @Lisa_math \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30DE\u30C3\u30C9\uFF01",
  "id" : 197906277077229568,
  "created_at" : "2012-05-03 04:31:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197902199274221568",
  "text" : "\u30DE\u30C3\u30C9\u30AF\u30ED\u30C3\u30AF\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 197902199274221568,
  "created_at" : "2012-05-03 04:15:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197895248838529024",
  "text" : "\u8AB0\u304B\u5E30\u7701\u3059\u308B\u3068\u304B\u51FA\u639B\u3051\u306A\u3044\u3068\u304B\u3067\u81EA\u8EE2\u8ECA\u8CB8\u3057\u3066\u304F\u308C\u308B\u4EBA\u3044\u307E\u305B\u3093\uFF1F",
  "id" : 197895248838529024,
  "created_at" : "2012-05-03 03:47:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197888689588813826",
  "text" : "\u3086\u308B\u307C \u81EA\u8EE2\u8ECA\u8CB8\u3057\u3066\u304F\u308C\u308B\u4EBA",
  "id" : 197888689588813826,
  "created_at" : "2012-05-03 03:21:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197868927416676352",
  "geo" : { },
  "id_str" : "197869004847722497",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u4F55\u8A00\u3063\u3066\u3093\u306E",
  "id" : 197869004847722497,
  "in_reply_to_status_id" : 197868927416676352,
  "created_at" : "2012-05-03 02:03:41 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197868521387069440",
  "text" : "\u9AEA\u5207\u3063\u3066\u304D\u305F",
  "id" : 197868521387069440,
  "created_at" : "2012-05-03 02:01:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 2, 16 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    }, {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 17, 25 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrrn",
      "indices" : [ 26, 40 ],
      "id_str" : "295216106",
      "id" : 295216106
    }, {
      "name" : "\u304B\u307F\u3085",
      "screen_name" : "kamyuri96",
      "indices" : [ 41, 51 ],
      "id_str" : "311187890",
      "id" : 311187890
    }, {
      "name" : "\u8336\u67F1\u3055\u3093(\u304A\u4F11\u307F\u4E2D\u3067\u3059)",
      "screen_name" : "chabashirasan",
      "indices" : [ 52, 66 ],
      "id_str" : "472125109",
      "id" : 472125109
    }, {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 67, 73 ],
      "id_str" : "184844182",
      "id" : 184844182
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 84, 94 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197849498138058752",
  "text" : ". @riveriver4361 @i_horse @nisehorrrrrrn @kamyuri96 @chabashirasan @0_uda @ispamgis @Lisa_math \u304A\u306F\u3088\u3046\u3042\u308A\u304C\u3068\u3067\u3057\u305F\u30FC",
  "id" : 197849498138058752,
  "created_at" : "2012-05-03 00:46:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197846917844180993",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 197846917844180993,
  "created_at" : "2012-05-03 00:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 2, 14 ],
      "id_str" : "229754624",
      "id" : 229754624
    }, {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 25, 33 ],
      "id_str" : "57847957",
      "id" : 57847957
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 34, 49 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "\u30B3\u30D0\u30E4\u30B7\u30B9",
      "screen_name" : "1_7724538509055",
      "indices" : [ 50, 66 ],
      "id_str" : "523275831",
      "id" : 523275831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197846869190246400",
  "text" : ". @nisehorrrrn @ispamgis @ninetan @G4_Hirano_chan @1_7724538509055 \u304A\u3084\u3042\u308A\u3067\u3057\u30FC",
  "id" : 197846869190246400,
  "created_at" : "2012-05-03 00:35:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197737468601171968",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 197737468601171968,
  "created_at" : "2012-05-02 17:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3061\u3047\u308A\u30FC",
      "screen_name" : "che_rrrry",
      "indices" : [ 0, 10 ],
      "id_str" : "2859162751",
      "id" : 2859162751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197733038728298496",
  "geo" : { },
  "id_str" : "197733081438883840",
  "in_reply_to_user_id" : 145536184,
  "text" : "@che_rrrry \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 197733081438883840,
  "in_reply_to_status_id" : 197733038728298496,
  "created_at" : "2012-05-02 17:03:34 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197732645092851713",
  "text" : "\u306A\u3093\u306A\u3093\u3060\u308D\u3046\u3053\u308C",
  "id" : 197732645092851713,
  "created_at" : "2012-05-02 17:01:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/197732546782576640\/photo\/1",
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/PuAbzXrW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar58tCPCQAAftmz.jpg",
      "id_str" : "197732546786770944",
      "id" : 197732546786770944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar58tCPCQAAftmz.jpg",
      "sizes" : [ {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PuAbzXrW"
    } ],
    "hashtags" : [ {
      "text" : "\u306A\u305C\u4FDD\u5B58\u3057\u305F\u304B\u308F\u304B\u3089\u306A\u3044\u753B\u50CF\u8CBC\u3063\u3066\u3051",
      "indices" : [ 0, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197732546782576640",
  "text" : "#\u306A\u305C\u4FDD\u5B58\u3057\u305F\u304B\u308F\u304B\u3089\u306A\u3044\u753B\u50CF\u8CBC\u3063\u3066\u3051 http:\/\/t.co\/PuAbzXrW",
  "id" : 197732546782576640,
  "created_at" : "2012-05-02 17:01:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197718419448147969",
  "text" : "\u3084\u3063\u3066\u306A\u3055\u305D\u3046\u3060\u306A",
  "id" : 197718419448147969,
  "created_at" : "2012-05-02 16:05:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197718013624074240",
  "text" : "\u4ECA\u65E5\u3063\u3066\u5B66\u98DF\u3084\u3063\u3066\u3093\u306E\uFF1F",
  "id" : 197718013624074240,
  "created_at" : "2012-05-02 16:03:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197717641178251264",
  "text" : "\u6628\u591C\u306E\u4ED6\u8005\u7D39\u4ECB\uFF34\uFF2C\u307E\u3068\u3081\u3059\u3046\u304C\u304F\u5F92\u7248\u3092\u898B\u3066\u304D\u305F\u3002\u9762\u767D\u304B\u3063\u305F\u304C\u81EA\u5206\u304C\u53C2\u52A0\u3067\u304D\u306A\u304B\u3063\u305F\u306E\u304C\u6B8B\u5FF5\u3060\u3002",
  "id" : 197717641178251264,
  "created_at" : "2012-05-02 16:02:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197714026405433344",
  "geo" : { },
  "id_str" : "197714112992653313",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u308F\u3093\u3061\u3083\u3093\u3042\u308B",
  "id" : 197714112992653313,
  "in_reply_to_status_id" : 197714026405433344,
  "created_at" : "2012-05-02 15:48:12 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197713807651520513",
  "geo" : { },
  "id_str" : "197713917605199872",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u4F55\u306E\u61F8\u8CDE\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 197713917605199872,
  "in_reply_to_status_id" : 197713807651520513,
  "created_at" : "2012-05-02 15:47:25 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197713425651085312",
  "text" : "\u81EA\u5206\u306E\u5199\u771F\u4E0A\u3052\u308B\u3068\u304B\u5727\u5012\u7684\u62B5\u6297\u611F\u304C\u3050\u3072\u3083\u307A\u308D",
  "id" : 197713425651085312,
  "created_at" : "2012-05-02 15:45:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197713298995683330",
  "text" : "@Malmach140 \u305D\u308C\u306F\u3061\u3087\u3063\u3068\u62B5\u6297\u5728\u308A\u307E\u3059\u306D\u3047",
  "id" : 197713298995683330,
  "created_at" : "2012-05-02 15:44:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197713049598173184",
  "text" : "@Malmach140 \u30D0\u30C3\u30B5\u30EA\u5207\u308A\u307E\u3059\uFF01",
  "id" : 197713049598173184,
  "created_at" : "2012-05-02 15:43:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197712869868060673",
  "text" : "\u4ECA\u65E510\u6642\u304B\u3089\u7F8E\u5BB9\u9662\u306A\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 197712869868060673,
  "created_at" : "2012-05-02 15:43:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6DF1\u591C\u306E\u6383\u9664",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197712749579603969",
  "text" : "#\u6DF1\u591C\u306E\u6383\u9664",
  "id" : 197712749579603969,
  "created_at" : "2012-05-02 15:42:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197712508864299009",
  "text" : "RT @the_TQFT: \u8A3C\u660E\u308F\u304B\u3089\u3093\u307D\u3093\u3067\u30D3\u30FC\u30E0\u51FA\u305D\u3046wwwww(^^)(^^)(^^)wwwww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197704815076323329",
    "text" : "\u8A3C\u660E\u308F\u304B\u3089\u3093\u307D\u3093\u3067\u30D3\u30FC\u30E0\u51FA\u305D\u3046wwwww(^^)(^^)(^^)wwwww",
    "id" : 197704815076323329,
    "created_at" : "2012-05-02 15:11:15 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 197712508864299009,
  "created_at" : "2012-05-02 15:41:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197712483308417024",
  "text" : "RT @the_TQFT: \u6B7B\u306B\u81F3\u308B\u3050\u3072\u3083\u307A\u308Dwwwww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197707148095012864",
    "text" : "\u6B7B\u306B\u81F3\u308B\u3050\u3072\u3083\u307A\u308Dwwwww",
    "id" : 197707148095012864,
    "created_at" : "2012-05-02 15:20:31 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 197712483308417024,
  "created_at" : "2012-05-02 15:41:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197712469500772352",
  "text" : "RT @the_TQFT: \u3082\u3057\u8A3C\u660E\u304C\u308F\u304B\u308C\u3070\u3001\u8A3C\u660E\u304C\u308F\u304B\u308B\u306E\u306B\u306A\u30FC(^^)(^^)(^^)wwwwwww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197706856427298817",
    "text" : "\u3082\u3057\u8A3C\u660E\u304C\u308F\u304B\u308C\u3070\u3001\u8A3C\u660E\u304C\u308F\u304B\u308B\u306E\u306B\u306A\u30FC(^^)(^^)(^^)wwwwwww",
    "id" : 197706856427298817,
    "created_at" : "2012-05-02 15:19:22 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 197712469500772352,
  "created_at" : "2012-05-02 15:41:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 0, 14 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197627071994929152",
  "geo" : { },
  "id_str" : "197627336286404608",
  "in_reply_to_user_id" : 320494295,
  "text" : "@riveriver4361 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 197627336286404608,
  "in_reply_to_status_id" : 197627071994929152,
  "created_at" : "2012-05-02 10:03:23 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197625591376252929",
  "text" : "\u4F8B\u4F1A\uFF67\uFF01",
  "id" : 197625591376252929,
  "created_at" : "2012-05-02 09:56:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197598527155740672",
  "text" : "@capella_1127 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 197598527155740672,
  "created_at" : "2012-05-02 08:08:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197593034299424768",
  "text" : "\u3051\u3093\u308D\u3093\uFF01",
  "id" : 197593034299424768,
  "created_at" : "2012-05-02 07:47:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197583041240117249",
  "text" : "\u8CE2\u8005\u304C\u5727\u5012\u7684\u3092\u7D75\u306B\u66F8\u3044\u3066\u3044\u308B",
  "id" : 197583041240117249,
  "created_at" : "2012-05-02 07:07:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/the_TQFT\/status\/197582278174588929\/photo\/1",
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/tXEI89GI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar30CQDCQAE4W14.jpg",
      "id_str" : "197582278178783233",
      "id" : 197582278178783233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar30CQDCQAE4W14.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tXEI89GI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197582883811110912",
  "text" : "RT @the_TQFT: (^^)(^^)(^^)\u304A\u7D75\u63CF\u304D(^^)(^^)(^^) http:\/\/t.co\/tXEI89GI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/the_TQFT\/status\/197582278174588929\/photo\/1",
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/tXEI89GI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar30CQDCQAE4W14.jpg",
        "id_str" : "197582278178783233",
        "id" : 197582278178783233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar30CQDCQAE4W14.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tXEI89GI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197582278174588929",
    "text" : "(^^)(^^)(^^)\u304A\u7D75\u63CF\u304D(^^)(^^)(^^) http:\/\/t.co\/tXEI89GI",
    "id" : 197582278174588929,
    "created_at" : "2012-05-02 07:04:22 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 197582883811110912,
  "created_at" : "2012-05-02 07:06:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197581885378019329",
  "text" : "\u84B8\u3059",
  "id" : 197581885378019329,
  "created_at" : "2012-05-02 07:02:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197578900275077121",
  "text" : "RT @_flyingmoomin: \uFF3C\u3001\u309D\uFF3C\u30FB\u3001\uFF3C\u3001\uFF3C\u30FB\u3002\u309C\u3001\uFF3C\u30FB\uFF3C\u309D\u30FB\uFF3C\u3002\u309C\uFF3C\u3001\u3001\uFF3C\u30FB\u3002\uFF3C\u3001\u309D\u30FB\u3002\u3001\uFF3C\uFF3C\u30FB\uFF3C\u3002\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\u3001\uFF3C\u309D\uFF3C\u3002\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\uFF3C\u3001\u309D\u30FB\u3001\uFF3C\u3001\uFF3C\u30FB\u3002\u309C\uFF3C\u3001\uFF3C\uFF3C\u309D\u30FB\uFF3C\u3002\u309C\uFF3C\u3001\u3001\u309D\uFF3C\u30FB\u3002\uFF3C\u3001\u309D\u30FB\u3002\u3001\uFF3C\uFF3C\u30FB\uFF3C\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\u3001\u3001\u309D\u30FB\uFF3C\u3002\n\uFF3C\u3001\uFF3C (^ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197578324065796096",
    "text" : "\uFF3C\u3001\u309D\uFF3C\u30FB\u3001\uFF3C\u3001\uFF3C\u30FB\u3002\u309C\u3001\uFF3C\u30FB\uFF3C\u309D\u30FB\uFF3C\u3002\u309C\uFF3C\u3001\u3001\uFF3C\u30FB\u3002\uFF3C\u3001\u309D\u30FB\u3002\u3001\uFF3C\uFF3C\u30FB\uFF3C\u3002\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\u3001\uFF3C\u309D\uFF3C\u3002\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\uFF3C\u3001\u309D\u30FB\u3001\uFF3C\u3001\uFF3C\u30FB\u3002\u309C\uFF3C\u3001\uFF3C\uFF3C\u309D\u30FB\uFF3C\u3002\u309C\uFF3C\u3001\u3001\u309D\uFF3C\u30FB\u3002\uFF3C\u3001\u309D\u30FB\u3002\u3001\uFF3C\uFF3C\u30FB\uFF3C\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\u309C\uFF3C\u3001\u309D\uFF3C\u30FB\u3001\u3001\u309D\u30FB\uFF3C\u3002\n\uFF3C\u3001\uFF3C (^^(^^(^^\u4E09^^)^^)^^) \u2190\u96E8\u4E2D\u8CE2\u8005",
    "id" : 197578324065796096,
    "created_at" : "2012-05-02 06:48:37 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 197578900275077121,
  "created_at" : "2012-05-02 06:50:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197577562417934336",
  "text" : "\u3044\u3084\u307E\u3041\u3044\u308B\u3060\u3051\u3060\u304C",
  "id" : 197577562417934336,
  "created_at" : "2012-05-02 06:45:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197577515697586176",
  "text" : "\u306A\u3093\u3067\u79C1\u304C\u5E7E\u4F55\u5B66\u6F14\u7FA9\u306B\uFF01\uFF1F",
  "id" : 197577515697586176,
  "created_at" : "2012-05-02 06:45:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197562773415264256",
  "text" : "6\u53F7\u9928\u306B\u904A\u3073\u306B\u6765\u305F\u304C\u2026\u6F14\u7FA9\u3063\u3066\u3069\u3053\u3067\u3084\u3063\u3066\u3093\u306E\uFF1F",
  "id" : 197562773415264256,
  "created_at" : "2012-05-02 05:46:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/H3AmFSfT",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=hiroskii_mk2",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197536196765822976",
  "text" : "\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u308B\u3060\u308C\u304B\u3055\u3093\u3068\u3001hiroskii_mk2\u3055\u3093\u304C\u6570\u5B66\u3057\u305F\u3044\u305D\u3046\u3067\u3059\u3002[\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059] http:\/\/t.co\/H3AmFSfT #gohantabeyo",
  "id" : 197536196765822976,
  "created_at" : "2012-05-02 04:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197522047482601472",
  "text" : "\u3055\u3041\u51FA\u304B\u3051\u3088\u3046\u3002\u6FE1\u308C\u306A\u304C\u3089\u3002",
  "id" : 197522047482601472,
  "created_at" : "2012-05-02 03:05:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 0, 9 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197521375072763905",
  "geo" : { },
  "id_str" : "197521607592394754",
  "in_reply_to_user_id" : 176127240,
  "text" : "@the_TQFT \u5727\u5012\u7684\u96E8\u4E2D\u8CE2\u8005(^^)(^^)(^^)(^^)(^^)(^^)(^^)(^^)(^^)",
  "id" : 197521607592394754,
  "in_reply_to_status_id" : 197521375072763905,
  "created_at" : "2012-05-02 03:03:15 +0000",
  "in_reply_to_screen_name" : "the_TQFT",
  "in_reply_to_user_id_str" : "176127240",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197516795563868160",
  "text" : "\u4E8C\u65E5\u7D9A\u3051\u306612\u6642\u9593\u8FD1\u304F\u5BDD\u3066\u3044\u308B\u2026\u5BDD\u904E\u304E",
  "id" : 197516795563868160,
  "created_at" : "2012-05-02 02:44:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197516541300981760",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 197516541300981760,
  "created_at" : "2012-05-02 02:43:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197340273766969345",
  "text" : "\u65E5\u4ED8\u5909\u3063\u305F\u3057\u5BDD\u3088\u3046\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 197340273766969345,
  "created_at" : "2012-05-01 15:02:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197338932264964096",
  "geo" : { },
  "id_str" : "197339118500462592",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u30E1\u30C3\u30B7\u30E5\u3067\u306F\u751F\u306C\u308B\u3044\uFF08\u304C\u7DD1\u8336\u306F\u5E7E\u3089\u304B\u306C\u308B\u3044\u65B9\u304C\u82E6\u307F\u304C\u51FA\u306A\u3044\u3093\u3060\u3088\u306D\uFF09",
  "id" : 197339118500462592,
  "in_reply_to_status_id" : 197338932264964096,
  "created_at" : "2012-05-01 14:58:06 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u975E\u516C\u5F0FRT\u3057\u305F\u3089\u4EE3\u30C8\u30DD\u30AF\u30E9\u30B9\u30BF",
      "indices" : [ 19, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197338837192687616",
  "text" : "RT @koizumi_fifty: #\u975E\u516C\u5F0FRT\u3057\u305F\u3089\u4EE3\u30C8\u30DD\u30AF\u30E9\u30B9\u30BF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u975E\u516C\u5F0FRT\u3057\u305F\u3089\u4EE3\u30C8\u30DD\u30AF\u30E9\u30B9\u30BF",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197338788836544512",
    "text" : "#\u975E\u516C\u5F0FRT\u3057\u305F\u3089\u4EE3\u30C8\u30DD\u30AF\u30E9\u30B9\u30BF",
    "id" : 197338788836544512,
    "created_at" : "2012-05-01 14:56:48 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 197338837192687616,
  "created_at" : "2012-05-01 14:56:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 30, 38 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197338724323958784",
  "text" : "\u7DD1\u306B\u67D3\u3081\u3066\u300C\u8336\u9AEA\u300D\u3063\u3066\u3054\u308A\u62BC\u3059\u82B8\u3092\u601D\u3044\u3064\u3044\u305F\u306E\u3067\u3069\u3046\u305ERT @maucha_: \u8336\u9AEA\u3060\u304B\u3089\u30C1\u30E3\u30E9\u3044\u3068\u304B\u304A\u304B\u3057\u3044\u3060\u308D",
  "id" : 197338724323958784,
  "created_at" : "2012-05-01 14:56:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u305C\u3093\u305F\u3044\u3059\u3046",
      "screen_name" : "maniwatch",
      "indices" : [ 0, 10 ],
      "id_str" : "236476272",
      "id" : 236476272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197337873958187008",
  "geo" : { },
  "id_str" : "197338173863501825",
  "in_reply_to_user_id" : 236476272,
  "text" : "@maniwatch \uFF34\uFF2C\u306B\u5730\u5143\u6C11\u3044\u308B\u3068\u89AA\u8FD1\u611F\u6E67\u304D\u307E\u3059\u3088\u306D\u30FC\uFF57\uFF35\uFF34\u306E\u4EBA\u306F\u7D50\u69CB\u8FD1\u304F\u306B\u3044\u3066\u89AA\u8FD1\u611F\u3067\u3059\u3001\u3044\u3064\u304B\u904A\u3073\u306B\u884C\u304D\u305F\u3044\u3002",
  "id" : 197338173863501825,
  "in_reply_to_status_id" : 197337873958187008,
  "created_at" : "2012-05-01 14:54:21 +0000",
  "in_reply_to_screen_name" : "maniwatch",
  "in_reply_to_user_id_str" : "236476272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197337566691852288",
  "text" : "\u5E7C\u5973\u306B\u597D\u304B\u308C\u305D\u3046\u306A\u611F\u3058\u306A\u3089\u666E\u901A\u306B\u5973\u6027\u306B\u597D\u304B\u308C\u3066\u3082\u3088\u3055\u305D\u3046\u306A\u3082\u306E\u3060\u304C\u305D\u3046\u3067\u306A\u3044\u306E\u3067\u507D",
  "id" : 197337566691852288,
  "created_at" : "2012-05-01 14:51:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 29, 45 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197337440690778112",
  "text" : "\u3058\u3085\u308B\u3058\u3085\u308B\u3057\u3066\u308B\u6570\u5B66\u5F92\u3001\u30CE\u30FC\u30C8\u6709\u96E3\u3046\u3054\u3056\u3044\u307E\u3059\u3002 RT @Jelly_in_a_tank: #\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
  "id" : 197337440690778112,
  "created_at" : "2012-05-01 14:51:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197336916373417985",
  "text" : "\u5E7C\u5973\u306B\u597D\u304B\u308C\u305D\u3046\u306A\u611F\u3058\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 197336916373417985,
  "created_at" : "2012-05-01 14:49:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 3, 15 ],
      "id_str" : "131048355",
      "id" : 131048355
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 66, 76 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197336884324728833",
  "text" : "RT @MaryMimiary: \u3048\u3093\u3069\u3055\u3093\u3002\u6587\u7CFB\u3067\u3042\u308A\u7406\u7CFB\u3002\u5E7C\u5973\u306B\u597D\u304B\u308C\u305D\u3046\u306A\u611F\u3058\u3002\u82E6\u52B4\u4EBA\u306E\u306B\u304A\u3044\u304C\u3059\u308B\u304B\u3089\u9811\u5F35\u3063\u3066\u6B32\u3057\u3044\u3002RT @end313124: #\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 49, 59 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
        "indices" : [ 61, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197336739315073024",
    "text" : "\u3048\u3093\u3069\u3055\u3093\u3002\u6587\u7CFB\u3067\u3042\u308A\u7406\u7CFB\u3002\u5E7C\u5973\u306B\u597D\u304B\u308C\u305D\u3046\u306A\u611F\u3058\u3002\u82E6\u52B4\u4EBA\u306E\u306B\u304A\u3044\u304C\u3059\u308B\u304B\u3089\u9811\u5F35\u3063\u3066\u6B32\u3057\u3044\u3002RT @end313124: #\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
    "id" : 197336739315073024,
    "created_at" : "2012-05-01 14:48:39 +0000",
    "user" : {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "protected" : false,
      "id_str" : "131048355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592322663835545602\/c9mnr8R-_normal.jpg",
      "id" : 131048355,
      "verified" : false
    }
  },
  "id" : 197336884324728833,
  "created_at" : "2012-05-01 14:49:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u305C\u3093\u305F\u3044\u3059\u3046",
      "screen_name" : "maniwatch",
      "indices" : [ 0, 10 ],
      "id_str" : "236476272",
      "id" : 236476272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197336600898846721",
  "geo" : { },
  "id_str" : "197336819707289601",
  "in_reply_to_user_id" : 236476272,
  "text" : "@maniwatch \u3066\u304B\u4E09\u9DF9\u5E02\u6C11\u3067\u3059\u304B\u3044\u3002\u5B9F\u5BB6\u304C\u4E09\u9DF9\u53F0\u306A\u306E\u3067\u3059\u304C\u3002",
  "id" : 197336819707289601,
  "in_reply_to_status_id" : 197336600898846721,
  "created_at" : "2012-05-01 14:48:58 +0000",
  "in_reply_to_screen_name" : "maniwatch",
  "in_reply_to_user_id_str" : "236476272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197336618703659010",
  "text" : "\u6700\u8FD1\u6570\u5B66\u90E8\u6587\u5B66\u79D1\u306A\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u3044\u3046\u5642\u3082\u307E\u3053\u3068\u3057\u3084\u304B\u306B\u3055\u3055\u3084\u304B\u308C\u3066\u3044\u308B\u3057\u3082\u3046\u3088\u304F\u308F\u304B\u3093\u306A\u3044",
  "id" : 197336618703659010,
  "created_at" : "2012-05-01 14:48:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 0, 14 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197336112811868160",
  "geo" : { },
  "id_str" : "197336333226737664",
  "in_reply_to_user_id" : 320494295,
  "text" : "@riveriver4361 \u6A21\u8A66\u306E\u5224\u5B9A\u306F\u304A\u307F\u304F\u3058",
  "id" : 197336333226737664,
  "in_reply_to_status_id" : 197336112811868160,
  "created_at" : "2012-05-01 14:47:02 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197336105639616512",
  "text" : "\u3044\u3064\u304B\u3089\u3059\u3046\u304C\u304F\u304B\u3060\u3068\u3055\u3063\u304B\u304F\u3057\u3066\u3044\u305F\uFF08\u3057\u308D\u3081",
  "id" : 197336105639616512,
  "created_at" : "2012-05-01 14:46:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197335720627671041",
  "text" : "\u306A\u304B\u306A\u304B\u7D39\u4ECB\u3055\u308C\u306A\u3044\u306A\u30FC\u3068\u601D\u3063\u3066\u3044\u305F\u3089\u5225\u306B\u975E\u516C\u5F0F\uFF32\uFF34\u3057\u3066\u306A\u304B\u3063\u305F\u3067\u3057\u305F",
  "id" : 197335720627671041,
  "created_at" : "2012-05-01 14:44:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197335501722759169",
  "text" : "#\u975E\u516C\u5F0FRT\u3057\u305F\u4EBA\u306B\u7D39\u4ECB\u3055\u308C\u308B",
  "id" : 197335501722759169,
  "created_at" : "2012-05-01 14:43:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197334001155981312",
  "geo" : { },
  "id_str" : "197334573447774210",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u7121\u9650\u3046\u3069\u3093\u5217\u306E\u5727\u5012\u7684\u30B8\u30A7\u30CD\u30EC\u30FC\u30C8\uFF08\uFF3E\uFF3E\uFF09\uFF08\uFF3E\uFF3E\uFF09\uFF08\uFF3E\uFF3E\uFF09\uFF08\uFF3E\uFF3E\uFF09\uFF08\uFF3E\uFF3E\uFF09",
  "id" : 197334573447774210,
  "in_reply_to_status_id" : 197334001155981312,
  "created_at" : "2012-05-01 14:40:03 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197332987401084928",
  "geo" : { },
  "id_str" : "197333294587711488",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u3046\u3069\u3093\u98DF\u3079\u3066\u304B\u3089\u3046\u3069\u3093\u6253\u3066\u3070\u3044\u3044\u3093\u3067\u3059\uFF01\u307E\u305A\u3046\u3069\u3093\u3092\u98DF\u3079\u308B\u305F\u3081\u306B\u3046\u3069\u3093\u3092\u6253\u3061\u307E\u3057\u3087\u3046\uFF01",
  "id" : 197333294587711488,
  "in_reply_to_status_id" : 197332987401084928,
  "created_at" : "2012-05-01 14:34:58 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197331890980659201",
  "text" : "\u3053\u308C\u3063\u3066\u975E\u5B9F\u5728\u3060\u3063\u305F\u3088\u3046\u306A RT @ toribiaaka: \u30C8\u30B2\u30A2\u30EA\u30C8\u30B2\u30CA\u30B7\u30C8\u30B2\u30C8\u30B2\u3068\u3044\u3046\u866B\u304C\u3044\u308B",
  "id" : 197331890980659201,
  "created_at" : "2012-05-01 14:29:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7766\u6708\u30FE\uFF08\u30FB\u03C9\u30FB\u273F\uFF09\u30CE",
      "screen_name" : "owlmutsuki",
      "indices" : [ 0, 11 ],
      "id_str" : "283993563",
      "id" : 283993563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197331362225721345",
  "geo" : { },
  "id_str" : "197331465426567168",
  "in_reply_to_user_id" : 283993563,
  "text" : "@owlmutsuki \u3044\u3048\u3044\u3048\u30FC",
  "id" : 197331465426567168,
  "in_reply_to_status_id" : 197331362225721345,
  "created_at" : "2012-05-01 14:27:42 +0000",
  "in_reply_to_screen_name" : "owlmutsuki",
  "in_reply_to_user_id_str" : "283993563",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197330818157391873",
  "geo" : { },
  "id_str" : "197330900302835714",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u58F0\u3092\u8AAC\u660E\u3063\u3066\u8D85\u7D76\u306B\u96E3\u3057\u3044\u3093\u3058\u3083\u2026",
  "id" : 197330900302835714,
  "in_reply_to_status_id" : 197330818157391873,
  "created_at" : "2012-05-01 14:25:27 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197330386076971008",
  "geo" : { },
  "id_str" : "197330675496529920",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u307E\u3041\u306C\u308B\u306C\u308B\u304C\u3093\u3070\u308C\uFF57\u5F8C\u534A\u306E\u96D1\u306B\u306A\u3063\u3066\u3044\u304F\u611F\u3058\u3092\u6A2A\u304B\u3089\u697D\u3057\u307F\u306B\u3057\u3066\u3044\u308B\u3002",
  "id" : 197330675496529920,
  "in_reply_to_status_id" : 197330386076971008,
  "created_at" : "2012-05-01 14:24:33 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 14, 30 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197330207596748801",
  "geo" : { },
  "id_str" : "197330545636675584",
  "in_reply_to_user_id" : 138430452,
  "text" : "\uFF08\u3058\u3047\u308A\u30FC\u3068\u3048\u3093\u3069\uFF09 QT @Jelly_in_a_tank: (\u3058\u3047\u308A\u30FC\u3066\u3043\u3063\u3069)",
  "id" : 197330545636675584,
  "in_reply_to_status_id" : 197330207596748801,
  "created_at" : "2012-05-01 14:24:02 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197330394348134401",
  "text" : "\uFF08\u3067\u308A\u30FC\u3068\u3048\u3093\u3069\uFF09",
  "id" : 197330394348134401,
  "created_at" : "2012-05-01 14:23:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u305D\u3057\u3066\u4E0A\u9650\uFF13\u3092\u8A2D\u5B9A\u3059\u308B\u30822\u4EBA\u3057\u304B\u7D39\u4ECB\u306E\u5FDC\u52DF\u304C\u306A\u304B\u3063\u305F\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u3053\u3061\u3089\u306B\u306A\u308A\u307E\u3059",
      "indices" : [ 26, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197329954059464706",
  "geo" : { },
  "id_str" : "197330256233906177",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u81EA\u5206\u306E\u4EBA\u6C17\u306F\u81EA\u899A\u3057\u306A\u3044\u3068\u3002 #\u305D\u3057\u3066\u4E0A\u9650\uFF13\u3092\u8A2D\u5B9A\u3059\u308B\u30822\u4EBA\u3057\u304B\u7D39\u4ECB\u306E\u5FDC\u52DF\u304C\u306A\u304B\u3063\u305F\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u3053\u3061\u3089\u306B\u306A\u308A\u307E\u3059",
  "id" : 197330256233906177,
  "in_reply_to_status_id" : 197329954059464706,
  "created_at" : "2012-05-01 14:22:53 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197329574936317952",
  "geo" : { },
  "id_str" : "197329793774137344",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u4E0A\u9650\u3092\u8A2D\u3051\u306A\u304B\u3063\u305F\u306E\u304C\u6557\u56E0\u3002\u304C\u3093\u3070\u308C\u3002",
  "id" : 197329793774137344,
  "in_reply_to_status_id" : 197329574936317952,
  "created_at" : "2012-05-01 14:21:03 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7766\u6708\u30FE\uFF08\u30FB\u03C9\u30FB\u273F\uFF09\u30CE",
      "screen_name" : "owlmutsuki",
      "indices" : [ 3, 14 ],
      "id_str" : "283993563",
      "id" : 283993563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197329331826065408",
  "text" : "\u7D39\u4ECB @owlmutsuki \u5B9F\u306F\u30EA\u30A2\u30EB\u3067\u77E5\u308A\u5408\u3046\u65B9\u304C\u65E9\u304B\u3063\u305F\u308A\u3057\u305F\u3002\u85AC\u5B66\u5F92\u3002\u8CB8\u3057\u3066\u3044\u305F\u3060\u3044\u305F\u3053\u3068\u3082\u3042\u308B\u304C\u30CE\u30FC\u30C8\u304C\u975E\u5E38\u306B\u7DBA\u9E97\u3067\u8AAD\u307F\u3084\u3059\u3044\u3002\u306A\u3093\u3068\u3044\u3046\u304B\u771F\u9762\u76EE\u306A\u30A4\u30E1\u30FC\u30B8\uFF08\u3060\u304C\u6982\u306D\u7DBA\u9E97\u306A\u30CE\u30FC\u30C8\u306E\u305B\u3044\u3067\u3042\u308B\uFF09\u4F55\u306E\u30AC\u30C1\u52E2\u306A\u306E\u304B\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3051\u308C\u3069\u3001\u4F55\u304B\u306E\u30AC\u30C1\u52E2\u3060\u3068\u601D\u3046\uFF08\u306A\u3093\u3060\u3053\u308C\uFF09",
  "id" : 197329331826065408,
  "created_at" : "2012-05-01 14:19:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 3, 18 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197327726372327425",
  "text" : "\u7D39\u4ECB @haruhalcyoncat \u306F\u308B\u304F\u308B\u3057\u3085\u3093\u3089\u3044\u306F\u308B\u304D\u306F\u308B\u3053\u3044\u3002\u672C\u4EBA\u306B\u6B63\u89E3\u3092\u805E\u3044\u305F\u3053\u3068\u304C\u3042\u308B\u304C\u3001\u305D\u306E\u3068\u304D\u306B\u8272\u3005\u306A\u30D1\u30BF\u30FC\u30F3\u3092\u805E\u3044\u305F\u305B\u3044\u3067\u4F59\u8A08\u306B\u308F\u304B\u3089\u306A\u304F\u306A\u3063\u305F\u3002\u304B\u308B\u305F\u30AC\u30C1\u52E2\u3002\u304B\u308B\u305F\u3092\u4ED6\u306E\u4EBA\u306B\u3068\u3089\u308C\u306A\u3044\u3088\u3046\u306B\u624B\u9996\u306E\u30B9\u30CA\u30C3\u30D7\u3067\u300C\u3066\u3044\u3063\u300D\u3063\u3066\u3059\u3054\u3044\u901F\u5EA6\u3067\u98DB\u3070\u3059\u306B\u9055\u3044\u306A\u3044\uFF08\u504F\u898B\uFF09",
  "id" : 197327726372327425,
  "created_at" : "2012-05-01 14:12:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197326630300024833",
  "geo" : { },
  "id_str" : "197326683378958336",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u3069\u3046\u305E\uFF08\u8FEB\u771F\uFF09",
  "id" : 197326683378958336,
  "in_reply_to_status_id" : 197326630300024833,
  "created_at" : "2012-05-01 14:08:42 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3082\u3046\u3070\u308C\u305F",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197326628429377536",
  "text" : "\u3006\u3088\u3046\u3068\u601D\u3063\u3066\u308B\u306E\u306B2\u4EBA\u306B\u3057\u304B\u3075\u3041\u307C\u3089\u308C\u3066\u306A\u3044\u304B\u3089\u3006\u3089\u308C\u306A\u3044\u3057\u3053\u3053\u3067\u3006\u305F\u30892\u4EBA\u306B\u3057\u304B\u3075\u3041\u307C\u3089\u308C\u306A\u304B\u3063\u305F\u3053\u3068\u304C\u3070\u308C\u3061\u3083\u3046\u3093\u3060\u304C\u30FC\uFF1F #\u3082\u3046\u3070\u308C\u305F",
  "id" : 197326628429377536,
  "created_at" : "2012-05-01 14:08:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3075\u3041\u307C\u3063\u3066\u304F\u308C\u305F\u4EBA\u3092\u5148\u77403\u4EBA\u3060\u3051\u52DD\u624B\u306A\u5370\u8C61\u3067\u7D39\u4ECB\u3057\u3066\u307F\u308B",
      "indices" : [ 17, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197325108237443072",
  "text" : "\u4FBF\u4E57\u3002\u3067\u3082\u3001\u591A\u3044\u3068\u9762\u5012\u3060\u3057\u306D\u3047\u3002 #\u3075\u3041\u307C\u3063\u3066\u304F\u308C\u305F\u4EBA\u3092\u5148\u77403\u4EBA\u3060\u3051\u52DD\u624B\u306A\u5370\u8C61\u3067\u7D39\u4ECB\u3057\u3066\u307F\u308B",
  "id" : 197325108237443072,
  "created_at" : "2012-05-01 14:02:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u305D\u3082\u305D\u3082\u9AEA\u578B\u306A\u3093\u304B\u3067\u5909\u308F\u308B\u306E\u306F\u7B2C\u4E00\u5370\u8C61\u3060\u3051\u3058\u3083\u3068\u304B\u601D\u3063\u3061\u3083\u3046",
      "indices" : [ 25, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197323598527078400",
  "text" : "\u3044\u3063\u3064\u3082\u30A4\u30E1\u30C1\u30A7\u30F3\u3057\u305F\u3044\u306A\u3041\u3068\u601D\u3044\u306A\u304C\u3089\u73FE\u72B6\u7DAD\u6301 #\u305D\u3082\u305D\u3082\u9AEA\u578B\u306A\u3093\u304B\u3067\u5909\u308F\u308B\u306E\u306F\u7B2C\u4E00\u5370\u8C61\u3060\u3051\u3058\u3083\u3068\u304B\u601D\u3063\u3061\u3083\u3046",
  "id" : 197323598527078400,
  "created_at" : "2012-05-01 13:56:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197323257899257857",
  "text" : "\u305A\u30FC\u3063\u3068\u30DF\u30C7\u30A3\u30A2\u30E0\u3060\u3057\u601D\u3044\u5207\u3063\u3066\u30B7\u30E7\u30FC\u30C8\u306B\u3057\u3066\u307F\u307E\u3057\u3087\u3046\u304B",
  "id" : 197323257899257857,
  "created_at" : "2012-05-01 13:55:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 19, 34 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197319679201648642",
  "geo" : { },
  "id_str" : "197319781286805504",
  "in_reply_to_user_id" : 97121312,
  "text" : "\u3055\u304B\u306A\u304F\u3093\u30DE\u30B8\u9752\u9B5A\uFF08\u8DB3\u304C\u901F\u3044\uFF09 QT @haruhalcyoncat: \u3055\u304B\u306A\u304F\u3093\u306F\u30DE\u30B8\u597D\u9752\u5E74\u3002",
  "id" : 197319781286805504,
  "in_reply_to_status_id" : 197319679201648642,
  "created_at" : "2012-05-01 13:41:16 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30C0\u30A4\u30BD\u30F3\u6570\u5B66\u5316\u8A08\u753B",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "\u9AD8\u5EA6\u306B\u982D\u304C\u60AA\u3044",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197319427392417792",
  "text" : "#\u30C0\u30A4\u30BD\u30F3\u6570\u5B66\u5316\u8A08\u753B #\u9AD8\u5EA6\u306B\u982D\u304C\u60AA\u3044",
  "id" : 197319427392417792,
  "created_at" : "2012-05-01 13:39:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yunus bal\u0131k\u00E7\u0131",
      "screen_name" : "yuno_49",
      "indices" : [ 0, 8 ],
      "id_str" : "1420722181",
      "id" : 1420722181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197318876525105152",
  "geo" : { },
  "id_str" : "197319302809001984",
  "in_reply_to_user_id" : 543955214,
  "text" : "@yuno_49 \uFF08\u77E5\u3089\u306A\u304B\u3063\u305F\u306E\u3067\u8ABF\u3079\u3066\u307F\u307E\u3057\u305F\u304C\uFF09\u3053\u308C\u305D\u306E\u307E\u307E\u4F7F\u3063\u305F\u3089\u7D50\u69CB\u3057\u3063\u304B\u308A\u66F8\u3051\u305D\u3046\u3067\u3059\u306D\uFF01",
  "id" : 197319302809001984,
  "in_reply_to_status_id" : 197318876525105152,
  "created_at" : "2012-05-01 13:39:22 +0000",
  "in_reply_to_screen_name" : "ntnt4174",
  "in_reply_to_user_id_str" : "543955214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 20, 31 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197318535767273472",
  "geo" : { },
  "id_str" : "197318891620413441",
  "in_reply_to_user_id" : 230481483,
  "text" : "\u6253\u3061\u89E3\u3051\u308B\u524D\u306B\u8ABF\u5B50\u306B\u4E57\u308B\u4EBA\u3063\u3066\u2026 QT @sakanafsku: \u3061\u3083\u3089\u305D\u3046\u3068\u304B\u521D\u3081\u3066\u8A00\u308F\u308C\u305F\uFF0E\u30C1\u30E3\u30E9\u3044\u3063\u3066\u3044\u3046\u304B\uFF0C\u6253\u3061\u89E3\u3051\u308B\u3068\u8ABF\u5B50\u306B\u4E57\u308B\u30BF\u30A4\u30D7\u3060\u3068\u81EA\u5206\u3067\u306F\u601D\u3063\u3066\u308B\uFF0E\u6253\u3061\u89E3\u3051\u308B\u307E\u3067\u306F\u304A\u3069\u304A\u3069\u3057\u3066\u308B\uFF0E",
  "id" : 197318891620413441,
  "in_reply_to_status_id" : 197318535767273472,
  "created_at" : "2012-05-01 13:37:44 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197318749148291072",
  "text" : "\u5438\u5F15\u529B\u51FD\u6570\u307F\u305F\u3044\u306A\u3082\u306E\u3092\u5B9A\u7FA9\u3057\u3066\u4E91\u3005",
  "id" : 197318749148291072,
  "created_at" : "2012-05-01 13:37:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 0, 7 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197318414782574592",
  "geo" : { },
  "id_str" : "197318613315764224",
  "in_reply_to_user_id" : 50640629,
  "text" : "@igaris \u300C\u5438\u5F15\u529B\u304C\u4E0D\u5909\u300D\u306E\u3042\u305F\u308A\u3092\u3082\u3046\u3061\u3087\u3044\u306A\u3093\u3068\u304B\u2026",
  "id" : 197318613315764224,
  "in_reply_to_status_id" : 197318414782574592,
  "created_at" : "2012-05-01 13:36:38 +0000",
  "in_reply_to_screen_name" : "igaris",
  "in_reply_to_user_id_str" : "50640629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197318320607866882",
  "text" : "\u660E\u65E5\u9AEA\u3092\u5207\u308A\u306B\u884C\u3051\u308B\u304B\u306A\uFF1F",
  "id" : 197318320607866882,
  "created_at" : "2012-05-01 13:35:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E38\u6295\u3052",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197317739612864513",
  "text" : "\u300C\u5438\u5F15\u529B\u306E\u5909\u308F\u3089\u306A\u3044\u305F\u3060\u4E00\u3064\u306E\u6383\u9664\u6A5F\u300D\u3063\u3066\u6570\u5B66\u7684\u306B\u66F8\u3044\u305F\u3089\u3069\u3046\u306A\u308B\u3093\u3060\u308D\u3046 #\u4E38\u6295\u3052",
  "id" : 197317739612864513,
  "created_at" : "2012-05-01 13:33:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u9069\u5F53",
      "indices" : [ 35, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197316986886307840",
  "text" : "\u300E\u9154\u3044\u3069\u308C\uFF01\u30CB\u30E3\u30EB\u5B50\u3055\u3093\u300F\u3092\u9154\u3063\u305F\u4E2D\u306E\u4EBA\u306B\u3084\u3089\u305B\u305F\u3089\u304D\u3063\u3068\u304A\u3082\u3057\u308D\u3044 #\u9069\u5F53",
  "id" : 197316986886307840,
  "created_at" : "2012-05-01 13:30:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197315683124649984",
  "text" : "\u56DB\u56FD\u3082\u4E5D\u5DDE\u3082\u826F\u304F\u8003\u3048\u305F\u3089\u6D77\uFF08\u306E\uFF09\u5916\u306A\u306E\u3067\u306F\uFF1F",
  "id" : 197315683124649984,
  "created_at" : "2012-05-01 13:24:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197315241430888448",
  "text" : "\u4E5D\u5DDE\u3067\u3075\u3041\u307C\u3063\u3066\u304F\u308B\u3001\u5438\u53CE\u529B\u306E\u5909\u308F\u3089\u306A\u3044\u305F\u3060\u4E00\u4EBA\u306E\u56DB\u6642\u3055\u3093",
  "id" : 197315241430888448,
  "created_at" : "2012-05-01 13:23:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197314701963689984",
  "text" : "\u6C96\u7E04\u3082\u307E\u3060\u672A\u8E0F",
  "id" : 197314701963689984,
  "created_at" : "2012-05-01 13:21:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197314650814164992",
  "text" : "\u4ECA\u306F\u6D77\u5916\u3088\u308A\u3082\u4E5D\u5DDE\u56DB\u56FD\u306B\u884C\u304D\u305F\u3044\u306E\u3067\u3042\u308B\u3002",
  "id" : 197314650814164992,
  "created_at" : "2012-05-01 13:20:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197314435973513216",
  "text" : "\u601D\u3046\u306B\u5BC6\u5BA4\u3001\u9AD8\u901F\u3067\u79FB\u52D5\u3059\u308B\u304B\u3089\u3044\u3051\u306A\u3044\u3093\u3060\u3088\u306D\u3002\u8239\u3067\u6D77\u5916\u3068\u304B\u884C\u3063\u3066\u307F\u305F\u3089\u3044\u3044\u306E\u304B\u306A\u3002",
  "id" : 197314435973513216,
  "created_at" : "2012-05-01 13:20:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197314166581755904",
  "text" : "\u81EA\u5206\u306B\u6271\u3048\u308B\u8DDD\u96E2\u611F\u306A\u3093\u3066\u305F\u304B\u304C\u77E5\u308C\u3066\u3044\u308B\u304B\u3089\u306A\u30FC\u6771\u4EAC\u4EAC\u90FD\u9593\u3067\u65E2\u306B\u5B9F\u611F\u5931\u3046\u3057\u2026",
  "id" : 197314166581755904,
  "created_at" : "2012-05-01 13:18:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197313848880013313",
  "text" : "\u89AA\u7236\u306B\u300C\u5B66\u751F\u306E\u9593\u306B\u6D77\u5916\u306B\u884C\u3051\u3001\u898B\u65B9\u304C\u5909\u308F\u308B\u305E\u300D\u3068\u8A00\u308F\u308C\u305F\u3057\u78BA\u304B\u306B\u305D\u3046\u3060\u3068\u601D\u3063\u305F\u304C\u8A00\u308F\u308C\u3066\u884C\u304F\u3088\u3046\u306A\u30BD\u30EC\u306B\u610F\u5473\u306F\u3042\u308B\u306E\u304B\u306A\u3041\u2026",
  "id" : 197313848880013313,
  "created_at" : "2012-05-01 13:17:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5A9A\u3073\u7121\u3057\u3067\u4E00\u756A\u9762\u767D\u3044\u3068\u601D\u3046\u30C4\u30A4\u30C3\u30BF\u30E9\u30FC\u6319\u3052\u3066\u3051",
      "indices" : [ 15, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197312153760448512",
  "text" : "\u3069\u3046\u8003\u3048\u3066\u3082\u5B87\u5B99\u8CE2\u8005\u3055\u3093\u4E00\u629E #\u5A9A\u3073\u7121\u3057\u3067\u4E00\u756A\u9762\u767D\u3044\u3068\u601D\u3046\u30C4\u30A4\u30C3\u30BF\u30E9\u30FC\u6319\u3052\u3066\u3051",
  "id" : 197312153760448512,
  "created_at" : "2012-05-01 13:10:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197311949359419392",
  "text" : "\u3046\u3060\u3055\u3093\u304C\u5B8C\u5168\u306B\u3044\u308D\u3044\u308D\u3068\u30E9\u30B9\u30DC\u30B9\u306B\u306A\u3063\u3066\u3057\u307E\u3046",
  "id" : 197311949359419392,
  "created_at" : "2012-05-01 13:10:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197311883114586112",
  "text" : "RT @kagakuma: \u30CB\u30B3\u30CB\u30B3\u52D5\u753Bzero\u3063\u3066\u4F55\u3002uda\u3055\u3093\u306E\u56DE\u3057\u8005\u306A\u306E\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197311834041237504",
    "text" : "\u30CB\u30B3\u30CB\u30B3\u52D5\u753Bzero\u3063\u3066\u4F55\u3002uda\u3055\u3093\u306E\u56DE\u3057\u8005\u306A\u306E\u3002",
    "id" : 197311834041237504,
    "created_at" : "2012-05-01 13:09:41 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 197311883114586112,
  "created_at" : "2012-05-01 13:09:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197311722451779587",
  "text" : "\u81EA\u5206\u304C\u89E3\u3063\u3066\u3044\u306A\u3044\u306E\u304C\u3044\u3051\u306A\u3044\u3002\u3060\u304B\u3089\u3053\u305D\u3057\u3093\u3069\u3044\u306E\u3060\u304C\u3002",
  "id" : 197311722451779587,
  "created_at" : "2012-05-01 13:09:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197311639698157568",
  "text" : "\u3068\u3044\u3046\u304B\u4E0D\u5F53\u306A\u5ACC\u304C\u3089\u305B\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u308C\u3069\u306D\u3001\u3069\u3063\u3061\u3082\u3002",
  "id" : 197311639698157568,
  "created_at" : "2012-05-01 13:08:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3042\u304F\u307E\u3067\u500B\u4EBA\u306E\u611F\u60F3\u3067\u3059",
      "indices" : [ 27, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197311259757133825",
  "text" : "\u30DE\u30B9\u30CF\u30E9\u306F\u7269\u7406\u653B\u6483\u3060\u304C\u30D5\u30A3\u30ED\u30CF\u30E9\u306F\u7CBE\u795E\u653B\u6483\u306A\u306E\u3067\u3042\u308B #\u3042\u304F\u307E\u3067\u500B\u4EBA\u306E\u611F\u60F3\u3067\u3059",
  "id" : 197311259757133825,
  "created_at" : "2012-05-01 13:07:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197311146745798656",
  "text" : "\u30DE\u30B9\u30CF\u30E9\u306F\u6016\u3044\u3002\u305F\u3057\u304B\u306B\u6016\u3044\u3002\u3067\u3082\u30D5\u30A3\u30ED\u30CF\u30E9\u3060\u3063\u3066\u78BA\u304B\u306B\u6016\u3044\u3002",
  "id" : 197311146745798656,
  "created_at" : "2012-05-01 13:06:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 20, 28 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KU_mahjang",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/iwfRnVtO",
      "expanded_url" : "http:\/\/p.ybt.jp\/maucha_\/4f9d594ae08c3.jpg",
      "display_url" : "p.ybt.jp\/maucha_\/4f9d59\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197305647459614720",
  "text" : "\u4ECA\u66F4\u898B\u305F\u304C\u4E3B\u50AC\u8005\u306E\u5727\u5012\u7684\u6557\u5317\u611F\u2026 RT @maucha_: \u5065\u5168\u9EBB\u96C0\u30AA\u30D5\u306E\u7D50\u679C #KU_mahjang http:\/\/t.co\/iwfRnVtO",
  "id" : 197305647459614720,
  "created_at" : "2012-05-01 12:45:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197298207481532416",
  "text" : "\u3053\u306E\u524D\u6982\u8981\u306F\u8AAC\u660E\u3057\u3066\u3082\u3089\u3063\u305F\u304C\u81EA\u5206\u306E\u7406\u89E3\u3058\u3083\u6587\u7AE0\u306B\u306A\u3089\u306C",
  "id" : 197298207481532416,
  "created_at" : "2012-05-01 12:15:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7121\u8336\u632F\u308A",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197298096298921984",
  "text" : "\u8AB0\u304B\u201D\u30A8\u30EC\u30F3\u30D5\u30A7\u30B9\u30C8\u306E\u5B9A\u7406\u201D\u3092\uFF12\u884C\u304F\u3089\u3044\u3067\u5927\u96D1\u628A\u306B\u8AAC\u660E\u3057\u3066\u304F\u308C #\u7121\u8336\u632F\u308A",
  "id" : 197298096298921984,
  "created_at" : "2012-05-01 12:15:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197297927880843265",
  "text" : "\u8D77\u52D5\u3057\u3061\u3083\u3063\u305F\u3002\u3061\u3083\u3093\u3068\u7406\u7531\u3042\u308B\u3051\u3069\u3002",
  "id" : 197297927880843265,
  "created_at" : "2012-05-01 12:14:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "sm9151765",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/3oh872Zi",
      "expanded_url" : "http:\/\/nico.ms\/sm9151765",
      "display_url" : "nico.ms\/sm9151765"
    } ]
  },
  "geo" : { },
  "id_str" : "197296704427532288",
  "text" : "\u3010\u30D8\u30C3\u30C9\u30D5\u30A9\u30F3\u63A8\u5968\u3011\u30B5\u30A4\u30EC\u30F3\u3000\u540C\u6642\u518D\u751F\u3010LR\u5225\u3005\u30D0\u30FC\u30B8\u30E7\u30F3\u3011 (6:17) #nicovideo #sm9151765 http:\/\/t.co\/3oh872Zi\u3000\u30A2\u30B8\u30AB\u30F3\u597D\u304D\u306A\u3089\u3053\u308C\u306F\u9CE5\u808C",
  "id" : 197296704427532288,
  "created_at" : "2012-05-01 12:09:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197294396167819265",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 197294396167819265,
  "created_at" : "2012-05-01 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u81EA\u5236",
      "indices" : [ 16, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197288763557285888",
  "text" : "\uFF34\uFF57\uFF45\uFF45\uFF4E\u843D\u3068\u3057\u307E\u3059\uFF01\uFF01\uFF01\uFF01\uFF01 #\u81EA\u5236",
  "id" : 197288763557285888,
  "created_at" : "2012-05-01 11:38:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197288486288621568",
  "text" : "\u3055\u3066\u3055\u3066\u8AB2\u984C\u7D42\u308F\u3089\u305B\u308B\u3088",
  "id" : 197288486288621568,
  "created_at" : "2012-05-01 11:36:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197288034192990208",
  "text" : "\u805E\u3053\u3048\u308B\u3063\u3066\u306A\u3093\u306A\u3093\u3060",
  "id" : 197288034192990208,
  "created_at" : "2012-05-01 11:35:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197287550828814337",
  "text" : "\u306A\u306B\u3053\u308C\u53CD\u8A3C\u51FA\u6765\u308B\u306E\uFF1F",
  "id" : 197287550828814337,
  "created_at" : "2012-05-01 11:33:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rugby180\uFF05",
      "screen_name" : "horigon02",
      "indices" : [ 3, 13 ],
      "id_str" : "340769030",
      "id" : 340769030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E00\u756A\u3059\u3052\u3047w\u3063\u3066\u306A\u308B\u8C46\u77E5\u8B58\u8A00\u3063\u305F\u5974\u304C\u512A\u52DD",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197287446881386496",
  "text" : "RT @horigon02: \u75C5\u9662\u3067\u4EA1\u304F\u306A\u3063\u305F\u6642\u3001\u533B\u8005\u304C\u300C\u3054\u81E8\u7D42\u3067\u3059\u300D\u3068\u8A00\u3046\u304C\u3001\u6B7B\u3093\u3060\u4EBA\u9593\u306F\u305D\u308C\u3092\u805E\u3044\u3066\u3044\u308B\u3089\u3057\u3044\u3002\u4EBA\u9593\u304C\u6B7B\u306C\u6642\u3001\u8074\u899A\u304C\u4E00\u756A\u6700\u5F8C\u307E\u3067\u6B8B\u3063\u3066\u3044\u308B\u3093\u3060\u3068\u304B\u3002\u3060\u304B\u3089\u81EA\u5206\u306E\u89AA\u304C\u6B7B\u306C\u3068\u304D\u306F\u3001\u5FC3\u62CD\u505C\u6B62\u97F3\u306E\u5F8C\u300C\u3042\u308A\u304C\u3068\u3046\u300D\u3092\u5148\u306B\u8A00\u3046\u3079\u304D\u3002\u805E\u3053\u3048\u308B\u5185\u306B\u3002\u3000#\u4E00\u756A\u3059\u3052\u3047w\u3063 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u4E00\u756A\u3059\u3052\u3047w\u3063\u3066\u306A\u308B\u8C46\u77E5\u8B58\u8A00\u3063\u305F\u5974\u304C\u512A\u52DD",
        "indices" : [ 113, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "186791887083016192",
    "text" : "\u75C5\u9662\u3067\u4EA1\u304F\u306A\u3063\u305F\u6642\u3001\u533B\u8005\u304C\u300C\u3054\u81E8\u7D42\u3067\u3059\u300D\u3068\u8A00\u3046\u304C\u3001\u6B7B\u3093\u3060\u4EBA\u9593\u306F\u305D\u308C\u3092\u805E\u3044\u3066\u3044\u308B\u3089\u3057\u3044\u3002\u4EBA\u9593\u304C\u6B7B\u306C\u6642\u3001\u8074\u899A\u304C\u4E00\u756A\u6700\u5F8C\u307E\u3067\u6B8B\u3063\u3066\u3044\u308B\u3093\u3060\u3068\u304B\u3002\u3060\u304B\u3089\u81EA\u5206\u306E\u89AA\u304C\u6B7B\u306C\u3068\u304D\u306F\u3001\u5FC3\u62CD\u505C\u6B62\u97F3\u306E\u5F8C\u300C\u3042\u308A\u304C\u3068\u3046\u300D\u3092\u5148\u306B\u8A00\u3046\u3079\u304D\u3002\u805E\u3053\u3048\u308B\u5185\u306B\u3002\u3000#\u4E00\u756A\u3059\u3052\u3047w\u3063\u3066\u306A\u308B\u8C46\u77E5\u8B58\u8A00\u3063\u305F\u5974\u304C\u512A\u52DD\"",
    "id" : 186791887083016192,
    "created_at" : "2012-04-02 12:27:10 +0000",
    "user" : {
      "name" : "rugby180\uFF05",
      "screen_name" : "horigon02",
      "protected" : false,
      "id_str" : "340769030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2211408753\/7Mhl5HGj_normal",
      "id" : 340769030,
      "verified" : false
    }
  },
  "id" : 197287446881386496,
  "created_at" : "2012-05-01 11:32:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197286497404190720",
  "text" : "\u6F14\u628020\u6642\u904E\u304E\u307E\u3067\u3063\u3066\uFF4D\uFF4A\uFF4B\uFF59",
  "id" : 197286497404190720,
  "created_at" : "2012-05-01 11:29:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197273867369197569",
  "text" : "\u5E30\u5B85\u3057\u3066\u3044\u308B",
  "id" : 197273867369197569,
  "created_at" : "2012-05-01 10:38:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197246420221313024",
  "text" : "\u3084\u3063\u3068\u4EAC\u90FD",
  "id" : 197246420221313024,
  "created_at" : "2012-05-01 08:49:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 6, 17 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197237660434178048",
  "text" : "\u3048\u3063 RT @noukoknows: \u30DD\u30F3\u30C7\u30EA\u30F3\u30B0\u98DF\u3079\u305F\u3053\u3068\u306A\u3044\u3051\u3069\u304A\u3044\u3057\u3044\u306E\u304B\u306A\u3002",
  "id" : 197237660434178048,
  "created_at" : "2012-05-01 08:14:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197237341222481920",
  "text" : "\u306A\u3054\u3084",
  "id" : 197237341222481920,
  "created_at" : "2012-05-01 08:13:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197232652154187778",
  "text" : "\u3042\u3068\u306F\u5BB6\u3067\u3084\u308D\u3046(^^)(^^)(^^)",
  "id" : 197232652154187778,
  "created_at" : "2012-05-01 07:55:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197231987621236736",
  "text" : "\u65B0\u5E79\u7DDA\u3067\u8AB2\u984C\u3084\u3063\u3066\u305F\u3089\u9154\u3063\u3066\u304D\u305F",
  "id" : 197231987621236736,
  "created_at" : "2012-05-01 07:52:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u307F\u3085",
      "screen_name" : "kamyuri96",
      "indices" : [ 0, 10 ],
      "id_str" : "311187890",
      "id" : 311187890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197223846208741376",
  "geo" : { },
  "id_str" : "197224193614561280",
  "in_reply_to_user_id" : 311187890,
  "text" : "@kamyuri96 \u307E\u3046\u3061\u3083\u304C\u4ECA\u5F8C\u4EAC\u5973\u3092\u540D\u4E57\u308B\u30A2\u30AB\u30A6\u30F3\u30C8\u3092\u4FE1\u3058\u3089\u308C\u306A\u304F\u306A\u308B\u3088\u3046\u306B\u91CF\u7523\u30EF\u30F3\u30C1\u30E3\u30F3",
  "id" : 197224193614561280,
  "in_reply_to_status_id" : 197223846208741376,
  "created_at" : "2012-05-01 07:21:26 +0000",
  "in_reply_to_screen_name" : "kamyuri96",
  "in_reply_to_user_id_str" : "311187890",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197223532961333248",
  "text" : "\u6163\u7528\u3060\u3088\uFF01",
  "id" : 197223532961333248,
  "created_at" : "2012-05-01 07:18:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197223390661193728",
  "text" : "\u5BDB\u5BB9\u3063\u3066\u306A\u3093\u3060\u3088\u3001\u3084\u3055\u3057\u3044\u306E\u304B\u3088",
  "id" : 197223390661193728,
  "created_at" : "2012-05-01 07:18:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\uFF10\u306F\u81EA\u7136\u6570",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197223175078158336",
  "text" : "zero\u3068\u3064\u304F\u82F1\u8A9E\u306E\u5BDB\u5BB9\u8868\u73FE\u306B\u306F #\uFF10\u306F\u81EA\u7136\u6570 \u306E\u7CBE\u795E\u304C\u898B\u3048\u304B\u304F\u308C\u3059\u308B\u3093\u3067\u3059\u304B\u306D",
  "id" : 197223175078158336,
  "created_at" : "2012-05-01 07:17:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\uFF10\u306F\u81EA\u7136\u6570",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "\u306A\u306E\u306B\u8AAC\u660E\u306F\uFF11\u304B\u3089",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197222625586593793",
  "text" : "patient zero\n\uFF11\u3014\u3042\u308B\u75C5\u6C17\u306E\u3015\u6700\u521D\u306E\u60A3\u8005\uFF64\u60A3\u8005\u7B2C1\u53F7\n\uFF12\u3008\u7C73\u3009\uFF74\uFF72\uFF7D\uFF9E(\u60A3\u8005)\u7B2C1\u53F7\n\uFF13\u3014\u3042\u308B\uFF73\uFF72\uFF99\uFF7D\u306B\u3015\u6700\u521D\u306B\u611F\u67D3\u3057\u305F\uFF7A\uFF9D\uFF8B\uFF9F\uFF6D\uFF70\uFF80\n#\uFF10\u306F\u81EA\u7136\u6570\n#\u306A\u306E\u306B\u8AAC\u660E\u306F\uFF11\u304B\u3089",
  "id" : 197222625586593793,
  "created_at" : "2012-05-01 07:15:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197211649814429696",
  "text" : "\u304D\u3087\u3046\u3068\u306E\u3066\u3093\u304D\u306F\u3069\u3046\u3067\u3059\uFF1F",
  "id" : 197211649814429696,
  "created_at" : "2012-05-01 06:31:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197211435560992768",
  "text" : "\u767A",
  "id" : 197211435560992768,
  "created_at" : "2012-05-01 06:30:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197207476989472768",
  "text" : "\u8584\u3044\u670D\u306F\u597D\u304D\u3060",
  "id" : 197207476989472768,
  "created_at" : "2012-05-01 06:15:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197207358387134464",
  "text" : "\u305D\u3046\u3044\u3084\u30AF\u30FC\u30EB\u30D3\u30B8\u30A3\u306A\u30B8\u30E3\u30B1\u30C3\u30C8\u3092\u8CB7\u3063\u305F",
  "id" : 197207358387134464,
  "created_at" : "2012-05-01 06:14:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197207218301583360",
  "text" : "\u65B0\u5E79\u7DDA\u3067\u6F14\u7FD2\u3092\u3084\u308B\u3053\u3068\u3067\u610F\u8B58\u306E\u9AD8\u3055\u3092\u6F14\u51FA\u304B\u3064\u6642\u9593\u306E\u52B9\u7387\u5316\u3092\u56F3\u308B",
  "id" : 197207218301583360,
  "created_at" : "2012-05-01 06:13:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197206798825037824",
  "text" : "\u3042\u3044\u3071\u3063\u3069\u3082\u8CB7\u3063\u3061\u3083\u3046\u3082\u3093\u306D",
  "id" : 197206798825037824,
  "created_at" : "2012-05-01 06:12:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197206653886664705",
  "text" : "\u8AA4\u5B57\u3072\u3063\u3069\u3044\u306A\u4ECA\u65E5",
  "id" : 197206653886664705,
  "created_at" : "2012-05-01 06:11:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197206571141439488",
  "text" : "\u79FB\u884C",
  "id" : 197206571141439488,
  "created_at" : "2012-05-01 06:11:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197206517466923008",
  "text" : "\u305D\u3057\u3066iPhone\u3078\u306E\u4EE5\u964D\u306F\u4E00\u9031\u9593\u5EF6\u671F",
  "id" : 197206517466923008,
  "created_at" : "2012-05-01 06:11:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197205508489359360",
  "text" : "\u4F59\u88D5\u3092\u307F\u306630\u5206\u306E\u96FB\u8ECA\u306B\u3057\u305F\u304C10\u5206\u767A\u3067\u3082\u826F\u304B\u3063\u305F\u306A",
  "id" : 197205508489359360,
  "created_at" : "2012-05-01 06:07:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197202646879322112",
  "text" : "\u4E38\u306E\u5185\u3067\u30AF\u30EA\u30FC\u30E0\u30D6\u30EA\u30E5\u30EC\u3068\u304B\u98DF\u3079\u3066\u3057\u307E\u3063\u305F",
  "id" : 197202646879322112,
  "created_at" : "2012-05-01 05:55:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CompactHausdorff\u5C71\u7530",
      "screen_name" : "NoriMathTp",
      "indices" : [ 23, 34 ],
      "id_str" : "231358679",
      "id" : 231358679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197193891592683520",
  "geo" : { },
  "id_str" : "197194448315228160",
  "in_reply_to_user_id" : 231358679,
  "text" : "\u2026\u52A9\u3051\u306A\u3044\u3002\u541B\u304C\u52DD\u624B\u306B\u52A9\u304B\u308B\u3060\u3051\u3060\u3088\u3002 QT @NoriMathTp: \u306A\u30FC\u3067\u3053\u30FC\u3060\u3088\u3049\u3045",
  "id" : 197194448315228160,
  "in_reply_to_status_id" : 197193891592683520,
  "created_at" : "2012-05-01 05:23:14 +0000",
  "in_reply_to_screen_name" : "NoriMathTp",
  "in_reply_to_user_id_str" : "231358679",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197193425785860096",
  "text" : "\u3060\u3044\u305F\u3044\u4ECA\u65E5\u660E\u65E5\u3068\u6388\u696D\u3042\u308B\u306E\u304C\u304A\u304B\u3057\u3044",
  "id" : 197193425785860096,
  "created_at" : "2012-05-01 05:19:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 10, 20 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197192964953489408",
  "geo" : { },
  "id_str" : "197193147992911873",
  "in_reply_to_user_id" : 155546700,
  "text" : "\u00D7\u304B\u3089\u25CB\u306A\u3089 QT @end313124: \u30EA\u30CB\u30A2\u30E2\u30FC\u30BF\u30FC\u30AB\u30FC\u304B\u3089\uFF14\u9650\u51FA\u308C\u308B\u304B\u3082",
  "id" : 197193147992911873,
  "in_reply_to_status_id" : 197192964953489408,
  "created_at" : "2012-05-01 05:18:04 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197192964953489408",
  "text" : "\u30EA\u30CB\u30A2\u30E2\u30FC\u30BF\u30FC\u30AB\u30FC\u304B\u3089\uFF14\u9650\u51FA\u308C\u308B\u304B\u3082",
  "id" : 197192964953489408,
  "created_at" : "2012-05-01 05:17:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D8\u30EA\u30B3\u30D7\u30BF\u30FC\u306A\u3089\u30EF\u30F3\u30C1\u30E3\u30F3",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197192616696225793",
  "geo" : { },
  "id_str" : "197192831318757376",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u7269\u7406\u7684\u306B\u3076\u3063\u3061\u4EE5\u5916\u306E\u9078\u629E\u80A2\u304C\u306A\u3044 #\u30D8\u30EA\u30B3\u30D7\u30BF\u30FC\u306A\u3089\u30EF\u30F3\u30C1\u30E3\u30F3",
  "id" : 197192831318757376,
  "in_reply_to_status_id" : 197192616696225793,
  "created_at" : "2012-05-01 05:16:49 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197192531165978625",
  "text" : "\u304A\u3063\u3061\u3083\u306E\u3063\u307F\u305A\u3063",
  "id" : 197192531165978625,
  "created_at" : "2012-05-01 05:15:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 16, 24 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7C89\u5875\u7206\u767A\u3054\u3063\u3053",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "\u3068\u306F",
      "indices" : [ 9, 12 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197190926530125826",
  "geo" : { },
  "id_str" : "197191645706461184",
  "in_reply_to_user_id" : 16929336,
  "text" : "#\u7C89\u5875\u7206\u767A\u3054\u3063\u3053 #\u3068\u306F QT @shigmax: \u30B3\u30F3\u30ED\u3067\u7C89\u5875\u7206\u767A\u3054\u3063\u3053\u3057\u3066\u305F\u3089\u7740\u706B\u88C5\u7F6E\u52D5\u304B\u306A\u304F\u306A\u3063\u305F",
  "id" : 197191645706461184,
  "in_reply_to_status_id" : 197190926530125826,
  "created_at" : "2012-05-01 05:12:06 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E86\u89E3\u3057\u305F",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197191285159886849",
  "text" : "\u7236\u89AA\u3068\u306E\u30E1\u30FC\u30EB\u306B\u300C\u51CC\u99D5\u3057\u305F\u300D\u3063\u3066\u9001\u308A\u305D\u3046\u306B\u306A\u3063\u305F #\u4E86\u89E3\u3057\u305F",
  "id" : 197191285159886849,
  "created_at" : "2012-05-01 05:10:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u305D\u3082\u305D\u3082",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197187811928059905",
  "text" : "(UT\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u9054\u306F\u69CB\u3063\u3066\u304F\u308C\u308B\u306E\u304B\u306A) #\u305D\u3082\u305D\u3082",
  "id" : 197187811928059905,
  "created_at" : "2012-05-01 04:56:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197187248767254528",
  "text" : "\u4ECA\u56DE\u306FUT\u306B\u904A\u3073\u306B\u884C\u304F\u6687\u304C\u306A\u304B\u3063\u305F\u306E\u304C\u6B8B\u5FF5",
  "id" : 197187248767254528,
  "created_at" : "2012-05-01 04:54:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197187117405843456",
  "text" : "\u897F\u837B\u304B\u3089\u6771\u4EAC\u99C5\u306B",
  "id" : 197187117405843456,
  "created_at" : "2012-05-01 04:54:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]