Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 10, 21 ],
      "id_str" : "229752118",
      "id" : 229752118
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 22, 33 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 34, 43 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119640113478254592",
  "geo" : { },
  "id_str" : "119650201404321792",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 @nisehorrrn @magokoro84 @akeopyaa \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 119650201404321792,
  "in_reply_to_status_id" : 119640113478254592,
  "created_at" : "2011-09-30 05:50:05 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119636355633520640",
  "text" : "\u30DE\u30C3\u30C4\u306A\u3046",
  "id" : 119636355633520640,
  "created_at" : "2011-09-30 04:55:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119626970442113024",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u8272\u3093\u306A\u306E\u98DF\u3079\u308C\u3066\u3046\u3089\u3084\u307E\u3057\u3044\u3088\u3002",
  "id" : 119626970442113024,
  "created_at" : "2011-09-30 04:17:46 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119625858884440064",
  "geo" : { },
  "id_str" : "119626064669573121",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u897F\u306B\u6771\u306B\u5FD9\u3057\u3044\u306D\u3047",
  "id" : 119626064669573121,
  "in_reply_to_status_id" : 119625858884440064,
  "created_at" : "2011-09-30 04:14:11 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119625519921770497",
  "geo" : { },
  "id_str" : "119625822087819264",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u6771\u4EAC\u99C5\u306B\u3044\u308B\u306E\uFF1F",
  "id" : 119625822087819264,
  "in_reply_to_status_id" : 119625519921770497,
  "created_at" : "2011-09-30 04:13:13 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119625226416963584",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 119625226416963584,
  "created_at" : "2011-09-30 04:10:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119625182234165248",
  "text" : "\u96E8\u304B\u2026\u5341\u5168\u3058\u3083\u3042\u306A\u3044\u306A\u2026",
  "id" : 119625182234165248,
  "created_at" : "2011-09-30 04:10:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D30\u5DDD\u8CB4\u82F1 #\u58F0\u306B\u51FA\u3057\u3066\u8E0F\u307F\u305F\u3044\u97FB",
      "screen_name" : "takahide_h",
      "indices" : [ 3, 14 ],
      "id_str" : "99548215",
      "id" : 99548215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119457652521697281",
  "text" : "RT @takahide_h: \u300C\u8131\u514E\u300D\u3063\u3066\u3001\u7D76\u5BFE\u5F8C\u308D\u306B\u300C\u306E\u3054\u3068\u304F\u300D\u304C\u4ED8\u304F\u3088\u306D\u3002\u300C\u8131\u514E\u98FC\u3044\u59CB\u3081\u305F\u308F\u30FC\u300D\u3068\u304B\u300C\u8131\u514E\u306E\u306C\u3044\u3050\u308B\u307F\u6B32\u3057\u3044\uFF01\u300D\u3068\u304B\u8A00\u308F\u306A\u3044\u3088\u306D\u3002\u3058\u3083\u3042\u8131\u514E\u306A\u3093\u3066\u672C\u5F53\u306F\u3044\u306A\u3044\u3063\u3066\u3053\u3068\u3058\u3083\u3093\uFF01\u307E\u3060\u62E1\u5F35\u5B50\u304C.dat\u306E\u30D5\u30A1\u30A4\u30EB\u306E\u30D5\u30A1\u30A4\u30EB\u306F\u305F\u307E\u306B\u3042\u308B\u3051\u3069\u306D\uFF01\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119444952689278977",
    "text" : "\u300C\u8131\u514E\u300D\u3063\u3066\u3001\u7D76\u5BFE\u5F8C\u308D\u306B\u300C\u306E\u3054\u3068\u304F\u300D\u304C\u4ED8\u304F\u3088\u306D\u3002\u300C\u8131\u514E\u98FC\u3044\u59CB\u3081\u305F\u308F\u30FC\u300D\u3068\u304B\u300C\u8131\u514E\u306E\u306C\u3044\u3050\u308B\u307F\u6B32\u3057\u3044\uFF01\u300D\u3068\u304B\u8A00\u308F\u306A\u3044\u3088\u306D\u3002\u3058\u3083\u3042\u8131\u514E\u306A\u3093\u3066\u672C\u5F53\u306F\u3044\u306A\u3044\u3063\u3066\u3053\u3068\u3058\u3083\u3093\uFF01\u307E\u3060\u62E1\u5F35\u5B50\u304C.dat\u306E\u30D5\u30A1\u30A4\u30EB\u306E\u30D5\u30A1\u30A4\u30EB\u306F\u305F\u307E\u306B\u3042\u308B\u3051\u3069\u306D\uFF01\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046\uFF01\u304A\u3084\u3059\u307F\uFF01",
    "id" : 119444952689278977,
    "created_at" : "2011-09-29 16:14:30 +0000",
    "user" : {
      "name" : "\u7D30\u5DDD\u8CB4\u82F1 #\u58F0\u306B\u51FA\u3057\u3066\u8E0F\u307F\u305F\u3044\u97FB",
      "screen_name" : "takahide_h",
      "protected" : false,
      "id_str" : "99548215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2018385558\/150_normal.jpg",
      "id" : 99548215,
      "verified" : false
    }
  },
  "id" : 119457652521697281,
  "created_at" : "2011-09-29 17:04:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119457575279411200",
  "text" : "\u6771\u3001\u767D\u3001\u5BFE\u3005\u3001\u6DF7\u4E00\u3001\u6DF7\u8001\u3001\u30C9\u30E9\uFF13\u2026",
  "id" : 119457575279411200,
  "created_at" : "2011-09-29 17:04:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D30\u5DDD\u8CB4\u82F1 #\u58F0\u306B\u51FA\u3057\u3066\u8E0F\u307F\u305F\u3044\u97FB",
      "screen_name" : "takahide_h",
      "indices" : [ 11, 22 ],
      "id_str" : "99548215",
      "id" : 99548215
    }, {
      "name" : "Yamashita",
      "screen_name" : "ymtk0815",
      "indices" : [ 38, 47 ],
      "id_str" : "58742967",
      "id" : 58742967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119440222709755904",
  "text" : "\u3088\u304F\u3042\u308B\u8A71\u3067\u3059 RT @takahide_h: \u6B32\u306A\u3044\u306E\u306F\u826F\u304F\u306A\u3044\u3002 RT @ymtk0815: \u300C\u6B32\u304C\u7121\u3044\u3053\u3068\u306F\u7F6A\u3060\u300D\u3068\u611F\u3058\u307E\u3057\u305F\u3002",
  "id" : 119440222709755904,
  "created_at" : "2011-09-29 15:55:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119437902856978432",
  "geo" : { },
  "id_str" : "119439786137223169",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305C\u3072\u611F\u60F3\u3092\uFF01",
  "id" : 119439786137223169,
  "in_reply_to_status_id" : 119437902856978432,
  "created_at" : "2011-09-29 15:53:58 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zekitter",
      "screen_name" : "zekitter",
      "indices" : [ 3, 12 ],
      "id_str" : "93639986",
      "id" : 93639986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119403139689496576",
  "text" : "RT @zekitter: BD\u306F\u3042\u308B\u3051\u3069\u518D\u751F\u6A5F\u5668\u304C\u306A\u3044\u72B6\u6CC1\u306E\u3053\u3068\u3092\u6A5F\u5668\u7684\u72B6\u6CC1\u3068\u547C\u3076",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119399587076243456",
    "text" : "BD\u306F\u3042\u308B\u3051\u3069\u518D\u751F\u6A5F\u5668\u304C\u306A\u3044\u72B6\u6CC1\u306E\u3053\u3068\u3092\u6A5F\u5668\u7684\u72B6\u6CC1\u3068\u547C\u3076",
    "id" : 119399587076243456,
    "created_at" : "2011-09-29 13:14:14 +0000",
    "user" : {
      "name" : "zekitter",
      "screen_name" : "zekitter",
      "protected" : false,
      "id_str" : "93639986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2698507943\/85e48a4b1c6dd44be71c82b0d6795242_normal.jpeg",
      "id" : 93639986,
      "verified" : false
    }
  },
  "id" : 119403139689496576,
  "created_at" : "2011-09-29 13:28:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3084\u3059\u304D\u304F",
      "screen_name" : "yasu_kiku1song",
      "indices" : [ 3, 18 ],
      "id_str" : "211558069",
      "id" : 211558069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119398629021724672",
  "text" : "RT @yasu_kiku1song: \u5642\u306B\u3088\u308B\u3068\u4ECA\u5E74\u306E\u6771\u5927\u306E\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\u306F12\/23\u3067\u5973\u5B50\u9AD8\u751F\u5411\u3051\u304C12\/24\u3089\u3057\u3044 \u3053\u308C\u306F\u5973\u5B50\u3092\u672C\u6C17\u3067\u547C\u3076\u6C17\u304C\u7121\u3044\u306E\u304B\u3001\u305D\u308C\u3068\u3082\u6771\u5927\u6765\u308B\u3088\u3046\u306A\u5973\u5B50\u306F\u3069\u3046\u305B\u305D\u306E\u65E5\u6687\u3084\u308D\u3063\u3066\u898B\u4E0B\u3057\u3066\u308B\u306E\u304B \u3042\u308B\u3044\u306F40\u306B\u3082\u306A\u3063\u3066\u72EC\u8EAB\u306E\u6559\u6388\u304C\u5AC9\u59AC\u306B\u307E\u307F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85663416932503552",
    "text" : "\u5642\u306B\u3088\u308B\u3068\u4ECA\u5E74\u306E\u6771\u5927\u306E\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\u306F12\/23\u3067\u5973\u5B50\u9AD8\u751F\u5411\u3051\u304C12\/24\u3089\u3057\u3044 \u3053\u308C\u306F\u5973\u5B50\u3092\u672C\u6C17\u3067\u547C\u3076\u6C17\u304C\u7121\u3044\u306E\u304B\u3001\u305D\u308C\u3068\u3082\u6771\u5927\u6765\u308B\u3088\u3046\u306A\u5973\u5B50\u306F\u3069\u3046\u305B\u305D\u306E\u65E5\u6687\u3084\u308D\u3063\u3066\u898B\u4E0B\u3057\u3066\u308B\u306E\u304B \u3042\u308B\u3044\u306F40\u306B\u3082\u306A\u3063\u3066\u72EC\u8EAB\u306E\u6559\u6388\u304C\u5AC9\u59AC\u306B\u307E\u307F\u308C\u3066\u8A2D\u5B9A\u3057\u305F\u306E\u304B",
    "id" : 85663416932503552,
    "created_at" : "2011-06-28 10:58:44 +0000",
    "user" : {
      "name" : "\u3084\u3059\u304D\u304F",
      "screen_name" : "yasu_kiku1song",
      "protected" : false,
      "id_str" : "211558069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2968106002\/e1be888efbc538dd75c380e280b22b6c_normal.jpeg",
      "id" : 211558069,
      "verified" : false
    }
  },
  "id" : 119398629021724672,
  "created_at" : "2011-09-29 13:10:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u79C1\u306B\u4F3C\u5408\u3044\u305D\u3046\u306A\u30DD\u30B1\u30E2\u30F3",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119397484165476352",
  "text" : "\u3055\u3066\u3061\u3087\u3063\u3068\u6C17\u306B\u306A\u308B\u304B\u3089\u805E\u3044\u3066\u307F\u3088\u3046\u304B #\u79C1\u306B\u4F3C\u5408\u3044\u305D\u3046\u306A\u30DD\u30B1\u30E2\u30F3",
  "id" : 119397484165476352,
  "created_at" : "2011-09-29 13:05:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119381108424056832",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 119381108424056832,
  "created_at" : "2011-09-29 12:00:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119372403276136448",
  "geo" : { },
  "id_str" : "119372958035755009",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u8C46\u4E73\u3068\u5473\u564C\u3068\u3060\u3057\u6C41\u3068\u3092\u304A\u7C73\u3068\u4E00\u7DD2\u306B\u3068\u308D\u706B\u3067\uFF13\uFF10\u5206\u307B\u3069\u3002",
  "id" : 119372958035755009,
  "in_reply_to_status_id" : 119372403276136448,
  "created_at" : "2011-09-29 11:28:25 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119371583553933312",
  "text" : "\u4ED6\u4EBA\u3088\u308A\u81EA\u5206\u304C\u5927\u4E8B\u3060\u3088\u306A\u3002\u305D\u308A\u3083\u305D\u3046\u3060\u3002",
  "id" : 119371583553933312,
  "created_at" : "2011-09-29 11:22:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7247\u5CA1K",
      "screen_name" : "kataoka_k",
      "indices" : [ 3, 13 ],
      "id_str" : "112312978",
      "id" : 112312978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/x36xwzSR",
      "expanded_url" : "http:\/\/twitpic.com\/6s9ft2",
      "display_url" : "twitpic.com\/6s9ft2"
    } ]
  },
  "geo" : { },
  "id_str" : "119371525748043776",
  "text" : "RT @kataoka_k: \u304A\u3044\u3001\u9006\uFF01 \u9006\uFF01 http:\/\/t.co\/x36xwzSR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 29 ],
        "url" : "http:\/\/t.co\/x36xwzSR",
        "expanded_url" : "http:\/\/twitpic.com\/6s9ft2",
        "display_url" : "twitpic.com\/6s9ft2"
      } ]
    },
    "geo" : { },
    "id_str" : "119348639658291200",
    "text" : "\u304A\u3044\u3001\u9006\uFF01 \u9006\uFF01 http:\/\/t.co\/x36xwzSR",
    "id" : 119348639658291200,
    "created_at" : "2011-09-29 09:51:47 +0000",
    "user" : {
      "name" : "\u7247\u5CA1K",
      "screen_name" : "kataoka_k",
      "protected" : false,
      "id_str" : "112312978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548069315484733440\/8qIL5ca6_normal.jpeg",
      "id" : 112312978,
      "verified" : false
    }
  },
  "id" : 119371525748043776,
  "created_at" : "2011-09-29 11:22:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119370590732812288",
  "text" : "\u8C46\u4E73\u7CA5\u308F\u305A\u3002\u7F8E\u5473\u3057\u304B\u3063\u305F\u3002",
  "id" : 119370590732812288,
  "created_at" : "2011-09-29 11:19:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119286999650807808",
  "text" : "\u75DB\u5FEB\u3067\u597D\u304D\u306A\u3093\u3060\u3051\u3069\u30CD\u30BF\u3068\u8A8D\u8B58\u3055\u308C\u306A\u3044\u3068\u305F\u3060\u306E\u5ACC\u306A\u4EBA\u306B\u306A\u3063\u3061\u3083\u3046\u306E\u304C\u8F9B\u3044\u6240",
  "id" : 119286999650807808,
  "created_at" : "2011-09-29 05:46:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119286763045920768",
  "text" : "\u4E09\u7559\u306B\u76F8\u5FDC\u3057\u3044\u304A\u3081\u3067\u305F\u3044\u8133\u307F\u305D\u3060\u306A\uFF08\u5929\u6C5F\u8863\u306E\u53F0\u8A5E\u3088\u308A\uFF09",
  "id" : 119286763045920768,
  "created_at" : "2011-09-29 05:45:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "indices" : [ 3, 16 ],
      "id_str" : "78523759",
      "id" : 78523759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119286505192697856",
  "text" : "RT @tatamin_ttmn: \u304A\u524D\u3089\u5927\u5B66\u30B5\u30DC\u308B\u3068\u304B\u30DE\u30B8\u3067\u3084\u3081\u3068\u3051\u3002\u306A\uFF1F\u60AA\u3044\u3053\u3068\u8A00\u308F\u306A\u3044\u304B\u3089\u3002\u6B6F\u98DF\u3044\u3057\u3070\u3063\u3066\u884C\u3051\u3002\u6388\u696D\u4E2D\u5BDD\u3066\u3066\u3082\u3044\u3044\u3001Twitter\u3057\u3066\u3066\u3082\u3044\u3044\u304B\u3089\u3002\u51FA\u5E2D\u306F\u3059\u308B\u3053\u3068\u3002\u3067\u304D\u305F\u3089\u6388\u696D\u3082\u805E\u304F\u3002\u306A\uFF1F\u9AD8\u6821\u307E\u3067\u666E\u901A\u306B\u3057\u3066\u305F\u3053\u3068\u3060\u3088\u3002\u3067\u304D\u308B\u3063\u3066\u3002\u304A\u5144\u3055\u3093\u3068\u306E\u7D04\u675F\u306A\u3002 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84046102487236608",
    "text" : "\u304A\u524D\u3089\u5927\u5B66\u30B5\u30DC\u308B\u3068\u304B\u30DE\u30B8\u3067\u3084\u3081\u3068\u3051\u3002\u306A\uFF1F\u60AA\u3044\u3053\u3068\u8A00\u308F\u306A\u3044\u304B\u3089\u3002\u6B6F\u98DF\u3044\u3057\u3070\u3063\u3066\u884C\u3051\u3002\u6388\u696D\u4E2D\u5BDD\u3066\u3066\u3082\u3044\u3044\u3001Twitter\u3057\u3066\u3066\u3082\u3044\u3044\u304B\u3089\u3002\u51FA\u5E2D\u306F\u3059\u308B\u3053\u3068\u3002\u3067\u304D\u305F\u3089\u6388\u696D\u3082\u805E\u304F\u3002\u306A\uFF1F\u9AD8\u6821\u307E\u3067\u666E\u901A\u306B\u3057\u3066\u305F\u3053\u3068\u3060\u3088\u3002\u3067\u304D\u308B\u3063\u3066\u3002\u304A\u5144\u3055\u3093\u3068\u306E\u7D04\u675F\u306A\u3002(\u5927\u5B66\u56DB\u56DE\u751F\u30FB\u4E09\u7559\u30FB25\u6B73)",
    "id" : 84046102487236608,
    "created_at" : "2011-06-23 23:52:06 +0000",
    "user" : {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "protected" : false,
      "id_str" : "78523759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603218136339337216\/1sSV3Bdp_normal.jpg",
      "id" : 78523759,
      "verified" : false
    }
  },
  "id" : 119286505192697856,
  "created_at" : "2011-09-29 05:44:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yosuke Ikeda",
      "screen_name" : "ikeikey",
      "indices" : [ 3, 11 ],
      "id_str" : "93178755",
      "id" : 93178755
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kUWfoAU3",
      "expanded_url" : "http:\/\/theinterviews.jp\/ikeikey\/1825985",
      "display_url" : "theinterviews.jp\/ikeikey\/1825985"
    } ]
  },
  "geo" : { },
  "id_str" : "119275952940384257",
  "text" : "RT @ikeikey: \u524D\u306B\u3069\u3053\u304B\u3067\u300C\u76F8\u52A0\u76F8\u4E57\u5E73\u5747\u306E\u4E0D\u7B49\u5F0F\u300D\u3092\u5EA7\u6A19\u3068\u5186\u3092\u4F7F\u3063\u3066\u8A3C\u660E\u3067\u304D\u308B\u3068\u805E\u3044\u305F\u306E\u3067\u3059\u304C\u3001\u3044\u304F\u3089\u8003\u3048\u3066\u3082\u5206\u304B\u308A\u307E\u305B\u3093\u3002\u3082\u3057\u3088\u308D\u3057\u3051\u308C\u3070\u6559\u3048\u3066\u4E0B\u3055\u3044\u3002 - ikeikey [\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA] #theinterviews http:\/\/t.co\/kUW ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "theinterviews",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/kUWfoAU3",
        "expanded_url" : "http:\/\/theinterviews.jp\/ikeikey\/1825985",
        "display_url" : "theinterviews.jp\/ikeikey\/1825985"
      } ]
    },
    "geo" : { },
    "id_str" : "119259734128852992",
    "text" : "\u524D\u306B\u3069\u3053\u304B\u3067\u300C\u76F8\u52A0\u76F8\u4E57\u5E73\u5747\u306E\u4E0D\u7B49\u5F0F\u300D\u3092\u5EA7\u6A19\u3068\u5186\u3092\u4F7F\u3063\u3066\u8A3C\u660E\u3067\u304D\u308B\u3068\u805E\u3044\u305F\u306E\u3067\u3059\u304C\u3001\u3044\u304F\u3089\u8003\u3048\u3066\u3082\u5206\u304B\u308A\u307E\u305B\u3093\u3002\u3082\u3057\u3088\u308D\u3057\u3051\u308C\u3070\u6559\u3048\u3066\u4E0B\u3055\u3044\u3002 - ikeikey [\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA] #theinterviews http:\/\/t.co\/kUWfoAU3",
    "id" : 119259734128852992,
    "created_at" : "2011-09-29 03:58:31 +0000",
    "user" : {
      "name" : "Yosuke Ikeda",
      "screen_name" : "ikeikey",
      "protected" : false,
      "id_str" : "93178755",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559205144\/IMG_0011_normal.jpg",
      "id" : 93178755,
      "verified" : false
    }
  },
  "id" : 119275952940384257,
  "created_at" : "2011-09-29 05:02:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/NDiYWKvC",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=otaks21",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119214852211359744",
  "text" : "otaks21\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/NDiYWKvC",
  "id" : 119214852211359744,
  "created_at" : "2011-09-29 01:00:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119077693160554496",
  "text" : "\u305D\u3046\u3060\u3088\u306A\u3002\uFF13\u3067\u5272\u308B\u767A\u60F3\u304C\u3042\u308B\u3093\u3060\u304B\u3089\uFF15\u3084\uFF17\u3084\uFF19\u3067\u5272\u308B\u767A\u60F3\u304C\u51FA\u3066\u304D\u3066\u3082\u826F\u304B\u3063\u305F\u3088\u306A\u2026\u3002",
  "id" : 119077693160554496,
  "created_at" : "2011-09-28 15:55:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119077313471193088",
  "text" : "@nartakio \u3059\u3063\u304B\u308A\u898B\u9003\u3057\u3066\u307E\u3057\u305F\u3002\u89E3\u308A\u3084\u3059\u3044\u56DE\u7B54\u3067\u3059\u306D\u3002\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 119077313471193088,
  "created_at" : "2011-09-28 15:53:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 43, 53 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119076385754066944",
  "text" : "\uFF10\uFF0C\uFF13\uFF0C\uFF16\uFF0C\uFF19\u306F\uFF13\u306E\u500D\u6570\u306B\u306A\u308B\u304B\u3089\u6709\u308A\u3048\u306A\u3044\u3063\u3066\u306E\u306F\u6697\u7B97\u3067\u3059\u3050\u308F\u304B\u308B\u3051\u3069\u30FB\u30FB\u30FB RT @end313124 \u3010\u554F\u984C\u3011\u7D19\u3082\u30DA\u30F3\u3082\u96FB\u5353\u3082\u4F7F\u308F\u305A\u3001\uFF12\u306E\uFF12\uFF19\u4E57\u306E\uFF19\u30B1\u30BF\u306E\u6587\u5B57\u5217\u306B\u552F\u4E00\u73FE\u308C\u306A\u3044\uFF10\uFF5E\uFF19\u306E\u6570\u5B57\u4E00\u3064\u3092\u6C42\u3081\u3088\uFF01",
  "id" : 119076385754066944,
  "created_at" : "2011-09-28 15:49:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119076005238423552",
  "text" : "\u3010\u554F\u984C\u3011\u7D19\u3082\u30DA\u30F3\u3082\u96FB\u5353\u3082\u4F7F\u308F\u305A\u3001\uFF12\u306E\uFF12\uFF19\u4E57\u306E\uFF19\u30B1\u30BF\u306E\u6587\u5B57\u5217\u306B\u552F\u4E00\u73FE\u308C\u306A\u3044\uFF10\uFF5E\uFF19\u306E\u6570\u5B57\u4E00\u3064\u3092\u6C42\u3081\u3088\uFF01",
  "id" : 119076005238423552,
  "created_at" : "2011-09-28 15:48:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119057855839088640",
  "text" : "\u5E30\u5B85",
  "id" : 119057855839088640,
  "created_at" : "2011-09-28 14:36:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119023910896410625",
  "text" : "\u96E2\u8131\u3063",
  "id" : 119023910896410625,
  "created_at" : "2011-09-28 12:21:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119023733326352384",
  "text" : "\u5B89\u5B9A\u306E\u7F8E\u5C11\u5973\u30A2\u30A4\u30B3\u30F3\u7387\u2026",
  "id" : 119023733326352384,
  "created_at" : "2011-09-28 12:20:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 15, 24 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 25, 36 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 37, 42 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 43, 50 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 51, 60 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 61, 71 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 80, 94 ],
      "id_str" : "252811894",
      "id" : 252811894
    }, {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 95, 105 ],
      "id_str" : "181342377",
      "id" : 181342377
    }, {
      "name" : "TwitPic",
      "screen_name" : "TwitPic",
      "indices" : [ 131, 139 ],
      "id_str" : "12925072",
      "id" : 12925072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/L5h0AJFN",
      "expanded_url" : "http:\/\/twitpic.com\/6ciztm",
      "display_url" : "twitpic.com\/6ciztm"
    } ]
  },
  "geo" : { },
  "id_str" : "119023613939687424",
  "text" : "\u524D\u306E @magokoro84 @akeopyaa @akiyohmori @np2i @ayu167 @koketomi @lisa_math @mo5nya @nico_reflexio @kazma0318 http:\/\/t.co\/L5h0AJFN via @twitpic",
  "id" : 119023613939687424,
  "created_at" : "2011-09-28 12:20:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003Ezzy_2\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 31, 40 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 41, 52 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 53, 63 ],
      "id_str" : "181342377",
      "id" : 181342377
    }, {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 64, 71 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 72, 81 ],
      "id_str" : "305542897",
      "id" : 305542897
    }, {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 82, 91 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    }, {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 92, 101 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/Mi1PYd1P",
      "expanded_url" : "http:\/\/twitpic.com\/6ru67f",
      "display_url" : "twitpic.com\/6ru67f"
    } ]
  },
  "geo" : { },
  "id_str" : "119023146115411968",
  "text" : "[\u89AA\u53CB\u30B3\u30E9\u30FC\u30B8\u30E5] http:\/\/t.co\/Mi1PYd1P @akeopyaa @magokoro84 @kazma0318 @ayu167 @iwa_bj21 @koketomi @isaribiz http:\/\/twtm.kr\/TFC",
  "id" : 119023146115411968,
  "created_at" : "2011-09-28 12:18:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    }, {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 8, 17 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119020669542481920",
  "geo" : { },
  "id_str" : "119020862987968514",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp @isaribiz \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 119020862987968514,
  "in_reply_to_status_id" : 119020669542481920,
  "created_at" : "2011-09-28 12:09:19 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119019812885233664",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u6628\u65E5\u306E\u591C\u306E\u9EBB\u96C0\u3067\u5DBA\u4E0A\u958B\u82B1\u30C9\u30E91\u3063\u3066\u548C\u4E86\u308A\u304C\u3042\u3063\u305F\u306A\u3002\u30B7\u30E3\u30DC\u3067\u30C4\u30E2\u308B\u3068\u3082\u601D\u3063\u3066\u306A\u304B\u3063\u305F\u3051\u3069\u3002",
  "id" : 119019812885233664,
  "created_at" : "2011-09-28 12:05:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119018778158825472",
  "text" : "\u826F\u304F\u8003\u3048\u305F\u3089\u81EA\u5206\u306F\u3075\u3041\u307C\u9B54\u3067\u3082\u306A\u304F\u5927\u91CF\u30DD\u30B9\u30BF\u30FC\u3067\u3082\u306A\u304F\u30EA\u30C4\u30A4\u30C3\u30BF\u30FC\u306A\u3093\u3058\u3083\u306A\u3044\u3060\u308D\u3046\u304B",
  "id" : 119018778158825472,
  "created_at" : "2011-09-28 12:01:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3080\u3069\u3080",
      "screen_name" : "nika_dom",
      "indices" : [ 3, 12 ],
      "id_str" : "213637860",
      "id" : 213637860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119018542837415936",
  "text" : "RT @nika_dom: \u7236\u300C\u3042\u306E\u767D\u3044\u306E(\u30AD\u30E5\u30A5\u3079\u3047)\u3066\u30DD\u30B1\u30E2\u30F3\u304B\uFF1F\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119018000132210688",
    "text" : "\u7236\u300C\u3042\u306E\u767D\u3044\u306E(\u30AD\u30E5\u30A5\u3079\u3047)\u3066\u30DD\u30B1\u30E2\u30F3\u304B\uFF1F\u300D",
    "id" : 119018000132210688,
    "created_at" : "2011-09-28 11:57:57 +0000",
    "user" : {
      "name" : "\u3069\u3080\u3069\u3080",
      "screen_name" : "nika_dom",
      "protected" : false,
      "id_str" : "213637860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548471198443532289\/0nt7maet_normal.png",
      "id" : 213637860,
      "verified" : false
    }
  },
  "id" : 119018542837415936,
  "created_at" : "2011-09-28 12:00:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119018127911686144",
  "text" : "\u5B66\u5E74\u3067\u5909\u306A\u5974\u3067\u304B\u3064\u3042\u308B\u7A0B\u5EA6\u52C9\u5F37\u3067\u304D\u308B\u5B50\u3092\u96C6\u3081\u3066\u3082\u3001\u7D50\u5C40\u50CD\u304D\u30A2\u30EA\u306E\u539F\u7406\u307F\u305F\u3044\u306A\u3053\u3068\u304C\u8D77\u304D\u3066\u5909\u306A\u5974\u306F\u5C11\u6570\u306B\u53CE\u307E\u308B\u2026\u306E\u304B\u306A\uFF1F",
  "id" : 119018127911686144,
  "created_at" : "2011-09-28 11:58:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119017895979253760",
  "text" : "RT @magokoro84: \u7D50\u5C40\u666E\u901A\u306E\u4EBA\u304C\u591A\u3044\u304B\u3089\u306D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119017432697421824",
    "text" : "\u7D50\u5C40\u666E\u901A\u306E\u4EBA\u304C\u591A\u3044\u304B\u3089\u306D",
    "id" : 119017432697421824,
    "created_at" : "2011-09-28 11:55:41 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 119017895979253760,
  "created_at" : "2011-09-28 11:57:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u4EBA",
      "screen_name" : "Im_Weltkriege",
      "indices" : [ 3, 17 ],
      "id_str" : "18403048",
      "id" : 18403048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119017873963356160",
  "text" : "RT @Im_Weltkriege: \u300C\u4EAC\u90FD\u5927\u5B66\u306F\u81EA\u7531\u306A\u6821\u98A8\u3067\u30E6\u30CB\u30FC\u30AF\u306A\u4EBA\u6750\u3092\u8F29\u51FA\u3059\u308B\u300D\u3068\u3044\u3046\u5984\u60F3\u304C\u75DB\u3081\u3064\u3051\u305F\u4EBA\u9593\u306E\u6570\u3092\u77E5\u308A\u305F\u3044\u3067\u3059\u3088\u306D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43298932666806272",
    "text" : "\u300C\u4EAC\u90FD\u5927\u5B66\u306F\u81EA\u7531\u306A\u6821\u98A8\u3067\u30E6\u30CB\u30FC\u30AF\u306A\u4EBA\u6750\u3092\u8F29\u51FA\u3059\u308B\u300D\u3068\u3044\u3046\u5984\u60F3\u304C\u75DB\u3081\u3064\u3051\u305F\u4EBA\u9593\u306E\u6570\u3092\u77E5\u308A\u305F\u3044\u3067\u3059\u3088\u306D",
    "id" : 43298932666806272,
    "created_at" : "2011-03-03 13:17:24 +0000",
    "user" : {
      "name" : "\u975E\u4EBA",
      "screen_name" : "Im_Weltkriege",
      "protected" : false,
      "id_str" : "18403048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2474244028\/w55iggmtvh8ps34jznar_normal.gif",
      "id" : 18403048,
      "verified" : false
    }
  },
  "id" : 119017873963356160,
  "created_at" : "2011-09-28 11:57:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119016981331582976",
  "text" : "\u6628\u65E5\u5148\u8F29\u5B85\u3067\uFF34\uFF36\u306E\u8A71\u306B\u306A\u3063\u3066\u5168\u304F\u3064\u3044\u3066\u3044\u3051\u306A\u304F\u3066\u3061\u3087\u3063\u3068\u6065\u305A\u304B\u3057\u304B\u3063\u305F\u3051\u3069\u3001\u3060\u304B\u3089\u3068\u3044\u3063\u3066\uFF34\uFF36\u8CB7\u3046\u6C17\u306B\u3082\u306A\u3089\u306A\u3044\u3093\u3060\u3088\u306A\u30FC\u3002",
  "id" : 119016981331582976,
  "created_at" : "2011-09-28 11:53:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119014979646128128",
  "text" : "\u4EBA\u9593\u5BA3\u8A00\u3092\u983B\u7E41\u306B\u3057\u306A\u3044\u3068\u795E\u8A71\u306B\u7D44\u307F\u8FBC\u307E\u308C\u3066\u3084\u308A\u306B\u304F\u3044",
  "id" : 119014979646128128,
  "created_at" : "2011-09-28 11:45:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 53, 64 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119014831654305793",
  "text" : "\u306A\u3093\u3067\u3067\u3057\u3087\u3046\u306D\u2026\u79C1\u5927\u751F\u306B\u8EFD\u8511\u3055\u308C\u305F\u8A18\u61B6\u306F\u306A\u3044\u3051\u3069\u306A\u3002\u9006\u5DEE\u5225\u3067\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u306B\u56F0\u3063\u305F\u3053\u3068\u306A\u3089\u3042\u308B\u3051\u3069 RT @magokoro84 \u4E00\u90E8\u56FD\u7ACB\u5927\u751F\u306F\u3069\u3046\u3057\u3066\u3042\u3042\u3082\u79C1\u5927\u306E\u5B66\u751F\u3092\u8EFD\u8511\u3057\u3066\u308B\u306E\u304B\u306D\uFF1F",
  "id" : 119014831654305793,
  "created_at" : "2011-09-28 11:45:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119013310631919616",
  "text" : "\u3055\u3073\u3057\u304C\u308A\u5C4B\u306F\u300C\u3055\u3073\u3057\u304C\u308A\u300D\u3092\u58F2\u3063\u3066\u3044\u308B\u306E\u3060\u308D\u3046\u304B",
  "id" : 119013310631919616,
  "created_at" : "2011-09-28 11:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119008919849926656",
  "text" : "\u3086\u30D0\u30C3\u30B8\u6B32\u3057\u3044\u30FB\u30FB\u3051\u3069\u3064\u3051\u308B\u52C7\u6C17\u3082\u306A\u3051\u308C\u3070\u3082\u3089\u3046\u6A5F\u4F1A\u3082\u306A\u3044",
  "id" : 119008919849926656,
  "created_at" : "2011-09-28 11:21:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119008593650515969",
  "text" : "\u4F7F\u3063\u3066\u308B\u4EBA\u304C\u30B9\u30BF\u30A4\u30EA\u30C3\u30B7\u30E5\u3058\u3083\u306A\u3044\u3068\u304B\u8A00\u308F\u306A\u3044\uFF01",
  "id" : 119008593650515969,
  "created_at" : "2011-09-28 11:20:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119008496934068224",
  "text" : "\u306A\u3093\u304B\u30B9\u30BF\u30A4\u30EA\u30C3\u30B7\u30E5\u306A\u7B46\u7BB1\u6B32\u3057\u3044\u306A\u3002\u5E30\u7701\u3057\u305F\u6642\u306B\u9769\u306E\u304A\u5E97\u898B\u3066\u307F\u308C\u3070\u3088\u304B\u3063\u305F\u3002",
  "id" : 119008496934068224,
  "created_at" : "2011-09-28 11:20:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119008198828101632",
  "text" : "RT @_flyingmoomin: \u300C\u30D4\u30B6\u3063\u306610\u56DE\u8A00\u3063\u3066\u300D\u300C\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\" \u30FB\u30FB\u2127 \u309C\u311C\" \u30FB\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u300D\u300C\u3058\u3083\u3042\u3053\u308C\u306F\uFF1F\u300D\u300C\u2127 \u311C\" \u30FB\u30FB\u300D\u300C\u3068\u3053\u308D\u304C\u3069\u3063\u3053\u3044\u2026\u819D\u3058 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119006353497919488",
    "text" : "\u300C\u30D4\u30B6\u3063\u306610\u56DE\u8A00\u3063\u3066\u300D\u300C\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\" \u30FB\u30FB\u2127 \u309C\u311C\" \u30FB\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u2127 \u309C\u311C\"\u30FB\u30FB\u300D\u300C\u3058\u3083\u3042\u3053\u308C\u306F\uFF1F\u300D\u300C\u2127 \u311C\" \u30FB\u30FB\u300D\u300C\u3068\u3053\u308D\u304C\u3069\u3063\u3053\u3044\u2026\u819D\u3058\u3083\u3042\u308A\u307E\u305B\u3093\u2026\u8098\u3067\u3059\u2026\uFF01\u73FE\u5B9F\u2026\u3053\u308C\u304C\u73FE\u5B9F\u2026\uFF01\u300D",
    "id" : 119006353497919488,
    "created_at" : "2011-09-28 11:11:40 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 119008198828101632,
  "created_at" : "2011-09-28 11:19:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SYON BO RICK!",
      "screen_name" : "syonbori",
      "indices" : [ 3, 12 ],
      "id_str" : "16154302",
      "id" : 16154302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119008013620228096",
  "text" : "RT @syonbori: \u300C\u5909\u6570\u540D\u306F\u5F79\u5272\u3092\u8868\u3059\u540D\u524D\u306B\u3057\u306A\u3055\u3044\u300D\u3000\u300C int seisuu_wo_ireru_mono; \u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.misuzilla.org\/dist\/net\/twitterircgateway\/\" rel=\"nofollow\"\u003ETweetIrcGateway\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118995443047874560",
    "text" : "\u300C\u5909\u6570\u540D\u306F\u5F79\u5272\u3092\u8868\u3059\u540D\u524D\u306B\u3057\u306A\u3055\u3044\u300D\u3000\u300C int seisuu_wo_ireru_mono; \u300D",
    "id" : 118995443047874560,
    "created_at" : "2011-09-28 10:28:19 +0000",
    "user" : {
      "name" : "SYON BO RICK!",
      "screen_name" : "syonbori",
      "protected" : false,
      "id_str" : "16154302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000016253460\/68fd0f6ee906f60f2036fe8b881c6a10_normal.png",
      "id" : 16154302,
      "verified" : false
    }
  },
  "id" : 119008013620228096,
  "created_at" : "2011-09-28 11:18:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118995099857338368",
  "text" : "\u820C\u706B\u50B7\u3057\u305F\u304B\u306A\u3002\u7F8E\u5473\u3057\u304B\u3063\u305F\u3051\u3069\u3002",
  "id" : 118995099857338368,
  "created_at" : "2011-09-28 10:26:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118987565629046784",
  "text" : "\u30BD\u30EA\u30C6\u30A3\u30A2\u306E\u30BF\u30A4\u30E0\u30A2\u30BF\u30C3\u30AF\u306745\u79D2\u3092\u305F\u305F\u304D\u51FA\u3059\u7A0B\u5EA6\u306B\u306F\u5B64\u72EC\u3067\u3059\u3002",
  "id" : 118987565629046784,
  "created_at" : "2011-09-28 09:57:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118986250647650304",
  "text" : "\u3046\u308F\u3063\u2026\u7BB1\u2026\u3067\u304B\u3059\u304E\uFF1F\uFF01",
  "id" : 118986250647650304,
  "created_at" : "2011-09-28 09:51:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118984997347663872",
  "text" : "\u304A\u304B\u3086\u3063\u3066\u98A8\u90AA\u306E\u6642\u3057\u304B\u98DF\u3079\u306A\u3044\u3063\u3066\u4EBA\u5468\u308A\u306B\u7D50\u69CB\u591A\u3044\u3002\n\u666E\u901A\u306B\u98DF\u3079\u308B\u3057\u3001\u4E2D\u83EF\u7CA5\u3068\u304B\u98DF\u3079\u306B\u884C\u3063\u305F\u308A\u3059\u308B\u3093\u3060\u3051\u3069\u306A\u30FC",
  "id" : 118984997347663872,
  "created_at" : "2011-09-28 09:46:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118984789188558850",
  "text" : "\u5473\u564C\u7CA5\u2026\u7C73\u304B\u3089\u3084\u3063\u3066\u308230\u5206\u307B\u3069\u653E\u7F6E\u3067\u51FA\u6765\u4E0A\u304C\u308B\u512A\u79C0\u3055\u3002",
  "id" : 118984789188558850,
  "created_at" : "2011-09-28 09:45:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118982423777259520",
  "text" : "\u30EB\u30CD\u3067\u304F\u3063\u3061\u3093\u3071\u30AA\u30D5\u304B\u30FC\u3002\u306A\u3093\u304B\u3053\u3063\u305D\u308A\u306E\u305E\u304D\u306B\u884C\u3063\u3066\u3082\u826F\u304B\u3063\u305F\u304C\u3001\u305D\u3093\u306A\u52C7\u6C17\u3082\u306A\u3044\u3002",
  "id" : 118982423777259520,
  "created_at" : "2011-09-28 09:36:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118976756404326400",
  "text" : "\u5F1F\uFF08\u4E2D\uFF12\uFF09\u304C\u30B8\u30E3\u30F3\u30D7\u8CB7\u3063\u3066\u3066\u3061\u3087\u3063\u3068\u3073\u3063\u304F\u308A\u3057\u305F\u3051\u3069\u3001\u307E\u3041\u4E2D\u5B66\u751F\u306A\u3089\u81EA\u7136\u3060\u3088\u306A\u3002",
  "id" : 118976756404326400,
  "created_at" : "2011-09-28 09:14:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118976624359247873",
  "text" : "\u30B8\u30E3\u30F3\u30D7\u3068\u304B\u8CB7\u3063\u3066\u307E\u3067\u306F\u8AAD\u307E\u306A\u304B\u3063\u305F\u306A\u3041\u3002\u53CB\u4EBA\u306B\u501F\u308A\u3066\u8AAD\u3080\u3002\u501F\u308A\u3089\u308C\u306A\u304B\u3063\u305F\u3089\u305D\u308C\u3067\u3088\u3057\u3063\u3066\u3044\u3046\u7121\u9813\u7740\u306A\u611F\u3058\u3002",
  "id" : 118976624359247873,
  "created_at" : "2011-09-28 09:13:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118976429487702018",
  "text" : "\u4EBA\u9593\u8A66\u9A13\u8AAD\u3080\u305F\u3081\u3060\u3051\u306B\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u8CB7\u3063\u3061\u3083\u3063\u305F\u3002\u306A\u3093\u3068\u3044\u3046\u304B\u6F2B\u753B\u96D1\u8A8C\u8CB7\u3063\u305F\u306E\u3063\u3066\u5C0F\u5B66\u6821\u306E\u6642\u306B\u30B3\u30ED\u30B3\u30ED\u8CB7\u3063\u3066\u3082\u3089\u3063\u305F\u3068\u304B\u9664\u3044\u305F\u3089\u521D\u3081\u3066\u3060\u3002",
  "id" : 118976429487702018,
  "created_at" : "2011-09-28 09:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 8, 16 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118971002377080832",
  "text" : "\u30A8\u30FC\u30D4\u30FC RT @i_horse a.m.p.m. \u3063\u3066\u7565\u79F0\u3042\u308B\u306E\u304B\u306A",
  "id" : 118971002377080832,
  "created_at" : "2011-09-28 08:51:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "indices" : [ 3, 10 ],
      "id_str" : "89620915",
      "id" : 89620915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118917927549419520",
  "text" : "RT @qusumi: \u300C\u82B1\u306E\u30BA\u30DC\u30E9\u98EF\u3000\u3046\u3093\u307E\u301C\u3044\u30EC\u30B7\u30D4\u300D\u306F\u4E3B\u5A66\u306E\u53CB\u793E\u304B\u3089952\u5186\u3002\u30DE\u30F3\u30AC\u306E\u30D0\u30EA\u30A8\u30FC\u30B7\u30E7\u30F3\u3082\u542B\u3081\u7C21\u5358\u30BA\u30DC\u30E9\u6599\u7406\u304C\uFF11\uFF10\uFF17\u54C1\u3002\u30AA\u30FC\u30EB\u30AB\u30E9\u30FC\u3002\u304A\u3044\u3057\u305D\u30FC\u3067\u3059\u3088\u3002 http:\/\/ow.ly\/6GW46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118916536680464384",
    "text" : "\u300C\u82B1\u306E\u30BA\u30DC\u30E9\u98EF\u3000\u3046\u3093\u307E\u301C\u3044\u30EC\u30B7\u30D4\u300D\u306F\u4E3B\u5A66\u306E\u53CB\u793E\u304B\u3089952\u5186\u3002\u30DE\u30F3\u30AC\u306E\u30D0\u30EA\u30A8\u30FC\u30B7\u30E7\u30F3\u3082\u542B\u3081\u7C21\u5358\u30BA\u30DC\u30E9\u6599\u7406\u304C\uFF11\uFF10\uFF17\u54C1\u3002\u30AA\u30FC\u30EB\u30AB\u30E9\u30FC\u3002\u304A\u3044\u3057\u305D\u30FC\u3067\u3059\u3088\u3002 http:\/\/ow.ly\/6GW46",
    "id" : 118916536680464384,
    "created_at" : "2011-09-28 05:14:46 +0000",
    "user" : {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "protected" : false,
      "id_str" : "89620915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1625008477\/Q_Wqusumi_____normal.jpg",
      "id" : 89620915,
      "verified" : false
    }
  },
  "id" : 118917927549419520,
  "created_at" : "2011-09-28 05:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u93E1 \u5F18\u9053 ",
      "screen_name" : "kagami_hr",
      "indices" : [ 11, 21 ],
      "id_str" : "276392000",
      "id" : 276392000
    }, {
      "name" : "\u9EC4\u9B54\u8853\u58EB",
      "screen_name" : "Y_MAG",
      "indices" : [ 34, 40 ],
      "id_str" : "46739559",
      "id" : 46739559
    }, {
      "name" : "\u93E1 \u5F18\u9053 ",
      "screen_name" : "kagami_hr",
      "indices" : [ 65, 75 ],
      "id_str" : "276392000",
      "id" : 276392000
    }, {
      "name" : "THE Axis of Evil",
      "screen_name" : "Cryolite",
      "indices" : [ 96, 105 ],
      "id_str" : "12873342",
      "id" : 12873342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118914425934725122",
  "text" : "\u865A\u3092\u7A81\u304B\u308C\u305F\uFF01 RT @kagami_hr: i ._.)i RT @Y_MAG: \u5FAE\u5206\u3055\u308C\u305F\u3089\uFF12\u6B21\u5143\u306B\u884C\u3051\u308B\u306E\u304B\u306A\u2026\u2026\u3002 RT @kagami_hr: \u3058\u3083\u3042\u79C1\u306F\u5FAE\u5206 ' ._.)' RT @Cryolite: \u222B( ._.)\u222B\uFF1C\u304A\u524D\u3092\u7A4D\u5206\u3057\u3066\u3084\u308B\u30FC",
  "id" : 118914425934725122,
  "created_at" : "2011-09-28 05:06:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3042\u306E",
      "screen_name" : "CiaNostal",
      "indices" : [ 3, 13 ],
      "id_str" : "30864745",
      "id" : 30864745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118903160726237184",
  "text" : "RT @CiaNostal: |\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u25A1 \u529B\u5B66\u306E\u554F\u984C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118881151531237376",
    "text" : "|\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u25A1 \u529B\u5B66\u306E\u554F\u984C",
    "id" : 118881151531237376,
    "created_at" : "2011-09-28 02:54:09 +0000",
    "user" : {
      "name" : "\u3057\u3042\u306E",
      "screen_name" : "CiaNostal",
      "protected" : false,
      "id_str" : "30864745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567002121220792320\/HgRJlLQk_normal.png",
      "id" : 30864745,
      "verified" : false
    }
  },
  "id" : 118903160726237184,
  "created_at" : "2011-09-28 04:21:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hanibi",
      "screen_name" : "hanibi",
      "indices" : [ 3, 10 ],
      "id_str" : "16945402",
      "id" : 16945402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/10Pnnxnf",
      "expanded_url" : "http:\/\/twitpic.com\/6rnkrm",
      "display_url" : "twitpic.com\/6rnkrm"
    } ]
  },
  "geo" : { },
  "id_str" : "118893110465011713",
  "text" : "RT @hanibi: \u3053\u308C\u306F\u3072\u3069\u3044\u2026 http:\/\/t.co\/10Pnnxnf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 28 ],
        "url" : "http:\/\/t.co\/10Pnnxnf",
        "expanded_url" : "http:\/\/twitpic.com\/6rnkrm",
        "display_url" : "twitpic.com\/6rnkrm"
      } ]
    },
    "geo" : { },
    "id_str" : "118892189261639680",
    "text" : "\u3053\u308C\u306F\u3072\u3069\u3044\u2026 http:\/\/t.co\/10Pnnxnf",
    "id" : 118892189261639680,
    "created_at" : "2011-09-28 03:38:01 +0000",
    "user" : {
      "name" : "hanibi",
      "screen_name" : "hanibi",
      "protected" : false,
      "id_str" : "16945402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595914185638182913\/jTDnkE3v_normal.jpg",
      "id" : 16945402,
      "verified" : false
    }
  },
  "id" : 118893110465011713,
  "created_at" : "2011-09-28 03:41:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118892987668381696",
  "text" : "\u306A\u3093\u304B\u7761\u7720\u304C\u3076\u3064\u5207\u308A\u3060\u3063\u305F\u3051\u3069\u304A\u306F\u3088\u3046",
  "id" : 118892987668381696,
  "created_at" : "2011-09-28 03:41:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118763518102220800",
  "text" : "\u5BDD\u308B\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 118763518102220800,
  "created_at" : "2011-09-27 19:06:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118763450045440000",
  "text" : "\u9EBB\u96C0\u3001\u6700\u5F8C500\u70B9\u5DEE\u3067\u6372\u308B\u30D7\u30EC\u30A4\u30F3\u30B0\u3002\u81EA\u6478\u306A\u3089\u540C\u7740\u4E00\u4F4D\u3068\u3044\u3046\u5FAE\u5999\u3055\u3060\u3063\u305F\u3002",
  "id" : 118763450045440000,
  "created_at" : "2011-09-27 19:06:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118762740218216448",
  "text" : "\u5E30\u5B85",
  "id" : 118762740218216448,
  "created_at" : "2011-09-27 19:03:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118656402418962432",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 118656402418962432,
  "created_at" : "2011-09-27 12:01:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "101753216",
      "id" : 101753216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118619574420766721",
  "in_reply_to_user_id" : 101753216,
  "text" : "@factoring_bot 6221",
  "id" : 118619574420766721,
  "created_at" : "2011-09-27 09:34:45 +0000",
  "in_reply_to_screen_name" : "factoring_bot",
  "in_reply_to_user_id_str" : "101753216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "indices" : [ 3, 17 ],
      "id_str" : "199329343",
      "id" : 199329343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118537798239272961",
  "text" : "RT @Satomii_Opera: \u300C\u306A\u3042\u30012065\u5E74\u306B\u7DCF\u7406\u5927\u81E3\u306B\u306A\u3063\u305F\u306E\u3063\u3066\u7530\u4E2D\u2026\u2026\u306A\u3093\u3060\u3063\u3051\uFF1F\u300D\n\u300C\u30D1\u30E9\u30C7\u30A3\u30F3\u300D\n\u300C\u3069\u3046\u66F8\u304F\u3093\u3060\u3063\u3051\u300D\n\u300C\u8056\u306A\u308B\u9A0E\u58EB\u300D\n\u300C\u30B5\u30F3\u30AD\u30E5\u30FC\u300D\n\u300C\u3053\u306E\u6642\u4EE3\u306E\u8457\u540D\u4EBA\u3001\u540D\u524D\u8AAD\u3081\u306A\u3044\u5974\u3070\u304B\u308A\u3060\u304B\u3089\u5165\u8A66\u306B\u51FA\u3055\u306A\u3044\u3067\u307B\u3057\u3044\u3088\u306A\u300D\n\u300C\u306A\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118523323197038592",
    "text" : "\u300C\u306A\u3042\u30012065\u5E74\u306B\u7DCF\u7406\u5927\u81E3\u306B\u306A\u3063\u305F\u306E\u3063\u3066\u7530\u4E2D\u2026\u2026\u306A\u3093\u3060\u3063\u3051\uFF1F\u300D\n\u300C\u30D1\u30E9\u30C7\u30A3\u30F3\u300D\n\u300C\u3069\u3046\u66F8\u304F\u3093\u3060\u3063\u3051\u300D\n\u300C\u8056\u306A\u308B\u9A0E\u58EB\u300D\n\u300C\u30B5\u30F3\u30AD\u30E5\u30FC\u300D\n\u300C\u3053\u306E\u6642\u4EE3\u306E\u8457\u540D\u4EBA\u3001\u540D\u524D\u8AAD\u3081\u306A\u3044\u5974\u3070\u304B\u308A\u3060\u304B\u3089\u5165\u8A66\u306B\u51FA\u3055\u306A\u3044\u3067\u307B\u3057\u3044\u3088\u306A\u300D\n\u300C\u306A\u300D",
    "id" : 118523323197038592,
    "created_at" : "2011-09-27 03:12:16 +0000",
    "user" : {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "protected" : false,
      "id_str" : "199329343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212059931\/satomii_opera_normal.jpg",
      "id" : 199329343,
      "verified" : false
    }
  },
  "id" : 118537798239272961,
  "created_at" : "2011-09-27 04:09:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "indices" : [ 3, 18 ],
      "id_str" : "158991353",
      "id" : 158991353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118530743671595009",
  "text" : "RT @sorayama_asobi: \u56DE\u8EE2\u5BFF\u53F8\u306E\u30EC\u30FC\u30F3\u306B\u5358\u4F4D\u304C\u6D41\u3055\u308C\u3066\u3044\u304F\u5922\u3092\u898B\u305F\u3093\u3067\u3059\u3051\u3069\u3002\u8AB0\u304B\u5922\u5360\u3044\u3057\u3066\u304F\u3060\u3055\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118528931652583425",
    "text" : "\u56DE\u8EE2\u5BFF\u53F8\u306E\u30EC\u30FC\u30F3\u306B\u5358\u4F4D\u304C\u6D41\u3055\u308C\u3066\u3044\u304F\u5922\u3092\u898B\u305F\u3093\u3067\u3059\u3051\u3069\u3002\u8AB0\u304B\u5922\u5360\u3044\u3057\u3066\u304F\u3060\u3055\u3044",
    "id" : 118528931652583425,
    "created_at" : "2011-09-27 03:34:34 +0000",
    "user" : {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "protected" : false,
      "id_str" : "158991353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1864231491\/totoro_t_normal.jpg",
      "id" : 158991353,
      "verified" : false
    }
  },
  "id" : 118530743671595009,
  "created_at" : "2011-09-27 03:41:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118353697758654464",
  "geo" : { },
  "id_str" : "118355349135835136",
  "in_reply_to_user_id" : 62256126,
  "text" : "@38valleys \u304A\u75B2\u308C\u69D8\u3067\u3057\u305F\uFF01",
  "id" : 118355349135835136,
  "in_reply_to_status_id" : 118353697758654464,
  "created_at" : "2011-09-26 16:04:48 +0000",
  "in_reply_to_screen_name" : "nolimbre",
  "in_reply_to_user_id_str" : "62256126",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118352040803053569",
  "geo" : { },
  "id_str" : "118352413882187778",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3042\u30FC\u3001\u5F8C\u671F\u3082\u52C9\u5F37\u3059\u308B\u30D1\u30BF\u30F3\u3067\u3059\u304B\u3002",
  "id" : 118352413882187778,
  "in_reply_to_status_id" : 118352040803053569,
  "created_at" : "2011-09-26 15:53:09 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118351151199559681",
  "geo" : { },
  "id_str" : "118351581283500032",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u305D\u308C\u3082\u4E88\u5099\u767B\u9332\u65E5\u306B\u884C\u3063\u305F\u3089\u3082\u3057\u304B\u3057\u305F\u3089\u306D\u3058\u8FBC\u3081\u308B\u3093\u3058\u3083\u2026\u308F\u304B\u308A\u307E\u305B\u3093\u3051\u3069",
  "id" : 118351581283500032,
  "in_reply_to_status_id" : 118351151199559681,
  "created_at" : "2011-09-26 15:49:50 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 15, 29 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118350211507695617",
  "text" : "RT @38valleys: @_flyingmoomin \u30E0\u30FC\u30DF\u30F3\u3055\u3093\u3063\u3066\u3055\u3041\u2026\u306A\u3093\u304B\u305D\u3053\u3089\u8FBA\u306E\u9023\u4E2D\u3068\u5302\u3044\u9055\u3044\u307E\u3059\u3088\u306D\u2026\u3000\u5371\u967A\u3068\u3044\u3046\u304B\u30A2\u30A6\u30C8\u30ED\u30FC\u3063\u3066\u3044\u3046\u304B\u2026\n\u3082\u3063\u3068\u306F\u3063\u304D\u308A\u8A00\u3046\u3068\u2026\u3000\u3075\u3041\u307C\u306E\u5302\u3044\u304C\u3059\u308B\u3063\u3066\u3044\u3046\u304B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
        "screen_name" : "_flyingmoomin",
        "indices" : [ 0, 14 ],
        "id_str" : "91483221",
        "id" : 91483221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118348689780649984",
    "geo" : { },
    "id_str" : "118349495238017024",
    "in_reply_to_user_id" : 91483221,
    "text" : "@_flyingmoomin \u30E0\u30FC\u30DF\u30F3\u3055\u3093\u3063\u3066\u3055\u3041\u2026\u306A\u3093\u304B\u305D\u3053\u3089\u8FBA\u306E\u9023\u4E2D\u3068\u5302\u3044\u9055\u3044\u307E\u3059\u3088\u306D\u2026\u3000\u5371\u967A\u3068\u3044\u3046\u304B\u30A2\u30A6\u30C8\u30ED\u30FC\u3063\u3066\u3044\u3046\u304B\u2026\n\u3082\u3063\u3068\u306F\u3063\u304D\u308A\u8A00\u3046\u3068\u2026\u3000\u3075\u3041\u307C\u306E\u5302\u3044\u304C\u3059\u308B\u3063\u3066\u3044\u3046\u304B\u2026",
    "id" : 118349495238017024,
    "in_reply_to_status_id" : 118348689780649984,
    "created_at" : "2011-09-26 15:41:33 +0000",
    "in_reply_to_screen_name" : "_flyingmoomin",
    "in_reply_to_user_id_str" : "91483221",
    "user" : {
      "name" : "\u306E\u3089\u3093\u3076\u308B",
      "screen_name" : "nolimbre",
      "protected" : false,
      "id_str" : "62256126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599829445105438720\/xfix_1cZ_normal.jpg",
      "id" : 62256126,
      "verified" : false
    }
  },
  "id" : 118350211507695617,
  "created_at" : "2011-09-26 15:44:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118348353942720512",
  "text" : "\u3061\u306A\u307F\u306B\u3002\u30B3\u30FC\u30EB\u306B\u306D\u3058\u8FBC\u3080\u306B\u306F\u767B\u9332\u4E88\u5099\u306E\u65E5\u306B\u5927\u5B66\u306B\u884C\u304F\u306E\u304C\u304A\u52E7\u3081\u3060\u3088\u2606\n\u524D\u671F\u306F\u306D\u3058\u8FBC\u3093\u3067\u3082\u3089\u3048\u305F\u3002",
  "id" : 118348353942720512,
  "created_at" : "2011-09-26 15:37:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118347761535033344",
  "text" : "\u30B3\u30FC\u30EB\u901A\u3063\u305F\u306E\u306F\u5E78\u904B\u3060\u3063\u305F\u306E\u304B\u30FC\u3002\u5916\u308C\u305F\u3053\u3068\u306A\u3044\u304B\u3089\u5E78\u904B\u306E\u5B9F\u611F\u304C\u306A\u304B\u3063\u305F\u306A\u3002\u611F\u8B1D\u3057\u306A\u304F\u3066\u306F\u3002",
  "id" : 118347761535033344,
  "created_at" : "2011-09-26 15:34:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 12, 21 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118347433594990594",
  "text" : "\u304A\u75B2\u308C\u69D8\u3067\u3057\u305F\uFF01 RT @nartakio \u30E0\u30FC\u30DF\u30F3\u3055\u3093\u304A\u75B2\u308C\u69D8\u3067\u3059\uFF01\uFF01",
  "id" : 118347433594990594,
  "created_at" : "2011-09-26 15:33:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 0, 10 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118342556512829440",
  "geo" : { },
  "id_str" : "118343775373369344",
  "in_reply_to_user_id" : 126326979,
  "text" : "@Keitaecon \u6765\u5E74\u7D4C\u6E08\u306E\u3084\u3064\u6642\u9593\u5272\u3067\u53D6\u308C\u305D\u3046\u306A\u3089\u53D6\u3063\u3066\u307F\u307E\u3059\u30FC\u3002\u308F\u3056\u308F\u3056\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 118343775373369344,
  "in_reply_to_status_id" : 118342556512829440,
  "created_at" : "2011-09-26 15:18:49 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118341820727037953",
  "geo" : { },
  "id_str" : "118343517411090432",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \uFF34\uFF36\u307F\u3066\u306A\u3044\u306E\u3067\u89E3\u304B\u308A\u307E\u305B\u3093\u304C\u3001\u7D50\u5C40\u307F\u3093\u306A\u304C\u5206\u304B\u308B\u3088\u3046\u306B\u4F5C\u308B\u3068\u305D\u3046\u306A\u3063\u3061\u3083\u3046\u3093\u3067\u3059\u304B\u306D\u30FC\u3002\n\u3068\u3063\u3064\u304D\u3084\u3059\u3044\u8A71\u3057\u3057\u306A\u3044\u3068\u898B\u3066\u3082\u3089\u3048\u306A\u3044\u3067\u3057\u3087\u3046\u3057\u3002",
  "id" : 118343517411090432,
  "in_reply_to_status_id" : 118341820727037953,
  "created_at" : "2011-09-26 15:17:47 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118341669132304384",
  "geo" : { },
  "id_str" : "118342773517729792",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u622F\u8A00\u306E\u756A\u5916\u7DE8\u306E\u4EBA\u9593\u30B7\u30EA\u30FC\u30BA\u3082\u7D42\u308F\u3063\u305F\u3089\u305C\u3072\u305C\u3072",
  "id" : 118342773517729792,
  "in_reply_to_status_id" : 118341669132304384,
  "created_at" : "2011-09-26 15:14:50 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 0, 10 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118341487359557632",
  "geo" : { },
  "id_str" : "118342367068684288",
  "in_reply_to_user_id" : 126326979,
  "text" : "@Keitaecon \u306A\u308B\u307B\u3069\u30FC\u3002\u30DE\u30AF\u30ED\u304B\u3089\u89E6\u3063\u3066\u307F\u3088\u3046\u304B\u3068\u601D\u3044\u307E\u3059\u3002\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "id" : 118342367068684288,
  "in_reply_to_status_id" : 118341487359557632,
  "created_at" : "2011-09-26 15:13:13 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118341712325263362",
  "text" : "\u3042\u3089\u3076\u308B\uFF32\uFF34\u30BF\u30A4\u30E0\u306B\u306A\u3063\u3066\u3044\u308B\u3001\u3061\u3087\u3053\u3063\u3068\u7533\u3057\u8A33\u306A\u3044\u3002",
  "id" : 118341712325263362,
  "created_at" : "2011-09-26 15:10:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118341087113912320",
  "geo" : { },
  "id_str" : "118341476265631744",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u4ECA\u6708\u672B\u306B\u65B0\u520A\u3067\u307E\u3059\u3088\u30FC\u3002",
  "id" : 118341476265631744,
  "in_reply_to_status_id" : 118341087113912320,
  "created_at" : "2011-09-26 15:09:41 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 0, 10 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118340790375292928",
  "geo" : { },
  "id_str" : "118340936341274624",
  "in_reply_to_user_id" : 126326979,
  "text" : "@Keitaecon \u30DE\u30AF\u30ED\u3068\u30DF\u30AF\u30ED\u306F\u3069\u3063\u3061\u304C\u3068\u3063\u3064\u304D\u3084\u3059\u3044\u3067\u3059\u304B\uFF1F",
  "id" : 118340936341274624,
  "in_reply_to_status_id" : 118340790375292928,
  "created_at" : "2011-09-26 15:07:32 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118340793017696256",
  "text" : "RT @_flyingmoomin: \u30B9\u30C6\u30A4\u30C8\u30E1\u30F3\u30C8\u304C\u66F8\u3044\u3066\u3042\u308C\u3070\u8A3C\u660E\u3082\u8F09\u3063\u3066\u3044\u308B\u306E\u304C\u5F53\u305F\u308A\u524D\u304B\u2026\uFF1F\u306A\u305C\u305D\u3093\u306A\u3075\u3046\u306B\u8003\u3048\u308B\u2026\uFF1F\u3000\u30D0\u30AB\u304C\u3063\u2026\uFF01\u3068\u3093\u3067\u3082\u306A\u3044\u8AA4\u89E3\u3060\u2026\uFF01\u3000\u6559\u79D1\u66F8\u3068\u3044\u3046\u3082\u306E\u306F\u3068\u3069\u306E\u3064\u307E\u308A\u2026\u809D\u5FC3\u306A\u3053\u3068\u306F\u4F55\u4E00\u3064\u7B54\u3048\u305F\u308A\u3057\u306A\u3044\u2026\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118340651686428672",
    "text" : "\u30B9\u30C6\u30A4\u30C8\u30E1\u30F3\u30C8\u304C\u66F8\u3044\u3066\u3042\u308C\u3070\u8A3C\u660E\u3082\u8F09\u3063\u3066\u3044\u308B\u306E\u304C\u5F53\u305F\u308A\u524D\u304B\u2026\uFF1F\u306A\u305C\u305D\u3093\u306A\u3075\u3046\u306B\u8003\u3048\u308B\u2026\uFF1F\u3000\u30D0\u30AB\u304C\u3063\u2026\uFF01\u3068\u3093\u3067\u3082\u306A\u3044\u8AA4\u89E3\u3060\u2026\uFF01\u3000\u6559\u79D1\u66F8\u3068\u3044\u3046\u3082\u306E\u306F\u3068\u3069\u306E\u3064\u307E\u308A\u2026\u809D\u5FC3\u306A\u3053\u3068\u306F\u4F55\u4E00\u3064\u7B54\u3048\u305F\u308A\u3057\u306A\u3044\u2026\uFF01",
    "id" : 118340651686428672,
    "created_at" : "2011-09-26 15:06:24 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 118340793017696256,
  "created_at" : "2011-09-26 15:06:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118340741054464000",
  "text" : "\u5727\u5012\u7684\u300E\u8A3C\u660E\u7565\u300F\u2026\uFF01",
  "id" : 118340741054464000,
  "created_at" : "2011-09-26 15:06:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118340631004332032",
  "text" : "RT @_flyingmoomin: \u3044\u3044\u52A0\u6E1B\u306B\u3057\u308D\u3088\u3000\u3044\u3044\u52A0\u6E1B\u305D\u306E\u2026\n\u8A3C\u660E\u3092\u8AAD\u8005\u306E\u7DF4\u7FD2\u554F\u984C\u306B\u3059\u308B\u3063\u3066\u8003\u3048\u65B9\u6368\u3066\u308D\u3088\u3063\u2026\uFF01\n\u964D\u308A\u308B\u305E\u3063\u2026\uFF01\u3000\u3042\u3093\u307E\u308A\u7121\u8336\u8A00\u3046\u3068\u30AA\u30EC\u305F\u3061\u306F\n\u7686\u3000\u964D\u308A\u308B\u3063\u2026\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118340448875065344",
    "text" : "\u3044\u3044\u52A0\u6E1B\u306B\u3057\u308D\u3088\u3000\u3044\u3044\u52A0\u6E1B\u305D\u306E\u2026\n\u8A3C\u660E\u3092\u8AAD\u8005\u306E\u7DF4\u7FD2\u554F\u984C\u306B\u3059\u308B\u3063\u3066\u8003\u3048\u65B9\u6368\u3066\u308D\u3088\u3063\u2026\uFF01\n\u964D\u308A\u308B\u305E\u3063\u2026\uFF01\u3000\u3042\u3093\u307E\u308A\u7121\u8336\u8A00\u3046\u3068\u30AA\u30EC\u305F\u3061\u306F\n\u7686\u3000\u964D\u308A\u308B\u3063\u2026\uFF01",
    "id" : 118340448875065344,
    "created_at" : "2011-09-26 15:05:36 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 118340631004332032,
  "created_at" : "2011-09-26 15:06:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118340611274309632",
  "text" : "RT @_flyingmoomin: \u3010\u3000\u6570\u7406\u79D1\u5B66\u7834\u6212\u9332\u3000\u6539\u3000\u3011",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118340374736543744",
    "text" : "\u3010\u3000\u6570\u7406\u79D1\u5B66\u7834\u6212\u9332\u3000\u6539\u3000\u3011",
    "id" : 118340374736543744,
    "created_at" : "2011-09-26 15:05:18 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 118340611274309632,
  "created_at" : "2011-09-26 15:06:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118340102593314818",
  "geo" : { },
  "id_str" : "118340391941582849",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3067\u3059\u304B\u306D\u30FC\u3002\u7269\u7406\u5B66\u754C\u3092\u63FA\u308B\u304C\u3059\u304B\u3082\u3057\u308C\u306A\u3044\u30CB\u30E5\u30FC\u30B9\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u3047\u3002",
  "id" : 118340391941582849,
  "in_reply_to_status_id" : 118340102593314818,
  "created_at" : "2011-09-26 15:05:22 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118339755367866368",
  "text" : "\u5149\u306E\u901F\u3055\u3067\u30FC\u3063\u3066\u8868\u73FE\u304C\u51FA\u305F\u304B\u3089\u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u306E\u901F\u3055\u3067\u30FC\u3063\u3066\u8A00\u3044\u8FD4\u3057\u305F\u3089\u304D\u3087\u3068\u3093\u3068\u3055\u308C\u305F\u306A\u3046\u3063\uFF01",
  "id" : 118339755367866368,
  "created_at" : "2011-09-26 15:02:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 0, 10 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/9qzISiKo",
      "expanded_url" : "http:\/\/workline.xii.jp\/favgraph\/end313124\/favs",
      "display_url" : "workline.xii.jp\/favgraph\/end31\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118338133539565568",
  "in_reply_to_user_id" : 155546700,
  "text" : "@end313124 \u306F @mathbot_ \u3092\u4E00\u756A\u3075\u3041\u307C\u3063\u3066\u3044\u307E\u3059! (10.53% \u4ED61\u4EBA) http:\/\/t.co\/9qzISiKo",
  "id" : 118338133539565568,
  "created_at" : "2011-09-26 14:56:24 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 0, 10 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 29, 40 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/ashGi1G0",
      "expanded_url" : "http:\/\/workline.xii.jp\/favgraph\/end313124\/faved",
      "display_url" : "workline.xii.jp\/favgraph\/end31\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118337782371459072",
  "in_reply_to_user_id" : 155546700,
  "text" : "@end313124 \u306E\u767A\u8A00\u3092\u4E00\u756A\u3088\u304F\u3075\u3041\u307C\u3063\u3066\u3044\u308B\u306E\u306F @magokoro84 \u3067\u3059! (13.95%) http:\/\/t.co\/ashGi1G0",
  "id" : 118337782371459072,
  "created_at" : "2011-09-26 14:55:00 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 10, 19 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118337089455669249",
  "geo" : { },
  "id_str" : "118337344360284160",
  "in_reply_to_user_id" : 112398542,
  "text" : "\u307B\u3093\u307E\u305D\u308C\u306A RT @akeopyaa \u5B66\u6821\u304C\u597D\u304D\u3068\u3044\u3046\u3088\u308A\u306F\u3001\u305D\u3053\u3067\u4EF2\u826F\u304F\u306A\u3063\u305F\u4EBA\u9593\u304C\u597D\u304D\u306A\u3060\u3051\u306A\u306E\u3055\u3002\u3044\u3084\u3001\u305D\u308A\u3083\u305D\u3046\u3060\u308F\u306A\u3002",
  "id" : 118337344360284160,
  "in_reply_to_status_id" : 118337089455669249,
  "created_at" : "2011-09-26 14:53:16 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118335906888429568",
  "geo" : { },
  "id_str" : "118337191561793536",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u9031\uFF12\u306E\u6388\u696D\u306F\u305F\u3044\u3066\u3044\u7D9A\u304D\u3060\u304B\u3089\u4E21\u65B9\u3067\u306A\u3044\u3068\u3060\u3081\u3002",
  "id" : 118337191561793536,
  "in_reply_to_status_id" : 118335906888429568,
  "created_at" : "2011-09-26 14:52:39 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118335268813144064",
  "geo" : { },
  "id_str" : "118336767563800576",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6587\u7CFB\u304C\u7A4D\u5206\u3092\u77E5\u3089\u306A\u3044\u5C65\u4FEE\u6F0F\u308C\u2606",
  "id" : 118336767563800576,
  "in_reply_to_status_id" : 118335268813144064,
  "created_at" : "2011-09-26 14:50:58 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118333116275376129",
  "geo" : { },
  "id_str" : "118333347628978177",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3042\u30FC\u4F59\u8A08\u306A\u3053\u3068\u8A00\u308F\u306A\u304D\u3083\u3088\u304B\u3063\u305F\uFF08\u767D\u76EE",
  "id" : 118333347628978177,
  "in_reply_to_status_id" : 118333116275376129,
  "created_at" : "2011-09-26 14:37:23 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118331659228692480",
  "geo" : { },
  "id_str" : "118331862220406784",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3048\u3063\u3001\u5916\u308C\u305F\u3053\u3068\u306A\u3044\u3093\u3067\u3059\u304C",
  "id" : 118331862220406784,
  "in_reply_to_status_id" : 118331659228692480,
  "created_at" : "2011-09-26 14:31:29 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118331336988696578",
  "text" : "\u4E00\u6614\u524D\u306B\u4F3C\u305F\u3088\u3046\u306A\u3053\u3068\u3044\u3063\u305F\u8A18\u61B6\u304C\u3042\u308B\u3088\u30AF\u30E9\u30B9\u30BF",
  "id" : 118331336988696578,
  "created_at" : "2011-09-26 14:29:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118324868684058624",
  "text" : "\u5E30\u5B85",
  "id" : 118324868684058624,
  "created_at" : "2011-09-26 14:03:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118229629407477760",
  "text" : "\u5927\u4F53\u4F55\u5E74\u4ED8\u304D\u5408\u3063\u305F\u3063\u3066\u4EBA\u9593\u3092\u5224\u65AD\u3059\u308B\u306E\u306F\u96E3\u3057\u3044\u3068\u601D\u3063\u3066\u3044\u308B\u3002",
  "id" : 118229629407477760,
  "created_at" : "2011-09-26 07:45:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118229500877217792",
  "text" : "\u307E\u30FC\u30A2\u30A4\u30B3\u30F3\u306A\u3093\u305E\u3067\u4EBA\u304C\u5224\u65AD\u3067\u304D\u308B\u308F\u3051\u306A\u3044\u3058\u3083\u3093\u3002\u4EBA\u9593\u306F\u305D\u3093\u306A\u306B\u89E3\u308A\u3084\u3059\u304F\u51FA\u6765\u3066\u3044\u306A\u3044\u3068\u4FE1\u3058\u3066\u3044\u308B\u3002",
  "id" : 118229500877217792,
  "created_at" : "2011-09-26 07:44:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118229234626990080",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u30DB\u30EB\u30F3\u3082\u3050\u308B\u3050\u308B\u3057\u3066\u305F\u3057\u30D3\u30EA\u30E4\u30FC\u30C9\u3082\u7403\u304C\u3050\u308B\u3050\u308B\u3059\u308B\u3057\u3001\u3042\u308C\u3063\uFF1F\u3082\u3057\u304B\u3057\u3066\u81EA\u5206\u3050\u308B\u3050\u308B\u597D\u304D\uFF1F",
  "id" : 118229234626990080,
  "created_at" : "2011-09-26 07:43:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118229039365361665",
  "text" : "\u2190\u306A\u3093\u304B\u3050\u308B\u3050\u308B\u3057\u3066\u308B\u4EBA",
  "id" : 118229039365361665,
  "created_at" : "2011-09-26 07:42:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3081\u3044\u308D\u307E \u65B0\u520A\u300C\u6DFB\u524A\uFF01\u65E5\u672C\u4EBA\u82F1\u8A9E\u300D",
      "screen_name" : "May_Roma",
      "indices" : [ 3, 12 ],
      "id_str" : "10145862",
      "id" : 10145862
    }, {
      "name" : "\u65E9\u5DDD\u7531\u7D00\u592B",
      "screen_name" : "HayakawaYukio",
      "indices" : [ 37, 51 ],
      "id_str" : "88581459",
      "id" : 88581459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118228967865065472",
  "text" : "RT @May_Roma: \u79BF\u540C\u3002\u30CD\u30B3\u30A2\u30A4\u30B3\u30F3\u306F\u30C0\u30E1\u306A\u4EBA\u591A\u3044\u306B\u540C\u610F RT @HayakawaYukio: \u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u3082\u3001\u8CEA\u554F\u306E\u4ED5\u65B9\u3068\u5185\u5BB9\u3092\u307F\u308C\u3070\u3001\u305D\u306E\u3072\u3068\u306E\u77E5\u8B58\u3068\u5B66\u529B\u3068\u6027\u683C\u304C\u304A\u304A\u3080\u306D\u60F3\u50CF\u3064\u304F\u3002\u60F3\u50CF\u3057\u305F\u3046\u3048\u3067\u3001\u30C4\u30A4\u30C3\u30BF\u30FC\u30DA\u30FC\u30B8\u306B\u3044\u3063\u3066\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u3092\u89B3\u5BDF\u3059\u308B\u3068\u3001\u307B\u307C\u5408\u3063\u3066\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B  for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u65E9\u5DDD\u7531\u7D00\u592B",
        "screen_name" : "HayakawaYukio",
        "indices" : [ 23, 37 ],
        "id_str" : "88581459",
        "id" : 88581459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118116524341997568",
    "text" : "\u79BF\u540C\u3002\u30CD\u30B3\u30A2\u30A4\u30B3\u30F3\u306F\u30C0\u30E1\u306A\u4EBA\u591A\u3044\u306B\u540C\u610F RT @HayakawaYukio: \u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u3082\u3001\u8CEA\u554F\u306E\u4ED5\u65B9\u3068\u5185\u5BB9\u3092\u307F\u308C\u3070\u3001\u305D\u306E\u3072\u3068\u306E\u77E5\u8B58\u3068\u5B66\u529B\u3068\u6027\u683C\u304C\u304A\u304A\u3080\u306D\u60F3\u50CF\u3064\u304F\u3002\u60F3\u50CF\u3057\u305F\u3046\u3048\u3067\u3001\u30C4\u30A4\u30C3\u30BF\u30FC\u30DA\u30FC\u30B8\u306B\u3044\u3063\u3066\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u3092\u89B3\u5BDF\u3059\u308B\u3068\u3001\u307B\u307C\u5408\u3063\u3066\u308B\u3002",
    "id" : 118116524341997568,
    "created_at" : "2011-09-26 00:15:48 +0000",
    "user" : {
      "name" : "\u3081\u3044\u308D\u307E \u65B0\u520A\u300C\u6DFB\u524A\uFF01\u65E5\u672C\u4EBA\u82F1\u8A9E\u300D",
      "screen_name" : "May_Roma",
      "protected" : false,
      "id_str" : "10145862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559338840628817920\/BWt_FklR_normal.jpeg",
      "id" : 10145862,
      "verified" : false
    }
  },
  "id" : 118228967865065472,
  "created_at" : "2011-09-26 07:42:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118224477581606912",
  "text" : "\u3069\u3046\u305B\u4E00\u822C\u6559\u990A\u5E7E\u3064\u304B\u8208\u5473\u3067\u53D6\u308A\u306B\u884C\u304F\u3051\u3069\u3055",
  "id" : 118224477581606912,
  "created_at" : "2011-09-26 07:24:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118224336715911168",
  "text" : "\u5927\u4F53\u5F8C\u671F\u3060\u3051\u3067\u53D6\u308C\u308B\u5C02\u9580\u79D1\u76EE\u5C11\u306A\u3059\u304E\u306A\u3093\u3060\u3088\u3002\u305F\u3060\u3067\u3055\u3048\u8208\u5473\u3042\u308B\u5C02\u9580\u79D1\u76EE\u304C\u5C11\u306A\u3044\u3063\u3066\u306E\u306B\u3002",
  "id" : 118224336715911168,
  "created_at" : "2011-09-26 07:24:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118223969794015232",
  "text" : "\u3042\u3041\u697D\u3057\u3044\u60B2\u3057\u3044\u5C65\u4FEE\u767B\u9332\u3060\u3002",
  "id" : 118223969794015232,
  "created_at" : "2011-09-26 07:22:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "indices" : [ 3, 16 ],
      "id_str" : "96289411",
      "id" : 96289411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118221554982191104",
  "text" : "RT @d_v_osorezan: \u300C\u8AB2\u9577\u3001\u4E73\u767D\u8272\u306B\u8584\u66C7\u3063\u305F\u7A7A\u306E\u3082\u3068\u3067\u50CD\u304D\u87FB\u305F\u3061\u304C\u5922\u306E\u6B20\u7247\u3092\u904B\u3073\u8FBC\u3080\u304B\u306E\u3088\u3046\u306B\u6DE1\u304F\u865A\u3057\u3044\u898B\u7A4D\u66F8\u3092\u6DFB\u4ED8\u3057\u3066\u30E1\u30FC\u30EB\u3057\u3068\u304D\u307E\u3057\u305F\u300D\n\u300C\u30D3\u30B8\u30CD\u30B9\u306B\u8A69\u60C5\u3092\u631F\u3080\u306A\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118212639926136832",
    "text" : "\u300C\u8AB2\u9577\u3001\u4E73\u767D\u8272\u306B\u8584\u66C7\u3063\u305F\u7A7A\u306E\u3082\u3068\u3067\u50CD\u304D\u87FB\u305F\u3061\u304C\u5922\u306E\u6B20\u7247\u3092\u904B\u3073\u8FBC\u3080\u304B\u306E\u3088\u3046\u306B\u6DE1\u304F\u865A\u3057\u3044\u898B\u7A4D\u66F8\u3092\u6DFB\u4ED8\u3057\u3066\u30E1\u30FC\u30EB\u3057\u3068\u304D\u307E\u3057\u305F\u300D\n\u300C\u30D3\u30B8\u30CD\u30B9\u306B\u8A69\u60C5\u3092\u631F\u3080\u306A\u300D",
    "id" : 118212639926136832,
    "created_at" : "2011-09-26 06:37:44 +0000",
    "user" : {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "protected" : false,
      "id_str" : "96289411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3457427933\/e9c1859b77927509e49bcdd8ea328bdb_normal.jpeg",
      "id" : 96289411,
      "verified" : false
    }
  },
  "id" : 118221554982191104,
  "created_at" : "2011-09-26 07:13:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118182389108318208",
  "text" : "\u3042\u30FC\u3001\u304A\u306F\u3088\u3046",
  "id" : 118182389108318208,
  "created_at" : "2011-09-26 04:37:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118182319461904384",
  "text" : "\u3073\u3076\u3093\u305B\u304D\u3076\u3093\u5B66\u79D1\u306E\u79C1\u306B\u306F\u308F\u304B\u308A\u307E\u305B\u3093\u3002",
  "id" : 118182319461904384,
  "created_at" : "2011-09-26 04:37:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3084\u307E\u3082\u3068\u3044\u3061\u308D\u3046",
      "screen_name" : "kirik",
      "indices" : [ 3, 9 ],
      "id_str" : "5191991",
      "id" : 5191991
    }, {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 35, 44 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/afB2HMF1",
      "expanded_url" : "http:\/\/deck.ly\/~wYm7T",
      "display_url" : "deck.ly\/~wYm7T"
    } ]
  },
  "geo" : { },
  "id_str" : "118181625354928128",
  "text" : "RT @kirik: \u533B\u5B66\u79D1\u306E\u304A\u524D\u306B\u4F55\u306E\u4E8B\u60C5\u304C\u308F\u304B\u308B\u3068\u8A00\u3046\u306E\u3060\u3000RT @hanaoka_ \u5B9F\u3092\u8A00\u3046\u3068\u30BD\u30D5\u30C8\u30D0\u30F3\u30AF\u306F\u3082\u3046\u3060\u3081\u3067\u3059\u3002\u7A81\u7136\u3053\u3093\u306A\u3053\u3068\u8A00\u3063\u3066\u3054\u3081\u3093\u306D\u3002\u3067\u3082\u672C\u5F53\u3067\u3059\u3002\n\uFF12\u3001\uFF13\u65E5\u5F8C\u306Bau\u304B\u3089iPhone5\u306E\u88FD\u54C1\u767A\u8868\u304C\u3042\u308A\u307E\u3059\u3002\u305D\u308C\u304C\u7D42\u308F\u308A\u2026 (cont) http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
        "screen_name" : "hanaoka_",
        "indices" : [ 24, 33 ],
        "id_str" : "126927392",
        "id" : 126927392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/afB2HMF1",
        "expanded_url" : "http:\/\/deck.ly\/~wYm7T",
        "display_url" : "deck.ly\/~wYm7T"
      } ]
    },
    "geo" : { },
    "id_str" : "118174757798686720",
    "text" : "\u533B\u5B66\u79D1\u306E\u304A\u524D\u306B\u4F55\u306E\u4E8B\u60C5\u304C\u308F\u304B\u308B\u3068\u8A00\u3046\u306E\u3060\u3000RT @hanaoka_ \u5B9F\u3092\u8A00\u3046\u3068\u30BD\u30D5\u30C8\u30D0\u30F3\u30AF\u306F\u3082\u3046\u3060\u3081\u3067\u3059\u3002\u7A81\u7136\u3053\u3093\u306A\u3053\u3068\u8A00\u3063\u3066\u3054\u3081\u3093\u306D\u3002\u3067\u3082\u672C\u5F53\u3067\u3059\u3002\n\uFF12\u3001\uFF13\u65E5\u5F8C\u306Bau\u304B\u3089iPhone5\u306E\u88FD\u54C1\u767A\u8868\u304C\u3042\u308A\u307E\u3059\u3002\u305D\u308C\u304C\u7D42\u308F\u308A\u2026 (cont) http:\/\/t.co\/afB2HMF1",
    "id" : 118174757798686720,
    "created_at" : "2011-09-26 04:07:12 +0000",
    "user" : {
      "name" : "\u3084\u307E\u3082\u3068\u3044\u3061\u308D\u3046",
      "screen_name" : "kirik",
      "protected" : false,
      "id_str" : "5191991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607872314881896448\/6zjJqiHS_normal.jpg",
      "id" : 5191991,
      "verified" : false
    }
  },
  "id" : 118181625354928128,
  "created_at" : "2011-09-26 04:34:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/gYNDiMFa",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=notbaikin",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118110230847561728",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001notbaikin\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/gYNDiMFa",
  "id" : 118110230847561728,
  "created_at" : "2011-09-25 23:50:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117931597105348608",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 117931597105348608,
  "created_at" : "2011-09-25 12:00:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117803429157535744",
  "text" : "\u304A\u306F\u3088\u3046\u306F\u8D77\u304D\u3066\u304B\u3089\uFF12\u30C4\u30A4\u30FC\u30C8\u76EE\u304C\u30C7\u30D5\u30A9\u30EB\u30C8\u306B\u306A\u3063\u3066\u308B\u306A",
  "id" : 117803429157535744,
  "created_at" : "2011-09-25 03:31:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117803249800720384",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 117803249800720384,
  "created_at" : "2011-09-25 03:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304E\u3087\u305F",
      "screen_name" : "_garren",
      "indices" : [ 3, 11 ],
      "id_str" : "133258574",
      "id" : 133258574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117803090534604800",
  "text" : "RT @_garren: \u300E\u8A3C\u660E\u7565\u304C\u306A\u3044\u25CB\u25CB\u554F\u984C\u96C6\u300F\u3000\u3063\u3066\u540D\u524D\u306B\u3059\u308B\u3068\u58F2\u308C\u308B\u6C17\u304C\u3057\u3066\u304D\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117800330653220864",
    "text" : "\u300E\u8A3C\u660E\u7565\u304C\u306A\u3044\u25CB\u25CB\u554F\u984C\u96C6\u300F\u3000\u3063\u3066\u540D\u524D\u306B\u3059\u308B\u3068\u58F2\u308C\u308B\u6C17\u304C\u3057\u3066\u304D\u305F",
    "id" : 117800330653220864,
    "created_at" : "2011-09-25 03:19:22 +0000",
    "user" : {
      "name" : "\u307E\u304E\u3087\u305F",
      "screen_name" : "_garren",
      "protected" : false,
      "id_str" : "133258574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450656185968885760\/nYljsu9v_normal.jpeg",
      "id" : 133258574,
      "verified" : false
    }
  },
  "id" : 117803090534604800,
  "created_at" : "2011-09-25 03:30:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 11, 22 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117799683593740289",
  "geo" : { },
  "id_str" : "117803004232605696",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu @akiyohmori \u76F8\u8AC7\u304B\u3089\u59CB\u307E\u308B\u5178\u578B\u7684\u306A\u2026\uFF57\uFF57",
  "id" : 117803004232605696,
  "in_reply_to_status_id" : 117799683593740289,
  "created_at" : "2011-09-25 03:29:59 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117651850643243008",
  "text" : "\u4E88\u5B9A\u3088\u308A\u65E9\u3044\u3051\u3069\u304D\u308A\u304C\u3044\u3044\u304B\u3089\u5BDD\u308B\u304B\u306A\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 117651850643243008,
  "created_at" : "2011-09-24 17:29:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117651550855368704",
  "text" : "\u3053\u306E\u4F59\u767D\u306F\u3042\u307E\u308A\u306B\u72ED\u3059\u304E\u308B\u3002",
  "id" : 117651550855368704,
  "created_at" : "2011-09-24 17:28:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117650050766737408",
  "text" : "\u7D19\u5A92\u4F53\u306E\u6700\u5927\u3068\u3082\u8A00\u3063\u3066\u3044\u3044\u6B20\u70B9\u306F\u30B3\u30D4\u30FC\u30A2\u30F3\u30C9\u30DA\u30FC\u30B9\u30C8\u3068\u633F\u5165\u304C\u3067\u304D\u306A\u3044\u4E8B\u3002",
  "id" : 117650050766737408,
  "created_at" : "2011-09-24 17:22:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117645034668556288",
  "text" : "\u591C\u4E2D\u306E\u6570\u5B66\u306E\u306F\u304B\u3069\u308A\u306F\u7570\u5E38\u30022:40\u904E\u304E\u305F\u3089\u5BDD\u308B\u3075\u308A\u3092\u3057\u3088\u3046",
  "id" : 117645034668556288,
  "created_at" : "2011-09-24 17:02:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117632973284716545",
  "text" : "@ayu167 \u305D\u308C\u306A\u304B\u306A\u304B\u5BDD\u308C\u306A\u3044\u305C\uFF57\uFF57\uFF57\uFF57",
  "id" : 117632973284716545,
  "created_at" : "2011-09-24 16:14:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117625316876369921",
  "text" : "\u9006\u30D5\u30EB\u5358\u3068\u3044\u3046\u5358\u8A9E\u306E\u97FF\u304D\u304C\u3053\u306E\u4E0A\u306A\u304F\u5947\u5999\u3002\u5316\u5B66\u4EE5\u5916\u30D5\u30EB\u5358\u3068\u304B\u610F\u5473\u4E0D\u660E\u306A\u3053\u3068\u8A00\u3063\u3066\u308B\u53CB\u4EBA\u304C\u3044\u305F\u304C\u3002\u3002\u3002",
  "id" : 117625316876369921,
  "created_at" : "2011-09-24 15:43:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117623006691471361",
  "geo" : { },
  "id_str" : "117623577460736001",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u3088\u304F\u8A00\u3048\u3070\u8208\u5473\u306E\u5E45\u304C\u5E83\u3044\u3002\u60AA\u304F\u8A00\u3048\u3070\u5668\u7528\u8CA7\u4E4F\u3063\u3066\u3068\u3053\u308D\u3067\u3057\u3087\u3046\u304B\uFF57",
  "id" : 117623577460736001,
  "in_reply_to_status_id" : 117623006691471361,
  "created_at" : "2011-09-24 15:37:00 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117621621468045312",
  "text" : "\u307E\u3041\u3001\u3061\u3087\u3063\u3068\u52C9\u5F37\u3057\u76F4\u3055\u306A\u304D\u3083\u3060\u3051\u3069\u3002\u3067\u3082\u4E16\u754C\u53F2\u306F\u3061\u3087\u3063\u3068\u3058\u3083\u3059\u307E\u306A\u3044\u6C17\u304C\u3059\u308B\u3002",
  "id" : 117621621468045312,
  "created_at" : "2011-09-24 15:29:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 39, 54 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117621509584977920",
  "text" : "\u30BB\u30F3\u30BF\u30FC\u30EC\u30D9\u30EB\u306A\u3089\u4E16\u754C\u53F2\u3088\u308A\u7269\u7406\u306E\u65B9\u304C\u6559\u3048\u3089\u308C\u308B\u3093\u3058\u3083\u306A\u3044\u304B\u7CFB\u6587\u7CFB\u7537\u5B50 RT @haruhalcyoncat \u3080\u3057\u308D\u30BB\u30F3\u30BF\u30FC\u30EC\u30D9\u30EB\u306A\u3089\u5316\u5B66\u3088\u308A\u4E16\u754C\u53F2\u306E\u65B9\u304C\u6559\u3048\u3089\u308C\u308B\u3093\u3058\u3083\u306A\u3044\u304B\u7CFB\u7406\u7CFB\u7537\u5B50\u3002",
  "id" : 117621509584977920,
  "created_at" : "2011-09-24 15:28:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 7, 16 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117615992837906432",
  "text" : "\u3088\u3046\u4FFA RT @koketomi \u663C\u5BDD\u306E\u305B\u3044\u3067\u3055\u3063\u3071\u308A\u7720\u304F\u306A\u3089\u306A\u3044",
  "id" : 117615992837906432,
  "created_at" : "2011-09-24 15:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117612337636184065",
  "text" : "\u663C\u5BDD\u3057\u305F\u304B\u3089\u5168\u304F\u7720\u304F\u306A\u3044orz",
  "id" : 117612337636184065,
  "created_at" : "2011-09-24 14:52:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117589746414395393",
  "geo" : { },
  "id_str" : "117591005615751168",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u306E\u5B50\u30ED\u30B7\u30A2\u8A9E\u306F\u30DA\u30E9\u30DA\u30E9\u3089\u3057\u3044\u304B\u3089\u4F55\u3082\u304B\u3082\u610F\u5473\u308F\u304B\u3093\u306A\u3044\u3088\u306A\u3002",
  "id" : 117591005615751168,
  "in_reply_to_status_id" : 117589746414395393,
  "created_at" : "2011-09-24 13:27:35 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117587998417240064",
  "geo" : { },
  "id_str" : "117588521652461569",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u731B\u8005\u3060\u306A\u3002\u4FFA\u306E\u5B66\u90E8\u306E\u53CB\u4EBA\u306F\u898B\u77E5\u3089\u306C\u9AD8\u6821\u751F\u306B\u30D8\u30D6\u30E9\u30A4\u8A9E\u6559\u3048\u3066\u308B\u307F\u305F\u3044\u3060\u304C\uFF57\uFF57",
  "id" : 117588521652461569,
  "in_reply_to_status_id" : 117587998417240064,
  "created_at" : "2011-09-24 13:17:42 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 34, 44 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117588224704131072",
  "text" : "\u7D50\u5C401024*1024*512\u3092\u8A08\u7B97\uFF1F\u306A\u3093\u304B\u5F15\u3063\u304B\u304B\u308B\u3088\u306A\u30FC RT @end313124 \u4E8C\u306E\u4E8C\u5341\u4E5D\u4E57\u306F\uFF19\u30B1\u30BF\u306E\u6570\u5B57\u306B\u306A\u308A\u3001\u5404\u6841\u306E\u6570\u5B57\u306F\u305D\u308C\u305E\u308C\u7570\u306A\u3063\u3066\u3044\u308B\u3002\u3064\u307E\u308A\u3001\uFF10\u304B\u3089\uFF19\u307E\u3067\u306E\u6570\u5B57\u306E\u3046\u3061\u4E00\u3064\u3060\u3051\u542B\u307E\u308C\u3066\u3044\u306A\u3044\u3002\u305D\u306E\u6570\u5B57\u306F\uFF1F\n\u96FB\u5353\u3067\u3084\u308B\u3068\u7B54\u3048\u306F\uFF14\u3060\u3051\u3069\u3001\u305D\u3046\u3058\u3083\u306A\u3044\u65B9\u6CD5\u3060\u3068\u2026\uFF1F",
  "id" : 117588224704131072,
  "created_at" : "2011-09-24 13:16:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117586672157339650",
  "text" : "\u306B\u305B\u307B\u30FB\u30FB\u30FB\u304A\u524D\u30FB\u30FB\u30FB",
  "id" : 117586672157339650,
  "created_at" : "2011-09-24 13:10:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 3, 13 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117586594646601728",
  "text" : "RT @nisehorrn: @phagerou700 \u306B\u305B\u307B\u306F\u3069\u3070\u306B\u3083\u3093\u306E\u4E8B\u304C\u5927\u597D\u304D\u306A\u306E\u3063\/\/\/\u3000\u3000\u3000\u3000",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117585699154309120",
    "text" : "@phagerou700 \u306B\u305B\u307B\u306F\u3069\u3070\u306B\u3083\u3093\u306E\u4E8B\u304C\u5927\u597D\u304D\u306A\u306E\u3063\/\/\/\u3000\u3000\u3000\u3000",
    "id" : 117585699154309120,
    "created_at" : "2011-09-24 13:06:29 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "protected" : false,
      "id_str" : "96560355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009740902\/06-12-24_23-49_kisee_bigger_normal.jpg",
      "id" : 96560355,
      "verified" : false
    }
  },
  "id" : 117586594646601728,
  "created_at" : "2011-09-24 13:10:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/VDD5iT4a",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117586502002810880",
  "text" : "\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u306E\u3084\u3064\u3000http:\/\/t.co\/VDD5iT4a",
  "id" : 117586502002810880,
  "created_at" : "2011-09-24 13:09:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117583408284184576",
  "text" : "\u4E8C\u306E\u4E8C\u5341\u4E5D\u4E57\u306F\uFF19\u30B1\u30BF\u306E\u6570\u5B57\u306B\u306A\u308A\u3001\u5404\u6841\u306E\u6570\u5B57\u306F\u305D\u308C\u305E\u308C\u7570\u306A\u3063\u3066\u3044\u308B\u3002\u3064\u307E\u308A\u3001\uFF10\u304B\u3089\uFF19\u307E\u3067\u306E\u6570\u5B57\u306E\u3046\u3061\u4E00\u3064\u3060\u3051\u542B\u307E\u308C\u3066\u3044\u306A\u3044\u3002\u305D\u306E\u6570\u5B57\u306F\uFF1F\n\u96FB\u5353\u3067\u3084\u308B\u3068\u7B54\u3048\u306F\uFF14\u3060\u3051\u3069\u3001\u305D\u3046\u3058\u3083\u306A\u3044\u65B9\u6CD5\u3060\u3068\u2026\uFF1F",
  "id" : 117583408284184576,
  "created_at" : "2011-09-24 12:57:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30E1\u30B5\u30D4\u30A8\u30F3\u30B9",
      "screen_name" : "d_sapi",
      "indices" : [ 3, 10 ],
      "id_str" : "223602452",
      "id" : 223602452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117579593854107648",
  "text" : "RT @d_sapi: \u77E5\u308A\u5408\u3044\u306E\u30D6\u30E9\u30C3\u30AF\u904E\u304E\u308B\u30B8\u30E7\u30FC\u30AF\u304C\u597D\u304D\u306A\u7C73\u4EBA\u300C\u304A\u307E\u3048\u3089\u65E5\u672C\u4EBA\u3063\u3066\u4F55\u4E16\u7D00\u306B\u751F\u304D\u3066\u308B\u3093\u3060\u3088\uFF57\uFF57\uFF57\u53F0\u98A8\u306E\u65E5\u306B\u51FA\u52E4\u3068\u304B\u3001\u901A\u4FE1\u30A4\u30F3\u30D5\u30E9\u3069\u3046\u306A\u3063\u3066\u308B\u306E\uFF1F\uFF57\uFF57\u30DF\u30FC\u30C6\u30A3\u30F3\u30B0\uFF1F\u30AA\u30F3\u30E9\u30A4\u30F3\u3067\u3084\u308C\u3088\uFF57\uFF57\uFF57\uFF57\u9867\u5BA2\uFF1F\u9867\u5BA2\u3060\u3063\u3066\u81EA\u5B85\u52E4\u52D9\u3060\u3088\uFF57\uFF57\uFF57\u300D\u30FB\u30FB\u30FB\u30FB\u5168\u304F\u305D\u306E\u901A\u308A\u3067\u3059\u30FB\u30FB\u30FB\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tabtter.jp\" rel=\"nofollow\"\u003ETabtter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116461236358619136",
    "text" : "\u77E5\u308A\u5408\u3044\u306E\u30D6\u30E9\u30C3\u30AF\u904E\u304E\u308B\u30B8\u30E7\u30FC\u30AF\u304C\u597D\u304D\u306A\u7C73\u4EBA\u300C\u304A\u307E\u3048\u3089\u65E5\u672C\u4EBA\u3063\u3066\u4F55\u4E16\u7D00\u306B\u751F\u304D\u3066\u308B\u3093\u3060\u3088\uFF57\uFF57\uFF57\u53F0\u98A8\u306E\u65E5\u306B\u51FA\u52E4\u3068\u304B\u3001\u901A\u4FE1\u30A4\u30F3\u30D5\u30E9\u3069\u3046\u306A\u3063\u3066\u308B\u306E\uFF1F\uFF57\uFF57\u30DF\u30FC\u30C6\u30A3\u30F3\u30B0\uFF1F\u30AA\u30F3\u30E9\u30A4\u30F3\u3067\u3084\u308C\u3088\uFF57\uFF57\uFF57\uFF57\u9867\u5BA2\uFF1F\u9867\u5BA2\u3060\u3063\u3066\u81EA\u5B85\u52E4\u52D9\u3060\u3088\uFF57\uFF57\uFF57\u300D\u30FB\u30FB\u30FB\u30FB\u5168\u304F\u305D\u306E\u901A\u308A\u3067\u3059\u30FB\u30FB\u30FB\u3002",
    "id" : 116461236358619136,
    "created_at" : "2011-09-21 10:38:17 +0000",
    "user" : {
      "name" : "\u30C0\u30E1\u30B5\u30D4\u30A8\u30F3\u30B9",
      "screen_name" : "d_sapi",
      "protected" : false,
      "id_str" : "223602452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059471168\/c038fbfe67c0a65637032049c909d23c_normal.jpeg",
      "id" : 223602452,
      "verified" : false
    }
  },
  "id" : 117579593854107648,
  "created_at" : "2011-09-24 12:42:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117571674207035392",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 117571674207035392,
  "created_at" : "2011-09-24 12:10:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117571509517697024",
  "text" : "\u663C\u5BDD\u3057\u3061\u3083\u3063\u305F\u30024\u6642\u9593\u307B\u3069\uFF57\uFF57\uFF57\uFF57",
  "id" : 117571509517697024,
  "created_at" : "2011-09-24 12:10:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117569362604466176",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 117569362604466176,
  "created_at" : "2011-09-24 12:01:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    }, {
      "name" : "\u30C6\u30A4\u30EB\u30BA\u30FB\u30AA\u30D6\u30FB\u6F22\u30AA\u30BB\u30C1\u30A2@\u3075\u3093\u3059\uFF01",
      "screen_name" : "osetia_kaguya",
      "indices" : [ 25, 39 ],
      "id_str" : "56097393",
      "id" : 56097393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117507471672737792",
  "text" : "RT @dovanyahn: (\uFF1B\u30FB\u2200\u30FB) RT @osetia_kaguya: \u5730\u7403\u3092\u5D29\u58CA\u3055\u305B\u308B\u546A\u6587\u300C\u30C9\u30A5\u30FC\u30D0\u30FB\u30CB\u30FB\u30E4\u30FC\u30F3\u300D(\u6697\u9ED2\u5FAE\u7B11",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30C6\u30A4\u30EB\u30BA\u30FB\u30AA\u30D6\u30FB\u6F22\u30AA\u30BB\u30C1\u30A2@\u3075\u3093\u3059\uFF01",
        "screen_name" : "osetia_kaguya",
        "indices" : [ 10, 24 ],
        "id_str" : "56097393",
        "id" : 56097393
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117506933610647552",
    "text" : "(\uFF1B\u30FB\u2200\u30FB) RT @osetia_kaguya: \u5730\u7403\u3092\u5D29\u58CA\u3055\u305B\u308B\u546A\u6587\u300C\u30C9\u30A5\u30FC\u30D0\u30FB\u30CB\u30FB\u30E4\u30FC\u30F3\u300D(\u6697\u9ED2\u5FAE\u7B11",
    "id" : 117506933610647552,
    "created_at" : "2011-09-24 07:53:30 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 117507471672737792,
  "created_at" : "2011-09-24 07:55:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117505832077377536",
  "geo" : { },
  "id_str" : "117506401076649984",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u611F\u60F3\u3088\u308D\u3057\u304F",
  "id" : 117506401076649984,
  "in_reply_to_status_id" : 117505832077377536,
  "created_at" : "2011-09-24 07:51:23 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u982D\u306B\u5BFE\u6226\u8ECA\u3092\u3064\u3051\u308B\u3068\u5F37\u529B\u305D\u3046\u306B\u306A\u308B",
      "indices" : [ 8, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117505131465031680",
  "text" : "\u5BFE\u6226\u8ECA\u5E38\u7528\u5BFE\u6570 #\u982D\u306B\u5BFE\u6226\u8ECA\u3092\u3064\u3051\u308B\u3068\u5F37\u529B\u305D\u3046\u306B\u306A\u308B",
  "id" : 117505131465031680,
  "created_at" : "2011-09-24 07:46:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117502744796987393",
  "text" : "ne mu i",
  "id" : 117502744796987393,
  "created_at" : "2011-09-24 07:36:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3048\u304F\u3059\u308F\u3044\u3048\u304F\u3059 \/ xyx",
      "screen_name" : "xyx_is",
      "indices" : [ 3, 10 ],
      "id_str" : "42594957",
      "id" : 42594957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117488012115443712",
  "text" : "RT @xyx_is: \u81EA\u7136\u6570\u306F\u666E\u901A0\u306B\u5165\u3089\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117483260392636416",
    "text" : "\u81EA\u7136\u6570\u306F\u666E\u901A0\u306B\u5165\u3089\u306A\u3044",
    "id" : 117483260392636416,
    "created_at" : "2011-09-24 06:19:26 +0000",
    "user" : {
      "name" : "\u3048\u304F\u3059\u308F\u3044\u3048\u304F\u3059 \/ xyx",
      "screen_name" : "xyx_is",
      "protected" : false,
      "id_str" : "42594957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1169913697\/teruyo_icon5_mikan_normal.png",
      "id" : 42594957,
      "verified" : false
    }
  },
  "id" : 117488012115443712,
  "created_at" : "2011-09-24 06:38:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117444469544062976",
  "geo" : { },
  "id_str" : "117445247499370496",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30A6\u30A3\u30B9\u30AD\u30FC\u3082\u3042\u3046\u3088",
  "id" : 117445247499370496,
  "in_reply_to_status_id" : 117444469544062976,
  "created_at" : "2011-09-24 03:48:23 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117429237354463234",
  "geo" : { },
  "id_str" : "117441820346171392",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3042\u300127\u65E5\u306B\u30B5\u30FC\u30AF\u30EB\u306E\u4E88\u5B9A\u3067\u3059\u3002\u8FFD\u3063\u3066\u9023\u7D61\u3057\u307E\u3059\u304C\u3002",
  "id" : 117441820346171392,
  "in_reply_to_status_id" : 117429237354463234,
  "created_at" : "2011-09-24 03:34:46 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117441563600232448",
  "text" : "\u5BD2\u3044\u3068\u9F3B\u306E\u8ABF\u5B50\u304C\u60AA\u304F\u306A\u308B\u3002\u308F\u304B\u308A\u3084\u3059\u304F\u3066\u3044\u3044\u3002",
  "id" : 117441563600232448,
  "created_at" : "2011-09-24 03:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117440632468934656",
  "text" : "\u6614\u306E\u30AD\u30EC\u304C\u306A\u3044\u3088\u306A\u30FC\u3002\u30DE\u30B8\u30AD\u30C1\u611F\u304C\u8584\u3044\u3002",
  "id" : 117440632468934656,
  "created_at" : "2011-09-24 03:30:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/BZCHsazU",
      "expanded_url" : "http:\/\/twitpic.com\/6pl6r4",
      "display_url" : "twitpic.com\/6pl6r4"
    } ]
  },
  "geo" : { },
  "id_str" : "117440507545780225",
  "text" : "RT @dovanyahn: \u5E74\u306B\u4E00\u5EA6\u306E\u8A08\u753B\u767A\u96FB http:\/\/t.co\/BZCHsazU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 30 ],
        "url" : "http:\/\/t.co\/BZCHsazU",
        "expanded_url" : "http:\/\/twitpic.com\/6pl6r4",
        "display_url" : "twitpic.com\/6pl6r4"
      } ]
    },
    "geo" : { },
    "id_str" : "117439573793046528",
    "text" : "\u5E74\u306B\u4E00\u5EA6\u306E\u8A08\u753B\u767A\u96FB http:\/\/t.co\/BZCHsazU",
    "id" : 117439573793046528,
    "created_at" : "2011-09-24 03:25:50 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 117440507545780225,
  "created_at" : "2011-09-24 03:29:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117439881298452481",
  "text" : "\u3053\u306E\u524D\u307E\u3067\u6691\u304F\u3066\u76EE\u3092\u899A\u307E\u3057\u3066\u305F\u306E\u306B\u3001\u5BD2\u304F\u3066\u76EE\u3092\u899A\u307E\u3057\u305F\u3002\u79CB\u304C\u5510\u7A81\u306B\u3002",
  "id" : 117439881298452481,
  "created_at" : "2011-09-24 03:27:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117437736654348288",
  "text" : "\u5BD2\u3044\u2026\u304A\u306F\u3088\u3046",
  "id" : 117437736654348288,
  "created_at" : "2011-09-24 03:18:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117303689772924928",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 117303689772924928,
  "created_at" : "2011-09-23 18:25:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117296983986806784",
  "text" : "@mo5nya \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 117296983986806784,
  "created_at" : "2011-09-23 17:59:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117296710128119808",
  "text" : "\u5BDD\u8A00\u3092\u5410\u304F\uFF1F\u5BDD\u8A00\u3092\u5F04\u3059\u308B\uFF1F",
  "id" : 117296710128119808,
  "created_at" : "2011-09-23 17:58:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117296388886372352",
  "text" : "\u3072\u3068\u3057\u304D\u308A\u5BDD\u8A00\u8A00\u3063\u305F\u3057\u5BDD\u308B\u304B\u3002\n\n\u3093\uFF1F\u5BDD\u8A00\u3092\u8A00\u3046\u3063\u3066\u91CD\u8907\uFF1F",
  "id" : 117296388886372352,
  "created_at" : "2011-09-23 17:56:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117295749259198465",
  "text" : "\u9AD8\u6821\u306E\u884C\u4E8B\u3068\u304B\u3067\u300C\u62CD\u624B\u3092\u304A\u9858\u3044\u3057\u307E\u3059\u300D\u3068\u304B\u3084\u3063\u3066\u305F\u3051\u3069\u304A\u9858\u3044\u3055\u308C\u3066\u3084\u308B\u62CD\u624B\u306B\u610F\u5473\u304C\u3042\u308B\u306E\u304B\u3068\u7591\u554F\u3060\u3063\u305F",
  "id" : 117295749259198465,
  "created_at" : "2011-09-23 17:54:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117295491741519872",
  "text" : "\u3084\u3063\u3071\u81EA\u767A\u7684\u3058\u3083\u306A\u3044\u3068\u610F\u5473\u304C\u306A\u3044\u3053\u3068\u3063\u3066\u6CA2\u5C71\u3042\u308B\u3068\u601D\u3046\u3093\u3060\u3088\u306A\u30FC\u3002\u611F\u8B1D\u3068\u304B\u3002",
  "id" : 117295491741519872,
  "created_at" : "2011-09-23 17:53:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117295234634887168",
  "text" : "\u4ED6\u4EBA\u306B\u4F55\u304B\u3092\u5F37\u8981\u3059\u308B\u306E\u306F\u5ACC\u3044\u3002\u81EA\u5206\u304C\u305D\u3046\u3055\u308C\u308B\u306E\u304C\u5ACC\u3060\u304B\u3089\u3002",
  "id" : 117295234634887168,
  "created_at" : "2011-09-23 17:52:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117294831704883200",
  "text" : "\u307E\u3001\u3053\u306E\u624B\u306E\u30BF\u30B0\u306F\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u304F\u53CD\u5FDC\u3092\u8981\u6C42\u3059\u308B\u304B\u3089\u99B4\u308C\u5408\u3044\u8272\u5F37\u304F\u306A\u308B\u306E\u306F\u6C17\u306B\u306A\u308B\u306A\u30FC\u3002\u4E71\u767A\u306F\u907F\u3051\u305F\u3044\u3002",
  "id" : 117294831704883200,
  "created_at" : "2011-09-23 17:50:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4F1A\u3063\u305F\u3053\u3068\u306E\u306A\u3044\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u7B2C\u4E00\u5370\u8C61\u3092\u304A\u3057\u3048\u3066\u304F\u308C\u308B",
      "indices" : [ 9, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117294178756599809",
  "text" : "\u3053\u3063\u3061\u306E\u304C\u6016\u3044\u304B #\u4F1A\u3063\u305F\u3053\u3068\u306E\u306A\u3044\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u7B2C\u4E00\u5370\u8C61\u3092\u304A\u3057\u3048\u3066\u304F\u308C\u308B",
  "id" : 117294178756599809,
  "created_at" : "2011-09-23 17:48:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117293665281511425",
  "text" : "\u7B2C\u4E00\u5370\u8C61\u3066\u6570\u79D2\u3067\u6C7A\u307E\u308B\u3089\u3057\u3044\u306D\u30FC\u3002\u305D\u308A\u3083\u7B2C\u4E00\u3060\u304B\u3089\u5F53\u305F\u308A\u524D\u3060\u3051\u3069\u3002",
  "id" : 117293665281511425,
  "created_at" : "2011-09-23 17:46:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4F1A\u3063\u305F\u3053\u3068\u306E\u3042\u308B\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u7B2C\u4E00\u5370\u8C61\u3092\u304A\u3057\u3048\u3066\u304F\u308C\u308B",
      "indices" : [ 14, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117293123717185536",
  "text" : "\u81EA\u5206\u3092\u5BA2\u89B3\u8996\u3059\u308B\u52C7\u6C17\u3001\u6016\u3044 #\u4F1A\u3063\u305F\u3053\u3068\u306E\u3042\u308B\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u7B2C\u4E00\u5370\u8C61\u3092\u304A\u3057\u3048\u3066\u304F\u308C\u308B",
  "id" : 117293123717185536,
  "created_at" : "2011-09-23 17:43:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117291944912224256",
  "text" : "@mo5nya \u3061\u3087\u3063\u3068\u5272\u9AD8\u3067\u3059\u304C\u8272\u3005\u98DF\u3079\u308C\u308B\u306E\u306F\u3044\u3044\u3067\u3059\u3088\u306D\u3002\u98DF\u3079\u308B\u9806\u756A\u3068\u304B\u3067\u5E78\u305B\u306B\u60A9\u3081\u307E\u3059\u3002",
  "id" : 117291944912224256,
  "created_at" : "2011-09-23 17:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117291687730098176",
  "text" : "\u6628\u65E5\u3060\u304B\u4E00\u6628\u65E5\u306E\u30E9\u30FC\u30E1\u30F3\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u3082\u8F9B\u304B\u3063\u305F\u306A",
  "id" : 117291687730098176,
  "created_at" : "2011-09-23 17:38:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117291517630095360",
  "text" : "\u30DF\u30B9\u30C9\u2026\u7A7A\u8179\u2026\u3002",
  "id" : 117291517630095360,
  "created_at" : "2011-09-23 17:37:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117290979958067200",
  "geo" : { },
  "id_str" : "117291325799403521",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4E00\u5FDC\u4E0D\u7279\u5B9A\u591A\u6570\u304C\u898B\u3046\u308B\u306E\u3067\u3002",
  "id" : 117291325799403521,
  "in_reply_to_status_id" : 117290979958067200,
  "created_at" : "2011-09-23 17:36:45 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u307F\u3093\u306A\u30DF\u30B9\u30C9\u306E\u597D\u304D\u306A\u30C9\u30FC\u30CA\u30C4\u6652\u305B\u3088",
      "indices" : [ 29, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117291158501208064",
  "text" : "\u5730\u5473\u306B\u30C1\u30E7\u30B3\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u3068\u304B\u597D\u304D\u3002\u30D5\u30EC\u30F3\u30C1\u30AF\u30EB\u30FC\u30E9\u30FC\u3082\u3002 #\u307F\u3093\u306A\u30DF\u30B9\u30C9\u306E\u597D\u304D\u306A\u30C9\u30FC\u30CA\u30C4\u6652\u305B\u3088",
  "id" : 117291158501208064,
  "created_at" : "2011-09-23 17:36:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117290789612163072",
  "text" : "D\u30DD\u30C3\u30D7\u3066\u8B0E\u306E\u8D05\u6CA2\u611F\u3042\u308B\u3088\u306D",
  "id" : 117290789612163072,
  "created_at" : "2011-09-23 17:34:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*\u304B\u3059\u307F\u3093*",
      "screen_name" : "kasumin_107",
      "indices" : [ 3, 15 ],
      "id_str" : "212745077",
      "id" : 212745077
    }, {
      "name" : "\u3084\u304E\u307D\u3093",
      "screen_name" : "yagi__pon",
      "indices" : [ 34, 44 ],
      "id_str" : "271557325",
      "id" : 271557325
    }, {
      "name" : "\u306A\u3064\u304D\u3093\u3050",
      "screen_name" : "natsukinator",
      "indices" : [ 65, 78 ],
      "id_str" : "223880385",
      "id" : 223880385
    }, {
      "name" : "\u3084\u304E\u307D\u3093",
      "screen_name" : "yagi__pon",
      "indices" : [ 92, 102 ],
      "id_str" : "271557325",
      "id" : 271557325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u307F\u3093\u306A\u30DF\u30B9\u30C9\u306E\u597D\u304D\u306A\u30C9\u30FC\u30CA\u30C4\u6652\u305B\u3088",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117290649782452224",
  "text" : "RT @kasumin_107: \u30D5\u30EC\u30F3\u30C1\u30AF\u30EB\u30FC\u30E9\u30FC \u4E00\u629E\u3002\nRT @yagi__pon: \u30CF\u30CB\u30FC\u304C\u304B\u304B\u3063\u3066\u308C\u3070\u306A\u3093\u3067\u3082\u3002 RT @natsukinator: \u30CF\u30CB\u30FC\u30C1\u30E5\u30ED\u4E00\u629E\u3002RT @yagi__pon \u30CF\u30CB\u30FC\u30C7\u30A3\u30C3\u30D7\u3002  #\u307F\u3093\u306A\u30DF\u30B9\u30C9\u306E\u597D\u304D\u306A\u30C9\u30FC\u30CA\u30C4\u6652\u305B\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3084\u304E\u307D\u3093",
        "screen_name" : "yagi__pon",
        "indices" : [ 17, 27 ],
        "id_str" : "271557325",
        "id" : 271557325
      }, {
        "name" : "\u306A\u3064\u304D\u3093\u3050",
        "screen_name" : "natsukinator",
        "indices" : [ 48, 61 ],
        "id_str" : "223880385",
        "id" : 223880385
      }, {
        "name" : "\u3084\u304E\u307D\u3093",
        "screen_name" : "yagi__pon",
        "indices" : [ 75, 85 ],
        "id_str" : "271557325",
        "id" : 271557325
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u307F\u3093\u306A\u30DF\u30B9\u30C9\u306E\u597D\u304D\u306A\u30C9\u30FC\u30CA\u30C4\u6652\u305B\u3088",
        "indices" : [ 96, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117289823361957890",
    "text" : "\u30D5\u30EC\u30F3\u30C1\u30AF\u30EB\u30FC\u30E9\u30FC \u4E00\u629E\u3002\nRT @yagi__pon: \u30CF\u30CB\u30FC\u304C\u304B\u304B\u3063\u3066\u308C\u3070\u306A\u3093\u3067\u3082\u3002 RT @natsukinator: \u30CF\u30CB\u30FC\u30C1\u30E5\u30ED\u4E00\u629E\u3002RT @yagi__pon \u30CF\u30CB\u30FC\u30C7\u30A3\u30C3\u30D7\u3002  #\u307F\u3093\u306A\u30DF\u30B9\u30C9\u306E\u597D\u304D\u306A\u30C9\u30FC\u30CA\u30C4\u6652\u305B\u3088",
    "id" : 117289823361957890,
    "created_at" : "2011-09-23 17:30:47 +0000",
    "user" : {
      "name" : "*\u304B\u3059\u307F\u3093*",
      "screen_name" : "kasumin_107",
      "protected" : false,
      "id_str" : "212745077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700333471\/kasumin_107_normal.jpg",
      "id" : 212745077,
      "verified" : false
    }
  },
  "id" : 117290649782452224,
  "created_at" : "2011-09-23 17:34:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 10, 20 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117289093297213441",
  "text" : "\u3069\u30FC\u304B\u3093\u3067\u3059 RT @blackVELU: ( \u25E0\u203F\u25E0 ) \u3069\u304B\u3093\u304C\u3069\u3063\u304B\u3093",
  "id" : 117289093297213441,
  "created_at" : "2011-09-23 17:27:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117287303348621312",
  "geo" : { },
  "id_str" : "117288122961756160",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4E00\u5FDC\u6253\u3066\u307E\u3059\u304C\u4ECA\u65E5\u306F\u307E\u3060\u5E30\u7701\u3057\u3066\u308B\u307F\u305F\u3044\u3067\u3059\u3002",
  "id" : 117288122961756160,
  "in_reply_to_status_id" : 117287303348621312,
  "created_at" : "2011-09-23 17:24:02 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117286204273205250",
  "geo" : { },
  "id_str" : "117286575699787776",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4E45\u3005\u306B\u968F\u5206\u8CA0\u3051\u307E\u3057\u305F\u30FC\u3002\u307E\u3041\u30CE\u30FC\u30EC\u30FC\u30C8\u3067\u3059\u3057\u697D\u3057\u304B\u3063\u305F\u3067\u3059\u3088\u3002",
  "id" : 117286575699787776,
  "in_reply_to_status_id" : 117286204273205250,
  "created_at" : "2011-09-23 17:17:53 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117285840262152192",
  "text" : "\u4E00\u5411\u8074\u304B\u3089\u9577\u3044\u9EBB\u96C0\u3060\u3063\u305F\u30FC\u3002\u7D50\u679C\u306F\u304A\u5BDF\u3057\u4E0B\u3055\u3044\u3002",
  "id" : 117285840262152192,
  "created_at" : "2011-09-23 17:14:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117284508717424640",
  "text" : "\u5E30\u5B85\uFF67\uFF01",
  "id" : 117284508717424640,
  "created_at" : "2011-09-23 17:09:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 7, 14 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30A2\u30A4\u30B3\u30F3\u306B\u306B\u3083\u30FC\u3068\u8A00\u308F\u305B\u3066\u307F\u308B",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117284428224536577",
  "text" : "\u306B\u3083\u30FC RT @ayu167: \u306B\u3083\u30FC #\u30A2\u30A4\u30B3\u30F3\u306B\u306B\u3083\u30FC\u3068\u8A00\u308F\u305B\u3066\u307F\u308B",
  "id" : 117284428224536577,
  "created_at" : "2011-09-23 17:09:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117283767814586368",
  "text" : "@nico_reflexio \u79FB\u8EE2\u3057\u305F\u3002\u7DBA\u9E97\u3067\u826F\u304B\u3063\u305F\u3088\u3002",
  "id" : 117283767814586368,
  "created_at" : "2011-09-23 17:06:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117166879516270592",
  "geo" : { },
  "id_str" : "117170449225498624",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u96E2\u8131\u3092\u96E2\u8131\u3068\u9D5C\u5451\u307F\u306B\u3057\u3066\u826F\u3044\u306E\u304B\uFF1F",
  "id" : 117170449225498624,
  "in_reply_to_status_id" : 117166879516270592,
  "created_at" : "2011-09-23 09:36:26 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117166595444445185",
  "text" : "\u96E2\u8131\u3063",
  "id" : 117166595444445185,
  "created_at" : "2011-09-23 09:21:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117163555618430976",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u51FA\u304B\u3051\u3088\u3046",
  "id" : 117163555618430976,
  "created_at" : "2011-09-23 09:09:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117163457199095810",
  "text" : "\u5E73\u65E510\uFF5E17\u6642\uFF08\u571F\u65E5\u795D\u4F11\u696D\uFF09\u3063\u3066\u6765\u9031\u6708\u66DC\u307E\u3067\u7384\u95A2\u306B\u304A\u8377\u7269\u304B\u3088orz",
  "id" : 117163457199095810,
  "created_at" : "2011-09-23 09:08:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117162999755718656",
  "text" : "\u9811\u5F35\u308C\u3070\u7F6E\u3051\u305D\u3046\u3060\u3051\u3069\u306D\uFF57\u4EE3\u91D1\u306F\u5F53\u7136\u4E00\u3064\u5206\u3057\u304B\u652F\u6255\u3063\u3066\u306A\u3044\u3088\uFF01",
  "id" : 117162999755718656,
  "created_at" : "2011-09-23 09:06:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117162782083923968",
  "text" : "\u3069\u3046\u3044\u3046\u308F\u3051\u304B\u5148\u65E5\u983C\u3093\u3060\u672C\u68DA\u304C\u3082\u3046\u4E00\u3064\u5C4A\u3044\u305F\u3002\u6CE8\u6587\u30DC\u30BF\u30F3\u3092\u500D\u30D7\u30C3\u30B7\u30E5\u3057\u305F\u308A\u3057\u3066\u306A\u3044\u3093\u3060\u3051\u3069\u306A\u3002\u306A\u306B\u306F\u3068\u3082\u3042\u308C\u30B5\u30DD\u30FC\u30C8\u30BB\u30F3\u30BF\u30FC\u306B\u9023\u7D61\u3002",
  "id" : 117162782083923968,
  "created_at" : "2011-09-23 09:05:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117157347469697024",
  "text" : "@koketomi \nkoketomi\u300C\u30C7\u30E5\u30D5\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u30C7\u30E5\u30D5\uFF57\uFF57\uFF57\uFF57\u300D\n\u65E9\u82D7\u300C\u3046\u308F\u2026\uFF08\u82E6\u7B11\uFF09\u300D",
  "id" : 117157347469697024,
  "created_at" : "2011-09-23 08:44:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3089\u306A\u308B\u30FC\u305F",
      "screen_name" : "ranaluta",
      "indices" : [ 3, 12 ],
      "id_str" : "147605201",
      "id" : 147605201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117140521683664896",
  "text" : "RT @ranaluta: LC\u3068\u304B\u3044\u305F\u3089\uFF62locally compact\u3060\uFF01\uFF63\u3068\u3044\u3046\u4EBA\u3068\uFF62locally convex\u3060\uFF01\uFF63\u3068\u3044\u3046\u4EBA\u3068\uFF62Levi-Civita\u3060\uFF01\uFF63\u3068\u3044\u3046\u4EBA\u304C\u8133\u5185\u3067\u55A7\u5629\u3092\u3057\u3066\u3044\u308B\u3093\u3060\u3051\u3069\u3001\u4E00\u4EBA\u76EE\u304C\u6B8B\u308A\u3092\u8E42\u8E99\u3057\u3066\u3066\u306A\u3093\u304B\u8FBA\u308A\u306F\u8840\u306E\u6D77",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117129920659988480",
    "text" : "LC\u3068\u304B\u3044\u305F\u3089\uFF62locally compact\u3060\uFF01\uFF63\u3068\u3044\u3046\u4EBA\u3068\uFF62locally convex\u3060\uFF01\uFF63\u3068\u3044\u3046\u4EBA\u3068\uFF62Levi-Civita\u3060\uFF01\uFF63\u3068\u3044\u3046\u4EBA\u304C\u8133\u5185\u3067\u55A7\u5629\u3092\u3057\u3066\u3044\u308B\u3093\u3060\u3051\u3069\u3001\u4E00\u4EBA\u76EE\u304C\u6B8B\u308A\u3092\u8E42\u8E99\u3057\u3066\u3066\u306A\u3093\u304B\u8FBA\u308A\u306F\u8840\u306E\u6D77",
    "id" : 117129920659988480,
    "created_at" : "2011-09-23 06:55:23 +0000",
    "user" : {
      "name" : "\u3089\u306A\u308B\u30FC\u305F",
      "screen_name" : "ranaluta",
      "protected" : false,
      "id_str" : "147605201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566114293683191808\/HxbAkcnp_normal.jpeg",
      "id" : 147605201,
      "verified" : false
    }
  },
  "id" : 117140521683664896,
  "created_at" : "2011-09-23 07:37:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117131131085799424",
  "geo" : { },
  "id_str" : "117131311524757504",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u306B\u305B\u307B\u30FC",
  "id" : 117131311524757504,
  "in_reply_to_status_id" : 117131131085799424,
  "created_at" : "2011-09-23 07:00:55 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 11, 25 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117130303323123712",
  "geo" : { },
  "id_str" : "117130692969758720",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @nico_reflexio \u51FA\u6765\u308B\u3068\u3057\u305F\u3089\u5E74\u672B\u5E74\u59CB\u304B\u306A\u30FC\u3002\u3042\u3068\u4E00\u4EBA\u96C6\u3081\u306A\u3044\u3068\u306D\u3002",
  "id" : 117130692969758720,
  "in_reply_to_status_id" : 117130303323123712,
  "created_at" : "2011-09-23 06:58:28 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117130268699144192",
  "text" : "\u9762\u5B50\u304C\u96C6\u307E\u3089\u306A\u3044\u3088\u3046",
  "id" : 117130268699144192,
  "created_at" : "2011-09-23 06:56:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117130057167814656",
  "text" : "\u3010\u7DE9\u52DF\u3011\u4ECA\u65E5\u5915\u65B9\u304B\u3089\u591C\u306B\u304B\u3051\u3066\u9EBB\u96C0\u3067\u304D\u308B\u4EAC\u90FD\u306E\u4EBA\u3001\u4E00\u4EBA\u3002\u96C0\u8358\u3067\u3082\u53CB\u4EBA\u5B85\u3067\u3082\u3002",
  "id" : 117130057167814656,
  "created_at" : "2011-09-23 06:55:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 11, 25 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117129201617874944",
  "geo" : { },
  "id_str" : "117129585262465024",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @nico_reflexio \u5927\u6B53\u8FCE\u3060\u305C\u3002\u30CD\u30C3\u30C8\u3060\u3068\u697D\u3060\u3051\u3069\u5E30\u3063\u305F\u6642\u306B\u5353\u3092\u56F2\u3080\u306E\u3082\u60AA\u304F\u306A\u3044\u306A\u3002",
  "id" : 117129585262465024,
  "in_reply_to_status_id" : 117129201617874944,
  "created_at" : "2011-09-23 06:54:03 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117125181788520448",
  "text" : "@nico_reflexio \u3044\u3084\u3001\u4ECA\u6669\u4EAC\u90FD\u3067\u3084\u308B\u306E\u3055\u3002\u306B\u3057\u3066\u3082\u5473\u6C17\u306A\u3044\u751F\u653E\u9001\u3060\u306A\u3002",
  "id" : 117125181788520448,
  "created_at" : "2011-09-23 06:36:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117115288398467072",
  "text" : "3\u4EBA\u6253\u3061\u306F\u30FB\u30FB\u30FB\u5FAE\u5999\u306A\u3093\u3060\u3088\u306A\u30FC\u3002\u77E5\u308A\u5408\u3044\u5E30\u7701\u3084\u3089\u4F55\u3084\u3089\u3067\u5168\u7136\u96C6\u307E\u3093\u306A\u3044orz",
  "id" : 117115288398467072,
  "created_at" : "2011-09-23 05:57:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117114190392598528",
  "text" : "\u3042\u30FC\u9EBB\u96C0\u306E\u9762\u5B50\u304C\u4E00\u4EBA\u8DB3\u308A\u306A\u3044\u30FB\u30FB\u30FB\uFF01",
  "id" : 117114190392598528,
  "created_at" : "2011-09-23 05:52:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pomme doux et bon",
      "screen_name" : "deninigi",
      "indices" : [ 0, 9 ],
      "id_str" : "186463462",
      "id" : 186463462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117104514233933824",
  "geo" : { },
  "id_str" : "117104687370616832",
  "in_reply_to_user_id" : 186463462,
  "text" : "@deninigi \u5E30\u3063\u3066\u304D\u305F\uFF1F",
  "id" : 117104687370616832,
  "in_reply_to_status_id" : 117104514233933824,
  "created_at" : "2011-09-23 05:15:07 +0000",
  "in_reply_to_screen_name" : "deninigi",
  "in_reply_to_user_id_str" : "186463462",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phase_tr",
      "screen_name" : "phase_tr",
      "indices" : [ 3, 12 ],
      "id_str" : "1180951171",
      "id" : 1180951171
    }, {
      "name" : "\u8302\u6728\u5065\u4E00\u90CE",
      "screen_name" : "kenichiromogi",
      "indices" : [ 40, 54 ],
      "id_str" : "92686016",
      "id" : 92686016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/xxcQeUKc",
      "expanded_url" : "http:\/\/togetter.com\/li\/191462",
      "display_url" : "togetter.com\/li\/191462"
    } ]
  },
  "geo" : { },
  "id_str" : "117093766908747776",
  "text" : "RT @phase_tr: .kentasinjyou \u3055\u3093\u306E\u300C\u8302\u6728\u5065\u4E00\u90CE\u3055\u3093 @kenichiromogi \u300C\u30B5\u30F3\u30D7\u30EA\u30F3\u30B0\u306F\u3001\u3082\u3057\u3084\u308B\u3068\u3057\u305F\u3089\u3001\u307E\u3058\u3081\u306B\u3084\u3063\u305F\u65B9\u304C\u3044\u3044\u3002\u300D\u300D\u3092\u304A\u6C17\u306B\u5165\u308A\u306B\u3057\u307E\u3057\u305F\u3002 \u5E02\u6C11\u7D71\u8A08\u5B66\u3092\u582A\u80FD\u3057\u305F http:\/\/t.co\/xxcQeUKc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u8302\u6728\u5065\u4E00\u90CE",
        "screen_name" : "kenichiromogi",
        "indices" : [ 26, 40 ],
        "id_str" : "92686016",
        "id" : 92686016
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/xxcQeUKc",
        "expanded_url" : "http:\/\/togetter.com\/li\/191462",
        "display_url" : "togetter.com\/li\/191462"
      } ]
    },
    "geo" : { },
    "id_str" : "117034344220065792",
    "text" : ".kentasinjyou \u3055\u3093\u306E\u300C\u8302\u6728\u5065\u4E00\u90CE\u3055\u3093 @kenichiromogi \u300C\u30B5\u30F3\u30D7\u30EA\u30F3\u30B0\u306F\u3001\u3082\u3057\u3084\u308B\u3068\u3057\u305F\u3089\u3001\u307E\u3058\u3081\u306B\u3084\u3063\u305F\u65B9\u304C\u3044\u3044\u3002\u300D\u300D\u3092\u304A\u6C17\u306B\u5165\u308A\u306B\u3057\u307E\u3057\u305F\u3002 \u5E02\u6C11\u7D71\u8A08\u5B66\u3092\u582A\u80FD\u3057\u305F http:\/\/t.co\/xxcQeUKc",
    "id" : 117034344220065792,
    "created_at" : "2011-09-23 00:35:36 +0000",
    "user" : {
      "name" : "\u76F8\u8EE2\u79FBP\uFF08\u5E02\u6C11\uFF09",
      "screen_name" : "phasetr",
      "protected" : false,
      "id_str" : "72528916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589451317149454337\/oC0MxNfm_normal.jpg",
      "id" : 72528916,
      "verified" : false
    }
  },
  "id" : 117093766908747776,
  "created_at" : "2011-09-23 04:31:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "38",
      "screen_name" : "Sayantino",
      "indices" : [ 3, 13 ],
      "id_str" : "120527008",
      "id" : 120527008
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6700\u5F37\u306E\u6B7B\u4EA1\u30D5\u30E9\u30B0\u3092\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u3084\u3064\u304C\u52DD\u3061",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117093667751206914",
  "text" : "RT @Sayantino: \u6B7B\u4EA1\u30D5\u30E9\u30B0\u306E\u300E\u3055\u3057\u3059\u305B\u305D\u300F \n\u30FB\u5148\u306B\u884C\u3051\u3001\u5974\u306F\u4FFA\u304C\u98DF\u3044\u6B62\u3081\u308B \n\u30FB\u6B7B\u306B\u305F\u3044\u5974\u3089\u306F\u3053\u3053\u306B\u3044\u308D\u3001\u4FFA\u306F\u90E8\u5C4B\u306B\u623B\u308B\u304B\u3089\u306A\uFF01 \n\u30FB\u3059\u3050\u306B\u623B\u308B\u3001\u3053\u3053\u3067\u5F85\u3063\u3066\u308D \n\u30FB\u6226\u4E89\u304C\u7D42\u308F\u3063\u305F\u3089\u4FFA\u3001\u7D50\u5A5A\u3059\u308B\u3093\u3060\u2026 \n\u30FB\u305D\u3046\u304B\u3063\uFF01\u305D\u3046\u3044\u3046\u3053\u3068\u3060\u3063\u305F\u306E\u304B\uFF01 \n#\u6700\u5F37\u306E\u6B7B\u4EA1 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u6700\u5F37\u306E\u6B7B\u4EA1\u30D5\u30E9\u30B0\u3092\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u3084\u3064\u304C\u52DD\u3061",
        "indices" : [ 115, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116508388543827971",
    "text" : "\u6B7B\u4EA1\u30D5\u30E9\u30B0\u306E\u300E\u3055\u3057\u3059\u305B\u305D\u300F \n\u30FB\u5148\u306B\u884C\u3051\u3001\u5974\u306F\u4FFA\u304C\u98DF\u3044\u6B62\u3081\u308B \n\u30FB\u6B7B\u306B\u305F\u3044\u5974\u3089\u306F\u3053\u3053\u306B\u3044\u308D\u3001\u4FFA\u306F\u90E8\u5C4B\u306B\u623B\u308B\u304B\u3089\u306A\uFF01 \n\u30FB\u3059\u3050\u306B\u623B\u308B\u3001\u3053\u3053\u3067\u5F85\u3063\u3066\u308D \n\u30FB\u6226\u4E89\u304C\u7D42\u308F\u3063\u305F\u3089\u4FFA\u3001\u7D50\u5A5A\u3059\u308B\u3093\u3060\u2026 \n\u30FB\u305D\u3046\u304B\u3063\uFF01\u305D\u3046\u3044\u3046\u3053\u3068\u3060\u3063\u305F\u306E\u304B\uFF01 \n#\u6700\u5F37\u306E\u6B7B\u4EA1\u30D5\u30E9\u30B0\u3092\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u3084\u3064\u304C\u52DD\u3061",
    "id" : 116508388543827971,
    "created_at" : "2011-09-21 13:45:39 +0000",
    "user" : {
      "name" : "38",
      "screen_name" : "Sayantino",
      "protected" : false,
      "id_str" : "120527008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1486745844\/origin13129178219615_normal.PNG",
      "id" : 120527008,
      "verified" : false
    }
  },
  "id" : 117093667751206914,
  "created_at" : "2011-09-23 04:31:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117084906915512320",
  "geo" : { },
  "id_str" : "117090129474097153",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u306F\u30EC\u30FC\u30EB\u306E\u4E0A\u3092\u306A\u305E\u308B\u7B54\u6848\u306F\u306A\u3093\u304B\u7AAE\u5C48\u3060\u3063\u305F\u306A\u3041\u3002\u5B66\u30B3\u30F3\u30EC\u30D9\u30EB\u3060\u3068\u5C0F\u554F\u306A\u3044\u3068\u7121\u7406\u3060\u304C\u3002",
  "id" : 117090129474097153,
  "in_reply_to_status_id" : 117084906915512320,
  "created_at" : "2011-09-23 04:17:16 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117080952798330880",
  "geo" : { },
  "id_str" : "117083564515934209",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u306F\u5C0F\u554F\u306A\u3044\u65B9\u304C\u597D\u304D\u3060\u3063\u305F\u306A\u30FC",
  "id" : 117083564515934209,
  "in_reply_to_status_id" : 117080952798330880,
  "created_at" : "2011-09-23 03:51:11 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "indices" : [ 3, 16 ],
      "id_str" : "78523759",
      "id" : 78523759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117083312878661632",
  "text" : "RT @tatamin_ttmn: \u3010\u5352\u696D\u5358\u4F4D128\u5358\u4F4D\u53D6\u5F97\u306E\u6B74\u53F2\u3011\n1\uFF1A5+12=17\n2\uFF1A18+27=45(62)\n3\uFF1A10+12=22(84)\n4\uFF1A0+0=0(84)\n5\uFF1A12+0=12(96)\n6\uFF1A6+24=30(126)\n7\uFF1A4(128over)\u2192\u5352\u696D\uFF01\uFF01\uFF01\nT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116712777170698240",
    "text" : "\u3010\u5352\u696D\u5358\u4F4D128\u5358\u4F4D\u53D6\u5F97\u306E\u6B74\u53F2\u3011\n1\uFF1A5+12=17\n2\uFF1A18+27=45(62)\n3\uFF1A10+12=22(84)\n4\uFF1A0+0=0(84)\n5\uFF1A12+0=12(96)\n6\uFF1A6+24=30(126)\n7\uFF1A4(128over)\u2192\u5352\u696D\uFF01\uFF01\uFF01\nTL\u306B\u3044\u308B\u30AF\u30BA\u5B66\u751F\u306F\u3053\u308C\u898B\u3066\u5143\u6C17\u3060\u305B\u3088\u2026\u3002",
    "id" : 116712777170698240,
    "created_at" : "2011-09-22 03:17:49 +0000",
    "user" : {
      "name" : "\u30BF\u30BF\u30DF\u30F3",
      "screen_name" : "tatamin_ttmn",
      "protected" : false,
      "id_str" : "78523759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603218136339337216\/1sSV3Bdp_normal.jpg",
      "id" : 78523759,
      "verified" : false
    }
  },
  "id" : 117083312878661632,
  "created_at" : "2011-09-23 03:50:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/LJXfukg5",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=ethyl_a",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117006003110821888",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001ethyl_a\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/LJXfukg5",
  "id" : 117006003110821888,
  "created_at" : "2011-09-22 22:42:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yamac_lab",
      "screen_name" : "yamac_lab",
      "indices" : [ 3, 13 ],
      "id_str" : "488052711",
      "id" : 488052711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116922892528271360",
  "text" : "RT @yamac_lab: @mo5nya @teppeif7 @nGokMsK @koichi1741 \u30C7\u30FC\u30BF\u89E3\u6790\u3084\u5730\u7403\u6E29\u6696\u5316\u3084\u751F\u547D\u79D1\u5B66\u3084\u866B\u597D\u304D\u3084\u5730\u8CEA\u5B66\u3084\u307D\u3063\u3061\u3083\u308A\u5B66\u3084\u30A8\u30ED\u533B\u7528\u5DE5\u5B66\u306E\u7814\u7A76\u8005\u304C\u4EAC\u90FD\u306B\u96C6\u307E\u3063\u3066\u65E5\u672C\u306E\u672A\u6765\u3068\u5973\u6027\u306E\u597D\u307F\u306B\u3064\u3044\u3066\u6DF1\u304F\u8B70\u8AD6\u3092\u4EA4\u308F\u3059\u3044\u305F\u3063\u3066\u30D5\u30E9\u30F3\u30AF\u306A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B  for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116919505191575552",
    "text" : "@mo5nya @teppeif7 @nGokMsK @koichi1741 \u30C7\u30FC\u30BF\u89E3\u6790\u3084\u5730\u7403\u6E29\u6696\u5316\u3084\u751F\u547D\u79D1\u5B66\u3084\u866B\u597D\u304D\u3084\u5730\u8CEA\u5B66\u3084\u307D\u3063\u3061\u3083\u308A\u5B66\u3084\u30A8\u30ED\u533B\u7528\u5DE5\u5B66\u306E\u7814\u7A76\u8005\u304C\u4EAC\u90FD\u306B\u96C6\u307E\u3063\u3066\u65E5\u672C\u306E\u672A\u6765\u3068\u5973\u6027\u306E\u597D\u307F\u306B\u3064\u3044\u3066\u6DF1\u304F\u8B70\u8AD6\u3092\u4EA4\u308F\u3059\u3044\u305F\u3063\u3066\u30D5\u30E9\u30F3\u30AF\u306A\u96C6\u307E\u308A\u306E\u7DCF\u79F0\u3067\u3059^^",
    "id" : 116919505191575552,
    "created_at" : "2011-09-22 16:59:16 +0000",
    "user" : {
      "name" : "Toshi Yamakawa",
      "screen_name" : "yamac_1ab",
      "protected" : false,
      "id_str" : "146306987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1310937469\/small_RIMG0352_normal.JPG",
      "id" : 146306987,
      "verified" : false
    }
  },
  "id" : 116922892528271360,
  "created_at" : "2011-09-22 17:12:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116918640212848640",
  "text" : "@ayu167 \u30CE\u30FC\u30C8\u958B\u304F",
  "id" : 116918640212848640,
  "created_at" : "2011-09-22 16:55:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "indices" : [ 0, 10 ],
      "id_str" : "232545906",
      "id" : 232545906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116918097700597760",
  "geo" : { },
  "id_str" : "116918263383998464",
  "in_reply_to_user_id" : 232545906,
  "text" : "@math_neko \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\u3069\u30FC\u3082\u6C17\u306B\u306A\u3063\u3061\u3083\u3063\u3066\u3002",
  "id" : 116918263383998464,
  "in_reply_to_status_id" : 116918097700597760,
  "created_at" : "2011-09-22 16:54:20 +0000",
  "in_reply_to_screen_name" : "math_neko",
  "in_reply_to_user_id_str" : "232545906",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116918151089889280",
  "text" : "@ayu167 \u5929\u795E\uFF1F",
  "id" : 116918151089889280,
  "created_at" : "2011-09-22 16:53:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 23, 30 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 32, 41 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116917761497776128",
  "text" : "\u3042\u30FC\u3001\u8A00\u308F\u306A\u3044\u3067\u7F6E\u3044\u305F\u306E\u306B\u30FC\uFF08\u68D2\u8AAD\u307F\uFF09 RT @ayu167: @koketomi \u3055\u3059\u304C\u55AA\u7537",
  "id" : 116917761497776128,
  "created_at" : "2011-09-22 16:52:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116917547894456320",
  "text" : "@koketomi \u306A\u308B\u307B\u3069\u305D\u3046\u3060\u3063\u305F\uFF01\u30B0\u30B0\u308C\u3063\u3066\u8A71\u3060\u3051\u3069\u306A\u3002\u3075\u3068\u6C17\u306B\u306A\u3063\u305F\u3002",
  "id" : 116917547894456320,
  "created_at" : "2011-09-22 16:51:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116916424525611008",
  "text" : "\u55AA\u7537\u306E\u55AA\u3063\u3066\u4F55\u3060\u3063\u3051\uFF1F\u6614\u805E\u3044\u305F\u3088\u306A\u6C17\u3082\u3059\u308B\u3051\u3069\u6C17\u306B\u306A\u3063\u3066\u591C\u3057\u304B\u7720\u308C\u306A\u3044",
  "id" : 116916424525611008,
  "created_at" : "2011-09-22 16:47:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 19, 28 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 65, 75 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116915259830321153",
  "text" : "\u4E00\u56DE\u304B\u4E8C\u56DE\u3057\u304B\u805E\u3044\u3066\u306A\u3044\u306E\u306B\u306A QT @koketomi: \u308A\u3093\u3054\u306E\u30C6\u30FC\u30DE\u3092\u805E\u3044\u3066\u3077\u3088\u3077\u3088\u306E\u6B4C\u304C\u8133\u5185\u518D\u751F\u3055\u308C\u308B\u306E\u306F\u91CD\u75C7\u306E\u8A3C\u3000RT @end313124 \u308A\u3093\u3054\u3061\u3083\u3093\u306E\u3077\u3088\u3077\u3088\u306E\u6B4C\u304C\u982D\u304B\u3089\u96E2\u308C\u306A\u3044\u2026",
  "id" : 116915259830321153,
  "created_at" : "2011-09-22 16:42:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116914869248339968",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u306A\u3041\u3002\u3053\u306E\u6642\u9593\u306F\u3044\u3064\u3082\u305D\u3046\u3060\u304B\u3089\u6163\u308C\u3066\u308B\u3051\u3069\u3055\u3002",
  "id" : 116914869248339968,
  "created_at" : "2011-09-22 16:40:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116913809553244160",
  "text" : "\u308A\u3093\u3054\u3061\u3083\u3093\u306E\u3077\u3088\u3077\u3088\u306E\u6B4C\u304C\u982D\u304B\u3089\u96E2\u308C\u306A\u3044\u2026",
  "id" : 116913809553244160,
  "created_at" : "2011-09-22 16:36:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116913358300659712",
  "text" : "\u6709\u540D\u4EBA\u3066\u5927\u5909\u305D\u3046\u3088\u306D\u2026",
  "id" : 116913358300659712,
  "created_at" : "2011-09-22 16:34:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "indices" : [ 3, 12 ],
      "id_str" : "53934373",
      "id" : 53934373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116913122404605952",
  "text" : "RT @otsuotsu: \u3069\u3070\u306B\u3083\u3093\u304C\u8EAB\u58F2\u308A\u3059\u308B\u3068\u805E\u3044\u3066",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116912448958758912",
    "text" : "\u3069\u3070\u306B\u3083\u3093\u304C\u8EAB\u58F2\u308A\u3059\u308B\u3068\u805E\u3044\u3066",
    "id" : 116912448958758912,
    "created_at" : "2011-09-22 16:31:14 +0000",
    "user" : {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "protected" : false,
      "id_str" : "53934373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574391922032148481\/_bjdAV6X_normal.jpeg",
      "id" : 53934373,
      "verified" : false
    }
  },
  "id" : 116913122404605952,
  "created_at" : "2011-09-22 16:33:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116913099927322624",
  "text" : "RT @dovanyahn: \u304A\u91D1\u306A\u3044\u304B\u3089\u4F55\u304B\u58F2\u308D\u3046\u3063\u3066\u8A00\u3063\u305F\u3089\u5351\u7325\u3063\u3066\u8A00\u308F\u308C\u308B\u3068\u306F\u601D\u308F\u306A\u304B\u3063\u305F(\uFF1B\u30FB\u2200\u30FB)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116912383498272770",
    "text" : "\u304A\u91D1\u306A\u3044\u304B\u3089\u4F55\u304B\u58F2\u308D\u3046\u3063\u3066\u8A00\u3063\u305F\u3089\u5351\u7325\u3063\u3066\u8A00\u308F\u308C\u308B\u3068\u306F\u601D\u308F\u306A\u304B\u3063\u305F(\uFF1B\u30FB\u2200\u30FB)",
    "id" : 116912383498272770,
    "created_at" : "2011-09-22 16:30:59 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 116913099927322624,
  "created_at" : "2011-09-22 16:33:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116911929519386624",
  "text" : "\u6C17\u6301\u3061\u60AA\u304F\u306A\u3044\u306E\u3092\u9078\u3093\u3060\u3064\u3082\u308A\u2026\u3064\u3082\u308A\u3002",
  "id" : 116911929519386624,
  "created_at" : "2011-09-22 16:29:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116911771553497088",
  "text" : "\u30A2\u30A4\u30B3\u30F3\u6C17\u6301\u3061\u60AA\u3044\uFF1F\u30D5\u30E9\u30AF\u30BF\u30EB\u56F3\u5F62\u306F\u4E00\u90E8\u306E\u4EBA\u306B\u306F\u751F\u7406\u7684\u306B\u7121\u7406\u3063\u3066\u8A71\u3082\u805E\u3044\u305F\u3053\u3068\u3042\u308B\u3088\u3046\u306A\u3001\u306A\u3044\u3088\u3046\u306A\u3002",
  "id" : 116911771553497088,
  "created_at" : "2011-09-22 16:28:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116909556419928064",
  "text" : "\u30A2\u30DB\u306A\u88AB\u5BB3\u5984\u60F3\u306F\u5197\u8AC7\u3068\u3057\u3066\u306F\u5ACC\u3044\u3058\u3083\u306A\u3044\u306A\u30FC\u3002\u7406\u4E0D\u5C3D\u306F\u7B11\u3044\u3092\u8A98\u3046\u3082\u3093\u306D\u30FC\u3002\u771F\u9762\u76EE\u306B\u8A00\u3063\u3066\u308B\u3093\u3060\u3063\u305F\u3089\u72C2\u6C17\u3060\u3051\u3069\u3002",
  "id" : 116909556419928064,
  "created_at" : "2011-09-22 16:19:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr.\u30BF\u30F3\u30AF\u30C8\u30C3\u30D7",
      "screen_name" : "anti_gakureki",
      "indices" : [ 3, 17 ],
      "id_str" : "326738053",
      "id" : 326738053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116909088314638337",
  "text" : "RT @anti_gakureki: \u4FFA\u306B\u306A\u304B\u306A\u304B\u5185\u5B9A\u304C\u51FA\u306A\u3044\u3053\u3068\u306B\u3064\u3044\u3066\u8003\u3048\u3066\u305F\u3002\u305D\u3053\u3067\u3075\u3068\u601D\u3044\u6D6E\u304B\u3093\u3060\u306E\u304C\u524D\u306B\u30D0\u30A4\u30C8\u5148\u306E\u5C45\u9152\u5C4B\u3067\u4E00\u7DD2\u3060\u3063\u305F\u5973\u306E\u3053\u3068\u3060\u3002\u9152\u306E\u540D\u524D\u3082\u899A\u3048\u3089\u308C\u306A\u3044\u30CE\u30ED\u30DE\u3067\u7F75\u3063\u305F\u3089\u3059\u3050\u306B\u8F9E\u3081\u3066\u3057\u307E\u3063\u305F\u3093\u3060\u304C\u3001\u6050\u3089\u304F\u305D\u3044\u3064\u304C\u4F01\u696D\u306E\u5F79\u54E1\u306E\u611B\u4EBA\u306B\u3067\u3082\u306A\u3063\u3066\u88CF\u3067\u52D5\u3044\u3066 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116890524706803712",
    "text" : "\u4FFA\u306B\u306A\u304B\u306A\u304B\u5185\u5B9A\u304C\u51FA\u306A\u3044\u3053\u3068\u306B\u3064\u3044\u3066\u8003\u3048\u3066\u305F\u3002\u305D\u3053\u3067\u3075\u3068\u601D\u3044\u6D6E\u304B\u3093\u3060\u306E\u304C\u524D\u306B\u30D0\u30A4\u30C8\u5148\u306E\u5C45\u9152\u5C4B\u3067\u4E00\u7DD2\u3060\u3063\u305F\u5973\u306E\u3053\u3068\u3060\u3002\u9152\u306E\u540D\u524D\u3082\u899A\u3048\u3089\u308C\u306A\u3044\u30CE\u30ED\u30DE\u3067\u7F75\u3063\u305F\u3089\u3059\u3050\u306B\u8F9E\u3081\u3066\u3057\u307E\u3063\u305F\u3093\u3060\u304C\u3001\u6050\u3089\u304F\u305D\u3044\u3064\u304C\u4F01\u696D\u306E\u5F79\u54E1\u306E\u611B\u4EBA\u306B\u3067\u3082\u306A\u3063\u3066\u88CF\u3067\u52D5\u3044\u3066\u308B\u3088\u3046\u306A\u6C17\u304C\u3057\u3066\u304D\u305F\u3002\u512A\u79C0\u306A\u5B66\u751F\u306B\u306F\u6575\u304C\u591A\u3044\u3002",
    "id" : 116890524706803712,
    "created_at" : "2011-09-22 15:04:07 +0000",
    "user" : {
      "name" : "Mr.\u30BF\u30F3\u30AF\u30C8\u30C3\u30D7",
      "screen_name" : "anti_gakureki",
      "protected" : false,
      "id_str" : "326738053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1420247879\/DQN_normal.png",
      "id" : 326738053,
      "verified" : false
    }
  },
  "id" : 116909088314638337,
  "created_at" : "2011-09-22 16:17:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116906138045382656",
  "text" : "\u5145\u96FB\u5207\u308C\u305D\u3046\u30FC\u3002\u81EA\u5B85\u3060\u3051\u3069\u3063\uFF01",
  "id" : 116906138045382656,
  "created_at" : "2011-09-22 16:06:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u65B9\u8A00\u307E\u308B\u3060\u3057\u3067\u558B\u3063\u3066\u307F\u3088\u3046",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116904849173524480",
  "text" : "\u3053\u3046\u3044\u3046\u306E\u306B\u4E00\u5207\u7A4D\u6975\u7684\u306B\u53C2\u52A0\u3067\u304D\u306A\u3044\u3093\u3067\u3059\u3088\u306D #\u65B9\u8A00\u307E\u308B\u3060\u3057\u3067\u558B\u3063\u3066\u307F\u3088\u3046",
  "id" : 116904849173524480,
  "created_at" : "2011-09-22 16:01:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "indices" : [ 3, 16 ],
      "id_str" : "96289411",
      "id" : 96289411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116890353549844481",
  "text" : "RT @d_v_osorezan: tween\u304B\u3089\u4FF3\u53E5\u66F8\u3044\u3066\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u3089\u3001\u300C\u8981\u6C42\u306F\u3000\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8\u306B\u3000\u306A\u308A\u307E\u3057\u305F\u300D\u3063\u3066\u8FD4\u53E5\u304C\u6765\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116886927097085952",
    "text" : "tween\u304B\u3089\u4FF3\u53E5\u66F8\u3044\u3066\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u3089\u3001\u300C\u8981\u6C42\u306F\u3000\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8\u306B\u3000\u306A\u308A\u307E\u3057\u305F\u300D\u3063\u3066\u8FD4\u53E5\u304C\u6765\u305F\u3002",
    "id" : 116886927097085952,
    "created_at" : "2011-09-22 14:49:49 +0000",
    "user" : {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "protected" : false,
      "id_str" : "96289411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3457427933\/e9c1859b77927509e49bcdd8ea328bdb_normal.jpeg",
      "id" : 96289411,
      "verified" : false
    }
  },
  "id" : 116890353549844481,
  "created_at" : "2011-09-22 15:03:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116856420862926849",
  "text" : "\u307E\u3041\u3067\u3082\u4EE3\u308F\u308A\uFF08\uFF1F\uFF09\u306B\u30D1\u30D1\u30A4\u30E4\u6CA2\u5C71\u98DF\u3079\u305F",
  "id" : 116856420862926849,
  "created_at" : "2011-09-22 12:48:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116856265992437760",
  "text" : "\u4ECA\u5E74\u306F\u3064\u3044\u306B\u6843\u3092\u98DF\u3079\u305D\u3053\u306A\u3063\u3061\u3083\u3063\u305F\u306A\u3041\u3002",
  "id" : 116856265992437760,
  "created_at" : "2011-09-22 12:47:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116856087902302208",
  "text" : "\u68A8\u7F8E\u5473\u3057\u304B\u3063\u305F\uFF01",
  "id" : 116856087902302208,
  "created_at" : "2011-09-22 12:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116844532368289793",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 116844532368289793,
  "created_at" : "2011-09-22 12:01:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasutomo57jp",
      "screen_name" : "yasutomo57jp",
      "indices" : [ 0, 13 ],
      "id_str" : "9990482",
      "id" : 9990482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116832366160384000",
  "geo" : { },
  "id_str" : "116834188329619456",
  "in_reply_to_user_id" : 9990482,
  "text" : "@yasutomo57jp \u7D50\u57CE\u6D69\u3055\u3093\u306E\uFF23\u8A00\u8A9E\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u30EC\u30C3\u30B9\u30F3 \u304A\u3059\u3059\u3081\u3067\u3059",
  "id" : 116834188329619456,
  "in_reply_to_status_id" : 116832366160384000,
  "created_at" : "2011-09-22 11:20:15 +0000",
  "in_reply_to_screen_name" : "yasutomo57jp",
  "in_reply_to_user_id_str" : "9990482",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natsubon",
      "screen_name" : "natsubon",
      "indices" : [ 3, 12 ],
      "id_str" : "6163482",
      "id" : 6163482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116833794786476032",
  "text" : "RT @natsubon: \u3084\u3063\u3071\u885D\u6483\u3060\u3063\u305F\u306E\u306F\u300C\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u304C\u72ED\u3044\u300D\u3068\u3044\u3046\u76F8\u8AC7\u3067\u76F8\u8AC7\u306E\u610F\u5473\u304C\u308F\u304B\u3089\u305A\u306BPC\u307F\u305F\u3089\u3053\u3093\u306A\u3060\u3063\u305F\u3001\u3063\u3066\u5974\u304C\u6700\u5F37\u3060\u3063\u305F\u306A\u3002 http:\/\/yfrog.com\/h44nfqkj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57460198708740096",
    "text" : "\u3084\u3063\u3071\u885D\u6483\u3060\u3063\u305F\u306E\u306F\u300C\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u304C\u72ED\u3044\u300D\u3068\u3044\u3046\u76F8\u8AC7\u3067\u76F8\u8AC7\u306E\u610F\u5473\u304C\u308F\u304B\u3089\u305A\u306BPC\u307F\u305F\u3089\u3053\u3093\u306A\u3060\u3063\u305F\u3001\u3063\u3066\u5974\u304C\u6700\u5F37\u3060\u3063\u305F\u306A\u3002 http:\/\/yfrog.com\/h44nfqkj",
    "id" : 57460198708740096,
    "created_at" : "2011-04-11 15:09:13 +0000",
    "user" : {
      "name" : "natsubon",
      "screen_name" : "natsubon",
      "protected" : false,
      "id_str" : "6163482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1233657598\/natsubon2011mono_normal.jpg",
      "id" : 6163482,
      "verified" : false
    }
  },
  "id" : 116833794786476032,
  "created_at" : "2011-09-22 11:18:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116815737640857600",
  "text" : "\u30AA\u30FC\u30AD\u30C9\u30CD\u30BF\u6C4E\u7528\u6027\u304C\u3042\u3063\u3066\u3044\u3044\u306A\u3002",
  "id" : 116815737640857600,
  "created_at" : "2011-09-22 10:06:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116814622283149312",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 116814622283149312,
  "created_at" : "2011-09-22 10:02:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116802022845579264",
  "geo" : { },
  "id_str" : "116802957940506625",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u304A\u3044\u3084\u3081\u308D\uFF57\uFF57\uFF57\uFF57",
  "id" : 116802957940506625,
  "in_reply_to_status_id" : 116802022845579264,
  "created_at" : "2011-09-22 09:16:09 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116800317911339008",
  "geo" : { },
  "id_str" : "116801616736305152",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6765\u9031\u6708\u66DC\u3067\u3059\u3057",
  "id" : 116801616736305152,
  "in_reply_to_status_id" : 116800317911339008,
  "created_at" : "2011-09-22 09:10:50 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 45, 50 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 65, 75 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116796967673282560",
  "text" : "\u6587\u5B66\u90E8\u751F\u306B\u306F\u7121\u99C4\u2192\u865A\u3001\u8208\u5473\u2192interest\u3001\u611B\u306E\uFF13\u70B9\u3067\uFF49\u3068\u8A00\u3063\u305F\u3068\u3053\u308D\u3067\u3057\u3087\u3046\u304B RT @np2i: \u5358\u4F4D\u5143\u306F\u4F55\u3060\u308D\u3046\u3002 RT @end313124: \u6570\u3048\u3066\u307F\u305F\u3089\u4E00\u822C\u6559\u990A\uFF22\u7FA4\u3060\u3051\u306730\u5358\u4F4D\u3082\u3042\u3063\u305F\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 116796967673282560,
  "created_at" : "2011-09-22 08:52:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116795431530397696",
  "text" : "\u30DF\u30AF\u30ED\u7D4C\u6E08\u3068\u30DE\u30AF\u30ED\u7D4C\u6E08\u3063\u3066\u96E3\u3057\u3044\u3093\u3067\u3059\uFF1F\u6765\u5E74\u524D\u671F\u53D6\u308C\u308C\u3070\u53D6\u308D\u3046\u304B\u306A\u30FC",
  "id" : 116795431530397696,
  "created_at" : "2011-09-22 08:46:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116793983224659968",
  "text" : "\u3042\u3001\uFF21\u7FA4\uFF08\u6587\u7CFB\u79D1\u76EE\uFF09\u3001\uFF22\u7FA4\uFF08\u7406\u7CFB\u79D1\u76EE\uFF09\u3067\u3059\u3002",
  "id" : 116793983224659968,
  "created_at" : "2011-09-22 08:40:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116793844745502721",
  "text" : "\u3048\uFF1F\uFF21\u7FA4\u3067\u3059\u304B\uFF1F\u2026\u202616\u5358\u4F4D\u3002",
  "id" : 116793844745502721,
  "created_at" : "2011-09-22 08:39:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116793664650481664",
  "text" : "\u6570\u3048\u3066\u307F\u305F\u3089\u4E00\u822C\u6559\u990A\uFF22\u7FA4\u3060\u3051\u306730\u5358\u4F4D\u3082\u3042\u3063\u305F\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 116793664650481664,
  "created_at" : "2011-09-22 08:39:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116793350706831360",
  "text" : "\u7D50\u5C40\u8208\u5473\u306E\u5E45\u304C\u5E83\u3059\u304E\u308B\u3057\u6559\u990A\u5B66\u90E8\u307F\u305F\u3044\u306A\u6240\u306B\u884C\u304F\u3079\u304D\u3060\u3063\u305F\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u3082\u601D\u308F\u306A\u304F\u3082\u306A\u3044\u3002\n\u6587\u5B66\u90E8\u306B\u6765\u305F\u3053\u3068\u306F\u5F8C\u6094\u3057\u3066\u3044\u306A\u3044\u3051\u308C\u3069\u3001\u4ED6\u306E\u65B9\u304C\u5411\u3044\u3066\u3044\u305F\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u3044\u3046\u6C17\u306F\u3059\u308B\u3002",
  "id" : 116793350706831360,
  "created_at" : "2011-09-22 08:37:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116793083319959552",
  "text" : "\u8150\u308A\u304B\u3051\u3063\u3066\u8868\u73FE\u3082\u30A2\u30EC\u304B\u3002\u8150\u308A\u304B\u3051\u306E\u8005\u306F\u7F8E\u5473\u3057\u3044\u304B\u3089\u3002",
  "id" : 116793083319959552,
  "created_at" : "2011-09-22 08:36:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3082\u3061\u3085\u3093",
      "screen_name" : "lemochun",
      "indices" : [ 3, 12 ],
      "id_str" : "212934710",
      "id" : 212934710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116792859822276608",
  "text" : "RT @lemochun: \u300C\u5098\u306A\u3044\u3093\u3060\u3051\u3069\u300D\u300C\u8CB8\u3055\u306A\u3044\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116792692440174592",
    "text" : "\u300C\u5098\u306A\u3044\u3093\u3060\u3051\u3069\u300D\u300C\u8CB8\u3055\u306A\u3044\u300D",
    "id" : 116792692440174592,
    "created_at" : "2011-09-22 08:35:22 +0000",
    "user" : {
      "name" : "\u308C\u3082\u3061\u3085\u3093",
      "screen_name" : "lemochun",
      "protected" : false,
      "id_str" : "212934710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000555012523\/a191bb7e62812924cdf1410e6b0fc47e_normal.jpeg",
      "id" : 212934710,
      "verified" : false
    }
  },
  "id" : 116792859822276608,
  "created_at" : "2011-09-22 08:36:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116792763802062849",
  "text" : "\u6B63\u76F4\u5927\u5B66\u5168\u4F53\u3067\u898B\u305F\u3089\u5E73\u5747\u7A0B\u5EA6\u306B\u306F\u771F\u9762\u76EE\u306A\u81EA\u4FE1\u304C\u3042\u308B\uFF08\u30C0\u30E1\u4EBA\u9593\u304C\u76EE\u7ACB\u3064\u304B\u3089\uFF1F\uFF09\u3051\u308C\u3069\u6587\u5B66\u90E8\u751F\u3068\u3057\u3066\u306F\u304B\u306A\u308A\u8150\u308A\u304B\u3051\u306A\u81EA\u899A\u306F\u3042\u308B(\uFF77\uFF98\uFF6F",
  "id" : 116792763802062849,
  "created_at" : "2011-09-22 08:35:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116792475850510336",
  "text" : "\u5F8C\u554F\u984C\u306F\u81EA\u7531\u5358\u4F4D\u3060\u3088\u306A\u3002\u6B63\u76F4\u5C02\u653B\u4EE5\u5916\u306E\u5206\u91CE\u306B\u8208\u5473\u304C\u3042\u3093\u307E\u308A\u306A\u3044\u305B\u3044\u3067\u81EA\u7531\u304C\u4E0D\u81EA\u7531\u306A\u3093\u3060\u3088\u306A\u3002\u7D4C\u6E08\u5B66\u90E8\u5358\u4F4D\u306B\u7D50\u69CB\u671F\u5F85\u3057\u3066\u308B\u3002",
  "id" : 116792475850510336,
  "created_at" : "2011-09-22 08:34:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116791964275445760",
  "text" : "\u3082\u3046\u30D5\u30E9\u30F3\u30B9\u8A9E\u4E2D\u7D1A\u697D\u306A\u5148\u751F\u898B\u3064\u3051\u305F\u3057\u305D\u306E\u6388\u696D\u306B\u5F35\u308A\u4ED8\u3044\u3066\uFF12\uFF0C\uFF13\u5E74\u306E\u524D\u5F8C\u671F\u30678\u5358\u4F4D\u63C3\u3048\u3088\u3046\u304B\u306A\uFF08\u767D\u76EE",
  "id" : 116791964275445760,
  "created_at" : "2011-09-22 08:32:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 3, 10 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116791664600813569",
  "text" : "RT @ac_key: \u300C\u305D\u3053\u306B\u4E09\u3064\u306E\u5358\u4F4D\u53D6\u5F97\u6761\u4EF6\u304C\u3042\u308B\u3058\u3083\u308D\uFF1F\u30B3\u30EC\u306F\u51FA\u5E2D\u56DE\u6570\u3068\u3044\u3063\u3066\u5168\u4F53\u306E3\/4\u306B\u6E80\u305F\u306A\u3044\u5834\u5408\u5373\u4E0D\u53EF\u3058\u3083\u3002\u30B3\u30EC\u306F\u30EC\u30DD\u30FC\u30C8\u3068\u8A00\u3063\u3066\u6210\u7E3E\u5168\u4F53\u306E2\uFF5E4\u5272\u7A0B\u5EA6\u306E\u5F71\u97FF\u3092\u4E0E\u3048\u308B\u30E2\u30CE\u3058\u3083\u3002\u30B3\u30EC\u306F\u671F\u672B\u8A66\u9A13\u3068\u8A00\u3063\u3066\u4E00\u591C\u6F2C\u3051\u3067\u306F\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3089\u306A\u3044\u30E2\u30CE\u3058\u3083\u3002\u3053\u3093\u306A\u306B\u660E\u5FEB\u306A\u30EB ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116790067938328576",
    "text" : "\u300C\u305D\u3053\u306B\u4E09\u3064\u306E\u5358\u4F4D\u53D6\u5F97\u6761\u4EF6\u304C\u3042\u308B\u3058\u3083\u308D\uFF1F\u30B3\u30EC\u306F\u51FA\u5E2D\u56DE\u6570\u3068\u3044\u3063\u3066\u5168\u4F53\u306E3\/4\u306B\u6E80\u305F\u306A\u3044\u5834\u5408\u5373\u4E0D\u53EF\u3058\u3083\u3002\u30B3\u30EC\u306F\u30EC\u30DD\u30FC\u30C8\u3068\u8A00\u3063\u3066\u6210\u7E3E\u5168\u4F53\u306E2\uFF5E4\u5272\u7A0B\u5EA6\u306E\u5F71\u97FF\u3092\u4E0E\u3048\u308B\u30E2\u30CE\u3058\u3083\u3002\u30B3\u30EC\u306F\u671F\u672B\u8A66\u9A13\u3068\u8A00\u3063\u3066\u4E00\u591C\u6F2C\u3051\u3067\u306F\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3089\u306A\u3044\u30E2\u30CE\u3058\u3083\u3002\u3053\u3093\u306A\u306B\u660E\u5FEB\u306A\u30EB\u30FC\u30EB\u3067\u306A\u305C\u5358\u4F4D\u3092\u843D\u3068\u3059\u3093\u3058\u3083\uFF1F\u300D",
    "id" : 116790067938328576,
    "created_at" : "2011-09-22 08:24:56 +0000",
    "user" : {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "protected" : false,
      "id_str" : "106036912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600553053863817216\/2TsFpIn8_normal.png",
      "id" : 106036912,
      "verified" : false
    }
  },
  "id" : 116791664600813569,
  "created_at" : "2011-09-22 08:31:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jide",
      "screen_name" : "frought",
      "indices" : [ 3, 11 ],
      "id_str" : "516356463",
      "id" : 516356463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116789385948692480",
  "text" : "RT @frought: \u30AA\u30FC\u30AD\u30C9\u6559\u6388\u300C\u305D\u3053\u306B\u5358\u4F4D\u304C3\u3064\u3042\u308B\u3058\u3083\u308D\uFF1F\u304A\u524D\u304C\u771F\u9762\u76EE\u306B\u52C9\u5F37\u3057\u3066\u3044\u308C\u3070\u3042\u3052\u308B\u3053\u3068\u306E\u3067\u304D\u305F\u5358\u4F4D\u3058\u3083\u3002\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115806478841032704",
    "text" : "\u30AA\u30FC\u30AD\u30C9\u6559\u6388\u300C\u305D\u3053\u306B\u5358\u4F4D\u304C3\u3064\u3042\u308B\u3058\u3083\u308D\uFF1F\u304A\u524D\u304C\u771F\u9762\u76EE\u306B\u52C9\u5F37\u3057\u3066\u3044\u308C\u3070\u3042\u3052\u308B\u3053\u3068\u306E\u3067\u304D\u305F\u5358\u4F4D\u3058\u3083\u3002\u300D",
    "id" : 115806478841032704,
    "created_at" : "2011-09-19 15:16:30 +0000",
    "user" : {
      "name" : "\u3075\u308A\u304F\u3068",
      "screen_name" : "tcirf",
      "protected" : false,
      "id_str" : "116721096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535998997777743873\/AiAatM1r_normal.jpeg",
      "id" : 116721096,
      "verified" : false
    }
  },
  "id" : 116789385948692480,
  "created_at" : "2011-09-22 08:22:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116783472441438208",
  "text" : "\u7D50\u5C40\u6587\u5B66\u90E8\u3063\u3066\u8A9E\u5B66\u3069\u308C\u3060\u3051\u5FC5\u8981\u306A\u3093\u3060\u308D\u30FB\u30FB\u30FB\u6642\u9593\u5272\u7D44\u3093\u3067\u308B\u3051\u3069\u3088\u304F\u308F\u304B\u3093\u306A\u3044orz",
  "id" : 116783472441438208,
  "created_at" : "2011-09-22 07:58:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " .",
      "screen_name" : "Jojo__0707",
      "indices" : [ 0, 11 ],
      "id_str" : "1512646136",
      "id" : 1512646136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116573459202580481",
  "text" : "@Jojo__0707 \u6559\u990AB\u7FA4\u306E\u751F\u6D3B\u3068\u6570\u5B66\u306F\u4E00\u5207\u751F\u6D3B\u306B\u95A2\u308F\u3089\u306A\u3044\u6570\u5B66\u3092\u7406\u5B66\u90E8\u306E\u500B\u6027\u7684\u306A\u5148\u751F\u304C\u308F\u304B\u308A\u306B\u304F\u304F\u6559\u3048\u3066\u304F\u308C\u305F\u3051\u3069\u3001\u30C6\u30B9\u30C8\u306B\u6570\u5F0F\u3089\u3057\u304D\u3082\u306E\u3092\u66F8\u304D\u6B8B\u3057\u3001\u3054\u3081\u3093\u306A\u3055\u3044\u3001\u308F\u304B\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3001\u3068\u66F8\u3044\u305F\u53CB\u4EBA\u304C\u5408\u683C\u3060\u3063\u305F\u3002",
  "id" : 116573459202580481,
  "created_at" : "2011-09-21 18:04:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116481263644323840",
  "text" : "\u53E3\u306E\u4E0A\u306E\u6240\u3084\u3051\u3069\u3057\u305F\u307F\u305F\u3044\u3002\u75DB\u3044\u3002",
  "id" : 116481263644323840,
  "created_at" : "2011-09-21 11:57:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3080\u3058",
      "screen_name" : "muzikzak",
      "indices" : [ 3, 12 ],
      "id_str" : "141222373",
      "id" : 141222373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116480398875295745",
  "text" : "RT @muzikzak: \u30E4\u30D0\u30A4\u53F0\u98A8\u30E4\u30D0\u30A4\u3002\u3054\u98EF\u8CB7\u3044\u306B\u884C\u3063\u305F\u5E30\u308A\u9053\u306B\u8AB0\u3082\u3044\u306A\u3044\u304B\u3089\u300C\u30EF\u30EB\u30D7\u30EB\u30AE\u30B9\u306E\u591C\u304C\u6765\u308B\u2026\uFF01\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3089\u5F8C\u308D\u306B\u5973\u6027\u304C\u7ACB\u3063\u3066\u3066\u30E4\u30D0\u3063\u8D85\u30CF\u30BA\u30A4\uFF01\uFF01\u3063\u3066\u601D\u3063\u3066\u3089\u300C\u5927\u4E08\u592B\u3060\u3088\u2026\u307B\u3080\u3089\u3061\u3083\u3093\u300D\u3063\u3066\u8FD4\u3055\u308C\u305F\u3002\u306A\u306B\u3053\u308C\u53F0\u98A8\u306F\u540C\u3058\u4EF2\u9593\u3092\u898B\u3064\u3051\u308B\u529B\u3067\u3082\u3042\u308B\u306E\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tabtter.jp\" rel=\"nofollow\"\u003ETabtter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116436531979366400",
    "text" : "\u30E4\u30D0\u30A4\u53F0\u98A8\u30E4\u30D0\u30A4\u3002\u3054\u98EF\u8CB7\u3044\u306B\u884C\u3063\u305F\u5E30\u308A\u9053\u306B\u8AB0\u3082\u3044\u306A\u3044\u304B\u3089\u300C\u30EF\u30EB\u30D7\u30EB\u30AE\u30B9\u306E\u591C\u304C\u6765\u308B\u2026\uFF01\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3089\u5F8C\u308D\u306B\u5973\u6027\u304C\u7ACB\u3063\u3066\u3066\u30E4\u30D0\u3063\u8D85\u30CF\u30BA\u30A4\uFF01\uFF01\u3063\u3066\u601D\u3063\u3066\u3089\u300C\u5927\u4E08\u592B\u3060\u3088\u2026\u307B\u3080\u3089\u3061\u3083\u3093\u300D\u3063\u3066\u8FD4\u3055\u308C\u305F\u3002\u306A\u306B\u3053\u308C\u53F0\u98A8\u306F\u540C\u3058\u4EF2\u9593\u3092\u898B\u3064\u3051\u308B\u529B\u3067\u3082\u3042\u308B\u306E\uFF1F",
    "id" : 116436531979366400,
    "created_at" : "2011-09-21 09:00:07 +0000",
    "user" : {
      "name" : "\u3080\u3058",
      "screen_name" : "muzikzak",
      "protected" : false,
      "id_str" : "141222373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496605240196472832\/15OjhFGF_normal.jpeg",
      "id" : 141222373,
      "verified" : false
    }
  },
  "id" : 116480398875295745,
  "created_at" : "2011-09-21 11:54:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116447700156813312",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u306B\u7720\u304F\u306A\u3063\u305F",
  "id" : 116447700156813312,
  "created_at" : "2011-09-21 09:44:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116447600449826816",
  "text" : "\u7761\u9B54\u3001\u30B9\u30A4\u30DE\u30FC",
  "id" : 116447600449826816,
  "created_at" : "2011-09-21 09:44:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116371055865634816",
  "geo" : { },
  "id_str" : "116371781396348928",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 116371781396348928,
  "in_reply_to_status_id" : 116371055865634816,
  "created_at" : "2011-09-21 04:42:49 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116364440982659073",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 116364440982659073,
  "created_at" : "2011-09-21 04:13:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116364385777238016",
  "text" : "\u96E8\u3001\u96E8\u3001\u96E8",
  "id" : 116364385777238016,
  "created_at" : "2011-09-21 04:13:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116119690530660352",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 116119690530660352,
  "created_at" : "2011-09-20 12:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116010358874963969",
  "text" : "\u30CA\u30CE\u306F\u95A2\u4FC2\u306A\u3044\u2026",
  "id" : 116010358874963969,
  "created_at" : "2011-09-20 04:46:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116010221356331008",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u30B9\u30BF\u30A4\u30EA\u30C3\u30B7\u30E5\u306A\u30EC\u30A4\u30F3\u30B3\u30FC\u30C8\u3063\u3066\u5B58\u5728\u3057\u306A\u3044\u306E\u304B\u306A\u3002\u3044\u3084\u3001\u7740\u308B\u81EA\u5206\u81EA\u8EAB\u304C\u30CE\u30F3\u30B9\u30BF\u30A4\u30EA\u30C3\u30B7\u30E5\u30CA\u30CE\u306F\u3068\u3082\u304B\u304F\u306D\u3002",
  "id" : 116010221356331008,
  "created_at" : "2011-09-20 04:46:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 10, 21 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 22, 37 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115849125714608129",
  "geo" : { },
  "id_str" : "116009749606170624",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz @magokoro84 @G4_Hirano_chan \u304A\u3084\u3059\u307F\u3069\u3082\u3067\u3057\u305F\u30FC\u3002",
  "id" : 116009749606170624,
  "in_reply_to_status_id" : 115849125714608129,
  "created_at" : "2011-09-20 04:44:14 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116009493053190144",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 116009493053190144,
  "created_at" : "2011-09-20 04:43:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116009384324239360",
  "text" : "ETR\uFF1A\u30A8\u30BF\u30FC\u30CA\u30EB\u7E4B\u304C\u3089\u306A\u3044\u9023\u9396\n\u304C\u305A\u3063\u3068\u982D\u304B\u3089\u96E2\u308C\u306A\u3044\u3002\u3053\u306E\u30CD\u30FC\u30DF\u30F3\u30B0\u30BB\u30F3\u30B9\u2026\u3077\u3088\u3089\u30FC\u306F\u30A2\u30EC\u3060\u3088\u306A\u3002\u9762\u767D\u3044\u3051\u3069\u3055\u3002",
  "id" : 116009384324239360,
  "created_at" : "2011-09-20 04:42:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 3, 15 ],
      "id_str" : "131856285",
      "id" : 131856285
    }, {
      "name" : "\u30A8\u30ED\u52A9",
      "screen_name" : "Bou0123",
      "indices" : [ 20, 28 ],
      "id_str" : "3098854620",
      "id" : 3098854620
    }, {
      "name" : "\u50CD\u304B\u305A\u306B\u66AE\u3089\u3057\u305F\u3044",
      "screen_name" : "kotobuki_hyt",
      "indices" : [ 38, 51 ],
      "id_str" : "304354019",
      "id" : 304354019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115981556102860800",
  "text" : "RT @momo_miku28: RT @Bou0123: \u3084\u3081\u308D\u3049\uFF01RT @kotobuki_hyt: \u3046\u308F\u30FB\u30FB\u30FB\u79C1\u306E\u5358\u4F4D\u3001\u5C11\u306A\u3059\u304E\uFF01\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30A8\u30ED\u52A9",
        "screen_name" : "Bou0123",
        "indices" : [ 3, 11 ],
        "id_str" : "3098854620",
        "id" : 3098854620
      }, {
        "name" : "\u50CD\u304B\u305A\u306B\u66AE\u3089\u3057\u305F\u3044",
        "screen_name" : "kotobuki_hyt",
        "indices" : [ 21, 34 ],
        "id_str" : "304354019",
        "id" : 304354019
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115978662544814080",
    "text" : "RT @Bou0123: \u3084\u3081\u308D\u3049\uFF01RT @kotobuki_hyt: \u3046\u308F\u30FB\u30FB\u30FB\u79C1\u306E\u5358\u4F4D\u3001\u5C11\u306A\u3059\u304E\uFF01\uFF1F",
    "id" : 115978662544814080,
    "created_at" : "2011-09-20 02:40:42 +0000",
    "user" : {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "protected" : true,
      "id_str" : "131856285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533040424097566720\/1Wjv-ZI7_normal.jpeg",
      "id" : 131856285,
      "verified" : false
    }
  },
  "id" : 115981556102860800,
  "created_at" : "2011-09-20 02:52:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115848982164541440",
  "text" : "\u5BDD\u308B\u3002\u304A\u4F11\u307F\u306A\u3055\u3044\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 115848982164541440,
  "created_at" : "2011-09-19 18:05:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "101753216",
      "id" : 101753216
    }, {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 37, 46 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115848700307324928",
  "text" : "RT @factoring_bot: 456=2*2*2*3*19 RT @nartakio: \u308C\u304A\u304F\u3093456\u8CFD\u3068\u304B\u30C9\u30F3\u5F15\u304D\u306A\u3093\u3067\u3059\u3051\u3069\u2026\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/prime.4403.biz\/factoring_bot\/\" rel=\"nofollow\"\u003Efactoring_bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nartakio",
        "screen_name" : "nartakio",
        "indices" : [ 18, 27 ],
        "id_str" : "612419223",
        "id" : 612419223
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115846629545873408",
    "text" : "456=2*2*2*3*19 RT @nartakio: \u308C\u304A\u304F\u3093456\u8CFD\u3068\u304B\u30C9\u30F3\u5F15\u304D\u306A\u3093\u3067\u3059\u3051\u3069\u2026\u2026",
    "id" : 115846629545873408,
    "created_at" : "2011-09-19 17:56:03 +0000",
    "user" : {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "protected" : false,
      "id_str" : "101753216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727655584\/factan_normal.png",
      "id" : 101753216,
      "verified" : false
    }
  },
  "id" : 115848700307324928,
  "created_at" : "2011-09-19 18:04:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115840507975962624",
  "text" : "\u5909\u306A\u59FF\u52E2\u3002\u8170\u304C\u75DB\u3044\u3002",
  "id" : 115840507975962624,
  "created_at" : "2011-09-19 17:31:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115839850233602048",
  "text" : "RT @JOJO_math: \u300C\u76F4\u89D2\u4E09\u89D2\u5F62\u306E\u5BFE\u8FBA\u3068\u659C\u8FBA\u306E\u6BD4\u300D\u30F3\u30C3\u30F3\uFF5E\u3000\u6B63\u5F26\u3060\u306A\u3053\u308C\u306F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115839586743226368",
    "text" : "\u300C\u76F4\u89D2\u4E09\u89D2\u5F62\u306E\u5BFE\u8FBA\u3068\u659C\u8FBA\u306E\u6BD4\u300D\u30F3\u30C3\u30F3\uFF5E\u3000\u6B63\u5F26\u3060\u306A\u3053\u308C\u306F",
    "id" : 115839586743226368,
    "created_at" : "2011-09-19 17:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 115839850233602048,
  "created_at" : "2011-09-19 17:29:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115839804880596992",
  "text" : "\u80CC\u7406\u6CD5\u266A\u80CC\u7406\u6CD5\u266A\u77DB\u76FE\u304C\u597D\u304D\uFF5E\u266A\u3063\u3066\u6B4C\uFF08\u30CF\u30A4\u30DB\u30FC\uFF01\u306E\u30EA\u30BA\u30E0\u3067\uFF09\u77E5\u3063\u3066\u308B\u4EBA\u3044\u307E\u3059\uFF1F",
  "id" : 115839804880596992,
  "created_at" : "2011-09-19 17:28:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115839203627118593",
  "text" : "\u3066\u304B\u4FFA\u306E\u8EAB\u5185\u8EAB\u5185\u30CD\u30BF\u5927\u597D\u304D\u3060\u306A\u3002\u3044\u3084\u3001\u4FFA\u3082\u5927\u597D\u304D\u3060\u3051\u3069\u3002\u8EAB\u5185\u30CD\u30BF\u3092\uFF33\uFF2E\uFF33\u3067\u5C55\u958B\u3057\u3066\u3044\u308B\u306E\u304C\u30A2\u30DB\u3060\u3088\u306A\u3002\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u304C\u72ED\u3059\u304E\u308B\u3063\uFF01",
  "id" : 115839203627118593,
  "created_at" : "2011-09-19 17:26:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115838963591286786",
  "text" : "\u306A\u3093\u304B\u7121\u5DEE\u5225\u30D5\u30A9\u30ED\u30FC\u3063\u307D\u3044\u3051\u3069\u3069\u3046\u305Bbot\u3060\u3057\u307B\u3046\u3063\u3066\u304A\u304F\u3053\u3068\u306B\u3057\u305F\u3002",
  "id" : 115838963591286786,
  "created_at" : "2011-09-19 17:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115838366385307648",
  "text" : "\uFF01\uFF1F\u305D\u308C\u306F\u305D\u308C\u3067\u304A\u304B\u3057\u304F\u306A\u3044\u304B\uFF1F\u3042\u3093\u306A\u8EAB\u5185\u30CD\u30BFbot\u2026mixi\u306E\u8EAB\u5185\u30CD\u30BF\u30B3\u30DF\u30E5\u30CB\u30C6\u30A3\u306B\u8CBC\u3063\u305F\u304B\u3089\u30B9\u30D1\u30E0\u7684\u306A\u3042\u308C\uFF1F\u4E2D\u8EAB\u898B\u3066\u307F\u3088\u3046\u3002",
  "id" : 115838366385307648,
  "created_at" : "2011-09-19 17:23:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115838072117149696",
  "text" : "\u3068\u304A\u3082\u3063\u305F\u3089bot\u306E\u65B9\u3060\u3063\u305F\u307F\u305F\u3044\u3002\u3073\u3063\u304F\u308A\u3002",
  "id" : 115838072117149696,
  "created_at" : "2011-09-19 17:22:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115837471757058048",
  "text" : "\u306A\u3093\u304B16\u30A2\u30AB\u30A6\u30F3\u30C8\u304F\u3089\u3044\u304B\u3089\u30D5\u30A9\u30ED\u30FC\u7206\u6483\u3092\u3082\u3089\u3063\u305F\u3002\u4E2D\u8EAB\u898B\u3066\u307F\u306A\u3044\u3068\u308F\u304B\u3093\u306A\u3044\u3051\u3069\u3042\u3093\u307E\u308A\u3044\u3044\u306B\u304A\u3044\u306F\u3057\u306A\u3044\u3002",
  "id" : 115837471757058048,
  "created_at" : "2011-09-19 17:19:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115836524888735744",
  "geo" : { },
  "id_str" : "115836742778621952",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u3042\u3001\u3061\u3083\u3093\u3068\u8AAD\u3093\u3067\u306A\u304B\u3063\u305F\u3002\u3054\u3081\u3093\u306A\u3055\u3044orz",
  "id" : 115836742778621952,
  "in_reply_to_status_id" : 115836524888735744,
  "created_at" : "2011-09-19 17:16:46 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115834361890353153",
  "geo" : { },
  "id_str" : "115836621479350272",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3048\u3047\uFF01\uFF1F\u3053\u308C\u3063\u3066\u75C5\u6C17\u306A\u306E\u304B\u3044\uFF01\uFF1F\u307B\u3046\u3063\u3066\u304A\u3044\u3066\u308B\u304C\u554F\u984C\u306A\u3044\u305C\u3002",
  "id" : 115836621479350272,
  "in_reply_to_status_id" : 115834361890353153,
  "created_at" : "2011-09-19 17:16:17 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115835870409539584",
  "geo" : { },
  "id_str" : "115836293463814145",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u304A\u3081\u30A1\uFF01\u6BB5\u4F4D\u306F\u8CA0\u3051\u308B\u3068\u4E0B\u304C\u308B\u306E\u3067\u3053\u3053\u304B\u3089\u3067\u3059\uFF01",
  "id" : 115836293463814145,
  "in_reply_to_status_id" : 115835870409539584,
  "created_at" : "2011-09-19 17:14:59 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115835574119694336",
  "geo" : { },
  "id_str" : "115836080682577920",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8A66\u9A13\u306F\u306A\u304B\u3063\u305F\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u3002\u307E\u3041\u5408\u3063\u3066\u3082\u30BB\u30F3\u30BF\u30FC\u30EC\u30D9\u30EB\u3060\u3057\u554F\u984C\u306A\u3044\u3068\u601D\u3046\u3051\u3069\u3002\n\u4E0B\u5BBF\u3059\u308B\u306B\u3057\u3066\u3082\u500B\u4EBA\u5951\u7D04\u3059\u308B\u306A\u3089\u5F8C\u8F29\u3068\u304B\u5730\u5143\u306E\u65B9\u304C\u7ACB\u3061\u56DE\u308A\u3084\u3059\u3044\u3068\u601D\u3046\u305C\u3002",
  "id" : 115836080682577920,
  "in_reply_to_status_id" : 115835574119694336,
  "created_at" : "2011-09-19 17:14:08 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115835395144556545",
  "text" : "RT @akeopyaa: @end313124 \u305D\u306E\u982D\u304C\u5FEB\u65B9\u306B\u5411\u304B\u3046\u3088\u3046\u4ECB\u62B1\u3057\u3066\u3084\u308D\u3046\u304B\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "115833638335168512",
    "geo" : { },
    "id_str" : "115834361890353153",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u305D\u306E\u982D\u304C\u5FEB\u65B9\u306B\u5411\u304B\u3046\u3088\u3046\u4ECB\u62B1\u3057\u3066\u3084\u308D\u3046\u304B\uFF1F",
    "id" : 115834361890353153,
    "in_reply_to_status_id" : 115833638335168512,
    "created_at" : "2011-09-19 17:07:18 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 115835395144556545,
  "created_at" : "2011-09-19 17:11:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115834410674290689",
  "geo" : { },
  "id_str" : "115835335950340096",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30C8\u30E9\u30A4\u3068\u304B\u305D\u306E\u8FBA\u306E\u30A2\u30EC\u306B\u767B\u9332\u3057\u305F\u3002\u3042\u3068\u306F\u9023\u7D61\u5F85\u3064\u3093\u3058\u3083\u306A\u304F\u3066\u3053\u3063\u3061\u304B\u3089\u9023\u7D61\u3057\u305F\u65B9\u304C\u3044\u3044\u304B\u3082\u3002\u306A\u3093\u306A\u3089\u4E8B\u52D9\u6240\u51FA\u5411\u304F\u65B9\u304C\u3044\u3044\u3089\u3057\u3044\u3002",
  "id" : 115835335950340096,
  "in_reply_to_status_id" : 115834410674290689,
  "created_at" : "2011-09-19 17:11:10 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115834150623256576",
  "text" : "\u304A\u306A\u304B\u6E1B\u3063\u305F\u306A\u3041\u3002\u304A\u3086\u306F\u3093\u65E9\u3044\u3068\u3053\u306E\u6642\u9593\u306B\u304A\u306A\u304B\u6E1B\u308B\u3002",
  "id" : 115834150623256576,
  "created_at" : "2011-09-19 17:06:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115833638335168512",
  "text" : "\u7F8E\u3057\u304F\u306A\u3044\"\u89E3\u6CD5\"\u3067\u3059\u304C\u3001\u9006\u7406\uFF01\u305D\u306E\u305B\u3044\u3067\u7F8E\u3057\u3044\u89E3\u304D\u65B9\u306B\u6C17\u4ED8\u3044\u305F\u308A\u3059\u308B\"\u89E3\u653E\"\u611F\u3082\u60AA\u304F\u306A\u304B\u3063\u305F\u308A\u3059\u308B\u3002",
  "id" : 115833638335168512,
  "created_at" : "2011-09-19 17:04:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115833057587638274",
  "text" : "\u8AD6\u7406\u30D1\u30BA\u30EB\u3068\u304B\u6574\u6570\u554F\u984C\u307F\u305F\u3044\u306A\u306E\u3063\u3066\u89E3\u3051\u306A\u3044\u89E3\u3051\u306A\u3044\u3068\u601D\u3044\u306A\u304C\u3089\u3082\u3042\u304D\u3089\u3081\u304D\u308C\u306A\u3044\u3067\u9577\u3005\u89E3\u3044\u3061\u3083\u3046\u3093\u3060\u3088\u306A\u30FC\u3002\u3057\u3089\u307F\u3064\u3076\u3057\u3068\u304B\u5ACC\u3044\u3058\u3083\u306A\u3044\u3057\u3001\u6700\u8FD1\u306F\u30D7\u30ED\u30B0\u30E9\u30E0\u3067\u3054\u308A\u62BC\u3057\u3059\u308B\u3063\u3066\u3044\u3046\u8352\u6280\u3092\u899A\u3048\u3066\u3057\u307E\u3063\u3066\u3044\u3051\u306A\u3044\u3002",
  "id" : 115833057587638274,
  "created_at" : "2011-09-19 17:02:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/VDD5iT4a",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115832697305300992",
  "text" : "\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3067\u300Cend313124\u3055\u3093\u300D\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3059\u308B #theinterviews http:\/\/t.co\/VDD5iT4a",
  "id" : 115832697305300992,
  "created_at" : "2011-09-19 17:00:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115832400428269570",
  "text" : "\u4F55\u306B\u3067\u3082\u8208\u5473\u304C\u3042\u308B\u3001\u306F\u4F55\u306B\u3082\u8208\u5473\u304C\u306A\u3044\u306B\u7E4B\u304C\u308A\u5F97\u308B\u3088\u306A\u30FC\u3002\u3046\u306A\u30FC\u3002",
  "id" : 115832400428269570,
  "created_at" : "2011-09-19 16:59:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115831545683656704",
  "text" : "\u30AF\u30A4\u30BA\u3068\u3044\u3066\u3044\u305F\u3089\u3053\u3093\u306A\u6642\u9593\u3002\u76EE\u304C\u3055\u3048\u3066\u3044\u308B\uFF57",
  "id" : 115831545683656704,
  "created_at" : "2011-09-19 16:56:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/NDiYWKvC",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=otaks21",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115823771524399104",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001otaks21\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/NDiYWKvC",
  "id" : 115823771524399104,
  "created_at" : "2011-09-19 16:25:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115783073798426624",
  "text" : "@nico_reflexio \u3093\uFF1F\u8A71\u304C\u898B\u3048\u306A\u3044\u3093\u3060\u304C\uFF1F",
  "id" : 115783073798426624,
  "created_at" : "2011-09-19 13:43:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115781881634631681",
  "text" : "@nico_reflexio \u3044\u3084\u30FC\u666E\u901A\u306B\uFF30\uFF23\u3067\u3084\u3063\u3066\u308B\u304B\u3089\u5927\u4E08\u592B\u3002",
  "id" : 115781881634631681,
  "created_at" : "2011-09-19 13:38:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115779516508549120",
  "text" : "\u6C17\u306B\u306A\u3063\u3066\u308B\u554F\u984C\u3092\u305F\u307E\u306B\u306F\u30D7\u30ED\u30B0\u30E9\u30E0\u3067\u89E3\u3044\u3066\u307F\u3088\u3046\u3068\u601D\u3044\u7ACB\u3063\u305F\u3002\u958B\u59CB\u3002",
  "id" : 115779516508549120,
  "created_at" : "2011-09-19 13:29:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3063\u304B\u4EAD\u7FC1('~`)\u6B7B\u306B\u640D\u306A\u3044",
      "screen_name" : "kikateo",
      "indices" : [ 3, 11 ],
      "id_str" : "146151493",
      "id" : 146151493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115748251470282752",
  "text" : "RT @kikateo: \u300C\u300E\u53EF\u611B\u3044\u300F\u306F\u300D\n\u300C\u300C\u300C\u3064\u304F\u308C\u308B\uFF01\u300D\u300D\u300D\n\u300C\u4F5C\u3063\u305F\u3082\u306E\u306F\u300D\n\u300C\u300C\u300C\u58CA\u308C\u308B\uFF01\u300D\u300D\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115714876168609792",
    "text" : "\u300C\u300E\u53EF\u611B\u3044\u300F\u306F\u300D\n\u300C\u300C\u300C\u3064\u304F\u308C\u308B\uFF01\u300D\u300D\u300D\n\u300C\u4F5C\u3063\u305F\u3082\u306E\u306F\u300D\n\u300C\u300C\u300C\u58CA\u308C\u308B\uFF01\u300D\u300D\u300D",
    "id" : 115714876168609792,
    "created_at" : "2011-09-19 09:12:31 +0000",
    "user" : {
      "name" : "\u304D\u3063\u304B\u4EAD\u7FC1('~`)\u6B7B\u306B\u640D\u306A\u3044",
      "screen_name" : "kikateo",
      "protected" : false,
      "id_str" : "146151493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2622467839\/lhiiycze210i686oat4d_normal.gif",
      "id" : 146151493,
      "verified" : false
    }
  },
  "id" : 115748251470282752,
  "created_at" : "2011-09-19 11:25:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 3, 13 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115746483785043968",
  "text" : "RT @eclair_15: \u30DD\u30B1\u30C3\u30C8\u30E2\u30F3\u30B9\u30BF\u30FC\u304F\u3063\u3061\u3093\u3071\u306F\u6587\u5B57\u5165\u529B\u6B04\u306B\u300C\u3086\u300D\u3057\u304B\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115744193623752704",
    "text" : "\u30DD\u30B1\u30C3\u30C8\u30E2\u30F3\u30B9\u30BF\u30FC\u304F\u3063\u3061\u3093\u3071\u306F\u6587\u5B57\u5165\u529B\u6B04\u306B\u300C\u3086\u300D\u3057\u304B\u306A\u3044",
    "id" : 115744193623752704,
    "created_at" : "2011-09-19 11:09:00 +0000",
    "user" : {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "protected" : false,
      "id_str" : "158645894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604517314164162560\/4WMjGFnD_normal.png",
      "id" : 158645894,
      "verified" : false
    }
  },
  "id" : 115746483785043968,
  "created_at" : "2011-09-19 11:18:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115731763317313538",
  "text" : "\u306A\u308B\u305F\u3051\u3084\u308F\u3089\u304B\u3044\u3084\u3064\u304C\u3044\u3044\u306A\u3002\u3053\u308C\u305D\u308D\u305D\u308D\u98DF\u3079\u3089\u3093\u306A\u304F\u306A\u308B\u3060\u308D\u3063\u3066\u3084\u3064\u3092\u51B7\u3084\u3057\u3066\u3044\u305F\u3060\u304D\u305F\u3044\u3002",
  "id" : 115731763317313538,
  "created_at" : "2011-09-19 10:19:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115731647504203776",
  "text" : "\u6843\u98DF\u3079\u305F\u3044\u306A\u30FC",
  "id" : 115731647504203776,
  "created_at" : "2011-09-19 10:19:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115668415166939136",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u673A\u306E\u4E0A\u3092\u7247\u4ED8\u3051\u3066\u52C9\u5F37\u3057\u3088\u3046\u3002\u3053\u3053\u6570\u65E5\u7121\u70BA\u306B\u904E\u3054\u3057\u904E\u304E\u3066\u3044\u308B\u3002",
  "id" : 115668415166939136,
  "created_at" : "2011-09-19 06:07:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30EB\u30E1\u30EB\u57A2\u3067\u3059",
      "screen_name" : "nero_0223",
      "indices" : [ 3, 13 ],
      "id_str" : "212884519",
      "id" : 212884519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115626836964294656",
  "text" : "RT @nero_0223: \u3010\u7DE9\u304FRT\u5E0C\u671B\u3011\u4ECA\u65E5\u306F\u3046\u3061\u306E\u5144\u306E\u8A95\u751F\u65E5\u3067\u3001\u53EF\u80FD\u6027\u306F\u5C11\u306A\u3044\u3068\u601D\u3046\u306E\u3067\u3059\u304C\u3001RT\u3067\u6771\u65B9\u30AF\u30E9\u30B9\u30BF\u306A\u5144\u306E\u3068\u3053\u307E\u3067\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u5C4A\u3051\u308C\u308B\u304B\u8A66\u3057\u3066\u307F\u305F\u3044\u306E\u3067\u3059\u2026\uFF01\u4ED8\u304D\u5408\u3063\u3066\u3084\u308B\u3088\u3063\u3066\u65B9\u306FRT\u3057\u3066\u4E0B\u3055\u3063\u305F\u3089\u5B09\u3057\u3044\u3067\u3059\u3002\u3000\u5144\u3061\u3083\u3093\u8A95\u751F\u65E5\u304A\u3081\u3067\u3068\u3046\uFF01\uFF01\u305D\u308C\u3068\u4F55 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115622116782653440",
    "text" : "\u3010\u7DE9\u304FRT\u5E0C\u671B\u3011\u4ECA\u65E5\u306F\u3046\u3061\u306E\u5144\u306E\u8A95\u751F\u65E5\u3067\u3001\u53EF\u80FD\u6027\u306F\u5C11\u306A\u3044\u3068\u601D\u3046\u306E\u3067\u3059\u304C\u3001RT\u3067\u6771\u65B9\u30AF\u30E9\u30B9\u30BF\u306A\u5144\u306E\u3068\u3053\u307E\u3067\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u5C4A\u3051\u308C\u308B\u304B\u8A66\u3057\u3066\u307F\u305F\u3044\u306E\u3067\u3059\u2026\uFF01\u4ED8\u304D\u5408\u3063\u3066\u3084\u308B\u3088\u3063\u3066\u65B9\u306FRT\u3057\u3066\u4E0B\u3055\u3063\u305F\u3089\u5B09\u3057\u3044\u3067\u3059\u3002\u3000\u5144\u3061\u3083\u3093\u8A95\u751F\u65E5\u304A\u3081\u3067\u3068\u3046\uFF01\uFF01\u305D\u308C\u3068\u4F55\u5E74\u3082\u5BB6\u306E\u70BA\u306B\u9811\u5F35\u3063\u3066\u304F\u308C\u3066\u3042\u308A\u304C\u3068\u3046\uFF01",
    "id" : 115622116782653440,
    "created_at" : "2011-09-19 03:03:55 +0000",
    "user" : {
      "name" : "\u30CF\u30EB\u30E1\u30EB\u57A2\u3067\u3059",
      "screen_name" : "nero_0223",
      "protected" : false,
      "id_str" : "212884519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461927847074881538\/VPLcRnFl_normal.png",
      "id" : 212884519,
      "verified" : false
    }
  },
  "id" : 115626836964294656,
  "created_at" : "2011-09-19 03:22:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30FC\u30B8",
      "screen_name" : "Kiriyama_George",
      "indices" : [ 3, 19 ],
      "id_str" : "130188593",
      "id" : 130188593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "sm15151005",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/TFrFDxNE",
      "expanded_url" : "http:\/\/nico.ms\/sm15151005",
      "display_url" : "nico.ms\/sm15151005"
    } ]
  },
  "geo" : { },
  "id_str" : "115487907552296960",
  "text" : "RT @Kiriyama_George: \u8B0E\u306E\u767A\u60F3\u3000\u30D0\u30C8\u30EB\u30C9\u30FC\u30E0\u3067\u5B66\u3076\u53E4\u5178\u3000\u300E\u6795\u8349\u5B50\u300F (1:55) #nicovideo #sm15151005 http:\/\/t.co\/TFrFDxNE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nicovideo",
        "indices" : [ 30, 40 ]
      }, {
        "text" : "sm15151005",
        "indices" : [ 41, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/TFrFDxNE",
        "expanded_url" : "http:\/\/nico.ms\/sm15151005",
        "display_url" : "nico.ms\/sm15151005"
      } ]
    },
    "geo" : { },
    "id_str" : "115481163111477249",
    "text" : "\u8B0E\u306E\u767A\u60F3\u3000\u30D0\u30C8\u30EB\u30C9\u30FC\u30E0\u3067\u5B66\u3076\u53E4\u5178\u3000\u300E\u6795\u8349\u5B50\u300F (1:55) #nicovideo #sm15151005 http:\/\/t.co\/TFrFDxNE",
    "id" : 115481163111477249,
    "created_at" : "2011-09-18 17:43:49 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30FC\u30B8",
      "screen_name" : "Kiriyama_George",
      "protected" : false,
      "id_str" : "130188593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1698591176\/image_normal",
      "id" : 130188593,
      "verified" : false
    }
  },
  "id" : 115487907552296960,
  "created_at" : "2011-09-18 18:10:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115487318198067200",
  "text" : "\u305D\u308D\u305D\u308D\u5BDD\u307E\u3059\u3002\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 115487318198067200,
  "created_at" : "2011-09-18 18:08:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115486742592749568",
  "text" : "\u00D7\u4ED6\u793E\u25CB\u4ED6\u8005",
  "id" : 115486742592749568,
  "created_at" : "2011-09-18 18:05:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115486021839368193",
  "text" : "\u4ED6\u793E\u7D39\u4ECB\u3084\u308A\u305F\u3044\u3057\u3084\u3089\u308C\u305F\u3044\u3051\u3069\u8EAB\u5185\u9664\u304F\u3068\u3042\u3093\u307E\u308A\u7D61\u3093\u3067\u306A\u3044\u305B\u3044\u3067\u4E92\u3044\u306B\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u30D1\u30BF\u30FC\u30F3\u304C\u898B\u3048\u3066\u3044\u308B",
  "id" : 115486021839368193,
  "created_at" : "2011-09-18 18:03:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115481685352648704",
  "geo" : { },
  "id_str" : "115482496585580544",
  "in_reply_to_user_id" : 100989370,
  "text" : "@yuyushirai \u30D3\u30EA\u30E4\u30FC\u30C9\u306F\u4E0A\u624B\u306A\u4EBA\u3068\u3084\u308B\u3068\u9806\u756A\u304C\u56DE\u3063\u3066\u3053\u306A\u3044\u3067\u3059\uFF57",
  "id" : 115482496585580544,
  "in_reply_to_status_id" : 115481685352648704,
  "created_at" : "2011-09-18 17:49:07 +0000",
  "in_reply_to_screen_name" : "orangeninjin",
  "in_reply_to_user_id_str" : "100989370",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115478517222879232",
  "text" : "mixi\u306E\u30AA\u30EF\u30B3\u30F3\u611F\u306F\u7570\u5E38\u2026\u2026\u3002",
  "id" : 115478517222879232,
  "created_at" : "2011-09-18 17:33:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115475483780583424",
  "text" : "\u3066\u304B\u5929\u9CF3\u306E\u30C1\u30E3\u30C3\u30C8\u6A5F\u80FD\u521D\u3081\u3066\u4F7F\u3063\u305F\u306A\uFF57",
  "id" : 115475483780583424,
  "created_at" : "2011-09-18 17:21:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    }, {
      "name" : "Malena Machado ",
      "screen_name" : "MalMach",
      "indices" : [ 10, 18 ],
      "id_str" : "32876510",
      "id" : 32876510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115474045025267712",
  "geo" : { },
  "id_str" : "115474376144596992",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz @MalMach \u304A\u75B2\u308C\u69D8\u3067\u3057\u305F\u3002\u305C\u3072\u305C\u3072\u307E\u305F\u3002",
  "id" : 115474376144596992,
  "in_reply_to_status_id" : 115474045025267712,
  "created_at" : "2011-09-18 17:16:51 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115474106903826433",
  "text" : "\u3066\u304B\u826F\u304F\u898B\u305F\u3089\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u306B\u9EBB\u96C0\u3068\u3055\u3048\u66F8\u3044\u3066\u306A\u3044\uFF57\uFF57\uFF57\u629C\u3051\u843D\u3061\u3066\u305F\u304B\uFF57\uFF57\uFF57",
  "id" : 115474106903826433,
  "created_at" : "2011-09-18 17:15:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115473937193902080",
  "text" : "\u5929\u9CF3\u306E\uFF29\uFF24\u3068\u30C4\u30A4\u30C3\u30BF-\uFF29\uFF24\u304C\u9055\u3046\u3068\u8A8D\u8B58\u3055\u308C\u306B\u304F\u304F\u3066\u7533\u3057\u8A33\u306A\u3044\u306A\u30FC\u3002\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u306B\u66F8\u3044\u3066\u304A\u304F\u3079\u304D\u3060\u3063\u305F\u304B\u306A\u3002",
  "id" : 115473937193902080,
  "created_at" : "2011-09-18 17:15:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115473439359381505",
  "geo" : { },
  "id_str" : "115473644184027137",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 115473644184027137,
  "in_reply_to_status_id" : 115473439359381505,
  "created_at" : "2011-09-18 17:13:56 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115473571773562880",
  "text" : "\u3044\u3084\u3001\u77E5\u3089\u306A\u3044\u4EBA\u3063\u3066\u306E\u3082\u306A\u3093\u304B\u3044\u3084\u306A\u8A00\u3044\u65B9\u3060\u306A\u30FB\u30FB\u30FB\u3002\u3067\u3082\u500B\u5BA4\u3067\u8EAB\u5185\u4EE5\u5916\u3068\u3084\u3063\u305F\u306E\u521D\u3081\u3066\u3060\u3063\u305F\u306A\u3041\u3002",
  "id" : 115473571773562880,
  "created_at" : "2011-09-18 17:13:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115473247285415936",
  "text" : "\u77E5\u3089\u306A\u3044\u4EBA\u3068\u9EBB\u96C0\u304A\u75B2\u308C\u69D8\u3067\u3057\u305F\u3002\u4ECA\u5EA6\u306F\u305C\u30724\u4EBA\u6253\u3061\u3067\uFF01\uFF13\u6253\u3061\u30A4\u30F3\u30D5\u30EC\u6016\u3044\u30FB\u30FB\u30FB\u3002",
  "id" : 115473247285415936,
  "created_at" : "2011-09-18 17:12:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "indices" : [ 3, 17 ],
      "id_str" : "199329343",
      "id" : 199329343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115457561897091072",
  "text" : "RT @Satomii_Opera: \u300C\u3042\u3001\u3053\u306E\u8A66\u9A13\u554F\u984C\u3001\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\uFF01\u300D\n\u300C\u3042\u3001\u3053\u306E\u5165\u8A66\u554F\u984C\u3082\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\uFF01\u300D\n\u300C\u3042\u308C\uFF1F\u3000\u3053\u306E\u9762\u63A5\u4F1A\u5834\u306E\u666F\u8272\u3001\u9032\u7814\u30BC\u30DF\u3067\u898B\u305F\u305E\uFF1F\u300D\n\u300C\u3053\u306E\u30D7\u30ED\u30DD\u30FC\u30BA\u3082\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\u300D\n\u300C\u3053\u306E\u5B50\u304C\u751F\u307E\u308C\u308B\u77AC\u9593\u3082\u9032\u7814\u30BC\u30DF\u3067\u898B\u305F\u300D\n\u300C\u3053\u306E\u6B7B\u306B\u969B\u3082\u9032\u7814 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111424162744119296",
    "text" : "\u300C\u3042\u3001\u3053\u306E\u8A66\u9A13\u554F\u984C\u3001\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\uFF01\u300D\n\u300C\u3042\u3001\u3053\u306E\u5165\u8A66\u554F\u984C\u3082\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\uFF01\u300D\n\u300C\u3042\u308C\uFF1F\u3000\u3053\u306E\u9762\u63A5\u4F1A\u5834\u306E\u666F\u8272\u3001\u9032\u7814\u30BC\u30DF\u3067\u898B\u305F\u305E\uFF1F\u300D\n\u300C\u3053\u306E\u30D7\u30ED\u30DD\u30FC\u30BA\u3082\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\u300D\n\u300C\u3053\u306E\u5B50\u304C\u751F\u307E\u308C\u308B\u77AC\u9593\u3082\u9032\u7814\u30BC\u30DF\u3067\u898B\u305F\u300D\n\u300C\u3053\u306E\u6B7B\u306B\u969B\u3082\u9032\u7814\u30BC\u30DF\u3067\u2026\u2026\u9032\u7814\u30BC\u30DF\u3068\u306F\u4E00\u4F53\u3001\u4F55\u3060\u3063\u305F\u306E\u304B\u2026\u2026\u300D",
    "id" : 111424162744119296,
    "created_at" : "2011-09-07 13:02:45 +0000",
    "user" : {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "protected" : false,
      "id_str" : "199329343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212059931\/satomii_opera_normal.jpg",
      "id" : 199329343,
      "verified" : false
    }
  },
  "id" : 115457561897091072,
  "created_at" : "2011-09-18 16:10:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115448401566498816",
  "geo" : { },
  "id_str" : "115449154951581696",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u61D0\u304B\u3057\u3044\u5730\u540D\u304C\uFF01\u4E2D\u592E\u7DDA\u306F\u3044\u3063\u3064\u3082\u82E5\u5E72\u9045\u308C\u3066\u307E\u3059\u3088\u306D",
  "id" : 115449154951581696,
  "in_reply_to_status_id" : 115448401566498816,
  "created_at" : "2011-09-18 15:36:38 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 3, 10 ],
      "id_str" : "129796835",
      "id" : 129796835
    }, {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 50, 64 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115413696485924864",
  "text" : "RT @7M1IHN: \u3044\u3084\u3001\u8D85\u30CE\u30FC\u30D9\u30EB\u8CDE\u3082\u306E\u3067\u3057\u3087\u3046\u3002\u767A\u8A00\u8005\u306B\u306F\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u8CDE\uFF08\u6587\u5B66\uFF09\u3092\u3002 RT @_flyingmoomin: \u5DE5\u5B66\u79D1\u306E\u53CB\u4EBA\u304C\u7206\u85AC\u306B\u3064\u3044\u3066\u89E3\u8AAC\u3057\u3066\u304F\u308C\u305F\u3093\u3060\u3051\u3069, \u30C6\u30F3\u30B7\u30E7\u30F3\u4E0A\u304C\u308A\u3059\u304E\u3066\u300C\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u306F\u30CE\u30FC\u30D9\u30EB\u8CDE\u3082\u306E\u306E\u767A\u660E\u3060\u300D\u3063\u3066\u8A00\u3063\u3066\u305F. \u65AC\u65B0\u904E\u304E\u308B.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for iPhone\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
        "screen_name" : "_flyingmoomin",
        "indices" : [ 38, 52 ],
        "id_str" : "91483221",
        "id" : 91483221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115412255734104065",
    "text" : "\u3044\u3084\u3001\u8D85\u30CE\u30FC\u30D9\u30EB\u8CDE\u3082\u306E\u3067\u3057\u3087\u3046\u3002\u767A\u8A00\u8005\u306B\u306F\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u8CDE\uFF08\u6587\u5B66\uFF09\u3092\u3002 RT @_flyingmoomin: \u5DE5\u5B66\u79D1\u306E\u53CB\u4EBA\u304C\u7206\u85AC\u306B\u3064\u3044\u3066\u89E3\u8AAC\u3057\u3066\u304F\u308C\u305F\u3093\u3060\u3051\u3069, \u30C6\u30F3\u30B7\u30E7\u30F3\u4E0A\u304C\u308A\u3059\u304E\u3066\u300C\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u306F\u30CE\u30FC\u30D9\u30EB\u8CDE\u3082\u306E\u306E\u767A\u660E\u3060\u300D\u3063\u3066\u8A00\u3063\u3066\u305F. \u65AC\u65B0\u904E\u304E\u308B.",
    "id" : 115412255734104065,
    "created_at" : "2011-09-18 13:10:00 +0000",
    "user" : {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "protected" : false,
      "id_str" : "129796835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1755356777\/7M1IHN_normal.jpg",
      "id" : 129796835,
      "verified" : false
    }
  },
  "id" : 115413696485924864,
  "created_at" : "2011-09-18 13:15:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115396863036895233",
  "text" : "\u3042\u30FC\u306B\u305B\u307B\u30FC\u898B\u9003\u3057\u305F",
  "id" : 115396863036895233,
  "created_at" : "2011-09-18 12:08:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115394921128656896",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 115394921128656896,
  "created_at" : "2011-09-18 12:01:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "saitohk",
      "screen_name" : "asc_gamefreak",
      "indices" : [ 42, 56 ],
      "id_str" : "8560662",
      "id" : 8560662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115373117152563200",
  "text" : "RT @hyuki: \u6570\u5B66\u30AC\u30FC\u30EB\u306A\u3046\u3002\u306B\u306F\u3001\u5C11\u306A\u304F\u3068\u3082\u56DB\u901A\u308A\u306E\u89E3\u91C8\u304C\u3042\u308A\u307E\u3059\u3002RT @asc_gamefreak: \u6570\u5B66\u30AC\u30FC\u30EB\u306A\u3046\u3002 \u3063\u3066\u66F8\u304F\u3068\u5973\u88C5\u3057\u3066\u308B\u307F\u305F\u3044\u3060\u306D\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "saitohk",
        "screen_name" : "asc_gamefreak",
        "indices" : [ 31, 45 ],
        "id_str" : "8560662",
        "id" : 8560662
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115369944060928000",
    "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306A\u3046\u3002\u306B\u306F\u3001\u5C11\u306A\u304F\u3068\u3082\u56DB\u901A\u308A\u306E\u89E3\u91C8\u304C\u3042\u308A\u307E\u3059\u3002RT @asc_gamefreak: \u6570\u5B66\u30AC\u30FC\u30EB\u306A\u3046\u3002 \u3063\u3066\u66F8\u304F\u3068\u5973\u88C5\u3057\u3066\u308B\u307F\u305F\u3044\u3060\u306D\uFF01",
    "id" : 115369944060928000,
    "created_at" : "2011-09-18 10:21:52 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 115373117152563200,
  "created_at" : "2011-09-18 10:34:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115353280590258176",
  "text" : "@ayu167 \u6709\u610F\u7FA9\u306A\u4E00\u65E5\u3058\u3083\u306A\u3044\u3063\u3059\u304B\uFF57\uFF57\uFF57",
  "id" : 115353280590258176,
  "created_at" : "2011-09-18 09:15:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115352373060321281",
  "text" : "\u55DA\u547C\u307E\u305F\u7121\u70BA\u306B\u4E00\u65E5\u304C\u904E\u304E\u3066\u3044\u304F\u3002",
  "id" : 115352373060321281,
  "created_at" : "2011-09-18 09:12:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115327657280937984",
  "text" : "@koketomi \u901F\u653B\u3068\u3044\u3046\u307B\u3069\u65E9\u304F\u306F\u306A\u3044\u304C9\u9023\u9396\u304F\u3089\u3044\u306A\u3089\u5B9F\u8DF5\u306B\u8010\u3048\u308B\u3068\u306F\u601D\u3046\u3002\u3084\u3063\u3066\u307F\u308B\u304B\u306A\u30FC\u3002",
  "id" : 115327657280937984,
  "created_at" : "2011-09-18 07:33:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115326256018501632",
  "text" : "@koketomi \u3053\u3046\u3044\u3046\u4EBA\u3057\u304B\u5468\u308A\u306B\u3044\u306A\u3044\u305B\u3044\u3067\u6016\u304F\u3066\u71B1\u5E2F\u306B\u53C2\u6226\u3067\u304D\u307E\u305B\u3093\uFF1E\uFF1C\n\u307E\u3001\u307E\u3068\u3082\u306B\u65E9\u304F\u7D44\u3081\u306A\u3044\u3057\u30A2\u30EC\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 115326256018501632,
  "created_at" : "2011-09-18 07:28:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115317438668742656",
  "text" : "@nico_reflexio @Hajime_Sake \u4ECA\u66F4\u304A\u306F\u3042\u308A\u3067\u3057\u305F\u3002",
  "id" : 115317438668742656,
  "created_at" : "2011-09-18 06:53:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/VDD5iT4a",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115304538906443776",
  "text" : "\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3067\u300Cend313124\u3055\u3093\u300D\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3059\u308B #theinterviews http:\/\/t.co\/VDD5iT4a\u3000\u805E\u304B\u308C\u306A\u3044\u3068\u7B54\u3048\u307E\u305B\u3093\u3002",
  "id" : 115304538906443776,
  "created_at" : "2011-09-18 06:01:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115303280023842816",
  "geo" : { },
  "id_str" : "115304069391851520",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 115304069391851520,
  "in_reply_to_status_id" : 115303280023842816,
  "created_at" : "2011-09-18 06:00:07 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115304022902181888",
  "text" : "\u89AA\u304C\u9001\u3063\u3066\u304F\u308C\u305F\u68A8\u304C\u7F8E\u5473\u3044\u3002\u3082\u3046\u3001\u3053\u306E\u307F\u305A\u307F\u305A\u3057\u3055\u3068\u7518\u3055\u304C\u4F55\u3068\u3082\u8A00\u3048\u306A\u3044\u3002\u679C\u7269\u306E\u4E2D\u3067\u68A8\u304C\u4E00\u756A\u597D\u304D\u304B\u3082\u77E5\u308C\u306A\u3044\u3002\u67D4\u3089\u304B\u3044\u6843\u3068\u3044\u3044\u52DD\u8CA0\u3002",
  "id" : 115304022902181888,
  "created_at" : "2011-09-18 05:59:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115293231058649088",
  "geo" : { },
  "id_str" : "115293356019552256",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u30CA\u30A4\u30B9\u30C9\u30AF\u30DA\uFF01",
  "id" : 115293356019552256,
  "in_reply_to_status_id" : 115293231058649088,
  "created_at" : "2011-09-18 05:17:32 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115265638079012865",
  "text" : "\u306A\u3093\u304B\u968F\u5206\u5BDD\u3061\u3083\u3063\u305F\u306A\u3041\n\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 115265638079012865,
  "created_at" : "2011-09-18 03:27:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115095465879535616",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 115095465879535616,
  "created_at" : "2011-09-17 16:11:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115094612506447872",
  "text" : "\u732B\u3092\u62B1\u3044\u3066\u7720\u308A\u305F\u3044\u3002\n\u732B\u604B\u3057\u3044\u3002",
  "id" : 115094612506447872,
  "created_at" : "2011-09-17 16:07:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115048120987037696",
  "text" : "\u8D85\u304F\u3089\u3060\u306A\u3044\u3051\u3069\u3001\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u8CDE\u5927\u597D\u304D\u3067\u3059",
  "id" : 115048120987037696,
  "created_at" : "2011-09-17 13:03:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115048011901579264",
  "text" : "RT @tameninaru: \u6C34\u5175\u306B\u5B9F\u5305\u3092\u4F7F\u3046\u3053\u3068\u3092\u6B62\u3081\u3055\u305B\u3001\u4EE3\u308F\u308A\u306B\u300C\u30D0\u30FC\u30F3!\u300D\u3068\u53EB\u3070\u305B\u305F\u3053\u3068\u306B\u5BFE\u3057\u3066\u3002\uFF082000\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u5E73\u548C\u8CDE\uFF1A\u30A4\u30AE\u30EA\u30B9\u6D77\u8ECD\uFF09http:\/\/goo.gl\/sTnr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115047364384919552",
    "text" : "\u6C34\u5175\u306B\u5B9F\u5305\u3092\u4F7F\u3046\u3053\u3068\u3092\u6B62\u3081\u3055\u305B\u3001\u4EE3\u308F\u308A\u306B\u300C\u30D0\u30FC\u30F3!\u300D\u3068\u53EB\u3070\u305B\u305F\u3053\u3068\u306B\u5BFE\u3057\u3066\u3002\uFF082000\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u5E73\u548C\u8CDE\uFF1A\u30A4\u30AE\u30EA\u30B9\u6D77\u8ECD\uFF09http:\/\/goo.gl\/sTnr",
    "id" : 115047364384919552,
    "created_at" : "2011-09-17 13:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 115048011901579264,
  "created_at" : "2011-09-17 13:02:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115046354862080001",
  "text" : "\uFF17\u30FB\uFF11\uFF11\u306E\u30CE\u30FC\u30D6\u30E9\u30F3\u30C9\u306E\u98F4\u304C\u7D50\u69CB\u304A\u3044\u3057\u3044\u3002\u30B7\u30F3\u30D7\u30EB\u3002",
  "id" : 115046354862080001,
  "created_at" : "2011-09-17 12:56:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115045428826882048",
  "text" : "\u5F7C\u3089\u304C\u843D\u3068\u3057\u3066\u3044\u308B\u306E\u306F3\u6B21\u5143\u304B\u30892\u6B21\u5143\u3078\u306E\u7406\u60F3\u7684\u306B\u5909\u63DB\u3055\u308C\u305F\u5F71\u306A\u3093\u3060\u3051\u3069\u306D\u3063\u3002",
  "id" : 115045428826882048,
  "created_at" : "2011-09-17 12:52:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115044941863985152",
  "text" : "\u30AA\u30BF\u30AF\u7537\u5B50\u3092\u843D\u3068\u3059\u30B3\u30C4\u3063\u3066\u3001\u30DB\u30F3\u30C8\u306B\u843D\u3068\u3057\u305F\u3044\u306E\uFF1F\u9177\u3044\u4EBA\u306F3\u6B21\u5143\u305D\u306E\u3082\u306E\u306B\u7D76\u671B\u3092\u899A\u3048\u3066\u3044\u308B\u4EBA\u305F\u3061\u3060\u3088\uFF1F\u305D\u306E\u899A\u609F\u304C\u3042\u308B\uFF1F",
  "id" : 115044941863985152,
  "created_at" : "2011-09-17 12:50:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3068\u3068\u306F\u3044\u307E\u305B\u3093",
      "screen_name" : "tototo0202",
      "indices" : [ 3, 14 ],
      "id_str" : "1283852412",
      "id" : 1283852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115044809810526208",
  "text" : "RT @tototo0202: \u30AA\u30BF\u30AF\u7537\u5B50\u3092\u843D\u3068\u3059\u30B3\u30C4\uFF5E\u3063\u3066\u898B\u304B\u3051\u308B\u3051\u3069\uFF0C\u3076\u3063\u3061\u3083\u3051\u300C\u597D\u304D\u3067\u3059\uFF0C\u4ED8\u304D\u5408\u3063\u3066\u304F\u3060\u3055\u3044\uFF1E\uFF1C\u300D\u3067\u4E00\u6483\u3060\u3068\u601D\u3046\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115036464294797312",
    "text" : "\u30AA\u30BF\u30AF\u7537\u5B50\u3092\u843D\u3068\u3059\u30B3\u30C4\uFF5E\u3063\u3066\u898B\u304B\u3051\u308B\u3051\u3069\uFF0C\u3076\u3063\u3061\u3083\u3051\u300C\u597D\u304D\u3067\u3059\uFF0C\u4ED8\u304D\u5408\u3063\u3066\u304F\u3060\u3055\u3044\uFF1E\uFF1C\u300D\u3067\u4E00\u6483\u3060\u3068\u601D\u3046\u3002",
    "id" : 115036464294797312,
    "created_at" : "2011-09-17 12:16:45 +0000",
    "user" : {
      "name" : "\u3068\u3068\u3068",
      "screen_name" : "__t2",
      "protected" : false,
      "id_str" : "184964814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541025934631915520\/bKIUxOfh_normal.png",
      "id" : 184964814,
      "verified" : false
    }
  },
  "id" : 115044809810526208,
  "created_at" : "2011-09-17 12:49:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115040424816676864",
  "text" : "\u30E1\u30FC\u30EB\u3044\u3063\u3071\u3044\u6765\u307E\u3059\u306D\u3002\u300C\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u307E\u3057\u305F\uFF01\u300D\u3063\u3066\u3002 RT @superuncochan \u305D\u3046\u3044\u3084\u72AC\u306E\u4EBA\u306B\u30D5\u30A9\u30ED\u30FC\uFF06\u30EA\u30E0\u30FC\u30D6\u7E70\u308A\u8FD4\u3055\u308C\u3066\u308B",
  "id" : 115040424816676864,
  "created_at" : "2011-09-17 12:32:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115040005595987968",
  "text" : "\u8C46\u8150\u30E1\u30F3\u30BF\u30EB\u3063\u3066\u8A00\u3046\u3051\u3069\u9AD8\u91CE\u8C46\u8150\u3068\u304A\u307C\u308D\u8C46\u8150\u3067\u76F8\u5F53\u3061\u304C\u3046\u3088\u306D\u3002",
  "id" : 115040005595987968,
  "created_at" : "2011-09-17 12:30:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115039356405821440",
  "text" : "\u92ED\u5229\u306A\u30D0\u30FC\u30EB\u306E\u3088\u3046\u306A\u3082\u306E\u3002\u77DB\u76FE\uFF1F",
  "id" : 115039356405821440,
  "created_at" : "2011-09-17 12:28:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115039035902267392",
  "text" : "\u3053\u3046\u3044\u3046\u8A00\u8A9E\u3092\u307E\u305F\u3044\u3060\u8A00\u8449\u904A\u3073\u306F\u60AA\u304F\u306A\u3044\u3002",
  "id" : 115039035902267392,
  "created_at" : "2011-09-17 12:26:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3070\u308B\u3057\u3042",
      "screen_name" : "valshia",
      "indices" : [ 3, 11 ],
      "id_str" : "38161816",
      "id" : 38161816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115038965991604225",
  "text" : "RT @valshia: ZIP\u3067\u4E0B\u8F09\uFF08\u4E2D\u56FD\u8A9E\u306E\"\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\"\u3068\u65E5\u672C\u8A9E\u306E\"\u304F\u3060\u3055\u3044\"\u3092\u304B\u3051\u305F\u9AD8\u5EA6\u3067\u56FD\u969B\u7684\u306A\u30AE\u30E3\u30B0\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59423317668532224",
    "text" : "ZIP\u3067\u4E0B\u8F09\uFF08\u4E2D\u56FD\u8A9E\u306E\"\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\"\u3068\u65E5\u672C\u8A9E\u306E\"\u304F\u3060\u3055\u3044\"\u3092\u304B\u3051\u305F\u9AD8\u5EA6\u3067\u56FD\u969B\u7684\u306A\u30AE\u30E3\u30B0\uFF09",
    "id" : 59423317668532224,
    "created_at" : "2011-04-17 01:09:57 +0000",
    "user" : {
      "name" : "\u3070\u308B\u3057\u3042",
      "screen_name" : "valshia",
      "protected" : false,
      "id_str" : "38161816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000271007457\/4a0f250a54c9da72f8e1bfefa96d8ed0_normal.png",
      "id" : 38161816,
      "verified" : false
    }
  },
  "id" : 115038965991604225,
  "created_at" : "2011-09-17 12:26:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/DTYd8YaP",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/1388933",
      "display_url" : "theinterviews.jp\/end313124\/1388\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115037052407517184",
  "text" : "\u4EAC\u90FD\u3067\u751F\u6D3B\u3057\u3066\u3001\u6700\u521D\u306B\u9A5A\u3044\u305F\u4E8B\u306F\u306A\u3093\u3067\u3059\u304B\uFF1F - end313124 [\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA] #theinterviews http:\/\/t.co\/DTYd8YaP \u521D\u3081\u3066\u306E\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u6765\u305F\uFF01\u305D\u306E\u5272\u306B\u7B54\u3048\u304C\u9069\uFF54\uFF08\uFF52\uFF59",
  "id" : 115037052407517184,
  "created_at" : "2011-09-17 12:19:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115036754725183488",
  "text" : "@mskyaz \u30E2\u30C1\u30D9\u30FC\u30B7\u30E7\u30F3\u4FDD\u3064\u305F\u3081\u306A\u3089\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u3067\u3059\u304B\uFF1F\u4ED6\u304C\u758E\u304B\u3058\u3083\u307E\u305A\u3044\u3067\u3059\u304C\uFF57\u9069\u5EA6\u306B\u697D\u3057\u3080\u5206\u306B\u306F\u3002",
  "id" : 115036754725183488,
  "created_at" : "2011-09-17 12:17:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115034143452184576",
  "text" : "@mskyaz \u50D5\u306F\u6587\u7CFB\u3067\u3057\u305F\u306E\u3067\uFF33\u3057\u304B\u51FA\u3057\u305F\u3053\u3068\u306A\u3044\u3067\u3059\u304C\u3001\u305D\u308C\u3067\u3082\u6587\u7CFB\u57FA\u6E96\u3060\u3068\u8DA3\u5473\u306E\u9818\u57DF\u3067\u3057\u305F\u306D\uFF57\u7121\u99C4\u3067\u306F\u306A\u3044\u3068\u601D\u3044\u307E\u3059\u3051\u3069\u3001\u5FC5\u8981\u3067\u306F\u306A\u3044\u3067\u3057\u3087\u3046\u306D\uFF57",
  "id" : 115034143452184576,
  "created_at" : "2011-09-17 12:07:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115033862266032128",
  "text" : "\u56E0\u6570\u3001\u3066\u304B\u5F15\u6570\u3063\u3066\u300C\u3072\u304D\u3059\u3046\u300D\u3058\u3083\u306A\u3044\u306E\u304B\u3002\u3072\u304D\u3059\u3046\u3060\u3068\u4E00\u767A\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 115033862266032128,
  "created_at" : "2011-09-17 12:06:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115033490394845184",
  "text" : "@mskyaz \u5B66\u30B3\u30F3\u306E\u554F\u984C\u306F\u5909\u3067\u3044\u3044\u52C9\u5F37\u306B\u306A\u308A\u307E\u3059\u3088\u306D\u3002\u6B63\u76F4\u3001\u8DA3\u5473\u306E\u9818\u57DF\u3067\u3059\u3051\u3069\u3002",
  "id" : 115033490394845184,
  "created_at" : "2011-09-17 12:04:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115032742944710656",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 115032742944710656,
  "created_at" : "2011-09-17 12:01:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115032304195342336",
  "text" : "\u5730\u5473\u3060\u304Cku\u306E\u30EA\u30B9\u30C8\u306B\u5165\u308C\u3066\u3082\u3089\u3063\u305F\u3002ku\u30AF\u30E9\u30B9\u30BF\u304B\u5FAE\u5999\u30AF\u30E9\u30B9\u30BF\u3092\u629C\u3051\u51FA\u3059\u3075\u308A\u3092\u3057\u3088\u3046\u3002",
  "id" : 115032304195342336,
  "created_at" : "2011-09-17 12:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115031319263719424",
  "geo" : { },
  "id_str" : "115031563443507200",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u65E5\u4ED8\u5909\u3063\u3061\u3083\u3063\u3066\u3093\u3058\u3083\u3093\u3063\uFF01\u6BCE\u65E5\u30D1\u30A1\u3063\u3068\u3057\u3066\u3093\u3058\u3083\u3093\u3063\uFF01",
  "id" : 115031563443507200,
  "in_reply_to_status_id" : 115031319263719424,
  "created_at" : "2011-09-17 11:57:16 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115031373093412866",
  "text" : "\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u306E\u30A2\u30A4\u30B3\u30F3\u304C\u300C\u3048\u300D\u3060\u3063\u305F\u3089\u3059\u3054\u304F\u30B7\u30E5\u30FC\u30EB\u306A\uFF34\uFF2C\u306B\u306A\u3063\u3066\u3044\u305F\u3053\u3068\u3060\u308D\u3046\u3002",
  "id" : 115031373093412866,
  "created_at" : "2011-09-17 11:56:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115029962733518848",
  "text" : "\u3066\u304B\u666E\u6BB5\uFF34\uFF2C\u3068\u306F\u5225\u306B\u307F\u3066\u308B2\u3064\u306E\u30EA\u30B9\u30C8\u306E\u4E21\u65B9\u306B\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u304C\u3044\u308B\u305B\u3044\u3067\u300C\u3086\u300D\u304C\u30B2\u30B7\u30E5\u30BF\u30EB\u30C8\u5D29\u58CA\u3059\u308B\u30EC\u30D9\u30EB",
  "id" : 115029962733518848,
  "created_at" : "2011-09-17 11:50:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/VDD5iT4a",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115027726229970945",
  "text" : "\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3067\u300Cend313124\u3055\u3093\u300D\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3059\u308B #theinterviews http:\/\/t.co\/VDD5iT4a \u805E\u304B\u308C\u305F\u3089\u7B54\u3048\u307E\u3059\u3002",
  "id" : 115027726229970945,
  "created_at" : "2011-09-17 11:42:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E7C\u5973",
      "screen_name" : "you_jo_ko",
      "indices" : [ 3, 13 ],
      "id_str" : "2340800905",
      "id" : 2340800905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115027448793542656",
  "text" : "RT @you_jo_ko: \u6211\u3053\u305D\u306F\u7570\u6559\u5F92\u300C\u3066\u6559\u300D\u3067\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115026654161674240",
    "text" : "\u6211\u3053\u305D\u306F\u7570\u6559\u5F92\u300C\u3066\u6559\u300D\u3067\u3042\u308B",
    "id" : 115026654161674240,
    "created_at" : "2011-09-17 11:37:46 +0000",
    "user" : {
      "name" : "\u30CC\u30DE\u3055\u3093",
      "screen_name" : "ohnumaman",
      "protected" : false,
      "id_str" : "206035790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549238809947168768\/YzlxblBY_normal.png",
      "id" : 206035790,
      "verified" : false
    }
  },
  "id" : 115027448793542656,
  "created_at" : "2011-09-17 11:40:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/kZHz1D7n",
      "expanded_url" : "http:\/\/shindanmaker.com\/137060",
      "display_url" : "shindanmaker.com\/137060"
    } ]
  },
  "geo" : { },
  "id_str" : "115027386315194368",
  "text" : "\u300C\u3000end33124\u3000\u304C\u3000\u7D20\u3000\u6575\u3000\u3060\u3000\u3068\u3000\u601D\u3000\u3046\u3000\u4EBA\u3000\u306F\u3000R\u3000T\u3000\u300D http:\/\/t.co\/kZHz1D7n  \u7D20\u3067\u6575\uFF1F",
  "id" : 115027386315194368,
  "created_at" : "2011-09-17 11:40:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3080\u304B\u3057\u306E\u3071\u305F\u3068\u307E",
      "screen_name" : "ttmtooao",
      "indices" : [ 3, 12 ],
      "id_str" : "442798981",
      "id" : 442798981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115025261237506048",
  "text" : "RT @ttmtooao: \u5973\u306E\u5B50\u300C\u305A\u3063\u3068\u3044\u3063\u3057\u3087\u3060\u3088\u2026\n\u7537\u306E\u5B50\u300C\u3086\u3073\u304D\u308A\u3052\u3093\u307E\u3093\u3046\u305D\u3064\u3044\u305F\u3089\u306F\u308A\u305B\u3093\u307C\u3093\u306E\u30FC\u307E\u3059\u3000\u3086\u3073\u304D\u3063\u305F\n\u534A\u5E74\u5F8C\n\u5973\u306E\u5B50\u300C\u304D\u307F\u306E\u3053\u3068\u304D\u3089\u3044\uFF01\n\u7537\u306E\u5B50\u300C\u3046\u305D\u3064\u304D\uFF01\n\u5973\u306E\u5B50\u300C\u6307\u5207\u308A\u306F\u672C\u6765\u58F2\u6625\u5A66\u3068\u5951\u7D04\u3059\u308B\u70BA\u306B\u7528\u3044\u3089\u308C\u308B\u884C\u70BA\u3067\u3042\u308A\u3001\u597D\u610F\u3092\u79F0\u3059\u5951\u7D04\u306B\u306A\u3058\u307E\u306A\u3044 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115020988101574657",
    "text" : "\u5973\u306E\u5B50\u300C\u305A\u3063\u3068\u3044\u3063\u3057\u3087\u3060\u3088\u2026\n\u7537\u306E\u5B50\u300C\u3086\u3073\u304D\u308A\u3052\u3093\u307E\u3093\u3046\u305D\u3064\u3044\u305F\u3089\u306F\u308A\u305B\u3093\u307C\u3093\u306E\u30FC\u307E\u3059\u3000\u3086\u3073\u304D\u3063\u305F\n\u534A\u5E74\u5F8C\n\u5973\u306E\u5B50\u300C\u304D\u307F\u306E\u3053\u3068\u304D\u3089\u3044\uFF01\n\u7537\u306E\u5B50\u300C\u3046\u305D\u3064\u304D\uFF01\n\u5973\u306E\u5B50\u300C\u6307\u5207\u308A\u306F\u672C\u6765\u58F2\u6625\u5A66\u3068\u5951\u7D04\u3059\u308B\u70BA\u306B\u7528\u3044\u3089\u308C\u308B\u884C\u70BA\u3067\u3042\u308A\u3001\u597D\u610F\u3092\u79F0\u3059\u5951\u7D04\u306B\u306A\u3058\u307E\u306A\u3044\u3002\u6545\u306B\u53F3\u5951\u7D04\u306F\u7121\u52B9\u3067\u3042\u308B\n\u7537\u306E\u5B50\u300C\u300D",
    "id" : 115020988101574657,
    "created_at" : "2011-09-17 11:15:15 +0000",
    "user" : {
      "name" : "\u304D\u3083\u3079\u3064\u3071\u305F\u3071\u305F\u3068\u307E\u3068\u305F\u3093",
      "screen_name" : "patatoma",
      "protected" : false,
      "id_str" : "116668150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603558940975071232\/Wi5lag2V_normal.png",
      "id" : 116668150,
      "verified" : false
    }
  },
  "id" : 115025261237506048,
  "created_at" : "2011-09-17 11:32:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115022887676674048",
  "text" : "\u3042\u3001\u3044\u3044\u611F\u3058\u306B\u7720\u3044\u3002",
  "id" : 115022887676674048,
  "created_at" : "2011-09-17 11:22:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115008204043333632",
  "text" : "\u306F\u306A\u304Dbot\u304C\u81EA\u79F0\u30D1\u30EF\u30FC\u30B9\u30C8\u30FC\u30F3\u597D\u304D\u306E\u4EBA\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u3066\u58F0\u51FA\u3057\u3066\u7B11\u3063\u3066\u3057\u307E\u3063\u305F\u305C\uFF57",
  "id" : 115008204043333632,
  "created_at" : "2011-09-17 10:24:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115000858407747584",
  "text" : "\u51C4\u3044\u96E8",
  "id" : 115000858407747584,
  "created_at" : "2011-09-17 09:55:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114960691751952384",
  "text" : "\u725B\u4E73\u98F2\u3080\u3068\u7720\u304F\u306A\u308B\u306E\u3063\u3066\u81EA\u5206\u3060\u3051\u304B\u306A\u3002\u89E3\u3063\u3066\u3066\u3082\u98F2\u3093\u3058\u3083\u3046\u3093\u3060\u3051\u3069\u3055\uFF57",
  "id" : 114960691751952384,
  "created_at" : "2011-09-17 07:15:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "indices" : [ 3, 10 ],
      "id_str" : "15570902",
      "id" : 15570902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114960188901048320",
  "text" : "RT @m_soba: \u301010\u56DE\u30AF\u30A4\u30BA\u3092\u5404\u770C\u6C11\u304C\u3084\u3063\u305F\u3089\u3011\n\u6771\u4EAC\u300C\u30D4\u30B6\u3063\u306610\u56DE\u8A00\u3063\u3066\u300D\u3000\n\u7FA4\u99AC\u300C\u0628\u064A\u062A\u0632\u0627\u0628\u064A\u062A\u0632\u0627\u0628\u064A\u062A\u0632\u0627\u300D\u3000\n\u6771\u4EAC\u300C\u4F55\u8A9E\u3060\u3088\uFF01\u3000\u307E\u3042\u3044\u3044\u3084\u3001\u3053\u308C\u306F\uFF1F\u300D\u3000\n\u9752\u68EE\u300C\u3072\uFF9D\u305A\u300D\u3000\n\u6771\u4EAC\u300C\u8A1B\u308A\u3059\u304E\u3066\u3069\u3063\u3061\u304B\u5206\u304B\u3093\u306A\u3044\u3088\uFF01\u300D\u3000\n\u9999\u5DDD\u300C\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u300D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114684533810536448",
    "text" : "\u301010\u56DE\u30AF\u30A4\u30BA\u3092\u5404\u770C\u6C11\u304C\u3084\u3063\u305F\u3089\u3011\n\u6771\u4EAC\u300C\u30D4\u30B6\u3063\u306610\u56DE\u8A00\u3063\u3066\u300D\u3000\n\u7FA4\u99AC\u300C\u0628\u064A\u062A\u0632\u0627\u0628\u064A\u062A\u0632\u0627\u0628\u064A\u062A\u0632\u0627\u300D\u3000\n\u6771\u4EAC\u300C\u4F55\u8A9E\u3060\u3088\uFF01\u3000\u307E\u3042\u3044\u3044\u3084\u3001\u3053\u308C\u306F\uFF1F\u300D\u3000\n\u9752\u68EE\u300C\u3072\uFF9D\u305A\u300D\u3000\n\u6771\u4EAC\u300C\u8A1B\u308A\u3059\u304E\u3066\u3069\u3063\u3061\u304B\u5206\u304B\u3093\u306A\u3044\u3088\uFF01\u300D\u3000\n\u9999\u5DDD\u300C\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u300D\u3000\n\u6771\u4EAC\u300C\u304A\u524D\u306F\u30EB\u30FC\u30EB\u5B88\u308C\u3088\uFF01\u300D",
    "id" : 114684533810536448,
    "created_at" : "2011-09-16 12:58:18 +0000",
    "user" : {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "protected" : false,
      "id_str" : "15570902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484672991460982784\/o-QnjXOh_normal.png",
      "id" : 15570902,
      "verified" : false
    }
  },
  "id" : 114960188901048320,
  "created_at" : "2011-09-17 07:13:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114943062320480256",
  "text" : "\u5FAE\u5C0F\u5FAE\u5C0F\u306B\u306A\u3063\u305F\u3002",
  "id" : 114943062320480256,
  "created_at" : "2011-09-17 06:05:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 10, 19 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114940854237544449",
  "geo" : { },
  "id_str" : "114942958435975168",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa @koketomi \u6551\u4E16\u4E3B\u3042\u3089\u308F\u308B\u3002\u6025\u901D\u3059\u308B\u3068\u3053\u308D\u3060\u3063\u305F\u3002",
  "id" : 114942958435975168,
  "in_reply_to_status_id" : 114940854237544449,
  "created_at" : "2011-09-17 06:05:11 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114938215793836033",
  "text" : "@koketomi \u3080\u3054\u3093\u308A\u3077\u3089\u3044\u3053\u308F\u3044 \u3084\u3081\u3066",
  "id" : 114938215793836033,
  "created_at" : "2011-09-17 05:46:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 29, 38 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114936926930354176",
  "text" : "\u30A4\u30E4\u30DB\u30F3\u300C\u30A4\u30E4\uFF01\u30DB\u30F3\u30C8\u306F\u3042\u308B\u3082\u3093\uFF01\u3088\u304F\u63A2\u3057\u3066\u3088\uFF01\u300D RT @koketomi: \u30A4\u30E4\u30DB\u30F3\u304C\u3001\u306A\u3044",
  "id" : 114936926930354176,
  "created_at" : "2011-09-17 05:41:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114936695492837376",
  "text" : "\u5317\u5927\u8DEFVIVRE\u306B\u9589\u3058\u8FBC\u3081\u3089\u308C\u305Forz",
  "id" : 114936695492837376,
  "created_at" : "2011-09-17 05:40:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114936067756539905",
  "text" : "\u3080\u30FC\u3001\u30B9\u30FC\u30C4\u7740\u308B\u3068\u96E8\u964D\u308B\u30B8\u30F3\u30AF\u30B9",
  "id" : 114936067756539905,
  "created_at" : "2011-09-17 05:37:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114931231073906688",
  "text" : "\u5317\u5927\u8DEF\u306B\u30DF\u30B9\u30C9\u3042\u3063\u305F\u3088\u306A\u3041\u2026\u3044\u3084\u3001\u5BC4\u3089\u306A\u3044\u3051\u3069\u3055\u3063\uFF01",
  "id" : 114931231073906688,
  "created_at" : "2011-09-17 05:18:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B7\u30E3\u30FC\u30ED\u30C3\u30AF\u30FB\u30B7\u30A7\u30EA\u30F3\u30D5\u30A9\u30FC\u30C9",
      "screen_name" : "sharo_bot",
      "indices" : [ 0, 10 ],
      "id_str" : "216702459",
      "id" : 216702459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114930391542009856",
  "geo" : { },
  "id_str" : "114930738645827584",
  "in_reply_to_user_id" : 216702459,
  "text" : "@sharo_bot \u307E\u3060\u3060\u3088\u3001\u30B7\u30E3\u30ED",
  "id" : 114930738645827584,
  "in_reply_to_status_id" : 114930391542009856,
  "created_at" : "2011-09-17 05:16:38 +0000",
  "in_reply_to_screen_name" : "sharo_bot",
  "in_reply_to_user_id_str" : "216702459",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114930419807424512",
  "text" : "\u7518\u3044\u3082\u306E\u306F\u6211\u6162\u3063",
  "id" : 114930419807424512,
  "created_at" : "2011-09-17 05:15:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114930337171243008",
  "text" : "\u5BB6\u3060\u3068\u98DF\u4E8B\u304C\u9069\u5F53\u306B\u306A\u308B\u5272\u306B\u5916\u98DF\u3059\u308B\u3068\u7518\u3044\u3082\u306E\u3068\u82E6\u3044\u3082\u306E\u304C\u6B32\u3057\u304F\u306A\u308B\u306A\u3041\u3002\u5E30\u5B85\u3057\u305F\u3089\u73C8\u7432\u714E\u308C\u3088\u3046\u3002",
  "id" : 114930337171243008,
  "created_at" : "2011-09-17 05:15:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114929818633637888",
  "text" : "\u4E00\u99C5\u6B69\u3044\u3066\u70CF\u4E38\u7DDA\u3002\u4EAC\u90FD\u306F\u659C\u3081\u79FB\u52D5\u304C\u3067\u304D\u306A\u3044\u3088\u306A\u30FC\u3002\u305D\u306E\u5206\u8FF7\u3044\u306B\u304F\u3044\u3051\u3069\u3002",
  "id" : 114929818633637888,
  "created_at" : "2011-09-17 05:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114929329691049984",
  "text" : "\u3061\u3087\u3063\u3068\u3057\u3087\u3063\u3071\u304B\u3063\u305F\u304B\u306A\u3002\u3042\u3068\u3068\u308D\u308D\u5C11\u306A\u304B\u3063\u305F\u3002\u3084\u3063\u3071\u6771\u4EAC\u5E30\u3063\u305F\u3089\u306D\u304E\u3057\u306B\u884C\u3053\u3046\u3002",
  "id" : 114929329691049984,
  "created_at" : "2011-09-17 05:11:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114740224613040130",
  "geo" : { },
  "id_str" : "114921442231058432",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4ECA\u66F4\u304A\u3084\u3042\u308A\u3067\u3057\u305F\u3002",
  "id" : 114921442231058432,
  "in_reply_to_status_id" : 114740224613040130,
  "created_at" : "2011-09-17 04:39:41 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114921298383224832",
  "text" : "\u5F85\u671B\uFF08\uFF1F\uFF09\u306E\u9EA6\u3068\u308D\u3054\u306F\u3093\u3063\uFF01\u51FA\u304B\u3051\u305F\u3064\u3044\u3067\uFF67\uFF01",
  "id" : 114921298383224832,
  "created_at" : "2011-09-17 04:39:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114740185819914243",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 114740185819914243,
  "created_at" : "2011-09-16 16:39:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 16, 24 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114738891034083328",
  "text" : "\u3042\u308C\uFF1F\u4FFA\u307F\u305F\u3044\u306A\u4EBA\u304C\u3044\u308B RT @i_horse: \u975E\u60F3\u5929\u5247\u306F\u30BB\u30F3\u30BF\u30FC\u304C\u7D42\u308F\u3063\u3066\u4E8C\u6B21\u8A66\u9A13\u307E\u3067\u53CB\u9054\u3068\u30B9\u30AB\u30A4\u30D7\u3084\u308A\u306A\u304C\u3089\u306F\u307E\u3063\u3066\u307E\u3057\u305F\u30FB\u30FB\u30FB",
  "id" : 114738891034083328,
  "created_at" : "2011-09-16 16:34:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/33ADuu04",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=dosannpinn",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114734742800302080",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001dosannpinn\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/33ADuu04",
  "id" : 114734742800302080,
  "created_at" : "2011-09-16 16:17:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114658571043614721",
  "text" : "@koketomi \u305D\u306E\u8DDD\u96E2\u306F\u65E5\u5E30\u308A\u3084\u3089\u77ED\u671F\u306E\u5E30\u7701\u304C\u3067\u304D\u3066\u7FA8\u307E\u3057\u3044\u308F\uFF57\n\u307E\u3041\u6C17\u3092\u4ED8\u3051\u3066\u3002",
  "id" : 114658571043614721,
  "created_at" : "2011-09-16 11:15:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114657342209003520",
  "text" : "@koketomi \u5C71\u7530\u884C\u304F\u3068\u304B\uFF1F",
  "id" : 114657342209003520,
  "created_at" : "2011-09-16 11:10:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "sm15576594",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/PUPq4Wml",
      "expanded_url" : "http:\/\/nico.ms\/sm15576594",
      "display_url" : "nico.ms\/sm15576594"
    } ]
  },
  "geo" : { },
  "id_str" : "114645969869606913",
  "text" : "\u3069\u308C\u3082\u3053\u308C\u3082\u7406\u89E3\u3067\u304D\u306A\u3055\u3059\u304E\u3066\u7B11\u3063\u3066\u3057\u307E\u3063\u305F\u3002 \u4EBA\u985E\u306B\u306F\u65E9\u3059\u304E\u308B\u30E9\u30F3\u30AD\u30F3\u30B0\uFF5E21st\u30B7\u30FC\u30BA\u30F3\uFF5E (10:48) #nicovideo #sm15576594 http:\/\/t.co\/PUPq4Wml",
  "id" : 114645969869606913,
  "created_at" : "2011-09-16 10:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4\u516C\u4E00\uFF08\u306F\u3080\u304B\u305Aa.k.a.\u306F\u3080\u306F\u3080\uFF09",
      "screen_name" : "hamukazu",
      "indices" : [ 3, 12 ],
      "id_str" : "60320929",
      "id" : 60320929
    }, {
      "name" : "\u3056\u3093",
      "screen_name" : "zhanpon",
      "indices" : [ 21, 29 ],
      "id_str" : "118228689",
      "id" : 118228689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114641730216804352",
  "text" : "RT @hamukazu: \u697D\u3057\u3080\u3002RT @zhanpon: \u6709\u52B9\u306A\u6570\u5B66\u306E\u52C9\u5F37\u6CD5\uFF1ATwitter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3056\u3093",
        "screen_name" : "zhanpon",
        "indices" : [ 7, 15 ],
        "id_str" : "118228689",
        "id" : 118228689
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114639711779299328",
    "text" : "\u697D\u3057\u3080\u3002RT @zhanpon: \u6709\u52B9\u306A\u6570\u5B66\u306E\u52C9\u5F37\u6CD5\uFF1ATwitter",
    "id" : 114639711779299328,
    "created_at" : "2011-09-16 10:00:11 +0000",
    "user" : {
      "name" : "\u52A0\u85E4\u516C\u4E00\uFF08\u306F\u3080\u304B\u305Aa.k.a.\u306F\u3080\u306F\u3080\uFF09",
      "screen_name" : "hamukazu",
      "protected" : false,
      "id_str" : "60320929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533223073760034816\/vo0U1Dtg_normal.jpeg",
      "id" : 60320929,
      "verified" : false
    }
  },
  "id" : 114641730216804352,
  "created_at" : "2011-09-16 10:08:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114641209196163072",
  "text" : "\u897F\u5C3E\u7DAD\u65B0\u306E\u5C11\u5973\u4E0D\u5341\u5206\u8AAD\u307F\u7D42\u3048\u3066\u305F\u3051\u3069\u9762\u767D\u304B\u3063\u305F\u3002\u4F5C\u98A8\u306F\u9055\u3063\u3061\u3083\u3063\u305F\u3051\u3069\u3001\u3042\u308C\u306F\u3042\u308C\u3067\u3002\u3069\u3053\u307E\u3067\u5B9F\u8A71\u306A\u3093\u3060\u308D\u3046\u3002\u4E00\u5FDC\u5B9F\u8A71\u306E\u4F53\u3092\u53D6\u3063\u3066\u3044\u308B\u3051\u308C\u3069\u3002",
  "id" : 114641209196163072,
  "created_at" : "2011-09-16 10:06:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114638558932905984",
  "text" : "\u306A\u3093\u3068\u306A\u30FC\u304F\u30D5\u30A9\u30ED\u30FC\u6570\u3068\u3075\u3041\u307C\u306E\u6570\u3092\u540C\u3058\u304F\u3089\u3044\u306B\u3057\u3066\u304A\u304D\u305F\u3044\u5F37\u8FEB\u89B3\u5FF5",
  "id" : 114638558932905984,
  "created_at" : "2011-09-16 09:55:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308A\u3058\u3047\u304F\u305F\u30FC",
      "screen_name" : "Rejecter92",
      "indices" : [ 3, 14 ],
      "id_str" : "82297557",
      "id" : 82297557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114637813244379136",
  "text" : "RT @Rejecter92: \u300C\u30AA\u30A4\u30E9\u30FC\u6CD5\u3067\u3059\u300D\u300C\u30C6\u30A4\u30E9\u30FC\u65B9\u3067\u3059\u300D\u300C\u30EB\u30F3\u30B2\u30FB\u30AF\u30C3\u30BF\u6CD5\u3067\u3059\u300D\u300C\u51FA\u305F\u306A\u5DEE\u5206\u4E09\u5144\u5F1F\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114632859708440576",
    "text" : "\u300C\u30AA\u30A4\u30E9\u30FC\u6CD5\u3067\u3059\u300D\u300C\u30C6\u30A4\u30E9\u30FC\u65B9\u3067\u3059\u300D\u300C\u30EB\u30F3\u30B2\u30FB\u30AF\u30C3\u30BF\u6CD5\u3067\u3059\u300D\u300C\u51FA\u305F\u306A\u5DEE\u5206\u4E09\u5144\u5F1F\u300D",
    "id" : 114632859708440576,
    "created_at" : "2011-09-16 09:32:58 +0000",
    "user" : {
      "name" : "\u308A\u3058\u3047\u304F\u305F\u30FC",
      "screen_name" : "Rejecter92",
      "protected" : false,
      "id_str" : "82297557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000127649883\/cfafc9439347c823974a788273006006_normal.jpeg",
      "id" : 82297557,
      "verified" : false
    }
  },
  "id" : 114637813244379136,
  "created_at" : "2011-09-16 09:52:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "indices" : [ 3, 18 ],
      "id_str" : "158991353",
      "id" : 158991353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114637777718620161",
  "text" : "RT @sorayama_asobi: \u6BCD\u89AA\u306B\u300C\u79C1\u306E\u51FA\u304B\u3051\u3066\u308B\u9593\u306B\u63DB\u6C17\u6247\u307E\u308F\u3057\u3057\u3068\u3044\u3066\u306D\u300D\u3063\u3066\u8A00\u308F\u308C\u305F\u306E\u3067\u3001\u3068\u308A\u3042\u3048\u305A\u5BB6\u4E2D\u306E\u63DB\u6C17\u6247\u3092\u56DE\u3057\u3066\u3044\u308B\u3051\u3069\u3001\u3082\u3057\u304B\u3057\u3066\u4E7E\u71E5\u6A5F\u306E\u8A00\u3044\u9593\u9055\u3044\u3058\u3083\u306A\u3044\u306E\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.docodemo.jp\/twil\/\" rel=\"nofollow\"\u003ETwil2 (Tweet Anytime, Anywhere by Mail)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114632393343766528",
    "text" : "\u6BCD\u89AA\u306B\u300C\u79C1\u306E\u51FA\u304B\u3051\u3066\u308B\u9593\u306B\u63DB\u6C17\u6247\u307E\u308F\u3057\u3057\u3068\u3044\u3066\u306D\u300D\u3063\u3066\u8A00\u308F\u308C\u305F\u306E\u3067\u3001\u3068\u308A\u3042\u3048\u305A\u5BB6\u4E2D\u306E\u63DB\u6C17\u6247\u3092\u56DE\u3057\u3066\u3044\u308B\u3051\u3069\u3001\u3082\u3057\u304B\u3057\u3066\u4E7E\u71E5\u6A5F\u306E\u8A00\u3044\u9593\u9055\u3044\u3058\u3083\u306A\u3044\u306E\u304B",
    "id" : 114632393343766528,
    "created_at" : "2011-09-16 09:31:06 +0000",
    "user" : {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "protected" : false,
      "id_str" : "158991353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1864231491\/totoro_t_normal.jpg",
      "id" : 158991353,
      "verified" : false
    }
  },
  "id" : 114637777718620161,
  "created_at" : "2011-09-16 09:52:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 16, 27 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 38, 47 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114637417729900544",
  "text" : "\u305B\u304D\u3076\u3093\u5B66\u90E8\u304C\u901A\u308A\u307E\u3059\u3088 RT @magokoro84 \u4EAC\u5927\u546A\u6587\u5B66\u90E8 RT @hanaoka_: \u7406\u56DB\u6587\u96F6\u4EAC\u5927\u9B54\u6CD5\u5B66\u90E8\u306B\u4EE3\u308F\u308B\u65B0\u3057\u3044\u4F55\u304B\u7121\u3044\u306E",
  "id" : 114637417729900544,
  "created_at" : "2011-09-16 09:51:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114637120689278976",
  "text" : "\u306B\u305B\u307B\u9B3C\u3060\u308D\uFF57\u9762\u767D\u3044\u3051\u3069\uFF57",
  "id" : 114637120689278976,
  "created_at" : "2011-09-16 09:49:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 3, 14 ],
      "id_str" : "229752118",
      "id" : 229752118
    }, {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 16, 25 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114637067400642560",
  "text" : "RT @nisehorrrn: @nartakio \u304F\u3055\u3044\u304B\u3089\u3084\u3081\u3066",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nartakio",
        "screen_name" : "nartakio",
        "indices" : [ 0, 9 ],
        "id_str" : "612419223",
        "id" : 612419223
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114636710226305024",
    "text" : "@nartakio \u304F\u3055\u3044\u304B\u3089\u3084\u3081\u3066",
    "id" : 114636710226305024,
    "created_at" : "2011-09-16 09:48:16 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "protected" : false,
      "id_str" : "229752118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009819094\/110325_010601a_normal.jpg",
      "id" : 229752118,
      "verified" : false
    }
  },
  "id" : 114637067400642560,
  "created_at" : "2011-09-16 09:49:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E00\u756A\u3084\u3070\u3044\u30DA\u30D7\u30B7\u8003\u3048\u305F\u5974\u304C\u512A\u52DD",
      "indices" : [ 9, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114636852803284992",
  "text" : "\u6C17\u306E\u629C\u3051\u305F\u30DA\u30D7\u30B7\u3000#\u4E00\u756A\u3084\u3070\u3044\u30DA\u30D7\u30B7\u8003\u3048\u305F\u5974\u304C\u512A\u52DD",
  "id" : 114636852803284992,
  "created_at" : "2011-09-16 09:48:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4FDD\u7BA1\u5EAB\u7BA1\u7406\u4EBA",
      "screen_name" : "takinoura",
      "indices" : [ 3, 13 ],
      "id_str" : "47642720",
      "id" : 47642720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114630627923468288",
  "text" : "RT @takinoura: \u300C\u306A\u305C\u65E5\u672C\u4EBA\u306F\u30CD\u30C3\u30C8\u3067\u507D\u540D\u3092\u4F7F\u3046\u4EBA\u304C\u307B\u3068\u3093\u3069\u306A\u306E\u3067\u3059\u304B\uFF1F\u300D\u300C\u305D\u308C\u306F\u5F7C\u3089\u304C\u5FCD\u8005\u306E\u5B50\u5B6B\u3060\u304B\u3089\u3067\u3059\u3002\u300D\u300C\u3067\u306F\u672C\u540D\u3067\u30CD\u30C3\u30C8\u3092\u3084\u3063\u3066\u3044\u308B\u4EBA\u305F\u3061\u306F\u30B5\u30E0\u30E9\u30A4\u306E\u5B50\u5B6B\u306A\u306E\u3067\u3059\u304B\uFF1F\u300D\u300C\u306F\u3044\u3001\u305D\u306E\u3068\u304A\u308A\u3067\u3059\u3002\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114321713851932672",
    "text" : "\u300C\u306A\u305C\u65E5\u672C\u4EBA\u306F\u30CD\u30C3\u30C8\u3067\u507D\u540D\u3092\u4F7F\u3046\u4EBA\u304C\u307B\u3068\u3093\u3069\u306A\u306E\u3067\u3059\u304B\uFF1F\u300D\u300C\u305D\u308C\u306F\u5F7C\u3089\u304C\u5FCD\u8005\u306E\u5B50\u5B6B\u3060\u304B\u3089\u3067\u3059\u3002\u300D\u300C\u3067\u306F\u672C\u540D\u3067\u30CD\u30C3\u30C8\u3092\u3084\u3063\u3066\u3044\u308B\u4EBA\u305F\u3061\u306F\u30B5\u30E0\u30E9\u30A4\u306E\u5B50\u5B6B\u306A\u306E\u3067\u3059\u304B\uFF1F\u300D\u300C\u306F\u3044\u3001\u305D\u306E\u3068\u304A\u308A\u3067\u3059\u3002\u300D",
    "id" : 114321713851932672,
    "created_at" : "2011-09-15 12:56:35 +0000",
    "user" : {
      "name" : "\u4FDD\u7BA1\u5EAB\u7BA1\u7406\u4EBA",
      "screen_name" : "takinoura",
      "protected" : false,
      "id_str" : "47642720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2495589047\/886ckqyo0f8vdylnrqge_normal.jpeg",
      "id" : 47642720,
      "verified" : false
    }
  },
  "id" : 114630627923468288,
  "created_at" : "2011-09-16 09:24:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3053\u306B\u3083",
      "screen_name" : "rmn_w",
      "indices" : [ 3, 9 ],
      "id_str" : "105715814",
      "id" : 105715814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114606429872209921",
  "text" : "RT @rmn_w: \u30EA\u30FC\u30DE\u30F3\u9762&gt;&gt;&gt;&gt;(\u8D8A\u3048\u3089\u308C\u306A\u3044\u58C1)&gt;&gt;&gt;&gt;\u30A4\u30B1\u30E1\u30F3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114603647928774656",
    "text" : "\u30EA\u30FC\u30DE\u30F3\u9762&gt;&gt;&gt;&gt;(\u8D8A\u3048\u3089\u308C\u306A\u3044\u58C1)&gt;&gt;&gt;&gt;\u30A4\u30B1\u30E1\u30F3",
    "id" : 114603647928774656,
    "created_at" : "2011-09-16 07:36:53 +0000",
    "user" : {
      "name" : "\u3082\u3053\u306B\u3083",
      "screen_name" : "rmn_w",
      "protected" : false,
      "id_str" : "105715814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603869863874965504\/1nH7nacE_normal.jpg",
      "id" : 105715814,
      "verified" : false
    }
  },
  "id" : 114606429872209921,
  "created_at" : "2011-09-16 07:47:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114606388818358272",
  "text" : "\u672C\u68DA\u7D44\u307F\u7ACB\u3066\u7D42\u308F\u3063\u305F\u3002\u3042\u30FC\u8089\u4F53\u52B4\u50CD\u306F\u5411\u3044\u3066\u3044\u306A\u3044\u306E\u3067\u3059\u3002",
  "id" : 114606388818358272,
  "created_at" : "2011-09-16 07:47:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 3, 10 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114605678655582208",
  "text" : "RT @rpdexp: \u3069\u3070\u306B\u3083\u3093\u306B\u306F\u653F\u6CBB\u304C\u308F\u304B\u3089\u306C\u3002\u3069\u3070\u306B\u3083\u3093\u306F\uFF0CKU\u306E\u3064\u3044\u3063\u305F\u3089\u30FC\u3067\u3042\u308B\u3002\u6CD5\u3092\u5B66\u3073\uFF0C\u5C71\u7F8A\u3068\u904A\u3093\u3067\u66AE\u3057\u3066\u6765\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114597924784189441",
    "text" : "\u3069\u3070\u306B\u3083\u3093\u306B\u306F\u653F\u6CBB\u304C\u308F\u304B\u3089\u306C\u3002\u3069\u3070\u306B\u3083\u3093\u306F\uFF0CKU\u306E\u3064\u3044\u3063\u305F\u3089\u30FC\u3067\u3042\u308B\u3002\u6CD5\u3092\u5B66\u3073\uFF0C\u5C71\u7F8A\u3068\u904A\u3093\u3067\u66AE\u3057\u3066\u6765\u305F\u3002",
    "id" : 114597924784189441,
    "created_at" : "2011-09-16 07:14:09 +0000",
    "user" : {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "protected" : false,
      "id_str" : "141811283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583276832234999810\/sa3_ZPQ4_normal.jpg",
      "id" : 141811283,
      "verified" : false
    }
  },
  "id" : 114605678655582208,
  "created_at" : "2011-09-16 07:44:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114528735339888640",
  "text" : "\u304D\u3063\u3068\u81EA\u5206\u306B\u306F\u7A4D\u6975\u6027\u304C\u8DB3\u308A\u306A\u3044\u3093\u3060\u308D\u3046\u306A\u3002\u30D5\u30A9\u30ED\u30EF\u30FC\u5897\u3048\u3066\u3082\u30EA\u30D7\u30E9\u30A4\u306E\u91CF\u304C\u5897\u3048\u306A\u3044\u306E\u306F\u305D\u3046\u3044\u3046\u3053\u3068\u3060\u308D\u3046\u3002\n\u307E\u3041\u3001\u99B4\u308C\u5408\u3044\uFF01\u307F\u305F\u3044\u306A\u306E\u3042\u3093\u307E\u308A\u597D\u304D\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u3069\u3002\u305F\u3060\u305B\u3063\u304B\u304F\u76F8\u4E92\u30D5\u30A9\u30ED\u30FC\u306A\u306E\u306B\u7D61\u307F\u304C\u5C11\u306A\u3044\u6C17\u3082\u3059\u308B\u3002",
  "id" : 114528735339888640,
  "created_at" : "2011-09-16 02:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/VDD5iT4a",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114526961111543808",
  "text" : "\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3067\u300Cend313124\u3055\u3093\u300D\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3059\u308B #theinterviews http:\/\/t.co\/VDD5iT4a",
  "id" : 114526961111543808,
  "created_at" : "2011-09-16 02:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 1, 11 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MachiTwi",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/gj3mAkox",
      "expanded_url" : "http:\/\/machi.userlocal.jp\/map\/end313124\/",
      "display_url" : "machi.userlocal.jp\/map\/end313124\/"
    } ]
  },
  "geo" : { },
  "id_str" : "114526195575562240",
  "text" : ".@end313124 \u306F\u3001 18\u90FD\u9053\u5E9C\u770C\u300117\u5E02\u533A\u90E1\u306ETwitter\u30E6\u30FC\u30B6\u30FC\u3068\u4EA4\u6D41\u3057\u3066\u3044\u307E\u3059\u3002 http:\/\/t.co\/gj3mAkox #MachiTwi \u6B8B\u308A29\u30A8\u30EA\u30A2",
  "id" : 114526195575562240,
  "created_at" : "2011-09-16 02:29:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114524880292155392",
  "text" : "\u672C\u68DA\u3068\u5EA6\u3057\u305F\u4ED5\u7D44\u307F\u7ACB\u3066\u3088\u3046\u3068\u601D\u3063\u305F\u3089\u30C9\u30E9\u30A4\u30D0\u8981\u308B\u306E\u304B\u3088\u3045\u3002\u8CB7\u3044\u306B\u3044\u304B\u306A\u3044\u3068\u7121\u3044\u3002\u3002\u3002",
  "id" : 114524880292155392,
  "created_at" : "2011-09-16 02:23:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114523586848505856",
  "text" : "\u30B7\u30E3\u30D5\u30C8\u304C\u30AA\u30FC\u30D0\u30FC\u30EF\u30FC\u30AF\u3058\u3083\u306A\u3044\u304B\u5FC3\u914D\u3060\u3002\u305D\u3057\u3066\u5FCD\u3061\u3083\u3093\u306E\u4E2D\u306E\u4EBA\u306F\u3069\u3046\u306A\u308B\u306E\uFF1F\u50B7\u3088\u308A\u507D\u306E\u304C\u65E9\u305D\u3046\u3060\u3057\u3002",
  "id" : 114523586848505856,
  "created_at" : "2011-09-16 02:18:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114523251203510272",
  "text" : "\u3057\u304B\u3057\u30BF\u30A4\u30E0\u30B7\u30D5\u30C8\u3067\u898B\u305F\u3051\u3069\u30CB\u30B3\u30CB\u30B3\u3067\u30A2\u30CB\u30E1\u306E\u65B0\u4F5C\u767A\u8868\u3068\u304B\u65B0\u3057\u3044\u3088\u306A\u30FC",
  "id" : 114523251203510272,
  "created_at" : "2011-09-16 02:17:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114523064498262018",
  "text" : "\u507D\u7269\u8A9E\u78BA\u5B9A\u3002\u5316\u7269\u8A9E\uFF22\uFF24\u306E\uFF22\uFF2F\uFF38\u3082\u78BA\u5B9A\u3002\u3093\u30FC\uFF22\uFF24\u306E\u8A2D\u5099\u3092\u53D6\u308A\u305D\u308D\u3048\u305F\u304F\u306A\u3063\u3066\u304D\u305F\u3002",
  "id" : 114523064498262018,
  "created_at" : "2011-09-16 02:16:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114368229387935746",
  "text" : "\u80A9\u51DD\u308A\u3001\u982D\u75DB\u3001\u4E0D\u52D5\u3001\u80A9\u51DD\u308A\u306E\u7121\u9650\u30EB\u30FC\u30D7",
  "id" : 114368229387935746,
  "created_at" : "2011-09-15 16:01:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114307767275241472",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 114307767275241472,
  "created_at" : "2011-09-15 12:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 55, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/VDD5iT4a",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114288917452304384",
  "text" : "\u805E\u304D\u305F\u3044\u3053\u3068\u3042\u3063\u305F\u308A\u306A\u304B\u3063\u305F\u308A\u3057\u305F\u3089\u3069\u3046\u305E \u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3067\u300Cend313124\u3055\u3093\u300D\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3059\u308B #theinterviews http:\/\/t.co\/VDD5iT4a",
  "id" : 114288917452304384,
  "created_at" : "2011-09-15 10:46:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114287912832598016",
  "text" : "\u30B8\u30EA\u8CA7\u3067\u3059\u3057\u304A\u3059\u3057",
  "id" : 114287912832598016,
  "created_at" : "2011-09-15 10:42:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114287849918046209",
  "text" : "\u30D0\u30A4\u30C8\u898B\u3064\u304B\u3089\u306A\u3044\u2026\u8AB0\u304B\u587E\u95A2\u9023\u7D39\u4ECB\u3057\u3066\u304F\u308C\u306A\u3044\u304B\u306A\u2190",
  "id" : 114287849918046209,
  "created_at" : "2011-09-15 10:42:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114277652248010752",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 114277652248010752,
  "created_at" : "2011-09-15 10:01:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u9762\u306D\u3053",
      "screen_name" : "2Dcat",
      "indices" : [ 3, 9 ],
      "id_str" : "145492904",
      "id" : 145492904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114263689187688448",
  "text" : "RT @2Dcat: \u300C\u7269\u7406\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\u306A\u306E\uFF01\uFF1F\u300D\u300C\u5358\u4F4D\u304C\u9055\u3046\u3002\u300D\n\u300C\u6570\u5B66\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\u306A\u306E\uFF01\uFF1F\u300D\u300C\u305D\u308C\u306Ftrivial\u3058\u3083\u306A\u3044\u3060\u308D\u3046\u304B\u3002\u300D\n\u300C\u60C5\u5831\u79D1\u5B66\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\uFF01\u306A\u306E\uFF1F\u300D\u300C\u578B\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093\u3002\u300D\n\u300C\u751F\u7269\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\u306A\u306E\uFF01\uFF1F\u300D\u300C\u3069\u3046\u9055\u3046\u306E\uFF1F\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58527881399246849",
    "text" : "\u300C\u7269\u7406\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\u306A\u306E\uFF01\uFF1F\u300D\u300C\u5358\u4F4D\u304C\u9055\u3046\u3002\u300D\n\u300C\u6570\u5B66\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\u306A\u306E\uFF01\uFF1F\u300D\u300C\u305D\u308C\u306Ftrivial\u3058\u3083\u306A\u3044\u3060\u308D\u3046\u304B\u3002\u300D\n\u300C\u60C5\u5831\u79D1\u5B66\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\uFF01\u306A\u306E\uFF1F\u300D\u300C\u578B\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093\u3002\u300D\n\u300C\u751F\u7269\u3068\u308F\u305F\u3057\u3069\u3063\u3061\u304C\u5927\u4E8B\u306A\u306E\uFF01\uFF1F\u300D\u300C\u3069\u3046\u9055\u3046\u306E\uFF1F\u300D",
    "id" : 58527881399246849,
    "created_at" : "2011-04-14 13:51:48 +0000",
    "user" : {
      "name" : "\u5E73\u9762\u306D\u3053",
      "screen_name" : "2Dcat",
      "protected" : false,
      "id_str" : "145492904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1536049354\/neko2_normal.gif",
      "id" : 145492904,
      "verified" : false
    }
  },
  "id" : 114263689187688448,
  "created_at" : "2011-09-15 09:06:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "indices" : [ 3, 15 ],
      "id_str" : "94825321",
      "id" : 94825321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114250487028649984",
  "text" : "RT @milkyholmes: \u300C\u3053\u306E\u30B7\u30E3\u30ED\u306E\u30BB\u30EA\u30D5\u2026\u2026\u982D\u826F\u3059\u304E\u3058\u3083\u306A\u3044\u3067\u3057\u3087\u3046\u304B\u300D\u3000\u2190\u76E3\u4FEE\u3067\u79C1\u304C\u6307\u6458\u3059\u308B\u70B9\u306E\u30C8\u30C3\u30D73\u306E\u3046\u3061\u306E1\u3064\u3089\u3057\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114244983061622784",
    "text" : "\u300C\u3053\u306E\u30B7\u30E3\u30ED\u306E\u30BB\u30EA\u30D5\u2026\u2026\u982D\u826F\u3059\u304E\u3058\u3083\u306A\u3044\u3067\u3057\u3087\u3046\u304B\u300D\u3000\u2190\u76E3\u4FEE\u3067\u79C1\u304C\u6307\u6458\u3059\u308B\u70B9\u306E\u30C8\u30C3\u30D73\u306E\u3046\u3061\u306E1\u3064\u3089\u3057\u3044",
    "id" : 114244983061622784,
    "created_at" : "2011-09-15 07:51:41 +0000",
    "user" : {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "protected" : false,
      "id_str" : "94825321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593967810226753537\/kej69_3u_normal.jpg",
      "id" : 94825321,
      "verified" : false
    }
  },
  "id" : 114250487028649984,
  "created_at" : "2011-09-15 08:13:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3082\u3061\u3085\u3093",
      "screen_name" : "lemochun",
      "indices" : [ 0, 9 ],
      "id_str" : "212934710",
      "id" : 212934710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113782552107548672",
  "geo" : { },
  "id_str" : "113782789157036032",
  "in_reply_to_user_id" : 212934710,
  "text" : "@lemochun \u306A\u308B\u307B\u3069\u30FC\u3001\u3053\u3061\u3089\u3053\u305D\u898B\u3064\u3051\u3066\u3044\u305F\u3060\u3044\u3066\u3042\u308A\u304C\u305F\u3044\u3053\u3068\u3067\u3059\uFF57",
  "id" : 113782789157036032,
  "in_reply_to_status_id" : 113782552107548672,
  "created_at" : "2011-09-14 01:15:05 +0000",
  "in_reply_to_screen_name" : "lemochun",
  "in_reply_to_user_id_str" : "212934710",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 8, 18 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113782487842435072",
  "text" : "\u00D7\u306A\u25CB\u304C QT @end313124: \u3082\u3046\u306B\u305B\u307B\u306A\u306B\u305B\u307B\u30FC\u3063\u3066\u8A00\u3063\u305F\u3089\u306B\u305B\u307B\u30FC\u3063\u3066\u8FD4\u3059\u30D7\u30ED\u30B0\u30E9\u30E0\u3092\uFF08ry\n\u307E\u3041\u3064\u307E\u3093\u306A\u3044\u3060\u308D\u3046\u306A",
  "id" : 113782487842435072,
  "created_at" : "2011-09-14 01:13:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113782369105870848",
  "text" : "\u3082\u3046\u306B\u305B\u307B\u306A\u306B\u305B\u307B\u30FC\u3063\u3066\u8A00\u3063\u305F\u3089\u306B\u305B\u307B\u30FC\u3063\u3066\u8FD4\u3059\u30D7\u30ED\u30B0\u30E9\u30E0\u3092\uFF08ry\n\u307E\u3041\u3064\u307E\u3093\u306A\u3044\u3060\u308D\u3046\u306A",
  "id" : 113782369105870848,
  "created_at" : "2011-09-14 01:13:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3082\u3061\u3085\u3093",
      "screen_name" : "lemochun",
      "indices" : [ 0, 9 ],
      "id_str" : "212934710",
      "id" : 212934710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113780817653805056",
  "geo" : { },
  "id_str" : "113781833249988608",
  "in_reply_to_user_id" : 212934710,
  "text" : "@lemochun \u8FD4\u3057\u307E\u3057\u305F\u30FC\u3002\u56E0\u307F\u306B\u3069\u3053\u304B\u3089\u898B\u3064\u3051\u307E\u3057\u305F\uFF1F",
  "id" : 113781833249988608,
  "in_reply_to_status_id" : 113780817653805056,
  "created_at" : "2011-09-14 01:11:17 +0000",
  "in_reply_to_screen_name" : "lemochun",
  "in_reply_to_user_id_str" : "212934710",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http:\/\/t.co\/M9oaoAE",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=otaks21",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113647414841327617",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001otaks21\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/M9oaoAE",
  "id" : 113647414841327617,
  "created_at" : "2011-09-13 16:17:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113582826095525889",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 113582826095525889,
  "created_at" : "2011-09-13 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113480767308435456",
  "text" : "memo\u300Cn\u306F\u5341\u306E\u4F4D\u304C0\u3067\u306F\u306A\u30444\u6841\u306E\u6B63\u306E\u6574\u6570\u3067\u3042\u308A\u3001n\u306E\u4E0A2\u6841\u3068\u4E0B2\u6841\u3092\u305D\u308C\u305E\u308C2\u6841\u306E\u6574\u6570\u3068\u8003\u3048\u305F\u3068\u304D\u3001\u3053\u306E2\u6570\u306E\u7A4D\u306Fn\u306E\u7D04\u6570\u3068\u306A\u308B\u3002\u305D\u306E\u3088\u3046\u306An\u3092\u3059\u3079\u3066\u6C42\u3081\u3088\u3002",
  "id" : 113480767308435456,
  "created_at" : "2011-09-13 05:14:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113287995431464960",
  "geo" : { },
  "id_str" : "113429042966953984",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u5927\u4E8B\u306A\u3053\u3068\u306A\u306E\u3067\u4E8C\u5EA6\u8A00\u3044\u307E\u3057\u305F\u3002",
  "id" : 113429042966953984,
  "in_reply_to_status_id" : 113287995431464960,
  "created_at" : "2011-09-13 01:49:25 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 3, 19 ],
      "id_str" : "230918258",
      "id" : 230918258
    }, {
      "name" : "...",
      "screen_name" : "hajimesugio",
      "indices" : [ 24, 36 ],
      "id_str" : "2154620634",
      "id" : 2154620634
    }, {
      "name" : "HiroshiMatsui",
      "screen_name" : "HeathRossie",
      "indices" : [ 38, 50 ],
      "id_str" : "189106293",
      "id" : 189106293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113425261592195072",
  "text" : "RT @takasan_san_san: RT @hajimesugio: @HeathRossie \u300C\u4F55\u306E\u7814\u7A76\u3092\u3055\u308C\u3066\u3044\u308B\u3093\u3067\u3059\u304B\uFF1F\u300D\u300C\u79D1\u5B66\u54F2\u5B66\u3001\u7279\u306B\u7269\u7406\u5B66\u306E\u54F2\u5B66\u3067\u3059\uFF01\u300D\u300C\u30FB\u30FB\u30FB\u300D\u300C\u7279\u306B\u3001\u91CF\u5B50\u529B\u5B66\u306B\u304A\u3051\u308B\u5B9F\u5728\u306E\u554F\u984C\u306B\u53D6\u308A\u7D44\u3093\u3067\u3044\u307E\u3059\u3002\u300D\u300C\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u3093\u3067\u3059\u304B\uFF1F\u300D\u300C\u30FB\u30FB\u30FB ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "...",
        "screen_name" : "hajimesugio",
        "indices" : [ 3, 15 ],
        "id_str" : "2154620634",
        "id" : 2154620634
      }, {
        "name" : "HiroshiMatsui",
        "screen_name" : "HeathRossie",
        "indices" : [ 17, 29 ],
        "id_str" : "189106293",
        "id" : 189106293
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113422276908687361",
    "text" : "RT @hajimesugio: @HeathRossie \u300C\u4F55\u306E\u7814\u7A76\u3092\u3055\u308C\u3066\u3044\u308B\u3093\u3067\u3059\u304B\uFF1F\u300D\u300C\u79D1\u5B66\u54F2\u5B66\u3001\u7279\u306B\u7269\u7406\u5B66\u306E\u54F2\u5B66\u3067\u3059\uFF01\u300D\u300C\u30FB\u30FB\u30FB\u300D\u300C\u7279\u306B\u3001\u91CF\u5B50\u529B\u5B66\u306B\u304A\u3051\u308B\u5B9F\u5728\u306E\u554F\u984C\u306B\u53D6\u308A\u7D44\u3093\u3067\u3044\u307E\u3059\u3002\u300D\u300C\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u3093\u3067\u3059\u304B\uFF1F\u300D\u300C\u30FB\u30FB\u30FB\u300D\u300C\u30FB\u30FB\u30FB\u300D\u300C\u4E16\u754C\u3092\u77E5\u308B\u3068\u3044\u3046\u3053\u3068\u306F\uFF5E\u300D\u300C\u30FB\u30FB\u30FB\u300D",
    "id" : 113422276908687361,
    "created_at" : "2011-09-13 01:22:32 +0000",
    "user" : {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "protected" : false,
      "id_str" : "230918258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1856992486\/proko2_normal.jpeg",
      "id" : 230918258,
      "verified" : false
    }
  },
  "id" : 113425261592195072,
  "created_at" : "2011-09-13 01:34:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113287346853650433",
  "text" : "\u5BDD\u308B\u3002\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 113287346853650433,
  "created_at" : "2011-09-12 16:26:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113286703623569412",
  "text" : "\u77E5\u8B58\u306F\u3042\u308B\u304C\u7D4C\u9A13\u306F\u306A\u3044\u3002\u3042\u307E\u305F\u3067\u3063\u304B\u3061\u3002",
  "id" : 113286703623569412,
  "created_at" : "2011-09-12 16:23:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113286487222652929",
  "text" : "\u305D\u3046\u3044\u3084\u4ECA\u65E5\u5730\u9707\u901F\u5831\u304C\u6B63\u3057\u3044\u78BA\u7387\u304C\uFF13\uFF10\uFF05\u3063\u3066\u3044\u3063\u305F\u3089\u5927\u6587\u5B57\u3067\u3084\u3051\u3069\u3068\u304B\u982D\u7A81\u304D\u3067\u602F\u307F\u3068\u304B\u307D\u3093\u307D\u3093\u51FA\u3066\u304D\u3066\u7B11\u3063\u305F\u3002",
  "id" : 113286487222652929,
  "created_at" : "2011-09-12 16:22:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113284186097459200",
  "text" : "\u6E80\u6708\u306E\u65E5\u306F\u5927\u5973\u5C06\u306B\u8FD4\u4FE1\u3059\u308B\uFF1F",
  "id" : 113284186097459200,
  "created_at" : "2011-09-12 16:13:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "indices" : [ 3, 12 ],
      "id_str" : "161910608",
      "id" : 161910608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113284071626522624",
  "text" : "RT @izugyoza: \u6E80\u6708\u306E\u65E5\u306F\u30AA\u30AA\u30AB\u30DF\u306B\u5909\u8EAB\u3059\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113283819288788992",
    "text" : "\u6E80\u6708\u306E\u65E5\u306F\u30AA\u30AA\u30AB\u30DF\u306B\u5909\u8EAB\u3059\u308B\u3002",
    "id" : 113283819288788992,
    "created_at" : "2011-09-12 16:12:21 +0000",
    "user" : {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "protected" : false,
      "id_str" : "161910608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607820959492370432\/IgL617FR_normal.png",
      "id" : 161910608,
      "verified" : false
    }
  },
  "id" : 113284071626522624,
  "created_at" : "2011-09-12 16:13:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282777763422208",
  "text" : "\u3053\u306E\u5185\u8907\u6570\u3092\u89E3\u308B\u4EBA\u3092\u8D64\u306E\u4ED6\u4EBA\u3068\u306F\u601D\u3048\u306A\u3044\u306A\u30FC",
  "id" : 113282777763422208,
  "created_at" : "2011-09-12 16:08:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282556367081472",
  "text" : "\u30A2\u30CB\u30DE\u30EB\u6A2A\u4E01",
  "id" : 113282556367081472,
  "created_at" : "2011-09-12 16:07:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282499148394497",
  "text" : "\u50CD\u304F\u30AA\u30C3\u30B5\u30F3\u5287\u5834",
  "id" : 113282499148394497,
  "created_at" : "2011-09-12 16:07:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282422958862336",
  "text" : "\u30AA\u30FC\u30DE\u30A4\u30AD\u30FC",
  "id" : 113282422958862336,
  "created_at" : "2011-09-12 16:06:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282372023222274",
  "text" : "\u9B54\u5973\u30B5\u30D6\u30EA\u30CA",
  "id" : 113282372023222274,
  "created_at" : "2011-09-12 16:06:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282320550735872",
  "text" : "\u97F3\u306E\u30BD\u30E0\u30EA\u30A8",
  "id" : 113282320550735872,
  "created_at" : "2011-09-12 16:06:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282266993655808",
  "text" : "\u99AC\u306E\u738B\u5B50\u69D8",
  "id" : 113282266993655808,
  "created_at" : "2011-09-12 16:06:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113282191320031232",
  "text" : "\u306A\u304B\u306A\u304B\u77E5\u3063\u3066\u308B\u4EBA\u304C\u3044\u306A\u3044\u5FAE\u5999\u306A\uFF34\uFF36\u756A\u7D44\u30B7\u30EA\u30FC\u30BA",
  "id" : 113282191320031232,
  "created_at" : "2011-09-12 16:05:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113281987749482497",
  "text" : "NHK\u306E\u30B8\u30E3\u30E0\uFF08\u8981\u51FA\u5178\uFF09\u3068\u304B\u3044\u3046\u80CC\u4E2D\u306B\u5BB6\u3092\u80CC\u8CA0\u3063\u305F\u8778\u725B\u306E\u30A2\u30CB\u30E1\u307F\u305F\u3044\u306E\u77E5\u3063\u3066\u308B\u4EBA\u3044\u307E\u3059\uFF1F",
  "id" : 113281987749482497,
  "created_at" : "2011-09-12 16:05:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113280440575598592",
  "text" : "\u9B5A\u6709\u7121\u30B7\u30EA\u30FC\u30BA\u306B\u306A\u308A\u3064\u3064\u3042\u308B\u3002\n\u9B5A\u306B\u6709\u308B\u3067\u30DE\u30B0\u30ED\u3060\u3051\u3069\u30DE\u30AF\u30ED\u7684\u306B\u306F\u95A2\u4FC2\u306A\u3044\u304B\u3002",
  "id" : 113280440575598592,
  "created_at" : "2011-09-12 15:58:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113280026018988032",
  "text" : "\u9BF5\u306F\u3042\u308B\u3051\u3069\u5473\u304C\u306A\u3044",
  "id" : 113280026018988032,
  "created_at" : "2011-09-12 15:57:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113279934679613440",
  "text" : "\u9C48\u306F\u3042\u308B\u3051\u3069\u8DB3\u3089\u306A\u3044\u3002",
  "id" : 113279934679613440,
  "created_at" : "2011-09-12 15:56:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113279817201369089",
  "text" : "\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u304C\u8352\u3076\u3063\u3066\u308B\u306E\u306F\u4E3B\u3068\u3057\u3066\u81EA\u5206\u306E\u6027\u2026\u3044\u3084\u3001\u305B\u3044\u3002",
  "id" : 113279817201369089,
  "created_at" : "2011-09-12 15:56:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113279612078931968",
  "text" : "\u30A2\u30A4\u30E0\u30E9\u30A4\u30F3\u304C\u9C48\u3076\u3063\u3066\u308B\u306A\u3041",
  "id" : 113279612078931968,
  "created_at" : "2011-09-12 15:55:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 14, 24 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 26, 36 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/cVxJlO8",
      "expanded_url" : "http:\/\/lockerz.com\/s\/113614919",
      "display_url" : "lockerz.com\/s\/113614919"
    } ]
  },
  "geo" : { },
  "id_str" : "113279288844886016",
  "text" : "\u306B\u305B\u307B\u4F55\u306A\u306E\uFF1F\uFF57\uFF57\uFF57 RT @nisehorrn: @end313124 \u3063 http:\/\/t.co\/cVxJlO8",
  "id" : 113279288844886016,
  "created_at" : "2011-09-12 15:54:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113279013044224000",
  "text" : "\u30B3\u30B9\u30E1\u306F\u30AA\u30B9\u30B9\u30E1\u3067\u304D\u308B\u307B\u3069\u77E5\u8B58\u304C\u306A\u3044\u3067\u3059\u3002\u30B3\u30F3\u30BD\u30E1\u306F\u30B9\u30FC\u30D7\u306B\u30AA\u30B9\u30B9\u30E1\u3067\u3059\u3002",
  "id" : 113279013044224000,
  "created_at" : "2011-09-12 15:53:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113278582918352896",
  "geo" : { },
  "id_str" : "113278787713634304",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u3061\u3087\u3063\u3068\u308F\u304B\u308A\u307E\u305B\u3093\u3002",
  "id" : 113278787713634304,
  "in_reply_to_status_id" : 113278582918352896,
  "created_at" : "2011-09-12 15:52:22 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113278665290285057",
  "text" : "\u30B3\u30B3\u30B9\u3092\u30AA\u30B9\u30B9\u30E1\n\u8A9E\u5442\u304C\u826F\u3044",
  "id" : 113278665290285057,
  "created_at" : "2011-09-12 15:51:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113278301325365248",
  "geo" : { },
  "id_str" : "113278446431518720",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30C9\u30EA\u30F3\u30AF\u30D0\u30FC\u306A\u3089\u30B3\u30B3\u30B9\u304C\u30AA\u30B9\u30B9\u30E1",
  "id" : 113278446431518720,
  "in_reply_to_status_id" : 113278301325365248,
  "created_at" : "2011-09-12 15:51:00 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113277800198316032",
  "geo" : { },
  "id_str" : "113277998215610368",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30B5\u30A4\u30BC\u30EA\u30E4\u306F\u305D\u3093\u306A\u306B\u597D\u304D\u3058\u3083\u306A\u3044\u3093\u3060\u306A",
  "id" : 113277998215610368,
  "in_reply_to_status_id" : 113277800198316032,
  "created_at" : "2011-09-12 15:49:14 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113277275906129920",
  "geo" : { },
  "id_str" : "113277529317576704",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u3067\u3082\u72AF\u4EBA\u306F\u30E4\u30B9\u306A\u3093\u3067\u3057\u3087\uFF1F",
  "id" : 113277529317576704,
  "in_reply_to_status_id" : 113277275906129920,
  "created_at" : "2011-09-12 15:47:22 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113277269497233408",
  "geo" : { },
  "id_str" : "113277418734747648",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3044\u3084\u3001\u5927\u3057\u305F\u4E8B\u3057\u3066\u306A\u3044\u3067\u3059\u3088\uFF57",
  "id" : 113277418734747648,
  "in_reply_to_status_id" : 113277269497233408,
  "created_at" : "2011-09-12 15:46:55 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113277271917330433",
  "text" : "\u6700\u8FD1\u300C\u301C\u3067\u3059\u3057\u300D\u3063\u3066\u306E\u304C\u53E3\u7656\u306B\u306A\u308A\u304B\u3051\u3066\u307E\u3059\u3057",
  "id" : 113277271917330433,
  "created_at" : "2011-09-12 15:46:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113275796658991104",
  "geo" : { },
  "id_str" : "113276966727204865",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u6C17\u306B\u3059\u3093\u306A",
  "id" : 113276966727204865,
  "in_reply_to_status_id" : 113275796658991104,
  "created_at" : "2011-09-12 15:45:08 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113276625986129920",
  "text" : "\u306A\u3093\u3060\u308D\u3046\u3002\u8FD1\u3057\u3044\u3063\u3066\u8A00\u8449\u306F\u597D\u304D\u3060\u3002",
  "id" : 113276625986129920,
  "created_at" : "2011-09-12 15:43:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113276183919075328",
  "geo" : { },
  "id_str" : "113276507396390913",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u307E\u3041\u5927\u4E08\u592B\u3067\u3057\u3087\u3046\u3002\u8ABF\u6574\u3057\u307E\u3059\u3088\u3093\u3002",
  "id" : 113276507396390913,
  "in_reply_to_status_id" : 113276183919075328,
  "created_at" : "2011-09-12 15:43:18 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113276353083748352",
  "text" : "\u3044\u308D\u3044\u308D\u306A\u7269\u306B\u8208\u5473\u304C\u3042\u308B\u306E\u306F\u3044\u308D\u3044\u308D\u306A\u7269\u306B\u8208\u5473\u304C\u306A\u3044\u3053\u3068\u306B\u8FD1\u3057\u3044",
  "id" : 113276353083748352,
  "created_at" : "2011-09-12 15:42:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113276030034255872",
  "text" : "\u3054\u514D\u306A\u3055\u3044\n\u3064\u307E\u308A\u898B\u9003\u305B\u3063\u3066\u8003\u3048\u308B\u3068\u50B2\u6162\u306A\u8A00\u8449\u3060\u3002\u622F\u8A00\u3060\u3051\u3069\u306D\u3002",
  "id" : 113276030034255872,
  "created_at" : "2011-09-12 15:41:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113275461106282496",
  "geo" : { },
  "id_str" : "113275620091363328",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u305D\u306E\u65E5\u3067\u30E1\u30F3\u30C4\u3092\u96C6\u3081\u3066\u304A\u304D\u307E\u3057\u3087\u3046",
  "id" : 113275620091363328,
  "in_reply_to_status_id" : 113275461106282496,
  "created_at" : "2011-09-12 15:39:47 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113275497944858625",
  "text" : "\u3054\u3081\u3093\u306A\u3055\u3044",
  "id" : 113275497944858625,
  "created_at" : "2011-09-12 15:39:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113275222903369728",
  "geo" : { },
  "id_str" : "113275415174447105",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306A\u3093\u306E\u3053\u3068\u3067\u3059\u304B\uFF1F\uFF08\u7121\u304B\u3063\u305F\u3053\u3068\u306B\u306A\u308A\u307E\u3057\u305F\uFF09",
  "id" : 113275415174447105,
  "in_reply_to_status_id" : 113275222903369728,
  "created_at" : "2011-09-12 15:38:58 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113274880732037120",
  "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u3084\u308B\u3068\u304D\u3068\u3084\u3089\u306A\u3044\u6642\u306E\u5DEE\u304C\u6FC0\u3057\u3044\u306A\u30FC",
  "id" : 113274880732037120,
  "created_at" : "2011-09-12 15:36:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113079681842036737",
  "text" : "\u5FCD\u3061\u3083\u3093\u306A\u3089\u767A\u72C2\u3059\u308B\u30EC\u30D9\u30EB",
  "id" : 113079681842036737,
  "created_at" : "2011-09-12 02:41:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112950018276720640",
  "text" : "\uFF11\uFF13\u9023\u9396\u5168\u6D88\u3057\u51FA\u6765\u3066\u3001\u5E78\u305B\u306A\u307E\u307E\u30DB\u30F3\u30C8\u306B\u5BDD\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 112950018276720640,
  "created_at" : "2011-09-11 18:05:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112936519051902976",
  "text" : "\u5BDD\u308B\u3063\uFF01\u3069\u3046\u305B\u3057\u3070\u3089\u304F\u8D77\u304D\u3066\uFF34\uFF2C\u898B\u3066\u308B\u3051\u3069\u306D\uFF57\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 112936519051902976,
  "created_at" : "2011-09-11 17:12:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6642\u96E8\u6CA2@\uFF16\u670810\u65E5\u65B0\u520A\u767A\u58F2\uFF01",
      "screen_name" : "sigsawa",
      "indices" : [ 3, 11 ],
      "id_str" : "116197195",
      "id" : 116197195
    }, {
      "name" : "Tats-o",
      "screen_name" : "Shimo_T",
      "indices" : [ 21, 29 ],
      "id_str" : "71022666",
      "id" : 71022666
    }, {
      "name" : "\u6642\u96E8\u6CA2@\uFF16\u670810\u65E5\u65B0\u520A\u767A\u58F2\uFF01",
      "screen_name" : "sigsawa",
      "indices" : [ 50, 58 ],
      "id_str" : "116197195",
      "id" : 116197195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112923954750029824",
  "text" : "RT @sigsawa: \u308F\u306F\u306F\u3002 RT @Shimo_T: \u300C\u3046\u308F\u3063\uFF01\u3000\u79C1\u306E\u5F7C\u6C0F\u3001\u4E0A\u6749\uFF1F\u300D RT @sigsawa: \u300C\u3046\u308F\u3063\uFF01\u3000\u79C1\u306E\u00D7\u00D7\u00D7\u00D7\u00D7\u3001\u00D7\u00D7\u00D7\u00D7\u00D7\u3059\u304E\uFF1F\u300D\u306F\u4FBF\u5229\u306A\u8A00\u8449\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tats-o",
        "screen_name" : "Shimo_T",
        "indices" : [ 8, 16 ],
        "id_str" : "71022666",
        "id" : 71022666
      }, {
        "name" : "\u6642\u96E8\u6CA2@\uFF16\u670810\u65E5\u65B0\u520A\u767A\u58F2\uFF01",
        "screen_name" : "sigsawa",
        "indices" : [ 37, 45 ],
        "id_str" : "116197195",
        "id" : 116197195
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112923283975974912",
    "text" : "\u308F\u306F\u306F\u3002 RT @Shimo_T: \u300C\u3046\u308F\u3063\uFF01\u3000\u79C1\u306E\u5F7C\u6C0F\u3001\u4E0A\u6749\uFF1F\u300D RT @sigsawa: \u300C\u3046\u308F\u3063\uFF01\u3000\u79C1\u306E\u00D7\u00D7\u00D7\u00D7\u00D7\u3001\u00D7\u00D7\u00D7\u00D7\u00D7\u3059\u304E\uFF1F\u300D\u306F\u4FBF\u5229\u306A\u8A00\u8449\u3002",
    "id" : 112923283975974912,
    "created_at" : "2011-09-11 16:19:43 +0000",
    "user" : {
      "name" : "\u6642\u96E8\u6CA2@\uFF16\u670810\u65E5\u65B0\u520A\u767A\u58F2\uFF01",
      "screen_name" : "sigsawa",
      "protected" : false,
      "id_str" : "116197195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1059261905\/SANY0049_________s_normal.jpg",
      "id" : 116197195,
      "verified" : false
    }
  },
  "id" : 112923954750029824,
  "created_at" : "2011-09-11 16:22:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112919741710082048",
  "text" : "@nartakio \u8272\u5F69\u691C\u5B9A\u3063\u3066\u96E3\u3057\u304B\u3063\u305F\u3067\u3059\u304B\uFF1F\u8208\u5473\u304C\u3042\u308B\u307E\u307E\u3057\u3070\u3089\u304F\u7D4C\u3064\u3093\u3067\u3059\u304C\uFF57",
  "id" : 112919741710082048,
  "created_at" : "2011-09-11 16:05:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112867309235879936",
  "text" : "@nico_reflexio \u3048\u3001\u4FFA\u3060\u3051\u307F\u305F\u3044\u306A\u30AA\u30C1\uFF1F\uFF57",
  "id" : 112867309235879936,
  "created_at" : "2011-09-11 12:37:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112858065237327872",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 112858065237327872,
  "created_at" : "2011-09-11 12:00:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112854871195123712",
  "text" : "@nico_reflexio \u3066\u304B\u6383\u9664\u306E\u7B2C\u4E00\u6BB5\u968E\u3063\u3066\u6563\u3089\u304B\u308B\u3088\u306A\uFF57\uFF57\uFF57",
  "id" : 112854871195123712,
  "created_at" : "2011-09-11 11:47:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112853925505400832",
  "text" : "\u6383\u9664\u3063\u3066\u7D42\u308F\u3089\u305B\u306A\u3044\u3068\u7D42\u308F\u3089\u306A\u3044\u3088\u306D\u3002",
  "id" : 112853925505400832,
  "created_at" : "2011-09-11 11:44:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112853846438592513",
  "text" : "\u4E00\u6BB5\u843D\u3002",
  "id" : 112853846438592513,
  "created_at" : "2011-09-11 11:43:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ken",
      "screen_name" : "t_yoshiyasu",
      "indices" : [ 23, 35 ],
      "id_str" : "1944396187",
      "id" : 1944396187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112850626584657920",
  "text" : "\u3053\u308C\u3059\u3054\u3044\u697D\u3057\u3044\u3088\u306A\u30FC\u3002\u306A\u3093\u3067\u3060\u308D\u3046\u3002 RT @t_yoshiyasu \u30AB\u30D5\u30A7\u3067\u30A2\u30EC\u306A\u30AB\u30C3\u30D7\u30EB\u9054\u304C\u91D1\u306E\u8A71\u3070\u3063\u304B\u308A\u3057\u3066\u308B\u6A2A\u3067\u3001\u9ED9\u3005\u3068\u6570\u5B66\u3057\u3066\u304D\u307E\u3057\u305F\u3002\u5927\u5909\u697D\u3057\u304B\u3063\u305F\u3067\u3059\u3002",
  "id" : 112850626584657920,
  "created_at" : "2011-09-11 11:31:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112850209830207488",
  "text" : "\u6B63\u78BA\u306B\u306F\u53CE\u7D0D\u3001\u3044\u3084\u3001\u53CE\u7D0D\u5BB6\u5177\u304C\u5C11\u306A\u3059\u304E\u308B\u3093\u3060\u306A",
  "id" : 112850209830207488,
  "created_at" : "2011-09-11 11:29:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112850096965681152",
  "text" : "\u3046\u308F\u3063\u3001\u308F\u305F\u3057\u306E\u90E8\u5C4B\u3001\u7269\u591A\u904E\u304E\u2026\uFF01\uFF1F",
  "id" : 112850096965681152,
  "created_at" : "2011-09-11 11:28:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112849116798779392",
  "text" : "@koketomi \u30CF\u30F3\u30CC\u30AE\u30FC\u7CBE\u795E\u3068\u3044\u3046\u3057\u3087\u3046\u3082\u306A\u3044\u5358\u8A9E\u304C\u3042\u308B\u306A",
  "id" : 112849116798779392,
  "created_at" : "2011-09-11 11:25:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112839493106679808",
  "geo" : { },
  "id_str" : "112840390062776320",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u6C96\u7E04\u306A\u3093\u3066\u73FE\u5730\u304B\u3089\u96E2\u308C\u305F\u3068\u3053\u308D\u3060\u3068\u5E7B\u60F3\u306F\u3053\u3068\u3055\u3089\u5927\u304D\u304B\u3063\u305F\u3067\u3057\u3087\u3046\u306D\u3047\uFF57",
  "id" : 112840390062776320,
  "in_reply_to_status_id" : 112839493106679808,
  "created_at" : "2011-09-11 10:50:20 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112839002482163712",
  "text" : "\u7DAD\u6301\u3067\u304D\u306A\u3044\u3051\u3069\u3001\u6383\u9664\u304C\u59CB\u307E\u308B\u3068\u610F\u5730\u306B\u306A\u3063\u3061\u3083\u3046\u3093\u3067\u3059\u3088\u306D\u3002\u3042\u3063\u3061\u3082\u3053\u3063\u3061\u3082\u3002",
  "id" : 112839002482163712,
  "created_at" : "2011-09-11 10:44:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112838925164359681",
  "text" : "\u6383\u9664\u305D\u306E\u3082\u306E\u306F\u305D\u3053\u307E\u3067\u597D\u304D\u3058\u3083\u306A\u3044\u3051\u308C\u3069\u3001\u6383\u9664\u304C\u7D42\u308F\u3063\u305F\u5F8C\u306E\u7406\u8DEF\u6574\u7136\u3068\u3057\u305F\u611F\u3058\u306F\u7D50\u69CB\u597D\u304D\u3002\u305F\u3060\u305D\u308C\u304C\u7DAD\u6301\u3067\u304D\u306A\u3044\u3063\u3066\u3060\u3051\u3067\u3002",
  "id" : 112838925164359681,
  "created_at" : "2011-09-11 10:44:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112838784982335488",
  "text" : "\u5C0F\u6383\u9664\u304C\u5927\u6383\u9664\u306B\u306A\u3063\u3066\u304D\u305F\u3002\u5272\u308A\u5207\u308C\u306A\u3044\u3051\u3069\u5546\u6383\u9664\u306A\u306E\u304B\u3002",
  "id" : 112838784982335488,
  "created_at" : "2011-09-11 10:43:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112777556108906496",
  "text" : "\u3042\u308B\u3044\u306F\u732B\uFF1F",
  "id" : 112777556108906496,
  "created_at" : "2011-09-11 06:40:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112777506406400000",
  "text" : "15\u65E5\u306B\u30CB\u30B3\u751F\u3067\u767A\u8868\u3067\u3001\u64AB\u5B50\u5F79\u3068\u3072\u305F\u304E\u5F79\u3068\u99FF\u6CB3\u5F79\u306E\u58F0\u512A\u3055\u3093\u3044\u308B\u3063\u3066\u3053\u3068\u306F\u307B\u307C\u507D\u3067\u78BA\u5B9A\u3060\u3068\u601D\u3046\uFF08\u3044\u305F\u3044\uFF09",
  "id" : 112777506406400000,
  "created_at" : "2011-09-11 06:40:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112777045938941952",
  "text" : "\u3048\u3001\u897F\u5C3E\u7DAD\u65B0\u30A2\u30CB\u30E1\u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u6700\u65B0\u60C5\u5831\uFF1F\u3048\u3001\u507D\u7269\u8A9E\u3067\u3059\u304B\uFF1F\u671F\u5F85\u3002",
  "id" : 112777045938941952,
  "created_at" : "2011-09-11 06:38:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 10, 22 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112758259856846848",
  "text" : "\u306B\u305B\u307B\u304C\u6016\u3044 RT @nisehorrrrn: \u9752\u81ED\u3044\u3053\u3068\u3092\u3002\u5927\u4E8B\u306A\u304A\u5B22\u3055\u3093\u3068\u3084\u3089\u3082\u9053\u9023\u308C\u306B\u3057\u3066\u3084\u308B\u3002",
  "id" : 112758259856846848,
  "created_at" : "2011-09-11 05:23:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112572652379582464",
  "text" : "\u30C7\u30E5\u30A2\u30EB\u30B9\u30AF\u30EA\u30FC\u30F3\u306F\u307E\u3060\u3064\u3044\u3066\u3044\u3051\u308B\u3051\u3069\u30DE\u30EB\u30C1\u30B9\u30AF\u30EA\u30FC\u30F3\u306F\u53B3\u3057\u305D\u3046\u3002",
  "id" : 112572652379582464,
  "created_at" : "2011-09-10 17:06:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112572088694480896",
  "text" : "\u3042\u308C\u306F\u6642\u9593\u304C\u304B\u304B\u3063\u3066\u3057\u3087\u30FC\u304C\u306A\u3044\u304B\u3089",
  "id" : 112572088694480896,
  "created_at" : "2011-09-10 17:04:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112571993383112704",
  "text" : "\u30C7\u30B9\u30AF\u3067\u30C4\u30A4\u30C3\u30BF\u30FC\u3057\u306A\u304C\u3089\u30CE\u30FC\u30C8\u3067\u30B9\u30AB\u30A4\u30D7\u3002\u9752\u3044\u30B5\u30F4\u30A1\u30F3\u3068\u306F\u9055\u3063\u3066\u53CB\u306B\u30DE\u30A6\u30B9\u306A\u306E\u3067\u52B9\u7387\u60AA\u3044\u3002",
  "id" : 112571993383112704,
  "created_at" : "2011-09-10 17:03:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E9C\u7F8E",
      "screen_name" : "aimin_xxx",
      "indices" : [ 0, 10 ],
      "id_str" : "198026591",
      "id" : 198026591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112566027782586368",
  "geo" : { },
  "id_str" : "112571361582522368",
  "in_reply_to_user_id" : 198026591,
  "text" : "@aimin_xxx \u305D\u308C\u306F\u3069\u3046\u3082\u3002\u3061\u306A\u307F\u306B\u3069\u3053\u304B\u3089\u898B\u3064\u3051\u307E\u3057\u305F\uFF1F",
  "id" : 112571361582522368,
  "in_reply_to_status_id" : 112566027782586368,
  "created_at" : "2011-09-10 17:01:18 +0000",
  "in_reply_to_screen_name" : "aimin_xxx",
  "in_reply_to_user_id_str" : "198026591",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/4imf5Hm",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=dosannpinn",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112560234433753088",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001dosannpinn\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/4imf5Hm",
  "id" : 112560234433753088,
  "created_at" : "2011-09-10 16:17:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112524046033371136",
  "geo" : { },
  "id_str" : "112524623299612672",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3055\u3059\u304C\u306B\u30ED\u30DC\u30C3\u30C8\u3067\u306F\u306A\u3044\u306E\u3067\u3059\u3002\u4EBA\u4E26\u307F\u306B\u8003\u3048\u3066\u3044\u308B\u306E\u3067\u3059\u3002",
  "id" : 112524623299612672,
  "in_reply_to_status_id" : 112524046033371136,
  "created_at" : "2011-09-10 13:55:35 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112523815975792640",
  "text" : "@koketomi \u3042\u3068\u304B\u3089\u30EF\u30FC\u30C9\u691C\u7D22\u639B\u3051\u3089\u308C\u305F\u308A\u4FBF\u5229\u3060\u3088\u306D\u3001\u3046\u3093\u3002",
  "id" : 112523815975792640,
  "created_at" : "2011-09-10 13:52:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112521808116326401",
  "text" : "\u597D\u304D\u306A\u4EBA\u306F\u305F\u304F\u3055\u3093\u3044\u308B\u3051\u308C\u3069\u3001\u604B\u3059\u308B\u4EBA\u304C\u3044\u306A\u3044\u306E\u3068\u540C\u69D8\u306B\u3002\u3080\u3045\u3002",
  "id" : 112521808116326401,
  "created_at" : "2011-09-10 13:44:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112521540494557184",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u597D\u304D\u306A\u30AD\u30E3\u30E9\u306F\u3069\u306E\u4F5C\u54C1\u306B\u3082\u3044\u308B\u3051\u308C\u3069\u604B\u3059\u308B\u30AD\u30E3\u30E9\u3063\u3066\u5C45\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u3001\u81EA\u5206\u3002",
  "id" : 112521540494557184,
  "created_at" : "2011-09-10 13:43:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/T5lHtF4",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112520918957428737",
  "text" : "\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3067\u300Cend313124\u3055\u3093\u300D\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3059\u308B #theinterviews http:\/\/t.co\/T5lHtF4 \u601D\u3063\u305F\u3051\u3069\u3053\u308C\u3063\u3066\u5B9A\u671F\u7684\u306B\u66F8\u304B\u306A\u3044\u3068\u3055\u3063\u3071\u308A\u3060\u3088\u306D\u3002",
  "id" : 112520918957428737,
  "created_at" : "2011-09-10 13:40:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112520470842183682",
  "text" : "\uFF34\uFF57\uFF49\uFF4C\uFF4F\uFF47\u898B\u3066\u305F\u3051\u3069\u4E00\u65E5\u306B100\u30DD\u30B9\u30C8\u306F\u81EA\u5206\u306B\u306F\u7121\u7406\u306A\u3093\u3060\u308D\u3046\u306A\u30FC\u3002\u4ECA\u306E\u624080\u304C\u9650\u5EA6\u3060\u3002",
  "id" : 112520470842183682,
  "created_at" : "2011-09-10 13:39:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112517874773528576",
  "text" : "\u307E\u30015\u5E74\u524D\u306B\u305D\u3093\u306A\u3053\u3068\u8A00\u3046\u4EBA\u304C\u3044\u3066\u3082\u304D\u3063\u3068\u61D0\u7591\u306E\u307E\u306A\u3056\u3057\u3067\u898B\u3066\u3044\u305F\u3060\u308D\u3046\u3002",
  "id" : 112517874773528576,
  "created_at" : "2011-09-10 13:28:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3082\u3057\u30825\u5E74\u524D\u81EA\u5206\u306B30\u79D2\u3060\u3051\u4F1A\u3048\u305F\u3089",
      "indices" : [ 20, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112517383033335808",
  "text" : "\u60AA\u3044\u3053\u3068\u306F\u8A00\u308F\u306A\u3044\u3002\u7406\u7CFB\u3092\u9078\u3073\u306A\u3055\u3044\u3002\n#\u3082\u3057\u30825\u5E74\u524D\u81EA\u5206\u306B30\u79D2\u3060\u3051\u4F1A\u3048\u305F\u3089\u3000",
  "id" : 112517383033335808,
  "created_at" : "2011-09-10 13:26:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112516594973933568",
  "text" : "\u304B\u306A\u308A\u5C11\u306A\u3044\u3051\u3069\u3075\u3041\u307C\u306F\u306A\u3093\u3068\u306A\u304F\u89E3\u308B\u3002\uFF32\uFF34\u3082\u306A\u3093\u3068\u306A\u304F\u308F\u304B\u308B\u3002\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u308B\u7406\u7531\u3001\u3044\u3084\u3001\u7406\u7531\u3068\u3044\u3046\u3088\u308A\u7D4C\u8DEF\u304B\u3002\u3069\u3053\u304B\u3089\u3053\u3093\u306A\u5834\u672B\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u3092\u63A2\u3057\u5F53\u3066\u3066\u304F\u308B\u306E\u304B\u7591\u554F\u3067\u3042\u308B\u3002\n\u5B9A\u671F\u306E\u30C4\u30A4\u30FC\u30C8\u304C\u3058\u308F\u3058\u308F\u52B9\u3044\u3066\u3044\u308B\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 112516594973933568,
  "created_at" : "2011-09-10 13:23:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112515785284534272",
  "text" : "\u5BFE\u5076\u3068\u308A\u59CB\u3081\u308B\u3042\u305F\u308A\u75C5\u6C17",
  "id" : 112515785284534272,
  "created_at" : "2011-09-10 13:20:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112515664354344960",
  "text" : "\u604B\u306A\u3089\u3070\u76F2\u76EE\u3001\u5BFE\u5076\u3092\u8003\u3048\u308B\u3068\u3001\u76F2\u76EE\u306A\u3089\u3056\u308C\u3070\u3001\u604B\u306A\u3089\u305A\u3002\u76F2\u76EE\u306B\u306A\u308C\u306A\u3044\u81EA\u5206\u306B\u604B\u306F\u4E0D\u53EF\u80FD\u306A\u306E\u304B\u3002\n\n\u3068\u3001\u307E\u3041\u3053\u3046\u3044\u3046\u601D\u8003\u56DE\u8DEF\u304C\u65E2\u306B\u30A2\u30EC\u3002",
  "id" : 112515664354344960,
  "created_at" : "2011-09-10 13:19:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112513759087575040",
  "text" : "\u3082\u308C\u306A\u304F\u3001\u30C0\u30D6\u308A\u306A\u304F\u3001\u5834\u5408\u3092\u5C3D\u304F\u3057\u3066\u8003\u3048\u306A\u3044\u3068\u3044\u3051\u306A\u3044\u3002",
  "id" : 112513759087575040,
  "created_at" : "2011-09-10 13:12:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C7\u30B9\u30AF\u30E9\u30A6\u30C9",
      "screen_name" : "n_2i",
      "indices" : [ 3, 8 ],
      "id_str" : "45118973",
      "id" : 45118973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112513632507658240",
  "text" : "RT @n_2i: \u7B54\u3048:\u305F\u307E\u305F\u307E\u4F8B\u5916\u304C\u306A\u304B\u3063\u305F\u304B\u3089",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112513086388305920",
    "text" : "\u7B54\u3048:\u305F\u307E\u305F\u307E\u4F8B\u5916\u304C\u306A\u304B\u3063\u305F\u304B\u3089",
    "id" : 112513086388305920,
    "created_at" : "2011-09-10 13:09:44 +0000",
    "user" : {
      "name" : "\u30C7\u30B9\u30AF\u30E9\u30A6\u30C9",
      "screen_name" : "n_2i",
      "protected" : false,
      "id_str" : "45118973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1129435473\/becky_verycute_normal.png",
      "id" : 45118973,
      "verified" : false
    }
  },
  "id" : 112513632507658240,
  "created_at" : "2011-09-10 13:11:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4ECA\u65E5\u3082\u30A4\u30AA\u30BF\u3060\u306B\u3083\u30FC",
      "screen_name" : "_iota",
      "indices" : [ 3, 9 ],
      "id_str" : "69003052",
      "id" : 69003052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http:\/\/t.co\/p0r67Bv",
      "expanded_url" : "http:\/\/burusoku-vip.com\/archives\/1556087.html",
      "display_url" : "burusoku-vip.com\/archives\/15560\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112513620419690497",
  "text" : "RT @_iota: \u306A\u305C\u6570\u5B66\u6559\u5E2B\u306F\u4F8B\u5916\u306A\u304F\u5ACC\u306A\u5974\u3060\u3063\u305F\u306E\u304Bhttp:\/\/t.co\/p0r67Bv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 38 ],
        "url" : "http:\/\/t.co\/p0r67Bv",
        "expanded_url" : "http:\/\/burusoku-vip.com\/archives\/1556087.html",
        "display_url" : "burusoku-vip.com\/archives\/15560\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "112508690053087232",
    "text" : "\u306A\u305C\u6570\u5B66\u6559\u5E2B\u306F\u4F8B\u5916\u306A\u304F\u5ACC\u306A\u5974\u3060\u3063\u305F\u306E\u304Bhttp:\/\/t.co\/p0r67Bv",
    "id" : 112508690053087232,
    "created_at" : "2011-09-10 12:52:16 +0000",
    "user" : {
      "name" : "\u4ECA\u65E5\u3082\u30A4\u30AA\u30BF\u3060\u306B\u3083\u30FC",
      "screen_name" : "_iota",
      "protected" : false,
      "id_str" : "69003052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000693751472\/3c0460eae07e54575d1addcf3e5aba0a_normal.png",
      "id" : 69003052,
      "verified" : false
    }
  },
  "id" : 112513620419690497,
  "created_at" : "2011-09-10 13:11:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 11, 20 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112509517647970304",
  "text" : "\u4ECA\u66F4\uFF57\uFF57\uFF57\uFF57\uFF57 RT @koketomi: \u3075\u3068\u601D\u3063\u305F\u3001\u65E9\u82D7\u3055\u3093\u306E\u3053\u3068\u306B\u306A\u308B\u3068\u5225\u4EBA\u307F\u305F\u3044\u306B\u306A\u308B\u306A\u4FFA",
  "id" : 112509517647970304,
  "created_at" : "2011-09-10 12:55:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112497680198021120",
  "text" : "@koketomi \u305D\u306E\u30DA\u30FC\u30B9\u3060\u3068\u3042\u30681\u9031\u9593\u304F\u3089\u3044\uFF1F",
  "id" : 112497680198021120,
  "created_at" : "2011-09-10 12:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112495736125538304",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 112495736125538304,
  "created_at" : "2011-09-10 12:00:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112410040941547520",
  "text" : "\u3053\u306E\u624B\u304C\u3042\u3063\u305F\u304B\u3002",
  "id" : 112410040941547520,
  "created_at" : "2011-09-10 06:20:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112410002702077952",
  "text" : "RT @0_uda: \u4E00\u756A\u3088\u304F\u3042\u308B\u306E\u306F\u3001\u300C\u4EBA\u306E\u9854\u3092\u899A\u3048\u3089\u308C\u306A\u3044\u300D\u300C\u307E\u3041\u307F\u3093\u306A\u4F4D\u76F8\u540C\u76F8\u3060\u304B\u3089\u306D\u300D\u3068\u304B\u3002\u306A\u304A\u30D4\u30A2\u30B9\u3092\u3064\u3051\u3066\u308B\u7CFB\u306E\u4EBA\u306F\u8FD1\u508D\u306B\u3044\u306A\u3044\u304B\u3089\u8003\u3048\u307E\u305B\u3093\u3002 [\u6E21\u4ECF\u58C7]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112409481530445824",
    "text" : "\u4E00\u756A\u3088\u304F\u3042\u308B\u306E\u306F\u3001\u300C\u4EBA\u306E\u9854\u3092\u899A\u3048\u3089\u308C\u306A\u3044\u300D\u300C\u307E\u3041\u307F\u3093\u306A\u4F4D\u76F8\u540C\u76F8\u3060\u304B\u3089\u306D\u300D\u3068\u304B\u3002\u306A\u304A\u30D4\u30A2\u30B9\u3092\u3064\u3051\u3066\u308B\u7CFB\u306E\u4EBA\u306F\u8FD1\u508D\u306B\u3044\u306A\u3044\u304B\u3089\u8003\u3048\u307E\u305B\u3093\u3002 [\u6E21\u4ECF\u58C7]",
    "id" : 112409481530445824,
    "created_at" : "2011-09-10 06:18:03 +0000",
    "user" : {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "protected" : false,
      "id_str" : "184844182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547956554922614784\/ccU36n2B_normal.png",
      "id" : 184844182,
      "verified" : false
    }
  },
  "id" : 112410002702077952,
  "created_at" : "2011-09-10 06:20:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112407536036085761",
  "text" : "@koketomi \u7D50\u5C40\u540C\u5B66\u5E74\u3067\u6253\u3066\u308B\u9762\u5B50\u306F\u4FFA\u304C\u6559\u3048\u3066\u3057\u307E\u3063\u305F\u3002\u5C45\u306A\u3044\u306E\u306A\u3089\u3070\u4F5C\u308C\u3070\u3044\u3044\u3063\u3066\u767A\u60F3\u3002",
  "id" : 112407536036085761,
  "created_at" : "2011-09-10 06:10:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112406085511553025",
  "text" : "@koketomi \u305D\u308C\u4EE5\u524D\u306B\u5353\u56F2\u307E\u306A\u3044\u3067\u8DA3\u5473\u3067\u3059\u304B\uFF57",
  "id" : 112406085511553025,
  "created_at" : "2011-09-10 06:04:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112394881867071488",
  "geo" : { },
  "id_str" : "112395053053382657",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u308C\u306F\u5341\u5168\u3060\u306A\u3002\u6765\u5B66\u671F\u304C\u697D\u3057\u307F\u3060\u3002",
  "id" : 112395053053382657,
  "in_reply_to_status_id" : 112394881867071488,
  "created_at" : "2011-09-10 05:20:43 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112394272581500928",
  "geo" : { },
  "id_str" : "112394462520549376",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3081\u3067\u3068\uFF01\u3069\u306E\u3042\u305F\u308A\uFF1F",
  "id" : 112394462520549376,
  "in_reply_to_status_id" : 112394272581500928,
  "created_at" : "2011-09-10 05:18:22 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112378860204593152",
  "text" : "@koketomi \u6687\u306A\u4EBA\u9593\u306F\u307F\u3093\u306A\u6687\u3060\u3068\u601D\u3044\u8FBC\u3093\u3067\u308B\u3053\u3068\u304C\u3042\u308B\u3088\u306A\u3002",
  "id" : 112378860204593152,
  "created_at" : "2011-09-10 04:16:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112374502586978304",
  "text" : "\u3080\u3001\u304A\u306F\u3088\u3046\u3002",
  "id" : 112374502586978304,
  "created_at" : "2011-09-10 03:59:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112238060330160128",
  "text" : "\u7720\u304F\u306A\u3044\u3051\u3069\u9811\u5F35\u3063\u3066\u5BDD\u3066\u307F\u307E\u3059\u3002\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 112238060330160128,
  "created_at" : "2011-09-09 18:56:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112237238200438784",
  "text" : "\u4F55\u51E6\u306B\u3082\u884C\u3051\u306A\u3044\u3002\u4ECA\u601D\u3048\u3070\u30A2\u30A4\u30B3\u30F3\u306E\u30C7\u30B6\u30A4\u30F3\u3082\u4F55\u51E6\u306B\u3082\u884C\u3051\u306A\u3044\u30C7\u30B6\u30A4\u30F3\u3060\u3063\u305F\u3002",
  "id" : 112237238200438784,
  "created_at" : "2011-09-09 18:53:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 31, 43 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112235446402166784",
  "text" : "\u5BA2\u89B3\u8996\u3059\u308B\u5B66\u554F\u3060\u304B\u3089\u8996\u70B9\u306E\u30EC\u30D9\u30EB\u3092\u4E0A\u3052\u305F\u304C\u308B\u3093\u3067\u3059\u304B\u306D RT @momo_miku28: \u6570\u5B66\u597D\u304D\u306A\u4EBA\u306F\u30E1\u30BF\u3063\u3066\u8A00\u8449\u304C\u597D\u304D\u306A\u306E\u304B\u306A",
  "id" : 112235446402166784,
  "created_at" : "2011-09-09 18:46:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112233971315777536",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u81EA\u5206\u306E\u4E8B\u306A\u306E\u3067\u81EA\u5206\u3067\u6298\u308A\u5408\u3044\u4ED8\u3051\u308B\u306E\u304C\u7406\u60F3\u306A\u3093\u3067\u3059\u304C\u96E3\u3057\u3044\u3067\u3059\u3002",
  "id" : 112233971315777536,
  "created_at" : "2011-09-09 18:40:38 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112231360197951488",
  "text" : "\u4F55\u51E6\u306B\u3082\u884C\u3051\u306A\u3044\u3002",
  "id" : 112231360197951488,
  "created_at" : "2011-09-09 18:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112231226454188033",
  "text" : "\u305D\u3046\u3044\u3048\u3070mixi\u3067\u8A00\u8449\u3067\u904A\u3093\u3067\u53CB\u4EBA\u306E\u771F\u9762\u76EE\u306A\u545F\u304D\u3092\u8336\u5316\u3057\u3066\u3057\u305F\u3089\u4ED6\u306E\u53CB\u4EBA\u306B\u300C\u30CF\u30C3\u3068\u3055\u305B\u3089\u308C\u308B\u3051\u3069\u3001\u3069\u3053\u306B\u3082\u884C\u3051\u306A\u3044\u6C17\u304C\u3057\u3066\u6016\u3044\u300D\u3068\u8A00\u308F\u308C\u305F\u8A18\u61B6\u304C\u3042\u308B\u3002",
  "id" : 112231226454188033,
  "created_at" : "2011-09-09 18:29:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112230390390988801",
  "text" : "\u3053\u308C\u3082\u30E1\u30BF\u306A\u81EA\u5DF1\u5426\u5B9A\u306B\u306A\u308B\u306E\u304B\u3002",
  "id" : 112230390390988801,
  "created_at" : "2011-09-09 18:26:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112230008784818176",
  "text" : "\u307E\u3041\u305D\u3046\u3044\u3046\u6B32\u6C42\u3092\u5426\u5B9A\u3057\u3066\u3057\u307E\u3046\u6BB5\u968E\u3067\u4F55\u304B\u6B20\u3051\u3066\u3044\u308B\u6C17\u304C\u3059\u308B",
  "id" : 112230008784818176,
  "created_at" : "2011-09-09 18:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112229665569112064",
  "text" : "SNS\u307F\u305F\u3044\u306A\u3042\u308B\u7A2E\u99B4\u308C\u5408\u3044\u306E\u5834\u3060\u3068\u9855\u8457\u306A\u306E\u306F\u5F53\u7136\u306B\u3057\u3066\u5411\u304B\u3044\u5408\u3063\u3066\u5BFE\u8A71\u3057\u3066\u3066\u3082\u611F\u3058\u308B\u306E\u306F\u4F55\u306A\u3093\u3060\u308D\u3046\u3002",
  "id" : 112229665569112064,
  "created_at" : "2011-09-09 18:23:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112229315541864448",
  "text" : "\u9B31\u30C4\u30A4\u30FC\u30C8\u307F\u305F\u3044\u306A\u81EA\u5DF1\u5426\u5B9A\u767A\u8A00\u3063\u3066\u3001\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u304F\u300C\u305D\u3093\u306A\u3053\u3068\u306A\u3044\u3088\uFF01\u300D\u3063\u3066\u8A00\u308F\u308C\u305F\u3044\u6B32\u6C42\u304C\u542B\u307E\u308C\u308B\u3088\u306A\u30FC\u3001\u3068\u81EA\u899A\u3057\u3066\u3057\u307E\u3046\u2192\u306A\u304A\u51F9\u3080\u306E\u30D1\u30BF\u30FC\u30F3\u304C\u898B\u3048\u308B\u304B\u3089\u51FA\u6765\u308B\u3060\u3051\u3084\u3089\u306A\u3044\u3002",
  "id" : 112229315541864448,
  "created_at" : "2011-09-09 18:22:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112207628108701696",
  "text" : "\u3084\u3063\u306813\u9023\u9396\uFF01\u3084\u3063\u3068\u30D1\u30FC\u30DF\u30C6\u30FC\u30B7\u30E7\u30F3\u3092\u805E\u3051\u305F\u3002",
  "id" : 112207628108701696,
  "created_at" : "2011-09-09 16:55:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112204538567598080",
  "text" : "\u819D\u306B\u30CE\u30FC\u30C8\uFF30\uFF23\u4E57\u305B\u3066\u305F\u305B\u3044\u3067\u6691\u3044\u3002",
  "id" : 112204538567598080,
  "created_at" : "2011-09-09 16:43:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112204412767830016",
  "text" : "\u4E8C\u6642\u306B\u306A\u308B\u306E\u304B\u3002\u4E2D\u9014\u534A\u7AEF\u306B\u5BDD\u305F\u305B\u3044\u3067\u7720\u304F\u306A\u3044\u3002\u5909\u306A\u59FF\u52E2\u3067\u5BDD\u3066\u305F\u306E\u304B\u80A9\u3068\u9996\u304C\u75DB\u3044\u3002",
  "id" : 112204412767830016,
  "created_at" : "2011-09-09 16:43:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112194022877052928",
  "text" : "\u5927\u5B66\u751F\u3067\u3042\u308B\u4EE5\u524D\u306B\u4EBA\u9593\u306A\u306E\u3067\u3059",
  "id" : 112194022877052928,
  "created_at" : "2011-09-09 16:01:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112193967138934784",
  "text" : "\u4E16\u9593\u306E\u76EE\u306F\u6771\u5927\u4EAC\u5927\u751F\u306F\u4EBA\u9593\u3058\u3083\u306A\u3044\u3082\u306E\u3068\u3057\u3066\u307F\u3066\u304F\u308B\u304B\u3089\u306A\u30FC\u3002\u3082\u3061\u308D\u3093\u305D\u308C\u304C\u30D7\u30E9\u30B9\u306B\u50CD\u304F\u3053\u3068\u3082\u3042\u308B\u3051\u3069\u3055\u3002",
  "id" : 112193967138934784,
  "created_at" : "2011-09-09 16:01:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112193597218107394",
  "text" : "\u00D7\u306A\u3088\u306A \u3000\u25CB\u3000\u3088\u306A\u3000RT @end313124 \u7532\u5B50\u5712\u3067\u306E\u611F\u52D5\u306F\u5168\u304F\u7D4C\u9A13\u304C\u306A\u3044\u3051\u3069\u3001\u3053\u306E\u6587\u53E5\u306F\u89E3\u305B\u306A\u3044\u306A\u3088\u306A\u3002",
  "id" : 112193597218107394,
  "created_at" : "2011-09-09 16:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112192952641650688",
  "text" : "\u7532\u5B50\u5712\u3067\u306E\u611F\u52D5\u306F\u5168\u304F\u7D4C\u9A13\u304C\u306A\u3044\u3051\u3069\u3001\u3053\u306E\u6587\u53E5\u306F\u89E3\u305B\u306A\u3044\u306A\u3088\u306A\u3002",
  "id" : 112192952641650688,
  "created_at" : "2011-09-09 15:57:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u304F\u307F\u304B\u3093",
      "screen_name" : "takumikan_o",
      "indices" : [ 3, 15 ],
      "id_str" : "148391341",
      "id" : 148391341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112192813000687616",
  "text" : "RT @takumikan_o: \u7532\u5B50\u5712\u3068\u304B\u30B5\u30C3\u30AB\u30FC\u306F\u300C\u611F\u52D5\u3057\u305F\uFF01\u300D\u300C\u52C7\u6C17\u3092\u3082\u3089\u3063\u305F\uFF01\u300D\u306A\u306E\u306B\u3001\u9AD8\u6821\u751F\u30AF\u30A4\u30BA\u3084\u9CE5\u4EBA\u9593\u3084\u30ED\u30DC\u30B3\u30F3\u306F\u300C\u30AA\u30BF\u30AF\u3063\u307D\u3044\u30AD\u30E2\u3044\uFF57\u300D\u300C\u52C9\u5F37\u3067\u304D\u3066\u3082\u306D\u3047\u300D\u3068\u304B\u3002\u306A\u3093\u3067\u306A\u3093\u3067\u3059\u304B\u306D\u3002\u898B\u3066\u3066\u3082\u308F\u304B\u3093\u306A\u3044\u304B\u3089\u6587\u53E5\u8A00\u3044\u305F\u3044\u3060\u3051\u3067\u3057\u3087\u3002\u5F7C\u3089\u3082\u7532\u5B50\u5712\u7403\u5150\u3068\u540C\u3058\u3088\u3046\u306B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112170639472865281",
    "text" : "\u7532\u5B50\u5712\u3068\u304B\u30B5\u30C3\u30AB\u30FC\u306F\u300C\u611F\u52D5\u3057\u305F\uFF01\u300D\u300C\u52C7\u6C17\u3092\u3082\u3089\u3063\u305F\uFF01\u300D\u306A\u306E\u306B\u3001\u9AD8\u6821\u751F\u30AF\u30A4\u30BA\u3084\u9CE5\u4EBA\u9593\u3084\u30ED\u30DC\u30B3\u30F3\u306F\u300C\u30AA\u30BF\u30AF\u3063\u307D\u3044\u30AD\u30E2\u3044\uFF57\u300D\u300C\u52C9\u5F37\u3067\u304D\u3066\u3082\u306D\u3047\u300D\u3068\u304B\u3002\u306A\u3093\u3067\u306A\u3093\u3067\u3059\u304B\u306D\u3002\u898B\u3066\u3066\u3082\u308F\u304B\u3093\u306A\u3044\u304B\u3089\u6587\u53E5\u8A00\u3044\u305F\u3044\u3060\u3051\u3067\u3057\u3087\u3002\u5F7C\u3089\u3082\u7532\u5B50\u5712\u7403\u5150\u3068\u540C\u3058\u3088\u3046\u306B\u9752\u6625\u304B\u3051\u3066\u52AA\u529B\u3057\u3066\u308B\u3093\u3060\u304B\u3089\u5FDC\u63F4\u3057\u306A\u3088\u3002",
    "id" : 112170639472865281,
    "created_at" : "2011-09-09 14:28:59 +0000",
    "user" : {
      "name" : "\u305F\u304F\u307F\u304B\u3093",
      "screen_name" : "takumikan_o",
      "protected" : false,
      "id_str" : "148391341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499019556262653952\/3hm6y5ah_normal.jpeg",
      "id" : 148391341,
      "verified" : false
    }
  },
  "id" : 112192813000687616,
  "created_at" : "2011-09-09 15:57:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112191989394571264",
  "geo" : { },
  "id_str" : "112192724979036161",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u96E3\u3057\u3044\u6CE8\u6587\u3060\u306A\u30FC\uFF57\u3000\u3066\u304B\u3053\u306E\u3084\u308A\u53D6\u308A\u3063\u3066\u5C0F\u5B66\u751F\u304F\u3089\u3044\u306E\u5B50\u4F9B\u3068\u6BCD\u89AA\u3068\u304B\u306E\u3084\u308A\u53D6\u308A\u3058\u3083\u306A\u3044\u304B\uFF57",
  "id" : 112192724979036161,
  "in_reply_to_status_id" : 112191989394571264,
  "created_at" : "2011-09-09 15:56:44 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112190162586439680",
  "geo" : { },
  "id_str" : "112191310915579904",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u77E5\u3089\u306A\u304B\u3063\u305F\u3088\u3002",
  "id" : 112191310915579904,
  "in_reply_to_status_id" : 112190162586439680,
  "created_at" : "2011-09-09 15:51:07 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112182395909840897",
  "geo" : { },
  "id_str" : "112182709719269377",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u5510\u7A81\u904E\u304E\u3066\u30A2\u30EC\u3060\u3051\u3069\u7D50\u5C40\u30CF\u30AF\u30B5\u30A4\u306F\u3069\u3063\u3061\uFF1F",
  "id" : 112182709719269377,
  "in_reply_to_status_id" : 112182395909840897,
  "created_at" : "2011-09-09 15:16:56 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112179499738726400",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 112179499738726400,
  "created_at" : "2011-09-09 15:04:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112179447607721985",
  "text" : "\u306F\u3063\uFF01\u5BDD\u3066\u305F\u3002",
  "id" : 112179447607721985,
  "created_at" : "2011-09-09 15:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112131448416374784",
  "text" : "\u77E5\u308A\u5408\u3044\u306E\u5E74\u4E0A\u597D\u304D\u66F0\u304F\u3001\u5E74\u4E0A\u3060\u3051\u3069\u5C48\u670D\u3055\u305B\u305F\u3044\u7684\u306A\u6B32\u6C42\u304C\u3042\u308B\u3068\u304B\u7121\u3044\u3068\u304B\u3002 RT @i_horse2 \u5E74\u4E0A\u597D\u304D\u306EJC,JK\u3063\u3066\u751F\u610F\u6C17\u306A\u5B50\u304C\u591A\u3044\u30A4\u30E1\u30FC\u30B8(\u00B4\u30FB\u03C9\u30FB\uFF40)",
  "id" : 112131448416374784,
  "created_at" : "2011-09-09 11:53:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112131279243329536",
  "text" : "\u30E9\u30E0\u601D\u3063\u305F\u3088\u308A\u56DE\u308B\u3002\u30DA\u30FC\u30B9\u65E9\u304B\u3063\u305F\u306E\u304C\u307E\u305A\u304B\u3063\u305F\u304B\u3082\u3002",
  "id" : 112131279243329536,
  "created_at" : "2011-09-09 11:52:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112130583932567553",
  "text" : "\u6708\u304C\u3042\u308A\u307E\u305B\u3093\u306B\u7B11\u3063\u305F\u3002\u6B21\u304C\u3042\u308A\u307E\u305B\u3093\u3002",
  "id" : 112130583932567553,
  "created_at" : "2011-09-09 11:49:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9CE5\u30D0\u30FC\u30C9",
      "screen_name" : "tori_bird_",
      "indices" : [ 3, 14 ],
      "id_str" : "85268618",
      "id" : 85268618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112130467561615360",
  "text" : "RT @tori_bird_: \u300C\u6708\u304C\u7DBA\u9E97\u3067\u3059\u306D\u2192\u611B\u3057\u3066\u3044\u307E\u3059\u300D\n\u300C\u6708\u304C\u7DBA\u9E97\u3067\u3057\u305F\u306D\u2192\u611B\u3057\u3066\u3044\u307E\u3057\u305F\u300D\n\u300C\u6708\u304C\u3042\u308A\u307E\u305B\u3093\u2192\u307E\u305A\u597D\u304D\u306A\u4EBA\u304C\u3044\u307E\u305B\u3093\u300D\n\u300C\u6708\u304C\u7DBA\u9E97\u304B\u3082\u77E5\u308C\u307E\u305B\u3093\u2192\u610F\u8B58\u306F\u3057\u3066\u308B\u3051\u3069\u307E\u3060\u3088\u304F\u89E3\u308A\u307E\u305B\u3093\u300D\n\u300C\u6708\u304C\u7DBA\u9E97\u306A\u8A33\u304C\u3042\u308A\u307E\u305B\u3093\u2192\u3079\u3001\u5225\u306B\u3042\u3093\u305F\u306E\u4E8B\u306A\u3093\u304B\u306A\u3093\u3068\u3082 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111757362225889280",
    "text" : "\u300C\u6708\u304C\u7DBA\u9E97\u3067\u3059\u306D\u2192\u611B\u3057\u3066\u3044\u307E\u3059\u300D\n\u300C\u6708\u304C\u7DBA\u9E97\u3067\u3057\u305F\u306D\u2192\u611B\u3057\u3066\u3044\u307E\u3057\u305F\u300D\n\u300C\u6708\u304C\u3042\u308A\u307E\u305B\u3093\u2192\u307E\u305A\u597D\u304D\u306A\u4EBA\u304C\u3044\u307E\u305B\u3093\u300D\n\u300C\u6708\u304C\u7DBA\u9E97\u304B\u3082\u77E5\u308C\u307E\u305B\u3093\u2192\u610F\u8B58\u306F\u3057\u3066\u308B\u3051\u3069\u307E\u3060\u3088\u304F\u89E3\u308A\u307E\u305B\u3093\u300D\n\u300C\u6708\u304C\u7DBA\u9E97\u306A\u8A33\u304C\u3042\u308A\u307E\u305B\u3093\u2192\u3079\u3001\u5225\u306B\u3042\u3093\u305F\u306E\u4E8B\u306A\u3093\u304B\u306A\u3093\u3068\u3082\u601D\u3063\u3066\u306A\u3044\u3093\u3060\u304B\u3089\u306D\u3063\uFF01\u2192\u611B\u3057\u3066\u3044\u307E\u3059\u300D",
    "id" : 111757362225889280,
    "created_at" : "2011-09-08 11:06:46 +0000",
    "user" : {
      "name" : "\u9CE5\u30D0\u30FC\u30C9",
      "screen_name" : "tori_bird_",
      "protected" : false,
      "id_str" : "85268618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1239456596\/bfa2eebe-3f6f-469b-ae37-2155d32113f6__normal.jpg",
      "id" : 85268618,
      "verified" : false
    }
  },
  "id" : 112130467561615360,
  "created_at" : "2011-09-09 11:49:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112128535195418624",
  "text" : "\u30BF\u30A4\u30E0\u30EA\u30FC",
  "id" : 112128535195418624,
  "created_at" : "2011-09-09 11:41:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112124844795117568",
  "text" : "\u30D6\u30EB\u30FC\u30CF\u30EF\u30A4\u3063\u3066\u898B\u308B\u304B\u3089\u306B\u4F53\u306B\u60AA\u305D\u3046\u306A\u8272\u3057\u3066\u308B\u3051\u3069\u304A\u3044\u3057\u3044\u3002",
  "id" : 112124844795117568,
  "created_at" : "2011-09-09 11:27:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112123517620850688",
  "text" : "@nico_reflexio \u304A\u3000\u307E\u3000\u3048\u3000\u304B\u3000\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 112123517620850688,
  "created_at" : "2011-09-09 11:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112119182094643200",
  "text" : "\u3057\u304B\u3057\u512A\u79C0\u306A\u30D0\u30AB\u767A\u898B\u5668\u3067\u3059\u3053\u3068\u3002\u767A\u8A00\u306E\u91CD\u8981\u6027\u304C0\u306B\u53CE\u675F\u3057\u305F\u304B\u3068\u601D\u3048\u3070\u767A\u6563\u2026\u3044\u3084\u3001\u62E1\u6563\u3059\u308B\u3053\u3068\u3082\u3042\u308B\u3002\u4E0D\u601D\u8B70\u306A\u30C4\u30FC\u30EB\u3060\u3002",
  "id" : 112119182094643200,
  "created_at" : "2011-09-09 11:04:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112118682498510848",
  "text" : "\uFF12\u3061\u3083\u3093\u3068\u304B\u306B\u30B9\u30EC\u304C\u7ACB\u3063\u3066\u3044\u308B\u3093\u3060\u308D\u3046\u306A\u3041\u3002\u307E\u3041\u81EA\u5DF1\u8CAC\u4EFB\u304B\u3002",
  "id" : 112118682498510848,
  "created_at" : "2011-09-09 11:02:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112117136129929216",
  "text" : "\u307E\u3001\u3053\u308C\u30A2\u30CB\u30E1\u30A2\u30A4\u30B3\u30F3\u3058\u3083\u306A\u3044\u3051\u3069\uFF57\uFF57\uFF57",
  "id" : 112117136129929216,
  "created_at" : "2011-09-09 10:56:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112116756264386560",
  "text" : "\u3055\u3063\u304D\u306E\u5F7C\u5F35\u308A\u4ED8\u3044\u3066\u307F\u3066\u305F\u3089\u6848\u306E\u5B9A\u708E\u4E0A\u3057\u3066\u3066\u30A2\u30EC\u3002\u5931\u8A00\u3059\u308B\u305F\u3073\u3001\u30D5\u30A9\u30ED\u30EF\u2015\u5897\u3048\u308B\u306D\uFF01",
  "id" : 112116756264386560,
  "created_at" : "2011-09-09 10:54:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112115274534227968",
  "text" : "\u3061\u3087\u3063\u3068\u524D\u306B\u3082\u306A\u3093\u304B\u306E\u5E97\u9577\u304C\u4F3C\u305F\u3088\u3046\u306A\u3053\u3068\u3084\u3063\u3066\u5927\u5909\u3060\u3063\u305F\u306E\u306B\u306D\u3047\u3002\u4E8C\u756A\u714E\u3058\u3002\u3042\u3001\u3055\u3063\u304D\u306E\uFF32\uFF34\u306E\u4EF6\u3060\u3051\u3069\uFF57",
  "id" : 112115274534227968,
  "created_at" : "2011-09-09 10:48:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112115031595958272",
  "text" : "@koketomi \u3042\u3061\u3089\u3053\u3061\u3089\u306B\u30B1\u30F3\u30AB\u58F2\u3063\u3066\u308B\u307F\u305F\u3044\u3060\u306D\u30FC\u3001\u307E\u3041\u9759\u89B3\u3059\u308B\u3051\u3069\u3002",
  "id" : 112115031595958272,
  "created_at" : "2011-09-09 10:48:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112114020621881344",
  "text" : "\u30CD\u30C3\u30C8\u4E0A\u306B\u8DDD\u96E2\u306E\u6982\u5FF5\u3092\u5C0E\u5165\u3059\u308B\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u3088\u3046\u3002",
  "id" : 112114020621881344,
  "created_at" : "2011-09-09 10:44:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112113783580786688",
  "text" : "@koketomi \u3042\u308B\u7A2E\u8150\u3063\u3066\u3044\u308B\u306E\u304B\u3082\u306A\u3002\u307E\u3001\u3053\u3093\u306A\u3053\u3068\u771F\u9762\u76EE\u306B\u8A00\u3048\u308B\u6839\u6027\u3068\u6BD4\u3079\u3089\u308C\u305F\u3089\u306D\u3047\uFF57",
  "id" : 112113783580786688,
  "created_at" : "2011-09-09 10:43:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112108013271261184",
  "text" : "\u4E45\u3005\u306B\u5473\u304C\u6FC3\u304B\u3063\u305F\u306A\u3041\u3002\u548C\u98A8\u30D1\u30B9\u30BF\u3002",
  "id" : 112108013271261184,
  "created_at" : "2011-09-09 10:20:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112102225081417729",
  "text" : "\u6BBA\u3057\u3066\u89E3\u3057\u3066\u4E26\u3079\u3066\u63C3\u3048\u3066\u6652\u3057\u3066\u3084\u3093\u3088\u3002\u7389\u306D\u304E\u3092\u3002",
  "id" : 112102225081417729,
  "created_at" : "2011-09-09 09:57:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112073906868854784",
  "text" : "RT @Kaibun_bot: \u4E16\u754C\u3092\u5D29\u3057\u305F\u3044\u306A\u3089\u3001\u6CE3\u3044\u305F\u96EB\u3092\u751F\u304B\u305B\u3000\uFF08\u305B\u304B\u3044\u3092\u304F\u305A\u3057\u305F\u3044\u306A\u3089\u306A\u3044\u305F\u3057\u305A\u304F\u3092\u3044\u304B\u305B\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 43, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112073244508565504",
    "text" : "\u4E16\u754C\u3092\u5D29\u3057\u305F\u3044\u306A\u3089\u3001\u6CE3\u3044\u305F\u96EB\u3092\u751F\u304B\u305B\u3000\uFF08\u305B\u304B\u3044\u3092\u304F\u305A\u3057\u305F\u3044\u306A\u3089\u306A\u3044\u305F\u3057\u305A\u304F\u3092\u3044\u304B\u305B\uFF09 #kaibun",
    "id" : 112073244508565504,
    "created_at" : "2011-09-09 08:01:58 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 112073906868854784,
  "created_at" : "2011-09-09 08:04:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112058065163010048",
  "text" : "\u3086\u3063\u304F\u308A\u304A\u98A8\u5442\u5165\u3063\u3066\u51FA\u305F\u3089\u30D1\u30A4\u30CA\u30C3\u30D7\u30EB\u30B8\u30E5\u30FC\u30B9\u98F2\u307F\u3064\u3064\u6570\u5B66\u3084\u308B\u3002",
  "id" : 112058065163010048,
  "created_at" : "2011-09-09 07:01:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea ",
      "screen_name" : "heine98",
      "indices" : [ 3, 11 ],
      "id_str" : "1701896556",
      "id" : 1701896556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112056818951405569",
  "text" : "RT @heine98: \u5B6B\u300C\u304A\u3058\u3044\u3061\u3083\u3093\u3001\u3069\u3046\u3057\u3066\u6CD5\u5B66\u90E8\u3068\u7406\u5B66\u90E8\u306F\u4EF2\u60AA\u3044\u306E\uFF1F\u300D\u4FFA\u300C\u305D\u308C\u306F\u306A\u3001\u304B\u3064\u3066\u7406\u7269\u304C\u6CD5\u5B66\u90E8\u751F\u306E\u81EA\u8EE2\u8ECA\u306E\u30B5\u30C9\u30EB\u3092\u3059\u3079\u3066\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u306B\u5909\u3048\u3066\u3057\u307E\u3063\u305F\u3053\u3068\u304C\u3042\u3063\u3066\u306A\u2026\u300D\u5B6B\u300C\uFF08\u4F55\u8A00\u3063\u3066\u3093\u3060\u3053\u306E\u30B8\u30B8\u30A4\uFF09\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112005331223191553",
    "text" : "\u5B6B\u300C\u304A\u3058\u3044\u3061\u3083\u3093\u3001\u3069\u3046\u3057\u3066\u6CD5\u5B66\u90E8\u3068\u7406\u5B66\u90E8\u306F\u4EF2\u60AA\u3044\u306E\uFF1F\u300D\u4FFA\u300C\u305D\u308C\u306F\u306A\u3001\u304B\u3064\u3066\u7406\u7269\u304C\u6CD5\u5B66\u90E8\u751F\u306E\u81EA\u8EE2\u8ECA\u306E\u30B5\u30C9\u30EB\u3092\u3059\u3079\u3066\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u306B\u5909\u3048\u3066\u3057\u307E\u3063\u305F\u3053\u3068\u304C\u3042\u3063\u3066\u306A\u2026\u300D\u5B6B\u300C\uFF08\u4F55\u8A00\u3063\u3066\u3093\u3060\u3053\u306E\u30B8\u30B8\u30A4\uFF09\u300D",
    "id" : 112005331223191553,
    "created_at" : "2011-09-09 03:32:06 +0000",
    "user" : {
      "name" : "\u30CF\u30A4\u30CD\uFF08\u3089\u307D\uFF09",
      "screen_name" : "heine__98",
      "protected" : false,
      "id_str" : "93607250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000757748447\/d432c125b91da28f4dcb39b585910669_normal.jpeg",
      "id" : 93607250,
      "verified" : false
    }
  },
  "id" : 112056818951405569,
  "created_at" : "2011-09-09 06:56:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E5\u30FC\u5B50\uFF08\u308Dbot\uFF09",
      "screen_name" : "DigitalCuko",
      "indices" : [ 17, 29 ],
      "id_str" : "180848288",
      "id" : 180848288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112053923254243328",
  "text" : "\u306A\u3093\u304B\u899A\u3048\u3066\u308B\u307F\u305F\u3044\u3067\u3059\u3057 RT @DigitalCuko: @ \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 112053923254243328,
  "created_at" : "2011-09-09 06:45:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112053259669225472",
  "text" : "\u7406\u4E0D\u5C3D\u3092\u8A34\u3048\u308B\u4E3B\u4F53\u304C\u7406\u4E0D\u5C3D\u3066\u306E\u306F\u30B7\u30CB\u30AB\u30EB\u3060\u3088\u306A\u30FC",
  "id" : 112053259669225472,
  "created_at" : "2011-09-09 06:42:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112053090080927744",
  "text" : "\u3053\u3046\u3044\u3046\u8A00\u8449\u904A\u3073\u306F\u5ACC\u3044\u3058\u3083\u306A\u3044\u306A\u30FC",
  "id" : 112053090080927744,
  "created_at" : "2011-09-09 06:41:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112051969207713792",
  "text" : "\u3042\u308C\uFF1F\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u3066\u30D5\u30E9\u30AF\u30BF\u30EB\u307F\u305F\u3044\u3058\u3083\u306A\u304B\u3063\u305F\u304B\u3057\u3089\u3093\u3002\u5225\u306E\u4F55\u304B\u3068\u52D8\u9055\u3044\u304B\u306A\uFF1F",
  "id" : 112051969207713792,
  "created_at" : "2011-09-09 06:37:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112051065020628992",
  "text" : "\u5C0F\u751F\u3066\u2026\u306A\u3044\u306A",
  "id" : 112051065020628992,
  "created_at" : "2011-09-09 06:33:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112050977762324480",
  "text" : "\u65B0\u3057\u304F\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3082\u3089\u3046\u306E\u306F\u5B09\u3057\u3044\u3051\u3069\u4E00\u4F53\u3069\u3053\u304B\u3089\u5C0F\u751F\u306E\u69D8\u306A\u5730\u5473\u30AD\u30E3\u30E9\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u3092\u307F\u3064\u3051\u3066\u304F\u308B\u306E\u304B\u306F\u7591\u554F\u3067\u3042\u308B\u3002",
  "id" : 112050977762324480,
  "created_at" : "2011-09-09 06:33:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112050102482378752",
  "text" : "\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u3068\u30B5\u30C9\u30EB\u306F\u4F4D\u76F8\u304C\u540C\u3058\u306A\u306E\uFF1F\u30B5\u30C9\u30EB\u306F\u7A74\u304C\u6709\u308A\u305D\u3046\u3060\u3051\u3069",
  "id" : 112050102482378752,
  "created_at" : "2011-09-09 06:30:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "girlydammy",
      "indices" : [ 3, 14 ],
      "id_str" : "494096887",
      "id" : 494096887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112049820532879360",
  "text" : "RT @girlydammy: \u304D\u3063\u3068\u3053\u308C\u306F\u73FE\u4EE3\u30A2\u30FC\u30C8\u3067\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u3068\u30B5\u30C9\u30EB\u3068\u306E\u5DEE\u7570\u3092\u554F\u3044\u304B\u3051\u30C8\u30DD\u30ED\u30B8\u30FC\u7684\u306B\u306F\u540C\u76F8\u3067\u3042\u308B\u3068\u3044\u3046\u3053\u3068\u304C\u4E00\u4F53\u73FE\u5B9F\u3067\u306F\u3069\u3046\u3044\u3063\u305F\u610F\u5473\u3092\u6210\u3059\u306E\u304B\u3068\u3044\u3046\u7D20\u6734\u306A\u7591\u554F\u304B\u3089\u6E29\u91CE\u83DC\u306E\u7F8E\u5473\u3057\u3055\u3092\u601D\u3044\u51FA\u3057\u3066\u6B32\u3057\u3044\u3068\u3044\u3046\u6C17\u6301\u3061\u3092\u8868\u73FE\u3057\u3066\u3044\u308B\u3093\u3060\u308D\u3046\u306A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112001583377686528",
    "text" : "\u304D\u3063\u3068\u3053\u308C\u306F\u73FE\u4EE3\u30A2\u30FC\u30C8\u3067\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u3068\u30B5\u30C9\u30EB\u3068\u306E\u5DEE\u7570\u3092\u554F\u3044\u304B\u3051\u30C8\u30DD\u30ED\u30B8\u30FC\u7684\u306B\u306F\u540C\u76F8\u3067\u3042\u308B\u3068\u3044\u3046\u3053\u3068\u304C\u4E00\u4F53\u73FE\u5B9F\u3067\u306F\u3069\u3046\u3044\u3063\u305F\u610F\u5473\u3092\u6210\u3059\u306E\u304B\u3068\u3044\u3046\u7D20\u6734\u306A\u7591\u554F\u304B\u3089\u6E29\u91CE\u83DC\u306E\u7F8E\u5473\u3057\u3055\u3092\u601D\u3044\u51FA\u3057\u3066\u6B32\u3057\u3044\u3068\u3044\u3046\u6C17\u6301\u3061\u3092\u8868\u73FE\u3057\u3066\u3044\u308B\u3093\u3060\u308D\u3046\u306A",
    "id" : 112001583377686528,
    "created_at" : "2011-09-09 03:17:13 +0000",
    "user" : {
      "name" : "\u3060\u307F\uFF5E",
      "screen_name" : "guiltydammy",
      "protected" : false,
      "id_str" : "204733791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564003099132444673\/HhYGXKBO_normal.png",
      "id" : 204733791,
      "verified" : false
    }
  },
  "id" : 112049820532879360,
  "created_at" : "2011-09-09 06:28:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "takasuke",
      "screen_name" : "kktyk",
      "indices" : [ 3, 9 ],
      "id_str" : "111623811",
      "id" : 111623811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112049798516973568",
  "text" : "RT @kktyk: \u3010\u901F\u5831\u3011\n\u7406\u7269\u304C\u3001\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u3068\u304B\u4F55\u3068\u304B\u3044\u3046\u591A\u9805\u5F0F\u304C\u65E2\u7D04\u3067\u306A\u3044\u4E8B\u3092\u8A3C\u660E\u3002\u81EA\u8EE2\u8ECA\u3068\u304B\u4F55\u3068\u304B\u8A00\u3046\u306E\u3092\u6839\u3068\u3057\u3066\u6301\u3064\u4E8B\u3092\u793A\u3059\u65B9\u91DD\u3060\u3063\u305F\u3089\u3057\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112044603619819520",
    "text" : "\u3010\u901F\u5831\u3011\n\u7406\u7269\u304C\u3001\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u3068\u304B\u4F55\u3068\u304B\u3044\u3046\u591A\u9805\u5F0F\u304C\u65E2\u7D04\u3067\u306A\u3044\u4E8B\u3092\u8A3C\u660E\u3002\u81EA\u8EE2\u8ECA\u3068\u304B\u4F55\u3068\u304B\u8A00\u3046\u306E\u3092\u6839\u3068\u3057\u3066\u6301\u3064\u4E8B\u3092\u793A\u3059\u65B9\u91DD\u3060\u3063\u305F\u3089\u3057\u3044\u3002",
    "id" : 112044603619819520,
    "created_at" : "2011-09-09 06:08:09 +0000",
    "user" : {
      "name" : "takasuke",
      "screen_name" : "kktyk",
      "protected" : false,
      "id_str" : "111623811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677587556\/firefox_normal.jpg",
      "id" : 111623811,
      "verified" : false
    }
  },
  "id" : 112049798516973568,
  "created_at" : "2011-09-09 06:28:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zigen(HN:\u6B21\u5143\u5927\u4ECB)",
      "screen_name" : "zigen",
      "indices" : [ 3, 9 ],
      "id_str" : "15761084",
      "id" : 15761084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112031859269054464",
  "text" : "RT @zigen: \u6771\u4EAC\u5927\u5B66\u3067\u81EA\u8EE2\u8ECA\u306E\u30B5\u30C9\u30EB\u3092\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u306B\u7F6E\u304D\u63DB\u3048\u308B\u3068\u3044\u3046\u884C\u70BA\u304C\u884C\u308F\u308C\u3066\u3044\u308B\u3088\u3046\u3067\u3059\u304C\u3001\u4EAC\u90FD\u5927\u5B66\u3067\u306F\n\u2460\u5927\u5B66\u5074\u304C\u653E\u7F6E\u81EA\u8EE2\u8ECA\u3092\"\u64A4\u53BB\"\u3068\u79F0\u3057\u4ECA\u51FA\u5DDD\u901A\u306E\u3042\u308B\u81EA\u8EE2\u8ECA\u5C4B\u3078\u8EE2\u58F2(?)\u2192\u2461\u81EA\u8EE2\u8ECA\u5C4B\u304C\u4FEE\u7406\u2192\u2462\u65B0\u5165\u751F\u304C\u8CFC\u5165\u2192\u24634\u5E74\u5F8C\u5352\u696D\u751F\u304C\u81EA\u8EE2\u8ECA\u3092\u653E\u7F6E\u2192\u2460\u3063\u3068\u3044\u3046\u81EA\u8EE2 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112012014234247168",
    "text" : "\u6771\u4EAC\u5927\u5B66\u3067\u81EA\u8EE2\u8ECA\u306E\u30B5\u30C9\u30EB\u3092\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u306B\u7F6E\u304D\u63DB\u3048\u308B\u3068\u3044\u3046\u884C\u70BA\u304C\u884C\u308F\u308C\u3066\u3044\u308B\u3088\u3046\u3067\u3059\u304C\u3001\u4EAC\u90FD\u5927\u5B66\u3067\u306F\n\u2460\u5927\u5B66\u5074\u304C\u653E\u7F6E\u81EA\u8EE2\u8ECA\u3092\"\u64A4\u53BB\"\u3068\u79F0\u3057\u4ECA\u51FA\u5DDD\u901A\u306E\u3042\u308B\u81EA\u8EE2\u8ECA\u5C4B\u3078\u8EE2\u58F2(?)\u2192\u2461\u81EA\u8EE2\u8ECA\u5C4B\u304C\u4FEE\u7406\u2192\u2462\u65B0\u5165\u751F\u304C\u8CFC\u5165\u2192\u24634\u5E74\u5F8C\u5352\u696D\u751F\u304C\u81EA\u8EE2\u8ECA\u3092\u653E\u7F6E\u2192\u2460\u3063\u3068\u3044\u3046\u81EA\u8EE2\u8ECA\u64CD\u696D\u304C\u6570\u5341\u5E74\u7D9A\u3044\u3066\u3044\u307E\u3059\u3002",
    "id" : 112012014234247168,
    "created_at" : "2011-09-09 03:58:39 +0000",
    "user" : {
      "name" : "zigen(HN:\u6B21\u5143\u5927\u4ECB)",
      "screen_name" : "zigen",
      "protected" : false,
      "id_str" : "15761084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1458883649\/1000000184_normal.jpg",
      "id" : 15761084,
      "verified" : false
    }
  },
  "id" : 112031859269054464,
  "created_at" : "2011-09-09 05:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "indices" : [ 3, 12 ],
      "id_str" : "161910608",
      "id" : 161910608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112023445893677056",
  "text" : "RT @izugyoza: \u4ECA\u65E5\u4E00\u65E5\u643A\u5E2F\u306E\u5F85\u53D7\u3092\u79C1\u306B\u3059\u308B\u3002 RT  11\u6708\u751F\u307E\u308C\u306A\u306E\u3067\u4ECA\u65E5\u9903\u5B50\u98DF\u3079\u307E\u3059\u3002\u5FD8\u308C\u306A\u3044\u3088\u3046\u306B\u3059\u308B\u306B\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3067\u3057\u3087\u3046\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112023134479204353",
    "text" : "\u4ECA\u65E5\u4E00\u65E5\u643A\u5E2F\u306E\u5F85\u53D7\u3092\u79C1\u306B\u3059\u308B\u3002 RT  11\u6708\u751F\u307E\u308C\u306A\u306E\u3067\u4ECA\u65E5\u9903\u5B50\u98DF\u3079\u307E\u3059\u3002\u5FD8\u308C\u306A\u3044\u3088\u3046\u306B\u3059\u308B\u306B\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3067\u3057\u3087\u3046\uFF1F",
    "id" : 112023134479204353,
    "created_at" : "2011-09-09 04:42:51 +0000",
    "user" : {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "protected" : false,
      "id_str" : "161910608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607820959492370432\/IgL617FR_normal.png",
      "id" : 161910608,
      "verified" : false
    }
  },
  "id" : 112023445893677056,
  "created_at" : "2011-09-09 04:44:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3085\u30FC\u3068",
      "screen_name" : "lochtext",
      "indices" : [ 3, 12 ],
      "id_str" : "66317645",
      "id" : 66317645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/STrR3dz",
      "expanded_url" : "http:\/\/htn.to\/4bQ9Wu",
      "display_url" : "htn.to\/4bQ9Wu"
    } ]
  },
  "geo" : { },
  "id_str" : "112012583598436352",
  "text" : "RT @lochtext: \u3069\u3046\u3057\u3066\u3053\u3046\u306A\u3063\u305F \/ \u3010\u901F\u5831\u3011\u6771\u5927\u3067\u81EA\u8EE2\u8ECA\u306E\u30B5\u30C9\u30EB\u304C\u6B21\u3005\u3068\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u306B\u5909\u3048\u3089\u308C\u308B\u4E8B\u4EF6\u304C\u767A\u751F http:\/\/t.co\/STrR3dz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hatena.ne.jp\/guide\/twitter\" rel=\"nofollow\"\u003EHatena\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 67 ],
        "url" : "http:\/\/t.co\/STrR3dz",
        "expanded_url" : "http:\/\/htn.to\/4bQ9Wu",
        "display_url" : "htn.to\/4bQ9Wu"
      } ]
    },
    "geo" : { },
    "id_str" : "112012282585808896",
    "text" : "\u3069\u3046\u3057\u3066\u3053\u3046\u306A\u3063\u305F \/ \u3010\u901F\u5831\u3011\u6771\u5927\u3067\u81EA\u8EE2\u8ECA\u306E\u30B5\u30C9\u30EB\u304C\u6B21\u3005\u3068\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC\u306B\u5909\u3048\u3089\u308C\u308B\u4E8B\u4EF6\u304C\u767A\u751F http:\/\/t.co\/STrR3dz",
    "id" : 112012282585808896,
    "created_at" : "2011-09-09 03:59:43 +0000",
    "user" : {
      "name" : "\u307F\u3085\u30FC\u3068",
      "screen_name" : "lochtext",
      "protected" : false,
      "id_str" : "66317645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444151902536601600\/4wo0aFPD_normal.jpeg",
      "id" : 66317645,
      "verified" : false
    }
  },
  "id" : 112012583598436352,
  "created_at" : "2011-09-09 04:00:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 21, 30 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 32, 42 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111979856547418113",
  "text" : "\u65B0\u3057\u3044\u306A\u3002\u4F55\u304C\u610F\u5916\u3060\u3063\u305F\u306E\u304B\uFF57\uFF57\uFF57 RT @nisehorn: @end313124 \u3048\u3001\u304A\u306F\u3088\u3046",
  "id" : 111979856547418113,
  "created_at" : "2011-09-09 01:50:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111979464480669696",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 111979464480669696,
  "created_at" : "2011-09-09 01:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111979421656813568",
  "text" : "\u25CB\u25CB\u7537\u5B50\u3068\u304B\u25CB\u25CB\u5973\u5B50\u3068\u304B\u8A00\u3044\u305F\u3044\u3060\u3051\u3058\u3083\u306A\u3044\u306E\u304B\u3001\u3068\u554F\u3044\u305F\u3044",
  "id" : 111979421656813568,
  "created_at" : "2011-09-09 01:49:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111978246538657794",
  "text" : "@gnawty49 \u590F\u306F\u590F\u660E\u3051\u307E\u3067\u501F\u308A\u3089\u308C\u308B\u306E\u3067\u306F\uFF1F",
  "id" : 111978246538657794,
  "created_at" : "2011-09-09 01:44:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111875531686936576",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 111875531686936576,
  "created_at" : "2011-09-08 18:56:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111875284512415745",
  "text" : "\u591C\u4E2D\u3060\u3057\u6D41\u308C\u308B\u3060\u308D\u3046\uFF08\u767D\u76EE",
  "id" : 111875284512415745,
  "created_at" : "2011-09-08 18:55:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111875150282100737",
  "text" : "\u3057\u3087\u3046\u3082\u306A\u3044\u306E\u306F\u3044\u3064\u3082\u3060\u3051\u3069\u3001\u4ECA\u306F\u7720\u3044\u3051\u3069\u7720\u308C\u306A\u3044\u305B\u3044\u306B\u3057\u3088\u3046\u3002",
  "id" : 111875150282100737,
  "created_at" : "2011-09-08 18:54:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111874957356707840",
  "text" : "\u7761\u7720\u306F\u610F\u8B58\u306E\u6D77\u306Eswimming\uFF1F\u3069\u3063\u3061\u304B\u3068\u3044\u3046\u3068\u6F5C\u6C34\uFF1F\u2190\u30BB\u30F3\u30B9\u3044\u3044\u3068\u306F\u601D\u308F\u306A\u3044",
  "id" : 111874957356707840,
  "created_at" : "2011-09-08 18:54:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111874107603288064",
  "text" : "\u5B9F\u88C5\u3067\u304D\u306A\u3044\u3063\uFF01\u307F\u305F\u3044\u306A\u3063\uFF01",
  "id" : 111874107603288064,
  "created_at" : "2011-09-08 18:50:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111873981476384768",
  "text" : "\u6545\u610F\u306B\u770B\u7834",
  "id" : 111873981476384768,
  "created_at" : "2011-09-08 18:50:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IT\u7528\u8A9E\u306B\u604B\u306E\u3092\u3064\u3051\u308B\u3068\u30E2\u30C6\u308B",
      "indices" : [ 11, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111873901977546752",
  "text" : "\u604B\u306E\u30B3\u30F3\u30D1\u30A4\u30EB\u30A8\u30E9\u30FC #IT\u7528\u8A9E\u306B\u604B\u306E\u3092\u3064\u3051\u308B\u3068\u30E2\u30C6\u308B \u604B\u306B\u56F0\u618A\u3001\u604B\u306B\u4E7E\u676F \u9BC9\u306B\u4E7E\u30D1\u30F3",
  "id" : 111873901977546752,
  "created_at" : "2011-09-08 18:49:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3084\u306F\u3066",
      "screen_name" : "yaoihayate",
      "indices" : [ 3, 14 ],
      "id_str" : "292948731",
      "id" : 292948731
    }, {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 20, 29 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111872798527471617",
  "text" : "RT @yaoihayate: \u30CERT @heyakita: \u982D\u306E\u4E2D\u304C\u3086\u308B\u3075\u308F\u3051\u3044\u7537\u5B50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3078\u3084\u304D\u305F",
        "screen_name" : "heyakita",
        "indices" : [ 4, 13 ],
        "id_str" : "100242979",
        "id" : 100242979
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111872734925045761",
    "text" : "\u30CERT @heyakita: \u982D\u306E\u4E2D\u304C\u3086\u308B\u3075\u308F\u3051\u3044\u7537\u5B50",
    "id" : 111872734925045761,
    "created_at" : "2011-09-08 18:45:13 +0000",
    "user" : {
      "name" : "\u3084\u306F\u3066",
      "screen_name" : "yaoihayate",
      "protected" : false,
      "id_str" : "292948731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1850014680\/________normal.jpg",
      "id" : 292948731,
      "verified" : false
    }
  },
  "id" : 111872798527471617,
  "created_at" : "2011-09-08 18:45:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 13, 20 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "\u30EA\u30A3\u30BA feat. \u5DF4\u30DE\u30ED",
      "screen_name" : "Ryiz_Flannel",
      "indices" : [ 25, 38 ],
      "id_str" : "268978972",
      "id" : 268978972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111872165154000899",
  "text" : "\u30E4\u30C9\u30E9\u30F3\u306B\u306F\u5BBF\u3089\u3093 RT @ayu167: RT @Ryiz_Flannel: \u30CB\u30C9\u30AD\u30F3\u30B0\u306B\u30C9\u30C3\u30AD\u30F3\u30B0\u2642",
  "id" : 111872165154000899,
  "created_at" : "2011-09-08 18:42:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111871557328056320",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u307E\u3067\u6620\u753B\u306E\u984C\u540D\u3057\u308A\u3068\u308A\u2026",
  "id" : 111871557328056320,
  "created_at" : "2011-09-08 18:40:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3081\u3063\u3057\u30FC",
      "screen_name" : "edamame3377",
      "indices" : [ 3, 15 ],
      "id_str" : "69502044",
      "id" : 69502044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111844844120440832",
  "text" : "RT @edamame3377: RT\u3010\u5404\u56FD\u306E\u30B9\u30A4\u30AB\u3011\n\u65E5\u672C\u2026\u30B9\u30A4\u30AB\u306B\u5869\u3092\u632F\u308A\u7518\u307F\u3092\u3072\u304D\u305F\u3066\u308B\n\u30A2\u30E1\u30EA\u30AB\u2026\u30B9\u30A4\u30AB\u306B\u7802\u7CD6\u3092\u632F\u308A\u7518\u307F\u3092\u5F37\u8ABF\u3059\u308B\n\u30D5\u30E9\u30F3\u30B9\u2026\u30B9\u30A4\u30AB\u306B\u30EF\u30A4\u30F3\u3092\u639B\u3051\u6DF1\u307F\u3092\u51FA\u3059\n\u30C9\u30A4\u30C4\u2026\u30B9\u30A4\u30AB\u306B\u30D3\u30FC\u30EB\u3092\u639B\u3051\u82E6\u307F\u3092\u3060\u3059\n\u30A4\u30F3\u30C9\u2026\u30B9\u30A4\u30AB\u3092\u30AC\u30F3\u30B8\u30B9\u5DDD\u306B\u6D41\u3057\u6E05\u3081\u308B\n\u97D3\u56FD\u2026\u30B9\u30A4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111726577724829696",
    "text" : "RT\u3010\u5404\u56FD\u306E\u30B9\u30A4\u30AB\u3011\n\u65E5\u672C\u2026\u30B9\u30A4\u30AB\u306B\u5869\u3092\u632F\u308A\u7518\u307F\u3092\u3072\u304D\u305F\u3066\u308B\n\u30A2\u30E1\u30EA\u30AB\u2026\u30B9\u30A4\u30AB\u306B\u7802\u7CD6\u3092\u632F\u308A\u7518\u307F\u3092\u5F37\u8ABF\u3059\u308B\n\u30D5\u30E9\u30F3\u30B9\u2026\u30B9\u30A4\u30AB\u306B\u30EF\u30A4\u30F3\u3092\u639B\u3051\u6DF1\u307F\u3092\u51FA\u3059\n\u30C9\u30A4\u30C4\u2026\u30B9\u30A4\u30AB\u306B\u30D3\u30FC\u30EB\u3092\u639B\u3051\u82E6\u307F\u3092\u3060\u3059\n\u30A4\u30F3\u30C9\u2026\u30B9\u30A4\u30AB\u3092\u30AC\u30F3\u30B8\u30B9\u5DDD\u306B\u6D41\u3057\u6E05\u3081\u308B\n\u97D3\u56FD\u2026\u30B9\u30A4\u30AB\u306E\u8D77\u6E90\u3092\u4E3B\u5F35\u3059\u308B\n\u4E2D\u56FD\u2026\u30B9\u30A4\u30AB\u304C\u7206\u767A\u3059\u308B",
    "id" : 111726577724829696,
    "created_at" : "2011-09-08 09:04:26 +0000",
    "user" : {
      "name" : "\u307E\u3081\u3063\u3057\u30FC",
      "screen_name" : "edamame3377",
      "protected" : false,
      "id_str" : "69502044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000234074098\/30cde07214544382c6434d074e101583_normal.jpeg",
      "id" : 69502044,
      "verified" : false
    }
  },
  "id" : 111844844120440832,
  "created_at" : "2011-09-08 16:54:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111770935920570368",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 111770935920570368,
  "created_at" : "2011-09-08 12:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111724882135482368",
  "text" : "\u3010\u7DE9\u52DF\u3011\u5929\u9CF3\u9EBB\u96C0 \u500B\u5BA4 18\uFF1A15\u4F4D\u304B\u3089\u3002\u8208\u5473\u306E\u3042\u308B\u4EBA\u3001\u8EAB\u5185\u3067\u3082\u305D\u3046\u3067\u306A\u304F\u3066\u3082\u30EA\u30D7\u30E9\u30A4\u3092\u3002",
  "id" : 111724882135482368,
  "created_at" : "2011-09-08 08:57:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111722754956464128",
  "text" : "\u306A\u305C\u304B\u8EAB\u5185\u30CD\u30BF\u307C\u3063\u3068\u304C\u8EAB\u5185\u4EE5\u5916\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u3066\u308B\u3002\u3053\u306E\u30AE\u30E3\u30B0\u30BB\u30F3\u30B9\u306F\u4E00\u822C\u53D7\u3051\u3059\u308B\u306E\u304B\uFF1F",
  "id" : 111722754956464128,
  "created_at" : "2011-09-08 08:49:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111712418866020353",
  "text" : "RT @Kaibun_bot: \u3053\u306E\u5B50\u306E\u30D1\u30D1\u306E\u6BCD\u306F\u5A46\u3001\u5A46\u306E\u6BCD\u306F\u30D1\u30D1\u306E\u5A46\u3001\u30D1\u30D1\u306F\u5A46\u306E\u6BCD\u306E\u5B50\u306E\u5B50 (\u3053\u306E\u3053\u306E\u306F\u306F\u306E\u306F\u306F\u306F\u306F\u306F\u306F\u306F\u306E\u306F\u306F\u306F\u306F\u306F\u306E\u306F\u306F\u306F\u306F\u306F\u306F\u306F\u306E\u306F\u306F\u306E\u3053\u306E\u3053) #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111710875529916416",
    "text" : "\u3053\u306E\u5B50\u306E\u30D1\u30D1\u306E\u6BCD\u306F\u5A46\u3001\u5A46\u306E\u6BCD\u306F\u30D1\u30D1\u306E\u5A46\u3001\u30D1\u30D1\u306F\u5A46\u306E\u6BCD\u306E\u5B50\u306E\u5B50 (\u3053\u306E\u3053\u306E\u306F\u306F\u306E\u306F\u306F\u306F\u306F\u306F\u306F\u306F\u306E\u306F\u306F\u306F\u306F\u306F\u306E\u306F\u306F\u306F\u306F\u306F\u306F\u306F\u306E\u306F\u306F\u306E\u3053\u306E\u3053) #kaibun",
    "id" : 111710875529916416,
    "created_at" : "2011-09-08 08:02:02 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 111712418866020353,
  "created_at" : "2011-09-08 08:08:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sasaki Mitsuya",
      "screen_name" : "Mitchara",
      "indices" : [ 3, 12 ],
      "id_str" : "70004300",
      "id" : 70004300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111707037343301632",
  "text" : "RT @Mitchara: \u300C\u4E0A\u304B\u3089\u76EE\u7DDA\u300D\u3092\u300C\u4FEF\u77B0\u7684\u8996\u70B9\u300D\u3068\u8A00\u3044\u304B\u3048\u308B\u3068\u304B\u3063\u3053\u3044\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111682110867259392",
    "text" : "\u300C\u4E0A\u304B\u3089\u76EE\u7DDA\u300D\u3092\u300C\u4FEF\u77B0\u7684\u8996\u70B9\u300D\u3068\u8A00\u3044\u304B\u3048\u308B\u3068\u304B\u3063\u3053\u3044\u3044",
    "id" : 111682110867259392,
    "created_at" : "2011-09-08 06:07:44 +0000",
    "user" : {
      "name" : "Sasaki Mitsuya",
      "screen_name" : "Mitchara",
      "protected" : false,
      "id_str" : "70004300",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555008435\/owl_normal.jpg",
      "id" : 70004300,
      "verified" : false
    }
  },
  "id" : 111707037343301632,
  "created_at" : "2011-09-08 07:46:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111704640361467906",
  "text" : "\u4EAC\u90FD\u306F\u3082\u3061\u308D\u3093\u307B\u3068\u3093\u3069\u914D\u9001\u7121\u6599\u3060\u3063\u305F\u3002\u3044\u3044\u306D\u3001\u3044\u3044\u306D\u3002",
  "id" : 111704640361467906,
  "created_at" : "2011-09-08 07:37:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "indices" : [ 3, 14 ],
      "id_str" : "161635350",
      "id" : 161635350
    }, {
      "name" : "\u30D6\u30B7\u30ED\u30FC\u30C9\u3044\u3056\u308F",
      "screen_name" : "hibiki_izawa",
      "indices" : [ 23, 36 ],
      "id_str" : "322397652",
      "id" : 322397652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111702792317579264",
  "text" : "RT @kisalantis: \u842C\u3082\u306D\uFF01RT @hibiki_izawa \u6700\u8FD1\u306F\u6570\u5B57\u3084\u8A08\u7B97\u306B\u8972\u308F\u308C\u308B\u65E5\u3005\u2026\uFF01\u540C\u3058\u6570\u5B57\u3067\u3082\u30D4\u30F3\u3084\u7AF9\u3084\u9CE5\u3055\u3093\u306F\u53EF\u611B\u3044\u306E\u306B\u306A\u30FC\u2193\u2193\u203B\u3053\u308C\u3067\u4F1D\u308F\u3063\u305F\u3089\u4EF2\u9593",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30D6\u30B7\u30ED\u30FC\u30C9\u3044\u3056\u308F",
        "screen_name" : "hibiki_izawa",
        "indices" : [ 7, 20 ],
        "id_str" : "322397652",
        "id" : 322397652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111702659806932992",
    "text" : "\u842C\u3082\u306D\uFF01RT @hibiki_izawa \u6700\u8FD1\u306F\u6570\u5B57\u3084\u8A08\u7B97\u306B\u8972\u308F\u308C\u308B\u65E5\u3005\u2026\uFF01\u540C\u3058\u6570\u5B57\u3067\u3082\u30D4\u30F3\u3084\u7AF9\u3084\u9CE5\u3055\u3093\u306F\u53EF\u611B\u3044\u306E\u306B\u306A\u30FC\u2193\u2193\u203B\u3053\u308C\u3067\u4F1D\u308F\u3063\u305F\u3089\u4EF2\u9593",
    "id" : 111702659806932992,
    "created_at" : "2011-09-08 07:29:24 +0000",
    "user" : {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "protected" : false,
      "id_str" : "161635350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451385034910347265\/OhkVStyG_normal.jpeg",
      "id" : 161635350,
      "verified" : false
    }
  },
  "id" : 111702792317579264,
  "created_at" : "2011-09-08 07:29:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111702721303818240",
  "text" : "\u52E2\u3044\u3067\u672C\u68DA\u6CE8\u6587\u3057\u3061\u3083\u3063\u305F\u3002\u3060\u3063\u3066\u3069\u3046\u8003\u3048\u3066\u3082\u7247\u3065\u3051\u3089\u308C\u306A\u3044\u3002",
  "id" : 111702721303818240,
  "created_at" : "2011-09-08 07:29:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "indices" : [ 3, 11 ],
      "id_str" : "115380002",
      "id" : 115380002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111687512178688001",
  "text" : "RT @nedikes: \u5B97\u6559\u300E\u3053\u3046\u751F\u304D\u306A\u3055\u3044\u300F\u3000\n\u54F2\u5B66\u300E\u306A\u305C\u751F\u304D\u308B\u306E\u304B\u300F\u3000\n\u79D1\u5B66\u300E\u751F\u304D\u308B\u3068\u306F\u4F55\u304B\u300F\u3000\n\u6587\u5B66\u300E\u3082\u3057\u3053\u3046\u751F\u304D\u3089\u308C\u305F\u3089\u300F\u3000\n\u82B8\u8853\u300E\u3053\u308C\u304C\u751F\u304D\u308B\u5F62\u3060\u300F\u3000\n\u6B74\u53F2\u300E\u305D\u308C\u304C\u751F\u304D\u305F\u8A3C\u3060\u300F\u3000\n\u7F8E\u5B66\u300E\u305D\u3046\u3084\u3063\u3066\u751F\u304D\u305F\u3044\u300F\u3000\n\u4E16\u8AD6\u300E\u751F\u304D\u3066\u3055\u3048\u3044\u308C\u3070\u3044\u3044\u300F\u3000\n\u533B\u7642\u300E\u751F\u304B\u3057\u3066\u307F\u305B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111088393739452416",
    "text" : "\u5B97\u6559\u300E\u3053\u3046\u751F\u304D\u306A\u3055\u3044\u300F\u3000\n\u54F2\u5B66\u300E\u306A\u305C\u751F\u304D\u308B\u306E\u304B\u300F\u3000\n\u79D1\u5B66\u300E\u751F\u304D\u308B\u3068\u306F\u4F55\u304B\u300F\u3000\n\u6587\u5B66\u300E\u3082\u3057\u3053\u3046\u751F\u304D\u3089\u308C\u305F\u3089\u300F\u3000\n\u82B8\u8853\u300E\u3053\u308C\u304C\u751F\u304D\u308B\u5F62\u3060\u300F\u3000\n\u6B74\u53F2\u300E\u305D\u308C\u304C\u751F\u304D\u305F\u8A3C\u3060\u300F\u3000\n\u7F8E\u5B66\u300E\u305D\u3046\u3084\u3063\u3066\u751F\u304D\u305F\u3044\u300F\u3000\n\u4E16\u8AD6\u300E\u751F\u304D\u3066\u3055\u3048\u3044\u308C\u3070\u3044\u3044\u300F\u3000\n\u533B\u7642\u300E\u751F\u304B\u3057\u3066\u307F\u305B\u308B\u300F\u3000\n\u5F79\u6240\u300E\u751F\u304D\u3066\u3044\u308B\u4E8B\u306B\u3059\u308B\u300F",
    "id" : 111088393739452416,
    "created_at" : "2011-09-06 14:48:31 +0000",
    "user" : {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "protected" : false,
      "id_str" : "115380002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009659425\/___normal.png",
      "id" : 115380002,
      "verified" : false
    }
  },
  "id" : 111687512178688001,
  "created_at" : "2011-09-08 06:29:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111682817011884032",
  "text" : "\u305D\u3046\u3058\u3067\u4E00\u767A\u5909\u63DB\u3067\u76F8\u4F3C\u3063\u3066\u51FA\u308B\u306E\u306F\u4F55\u306A\u306E\u3055",
  "id" : 111682817011884032,
  "created_at" : "2011-09-08 06:10:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111682720907804672",
  "text" : "\u76F8\u4F3C\u3059\u308B\u304B\u30FC\u3002\u3044\u3084\u3001\u6383\u9664\u3060\u3088\u3002",
  "id" : 111682720907804672,
  "created_at" : "2011-09-08 06:10:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111682577533902848",
  "text" : "\u6C17\u304C\u4ED8\u3044\u305F\u3089\uFF33\uFF4F\uFF49\uFF43\uFF48\uFF41\u4ED8\u3044\u3066\u3093\u306E\u306B\uFF33\uFF41\uFF45\uFF5A\uFF55\uFF52i\u8D77\u52D5\u3057\u3066\u305F\u3070\u304B\u308A\u304B\u666E\u901A\u306B\u30D6\u30E9\u30A6\u30B6\u3067\u3082\u30C4\u30A4\u30C3\u30BF\u30FC\u958B\u3044\u3066\u305F\u3002\u767A\u8A00\u5C11\u306A\u3044\u304F\u305B\u306B\u5EC3\u4EBA\u307F\u305F\u3044\u3060\u306A\uFF5E\u2190",
  "id" : 111682577533902848,
  "created_at" : "2011-09-08 06:09:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 21, 30 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111649578499063809",
  "text" : "\u3069\u3046\u3057\u3066\u305D\u3093\u306A\u30AA\u30E2\u30B7\u30ED\u72B6\u614B\u306B\uFF57\uFF57\uFF57 RT @koketomi: \u7D0D\u8C46\u3054\u98EF\u306E\u4E0A\u306B\u4E57\u305B\u305F\u307E\u307E\u3060\u3063\u305F\u3051\u3069\u30A2\u30D1\u30FC\u30C8\u98DB\u3073\u51FA\u3057\u305F",
  "id" : 111649578499063809,
  "created_at" : "2011-09-08 03:58:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111634704591097856",
  "text" : "RT @_flyingmoomin: \u304A\u524D\u304C\u4ECA\u65E5\u8A3C\u660E\u3057\u306A\u304F\u3066\u3082\u3044\u3044\u3084\u3068\u601D\u3063\u305F\u5B9A\u7406\u306F, \u305D\u308C\u3092\u4E88\u60F3\u3057\u305F\u6570\u5B66\u8005\u304C\u6B7B\u306C\u307B\u3069\u8A3C\u660E\u3057\u305F\u304B\u3063\u305F\u5B9A\u7406\u306A\u3093\u3060.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111633922189819905",
    "text" : "\u304A\u524D\u304C\u4ECA\u65E5\u8A3C\u660E\u3057\u306A\u304F\u3066\u3082\u3044\u3044\u3084\u3068\u601D\u3063\u305F\u5B9A\u7406\u306F, \u305D\u308C\u3092\u4E88\u60F3\u3057\u305F\u6570\u5B66\u8005\u304C\u6B7B\u306C\u307B\u3069\u8A3C\u660E\u3057\u305F\u304B\u3063\u305F\u5B9A\u7406\u306A\u3093\u3060.",
    "id" : 111633922189819905,
    "created_at" : "2011-09-08 02:56:15 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 111634704591097856,
  "created_at" : "2011-09-08 02:59:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111628362191085569",
  "text" : "\u3055\u3089\u3063\u3068\u975E\u516C\u5F0FRT",
  "id" : 111628362191085569,
  "created_at" : "2011-09-08 02:34:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 21, 31 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111628068820500480",
  "text" : "\u540C\u611F\uFF01\u524D\u306B\u62BC\u3057\u51FA\u3059\u3079\u304D\u8DA3\u5473\u306B\u975E\u305A\uFF01 RT @dovanyahn: \u30AA\u30BF\u30AF\u306F\u81EA\u6162\u3059\u3079\u304D\u3053\u3068\u3067\u3082\u4F55\u3067\u3082\u306A\u3044\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u3002\u975E\u30AA\u30BF\u30AF\u3082\u3057\u304B\u308A\u3002",
  "id" : 111628068820500480,
  "created_at" : "2011-09-08 02:33:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111627027341254656",
  "geo" : { },
  "id_str" : "111627608348827648",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u4F53\u3092\u3042\u3063\u305F\u3081\u308B\u306E\u304C\u826F\u3044\u3089\u3057\u3044\u3067\u3059\u3088\u30FC\u3002\u307E\u3041\u30DF\u30EB\u30AF\u306E\u307B\u3046\u306F\u6210\u5206\u7684\u306B\u826F\u3044\u3089\u3057\u3044\u306E\u3067\u3059\u304C\u3002\u3042\u3068\u306F\u300C\u98F2\u3093\u3060\u304B\u3089\u7720\u308C\u308B\u305E\u300D\u3063\u3066\u81EA\u5DF1\u6697\u793A\u3067\u3059\u2190",
  "id" : 111627608348827648,
  "in_reply_to_status_id" : 111627027341254656,
  "created_at" : "2011-09-08 02:31:10 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3058\u3057\u3085\u3000\u304D\u305B\u3043",
      "screen_name" : "Jishu_Kisei",
      "indices" : [ 3, 15 ],
      "id_str" : "146480246",
      "id" : 146480246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111626961633288192",
  "text" : "RT @Jishu_Kisei: \u3053\u306E\u5EA6\u306F\u5F53\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u306B\u3054\u5FDC\u52DF\u9802\u3044\u3066\u8AA0\u306B\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002\u8CB4\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u3092\u5BE9\u67FB\u3055\u305B\u3066\u9802\u3044\u305F\u7D50\u679C\u3001\u6B8B\u5FF5\u306A\u304C\u3089\u4ECA\u56DE\u306F\u30D5\u30A9\u30ED\u30FC\u3092\u8FD4\u3057\u304B\u306D\u308B\u3068\u3044\u3046\u7D50\u679C\u306B\u306A\u308A\u307E\u3057\u305F\u3002\u8CB4\u65B9\u306E\u4ECA\u5F8C\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u6D3B\u52D5\u306E\u5065\u95D8\u3092\u304A\u7948\u308A\u7533\u3057\u4E0A\u3052\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59962372563009537",
    "text" : "\u3053\u306E\u5EA6\u306F\u5F53\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u306B\u3054\u5FDC\u52DF\u9802\u3044\u3066\u8AA0\u306B\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002\u8CB4\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u3092\u5BE9\u67FB\u3055\u305B\u3066\u9802\u3044\u305F\u7D50\u679C\u3001\u6B8B\u5FF5\u306A\u304C\u3089\u4ECA\u56DE\u306F\u30D5\u30A9\u30ED\u30FC\u3092\u8FD4\u3057\u304B\u306D\u308B\u3068\u3044\u3046\u7D50\u679C\u306B\u306A\u308A\u307E\u3057\u305F\u3002\u8CB4\u65B9\u306E\u4ECA\u5F8C\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u6D3B\u52D5\u306E\u5065\u95D8\u3092\u304A\u7948\u308A\u7533\u3057\u4E0A\u3052\u307E\u3059\u3002",
    "id" : 59962372563009537,
    "created_at" : "2011-04-18 12:51:58 +0000",
    "user" : {
      "name" : "\u3058\u3057\u3085\u3000\u304D\u305B\u3043",
      "screen_name" : "Jishu_Kisei",
      "protected" : false,
      "id_str" : "146480246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546653894785257472\/i5-YVj2a_normal.jpeg",
      "id" : 146480246,
      "verified" : false
    }
  },
  "id" : 111626961633288192,
  "created_at" : "2011-09-08 02:28:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111626902690734080",
  "text" : "\u4E8C\u65E5\u524D\u304B\u3089\u5148\u4F38\u3070\u3057\u306B\u306A\u3063\u3066\u308B\u30D5\u30EC\u30F3\u30C1\u30C8\u30FC\u30B9\u30C8\u3092\u4F5C\u308D\u3046",
  "id" : 111626902690734080,
  "created_at" : "2011-09-08 02:28:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111626456970432513",
  "geo" : { },
  "id_str" : "111626625539506176",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u3042\u3089\u3089\u3001\u3058\u3083\u3042\u8C46\u4E73\u3068\u304B\uFF1F\u3053\u308C\u3082\u597D\u304D\u5ACC\u3044\u51FA\u3061\u3083\u3044\u307E\u3059\u304C",
  "id" : 111626625539506176,
  "in_reply_to_status_id" : 111626456970432513,
  "created_at" : "2011-09-08 02:27:16 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111626170231037952",
  "geo" : { },
  "id_str" : "111626303823806466",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u3064\u30DB\u30C3\u30C8\u30DF\u30EB\u30AF",
  "id" : 111626303823806466,
  "in_reply_to_status_id" : 111626170231037952,
  "created_at" : "2011-09-08 02:25:59 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111620544075538432",
  "text" : "13\u6642\u9593\u7761\u7720\u304B\u3089\u5E30\u3063\u3066\u304D\u305F\uFF67\uFF01",
  "id" : 111620544075538432,
  "created_at" : "2011-09-08 02:03:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http:\/\/t.co\/KQu8C1v",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=ethyl_a",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "111466207206584321",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001ethyl_a\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/KQu8C1v",
  "id" : 111466207206584321,
  "created_at" : "2011-09-07 15:49:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111384196911611904",
  "text" : "\u3042\u30FC\u3001\u3069\u3070\u306B\u3083\u3093\u3055\u3093\u306E\u30A2\u30A4\u30B3\u30F3\u7A79\u3061\u3083\u3093\u304B\uFF57\u3069\u3053\u304B\u3067\u898B\u305F\u3068\u601D\u3063\u305F\u3089\u3002",
  "id" : 111384196911611904,
  "created_at" : "2011-09-07 10:23:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111368524005519360",
  "text" : "\u304A\u3086\u306F\u3093\u5375\u4E3C\u3068\u30D5\u30EC\u30F3\u30C1\u30C8\u30FC\u30B9\u30C8\u3067\u8FF7\u3046\u3002",
  "id" : 111368524005519360,
  "created_at" : "2011-09-07 09:21:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/04quJQI",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/303871",
      "display_url" : "theinterviews.jp\/end313124\/3038\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "111356475930181633",
  "text" : "\u3069\u3093\u306A\u5B66\u751F\u6642\u4EE3\u3067\u3057\u305F\u304B\uFF1F \u601D\u3044\u51FA\u8A71\u306A\u3069\u3092\u805E\u304B\u305B\u3066\u304F\u3060\u3055\u3044 - end313124 [\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA] #theinterviews http:\/\/t.co\/04quJQI",
  "id" : 111356475930181633,
  "created_at" : "2011-09-07 08:33:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/zK4TNi5",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/303973",
      "display_url" : "theinterviews.jp\/end313124\/3039\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "111356434406576129",
  "text" : "\u5EA7\u53F3\u306E\u9298\u306A\u3069\u3001\u3042\u306A\u305F\u306E\u597D\u304D\u306A\u8A00\u8449\u306F\u3042\u308A\u307E\u3059\u304B\uFF1F - end313124 [\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA] #theinterviews http:\/\/t.co\/zK4TNi5",
  "id" : 111356434406576129,
  "created_at" : "2011-09-07 08:33:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theinterviews",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/T5lHtF4",
      "expanded_url" : "http:\/\/theinterviews.jp\/end313124\/interview",
      "display_url" : "theinterviews.jp\/end313124\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "111335694831587328",
  "text" : "\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3067\u300Cend313124\u3055\u3093\u300D\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3059\u308B #theinterviews http:\/\/t.co\/T5lHtF4 \u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u4F5C\u3063\u3066\u307F\u305F\u3088\u3093\u3002\u805E\u304D\u305F\u3044\u3053\u3068\u304C\u3042\u3063\u305F\u3089\u305C\u3072\u3002",
  "id" : 111335694831587328,
  "created_at" : "2011-09-07 07:11:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111310446790836224",
  "text" : "\u826F\u3044\u6D41\u308C\u3060\u304B\u3089\u4F0A\u7E54\u3068\u306E\u95A2\u4FC2\u3092\u8AAD\u307F\u76F4\u305D\u3046",
  "id" : 111310446790836224,
  "created_at" : "2011-09-07 05:30:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111310327509024768",
  "text" : "\u826F\u3044\u622F\u8A00\u3060\u3063\u305F\uFF01",
  "id" : 111310327509024768,
  "created_at" : "2011-09-07 05:30:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111282148283129856",
  "geo" : { },
  "id_str" : "111283562401103872",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u713C\u30E9\u30FC\u30E1\u30F3\u4E00\u629E",
  "id" : 111283562401103872,
  "in_reply_to_status_id" : 111282148283129856,
  "created_at" : "2011-09-07 03:44:03 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111081156245602305",
  "text" : "@koketomi \u305D\u3053\u305D\u3053\u6687\u3060\u304B\u3089\u9762\u5B50\u629C\u3051\u305D\u3046\u306A\u3089\u8A98\u3063\u3066\u304F\u308C",
  "id" : 111081156245602305,
  "created_at" : "2011-09-06 14:19:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "takasuke",
      "screen_name" : "kktyk",
      "indices" : [ 3, 9 ],
      "id_str" : "111623811",
      "id" : 111623811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111061886652526593",
  "text" : "RT @kktyk: \u4ECA\u65E5\u3001\u6570\u7406\u306E\u53CB\u4EBA\u3092\u3054\u98EF\u306B\u8A98\u3063\u305F\u3089\u3001\u300C\u79C1\u306B\u306F\u300E\u3054\u98EF\u300F\u3068\u3044\u3046\u6982\u5FF5\u304C\u3042\u308A\u307E\u305B\u3093\u300D\u3068\u8A00\u308F\u308C\u307E\u3057\u305F\u3002\n\u305D\u3093\u306A\u5F7C\u304C\u65C5\u884C\u306B\u51FA\u308B\u305D\u3046\u306A\u3093\u3067\u3001\u300C\u304A\u571F\u7523\u3001\u671F\u5F85\u3057\u3066\u307E\u3059\u306D\u3002\u2026\u98DF\u3079\u3089\u308C\u308B\u69D8\u306A\u3002\u300D\u3068\u8A00\u3063\u305F\u6240\u3001\u300C\u2026\u53D7\u3051\u8EAB\uFF1F\u300D\u3068\u805E\u304B\u308C\u307E\u3057\u305F\u3002\n\u2026\u304B\u3042\u3055\u3093\u3001\u6570\u7406\u306F\u3001\u6050\u308D\u3057\u3044\u6240\u3067\u3059\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111056801822289921",
    "text" : "\u4ECA\u65E5\u3001\u6570\u7406\u306E\u53CB\u4EBA\u3092\u3054\u98EF\u306B\u8A98\u3063\u305F\u3089\u3001\u300C\u79C1\u306B\u306F\u300E\u3054\u98EF\u300F\u3068\u3044\u3046\u6982\u5FF5\u304C\u3042\u308A\u307E\u305B\u3093\u300D\u3068\u8A00\u308F\u308C\u307E\u3057\u305F\u3002\n\u305D\u3093\u306A\u5F7C\u304C\u65C5\u884C\u306B\u51FA\u308B\u305D\u3046\u306A\u3093\u3067\u3001\u300C\u304A\u571F\u7523\u3001\u671F\u5F85\u3057\u3066\u307E\u3059\u306D\u3002\u2026\u98DF\u3079\u3089\u308C\u308B\u69D8\u306A\u3002\u300D\u3068\u8A00\u3063\u305F\u6240\u3001\u300C\u2026\u53D7\u3051\u8EAB\uFF1F\u300D\u3068\u805E\u304B\u308C\u307E\u3057\u305F\u3002\n\u2026\u304B\u3042\u3055\u3093\u3001\u6570\u7406\u306F\u3001\u6050\u308D\u3057\u3044\u6240\u3067\u3059\u2026",
    "id" : 111056801822289921,
    "created_at" : "2011-09-06 12:42:59 +0000",
    "user" : {
      "name" : "takasuke",
      "screen_name" : "kktyk",
      "protected" : false,
      "id_str" : "111623811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677587556\/firefox_normal.jpg",
      "id" : 111623811,
      "verified" : false
    }
  },
  "id" : 111061886652526593,
  "created_at" : "2011-09-06 13:03:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111061826560720896",
  "text" : "\u3053\u306E\u5C55\u958B\u306F\u5091\u4F5C\u3060\u305C\u3002\u30CD\u30B3\u30BD\u30AE\u30E9\u30B8\u30AB\u30EB\u4E2D",
  "id" : 111061826560720896,
  "created_at" : "2011-09-06 13:02:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B7\u30FC\u30BF",
      "screen_name" : "Perfect_Insider",
      "indices" : [ 3, 19 ],
      "id_str" : "108894387",
      "id" : 108894387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111048171752398848",
  "text" : "RT @Perfect_Insider: \u81EA\u7136\u79D1\u5B66\u306E\u5358\u8A9E\u306B\u51FA\u3066\u304F\u308B\u300C\u8D85\u300D\u306F\u3044\u308D\u3093\u306A\u8A9E\u306E\u8A33\u304C\u62BC\u3057\u3053\u307E\u308C\u3066\u308B\u3002\u300C\u8D85\u4F1D\u5C0E\u300D\u306F\u300Csuper\u300D\u3001\u300C\u8D85\u6570\u5B66\u300D\u306F\u300Cmeta\u300D\u3001\u300C\u8D85\u77ED\u6CE2\u300D\u306F\u300Cvery\u300D\u3001\u300C\u8D85\u97F3\u6CE2\u300D\u306F\u300Cultra\u300D\u3001\u300C\u8D85\u5E73\u9762\u300D\u306F\u300Chyper\u300D\u3001\u300C\u8D85\u5B8C\u5099\u6027\u300D\u306F\u300Cover\u300D\u3002\u3061 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110998591576866816",
    "text" : "\u81EA\u7136\u79D1\u5B66\u306E\u5358\u8A9E\u306B\u51FA\u3066\u304F\u308B\u300C\u8D85\u300D\u306F\u3044\u308D\u3093\u306A\u8A9E\u306E\u8A33\u304C\u62BC\u3057\u3053\u307E\u308C\u3066\u308B\u3002\u300C\u8D85\u4F1D\u5C0E\u300D\u306F\u300Csuper\u300D\u3001\u300C\u8D85\u6570\u5B66\u300D\u306F\u300Cmeta\u300D\u3001\u300C\u8D85\u77ED\u6CE2\u300D\u306F\u300Cvery\u300D\u3001\u300C\u8D85\u97F3\u6CE2\u300D\u306F\u300Cultra\u300D\u3001\u300C\u8D85\u5E73\u9762\u300D\u306F\u300Chyper\u300D\u3001\u300C\u8D85\u5B8C\u5099\u6027\u300D\u306F\u300Cover\u300D\u3002\u3061\u306A\u307F\u306B\u300C\u8D85\u6E96\u89E3\u6790\u300D\u306F\u300CNon-standard\u300D",
    "id" : 110998591576866816,
    "created_at" : "2011-09-06 08:51:41 +0000",
    "user" : {
      "name" : "\u30B7\u30FC\u30BF",
      "screen_name" : "Perfect_Insider",
      "protected" : false,
      "id_str" : "108894387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595611044661198848\/Q28LODTo_normal.jpg",
      "id" : 108894387,
      "verified" : false
    }
  },
  "id" : 111048171752398848,
  "created_at" : "2011-09-06 12:08:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111046260408061953",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 111046260408061953,
  "created_at" : "2011-09-06 12:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111030411110526977",
  "text" : "\u30CD\u30B3\u30BD\u30AE\u30E9\u30B8\u30AB\u30EB\u3092\u307E\u3068\u3081\u3066\u8AAD\u3080\uFF01",
  "id" : 111030411110526977,
  "created_at" : "2011-09-06 10:58:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9580\u5009\u4E9C\u4EBA",
      "screen_name" : "art_kdkr",
      "indices" : [ 3, 12 ],
      "id_str" : "114129213",
      "id" : 114129213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111028283952472064",
  "text" : "RT @art_kdkr: \u3042\u3068\u4E00\u7AE0\u3092\u6B8B\u3059\u306E\u307F\u3068\u306A\u3063\u305F\u6570\u5B66\u66F8\u3092\u524D\u306B\u3057\u3066\u3001\u300C\u30B1\u30EA\u3092\u3064\u3051\u3088\u3046\u305C\u3001\u516B\u795E\u300D\u300C\u8CB4\u69D8\u306E\u6B7B\u3092\u3082\u3063\u3066\u306A\u300D\u307F\u305F\u3044\u306A\u76DB\u308A\u4E0A\u304C\u308A\u3092\u898B\u305B\u3066\u3044\u308B\u306A\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110976821130047488",
    "text" : "\u3042\u3068\u4E00\u7AE0\u3092\u6B8B\u3059\u306E\u307F\u3068\u306A\u3063\u305F\u6570\u5B66\u66F8\u3092\u524D\u306B\u3057\u3066\u3001\u300C\u30B1\u30EA\u3092\u3064\u3051\u3088\u3046\u305C\u3001\u516B\u795E\u300D\u300C\u8CB4\u69D8\u306E\u6B7B\u3092\u3082\u3063\u3066\u306A\u300D\u307F\u305F\u3044\u306A\u76DB\u308A\u4E0A\u304C\u308A\u3092\u898B\u305B\u3066\u3044\u308B\u306A\u3046",
    "id" : 110976821130047488,
    "created_at" : "2011-09-06 07:25:10 +0000",
    "user" : {
      "name" : "\u9580\u5009\u4E9C\u4EBA",
      "screen_name" : "art_kdkr",
      "protected" : false,
      "id_str" : "114129213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583504268184780800\/5wHgRBC5_normal.jpg",
      "id" : 114129213,
      "verified" : false
    }
  },
  "id" : 111028283952472064,
  "created_at" : "2011-09-06 10:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111025018166710272",
  "text" : "@koketomi \u30AA\u30FC\u30C8\u30DE\u3067\u554F\u984C\u7121\u3044\u3002\u8ECA\u597D\u304D\u3067\u30DE\u30CB\u30E5\u30A2\u30EB\u8ECA\u306B\u4E57\u308A\u305F\u3044\u3068\u304B\u306A\u3089\u5225\u3060\u304C\u5408\u7406\u7684\u306A\u9078\u629E\u3060\u3002",
  "id" : 111025018166710272,
  "created_at" : "2011-09-06 10:36:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111024455798636544",
  "text" : "\u3042\u308C\u3001\u3082\u304619\u664230\u5206\u306A\u306E\u304B",
  "id" : 111024455798636544,
  "created_at" : "2011-09-06 10:34:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110981107788414977",
  "text" : "\u3082\u3046\u4E00\u65E5\u3067\u751F\u6D3B\u30EA\u30BA\u30E0\u304C\u58CA\u308C\u3066\u3057\u307E\u3063\u305F\u3002\u3002\u3002",
  "id" : 110981107788414977,
  "created_at" : "2011-09-06 07:42:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110372183519408128",
  "geo" : { },
  "id_str" : "110372936485056513",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u4E00\u5FDC\u30B3\u30F3\u30BF\u30AF\u30C8\u7533\u8ACB\u3057\u3066\u304A\u3044\u305F\u3088\u3093",
  "id" : 110372936485056513,
  "in_reply_to_status_id" : 110372183519408128,
  "created_at" : "2011-09-04 15:25:33 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110363087122604033",
  "geo" : { },
  "id_str" : "110364256196767744",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori 0\u664230\u5206\u4F4D\u307E\u3067\u306A\u3089",
  "id" : 110364256196767744,
  "in_reply_to_status_id" : 110363087122604033,
  "created_at" : "2011-09-04 14:51:03 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 10, 21 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 22, 32 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110362809707143168",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 @akiyohmori @blackpiyu \u307E\u3041\u4ECA\u5F8C\u3053\u306E\u624B\u306E\u306F\u30B9\u30AB\u30A4\u30D7\u304B\u306A\u3093\u304B\u3067\u3084\u308A\u307E\u3057\u3087\u3002\u611A\u75F4\u805E\u304F\u306E\u5ACC\u3044\u3058\u3083\u306A\u3044\u3057\u2190",
  "id" : 110362809707143168,
  "created_at" : "2011-09-04 14:45:18 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110361785797840896",
  "text" : "\u30AF\u30E9\u30A4\u30D0\u30F3\uFF08\u30AF\u30EA\u30D0\u30F3\uFF1F\uFF09\u30AD\u30E3\u30C3\u30C8\u3068\u3044\u3046\u60DA\u3051\u305F\u8868\u60C5\u306E\u732B\u306E\u30A4\u30E9\u30B9\u30C8\u77E5\u3063\u3066\u308B\u4EBA\u3044\u307E\u3059\u30FC\uFF1F",
  "id" : 110361785797840896,
  "created_at" : "2011-09-04 14:41:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 12, 21 ],
      "id_str" : "256321768",
      "id" : 256321768
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 22, 32 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110361041648623617",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @mar1e666 @blackpiyu \u3042\u3001\u3053\u306E\u4F1A\u8A71\u3082\u826F\u304F\u306A\u3044\u3063\u3066\u8A00\u304A\u3046\u3068\u3057\u305F\u77E2\u5148\u3002\u3053\u3053\u3089\u3067\u304A\u958B\u304D\u306B\u3057\u307E\u3057\u3087\u3002\u5F7C\u306B\u306F\u30EA\u30F3\u30AF\u4E91\u3005\u306B\u3064\u3044\u3066\u306F\u30E1\u30FC\u30EB\u3057\u3068\u304F\u308F\u3002",
  "id" : 110361041648623617,
  "created_at" : "2011-09-04 14:38:17 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 10, 20 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110358642049552384",
  "geo" : { },
  "id_str" : "110359892484820993",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 @blackpiyu mixi\u306B\u610F\u5730\u60AA\u306A\u611F\u3058\u306E\u30B3\u30E1\u30F3\u30C8\u3057\u3061\u3083\u3063\u3066\u3044\u3044\u304B\u306D\uFF1F\uFF57\n\u78BA\u8A8D\u3057\u305F\u3051\u3069\u3053\u308C\u306F\u30A4\u30E9\u30C3\u3068\u3059\u308B\u308F\u3002",
  "id" : 110359892484820993,
  "in_reply_to_status_id" : 110358642049552384,
  "created_at" : "2011-09-04 14:33:43 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 10, 20 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 21, 32 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110355330965323776",
  "geo" : { },
  "id_str" : "110357723673137152",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 @blackpiyu @akiyohmori \u53EF\u80FD\u6027\u3068\u3057\u3066\u3069\u3053\u306B\u884C\u3053\u3046\u3068\u6B63\u89E3\u3082\u8AA4\u308A\u3082\u3042\u308B\u306E\u306B\u306D\u3047\u3002\u305D\u306E\u8FBA\u306E\u914D\u616E\u2026\u3068\u8A00\u3046\u3088\u308A\u601D\u616E\u306F\u8DB3\u308A\u3066\u306A\u3044\u3088\u306D\u3002\n\u30C4\u30A4\u30C3\u30BF\u30FC\u3068mixi\u306E\u30EA\u30F3\u30AF\u6A5F\u80FD\u304B\u306D\u30FC\u3002\u9055\u3046\u30B5\u30A4\u30C8\u306A\u3093\u3060\u304B\u3089\u30EA\u30F3\u30AF\u3059\u308B\u3053\u3068\u306A\u3044\u3060\u308D\u3046\u306B\u3001\u3063\u3066\u306E\u306F\u6301\u8AD6\u3060\u3051\u3069\u3002",
  "id" : 110357723673137152,
  "in_reply_to_status_id" : 110355330965323776,
  "created_at" : "2011-09-04 14:25:06 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u305D\u307F\u3093@4\u9BD6\u3067\u30A2\u30FC\u30AF\u30B9\u3084\u3063\u3066\u307E\u3059",
      "screen_name" : "arukanova",
      "indices" : [ 0, 10 ],
      "id_str" : "272723823",
      "id" : 272723823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110354125572677632",
  "geo" : { },
  "id_str" : "110354659587276800",
  "in_reply_to_user_id" : 272723823,
  "text" : "@arukanova \u4E8C\u3064\u306B\u5206\u3051\u308B\u304B\u3089\u3067\u3059\u3088\u3045\u3002\u307E\u3001\u30D1\u30C1\u30A7\u3067\u3002",
  "id" : 110354659587276800,
  "in_reply_to_status_id" : 110354125572677632,
  "created_at" : "2011-09-04 14:12:55 +0000",
  "in_reply_to_screen_name" : "arukanova",
  "in_reply_to_user_id_str" : "272723823",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u305D\u307F\u3093@4\u9BD6\u3067\u30A2\u30FC\u30AF\u30B9\u3084\u3063\u3066\u307E\u3059",
      "screen_name" : "arukanova",
      "indices" : [ 0, 10 ],
      "id_str" : "272723823",
      "id" : 272723823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110353172907823104",
  "geo" : { },
  "id_str" : "110353799318745088",
  "in_reply_to_user_id" : 272723823,
  "text" : "@arukanova \u30D1\u30C1\u30A7\u963B\u6B62",
  "id" : 110353799318745088,
  "in_reply_to_status_id" : 110353172907823104,
  "created_at" : "2011-09-04 14:09:30 +0000",
  "in_reply_to_screen_name" : "arukanova",
  "in_reply_to_user_id_str" : "272723823",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u305D\u307F\u3093@4\u9BD6\u3067\u30A2\u30FC\u30AF\u30B9\u3084\u3063\u3066\u307E\u3059",
      "screen_name" : "arukanova",
      "indices" : [ 0, 10 ],
      "id_str" : "272723823",
      "id" : 272723823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110351396255186944",
  "geo" : { },
  "id_str" : "110353330848530432",
  "in_reply_to_user_id" : 272723823,
  "text" : "@arukanova \u30B1\u30ED\u3061\u3083\u3093\u963B\u6B62\u3063",
  "id" : 110353330848530432,
  "in_reply_to_status_id" : 110351396255186944,
  "created_at" : "2011-09-04 14:07:38 +0000",
  "in_reply_to_screen_name" : "arukanova",
  "in_reply_to_user_id_str" : "272723823",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110352852668518401",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu \u307E\u3041\u751F\u6696\u304B\u3044\u76EE\u3067\u898B\u3066\u307F\u3088\u3046\u3002\u30C4\u30A4\u30C3\u30BF\u30FC\u3068mixi\u3060\u3068\u307E\u305F\u9055\u3046\u304B\u3082\u3060\u3051\u3069\u3002\u81EA\u5206\u3082\u602A\u3057\u3044\u3068\u3053\u3042\u308B\u304B\u3089\u6559\u8A13\u3002",
  "id" : 110352852668518401,
  "created_at" : "2011-09-04 14:05:44 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110351642976714752",
  "text" : "\u3055\u3063\u304D\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u534A\u89D2\u30B9\u30DA\u30FC\u30B9\u3060\u3051\u3044\u308C\u3066\u975E\u516C\u5F0FRT\u3057\u3088\u3046\u3068\u3057\u305F\u4EBA\u306F\u4F55\u4EBA\u3044\u308B\u304B\u306A\uFF57\uFF57\uFF57\n\u304A\u3063\u3001\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3082\u307E\u3060\u5371\u306A\u3044\u306A",
  "id" : 110351642976714752,
  "created_at" : "2011-09-04 14:00:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110351325539221504",
  "text" : "\u975E\u516C\u5F0FRT\u306E\u300CRT\u300D\u306E\u524D\u306B\u534A\u89D2\u30B9\u30DA\u30FC\u30B9\u3092\u5165\u308C\u308B\u30AF\u30E9\u30B9\u30BF",
  "id" : 110351325539221504,
  "created_at" : "2011-09-04 13:59:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110350545612570625",
  "text" : "\u307E\u3001\u610F\u898B\u4EA4\u63DB\u3068\u304B\u6279\u5224\u3092\u53D7\u3051\u308B\u5834\u3068\u3057\u3066\u306F\u7D20\u6674\u3089\u3057\u3044\u306E\u306F\u8A00\u3046\u307E\u3067\u3082\u306A\u3044",
  "id" : 110350545612570625,
  "created_at" : "2011-09-04 13:56:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110350324161716224",
  "text" : "\u771F\u306B\u81EA\u5206\u306E\u8003\u3048\u3092\u7E8F\u3081\u305F\u3044\u306A\u3089\u7D19\u5A92\u4F53\u304B\u3001\u5BFE\u8A71\u3092\u901A\u3058\u3066\u3084\u3063\u305F\u65B9\u304C\u3044\u3044\u3093\u3060\u308D\u3046\u306A\u3002\u4E0D\u7279\u5B9A\u591A\u6570\u306E\u76EE\u304C\u3042\u308B\u3068\u3069\u3046\u3057\u3066\u3082\u72EC\u308A\u3088\u304C\u308A\u306B\u306A\u308B\u6C17\u304C\u3002\n\n\u2191\u3053\u306E\u3064\u3076\u3084\u304D\u3082\u4F8B\u306B\u6F0F\u308C\u306A\u3044",
  "id" : 110350324161716224,
  "created_at" : "2011-09-04 13:55:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110349681174913025",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u524D\u304B\u3089\u3042\u3093\u306A\u3093\u3060\u3051\u3069\u306D\u30FC\u3001\u6839\u306F\u3044\u3044\u5B50\u306A\u3093\u3060\u3051\u3069\u3002\u3080\u3057\u308D\u81EA\u4FE1\u304C\u306A\u3044\u304B\u3089mixi\u306E\u7D20\u6575\u306A\u4EF2\u9593\u306B\u80AF\u5B9A\u3057\u3066\u6B32\u3057\u3044\u3001\u3063\u3066\u306E\u3082\u7121\u610F\u8B58\u306B\u3042\u308B\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u30FC\u3002\u3053\u308C\u3082\u3053\u308C\u3067\u7A7F\u3063\u305F\u898B\u65B9\u3060\u3051\u3069\u3002\n\n\u305D\u3057\u3066\u3053\u308C\u3082\u9577\u6587\u3067\u7533\u3057\u8A33\u306A\u3044\u3002",
  "id" : 110349681174913025,
  "created_at" : "2011-09-04 13:53:08 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/JIzh8MJ",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kenigooon",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "110349136821354496",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kenigooon\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/JIzh8MJ",
  "id" : 110349136821354496,
  "created_at" : "2011-09-04 13:50:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/4TSCKRD",
      "expanded_url" : "http:\/\/shindanmaker.com\/151388",
      "display_url" : "shindanmaker.com\/151388"
    } ]
  },
  "geo" : { },
  "id_str" : "110347635004669952",
  "text" : "end313124\u3000\u306E\u3000\u672C\u3000\u6027\u3000\u300C\u3000\u6687\u3000\u3092\u3000\u6301\u3000\u3066\u3000\u4F59\u3000\u3057\u3000\u3066\u3000\u3044\u3000\u308B\u3000\u300D http:\/\/t.co\/4TSCKRD  \n\u9055\u3046\u306A\u3002\u6687\u304C\u4FFA\u3092\u6301\u3066\u4F59\u3057\u3066\u308B\u3093\u3060\uFF01\uFF08\uFF77\uFF98\uFF6F",
  "id" : 110347635004669952,
  "created_at" : "2011-09-04 13:45:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110347064906493953",
  "text" : "\u771F\u9762\u76EE\u306F\u4E0D\u771F\u9762\u76EE\u306B\u7E4B\u304C\u308B\u597D\u4F8B",
  "id" : 110347064906493953,
  "created_at" : "2011-09-04 13:42:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110346561296408576",
  "geo" : { },
  "id_str" : "110346945708568576",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u30C4\u30A4\u30C3\u30BF\u30FC\u307B\u3069\u6D41\u308C\u304C\u306A\u3044\u3076\u3093\u30C1\u30E9\u30B7\u306E\u88CF\u611F\u304C\u9177\u3044",
  "id" : 110346945708568576,
  "in_reply_to_status_id" : 110346561296408576,
  "created_at" : "2011-09-04 13:42:16 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110346679231852545",
  "text" : "\u3061\u3087\u3063\u3068\u306F\u771F\u9762\u76EE\u306B\u306A\u3063\u305F\u304B\u306A\uFF1F\u2190",
  "id" : 110346679231852545,
  "created_at" : "2011-09-04 13:41:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 53 ],
      "url" : "http:\/\/t.co\/YjzcpVn",
      "expanded_url" : "http:\/\/shindanmaker.com\/152637",
      "display_url" : "shindanmaker.com\/152637"
    } ]
  },
  "geo" : { },
  "id_str" : "110346572738478080",
  "text" : "\u795E\u69D8\u304B\u3089end313124\u3078\u4E00\u8A00\u3000\u795E\u69D8\u300C\u3082\u3046\u3061\u3087\u3044\u771F\u9762\u76EE\u306B\u306A\u308C\u3088\u300D http:\/\/t.co\/YjzcpVn \u300C\u3082\u3046\u3061\u3087\u3044\u300D\u3063\u3066\u4F55\u3060\u3002\u5B9A\u91CF\u7684\u306B\u8A00\u3063\u3066\u304F\u308C\u3002\u771F\u9762\u76EE\u3063\u3066\u3069\u3046\u3084\u3063\u3066\u91CF\u308B\u306E\u304B\u8A73\u3057\u304F\u6559\u3048\u3066\u304F\u308C\u3002",
  "id" : 110346572738478080,
  "created_at" : "2011-09-04 13:40:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110345356033789952",
  "text" : "\u3086\u306E\u4EBA\u30CF\u30A4\u30BB\u30F3\u30B9\uFF01",
  "id" : 110345356033789952,
  "created_at" : "2011-09-04 13:35:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110344682910920704",
  "text" : "\u3044\u3084\u3001\u660E\u78BA\u306A\u7406\u7531\u306F\u306A\u304F\u3066\u3082\u30B6\u30C3\u3068\u3069\u3093\u306A\u4EBA\u306A\u306E\u304B\u308F\u304B\u3093\u306A\u3044\u3068\u30A2\u30EC",
  "id" : 110344682910920704,
  "created_at" : "2011-09-04 13:33:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110344488949530624",
  "text" : "\u306A\u3093\u3064\u30FC\u304B\u3001\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u306B\u3042\u3093\u307E\u308A\u66F8\u3044\u3066\u306A\u3044\u4EBA\u3063\u3066\u30D5\u30A9\u30ED\u30FC\u8FD4\u3057\u306B\u304F\u3044\u306E\u306F\u81EA\u5206\u3060\u3051\uFF1F\u306A\u3093\u3067\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u305F\u306E\u304B\u308F\u304B\u3093\u306A\u3044\u3068\u306A\u304A\u3055\u3089\u3002",
  "id" : 110344488949530624,
  "created_at" : "2011-09-04 13:32:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110343166103785472",
  "text" : "\u66F8\u3044\u3066\u3066\u304A\u8179\u6E1B\u3063\u305F\u3002\u304A\u3086\u306F\u309317\u6642\u524D\u3060\u3063\u305F\u306A\u3002",
  "id" : 110343166103785472,
  "created_at" : "2011-09-04 13:27:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110342989150298113",
  "text" : "\u306A\u3093\u3068\u306A\u304F\u9903\u5B50\u3067\u3054\u98EF\u98DF\u3079\u306B\u304F\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u5B9F\u5BB6\u306E\u304C\u91CE\u83DC\u9903\u5B50\u3060\u304B\u3089\u304B\u306A\u30FC\u3002",
  "id" : 110342989150298113,
  "created_at" : "2011-09-04 13:26:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110342243923140609",
  "text" : "\u9903\u5B50\u306F\u304A\u304B\u305A\uFF1F",
  "id" : 110342243923140609,
  "created_at" : "2011-09-04 13:23:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110342176461946880",
  "text" : "\u5225\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u3066\u306A\u3044\u3072\u3068\u304B\u3089\u306E\u30EA\u30D7\u30E9\u30A4\u3082\u5927\u6B53\u8FCE\u3067\u3059\u3002\u30C4\u30C3\u30B3\u30DF\u3068\u304B\uFF1F\n\u696D\u8005\u306F\u9664\u304F",
  "id" : 110342176461946880,
  "created_at" : "2011-09-04 13:23:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/iJf1lXF",
      "expanded_url" : "http:\/\/shindanmaker.com\/152344",
      "display_url" : "shindanmaker.com\/152344"
    } ]
  },
  "geo" : { },
  "id_str" : "110341611606642688",
  "text" : "\u3010\u885D\u6483\u306E\u544A\u767D\uFF01\u3011\u3000end313124\u300C\u79C1\u3001\u5B9F\u306F\u5984\u60F3\u3070\u3063\u304B\u308A\u3057\u3066\u308B\u3093\u3067\u3059\uFF01\u300D http:\/\/t.co\/iJf1lXF  \u4E2D\u8EAB\u306F\u6709\u6599\u8AB2\u91D1\u30B3\u30F3\u30C6\u30F3\u30C4\u3067\u3059\u3057",
  "id" : 110341611606642688,
  "created_at" : "2011-09-04 13:21:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110341344366563328",
  "text" : "\u3061\u3087\u3044\u3068\u904A\u3093\u3060\u3089\u5BDD\u308B\u3063\u3002\u7720\u3044\u3063\u3002",
  "id" : 110341344366563328,
  "created_at" : "2011-09-04 13:20:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110321362295463936",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 110321362295463936,
  "created_at" : "2011-09-04 12:00:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110315741814861824",
  "text" : "RT @_flyingmoomin: \u6570\u5B66\u66F8\u8AAD\u3093\u3067\u305F\u3089\n\u300E\u3082\u3046\uFF01\u3000\u8AAC\u660E\u3057\u306A\u304F\u3066\u3082\u5206\u304B\u3063\u3066\u3088... \/\/ \u300F\n\u307F\u305F\u3044\u306A\u3053\u3068\u66F8\u3044\u3066\u3042\u3063\u305F. \u53EF\u611B\u3044\u3055\u4F59\u3063\u3066\u618E\u3055100\u500D\u3067\u3042\u308B.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110315195125088256",
    "text" : "\u6570\u5B66\u66F8\u8AAD\u3093\u3067\u305F\u3089\n\u300E\u3082\u3046\uFF01\u3000\u8AAC\u660E\u3057\u306A\u304F\u3066\u3082\u5206\u304B\u3063\u3066\u3088... \/\/ \u300F\n\u307F\u305F\u3044\u306A\u3053\u3068\u66F8\u3044\u3066\u3042\u3063\u305F. \u53EF\u611B\u3044\u3055\u4F59\u3063\u3066\u618E\u3055100\u500D\u3067\u3042\u308B.",
    "id" : 110315195125088256,
    "created_at" : "2011-09-04 11:36:06 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 110315741814861824,
  "created_at" : "2011-09-04 11:38:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110315345927090176",
  "text" : "\u3082\u3046\u7720\u3044\u3057\u3002\u914D\u9054\u306E\u304A\u5144\u3055\u3093\u3042\u308A\u304C\u3068\u3046\u3001\u30EA\u30BA\u30E0\u304C\u5065\u5168\u306B\u623B\u308A\u305D\u3046\u3067\u3059\u3002",
  "id" : 110315345927090176,
  "created_at" : "2011-09-04 11:36:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 14, 23 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110258227559661568",
  "text" : "\u5EC3\u4EBA\u306F\u7686\u305D\u3046\u8A00\u3046\u304C\u306A RT @koketomi: \u3064\u3044\u3063\u305F\u5EC3\u4EBA\u3067\u306F\u306A\u3044",
  "id" : 110258227559661568,
  "created_at" : "2011-09-04 07:49:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "indices" : [ 3, 12 ],
      "id_str" : "161910608",
      "id" : 161910608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110246371591864320",
  "text" : "RT @izugyoza: \u30DE\u30DE\u306B\u9903\u5B50\u306F\u51B7\u51CD\u5EAB\u306B\u3042\u308B\u304B\u3089\u306D\u3063\u3066\u8A00\u308F\u308C\u305F\u3093\u3060\u3051\u3069\u2026\u306A\u3093\u304B\u9903\u5B50\u98DF\u3079\u305F\u304F\u306A\u3044\u306E(&gt;_&lt;)\u6628\u65E5\u306E\u591C\u5927\u91CF\u306B\u9903\u5B50\u98DF\u3079\u307E\u304F\u3063\u305F\u3060\u3051\u3060\u3051\u3069\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110245364015185920",
    "text" : "\u30DE\u30DE\u306B\u9903\u5B50\u306F\u51B7\u51CD\u5EAB\u306B\u3042\u308B\u304B\u3089\u306D\u3063\u3066\u8A00\u308F\u308C\u305F\u3093\u3060\u3051\u3069\u2026\u306A\u3093\u304B\u9903\u5B50\u98DF\u3079\u305F\u304F\u306A\u3044\u306E(&gt;_&lt;)\u6628\u65E5\u306E\u591C\u5927\u91CF\u306B\u9903\u5B50\u98DF\u3079\u307E\u304F\u3063\u305F\u3060\u3051\u3060\u3051\u3069\u3002",
    "id" : 110245364015185920,
    "created_at" : "2011-09-04 06:58:37 +0000",
    "user" : {
      "name" : "\u6A58\u7530\u3044\u305A\u307F@\u9903\u5B50\u8A55\u8AD6\u5BB6",
      "screen_name" : "izugyoza",
      "protected" : false,
      "id_str" : "161910608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607820959492370432\/IgL617FR_normal.png",
      "id" : 161910608,
      "verified" : false
    }
  },
  "id" : 110246371591864320,
  "created_at" : "2011-09-04 07:02:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u3093\u3053\u3061\u3083\u3093\n\n",
      "screen_name" : "PANKOmamire",
      "indices" : [ 3, 15 ],
      "id_str" : "220935440",
      "id" : 220935440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110223120559898624",
  "text" : "RT @PANKOmamire: \u30DD\u30B1\u30C3\u30C8\u306E\u4E2D\u306B\u306F\u30D3\u30B9\u30B1\u30C3\u30C8\u304C\u4E00\u3064\u266A\u30DD\u30B1\u30C3\u30C8\u3092\u53E9\u304F\u3068\u30D3\u30B9\u30B1\u30C3\u30C8\u306F\u4E8C\u3064\u266A\u3082\u3072\u3068\u3064\u53E9\u304F\u3068\u30D3\u30B9\u30B1\u30C3\u30C8\u306F\u4E09\u3064\u266A\u53E9\u3044\u3066\u307F\u308B\u305F\u3073\u3001\u30D3\u30B9\u30B1\u30C3\u30C8\u306F\u5897\u3048\u308B\u266A\n\u30DD\u30B1\u30C3\u30C8\u30921699830000000\u56DE\u53E9\u304F\u3068\u3001\u9762\u7A4D30\u5E73\u65B9\u30BB\u30F3\u30C1\u30E1\u30FC\u30C8\u30EB\u306E\u30D3\u30B9\u30B1\u30C3\u30C8\u304C\u5730\u7403\u5168\u571F\u3092\u8986\u3044 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109950885920120833",
    "text" : "\u30DD\u30B1\u30C3\u30C8\u306E\u4E2D\u306B\u306F\u30D3\u30B9\u30B1\u30C3\u30C8\u304C\u4E00\u3064\u266A\u30DD\u30B1\u30C3\u30C8\u3092\u53E9\u304F\u3068\u30D3\u30B9\u30B1\u30C3\u30C8\u306F\u4E8C\u3064\u266A\u3082\u3072\u3068\u3064\u53E9\u304F\u3068\u30D3\u30B9\u30B1\u30C3\u30C8\u306F\u4E09\u3064\u266A\u53E9\u3044\u3066\u307F\u308B\u305F\u3073\u3001\u30D3\u30B9\u30B1\u30C3\u30C8\u306F\u5897\u3048\u308B\u266A\n\u30DD\u30B1\u30C3\u30C8\u30921699830000000\u56DE\u53E9\u304F\u3068\u3001\u9762\u7A4D30\u5E73\u65B9\u30BB\u30F3\u30C1\u30E1\u30FC\u30C8\u30EB\u306E\u30D3\u30B9\u30B1\u30C3\u30C8\u304C\u5730\u7403\u5168\u571F\u3092\u8986\u3044\u5C3D\u304F\u3057\u4EBA\u985E\u6EC5\u4EA1\u306E\u6642\u304C\u8A2A\u308C\u308B\u3060\u308D\u3046\u2026",
    "id" : 109950885920120833,
    "created_at" : "2011-09-03 11:28:28 +0000",
    "user" : {
      "name" : "\u3071\u3093\u3053\u3061\u3083\u3093\n\n",
      "screen_name" : "PANKOmamire",
      "protected" : false,
      "id_str" : "220935440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448444083732627456\/imQuK1vC_normal.jpeg",
      "id" : 220935440,
      "verified" : false
    }
  },
  "id" : 110223120559898624,
  "created_at" : "2011-09-04 05:30:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u305D\u307F\u3093@4\u9BD6\u3067\u30A2\u30FC\u30AF\u30B9\u3084\u3063\u3066\u307E\u3059",
      "screen_name" : "arukanova",
      "indices" : [ 9, 19 ],
      "id_str" : "272723823",
      "id" : 272723823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6771\u65B9\u597D\u304D\u3060\u3051\u3069\u6771\u65B9\u53A8\u306F\u3061\u3087\u3063\u3068\u3054\u3081\u3093\u306A\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
      "indices" : [ 21, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110207411259846656",
  "text" : "\u51C4\u304F\u308F\u304B\u308B RT @arukanova: #\u6771\u65B9\u597D\u304D\u3060\u3051\u3069\u6771\u65B9\u53A8\u306F\u3061\u3087\u3063\u3068\u3054\u3081\u3093\u306A\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
  "id" : 110207411259846656,
  "created_at" : "2011-09-04 04:27:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110200674465218560",
  "text" : "\u4ECA\u601D\u3044\u51FA\u3057\u305F\u3051\u3069magokoro\u304C\u725B\u4E3C\u5C4B\u3067\u82B1\u5CA1\u6C0F\u3088\u308D\u3057\u304F\u725B\u4E3C\u306B\u5375\u30927\uFF0C8\u500B\u304B\u3051\u3066\u308B\u5922\u3092\u898B\u305F\u3002\n\u7A81\u3063\u8FBC\u3093\u3060\u3089\u300C\u3044\u3084\u3001\u82B1\u5CA1\u306B\u306F\u52DD\u3066\u306A\u3044\u300D\u307F\u305F\u3044\u306A\u3053\u3068\u3092\u8A00\u308F\u308C\u305F\u3002",
  "id" : 110200674465218560,
  "created_at" : "2011-09-04 04:01:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110154081531727872",
  "text" : "\u7A7A\u8179\uFF67\uFF01\u98DF\u30D1\u30F3\u3092\u98DF\u3055\u3093",
  "id" : 110154081531727872,
  "created_at" : "2011-09-04 00:55:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110148884239626240",
  "text" : "\u9EA6\u3068\u308D\u98DF\u3079\u306B\u884C\u304D\u305F\u3044\u3051\u3069\u5FAE\u5999\u306B\u96E8\u964D\u3063\u3066\u3093\u3060\u3088\u306A\u30FC\u3001\u3080\u3045",
  "id" : 110148884239626240,
  "created_at" : "2011-09-04 00:35:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110147353595482112",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 110147353595482112,
  "created_at" : "2011-09-04 00:29:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110147276206374912",
  "text" : "\u5B9F\u5BB6\u304B\u3089\u5375\u304C\u5C4A\u3044\u3066\u8D77\u3053\u3055\u308C\u305F\u3002\u3046\u3093\u3001\u30EA\u30BA\u30E0\u3092\u623B\u3059\u306B\u306F\u60AA\u304F\u306A\u3044\u3002",
  "id" : 110147276206374912,
  "created_at" : "2011-09-04 00:28:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110044652735971328",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 110044652735971328,
  "created_at" : "2011-09-03 17:41:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110044607395528704",
  "text" : "\u307E\u3041\u6795\u62B1\u3044\u3066\u529B\u629C\u3044\u3066\u76EE\u7791\u308B\u3060\u3051\u3060\u3051\u3069",
  "id" : 110044607395528704,
  "created_at" : "2011-09-03 17:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110044441313685504",
  "text" : "\u7720\u308B\u52AA\u529B\u3092\u3059\u308B\u304B\u306A\u30FC\u3002",
  "id" : 110044441313685504,
  "created_at" : "2011-09-03 17:40:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110042917174919168",
  "text" : "@ayu167 \u3055\u308F\u3089\u3063\u3066\u9B5A\u306E\u8A8D\u77E5\u5EA6\u3060\u3051\u5FC3\u914D\u3060\u3063\u305F",
  "id" : 110042917174919168,
  "created_at" : "2011-09-03 17:34:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110042697561161729",
  "text" : "\u6DF1\u591C\u306E\u622F\u8A00\u3002\n\u3053\u3046\u3044\u3046\u3053\u3068\u3084\u308B\u304B\u3089\u30D5\u30A9\u30ED\u30FC\u5916\u3055\u308C\u3061\u3083\u3046\u306E\u304B\u306A\u3041\u3002",
  "id" : 110042697561161729,
  "created_at" : "2011-09-03 17:33:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110042445085016064",
  "text" : "\u6709\u7121\u3092\u8A00\u308F\u3055\u305A\u6709\u8036\u7121\u8036\u306B\u3057\u3066\u3084\u3093\u3088",
  "id" : 110042445085016064,
  "created_at" : "2011-09-03 17:32:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110042087491239936",
  "text" : "\u3055\u308F\u3089\u304C\u3042\u308B\u3051\u3069\u89E6\u3089\u306A\u3044\u3002",
  "id" : 110042087491239936,
  "created_at" : "2011-09-03 17:30:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110041764550811649",
  "text" : "\u6B32\u3042\u308B\u306E\u306F\u3088\u304F\u306A\u3044\u3002\u3042\u308B\u306E\u304B\u306A\u3044\u306E\u304B\u3002",
  "id" : 110041764550811649,
  "created_at" : "2011-09-03 17:29:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110041606878531584",
  "text" : "\u5BDD\u308B\u306E\u304C\u9045\u3044\u306E\u306F\u3088\u304F\u306A\u3044\u3053\u3068\u3060\u304C\u3088\u304F\u3042\u308B\u3053\u3068\u3002\u826F\u3044\u306E\u304B\u60AA\u3044\u306E\u304B\u3002",
  "id" : 110041606878531584,
  "created_at" : "2011-09-03 17:28:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110040622743826434",
  "text" : "\u663C\u306E\u661F\u304C\u982D\u304B\u3089\u96E2\u308C\u306A\u3044\u3002\u30B5\u30D3\u304C\u2026\u3002",
  "id" : 110040622743826434,
  "created_at" : "2011-09-03 17:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110039715150970881",
  "text" : "\u8A9E\u5B66\u5145\u306E\u3054\u5B66\u53CB\u4E94\u6708\u75C5",
  "id" : 110039715150970881,
  "created_at" : "2011-09-03 17:21:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 11, 22 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110039394517401600",
  "text" : "\u6570\u5B66\u5F92\uFF08\u7406\u60F3\uFF09 RT @magokoro84: \u8A9E\u5B66\u5145\uFF08\u7406\u60F3\uFF09",
  "id" : 110039394517401600,
  "created_at" : "2011-09-03 17:20:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110038525361139712",
  "geo" : { },
  "id_str" : "110038680038686720",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u3041\u767B\u9332\u306E\u6642\u671F\u306E\u3061\u3087\u3044\u524D\u306B\u306A\u3063\u305F\u3089\u307E\u305F",
  "id" : 110038680038686720,
  "in_reply_to_status_id" : 110038525361139712,
  "created_at" : "2011-09-03 17:17:20 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110038318770700288",
  "geo" : { },
  "id_str" : "110038480117186560",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u3060\u4F55\u306B\u3082\u8ABF\u3079\u3066\u306A\u3044\u3067\u3059\uFF08\uFF77\uFF98\uFF6F",
  "id" : 110038480117186560,
  "in_reply_to_status_id" : 110038318770700288,
  "created_at" : "2011-09-03 17:16:32 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110037798039453696",
  "geo" : { },
  "id_str" : "110038086381080576",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5F8C\u671F\u7D4C\u6E08\u3068\u308D\u3046\u305A\u3002\u30B7\u30B9\u30C6\u30E0\u89E3\u308B\u7D4C\u6E08\u306E\u4EBA\u5C45\u305F\u3002",
  "id" : 110038086381080576,
  "in_reply_to_status_id" : 110037798039453696,
  "created_at" : "2011-09-03 17:14:58 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/VXInDpY",
      "expanded_url" : "http:\/\/shindanmaker.com\/152406",
      "display_url" : "shindanmaker.com\/152406"
    } ]
  },
  "geo" : { },
  "id_str" : "110037855874727936",
  "text" : "\u521D\u5BFE\u9762\u306E\u4EBA\u3068\u5F85\u3061\u5408\u308F\u305B\u305F\u3002\u3000\u76F8\u624B\u300C\u5931\u793C\u3067\u3059\u3051\u3069 end313124\u3055\u3093\u3067\u3059\u304B\uFF1F\u300D\u3000end313124\u300C\u306F\u3044\u79C1\u3067\u3059\u300D\u3000\u76F8\u624B\u300C\u3044\u3084\u30FC\u3069\u3046\u3082 \u30A4\u30F3\u30C1\u30AD\u81ED\u3044\u304B\u3089\u3059\u3050\u5206\u304B\u308A\u307E\u3057\u305F\u3088\uFF01\u300D http:\/\/t.co\/VXInDpY  \n\u00D7\u30A4\u30F3\u30C1\u30AD\n\u25CB\u80E1\u6563",
  "id" : 110037855874727936,
  "created_at" : "2011-09-03 17:14:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110036955982606336",
  "text" : "\u5927\u559C\u5229\u306E\u6642\u306B\u68EE\u30C9\u30EA\u30FC\u30E0\u7A7A\u9593\u306E\u8A71\u3057\u3066\u305F\u4EBA\u3068\u4E00\u81F4\u3057\u3066\u305F\uFF57",
  "id" : 110036955982606336,
  "created_at" : "2011-09-03 17:10:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110036727267196929",
  "text" : "\u30AC\u30C1\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u3068\u805E\u3044\u3066\u601D\u308F\u305A\u30D5\u30A9\u30ED\u30FC\u6C7A\u3081\u305F\u3002",
  "id" : 110036727267196929,
  "created_at" : "2011-09-03 17:09:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109998728412278785",
  "geo" : { },
  "id_str" : "109999076719853568",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u8352\u3076\u308B\u30EA\u30B5\u3061\u3083\u3093",
  "id" : 109999076719853568,
  "in_reply_to_status_id" : 109998728412278785,
  "created_at" : "2011-09-03 14:39:58 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109998249133350915",
  "geo" : { },
  "id_str" : "109998479820062720",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u304A\u3044\uFF68\uFF01",
  "id" : 109998479820062720,
  "in_reply_to_status_id" : 109998249133350915,
  "created_at" : "2011-09-03 14:37:35 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109997810325266432",
  "geo" : { },
  "id_str" : "109998221627101185",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u5F15\u304D\u969B\u3082\u5927\u4E8B\u3088\u306D",
  "id" : 109998221627101185,
  "in_reply_to_status_id" : 109997810325266432,
  "created_at" : "2011-09-03 14:36:34 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109997622806331392",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u307B\u3089\u3001\u3053\u308F\u304F\u306A\u3044",
  "id" : 109997622806331392,
  "created_at" : "2011-09-03 14:34:11 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109997401900720128",
  "text" : "\u96E8\u97F3\u2026",
  "id" : 109997401900720128,
  "created_at" : "2011-09-03 14:33:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109996569293627392",
  "geo" : { },
  "id_str" : "109996621416239106",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math 5",
  "id" : 109996621416239106,
  "in_reply_to_status_id" : 109996569293627392,
  "created_at" : "2011-09-03 14:30:12 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109996580219785219",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\uFF30\uFF23\u843D\u3068\u3057\u307E\u3059\u30CE\u30B7\n\u643A\u5E2F\u304B\u3089\u898B\u3066\u307E\u3059\u304C\u2015",
  "id" : 109996580219785219,
  "created_at" : "2011-09-03 14:30:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109996484166025217",
  "text" : "RT @JOJO_math: \u8A3C\u660E\u306E\u5192\u982D\u3067\u30EB\u30FC\u30C8\uFF12\u304C\u6709\u7406\u6570\u3060\u3068\u30AD\u30C3\u30D1\u30EA\u4EEE\u5B9A\u3057\u305F\u3070\u304B\u308A\u3060\u3063\u305F\u306E\u306B\u2026\u30B9\u30DE\u30F3\u3042\u308A\u3083\u30A6\u30BD\u3060\u3063\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109996084910243840",
    "text" : "\u8A3C\u660E\u306E\u5192\u982D\u3067\u30EB\u30FC\u30C8\uFF12\u304C\u6709\u7406\u6570\u3060\u3068\u30AD\u30C3\u30D1\u30EA\u4EEE\u5B9A\u3057\u305F\u3070\u304B\u308A\u3060\u3063\u305F\u306E\u306B\u2026\u30B9\u30DE\u30F3\u3042\u308A\u3083\u30A6\u30BD\u3060\u3063\u305F",
    "id" : 109996084910243840,
    "created_at" : "2011-09-03 14:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 109996484166025217,
  "created_at" : "2011-09-03 14:29:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109996477224460288",
  "text" : "\u305D\u308C\u3053\u305D\u4F11\u307F\u7D42\u308F\u3063\u3066\u304B\u3089\u5F8C\u6094\u3059\u308B\u6C17\u304C\u3059\u308B\u3002\u5148\u306B\u7ACB\u305F\u306A\u3044\u306E\u3067\u5F8C\u6094\u3057\u306A\u3044\u3088\u3046\u306B\u3057\u306A\u304F\u3066\u306F\u3002",
  "id" : 109996477224460288,
  "created_at" : "2011-09-03 14:29:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109996274400493568",
  "text" : "\u3055\u3041\u9069\u5F53\u306B\u5BDD\u308B\u3075\u308A\u3092\u3059\u308B\u304B\u3002\u660E\u65E5\u306F\u300C\u5FAE\u5206\u6CD5\u3068\u305D\u306E\u5FDC\u7528\u300D\u307E\u3067\u3084\u308B\u3064\u3082\u308A\u3067\u3084\u308D\u3046\u3002\n\u590F\u4F11\u307F\u306E\u52C9\u5F37\u306B\u8DB3\u308A\u306A\u3044\u306E\u306F\u5F37\u5236\u529B\u3060\u3088\u306A\u30FC\u3002\u5B66\u6821\u59CB\u307E\u308B\u3068\u3084\u308A\u305F\u3044\u3051\u3069\u6642\u9593\u306A\u3044\u3063\u3066\u8A00\u3044\u8A33\u3057\u3061\u3083\u3046\u3057\u306A\u30FC\u3002",
  "id" : 109996274400493568,
  "created_at" : "2011-09-03 14:28:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109995148594782208",
  "text" : "\u300C\u5148\u306B\u7ACB\u305F\u306A\u3044\u306A\u3089\u5F8C\u6094\u3059\u308B\u306A\u3002\u300D\u3044\u3044\u8A00\u8449\u3060\u3002\u3044\u3044\u8A00\u8449\u306F\u6C7A\u3057\u3066\u306A\u304F\u306A\u3089\u306A\u3044\u3002",
  "id" : 109995148594782208,
  "created_at" : "2011-09-03 14:24:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109995001987076097",
  "text" : "RT @NISIOISIN_BOT: \u300C\u96E3\u3057\u3044\u9854\u3092\u3057\u3066\u601D\u3044\u60A9\u3093\u3067\u3044\u308B\u3068\u8CE2\u3044\u98A8\u306B\u898B\u3048\u308B\u3051\u308C\u3069\u305D\u3093\u306A\u306E\u306F\u8AA4\u89E3\u3060\u3088\u3002\u8003\u3048\u308C\u3070\u3044\u3044\u3063\u3066\u308F\u3051\u3058\u3083\u306A\u3044\u3002\u4F55\u3082\u8003\u3048\u305A\u306B\u307B\u3063\u3053\u308A\u3068\u751F\u304D\u3066\u308B\u5974\u306E\u307B\u3046\u304C\u3088\u3063\u307D\u3069\u5929\u4E0B\u3092\u53D6\u3063\u3066\u308B\u3002\u60A9\u3080\u306A\u3093\u3066\u306E\u306F\u6642\u9593\u306E\u7121\u99C4\u3060\u3002\u8003\u3048\u308B\u6687\u304C\u3042\u308B\u306A\u3089\u52D5\u3051\u3002\u60A9\u307F\u306F\u5FD8\u308C\u308D\u3002\u5148 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109994580560187392",
    "text" : "\u300C\u96E3\u3057\u3044\u9854\u3092\u3057\u3066\u601D\u3044\u60A9\u3093\u3067\u3044\u308B\u3068\u8CE2\u3044\u98A8\u306B\u898B\u3048\u308B\u3051\u308C\u3069\u305D\u3093\u306A\u306E\u306F\u8AA4\u89E3\u3060\u3088\u3002\u8003\u3048\u308C\u3070\u3044\u3044\u3063\u3066\u308F\u3051\u3058\u3083\u306A\u3044\u3002\u4F55\u3082\u8003\u3048\u305A\u306B\u307B\u3063\u3053\u308A\u3068\u751F\u304D\u3066\u308B\u5974\u306E\u307B\u3046\u304C\u3088\u3063\u307D\u3069\u5929\u4E0B\u3092\u53D6\u3063\u3066\u308B\u3002\u60A9\u3080\u306A\u3093\u3066\u306E\u306F\u6642\u9593\u306E\u7121\u99C4\u3060\u3002\u8003\u3048\u308B\u6687\u304C\u3042\u308B\u306A\u3089\u52D5\u3051\u3002\u60A9\u307F\u306F\u5FD8\u308C\u308D\u3002\u5148\u306B\u7ACB\u305F\u306A\u3044\u306A\u3089\u5F8C\u6094\u3059\u308B\u306A\u300D",
    "id" : 109994580560187392,
    "created_at" : "2011-09-03 14:22:06 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 109995001987076097,
  "created_at" : "2011-09-03 14:23:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109994439363133442",
  "geo" : { },
  "id_str" : "109994879840559104",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \uFF34\uFF2C\u306B\u898B\u304B\u3051\u305F\u6C17\u304C\u3059\u308B\u304C\u30FB\u30FB\u30FB\u30CD\u30BF\u306A\u3093\u3058\u3083\u306A\u3044\uFF1F",
  "id" : 109994879840559104,
  "in_reply_to_status_id" : 109994439363133442,
  "created_at" : "2011-09-03 14:23:17 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109993875443163137",
  "text" : "\u660E\u65E5\u306E\u5915\u65B9\u6674\u308C\u3066\u305F\u3089\u9EA6\u3068\u308D\u98DF\u3079\u306B\u884C\u3053\u3046\u304B\u306A\u30FC\u3002",
  "id" : 109993875443163137,
  "created_at" : "2011-09-03 14:19:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109993426300305408",
  "text" : "\u6625\u83CA\u306E\u5165\u3063\u3066\u306A\u3044\u3059\u304D\u713C\u304D\u306F\u8A8D\u3081\u306A\u3044\u3001\u3068\u304B\u3002\u3054\u307E\u3060\u308C\u306E\u51B7\u3084\u3057\u4E2D\u83EF\u306F\u90AA\u9053\u3060\u3002\u3068\u304B\u3002",
  "id" : 109993426300305408,
  "created_at" : "2011-09-03 14:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109993296717291520",
  "text" : "\u3042\u3068\u9EA6\u98EF\u3068\u308D\u308D\u3054\u306F\u3093\u98DF\u3079\u305F\u3044\uFF01\n\n\u3053\u306E\u4EBA\u306E\u30B0\u30EB\u30E1\u30A8\u30C3\u30BB\u30A4\u306F\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u3059\u3054\u304F\u4E3B\u89B3\u7684\u3067\u3001\u7D30\u304B\u3044\u3053\u3060\u308F\u308A\u306B\u6E80\u3061\u3066\u3066\u9762\u767D\u3044\u3002",
  "id" : 109993296717291520,
  "created_at" : "2011-09-03 14:17:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109993021180878848",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u306B\u91CE\u6B66\u58EB\u306E\u30B0\u30EB\u30E1\u306A\u3093\u304B\u8AAD\u3080\u3093\u3058\u3083\u306A\u304B\u3063\u305F\u3002\n\n\u30AB\u30C3\u30B3\u60AA\u304F\u3066\u3082\u3044\u3044\u304B\u3089\u3059\u304D\u713C\u304D\u98DF\u3079\u305F\u304F\u306A\u3063\u3061\u3083\u3063\u305F\u3058\u3083\u306A\u3044\u304B",
  "id" : 109993021180878848,
  "created_at" : "2011-09-03 14:15:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109983855620009985",
  "geo" : { },
  "id_str" : "109984093680308225",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u8E0F\u307E\u308C\u308B\u306E\u597D\u304D\u306A\u306E\u304B\u3002",
  "id" : 109984093680308225,
  "in_reply_to_status_id" : 109983855620009985,
  "created_at" : "2011-09-03 13:40:25 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109984018690347012",
  "text" : "\u8ABF\u548C\u7D1A\u6570\u306E\u548C\u3092\uFF33\uFF4E\u3067\u66F8\u304B\u308C\u308B\u3068\u6C17\u6301\u3061\u60AA\u3044\u306A\u3001\uFF28\uFF4E\u306E\u307B\u3046\u304C\u3057\u3063\u304F\u308A\u304F\u308B\u306E\u306F\u6163\u308C\u306E\u554F\u984C\u304B",
  "id" : 109984018690347012,
  "created_at" : "2011-09-03 13:40:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109983630813708288",
  "text" : "\u60AA\u304F\u306A\u3044\u3002",
  "id" : 109983630813708288,
  "created_at" : "2011-09-03 13:38:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109983576388411392",
  "text" : "\u5B87\u5B99\u306B\u3064\u3044\u3066\u8003\u3048\u3066\u7720\u308C\u306A\u3044\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 109983576388411392,
  "created_at" : "2011-09-03 13:38:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mac\u306F\u3084\u304F\u304B\u3048\u3063\u3066\u304D\u3066",
      "screen_name" : "sususuama",
      "indices" : [ 3, 13 ],
      "id_str" : "170263990",
      "id" : 170263990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http:\/\/t.co\/4JvWmAJ",
      "expanded_url" : "http:\/\/twitpic.com\/6fd6cv",
      "display_url" : "twitpic.com\/6fd6cv"
    } ]
  },
  "geo" : { },
  "id_str" : "109983517735264256",
  "text" : "RT @sususuama: \u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u8A8C\u306B\u8F09\u3063\u3066\u305F\u3002\u30A4\u30DE\u30C9\u30AD\u7537\u5B50\u306E\u60A9\u307F\u3060\u3068\u3055\u2026\uFF01\uFF01 http:\/\/t.co\/4JvWmAJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 48 ],
        "url" : "http:\/\/t.co\/4JvWmAJ",
        "expanded_url" : "http:\/\/twitpic.com\/6fd6cv",
        "display_url" : "twitpic.com\/6fd6cv"
      } ]
    },
    "geo" : { },
    "id_str" : "109959960791744513",
    "text" : "\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u8A8C\u306B\u8F09\u3063\u3066\u305F\u3002\u30A4\u30DE\u30C9\u30AD\u7537\u5B50\u306E\u60A9\u307F\u3060\u3068\u3055\u2026\uFF01\uFF01 http:\/\/t.co\/4JvWmAJ",
    "id" : 109959960791744513,
    "created_at" : "2011-09-03 12:04:32 +0000",
    "user" : {
      "name" : "Mac\u306F\u3084\u304F\u304B\u3048\u3063\u3066\u304D\u3066",
      "screen_name" : "sususuama",
      "protected" : false,
      "id_str" : "170263990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601790852386557953\/fivTWM8k_normal.png",
      "id" : 170263990,
      "verified" : false
    }
  },
  "id" : 109983517735264256,
  "created_at" : "2011-09-03 13:38:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109960882968199168",
  "text" : "\u7D0D\u8C46\u30C8\u30FC\u30B9\u30C8\u3063\u3066\u3059\u3054\u3044\u98DF\u3079\u7269\u3060\u3088\u306D\u3001\u826F\u304F\u8003\u3048\u305F\u3089\u3002",
  "id" : 109960882968199168,
  "created_at" : "2011-09-03 12:08:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109959043451326464",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 109959043451326464,
  "created_at" : "2011-09-03 12:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109958081470939136",
  "text" : "\u96E8\u304C\u3042\u3089\u3076\u3063\u3066\u308B\u3045",
  "id" : 109958081470939136,
  "created_at" : "2011-09-03 11:57:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109934385142300672",
  "text" : "\u6687\u3002\u3072\u30FB\u307E\u3002\uFF28\u30FB\uFF29\u30FB\uFF2D\u30FB\uFF21\uFF5E\u266A",
  "id" : 109934385142300672,
  "created_at" : "2011-09-03 10:22:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109919592570302464",
  "text" : "RT @NISIOISIN_BOT: \u6BBA\u3057\u3066\u89E3\u3057\u3066\u4E26\u3079\u3066\u63C3\u3048\u3066\u6652\u3057\u3066\u523B\u3093\u3067\u7092\u3081\u3066\u5343\u5207\u3063\u3066\u6F70\u3057\u3066\u5F15\u304D\u4F38\u3070\u3057\u3066\u523A\u3057\u3066\u6289\u3063\u3066\u5265\u304C\u3057\u3066\u65AD\u3058\u3066\u5233\u308A\u8CAB\u3044\u3066\u58CA\u3057\u3066\u6B6A\u3081\u3066\u7E0A\u3063\u3066\u66F2\u3052\u3066\u8EE2\u304C\u3057\u3066\u6C88\u3081\u3066\u7E1B\u3063\u3066\u72AF\u3057\u3066\u55B0\u3089\u3063\u3066\u8FB1\u3081\u3066\u3084\u3093\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109917328740843520",
    "text" : "\u6BBA\u3057\u3066\u89E3\u3057\u3066\u4E26\u3079\u3066\u63C3\u3048\u3066\u6652\u3057\u3066\u523B\u3093\u3067\u7092\u3081\u3066\u5343\u5207\u3063\u3066\u6F70\u3057\u3066\u5F15\u304D\u4F38\u3070\u3057\u3066\u523A\u3057\u3066\u6289\u3063\u3066\u5265\u304C\u3057\u3066\u65AD\u3058\u3066\u5233\u308A\u8CAB\u3044\u3066\u58CA\u3057\u3066\u6B6A\u3081\u3066\u7E0A\u3063\u3066\u66F2\u3052\u3066\u8EE2\u304C\u3057\u3066\u6C88\u3081\u3066\u7E1B\u3063\u3066\u72AF\u3057\u3066\u55B0\u3089\u3063\u3066\u8FB1\u3081\u3066\u3084\u3093\u3088",
    "id" : 109917328740843520,
    "created_at" : "2011-09-03 09:15:07 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 109919592570302464,
  "created_at" : "2011-09-03 09:24:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109883783465017344",
  "text" : "\u5F37\u98A8\u306F\u5927\u597D\u304D\u306A\u3093\u3060\u3051\u3069\u96E8\u306F\u5ACC\u3044\u3002",
  "id" : 109883783465017344,
  "created_at" : "2011-09-03 07:01:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109877568659927040",
  "text" : "\u5ACC\u3044\u306A\u8A00\u8449\uFF1A\u601D\u8003\u505C\u6B62\u3000\n\u3044\u3084\u3001\u3067\u3082\u3053\u308C\u81EA\u5206\u306E\u5ACC\u3044\u306A\u8A00\u8449\u306B\u3064\u3044\u3066\u306E\u601D\u8003\u3092\u505C\u6B62\u3057\u3066\u3044\u306A\u3044\u3060\u308D\u3046\u304B\u30FB\u30FB\u30FB\u3068\u3044\u3046\u30B5\u30A4\u30B3\u30ED\u30B8\u30AB\u30EB",
  "id" : 109877568659927040,
  "created_at" : "2011-09-03 06:37:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109876968190771200",
  "geo" : { },
  "id_str" : "109877261905297408",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u601D\u8003\u505C\u6B62\u306B\u306A\u3089\u306A\u3044\u3088\u3046\u306B\u306A\u30FC",
  "id" : 109877261905297408,
  "in_reply_to_status_id" : 109876968190771200,
  "created_at" : "2011-09-03 06:35:55 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109876541764280320",
  "text" : "\u3068\u304B\u8A00\u3044\u3064\u3064\u8EAB\u5185\u30CD\u30BFbot\u3068\u304B\u3044\u3046\u3082\u306E\u3092\u4F5C\u308A\u4E0A\u3052\u3066\u3057\u307E\u3063\u3066\u3044\u308B\u3042\u305F\u308A\u4E00\u8CAB\u3057\u3066\u306A\u3044\u3088\u306A\u3041\u3002",
  "id" : 109876541764280320,
  "created_at" : "2011-09-03 06:33:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109876419303186432",
  "text" : "\u307E\u3041\u305D\u306E\u4EBA\u306E\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u898B\u3066\u307F\u3066\u524D\u5F8C\u6570\u30C4\u30A4\u30FC\u30C8\u3068\u304B\u4F1A\u8A71\u3092\u3055\u304B\u306E\u307C\u3063\u3066\u307F\u308B\u7A0B\u5EA6\u306E\u52AA\u529B\u306F\u3059\u308B\u3079\u304D\u3002",
  "id" : 109876419303186432,
  "created_at" : "2011-09-03 06:32:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109876228005175296",
  "text" : "\u307E\u3041\u305D\u306E\u70B9\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u308F\u3051\u308F\u304B\u3093\u306A\u304F\u3066\u3082\u6D41\u308C\u306B\u57CB\u3082\u308C\u3061\u3083\u3046\u304B\u3089\u305D\u3053\u307E\u3067\u6C17\u306B\u306F\u306A\u3089\u306A\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u3051\u308C\u3069\u3002\u305D\u308C\u3067\u3082\u3002",
  "id" : 109876228005175296,
  "created_at" : "2011-09-03 06:31:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109875860345069568",
  "text" : "\u3060\u3063\u3066\u305D\u308C\u3059\u3054\u30FC\u304F\u9B31\u9676\u3057\u3044\u3002mixi\u3067\u3082\u300C\u30DE\u30B8\u6700\u60AA\u3060\u308F\u300D\u307F\u305F\u3044\u306A\u3053\u3068\u66F8\u304D\u306A\u304C\u3089\u4F55\u304C\u3042\u3063\u305F\u304B\u66F8\u304B\u306A\u3044\u307F\u305F\u3044\u306A\u8F29\u304C\u3044\u305F\u3051\u3069\u3001\u4E2D\u8EAB\u308F\u304B\u3093\u306A\u3044\u306E\u306B\u30B3\u30E1\u30F3\u30C8\u3067\u300C\u5143\u6C17\u3060\u3057\u306A\u3088\u300D\u307F\u305F\u3044\u306A\u622F\u8A00\u3092\u5410\u3051\u308B\u307B\u3069\u53CB\u9054\u3054\u3063\u3053\u306F\u597D\u304D\u3058\u3083\u306A\u3044\u3002",
  "id" : 109875860345069568,
  "created_at" : "2011-09-03 06:30:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109875319170797568",
  "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u304C\u3069\u3093\u306A\u306B\u30C1\u30E9\u88CF\u3067\u3082\u8AAD\u307F\u624B\u304C\u3044\u308B\u4EE5\u4E0A\u524D\u63D0\u77E5\u8B58\u3068\u304B\u6587\u8108\u3092\u7121\u8996\u3057\u305F\u3089\u7406\u89E3\u3067\u304D\u306A\u3044\u5206\u306F\u66F8\u304F\u3079\u304D\u3058\u3083\u306A\u3044\u3088\u306A\u3041\u3001\u3068\u53CD\u7701\u3002",
  "id" : 109875319170797568,
  "created_at" : "2011-09-03 06:28:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109874032110866432",
  "text" : "\u3042\u3001\u3077\u3088\u3077\u3088\u306E\u8A71\u306A\u3093\u3067\u3059\u3051\u3069\u306D\uFF57",
  "id" : 109874032110866432,
  "created_at" : "2011-09-03 06:23:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109873897297555457",
  "text" : "\u308A\u3093\u3054\u306E\u9023\u9396\u30DC\u30A4\u30B9\u304C\u5370\u8C61\u7684\u904E\u304E\u3066\u30A2\u30EC\u3002\u5F7C\u5973\u3082\u304D\u3063\u3068\u6570\u5B66\u30AC\u30FC\u30EB\u306B\u9055\u3044\u306A\u3044\u3002\u4E2D\u5B66\u751F\u8A2D\u5B9A\u3067\u30A4\u30F3\u30C6\u30B0\u30E9\u30EB\u3063\u3066\u5358\u8A9E\u3092\u4F7F\u3046\u3042\u305F\u308A\u7279\u306B\u3002",
  "id" : 109873897297555457,
  "created_at" : "2011-09-03 06:22:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "indices" : [ 16, 26 ],
      "id_str" : "232545906",
      "id" : 232545906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109873067253182464",
  "text" : "\u4F55\u305D\u308C\u304B\u308F\u3044\u3044\u3002\u6559\u6388\u304C\u3002 RT @math_neko: \u305D\u3046\u3044\u3048\u3070\u6570\u5B66\u306E\u8001\u6559\u6388\u304C\u5973\u5B50\u5B66\u751F\u306E\u524D\u3067\u300C\u7F6E\u63DB(\u3061\u304B\u3093)\u300D\u3063\u3066\u3044\u3046\u306E\u304C\u5ACC\u3067\u6065\u305A\u304B\u3057\u305D\u3046\u306B\u300C\u30D1\u30FC\u30DF\u30E5\u30C6\u30FC\u30B7\u30E7\u30F3\u300D\u3063\u3066\u767A\u97F3\u3057\u3066\u305F\u3001\u3063\u3066\u8A71\u306A\u3089\u672C\u3067\u8AAD\u3093\u3060\u3053\u3068\u3042\u308B",
  "id" : 109873067253182464,
  "created_at" : "2011-09-03 06:19:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109612777991192578",
  "text" : "\u3055\u3041\u4E00\u4ED5\u4E8B\u7D42\u308F\u3063\u305F\u3057\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3088\u3046\u3002",
  "id" : 109612777991192578,
  "created_at" : "2011-09-02 13:04:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109608846753935360",
  "text" : "\u304A\u3063\u3057\u3083\u3001\u8D70\u3063\u305F\uFF01\u5B8C\u74A7\u3067\u3059\u3002",
  "id" : 109608846753935360,
  "created_at" : "2011-09-02 12:49:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109600145842245632",
  "text" : "bot\u6417\u304F\u3093\u306E\u3063\u3066\u5927\u5909\u306A\u306E\u306D\u30FC\u3002\u51FA\u6765\u5408\u3044\u306E\u4F7F\u3063\u3066\u3082\u5927\u5909\u3060\u3063\u305F\u3002\u4E00\u304B\u3089\u66F8\u3044\u3066\u308B\u4EBA\u30DE\u30B8\u3067\u5C0A\u656C\u3059\u308B\u308F\u3002",
  "id" : 109600145842245632,
  "created_at" : "2011-09-02 12:14:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109550461509570560",
  "geo" : { },
  "id_str" : "109550583920345088",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u3063\u3066\u3001\u306A\u3093\u3067\u3067\u3059\u304B\u30FC",
  "id" : 109550583920345088,
  "in_reply_to_status_id" : 109550461509570560,
  "created_at" : "2011-09-02 08:57:49 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109550224149712896",
  "text" : "\u518D\u8D77\u52D5\u3041\uFF01",
  "id" : 109550224149712896,
  "created_at" : "2011-09-02 08:56:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109550045405261824",
  "text" : "\u3068\u4E2D\u9014\u534A\u7AEF\u306A\u7ACB\u5834\u304B\u3089\u3061\u3087\u3063\u3068\u30D1\u30ED\u30C7\u30A3\u3057\u3066\u307F\u305F\u308A\u3002\u524D\u8005\u306E\u304C\u6B63\u76F4\u8033\u306B\u75DB\u3044\u3002",
  "id" : 109550045405261824,
  "created_at" : "2011-09-02 08:55:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109549733625856000",
  "text" : "\u660E\u3089\u304B\u306B\u52C9\u5F37\u3082\u3057\u3066\u306A\u3044\u3088\u3046\u306A\uFF24\uFF31\uFF2E\u5927\u5B66\u751F\u3067\u3059\u3089\u3001\u30B1\u30FC\u30EA\u30FC\u30CF\u30DF\u30EB\u30C8\u30F3\u3068\u304B\u3001\u90E8\u5206\u7A4D\u5206\u3068\u304B\u3001\u5F53\u7136\u77E5\u3063\u3066\u3044\u308B\u3053\u3068\u306B\u306A\u308B\u3002\u305D\u308C\u3092\u77E5\u3089\u306A\u3044\u3001\u5FD8\u308C\u3066\u3057\u307E\u3063\u3066\u3044\u308B\u3068\u3053\u304C\u6094\u3057\u304F\u306A\u3044\u304B\u3002\u6094\u3057\u3044\u3060\u308D\u3002\u6587\u7CFB\u306B\u80E1\u5750\u3092\u304B\u3044\u3066\u3061\u3083\u30C0\u30E1\u3060\u3002",
  "id" : 109549733625856000,
  "created_at" : "2011-09-02 08:54:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3050\u3060\u306D\u3053@chandelle",
      "screen_name" : "gudaneko",
      "indices" : [ 3, 12 ],
      "id_str" : "178433667",
      "id" : 178433667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109548765060399104",
  "text" : "RT @gudaneko: \u660E\u3089\u304B\u306B\u52C9\u5F37\u3082\u3057\u3066\u306A\u3044\u3088\u3046\u306A\u3057\u3087\u3046\u3082\u306A\u3044\u5973\u5B50\u5927\u751F\u3067\u3059\u3089\u3001\u4E16\u754C\u53F2\u9078\u629E\u306A\u3089\u30C8\u30A5\u30FC\u30EB\u30DD\u30EF\u30C6\u30A3\u30A8\u3068\u304B\u3001\u65E5\u672C\u53F2\u9078\u629E\u306A\u3089\u8607\u6211\u5009\u5C71\u7530\u77F3\u5DDD\u9EBB\u5442\u3068\u304B\u3001\u5F53\u7136\u77E5\u3063\u3066\u308B\u3053\u3068\u306B\u306A\u308B\u3002\u305D\u308C\u3092\u77E5\u3089\u306A\u3044\u3053\u3068\u304C\u6094\u3057\u304F\u306A\u3044\u304B\u3002\u6094\u3057\u3044\u3060\u308D\u3002\u7406\u7CFB\u306B\u80E1\u5EA7\u3092\u304B\u3044\u3066\u3044\u308B\u306E\u3067\u306F\u30C0\u30E1\u3060\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109529814435770368",
    "text" : "\u660E\u3089\u304B\u306B\u52C9\u5F37\u3082\u3057\u3066\u306A\u3044\u3088\u3046\u306A\u3057\u3087\u3046\u3082\u306A\u3044\u5973\u5B50\u5927\u751F\u3067\u3059\u3089\u3001\u4E16\u754C\u53F2\u9078\u629E\u306A\u3089\u30C8\u30A5\u30FC\u30EB\u30DD\u30EF\u30C6\u30A3\u30A8\u3068\u304B\u3001\u65E5\u672C\u53F2\u9078\u629E\u306A\u3089\u8607\u6211\u5009\u5C71\u7530\u77F3\u5DDD\u9EBB\u5442\u3068\u304B\u3001\u5F53\u7136\u77E5\u3063\u3066\u308B\u3053\u3068\u306B\u306A\u308B\u3002\u305D\u308C\u3092\u77E5\u3089\u306A\u3044\u3053\u3068\u304C\u6094\u3057\u304F\u306A\u3044\u304B\u3002\u6094\u3057\u3044\u3060\u308D\u3002\u7406\u7CFB\u306B\u80E1\u5EA7\u3092\u304B\u3044\u3066\u3044\u308B\u306E\u3067\u306F\u30C0\u30E1\u3060\u3002",
    "id" : 109529814435770368,
    "created_at" : "2011-09-02 07:35:17 +0000",
    "user" : {
      "name" : "\u3050\u3060\u306D\u3053@chandelle",
      "screen_name" : "gudaneko",
      "protected" : false,
      "id_str" : "178433667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528818853367660545\/OyiRz_lX_normal.jpeg",
      "id" : 178433667,
      "verified" : false
    }
  },
  "id" : 109548765060399104,
  "created_at" : "2011-09-02 08:50:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109542481128992768",
  "text" : "\u96E8\u3001\u98A8\u3068\u3082\u306B\u30C6\u30F3\u30B7\u30E7\u30F3\u3042\u304C\u3063\u3066\u307E\u3044\u308A\u307E\u3057\u305F\u3002",
  "id" : 109542481128992768,
  "created_at" : "2011-09-02 08:25:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109525390854328320",
  "text" : "\u4E45\u3005\u306B\u304A\u6C17\u306B\u5165\u308A\u6574\u7406\u30026\u5E74\u306B\u3082\u306A\u308B\u3068\u7A4D\u3082\u308A\u7A4D\u3082\u3063\u3066\u308B\u3002\u524A\u9664\u524A\u9664\u3002",
  "id" : 109525390854328320,
  "created_at" : "2011-09-02 07:17:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u524D\u91CE\uFF3B\u3044\u308D\u3082\u306E\u7269\u7406\u5B66\u8005\uFF3D\u660C\u5F18",
      "screen_name" : "irobutsu",
      "indices" : [ 3, 12 ],
      "id_str" : "78012601",
      "id" : 78012601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109478526406770688",
  "text" : "RT @irobutsu: \u3010\u5E78\u305B\u3092\u3064\u304B\u3080\u305F\u3081\u306E\u91CF\u5B50\u529B\u5B66\u306E\u6CD5\u5247\u3011\u91CF\u5B50\u529B\u5B66\u3067\u306F\u4EA4\u63DB\u95A2\u4FC2\u304C\u3068\u3063\u3066\u3082\u5927\u4E8B\u3002\u6B63\u3057\u3044\u9806\u5E8F\u3067\u30A2\u30BF\u30C3\u30AF\u3057\u306A\u3044\u3068\u3001\u5F7C\u6C0F\u306E\u30CF\u30FC\u30C8\u306F\u3064\u304B\u3081\u307E\u305B\u3093\u3088\uFF01\u3000\u3057\u304B\u3082\u4EA4\u63DB\u3067\u304D\u306A\u3044\u4E8C\u3064\u306E\u91CF\u306F\u3001\u540C\u6642\u306B\u78BA\u5B9A\u3057\u306A\u3044\u304B\u3089\u3082\u3046\u305F\u3044\u3078\u3093\u3002\u4EA4\u63DB\u95A2\u4FC2\u3092\u3046\u307E\u304F\u5236\u5FA1\u3057\u306A\u3044\u3068\u3001\u3042\u306A\u305F\u306E\u4EBA\u751F\u306F\u3044 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109467024274628608",
    "text" : "\u3010\u5E78\u305B\u3092\u3064\u304B\u3080\u305F\u3081\u306E\u91CF\u5B50\u529B\u5B66\u306E\u6CD5\u5247\u3011\u91CF\u5B50\u529B\u5B66\u3067\u306F\u4EA4\u63DB\u95A2\u4FC2\u304C\u3068\u3063\u3066\u3082\u5927\u4E8B\u3002\u6B63\u3057\u3044\u9806\u5E8F\u3067\u30A2\u30BF\u30C3\u30AF\u3057\u306A\u3044\u3068\u3001\u5F7C\u6C0F\u306E\u30CF\u30FC\u30C8\u306F\u3064\u304B\u3081\u307E\u305B\u3093\u3088\uFF01\u3000\u3057\u304B\u3082\u4EA4\u63DB\u3067\u304D\u306A\u3044\u4E8C\u3064\u306E\u91CF\u306F\u3001\u540C\u6642\u306B\u78BA\u5B9A\u3057\u306A\u3044\u304B\u3089\u3082\u3046\u305F\u3044\u3078\u3093\u3002\u4EA4\u63DB\u95A2\u4FC2\u3092\u3046\u307E\u304F\u5236\u5FA1\u3057\u306A\u3044\u3068\u3001\u3042\u306A\u305F\u306E\u4EBA\u751F\u306F\u3044\u3064\u307E\u3067\u3082\u4E0D\u78BA\u5B9A\u306A\u307E\u307E\uFF01",
    "id" : 109467024274628608,
    "created_at" : "2011-09-02 03:25:47 +0000",
    "user" : {
      "name" : "\u524D\u91CE\uFF3B\u3044\u308D\u3082\u306E\u7269\u7406\u5B66\u8005\uFF3D\u660C\u5F18",
      "screen_name" : "irobutsu",
      "protected" : false,
      "id_str" : "78012601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1203634317\/dosei2_normal.jpg",
      "id" : 78012601,
      "verified" : false
    }
  },
  "id" : 109478526406770688,
  "created_at" : "2011-09-02 04:11:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109457516521463809",
  "text" : "\u5348\u524D\u4E2D\u306B\u8D77\u304D\u308C\u305F\uFF67\uFF01\u304A\u306F\u3088\u3046",
  "id" : 109457516521463809,
  "created_at" : "2011-09-02 02:48:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Q\/\u91CD\u529B\u6CE2\u5929\u6587\u5B66\u5F92",
      "screen_name" : "life_wont_wait",
      "indices" : [ 3, 18 ],
      "id_str" : "120477998",
      "id" : 120477998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109457227638784000",
  "text" : "RT @life_wont_wait: \u904E\u304E\u305F\u308B\u306F\u7336\u53CA\u3070\u3056\u308B\u304C\u5982\u3057\uFF1A\u89AA\u304C\u6211\u304C\u5B50\u3092\u300C\u3044\u3044\u5927\u5B66\u306B\u884C\u3063\u3066\u3001\u3044\u3044\u4F1A\u793E\u306B\u5C31\u8077\u3057\u3066\u3001\u4E0D\u81EA\u7531\u3057\u306A\u3044\u5E78\u305B\u306A\u66AE\u3089\u3057\u3092\u6B32\u3057\u3044\u300D\u3068\u3044\u3046\u4E00\u5FC3\u3067\u6559\u80B2\u3057\u3066\u304D\u305F\u7D50\u679C\u3001\u6570\u5B66\u3060\u306E\u7269\u7406\u3060\u306E\u306E\u9662\u751F\u306B\u306A\u3063\u3066\u3057\u307E\u3046\u3053\u3068",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102665726548115456",
    "text" : "\u904E\u304E\u305F\u308B\u306F\u7336\u53CA\u3070\u3056\u308B\u304C\u5982\u3057\uFF1A\u89AA\u304C\u6211\u304C\u5B50\u3092\u300C\u3044\u3044\u5927\u5B66\u306B\u884C\u3063\u3066\u3001\u3044\u3044\u4F1A\u793E\u306B\u5C31\u8077\u3057\u3066\u3001\u4E0D\u81EA\u7531\u3057\u306A\u3044\u5E78\u305B\u306A\u66AE\u3089\u3057\u3092\u6B32\u3057\u3044\u300D\u3068\u3044\u3046\u4E00\u5FC3\u3067\u6559\u80B2\u3057\u3066\u304D\u305F\u7D50\u679C\u3001\u6570\u5B66\u3060\u306E\u7269\u7406\u3060\u306E\u306E\u9662\u751F\u306B\u306A\u3063\u3066\u3057\u307E\u3046\u3053\u3068",
    "id" : 102665726548115456,
    "created_at" : "2011-08-14 08:59:51 +0000",
    "user" : {
      "name" : "Q\/\u91CD\u529B\u6CE2\u5929\u6587\u5B66\u5F92",
      "screen_name" : "life_wont_wait",
      "protected" : false,
      "id_str" : "120477998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000786710089\/8ddfbc4339975f59aa7de6d12170fb72_normal.jpeg",
      "id" : 120477998,
      "verified" : false
    }
  },
  "id" : 109457227638784000,
  "created_at" : "2011-09-02 02:46:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "indices" : [ 3, 17 ],
      "id_str" : "199329343",
      "id" : 199329343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109271279768567808",
  "text" : "RT @Satomii_Opera: \u6B8B\u696D\u300C\u7D42\u96FB\u3001\u7121\u304F\u306A\u3063\u3061\u3083\u3063\u305F\u306D\u2026\u2026\/\/\/\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109266958343606272",
    "text" : "\u6B8B\u696D\u300C\u7D42\u96FB\u3001\u7121\u304F\u306A\u3063\u3061\u3083\u3063\u305F\u306D\u2026\u2026\/\/\/\u300D",
    "id" : 109266958343606272,
    "created_at" : "2011-09-01 14:10:47 +0000",
    "user" : {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "protected" : false,
      "id_str" : "199329343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212059931\/satomii_opera_normal.jpg",
      "id" : 199329343,
      "verified" : false
    }
  },
  "id" : 109271279768567808,
  "created_at" : "2011-09-01 14:27:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109267037951508481",
  "text" : "@koketomi \u3042\u30FC\u3042\u308C\u898B\u305F\u76EE\u306F\u597D\u304D\u306A\u3093\u3060\u3051\u3069\u767A\u8A00\u5185\u5BB9\u304C\u3069\u3046\u307F\u3066\u3082\u30CF\u30CA\u30AD\u3067\u4F7F\u3046\u6C17\u306B\u306A\u308C\u306A\u304B\u3063\u305F\u306E\u3068\u58F0\u304C\u30A2\u30EC\u3060\u3063\u305F\u3002\u78BA\u304B\u306B\u767D\u3044\u65B9\u306F\u58F0\u306F\u8A31\u5BB9\u51FA\u6765\u305F\u3051\u3069\u3002",
  "id" : 109267037951508481,
  "created_at" : "2011-09-01 14:11:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109264779952140289",
  "text" : "@koketomi \u30E9\u30D5\u30A3\u30FC\u30CA\u304C\u4EBA\u6C17\u3060\u3063\u305F\u5370\u8C61\u304C\u3042\u308B\u306A\u30FC\u3002",
  "id" : 109264779952140289,
  "created_at" : "2011-09-01 14:02:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109262440696520704",
  "text" : "@koketomi \u30A2\u30B3\u30FC\u30EB\u5148\u751F\u3068\u308A\u3093\u3054\u304C\u304A\u6C17\u306B\u5165\u308A\u3002",
  "id" : 109262440696520704,
  "created_at" : "2011-09-01 13:52:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109253503838461952",
  "text" : "@koketomi 20\u5468\u5E74\u306E\u3084\u3064\u300C\u3077\u3088\u3077\u3088!!\u300D \uFF33\uFF35\uFF2E\u304B\u3089\u307B\u3068\u3093\u3069\u898B\u3066\u306A\u3044\u81EA\u5206\u3068\u3057\u3066\u306F\u30AD\u30E3\u30E9\u306E\u30EA\u30B9\u30C8\u30E9\u3068\u304B\u30B0\u30E9\u30D5\u30A3\u30C3\u30AF\u306E\u7F8E\u5316\u3068\u304B\u885D\u6483\u7684\u3067\u3059\u3057",
  "id" : 109253503838461952,
  "created_at" : "2011-09-01 13:17:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109252158347681792",
  "text" : "\u66B4\u767A\u3057\u306A\u3044\u524D\u63D0\u306A\u3089\u3086\u3063\u304F\u308A\u3086\u3063\u304F\u308A11\u9023\u9396\u307E\u3067\u306F\u7D44\u3081\u308B\u3088\u3046\u306B\u306A\u3063\u305F\u300212\u306F\u90FD\u5408\u306E\u3044\u3044\u30C4\u30E2\u306E\u3068\u304D\u3060\u3051\u304B\u3002",
  "id" : 109252158347681792,
  "created_at" : "2011-09-01 13:11:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109245578403254272",
  "text" : "\u5B89\u5B9A\u3068\u4FE1\u983C\u306E\u6570\u5B66\u7387\u3002\u9AD8\u6821\u306E\u53CB\u4EBA\u304B\u3089\u306F\u4EAC\u90FD\u3063\u3066\u306E\u304C\u76EE\u7ACB\u3063\u305F\u306A\u3002\u307E\u3041\u60F3\u50CF\u901A\u308A\u304B\u3002",
  "id" : 109245578403254272,
  "created_at" : "2011-09-01 12:45:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 15, 24 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 38, 48 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u30923\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
      "indices" : [ 61, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109239995931426816",
  "text" : "\u5927\u6238\u5C4B\u3063\u3066\u4F55\u3055\uFF57\uFF57\uFF57\uFF57 RT @akeopyaa \u6570\u5B66 \u6587\u5B66 \u5927\u6238\u5C4B RT @end313124: \u6D41\u884C\u3063\u3066\u308B\u3057\u4FBF\u4E57\u30A1\uFF01\u3000#\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u30923\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
  "id" : 109239995931426816,
  "created_at" : "2011-09-01 12:23:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109234261860687872",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 109234261860687872,
  "created_at" : "2011-09-01 12:00:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u30923\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
      "indices" : [ 11, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109234168902320129",
  "text" : "\u6D41\u884C\u3063\u3066\u308B\u3057\u4FBF\u4E57\u30A1\uFF01\u3000#\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u30923\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
  "id" : 109234168902320129,
  "created_at" : "2011-09-01 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109220053110632448",
  "text" : "\u6570\u5B66\u306B\u3064\u3044\u3066\u306F\u610F\u8B58\u306E\u9AD8\u3044\u5B66\u751F\uFF01\u305F\u3060\u3057\u6587\u5B66\u90E8\u3063\uFF01\u307F\u305F\u3044\u306A\u3063\uFF01",
  "id" : 109220053110632448,
  "created_at" : "2011-09-01 11:04:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 17, 26 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u590F\u4F11\u307F\u7D42\u308F\u3063\u3066\u3082\u6771\u65B9\u597D\u304D\u306E\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
      "indices" : [ 43, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109218620114092033",
  "text" : "\u7D05\u9B54\u9928\u306E\u56F3\u66F8\u9928\u306B\u5C31\u8077\u3057\u305F\u3044 RT @koketomi \u3010\u901F\u5831\u3011\u65E9\u82D7\u3055\u3093\u3068\u7D50\u5A5A\u3057\u307E\u3057\u305F\u3000#\u590F\u4F11\u307F\u7D42\u308F\u3063\u3066\u3082\u6771\u65B9\u597D\u304D\u306E\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
  "id" : 109218620114092033,
  "created_at" : "2011-09-01 10:58:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109214284478816256",
  "text" : "16\u6642\u306B\u8D77\u304D\u308B\u7A0B\u5EA6\u306B\u306F\u663C\u591C\u304C\u9006\u8EE2\u3057\u3066\u3044\u308B\u3002\u307E\u305A\u3044\u3002",
  "id" : 109214284478816256,
  "created_at" : "2011-09-01 10:41:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109211466799915008",
  "geo" : { },
  "id_str" : "109214080736313344",
  "in_reply_to_user_id" : 230889478,
  "text" : "@kouennnoyuugu \u3042\u3068\u96E3\u3057\u3044\u78BA\u7387\u306B\u3064\u3044\u3066\u304A\u52E7\u3081\u306A\u306E\u304C\u30AB\u30EB\u30CE\u30FC\u56F3\u3068\u72B6\u614B\u9077\u79FB\u56F3\uFF01\u30F4\u30A7\u30F3\u56F3\u3088\u308A\u6C4E\u7528\u6027\u5E83\u3044\u3057\u3001\u898B\u305F\u76EE\u306B\u308F\u304B\u308A\u3084\u3059\u3044\u3002\u5927\u5B66\u3078\u306E\u6570\u5B66\u306E\u78BA\u7387\u7279\u96C6\u306E\u6708\u306B\u8F09\u3063\u3066\u308B\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u30FC\u3002",
  "id" : 109214080736313344,
  "in_reply_to_status_id" : 109211466799915008,
  "created_at" : "2011-09-01 10:40:40 +0000",
  "in_reply_to_screen_name" : "phy_neko",
  "in_reply_to_user_id_str" : "230889478",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109211512467488768",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u3061\u3087\u3063\u3068\u96E2\u8131\u3002",
  "id" : 109211512467488768,
  "created_at" : "2011-09-01 10:30:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109211102457507840",
  "geo" : { },
  "id_str" : "109211412089405440",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30D1\u30BF\u30EA\u30ED\u3063\u3066\u5C11\u5973\u6F2B\u753B\u3060\u3063\u305F\u306E\u304B\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 109211412089405440,
  "in_reply_to_status_id" : 109211102457507840,
  "created_at" : "2011-09-01 10:30:04 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109211316044050432",
  "text" : "\u7D44\u307F\u5408\u308F\u305B\u3068\u304B\u3067\u611A\u76F4\u306A\u6570\u3048\u4E0A\u3052\u306E\u6280\u8853\u306F\u3001\u305D\u308C\u306F\u305D\u308C\u3067\u78E8\u3044\u3066\u304A\u304F\u3079\u304D\u3060\u3068\u601D\u3063\u3066\u308B\u30AF\u30E9\u30B9\u30BF",
  "id" : 109211316044050432,
  "created_at" : "2011-09-01 10:29:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109211117347287041",
  "text" : "RT @JOJO_math: \u305F\u3063\u305F\u3072\u3068\u3064\u3060\u3051\u7B56\u306F\u3042\u308B\uFF01\u3068\u3063\u3066\u304A\u304D\u306E\u3084\u3064\u3060\uFF01\u3044\u3044\u304B\uFF01\u8A66\u9A13\u304C\u7D42\u308F\u308B\u307E\u3067\u3068\u3053\u3068\u3093\u3084\u308B\u305C\uFF01\u30D5\u30D5\u30D5\u30D5\u30D5\u30D5\u3002\u5168\u90E8\u306E\u4E8B\u8C61\u3092\u66F8\u304D\u51FA\u3059\u3093\u3060\u3088\u30A9\u30A9\u30A9\u30FC\u30C3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109210907120386048",
    "text" : "\u305F\u3063\u305F\u3072\u3068\u3064\u3060\u3051\u7B56\u306F\u3042\u308B\uFF01\u3068\u3063\u3066\u304A\u304D\u306E\u3084\u3064\u3060\uFF01\u3044\u3044\u304B\uFF01\u8A66\u9A13\u304C\u7D42\u308F\u308B\u307E\u3067\u3068\u3053\u3068\u3093\u3084\u308B\u305C\uFF01\u30D5\u30D5\u30D5\u30D5\u30D5\u30D5\u3002\u5168\u90E8\u306E\u4E8B\u8C61\u3092\u66F8\u304D\u51FA\u3059\u3093\u3060\u3088\u30A9\u30A9\u30A9\u30FC\u30C3\uFF01",
    "id" : 109210907120386048,
    "created_at" : "2011-09-01 10:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 109211117347287041,
  "created_at" : "2011-09-01 10:28:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109211062519336960",
  "text" : "\u4E45\u3005\u306B\u6E6F\u8239\u306B\u3064\u304B\u308B\u304B\u30FC\u3002\u305D\u3057\u3066\u673A\u3092\u7247\u4ED8\u3051\u3066\u4E45\u3005\u306B\u6570\u5B66\u3092\u3084\u308D\u3046\u3002\u590F\u4F11\u307F\u7D42\u308F\u3063\u305F\u3089\u3084\u308C\u3070\u3088\u304B\u3063\u305F\u3063\u3066\u306A\u308B\u306E\u304C\u76EE\u306B\u898B\u3048\u3059\u304E\u3066\u30A2\u30EC",
  "id" : 109211062519336960,
  "created_at" : "2011-09-01 10:28:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109210521907113985",
  "text" : "\u3053\u3063\u3061\u306E\u304C\u30C7\u30A3\u30FC\u30D7\u304B\u3002\u30A2\u30CB\u6A2A\u306B\u81F3\u3063\u3066\u306F\u63B2\u8F09\u8A8C\u304C\u30EA\u30DC\u30F3\u3060\u3057\u306A\uFF57\uFF57\u79C0\u9038\u306A\u30AE\u30E3\u30B0\u6F2B\u753B\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 109210521907113985,
  "created_at" : "2011-09-01 10:26:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109210366877249538",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u30A2\u30CB\u30DE\u30EB\u6A2A\u4E01\u3092\u77E5\u3063\u3066\u308B\u5148\u8F29\u304C\u3044\u3066\u611F\u8B1D\u611F\u6FC0\u96E8\u3042\u3089\u308C\u3060\u3063\u305F\u3002\u3061\u306A\u307F\u306B\u305D\u306E\u4EBA\u30AA\u30FC\u30DE\u30A4\u30AD\u30FC\u3082\u77E5\u3063\u3066\u305F\u3002\u7D20\u6674\u3089\u3057\u3044\u3002",
  "id" : 109210366877249538,
  "created_at" : "2011-09-01 10:25:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109209756467605504",
  "text" : "\u305D\u3082\u305D\u3082\u30C7\u30A3\u30FC\u30D7\u306A\u8DA3\u5473\u3060\u304B\u3089\u3042\u3093\u307E\u308A\u4E3B\u5F35\u3057\u306B\u304F\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u5999\u306A\u504F\u898B\u6301\u3063\u3066\u308B\u4EBA\u3044\u3066\u3082\u30A2\u30EC\u3060\u3057\u3002",
  "id" : 109209756467605504,
  "created_at" : "2011-09-01 10:23:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109209586812198912",
  "text" : "\u826F\u304F\u8003\u3048\u305F\u3089\u8EAB\u306E\u56DE\u308A\u306B\u6771\u65B9\u89E3\u308B\u4EBA\u304C\u3044\u306A\u3044\u304B\u3082\u306A\u30FC\u3002\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u306E\u4E2D\u306B\u306F\u7D50\u69CB\u3044\u308B\u3063\u307D\u3044\u3051\u3069\u6771\u65B9\u95A2\u9023\u306E\u4E8B\u67C4\u3067\u558B\u3063\u305F\u3053\u3068\u306A\u3044\u3084\u3002",
  "id" : 109209586812198912,
  "created_at" : "2011-09-01 10:22:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6614\u306E\u6587\u98A8",
      "screen_name" : "Amanokaze",
      "indices" : [ 3, 13 ],
      "id_str" : "419146333",
      "id" : 419146333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u590F\u4F11\u307F\u7D42\u308F\u3063\u3066\u3082\u6771\u65B9\u597D\u304D\u306E\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
      "indices" : [ 19, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109209311854604288",
  "text" : "RT @Amanokaze: \uFF12\u56DE\u76EE\u3000#\u590F\u4F11\u307F\u7D42\u308F\u3063\u3066\u3082\u6771\u65B9\u597D\u304D\u306E\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u590F\u4F11\u307F\u7D42\u308F\u3063\u3066\u3082\u6771\u65B9\u597D\u304D\u306E\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
        "indices" : [ 4, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109208351006658560",
    "text" : "\uFF12\u56DE\u76EE\u3000#\u590F\u4F11\u307F\u7D42\u308F\u3063\u3066\u3082\u6771\u65B9\u597D\u304D\u306E\u4EBA\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u304F\u308C\u308B",
    "id" : 109208351006658560,
    "created_at" : "2011-09-01 10:17:54 +0000",
    "user" : {
      "name" : "\u6587\u98A8@\u8266\u968A\u53C2\u8B00\u9577",
      "screen_name" : "Ayakaze_sec",
      "protected" : false,
      "id_str" : "283931000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418451494564675584\/qxmsSB5N_normal.jpeg",
      "id" : 283931000,
      "verified" : false
    }
  },
  "id" : 109209311854604288,
  "created_at" : "2011-09-01 10:21:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 27 ],
      "url" : "http:\/\/t.co\/NOx05N9",
      "expanded_url" : "http:\/\/togetter.com\/li\/168275",
      "display_url" : "togetter.com\/li\/168275"
    } ]
  },
  "geo" : { },
  "id_str" : "109209129494654976",
  "text" : "\u8A00\u8449\u904A\u3073\u81EA\u5206\u7528 http:\/\/t.co\/NOx05N9",
  "id" : 109209129494654976,
  "created_at" : "2011-09-01 10:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109207759576252418",
  "geo" : { },
  "id_str" : "109207935380500480",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4F55\u4F53\u3082\u3042\u3064\u307E\u308B\u3068\u60B2\u60E8\u3060\u3088\u3002",
  "id" : 109207935380500480,
  "in_reply_to_status_id" : 109207759576252418,
  "created_at" : "2011-09-01 10:16:15 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 24, 31 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 32, 42 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 54, 63 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 64, 74 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109207841289670656",
  "text" : "\u7D20\u6575\u306A\u30D5\u30A9\u30ED\u30EF\u2015\u306B\u6075\u307E\u308C\u3066\u5E78\u305B\u3067\u3059\uFF57\uFF57\uFF57 RT @ayu167 @end313124 \u30A4\u30AB\u3057\u3066\u308B\u306A  RT @akeopyaa @end313124 \u6D41\u77F3\u4EAC\u5927\u751F\u30B2\u30BD\uFF01\u3000\u30B9\u30DF\u306B\u7F6E\u3051\u306A\u3044\u3067\u30B2\u30BD\uFF01",
  "id" : 109207841289670656,
  "created_at" : "2011-09-01 10:15:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 30, 39 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 41, 51 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109207105029947392",
  "text" : "\u30CD\u30BF\u3067\u8A00\u3063\u3066\u3093\u306E\u304B\u3001\u307B\u3093\u3068\u306B\u305D\u3046\u3044\u3046\u5370\u8C61\u304C\u3042\u308B\u306E\u304B\u3002 RT @akeopyaa: @end313124: \u5C11\u5E74\u8A8C\u306E\u30D0\u30C8\u30EB\u6F2B\u753B\u3068\u304B\u3042\u3093\u307E\u308A\u597D\u304D\u3058\u3083\u306A\u3055\u305D\u3046\u3060\u306D",
  "id" : 109207105029947392,
  "created_at" : "2011-09-01 10:12:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109206977233698816",
  "text" : "\u565B\u3093\u3058\u3083\u3063\u305F\u3002\u3042\u305F\u308A\u3081\u3060\u3051\u306B\u3002",
  "id" : 109206977233698816,
  "created_at" : "2011-09-01 10:12:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109206897122492416",
  "text" : "\u3042\u305F\u308A\u3081\u3092\u98DF\u3079\u3064\u3064\n\uFF21\u300C\u5F53\u308A\u524D\u306E\u4E8B\u3044\u3046\u3051\u3069\u3042\u305F\u308A\u3081\u3046\u3081\u3047\u300D\n\uFF22\uFF3B\u3042\u305F\u308A\u3081\u3047\u3088\uFF3D\n\uFF23\u300C\u3053\u308C\u306F\u30A4\u30AB\u3093\u306A\u300D\n\u3063\u3066\u3084\u308A\u3068\u308A\u304C\u3042\u3063\u3066\u5E78\u305B\u3092\u565B\u3093\u3058\u305F\u3002",
  "id" : 109206897122492416,
  "created_at" : "2011-09-01 10:12:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109206557358698497",
  "text" : "\u6700\u8FD1\u30C4\u30A4\u30C3\u30BF\u30FC\u3092\u69CB\u3063\u3066\u3042\u3052\u3066\u306A\u304B\u3063\u305F\u304B\u3089\u30D5\u30A9\u30ED\u30EF\u2015\u304C\u3061\u3087\u3063\u3068\u6E1B\u3063\u3066\u3066\u60B2\u3057\u3044\u3002",
  "id" : 109206557358698497,
  "created_at" : "2011-09-01 10:10:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 0, 7 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109201021150048256",
  "geo" : { },
  "id_str" : "109206273714696192",
  "in_reply_to_user_id" : 129796835,
  "text" : "@7M1IHN \u672C\u4EBA\u306B\u306F\u25CB\u25CB\u5148\u751F\u304B\u25CB\u25CB\u6559\u6388\u3001\u672C\u4EBA\u3044\u306A\u3044\u3068\u3053\u308D\u3067\u306F\u3055\u3093\u4ED8\u3051\u3067\u547C\u3093\u3058\u3083\u3044\u307E\u3059\u306D\u3002",
  "id" : 109206273714696192,
  "in_reply_to_status_id" : 109201021150048256,
  "created_at" : "2011-09-01 10:09:39 +0000",
  "in_reply_to_screen_name" : "7M1IHN",
  "in_reply_to_user_id_str" : "129796835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109205902594277376",
  "text" : "\u53CB\u4EBA\uFF08\u8907\u6570\uFF09\u306B\u300C\u5C11\u5E74\u8A8C\u306E\u30D0\u30C8\u30EB\u6F2B\u753B\u3068\u304B\u3042\u3093\u307E\u308A\u597D\u304D\u3058\u3083\u306A\u3055\u305D\u3046\u300D\u3063\u3066\u8A00\u308F\u308C\u305F\u3002\u5927\u597D\u304D\u304B\u3068\u8A00\u308F\u308C\u305F\u3089\u5FAE\u5999\u3060\u3051\u3069\u5ACC\u3044\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u3069\u306A\u30FC\u3002\u305D\u3093\u306A\u5370\u8C61\u304C\u3042\u308B\u306E\u304B\u30FC\u3002",
  "id" : 109205902594277376,
  "created_at" : "2011-09-01 10:08:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109168658042986496",
  "text" : "\u304A\u3001\u304A\u306F\u3088\u3046",
  "id" : 109168658042986496,
  "created_at" : "2011-09-01 07:40:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/6LCEhB2",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "109073254060261376",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/6LCEhB2",
  "id" : 109073254060261376,
  "created_at" : "2011-09-01 01:21:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]