Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329203443686309889",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 329203443686309889,
  "created_at" : "2013-04-30 11:59:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329061140934062080",
  "text" : "\u30E8\u30AF\u30CA\u30A4",
  "id" : 329061140934062080,
  "created_at" : "2013-04-30 02:34:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329061112052064257",
  "text" : "\u4E8C\u65E5\u9023\u7D9A\u3067\u5BDD\u574A\u3068\u304B\u8A00\u3046\u30A4\u30F3\u30B7\u30C7\u30F3\u30C8",
  "id" : 329061112052064257,
  "created_at" : "2013-04-30 02:34:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328903825186492416",
  "text" : "\u3042\u30FC\u4E00\u65E5\u5F53\u305F\u308A",
  "id" : 328903825186492416,
  "created_at" : "2013-04-29 16:09:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328903773399420929",
  "text" : "\u6700\u8FD1\u30C4\u30A4\u30FC\u30C8\u6570\u304C\u4E00\u822C\u30E6\u30FC\u30B6\u30FC\u3081\u3044\u3066\u304D\u305F",
  "id" : 328903773399420929,
  "created_at" : "2013-04-29 16:09:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328895490043297792",
  "geo" : { },
  "id_str" : "328895611392905216",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 328895611392905216,
  "in_reply_to_status_id" : 328895490043297792,
  "created_at" : "2013-04-29 15:36:38 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328528646774075392",
  "geo" : { },
  "id_str" : "328528812356804610",
  "in_reply_to_user_id" : 427714784,
  "text" : "@miattermeyer \u30E6\u30A6\u30B8\u30E7\u30A6\uFF01",
  "id" : 328528812356804610,
  "in_reply_to_status_id" : 328528646774075392,
  "created_at" : "2013-04-28 15:19:07 +0000",
  "in_reply_to_screen_name" : "miantomori",
  "in_reply_to_user_id_str" : "427714784",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328527544343199745",
  "geo" : { },
  "id_str" : "328528266233257984",
  "in_reply_to_user_id" : 427714784,
  "text" : "@miattermeyer \u3069\u3046\u3067\u3082\u3044\u3044\u306D\u3001\u3068\u8A00\u3046Chrome\u306E\u30A2\u30C9\u30AA\u30F3\u304C\u3042\u3063\u3066\u3060\u306A\u2026",
  "id" : 328528266233257984,
  "in_reply_to_status_id" : 328527544343199745,
  "created_at" : "2013-04-28 15:16:57 +0000",
  "in_reply_to_screen_name" : "miantomori",
  "in_reply_to_user_id_str" : "427714784",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328478730680942594",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 328478730680942594,
  "created_at" : "2013-04-28 12:00:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328355973418872833",
  "text" : "\u65B0\u5E79\u7DDA\u4E88\u7D04\u3057\u305F",
  "id" : 328355973418872833,
  "created_at" : "2013-04-28 03:52:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328337878608404481",
  "text" : "\u97F3\u30B2\u30FC\u30D0\u30C8\u30EB\u30DE\u30F3\u30AC\u3042\u308B\u3042\u308B\u3092\u601D\u3044\u51FA\u3057\u305F",
  "id" : 328337878608404481,
  "created_at" : "2013-04-28 02:40:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryou Ezoe",
      "screen_name" : "EzoeRyou",
      "indices" : [ 3, 12 ],
      "id_str" : "547227711",
      "id" : 547227711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328337821255467008",
  "text" : "RT @EzoeRyou: \u305D\u3046\u3044\u3048\u3070\u5150\u7AE5\u7528\u306E\u5927\u8846\u5A2F\u697D\u3068\u3057\u3066\u80FD\u529B\u30D0\u30C8\u30EB\u306E\u30CD\u30BF\u306B\u30A8\u30C7\u30A3\u30BF\u30FC\u3068\u304B\u3069\u3046\u304B\u306A\u3002\n\u300C\u3084\u3081\u308D\u3001\u305D\u308C\u4EE5\u4E0AEmacs\u3092\u4F7F\u3046\u3068\u8171\u9798\u708E\u306B\u306A\u308B\u305E\uFF01\u3000Vim\u3092\u30FB\u30FB\u30FBVim\u3092\u4F7F\u3046\u3093\u3060\u300D\n\u300C\u3048\u3048\u3044\u3001\u6B63\u7FA9\u306E\u305F\u3081\u3060\uFF01\u300D\n\u300C\u3042\u30FB\u30FB\u30FB\u8DB3\u3067\u30AD\u30FC\u30DC\u30FC\u30C9\u3092\uFF01\u3000\u306A\u3093\u3066\u3084\u3064\u3060\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328337436881072130",
    "text" : "\u305D\u3046\u3044\u3048\u3070\u5150\u7AE5\u7528\u306E\u5927\u8846\u5A2F\u697D\u3068\u3057\u3066\u80FD\u529B\u30D0\u30C8\u30EB\u306E\u30CD\u30BF\u306B\u30A8\u30C7\u30A3\u30BF\u30FC\u3068\u304B\u3069\u3046\u304B\u306A\u3002\n\u300C\u3084\u3081\u308D\u3001\u305D\u308C\u4EE5\u4E0AEmacs\u3092\u4F7F\u3046\u3068\u8171\u9798\u708E\u306B\u306A\u308B\u305E\uFF01\u3000Vim\u3092\u30FB\u30FB\u30FBVim\u3092\u4F7F\u3046\u3093\u3060\u300D\n\u300C\u3048\u3048\u3044\u3001\u6B63\u7FA9\u306E\u305F\u3081\u3060\uFF01\u300D\n\u300C\u3042\u30FB\u30FB\u30FB\u8DB3\u3067\u30AD\u30FC\u30DC\u30FC\u30C9\u3092\uFF01\u3000\u306A\u3093\u3066\u3084\u3064\u3060\u300D",
    "id" : 328337436881072130,
    "created_at" : "2013-04-28 02:38:39 +0000",
    "user" : {
      "name" : "Ryou Ezoe",
      "screen_name" : "EzoeRyou",
      "protected" : false,
      "id_str" : "547227711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3362324601\/19b1c53bc705d2c624098f395ea3d358_normal.png",
      "id" : 547227711,
      "verified" : false
    }
  },
  "id" : 328337821255467008,
  "created_at" : "2013-04-28 02:40:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328336260114550785",
  "text" : "\u4ECA\u3059\u3050\u62B1\u3048\u3066\u3044\u308B\u3082\u306E\u3059\u3079\u3066\u6295\u3052\u51FA\u3057\u3066\u30CF\u30EF\u30A4\u306E\u30D3\u30FC\u30C1\u3067\u30D4\u30CA\u30B3\u30E9\u30FC\u30C0\u98F2\u307F\u305F\u3044",
  "id" : 328336260114550785,
  "created_at" : "2013-04-28 02:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328335570050883584",
  "text" : "\u3053\u3053\u6700\u8FD1\u30E8\u30FC\u30B0\u30EB\u30C8\u4E2D\u6BD2\u307F\u305F\u3044\u306B\u30E8\u30FC\u30B0\u30EB\u30C8\u3092\u6B32\u3057\u3066\u3044\u308B",
  "id" : 328335570050883584,
  "created_at" : "2013-04-28 02:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328161767597428736",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u50D5\u3001\u8336\u8272\u3044\u5098\u3092\u5FD8\u308C\u3066\u307E\u305B\u3093\u304B\uFF1F",
  "id" : 328161767597428736,
  "created_at" : "2013-04-27 15:00:37 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328156420639977472",
  "text" : "\u306A\u3093\u304B\u305A\u3063\u3068\u5FAE\u5999\u306A\u8ABF\u5B50\u3060\u3057\u65E9\u3081\u306B\u5BDD\u3066\u304A\u304F\u304B\u2026",
  "id" : 328156420639977472,
  "created_at" : "2013-04-27 14:39:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328148663912251392",
  "text" : "\u3042\u3068\u3088\u304F\u51B7\u3048\u3066\u308B\u304B\u3089\u3068\u3066\u3082\u5BD2\u3044",
  "id" : 328148663912251392,
  "created_at" : "2013-04-27 14:08:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328148607159132160",
  "text" : "\u304A\u3084\u3064\u306B\u30E8\u30FC\u30B0\u30EB\u30C8\u98DF\u3079\u305F\u3068\u601D\u3063\u305F\u3089\u4ECA\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u98F2\u3093\u3067\u308B",
  "id" : 328148607159132160,
  "created_at" : "2013-04-27 14:08:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328116392039698432",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 328116392039698432,
  "created_at" : "2013-04-27 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327483317953896448",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 327483317953896448,
  "created_at" : "2013-04-25 18:04:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327483268389826561",
  "text" : "\u3057\u304B\u3057\u3001\u4E45\u3005\u306B\u5C0F\u8AAC\u8AAD\u3080\u3068\u6570\u5B66\u66F8\u3068\u306E\u30DA\u30FC\u30B9\u306E\u9055\u3044\u306B\u9A5A\u304D\u6843\u306E\u6728\u5C71\u6912\u306E\u6728",
  "id" : 327483268389826561,
  "created_at" : "2013-04-25 18:04:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327483041004007424",
  "text" : "2\u7AE0\u304F\u3089\u3044\u307E\u3067\u547C\u8AAD\u3093\u3067\u5BDD\u308B\u3064\u3082\u308A\u304C12\u52DD\u307E\u3067\u8AAD\u3093\u3067\u305F\u3001\u5BDD\u306A\u3044\u3068\u2026",
  "id" : 327483041004007424,
  "created_at" : "2013-04-25 18:03:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327392674422337537",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 327392674422337537,
  "created_at" : "2013-04-25 12:04:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327314589756817409",
  "text" : "\u3082\u304616:00\u3068\u304B\u30B7\u30F3\u30B8\u30E9\u30EC\u30CA\u30FC\u30A4",
  "id" : 327314589756817409,
  "created_at" : "2013-04-25 06:54:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327314554457575424",
  "text" : "\u4FFA\u306E15\u6642\u3092\u76D7\u3093\u3060\u4EBA\u3001\u4ECA\u306A\u3089\u6012\u3089\u306A\u3044\u304B\u3089\u7D20\u76F4\u306B\u540D\u4E57\u308A\u51FA\u3066\u6B32\u3057\u3044",
  "id" : 327314554457575424,
  "created_at" : "2013-04-25 06:54:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327131847614144512",
  "text" : "\u307E\u3041\u826F\u3044\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 327131847614144512,
  "created_at" : "2013-04-24 18:48:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327130533387702272",
  "text" : "\u3042\u308C\u3001\"d\u3057\u307E\u3057\u305F\"\u3063\u3066DM\u3057\u307E\u3057\u305F\u3001\u306E\u610F\u5473\u3068\u3057\u3066\u306F\u3042\u3093\u307E\u308A\u6D41\u901A\u3057\u3066\u306A\u3044\u306E\u304B",
  "id" : 327130533387702272,
  "created_at" : "2013-04-24 18:42:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327130396775034880",
  "text" : "@reflexio DM\u3057\u307E\u3057\u305F\u306E\u7565\u3060\u3063\u305F\u304C[d\u3057\u307E\u3057\u305F]",
  "id" : 327130396775034880,
  "created_at" : "2013-04-24 18:42:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327129405900083200",
  "text" : "facebook\u6BBA\u4F10\u52E2\u3068\u3057\u3066\u3082\u7A7A\u6C17\u3092\u8AAD\u307E\u305A\u306B\u306F\u3044\u3089\u308C\u306A\u3044\u30EC\u30D9\u30EB",
  "id" : 327129405900083200,
  "created_at" : "2013-04-24 18:38:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327129180854702080",
  "text" : "@reflexio d\u3057\u307E\u3057\u305F",
  "id" : 327129180854702080,
  "created_at" : "2013-04-24 18:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327084767357054976",
  "text" : "\u8A00\u8449\u3092\u9078\u3076\u306E\u304C\u4E0B\u624B\u3060\u306A\u3041\u2026",
  "id" : 327084767357054976,
  "created_at" : "2013-04-24 15:41:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u897F",
      "screen_name" : "chinchikurim_ba",
      "indices" : [ 0, 16 ],
      "id_str" : "277901173",
      "id" : 277901173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327072402263638017",
  "geo" : { },
  "id_str" : "327072711597760513",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurim_ba \u306F\u3044",
  "id" : 327072711597760513,
  "in_reply_to_status_id" : 327072402263638017,
  "created_at" : "2013-04-24 14:53:05 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u897F",
      "screen_name" : "chinchikurim_ba",
      "indices" : [ 0, 16 ],
      "id_str" : "277901173",
      "id" : 277901173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327071323140546560",
  "geo" : { },
  "id_str" : "327071887463165953",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurim_ba \u9AD8\u91CE\u306A\u3089\u5965\u306B\u5C45\u307E\u3057\u305F(?)",
  "id" : 327071887463165953,
  "in_reply_to_status_id" : 327071323140546560,
  "created_at" : "2013-04-24 14:49:49 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327011728166617089",
  "text" : "\u30B6\u30C3\u30B1\u30F3\u30CA\u30B3\u30E9\u30FC\uFF01\u6210\u305B\u3070\u6210\u308B\uFF01",
  "id" : 327011728166617089,
  "created_at" : "2013-04-24 10:50:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327011213877850112",
  "text" : "\u5FAE\u7B11\u3063\u305F",
  "id" : 327011213877850112,
  "created_at" : "2013-04-24 10:48:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 3, 14 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u304A\u3070\u3042\u3061\u3083\u3093\u306E\u907A\u8A00\u3067\u9078\u629E\u516C\u7406\u306B\u3060\u3051\u306F\u8FD1\u3065\u304F\u306A\u3068",
      "indices" : [ 16, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327011143388372993",
  "text" : "RT @nonamea774: #\u304A\u3070\u3042\u3061\u3083\u3093\u306E\u907A\u8A00\u3067\u9078\u629E\u516C\u7406\u306B\u3060\u3051\u306F\u8FD1\u3065\u304F\u306A\u3068",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/github.com\/sorah\/udon_tairiku\" rel=\"nofollow\"\u003E\u3046\u3069\u3093\u5927\u9678 (Uton Tairiku)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u304A\u3070\u3042\u3061\u3083\u3093\u306E\u907A\u8A00\u3067\u9078\u629E\u516C\u7406\u306B\u3060\u3051\u306F\u8FD1\u3065\u304F\u306A\u3068",
        "indices" : [ 0, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327011018549108736",
    "text" : "#\u304A\u3070\u3042\u3061\u3083\u3093\u306E\u907A\u8A00\u3067\u9078\u629E\u516C\u7406\u306B\u3060\u3051\u306F\u8FD1\u3065\u304F\u306A\u3068",
    "id" : 327011018549108736,
    "created_at" : "2013-04-24 10:47:57 +0000",
    "user" : {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "protected" : false,
      "id_str" : "122305557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599956952429432832\/8y-IRC09_normal.png",
      "id" : 122305557,
      "verified" : false
    }
  },
  "id" : 327011143388372993,
  "created_at" : "2013-04-24 10:48:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2s_event",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327010191650467842",
  "text" : "\u3053\u308C\u306F\u5927\u5909\u3060(\u68D2\u8AAD\u307F) #s2s_event",
  "id" : 327010191650467842,
  "created_at" : "2013-04-24 10:44:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/YKjEg4Gnt8",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=enkunkun",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327010074709090304",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/YKjEg4Gnt8",
  "id" : 327010074709090304,
  "created_at" : "2013-04-24 10:44:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327008054350598144",
  "text" : "\u8FD4\u4FE1\u306E\u3064\u3082\u308A\u3060\u3063\u305F\u30C8\u30EA\u30D7\u30EB\u30BF\u30C3\u30D7\u304C\u3075\u3041\u307C\u306B\u306A\u3063\u3066\u305F\u306A",
  "id" : 327008054350598144,
  "created_at" : "2013-04-24 10:36:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/emylCnr2wS",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/kyoto.html",
      "display_url" : "sx9.jp\/weather\/kyoto.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "327007712514826240",
  "geo" : { },
  "id_str" : "327007880240832515",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u9060\u304B\u3089\u305A\u6B62\u3080 http:\/\/t.co\/emylCnr2wS",
  "id" : 327007880240832515,
  "in_reply_to_status_id" : 327007712514826240,
  "created_at" : "2013-04-24 10:35:28 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327007482729865217",
  "text" : "\u304B\u305A\u30FC\u6C0F\u30EC\u30D9\u30EB\u306E\u4EBA\u304C\u300C\u62E1\u6563\u3059\u308B\u306A\u300D\u3068\u304B\u8A00\u3063\u305F\u3089\u305D\u308A\u3083\u62E1\u6563\u3055\u308C\u308B\u3067\u3057\u3087\u3046\u3088",
  "id" : 327007482729865217,
  "created_at" : "2013-04-24 10:33:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327007079380426752",
  "text" : "AC\uFF5E\u266A",
  "id" : 327007079380426752,
  "created_at" : "2013-04-24 10:32:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327006357570080768",
  "text" : "\u3053\u306E2\u30E1\u30FC\u30C8\u30EB\u306A\u3044\u8DDD\u96E2\u3067\u30EA\u30D7\u30E9\u30A4\u98DB\u3070\u3059\u306E\u8D05\u6CA2\u306A\u611F\u3058\u3059\u308B",
  "id" : 327006357570080768,
  "created_at" : "2013-04-24 10:29:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327006089558253568",
  "geo" : { },
  "id_str" : "327006222232465408",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u305D\u306E\u307E\u307E\u306E\u610F\u5473\u3060\u3088\uFF01\uFF01\uFF01",
  "id" : 327006222232465408,
  "in_reply_to_status_id" : 327006089558253568,
  "created_at" : "2013-04-24 10:28:53 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327005950777106432",
  "text" : "\u5F7C\u5927\u62B5\u30CB\u30E4\u30CB\u30E4\u3057\u3066\u308B\u3051\u3069",
  "id" : 327005950777106432,
  "created_at" : "2013-04-24 10:27:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327005882984574978",
  "text" : "\u307E\u308C\u3044\u3093\u304C\u3053\u3063\u3061\u307F\u3066\u30CB\u30E4\u3063\u3066\u3057\u305F",
  "id" : 327005882984574978,
  "created_at" : "2013-04-24 10:27:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3046\u30C0\u30CB",
      "screen_name" : "tyage",
      "indices" : [ 0, 6 ],
      "id_str" : "43054063",
      "id" : 43054063
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u308F\u304B\u308B",
      "indices" : [ 7, 11 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327005551886221312",
  "geo" : { },
  "id_str" : "327005618802143233",
  "in_reply_to_user_id" : 43054063,
  "text" : "@tyage #\u308F\u304B\u308B",
  "id" : 327005618802143233,
  "in_reply_to_status_id" : 327005551886221312,
  "created_at" : "2013-04-24 10:26:29 +0000",
  "in_reply_to_screen_name" : "tyage",
  "in_reply_to_user_id_str" : "43054063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327005448890880000",
  "text" : "\u304A\u304B\u305A\u3067\u304D\u3066\u3066\u3054\u98EF\u708A\u3051\u3066\u306A\u3044\u306E\u56F3",
  "id" : 327005448890880000,
  "created_at" : "2013-04-24 10:25:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3046\u30C0\u30CB",
      "screen_name" : "tyage",
      "indices" : [ 0, 6 ],
      "id_str" : "43054063",
      "id" : 43054063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327005314182418432",
  "geo" : { },
  "id_str" : "327005387003920385",
  "in_reply_to_user_id" : 43054063,
  "text" : "@tyage \u3042\u308B\u3042\u308B",
  "id" : 327005387003920385,
  "in_reply_to_status_id" : 327005314182418432,
  "created_at" : "2013-04-24 10:25:34 +0000",
  "in_reply_to_screen_name" : "tyage",
  "in_reply_to_user_id_str" : "43054063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326989679717122048",
  "text" : "\u4ECA\u65E5\u306F\u65B0\u6B53\u8B1B\u7FA9\u306A\u306E\u304B\u3001\u60C5\u5F37\u306E\u4EBA\u304C\u8AB0\u304B\u3057\u3089\u5C45\u305D\u3046\u3060\u3057\u884C\u304F\u304B",
  "id" : 326989679717122048,
  "created_at" : "2013-04-24 09:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326987820075986944",
  "text" : "\u3042\u306815\u5206\u3082\u3059\u308C\u3070\u6B62\u3080\u306F\u305A",
  "id" : 326987820075986944,
  "created_at" : "2013-04-24 09:15:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326987581210378240",
  "text" : "\u884C\u304F\u5148\u306E\u7121\u3044\u30A8\u30F3\u30C9\u304C\u3001\u96E8\u3084\u307F\u3092\u5F85\u3063\u3066\u3044\u308B",
  "id" : 326987581210378240,
  "created_at" : "2013-04-24 09:14:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/DuacsrC54J",
      "expanded_url" : "http:\/\/4sq.com\/15Ex2dr",
      "display_url" : "4sq.com\/15Ex2dr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "326680577724010496",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/DuacsrC54J",
  "id" : 326680577724010496,
  "created_at" : "2013-04-23 12:54:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326669984027774976",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 326669984027774976,
  "created_at" : "2013-04-23 12:12:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326597944356790272",
  "text" : "\u65B0\u3057\u3044\u30AA\u30FC\u30EB\u30C9\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u3001\u524D\u306E\u3082\u306E\u3088\u308A\u8EFD\u3044\u611F\u3058\u3059\u308B\u3051\u3069\u6C17\u306E\u305B\u3044\u304B\u306A",
  "id" : 326597944356790272,
  "created_at" : "2013-04-23 07:26:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326578248815362048",
  "text" : "\u4ECA\u601D\u3046\u3068\u5730\u5473\u306B\u717D\u3063\u3066\u3044\u305F\u611F\u3042\u308B\u306A",
  "id" : 326578248815362048,
  "created_at" : "2013-04-23 06:08:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326578123460194304",
  "text" : "thunderfist\u3001\u7D66\u6599\u65E5\u306E\u6B21\u306E\u6B21\u304F\u3089\u3044\u306B\u697D\u3057\u307F\u306B\u3057\u3066\u308B",
  "id" : 326578123460194304,
  "created_at" : "2013-04-23 06:07:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "indices" : [ 0, 8 ],
      "id_str" : "16331213",
      "id" : 16331213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326577680499761152",
  "geo" : { },
  "id_str" : "326577927581995009",
  "in_reply_to_user_id" : 16331213,
  "text" : "@kazoo04 \u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\u304C\u66F4\u65B0\u3055\u308C\u3066\u3044\u306A\u3044\u3068\u3053\u308D\u307F\u308B\u3068\u304A\u5FD9\u3057\u3044\u3093\u3067\u3059\u306D[\u671F\u5F85\u3057\u3066\u307E\u3059\u3088]",
  "id" : 326577927581995009,
  "in_reply_to_status_id" : 326577680499761152,
  "created_at" : "2013-04-23 06:07:00 +0000",
  "in_reply_to_screen_name" : "kazoo04",
  "in_reply_to_user_id_str" : "16331213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326576274422255616",
  "text" : "\u3044\u3084\u307E\u3041\u5F7C\u3082\u76F4\u5F8C\u306B\u52D8\u9055\u3044\u306B\u6C17\u3065\u3044\u3066\u307E\u3057\u305F\u3051\u3069",
  "id" : 326576274422255616,
  "created_at" : "2013-04-23 06:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326576174375530497",
  "text" : "\u53CB\u4EBA\u304C\u4E00\u822C\u6559\u990A\u306E\"\u30EC\u30DD\u30FC\u30C8\u63D0\u51FA\u306F3\u56DE\u4EE5\u4E0A\"\u306B\u3064\u3044\u3066\u300C\u4E00\u822C\u6559\u990A\u306F\u4E0A\u56DE\u751F\u306B\u53B3\u3057\u3059\u304E\u308B\u3001\u306A\u3093\u30671,2\u56DE\u751F\u306F\u30EC\u30DD\u30FC\u30C8\u7121\u3044\u3093\u3060\u3088\u300D\u3068\u304B\u8A00\u3063\u3066\u3066( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 326576174375530497,
  "created_at" : "2013-04-23 06:00:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326575715317317632",
  "text" : "\u4E00\u56DE\u3001\u4E8C\u56DE\u3067\u307B\u3068\u3093\u3069\u4F55\u3082\u3057\u3066\u306A\u304B\u3063\u305F\u81EA\u5DF1\u5ACC\u60AA\u306A\u2026[\u6570\u5B66\u3082\u305D\u308C\u4EE5\u5916\u3082]",
  "id" : 326575715317317632,
  "created_at" : "2013-04-23 05:58:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326574860941803520",
  "text" : "\u3061\u3083\u3093\u3068\u3057\u305F\u3044\u3001\u3068\u8A00\u3046\u306E\u304C\u3053\u3053\u6570\u30F6\u6708\u306E\u552F\u4E00\u306E\u9858\u3044",
  "id" : 326574860941803520,
  "created_at" : "2013-04-23 05:54:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326574719191101441",
  "text" : "\u3084\u308B\u6C17\u3068\u304B\u3082\u3042\u308B\u3051\u3069\u3001\u6D41\u3057\u8AAD\u307F\u306A\u306E\u304B\u7CBE\u8AAD\u306A\u306E\u304B\u306B\u3082\u4F9D\u308B",
  "id" : 326574719191101441,
  "created_at" : "2013-04-23 05:54:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326574631987331072",
  "text" : "\u82F1\u8A9E\u8AAD\u3080\u901F\u5EA6\u304C\u6587\u732E\u306B\u3088\u3063\u3066\u307E\u3061\u307E\u3061\u306A\u306E\u306F\u82F1\u8A9E\u306E\u8AAD\u307F\u3084\u3059\u3055\u306A\u306E\u304B\u5358\u8A9E\u306E\u77E5\u8B58\u91CF\u306A\u306E\u304B\u306A\u3093\u306A\u306E\u304B",
  "id" : 326574631987331072,
  "created_at" : "2013-04-23 05:53:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326573937070850048",
  "text" : "\u6570\u5B66\u5BB6\u3068\u304B\u6B74\u53F2\u8005\u3068\u304B\u8A00\u308F\u306A\u3044\u3088\u306D\u3047",
  "id" : 326573937070850048,
  "created_at" : "2013-04-23 05:51:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326573873074151424",
  "text" : "\u6570\u5B66\u8005\u3001\u6B74\u53F2\u5BB6\u3001\u7269\u7406\u5C4B\u3068\u304B\u8272\u3005\u8A00\u3044\u65B9\u3042\u308B\u3051\u3069\u8005\u3068\u5BB6\u3063\u3066\u304D\u3061\u3093\u3068\u7406\u7531\u304C\u3042\u3063\u3066\u5206\u3051\u3089\u308C\u3066\u308B\u306E\u304B\u306A[hogehoge\u5C4B\u306F\u6163\u7FD2\u7684\u306A\u547C\u3073\u65B9\u3063\u307D\u3044\u3051\u3069]",
  "id" : 326573873074151424,
  "created_at" : "2013-04-23 05:50:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326573131764465664",
  "text" : "\u307E\u3041\u81EA\u8AAC\u3092\u78BA\u7ACB\u3057\u3066\u3082\u53CD\u4F8B\u7684\u306A\u53F2\u6599\u304C\u4E00\u3064\u898B\u3064\u304B\u308B\u3068\u5168\u90E8\u304A\u3058\u3083\u3093\u3060\u3051\u3069\u306D\u3001\u3068\u3082\u8A00\u3063\u3066\u305F\u304C",
  "id" : 326573131764465664,
  "created_at" : "2013-04-23 05:47:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326572965896536065",
  "text" : "\u3059\u3054\u3044\u52B4\u529B\u3060\u304B\u3089\u5C0A\u656C\u3059\u308B",
  "id" : 326572965896536065,
  "created_at" : "2013-04-23 05:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326572928164577280",
  "text" : "\u9AD8\u6821\u306E\u6B74\u53F2\u306F\u3076\u3063\u3061\u3083\u3051\u5168\u7136\u9762\u767D\u304F\u306A\u304B\u3063\u305F\u3051\u3069\u3001\u6559\u6388\u304C\u3059\u308B\u53F2\u6599\u306B\u5F53\u305F\u3063\u3066\u81EA\u8AAC\u3092\u78BA\u304B\u3081\u3066\u3044\u304F\u8A71\u306F\u7D50\u69CB\u697D\u3057\u305D\u3046",
  "id" : 326572928164577280,
  "created_at" : "2013-04-23 05:47:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326572331159941121",
  "geo" : { },
  "id_str" : "326572575587196928",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6B74\u53F2\u5BB6\u304C\u3069\u3053\u304B\u306E\u30B5\u30FC\u30D0\u30FC\u306B\u30AD\u30E3\u30C3\u30B7\u30E5\u306E\u6B8B\u3063\u305F\u30BC\u30EA\u30FC\u3055\u3093\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u898B\u3064\u3051\u3066\u72C2\u559C\u4E71\u821E\u3059\u308B\u672A\u6765\u304C\u898B\u3048\u305F",
  "id" : 326572575587196928,
  "in_reply_to_status_id" : 326572331159941121,
  "created_at" : "2013-04-23 05:45:44 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326572164079837184",
  "text" : "\u7D19\u306E\u8F9E\u66F8\u597D\u304D\u3060\u3051\u3069\u65E9\u3055\u304C\u8DB3\u308A\u306A\u3044\u306A",
  "id" : 326572164079837184,
  "created_at" : "2013-04-23 05:44:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326572128663130112",
  "text" : "\u5358\u8A9E\u30BF\u30C3\u30C1\u3057\u305F\u3089\u8F9E\u66F8\u5F15\u3044\u3066\u304F\u308C\u308B\u306E\u304C\u89AA\u5207\u3059\u304E\u3066\u96FB\u5B50\u8F9E\u66F8\u3055\u3048\u9762\u5012\u306B\u611F\u3058\u308B[\u7D19\u306E\u8F9E\u66F8\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B]",
  "id" : 326572128663130112,
  "created_at" : "2013-04-23 05:43:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326571837444194304",
  "text" : "kindle\u3067\u6D0B\u66F8\u8AAD\u3080\u306E\u304C\u5FEB\u9069\u904E\u304E\u3066\u7D19\u3067\u8AAD\u3080\u306E\u304C\u9762\u5012\u306A\u6C17\u304C\u3057\u3066\u304F\u308B\u306A\uFF1F",
  "id" : 326571837444194304,
  "created_at" : "2013-04-23 05:42:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/7tZrITqGHx",
      "expanded_url" : "http:\/\/item.rakuten.co.jp\/cinemacollection\/sm-mkkn04\/",
      "display_url" : "item.rakuten.co.jp\/cinemacollecti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326348889303179264",
  "text" : "\u3053\u306E\u5DFE\u7740\u888B\u306E\u30A2\u30D0\u30F3\u30AE\u30E3\u30EB\u30C9\u611F\u30E4\u30D0\u30A4http:\/\/t.co\/7tZrITqGHx",
  "id" : 326348889303179264,
  "created_at" : "2013-04-22 14:56:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326317159204679680",
  "text" : "\u4F55\u304C\u56F0\u308B\u3063\u3066TeX\u74B0\u5883\u3092\u5168\u90E8Ubuntu\u306B\u96C6\u4E2D\u3055\u305B\u3066\u305F\u3053\u3068",
  "id" : 326317159204679680,
  "created_at" : "2013-04-22 12:50:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326316881571115009",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u81EA\u5206\u7528\u306B\u3084\u3063\u305F\u3053\u3068\uFF0C\u898B\u305F\u30B5\u30A4\u30C8\u306A\u3093\u304B\u3092\u307E\u3068\u3081\u308B\u305F\u3081\u306B\u3068\u3045\u304E\u3083\u3063\u3066\u307F\u305F\uFF0E",
  "id" : 326316881571115009,
  "created_at" : "2013-04-22 12:49:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/m9bzDoo27Z",
      "expanded_url" : "http:\/\/togetter.com\/li\/491791",
      "display_url" : "togetter.com\/li\/491791"
    } ]
  },
  "geo" : { },
  "id_str" : "326316535025127424",
  "text" : "\u300C\u8D77\u52D5\u3057\u306A\u3044end\u3055\u3093\u306EUbuntu\u300D\u3092\u30C8\u30A5\u30AE\u30E3\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/m9bzDoo27Z",
  "id" : 326316535025127424,
  "created_at" : "2013-04-22 12:48:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326314973439598592",
  "text" : "\u8D77\u52D5\u3057\u305D\u3046\u3067\u8D77\u52D5\u3057\u306A\u3044,\u3067\u3082\u3084\u3063\u3071\u308A\u8D77\u52D5\u3057\u306A\u3044\uFF0CUbuntu",
  "id" : 326314973439598592,
  "created_at" : "2013-04-22 12:42:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326314401256837121",
  "text" : "SYSLINUX 4.03 2010-10-22 EDD Copyright (C) 1994-2010 H. Peter Anvin et al \n\u3068\u66F8\u3044\u3066\u3042\u308B\u72B6\u614B\u304B\u3089\u52D5\u304B\u306A\u3044\u306E\u3067\u3059",
  "id" : 326314401256837121,
  "created_at" : "2013-04-22 12:39:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/RPVyTXlqs2",
      "expanded_url" : "http:\/\/detail.chiebukuro.yahoo.co.jp\/qa\/question_detail\/q1085259015",
      "display_url" : "detail.chiebukuro.yahoo.co.jp\/qa\/question_de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326314324849201152",
  "text" : "\u3068\u306F\u3044\u3048\u3053\u308C(http:\/\/t.co\/RPVyTXlqs2)\u898B\u308B\u9650\u308ASYSLINUX 4.03 2010-10-22 EDD Co( ry\u3068\u304B\u51FA\u3066\u308B\u3057USB\u304B\u3089\u6B63\u5E38\u306B\u8D77\u52D5\u51FA\u6765\u3066\u308B\u3063\u307D\u3044\u304B\u3089\u539F\u56E0\u306F\u307B\u304B\u306B\u3042\u308B\u306E\u304B\u306D",
  "id" : 326314324849201152,
  "created_at" : "2013-04-22 12:39:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326313532880719873",
  "text" : "\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u306E\u65B9\u5F0F\u304C\u307E\u305A\u3044\u306E\u304B\uFF0C\u3042\u308B\u3044\u306FUSB\u8D77\u52D5\u30C7\u30A3\u30B9\u30AF\u306E\u4F5C\u6210\u306B\u3064\u3044\u3066\u306A\u3093\u304B\u307E\u305A\u3044\u306E\u304B\uFF0C\u3042\u308B\u3044\u306FUSB\u305D\u306E\u3082\u306E\u304C\u307E\u305A\u3044\u306E\u304B",
  "id" : 326313532880719873,
  "created_at" : "2013-04-22 12:36:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326313392409284609",
  "text" : "USB\u306E\u30C7\u30FC\u30BF\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3068\u3063\u3066\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u3057\u3066\u304B\u3089ISO\u30A4\u30E1\u30FC\u30B8\u3067USB\u8D77\u52D5\u30C7\u30A3\u30B9\u30AF\u4F5C\u6210\u3057\u305F\u3051\u3069\u30C0\u30E1\u3060\u3063\u305F",
  "id" : 326313392409284609,
  "created_at" : "2013-04-22 12:35:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326310317112053761",
  "text" : "\u306A\u305CUSB\u304B\u3089\u304D\u3069\u3046\u3057\u3066\u304F\u308C\u306A\u3044\u306E\u304B",
  "id" : 326310317112053761,
  "created_at" : "2013-04-22 12:23:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326310266692329472",
  "text" : "\u3046\u304A\u3042\u3042\u3042\u3042",
  "id" : 326310266692329472,
  "created_at" : "2013-04-22 12:23:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326310211805642752",
  "text" : "\u5916\u4ED8\u3051\u306ECD\u30C9\u30E9\u30A4\u30D6\u3082\u884C\u65B9\u4E0D\u660E\u3060\u3057\u306A\uFF1F",
  "id" : 326310211805642752,
  "created_at" : "2013-04-22 12:23:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326310150992441344",
  "text" : "ubuntu\u304C\u8D77\u52D5\u3057\u306A\u304F\u3066\u8F9B\u3044",
  "id" : 326310150992441344,
  "created_at" : "2013-04-22 12:22:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326135665848897537",
  "text" : "\u7518\u7F8E\u306A\u4E8C\u5EA6\u5BDD\u304B\u3089\u306E\u304A\u306F\u3088\u3046",
  "id" : 326135665848897537,
  "created_at" : "2013-04-22 00:49:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326001504441991170",
  "text" : "\u5B9F\u969B\u5727\u5012\u7684\u53EF\u611B\u3055\u3060\u3063\u305F(^^)(^^)(^^)",
  "id" : 326001504441991170,
  "created_at" : "2013-04-21 15:56:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326001465950883840",
  "text" : "\u3042\u3068RIMS\u306E\u524D\u3067\u732B\u69D8\u3068\u622F\u308C\u305F\u3001\u4E45\u3005\u306B\u732B\u89E6\u3063\u305F",
  "id" : 326001465950883840,
  "created_at" : "2013-04-21 15:56:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326001127097245696",
  "text" : "\u30DD\u30B9\u30C8\u30E2\u30C0\u30F3\u89E3\u6790\u5B66\u306E\u8868\u7D19\u3092\u898B\u3066\u300C\u3048\u3063\u3001\u30DD\u30B9\u30C8\u30E2\u30C0\u30F3\u2026\uFF1F\uFF01\u300D\u3068\u3044\u3046\u304B\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u306F\u5168\u304F\u6301\u3063\u3066\u5F53\u7136\u306E\u305D\u308C",
  "id" : 326001127097245696,
  "created_at" : "2013-04-21 15:55:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325999110136152066",
  "text" : "\u6628\u65E5\u671F\u305B\u305A\u3057\u3066\u307F\u305E\u308C\u5973\u53F2\u3068\u306E\u30A8\u30F3\u30AB\u30A6\u30F3\u30C8\u3092\u679C\u305F\u3057\u305F\u3093\u3060\u3063\u305F",
  "id" : 325999110136152066,
  "created_at" : "2013-04-21 15:46:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325942818180849664",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 325942818180849664,
  "created_at" : "2013-04-21 12:03:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325934843290595330",
  "text" : "\u30CC\u30CC\u30CC\u30CC\u6587\u5BF8",
  "id" : 325934843290595330,
  "created_at" : "2013-04-21 11:31:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325934738604953600",
  "text" : "TL\u898B\u3066\u308B\u3068bidual\u306F\u4E8C\u91CD\u53CC\u5BFE\u3068\u8A33\u3059\u306E\u304C\u826F\u3044\u6A21\u69D8\u3001\u53CC\u53CC\u5BFE\u3068\u304B\u3042\u308C\u3060\u3082\u3093\u306D",
  "id" : 325934738604953600,
  "created_at" : "2013-04-21 11:31:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325851193630920706",
  "text" : "\u72D0\u306E\u5AC1\u5165\u308A\u3081\u3044\u3066\u3044\u308B",
  "id" : 325851193630920706,
  "created_at" : "2013-04-21 05:59:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u307F\u306A\u3061\u3083\u3093",
      "screen_name" : "rumichang",
      "indices" : [ 0, 10 ],
      "id_str" : "242763253",
      "id" : 242763253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325807428551704577",
  "geo" : { },
  "id_str" : "325807482733735936",
  "in_reply_to_user_id" : 242763253,
  "text" : "@rumichang \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 325807482733735936,
  "in_reply_to_status_id" : 325807428551704577,
  "created_at" : "2013-04-21 03:05:31 +0000",
  "in_reply_to_screen_name" : "rumichang",
  "in_reply_to_user_id_str" : "242763253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325797617474875393",
  "text" : "\u30AA\u30EA\u30FC\u30D6\u3068\u30AA\u30EA\u30FC\u30D6\u30AA\u30A4\u30EB\u304C\u88AB\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 325797617474875393,
  "created_at" : "2013-04-21 02:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325797476156203008",
  "text" : "\u30AA\u30EA\u30FC\u30D6\u3068\u30AD\u30E3\u30D9\u30C4\u306E\u30DA\u30DA\u30ED\u30F3\u30C1\u30FC\u30CE\u98DF\u3079\u3066\u308B\uFF0E\u30B7\u30F3\u30D7\u30EB\uFF0E",
  "id" : 325797476156203008,
  "created_at" : "2013-04-21 02:25:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325789042912407553",
  "text" : "\u30D1\u30B9\u30BF\u306B\u5869\u4E91\u3005\u306E\u307E\u3068\u3081\u3061\u3083\u3093\u3068\u8AAD\u3080\u3068\u672C\u5F53\u306B\u53E9\u304D\u306E\u3081\u3057\u3066\u3044\u308B\u611F\u3058\u3059\u308B\u306A",
  "id" : 325789042912407553,
  "created_at" : "2013-04-21 01:52:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325785344656175106",
  "geo" : { },
  "id_str" : "325787576638271491",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u30E6\u30A6\u30B8\u30E7\u30A6\uFF01",
  "id" : 325787576638271491,
  "in_reply_to_status_id" : 325785344656175106,
  "created_at" : "2013-04-21 01:46:25 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325784615186997250",
  "geo" : { },
  "id_str" : "325784855000543232",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u6559\u3048\u305F\u304F\u306A\u3044\u306A\u3089\u305D\u3046\u3067\u3059\u306D[\u4ED6\u4EBA\u306E\u30A2\u30AB\u3092\u6559\u3048\u308B\u3068\u3044\u3046\u30A4\u30BF\u30BA\u30E9\u3082\u3042\u308A\u307E\u3059\u3051\u3069]",
  "id" : 325784855000543232,
  "in_reply_to_status_id" : 325784615186997250,
  "created_at" : "2013-04-21 01:35:36 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325784493053063168",
  "text" : "\u3042\u3001\u30C0\u30DF\u30FC\u30A2\u30AB\u4F5C\u3063\u3066\u304A\u304F\u3068\u8A00\u3046\u306E\u3082\u3042\u3063\u305F\u306A",
  "id" : 325784493053063168,
  "created_at" : "2013-04-21 01:34:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325784081956745218",
  "geo" : { },
  "id_str" : "325784350039871489",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u3084\u3063\u3066\u306A\u3044\/\u3084\u3063\u3066\u305F\u3051\u3069\u3084\u3081\u305F\/\u7D20\u76F4\u306B\u6559\u3048\u308B\/\u6559\u3048\u3066\u3082\u3089\u3063\u3066\u5148\u5236\u30D6\u30ED\u30C3\u30AF",
  "id" : 325784350039871489,
  "in_reply_to_status_id" : 325784081956745218,
  "created_at" : "2013-04-21 01:33:36 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325783986649583616",
  "text" : "\u3042\u3068\u3001\u4F53\u80B2\u3092\u898B\u5B66\u3059\u308B\u5922\u3092\u898B\u305F\u3002\u5922\u306E\u4E2D\u3067\u304F\u3089\u3044\u53C2\u52A0\u3057\u308D\u3088\u306A\uFF1F",
  "id" : 325783986649583616,
  "created_at" : "2013-04-21 01:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325783448054796291",
  "text" : "\u3042\u3068\u300C\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01\u300D\u3068\u66F8\u3044\u3066\u3042\u308B\u30C4\u30A4\u30FC\u30C8\u3092\u30BF\u30C3\u30D7\u3059\u308B\u3068\u4E00\u5B9A\u78BA\u7387\u3067\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u304C\u51FA\u3066\u304F\u308B\u5922\u3092\u898B\u305F\u3002\u51B7\u9759\u306B\u8003\u3048\u308B\u3068\u672C\u5F53\u306B\u610F\u5473\u304C\u5206\u304B\u3089\u306A\u3044\u3002",
  "id" : 325783448054796291,
  "created_at" : "2013-04-21 01:30:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325782172441145344",
  "text" : "\u60C5\u5831\u5897\u3048\u3066\u306A\u3044\u306A\uFF1F",
  "id" : 325782172441145344,
  "created_at" : "2013-04-21 01:24:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325782107144212480",
  "text" : "\u5206\u304B\u3089\u306A\u3044\u554F\u984C\u3092\u4EBA\u306B\u805E\u3044\u3066\u3001\u300C\u826F\u3044\u7DDA\u8A00\u3063\u3066\u308B\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u5922\u3092\u898B\u305F\u3051\u3069\u3001\u3053\u308C\u4F55\u3082\u3058\u3087",
  "id" : 325782107144212480,
  "created_at" : "2013-04-21 01:24:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325687038273798144",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 325687038273798144,
  "created_at" : "2013-04-20 19:06:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325686143972691969",
  "geo" : { },
  "id_str" : "325686374785249280",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u3068\u3082\u3059\u308C\u3070\u7537\u306B\u3044\u3046\u3079\u304D\u30BB\u30EA\u30D5\u3067\u3082\u306A\u304B\u308D\u3046",
  "id" : 325686374785249280,
  "in_reply_to_status_id" : 325686143972691969,
  "created_at" : "2013-04-20 19:04:17 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325686142831833088",
  "text" : "\u3068\u601D\u3063\u305F\u304C\u3081\u3060\u304B\u30DC\u30C3\u30AF\u30B9\u3067\"\u30B9\u30AD\u30EB\u3092\u55B0\u3044\u6539\u3081\u308B\u30B9\u30AD\u30EB\"\u304C\u3042\u3063\u305F\u306A\uFF1F",
  "id" : 325686142831833088,
  "created_at" : "2013-04-20 19:03:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325685738131820544",
  "text" : "4\u6642\u304B\u2026",
  "id" : 325685738131820544,
  "created_at" : "2013-04-20 19:01:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325685592581083136",
  "text" : "\u524D\u304B\u3089\u3060\u3051\u3069\u5927\u5B66\u6B63\u9580\u5411\u304B\u3044\u306E\u304A\u5F01\u5F53\u5C4B\u3055\u3093\u306E\"\u7384\u7C73\u6DF7\u305C\u3054\u98EF\"\u304C\u7F8E\u5473\u3057\u3059\u304E\u3066\u3088\u304F\u98DF\u3079\u3066\u308B",
  "id" : 325685592581083136,
  "created_at" : "2013-04-20 19:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 12, 22 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325685273117724673",
  "text" : "\u8AB0\u7F8E\u5473 RT \u9375\u30A2\u30AB: @end313124 \u55B0\u3044\u6539\u3081\u306A\u3055\u3044\u2026",
  "id" : 325685273117724673,
  "created_at" : "2013-04-20 18:59:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325684685508329472",
  "text" : "\u300C\u4ECA\u65E5\u3001\u8D16\u7F6A\u3092\u9001\u308A\u307E\u3057\u305F\u3002\u6BCD\u3088\u308A\u300D\u307F\u305F\u3044\u306A\u30E1\u30FC\u30EB\u6765\u305F\u3089\u6226\u6144\u3059\u308B\u308F\u3002",
  "id" : 325684685508329472,
  "created_at" : "2013-04-20 18:57:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325684296356614144",
  "text" : "\u306A\u3093\u3067\u8D16\u7F6A\u306E\u65B9\u304C\u5148\u306B\u51FA\u305F\u306E\u304B\u7406\u89E3\u306B\u82E6\u3057\u3080",
  "id" : 325684296356614144,
  "created_at" : "2013-04-20 18:56:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325684211161890816",
  "text" : "\u8D16\u7F6A\u304C\u5C4A\u304F\u3068\u304B\u3084\u3070\u3044[\u98DF\u6750\u306A]",
  "id" : 325684211161890816,
  "created_at" : "2013-04-20 18:55:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325684111261982720",
  "text" : "\u5B9F\u5BB6\u304B\u3089\u8D16\u7F6A\u304C\u5C4A\u304F\u3068\u305F\u307E\u306B\u3084\u308B",
  "id" : 325684111261982720,
  "created_at" : "2013-04-20 18:55:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325683637964140544",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u300C\u6599\u7406\u5F97\u610F\u3084\u3067\u30FC(\u30C9\u30E4\u30A1\u300D\u3063\u3066\u8A00\u3046\u3060\u3051\u3088\u308A\u8AB0\u304B\u547C\u3093\u3067\u5BB6\u3067\u3054\u98EF\u3092\u632F\u821E\u3063\u305F\u65B9\u304C\u5B9F\u969B\u697D\u3057\u3044\u3057\u632F\u821E\u308F\u308C\u305F\u65B9\u3082\u5B09\u3057\u3044\u306A\u3001\u3068\u6700\u8FD1\u601D\u3063\u3066\u3044\u308B",
  "id" : 325683637964140544,
  "created_at" : "2013-04-20 18:53:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325682196100825088",
  "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u3068\u306E\u30E6\u30A6\u30B8\u30E7\u30A6\u3082\u6DF1\u307E\u308A\u30E0\u30E9\u30CF\u30C1\u306B\u3055\u308C\u306A\u3044\u5B9F\u969B\u5965\u3086\u304B\u3057\u3044\u6587\u5316\u3060\u3068\u601D\u3046\u306E\u3060\u304C\u2026",
  "id" : 325682196100825088,
  "created_at" : "2013-04-20 18:47:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325681894597468162",
  "text" : "\u30EA\u30D7\u30E9\u30A4\u306E\u7D42\u308F\u308A\u969B\u306B\"\u8AAD\u3093\u3060\u3051\u3069\u3082\u3046\u30EA\u30D7\u30E9\u30A4\u3057\u306A\u3044\u3088\u306E\u3075\u3041\u307C\"\u3067\u306A\u304F\u304A\u4E92\u3044\u306B\"\u30E6\u30A6\u30B8\u30E7\u30A6\uFF01\"\u3068\u9001\u308A\u5408\u3046\u6587\u5316\u3092\u6D41\u884C\u3089\u305B\u305F\u3044",
  "id" : 325681894597468162,
  "created_at" : "2013-04-20 18:46:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325680992415277056",
  "text" : "\u5869\u5473\u306F\u7DCF\u3058\u3066\u9069\u5F53\u3067\u3082\u306A\u3093\u3068\u306A\u304F\u4E0A\u624B\u304F\u3044\u304F\u3051\u3069\u7518\u307F\u306F\u4E01\u5BE7\u306B\u3084\u3089\u306A\u3044\u3068\u30D0\u30E9\u30F3\u30B9\u5D29\u3057\u3084\u3059\u3044\u5370\u8C61\u3042\u308B\u306A",
  "id" : 325680992415277056,
  "created_at" : "2013-04-20 18:42:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conjugate_box",
      "screen_name" : "conjugate_box",
      "indices" : [ 3, 17 ],
      "id_str" : "214532657",
      "id" : 214532657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325680526604251137",
  "text" : "RT @conjugate_box: \u5F15\u304D\u7B97\u304C\u5B9A\u7FA9\u3055\u308C\u3066\u306A\u3044\u7CFB\u304C\u884C\u304D\u7740\u304D\u5148\u3068\u3057\u3066\u306E\u30AB\u30EC\u30FC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325680394496262144",
    "text" : "\u5F15\u304D\u7B97\u304C\u5B9A\u7FA9\u3055\u308C\u3066\u306A\u3044\u7CFB\u304C\u884C\u304D\u7740\u304D\u5148\u3068\u3057\u3066\u306E\u30AB\u30EC\u30FC",
    "id" : 325680394496262144,
    "created_at" : "2013-04-20 18:40:31 +0000",
    "user" : {
      "name" : "conjugate_box",
      "screen_name" : "conjugate_box",
      "protected" : false,
      "id_str" : "214532657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000227276159\/b35078da1ab080a1319f8cb615bfe0e1_normal.png",
      "id" : 214532657,
      "verified" : false
    }
  },
  "id" : 325680526604251137,
  "created_at" : "2013-04-20 18:41:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325680473378549760",
  "text" : "\u6599\u7406\u306F\u697D\u3057\u3044\u3051\u3069\u5B9F\u969B\u9762\u5012\u306A\u3068\u3053\u308D\u3082\u5426\u3081\u306C",
  "id" : 325680473378549760,
  "created_at" : "2013-04-20 18:40:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325679986839265281",
  "geo" : { },
  "id_str" : "325680250472259584",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u5B9A\u98DF\u3068\u3057\u3066\u306F\u6C17\u6301\u3061\u9AD8\u3081\u3067\u3059\u304C\u9B5A\u98DF\u3079\u308C\u308B\u5E0C\u5C11\u306A\u304A\u5E97\u3067\u3059(^^)(^^)(^^)",
  "id" : 325680250472259584,
  "in_reply_to_status_id" : 325679986839265281,
  "created_at" : "2013-04-20 18:39:57 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325680052102627328",
  "text" : "\u3042\u3068\u3001\u307F\u308A\u3093\u3002\u3042\u306E\u7518\u307F\u306F\u4E0A\u624B\u306B\u4F7F\u3048\u3070\u30B3\u30AF\u3082\u51FA\u308B\u3057\u826F\u3044\u306E\u3060\u304C\u3001\u3061\u3087\u3063\u3068\u8B1D\u308B\u3068\u3068\u3066\u3082\u3057\u3064\u3053\u304F\u306A\u308B\u3002",
  "id" : 325680052102627328,
  "created_at" : "2013-04-20 18:39:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325679906405093376",
  "text" : "\u5473\u564C\u306F\u7A2E\u985E\u3082\u591A\u3044\u3057\u5965\u304C\u6DF1\u3044\u30A4\u30E1\u30FC\u30B8\u3001\u4E0A\u624B\u306B\u4F7F\u3044\u3053\u306A\u305B\u306A\u3044",
  "id" : 325679906405093376,
  "created_at" : "2013-04-20 18:38:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325679006613659649",
  "geo" : { },
  "id_str" : "325679469614485504",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u5B9F\u969B\u9BD6\u5473\u564C\u306F\u3054\u306F\u3093\u6357\u308A\u307E\u3059\u306D[\u97A0\u5C0F\u8DEF\u306E\u3068\u304F\u3089\u3068\u3044\u3046\u5B9A\u98DF\u5C4B\u3055\u3093\u306E\u30B5\u30D0\u5473\u564C\u304A\u3044\u3057\u3044\u3067\u3059]",
  "id" : 325679469614485504,
  "in_reply_to_status_id" : 325679006613659649,
  "created_at" : "2013-04-20 18:36:51 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325679144052609025",
  "text" : "\u304A\u5E97\u306E\u306B\u52DD\u3066\u308B\u6C17\u304C\u3057\u306A\u3044\u6599\u7406\u9054[\u30AA\u30E0\u30E9\u30A4\u30B9\u3001\u9BD6\u306E\u5473\u564C\u716E\u3001\u30C1\u30AD\u30F3\u30E9\u30A4\u30B9\u3001\u30B9\u30C6\u30FC\u30AD\u7B49\u3005]",
  "id" : 325679144052609025,
  "created_at" : "2013-04-20 18:35:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325678662559084545",
  "geo" : { },
  "id_str" : "325678856306573312",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u9BD6\u306E\u5473\u564C\u716E\u306F\u3069\u3046\u9811\u5F35\u3063\u3066\u3082\u304A\u5E97\u306E\u306B\u52DD\u3066\u308B\u6C17\u304C\u3057\u306A\u3044",
  "id" : 325678856306573312,
  "in_reply_to_status_id" : 325678662559084545,
  "created_at" : "2013-04-20 18:34:24 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325678715919024128",
  "text" : "\u5473\u4ED8\u3051\u306F\u8DB3\u3057\u7B97\u3067\u304D\u308B\u3051\u3069\u5F15\u304D\u7B97\u3067\u304D\u306A\u3044\u3001\u3068\u304B\u306A",
  "id" : 325678715919024128,
  "created_at" : "2013-04-20 18:33:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325678550931890176",
  "text" : "\u3042\u3068\u306F\u3084\u3063\u3066\u306F\u3044\u3051\u306A\u3044\u3053\u3068\u3060\u3051\u3044\u304F\u3064\u304B\u5B66\u3079\u3070\u5927\u4E08\u592B",
  "id" : 325678550931890176,
  "created_at" : "2013-04-20 18:33:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325678123129634816",
  "text" : "\u3042\u3001\u304A\u83D3\u5B50\u985E\u306F\u304D\u3063\u3061\u308A\u56F3\u3089\u306A\u3044\u3068\u6B7B\u306B\u307E\u3059",
  "id" : 325678123129634816,
  "created_at" : "2013-04-20 18:31:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325678061293039616",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u53B3\u5BC6\u306B\u305D\u306E\u901A\u308A\u306B\u3057\u306A\u304F\u3066\u3082\u3044\u3044\u304B\u3089\u3001\u30EC\u30B7\u30D4\u8ABF\u3079\u308B\u3060\u3051\u3067\u6599\u7406\u306F\u306A\u3093\u3068\u306A\u304F\u3067\u304D\u308B\u69D8\u306B\u306A\u308B\u3068\u601D\u3046",
  "id" : 325678061293039616,
  "created_at" : "2013-04-20 18:31:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3061\u3047\u308B\u3057\u30FC",
      "screen_name" : "chelsea_mi",
      "indices" : [ 0, 11 ],
      "id_str" : "206295891",
      "id" : 206295891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325677570689490944",
  "geo" : { },
  "id_str" : "325677757453447170",
  "in_reply_to_user_id" : 206295891,
  "text" : "@chelsea_mi \u306A\u3093\u3068\u3044\u3046\u304B\u308D\u3058\u30FC\u541B\u306E\u77E5\u8B58\u304C\u504F\u3063\u3066\u3044\u308B\u3053\u3068\u304C\u3059\u3054\u304F\u308F\u304B\u3063\u305F.",
  "id" : 325677757453447170,
  "in_reply_to_status_id" : 325677570689490944,
  "created_at" : "2013-04-20 18:30:02 +0000",
  "in_reply_to_screen_name" : "chelsea_mi",
  "in_reply_to_user_id_str" : "206295891",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325676877480091648",
  "geo" : { },
  "id_str" : "325677399075336192",
  "in_reply_to_user_id" : 1068463296,
  "text" : "@Nano_citY \u306A\u308B\u307B\u3069\u2026",
  "id" : 325677399075336192,
  "in_reply_to_status_id" : 325676877480091648,
  "created_at" : "2013-04-20 18:28:37 +0000",
  "in_reply_to_screen_name" : "ny_ypsilon",
  "in_reply_to_user_id_str" : "1068463296",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325677186394779649",
  "text" : "\u3048\u30FC\u3068\u3001\u9593\u9055\u3063\u3066\u305F\u3089\u3042\u308C\u306A\u3093\u3060\u3051\u3069\u304A\u7C73\u304B\u3089\u4F5C\u308B\u30C1\u30E3\u30FC\u30CF\u30F3\u7684\u306A\u3082\u306E\u3063\u3066\u30D4\u30E9\u30D5\u3067\u306F\uFF1F",
  "id" : 325677186394779649,
  "created_at" : "2013-04-20 18:27:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3061\u3047\u308B\u3057\u30FC",
      "screen_name" : "chelsea_mi",
      "indices" : [ 0, 11 ],
      "id_str" : "206295891",
      "id" : 206295891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325676836749197315",
  "geo" : { },
  "id_str" : "325677011609722880",
  "in_reply_to_user_id" : 206295891,
  "text" : "@chelsea_mi \u305D\u308C\u30D4\u30E9\u30D5\u3067\u306F\u2026",
  "id" : 325677011609722880,
  "in_reply_to_status_id" : 325676836749197315,
  "created_at" : "2013-04-20 18:27:05 +0000",
  "in_reply_to_screen_name" : "chelsea_mi",
  "in_reply_to_user_id_str" : "206295891",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325676905498030080",
  "text" : "\u30CB\u30E7\u30C3\u30AD\u306F\u30D1\u30B9\u30BF\u3060\u3063\u3051\u304B\uFF1F",
  "id" : 325676905498030080,
  "created_at" : "2013-04-20 18:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325676783099838464",
  "text" : "\u30EC\u30FC\u30EB\u30AC\u30F3\u5B9F\u6CC1\u30DF\u30E5\u30FC\u30C8\u30DF\u30E5\u30FC\u30C8\u3063\u3068[\u30B7\u30B9\u30BF\u30FC\u30BA\u7BC7\u3084\u308B\u3068\u304B\u3084\u3089\u306A\u3044\u3068\u304B\uFF1F]",
  "id" : 325676783099838464,
  "created_at" : "2013-04-20 18:26:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325676025755357184",
  "text" : "\u3053\u308C\u306F\u65B0\u624B\u306E\u98EF\u30C6\u30ED\u306A\u306E\u3067\u306F",
  "id" : 325676025755357184,
  "created_at" : "2013-04-20 18:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325675955718848512",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u306A\u3041\u2026\u30D1\u30B9\u30BFTL\u306B\u30A2\u30C6\u3089\u308C\u305F\u5F62\u2026",
  "id" : 325675955718848512,
  "created_at" : "2013-04-20 18:22:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325675469313806337",
  "geo" : { },
  "id_str" : "325675665565315072",
  "in_reply_to_user_id" : 1068463296,
  "text" : "@Nano_citY \u3048\u3063\u2026[\u5C45\u3066\u30825%\u3068\u304B\u305D\u306E\u304F\u3089\u3044\u304B\u3068\u2026]",
  "id" : 325675665565315072,
  "in_reply_to_status_id" : 325675469313806337,
  "created_at" : "2013-04-20 18:21:44 +0000",
  "in_reply_to_screen_name" : "ny_ypsilon",
  "in_reply_to_user_id_str" : "1068463296",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325675151884685312",
  "text" : "\u304A\u6C41\u7C89\u306B\u3072\u3068\u3064\u307E\u307F\u5869\u5165\u308C\u305F\u308A\uFF1F",
  "id" : 325675151884685312,
  "created_at" : "2013-04-20 18:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325674732236193792",
  "geo" : { },
  "id_str" : "325674961157103616",
  "in_reply_to_user_id" : 1068463296,
  "text" : "@Nano_citY \u307B\u3050\u3055\u306A\u3044\u52E2\u3044\u308B\u3093\u3067\u3059\u304B\u306D[\u307B\u3050\u3055\u306A\u3044\u52E2\u306B\u523A\u3055\u308B\u30DD\u30B9\u30C8]",
  "id" : 325674961157103616,
  "in_reply_to_status_id" : 325674732236193792,
  "created_at" : "2013-04-20 18:18:56 +0000",
  "in_reply_to_screen_name" : "ny_ypsilon",
  "in_reply_to_user_id_str" : "1068463296",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325674257709408256",
  "text" : "\u77E5\u3063\u3066\u5C45\u3066\u3082\u5168\u7136\u304A\u304B\u3057\u304F\u306A\u304B\u3063\u305F\u5E38\u8B58\u307F\u305F\u3044\u306A\u3082\u306E\u3092\u305F\u307E\u305F\u307E\u77E5\u3089\u306A\u3044\u3063\u3066\u4E8B\u3001\u7A00\u306B\u3042\u308B",
  "id" : 325674257709408256,
  "created_at" : "2013-04-20 18:16:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325673760285921280",
  "text" : "\u30AA\u30EC\u30AA\u3092\u305D\u306E\u307E\u307E\u9F67\u3063\u305F\u6642\u306B\u4F3C\u305F\u3088\u3046\u306A\u6279\u5224(?)\u53D7\u3051\u305F\u306A\u3041\u30FC",
  "id" : 325673760285921280,
  "created_at" : "2013-04-20 18:14:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325673419062530049",
  "text" : "\u3068\u306F\u3044\u3048\u308D\u3058\u30FC\u541B\u304C\u8CAC\u3081\u3089\u308C(?)\u3059\u304E\u3066\u308B\u611F\u3042\u308B\u306A\uFF1F",
  "id" : 325673419062530049,
  "created_at" : "2013-04-20 18:12:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325673099251027969",
  "text" : "\u30D5\u30A3\u30C3\u30C8\u30C1\u30FC\u30CD\u3067\u3082\u30DE\u30AB\u30ED\u30CB\u3067\u3082\u5869\u8339\u3067",
  "id" : 325673099251027969,
  "created_at" : "2013-04-20 18:11:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325672389516070913",
  "text" : "\u3080\u3057\u308D\u5869\u304C\u306A\u304B\u3063\u305F\u3089\u30D1\u30B9\u30BF\u4F5C\u308B\u306E\u65AD\u5FF5\u3059\u308B\u30EC\u30D9\u30EB",
  "id" : 325672389516070913,
  "created_at" : "2013-04-20 18:08:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325672298742943745",
  "text" : "\u30D1\u30B9\u30BF\u306F\u5869\u8339\u3067\u3067\u3057\u3087[\u4E57\u308A\u9045\u308C\u305F\u611F]",
  "id" : 325672298742943745,
  "created_at" : "2013-04-20 18:08:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325580218549030914",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 325580218549030914,
  "created_at" : "2013-04-20 12:02:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325574684282347520",
  "text" : "\u4E09\u534A\u898F\u7BA1\u5F31\u3059\u304E\u3066\u30D0\u30B910\u5206\u3067\u6C17\u5206\u60AA\u304F\u306A\u308B\u306A\uFF1F",
  "id" : 325574684282347520,
  "created_at" : "2013-04-20 11:40:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325571704317431809",
  "text" : "\u52C9\u5F37\u3057\u3066\u305F\u3060\u3051\u3060\u306A\uFF1F",
  "id" : 325571704317431809,
  "created_at" : "2013-04-20 11:28:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325571605155704832",
  "text" : "\u6D6A\u4EBA\u6642\u4EE3\u9031\u4E00\u3067\u30B9\u30BF\u30D0\u901A\u3063\u3066\u305F\u3057\u30EA\u30A2\u5145\u6D6A\u4EBA\u751F\u3060\u3063\u305F\u53EF\u80FD\u6027",
  "id" : 325571605155704832,
  "created_at" : "2013-04-20 11:28:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3089@6\/28\u540D\u53E4\u5C4B",
      "screen_name" : "clarenabel",
      "indices" : [ 3, 14 ],
      "id_str" : "176926259",
      "id" : 176926259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325571466332614656",
  "text" : "RT @clarenabel: \u30B9\u30BF\u30D0\u901A\u308F\u306A\u3044\u3068\"\u30EA\u30A2\u5145\u5927\u5B66\u751F\"\u3068\u3057\u3066\u306E\u5FC5\u8981\u6761\u4EF6\u3092\u6E80\u305F\u3055\u306A\u3044\u3068\u611F\u3058\u308B\u5927\u5B66\u751F\u306E\u591A\u3055",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325571285000269825",
    "text" : "\u30B9\u30BF\u30D0\u901A\u308F\u306A\u3044\u3068\"\u30EA\u30A2\u5145\u5927\u5B66\u751F\"\u3068\u3057\u3066\u306E\u5FC5\u8981\u6761\u4EF6\u3092\u6E80\u305F\u3055\u306A\u3044\u3068\u611F\u3058\u308B\u5927\u5B66\u751F\u306E\u591A\u3055",
    "id" : 325571285000269825,
    "created_at" : "2013-04-20 11:26:57 +0000",
    "user" : {
      "name" : "\u304F\u3089\u3089@6\/28\u540D\u53E4\u5C4B",
      "screen_name" : "clarenabel",
      "protected" : false,
      "id_str" : "176926259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539220654910746624\/BqCh_ihW_normal.jpeg",
      "id" : 176926259,
      "verified" : false
    }
  },
  "id" : 325571466332614656,
  "created_at" : "2013-04-20 11:27:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325530805537480704",
  "geo" : { },
  "id_str" : "325533959528255488",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u306A\u3089\u30AA\u30C3\u30B1\u30FC\uFF01(?)[iPad\u8CB7\u3063\u305F\u306E\u304B\uFF01]",
  "id" : 325533959528255488,
  "in_reply_to_status_id" : 325530805537480704,
  "created_at" : "2013-04-20 08:58:38 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325518344864296961",
  "geo" : { },
  "id_str" : "325522482528391168",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u305D\u308C\u3059\u3067\u306B\u89AA\u77E5\u3089\u305A\u3067\u306A\u3044\u306E\u3067\u306F\u2026",
  "id" : 325522482528391168,
  "in_reply_to_status_id" : 325518344864296961,
  "created_at" : "2013-04-20 08:13:02 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325512178411126784",
  "geo" : { },
  "id_str" : "325513342422769666",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u5F53\u7136\u89AA\u306B\u306F\u4F1D\u3048\u3066\u306A\u3044\u3093\u3060\u308D\u3046\u306A\uFF1F",
  "id" : 325513342422769666,
  "in_reply_to_status_id" : 325512178411126784,
  "created_at" : "2013-04-20 07:36:43 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325473781843902466",
  "text" : "\u968F\u5206\u524D\u306E\u8A2D\u5B9A\u304C\u751F\u304D\u3066\u305F\u306A",
  "id" : 325473781843902466,
  "created_at" : "2013-04-20 04:59:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u304B\u3078\u308F\u306C\u3081",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325473707944460288",
  "text" : "\u6C34\u66DC\u65E5\u306BS2S\u306E\u4F8B\u4F1A\u3067\u60C5\u5F37\u306E\u5148\u8F29\/\u5F8C\u8F29\u306B\u805E\u304F\u306E\u304C\u826F\u3044\u306E\u304B\u3082\u3057\u308C\u306A\u3044 #\u304B\u3078\u308F\u306C\u3081",
  "id" : 325473707944460288,
  "created_at" : "2013-04-20 04:59:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u304B\u3078\u308F\u306C\u3081",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325473144892690432",
  "text" : "\u306C\u30FC\u3093\uFF0C\u7D50\u5C40\u524D\u306B\u9032\u3081\u306A\u3044\u305C\u3044 #\u304B\u3078\u308F\u306C\u3081",
  "id" : 325473144892690432,
  "created_at" : "2013-04-20 04:56:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325468330804789248",
  "text" : "\u3082\u3046\u4E00\u56DE\u3084\u3063\u3066\u307F\u3088\u3046",
  "id" : 325468330804789248,
  "created_at" : "2013-04-20 04:37:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325468133118844928",
  "text" : "\u3046\u30FC\u53C2\u308B",
  "id" : 325468133118844928,
  "created_at" : "2013-04-20 04:37:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325467867816542208",
  "text" : "USB\u7D4C\u7531\u3067\u3084\u308B\u65B9\u6CD5\u304C\u66F8\u3044\u3066\u3042\u308B\u30B5\u30A4\u30C8\u304C\u3042\u3063\u305F\u304B\u3089\u898B\u306A\u304C\u3089\u3084\u3063\u3066\u308B\u304CUSB\u304B\u3089\u306E\u8D77\u52D5\u306E\u3068\u3053\u308D\u3067syslinux 4.03hogehoge \u3068\u51FA\u305F\u307E\u307E\u52D5\u304B\u306A\u3044",
  "id" : 325467867816542208,
  "created_at" : "2013-04-20 04:36:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325467506997329920",
  "text" : "grub\u306E\u5165\u308C\u76F4\u3057\u3092\u56F3\u3063\u3066\u3044\u308B\u304C\u2026",
  "id" : 325467506997329920,
  "created_at" : "2013-04-20 04:34:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 3, 14 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325467425053224961",
  "text" : "RT @nonamea774: Grub \u3067\u6B62\u307E\u308B\u7CFB\u3060\u3068Live DVD \u3068\u304B\u304B\u3089Grub \u5165\u308C\u306A\u304A\u3057\u305F\u3089\u306A\u3093\u3068\u304B\u306A\u308B\u3053\u3068\u591A\u3044\u6C17\u304C\u3059\u308B\u3051\u3069\u8A73\u3057\u3044\u3053\u3068\u306F\u308F\u304B\u3089\u306A\u3044\u306E\u3067\u3042\u3093\u307E\u308A\u308F\u304B\u3089\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325285665136836608",
    "text" : "Grub \u3067\u6B62\u307E\u308B\u7CFB\u3060\u3068Live DVD \u3068\u304B\u304B\u3089Grub \u5165\u308C\u306A\u304A\u3057\u305F\u3089\u306A\u3093\u3068\u304B\u306A\u308B\u3053\u3068\u591A\u3044\u6C17\u304C\u3059\u308B\u3051\u3069\u8A73\u3057\u3044\u3053\u3068\u306F\u308F\u304B\u3089\u306A\u3044\u306E\u3067\u3042\u3093\u307E\u308A\u308F\u304B\u3089\u306A\u3044",
    "id" : 325285665136836608,
    "created_at" : "2013-04-19 16:32:00 +0000",
    "user" : {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "protected" : false,
      "id_str" : "122305557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599956952429432832\/8y-IRC09_normal.png",
      "id" : 122305557,
      "verified" : false
    }
  },
  "id" : 325467425053224961,
  "created_at" : "2013-04-20 04:34:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325466968650043392",
  "text" : "\u3055\u30FC\u3066\u672A\u3060\u554F\u984C\u304C\u89E3\u6C7A\u3057\u306A\u3044\u305E\uFF1F\uFF1F\uFF1F",
  "id" : 325466968650043392,
  "created_at" : "2013-04-20 04:32:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325290883136229376",
  "text" : "\u30AA\u30E4\u30B9\u30DF",
  "id" : 325290883136229376,
  "created_at" : "2013-04-19 16:52:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325290155487412224",
  "text" : "\u8EAB\u306E\u4E08\u306B\u5408\u308F\u306A\u3044dualboot\u304C\u707D\u3044\u3057\u3066\u308B\u306A\uFF1F",
  "id" : 325290155487412224,
  "created_at" : "2013-04-19 16:49:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325290049530916864",
  "text" : "\u307E\u3041\u3069\u3046\u3082Windows\u306Eupdate\u306B\u969B\u3057\u3066Ubuntu\u306E\u5927\u4E8B\u306A\u4F55\u304B\u304C\u6D88\u3055\u308C\u305F\u304B\u3001\u4E0A\u66F8\u304D\u3055\u308C\u305F\u304B\u3055\u308C\u305F\u3068\u3044\u3046\u898B\u7ACB\u3066\u3067\u591A\u5206\u9593\u9055\u3044\u306F\u306A\u3044",
  "id" : 325290049530916864,
  "created_at" : "2013-04-19 16:49:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325289824930123776",
  "text" : "PC\u95A2\u9023\u306F\u30C8\u30E9\u30D6\u30EB\u3068\u672C\u5F53\u306B\u4E0D\u5B89\u3060\u306A\u2026\u58CA\u308C\u305F\u3089\u9AD8\u3044\u3057\u306A\u2026",
  "id" : 325289824930123776,
  "created_at" : "2013-04-19 16:48:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325288548787965952",
  "text" : "\u3042\u30FC\u571F\u66DC\u65E5\u3053\u308C\u3060\u3051\u3067\u7D42\u308F\u308B\u4E88\u611F\u3059\u308B",
  "id" : 325288548787965952,
  "created_at" : "2013-04-19 16:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325288444920217601",
  "text" : "\u3044\u304B\u3093\u305B\u3093\u7720\u304F\u3066\u30C0\u30E1\u3060\u3002\u8D77\u304D\u3066\u304B\u3089\u306B\u3057\u3088\u3046\u3002",
  "id" : 325288444920217601,
  "created_at" : "2013-04-19 16:43:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yutaka Aiko",
      "screen_name" : "ubon",
      "indices" : [ 96, 101 ],
      "id_str" : "14595787",
      "id" : 14595787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/xP4Regybhh",
      "expanded_url" : "http:\/\/viva-ubuntu.com\/viva-ubuntu\/grub2%e3%81%8c%e5%a3%8a%e3%82%8c%e3%81%a6%e8%b5%b7%e5%8b%95%e3%81%a7%e3%81%8d%e3%81%aa%e3%81%84%e6%99%82%e3%81%ab%e3%80%81%e3%82%89%e3%81%8f%e3%81%a1%e3%82%93%e3%81%ab%e4%bf%ae%e5%be%a9%e3%81%99.html",
      "display_url" : "viva-ubuntu.com\/viva-ubuntu\/gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "325288301382742016",
  "text" : "\u3053\u306E\u8FBA\u304B\u306A\u3001USB\u3067\u5BFE\u51E6\u3067\u304D\u308B\u306A\u3089\u826F\u3044\u304C\u2026 GRUB2\u304C\u58CA\u308C\u3066\u8D77\u52D5\u3067\u304D\u306A\u3044\u6642\u306B\u3001\u3089\u304F\u3061\u3093\u306B\u4FEE\u5FA9\u3059\u308B\uFF01\u8EE2\u3070\u306C\u5148\u306E\u300CSuper Grub Disk\u300D http:\/\/t.co\/xP4Regybhh @ubon\u3055\u3093\u304B\u3089",
  "id" : 325288301382742016,
  "created_at" : "2013-04-19 16:42:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325287237145202688",
  "text" : "\u3044\u304F\u3064\u304B\u8ABF\u3079\u3066\u898B\u305F\u304Croot\u30B3\u30DE\u30F3\u30C9\u3092\u77E5\u3089\u306A\u3044\u3063\u3066\u8A00\u308F\u308C\u308B\u3068\u3082\u3046\u3069\u3046\u3057\u3088\u3046\u3082\u7121\u3044\u2026",
  "id" : 325287237145202688,
  "created_at" : "2013-04-19 16:38:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u77E5\u6075\u888B_",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Zs5BlaYrvo",
      "expanded_url" : "http:\/\/detail.chiebukuro.yahoo.co.jp\/qa\/question_detail\/q1421685469?fr=pc_tw_share_q",
      "display_url" : "detail.chiebukuro.yahoo.co.jp\/qa\/question_de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "325287048799985666",
  "text" : "ubuntu\u8D77\u52D5\u6642\u306Bgrub\u306E\u30B3\u30DE\u30F3\u30C9\u753B\u9762\u304C\u3067\u3066\u3001\u5148\u306B\u3059\u3059\u307F\u307E\u305B\u3093\u3002\uFF1E\uFF1C\u521D\u5FC3\u8005\u306A\u308A\u306B\u30B0... http:\/\/t.co\/Zs5BlaYrvo #\u77E5\u6075\u888B_",
  "id" : 325287048799985666,
  "created_at" : "2013-04-19 16:37:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325285118572916736",
  "text" : "\u3075\u3041\u307C\u3063\u3066\u306A\u3044\u3067\u3069\u3046\u3057\u305F\u3089\u826F\u3044\u306E\u304B\u6559\u3048\u3066\u304F\u3060\u3055\u3044(\u771F\u9854)",
  "id" : 325285118572916736,
  "created_at" : "2013-04-19 16:29:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325284419575361536",
  "text" : "( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D\u56F0\u3063\u305F",
  "id" : 325284419575361536,
  "created_at" : "2013-04-19 16:27:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325284388898226178",
  "text" : "ubuntu\u304C\u8D77\u52D5\u3057\u306A\u304F\u306A\u3063\u3066grub\u30B3\u30DE\u30F3\u30C9\u30E9\u30A4\u30F3\u304C\u51FA\u3066\u6765\u305F\u304C\u60C5\u5F31\u3060\u304B\u3089\u3068\u307B\u3046\u306B\u304F\u308C\u3066\u3044\u308B",
  "id" : 325284388898226178,
  "created_at" : "2013-04-19 16:26:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325220034358161408",
  "text" : "\u8AAD\u66F8\u30E1\u30FC\u30BF\u30FC\u3063\u3066\u5B9F\u969B\u3069\u3046\u306A\u3093",
  "id" : 325220034358161408,
  "created_at" : "2013-04-19 12:11:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nicovideo.jp\/\" rel=\"nofollow\"\u003Eniconico \u30CB\u30B3\u30EC\u30DD\u9023\u643A\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sm3765802",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/F44nfeuF3W",
      "expanded_url" : "http:\/\/nico.ms\/sm3765802",
      "display_url" : "nico.ms\/sm3765802"
    } ]
  },
  "geo" : { },
  "id_str" : "325219386552102912",
  "text" : "\u3053\u308C\u5927\u597D\u304D \u3010\u30EC\u30D3\u30E5\u30FC\u3011\u591C\u6C7D\u8ECA\u306E\u7537 http:\/\/t.co\/F44nfeuF3W #sm3765802",
  "id" : 325219386552102912,
  "created_at" : "2013-04-19 12:08:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325151045200277504",
  "text" : "\u3059\u3067\u306B\u7A7A\u8179\u3092\u899A\u3048\u3066\u3044\u308B16:36",
  "id" : 325151045200277504,
  "created_at" : "2013-04-19 07:37:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325061251875078144",
  "geo" : { },
  "id_str" : "325086029293969408",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u3068\u3093\u304B\u3064\u30BD\u30FC\u30B9\u300C\u3068\u3093\u304B\u3064\u4EE5\u5916\u306B\u639B\u3051\u3089\u308C\u308B\u3068\u306F\u5FC3\u5916\u3067\u3042\u308B\u300D",
  "id" : 325086029293969408,
  "in_reply_to_status_id" : 325061251875078144,
  "created_at" : "2013-04-19 03:18:43 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\u4F1A\u8A71\u306F\u30C6\u30F3\u30D7\u30EC\u3068\u898B\u5206\u3051\u304C\u4ED8\u304B\u306A\u3044",
      "indices" : [ 0, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325051582100152320",
  "text" : "#\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\u4F1A\u8A71\u306F\u30C6\u30F3\u30D7\u30EC\u3068\u898B\u5206\u3051\u304C\u4ED8\u304B\u306A\u3044",
  "id" : 325051582100152320,
  "created_at" : "2013-04-19 01:01:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 0, 6 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\u4F1A\u8A71\u306F\u30C6\u30F3\u30D7\u30EC\u3068\u898B\u5206\u3051\u304C\u4ED8\u304B\u306A\u3044",
      "indices" : [ 35, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325047085827227648",
  "geo" : { },
  "id_str" : "325051490370736128",
  "in_reply_to_user_id" : 127940910,
  "text" : "@alg_d  \u2582\u2585\u2587\u2588\u2593\u2592\u2591(\u2019\u03C9\u2019)\u2591\u2592\u2593\u2588\u2587\u2585\u2582 \u3046\u308F\u3042\u3042\u3042\u3042 #\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\u4F1A\u8A71\u306F\u30C6\u30F3\u30D7\u30EC\u3068\u898B\u5206\u3051\u304C\u4ED8\u304B\u306A\u3044",
  "id" : 325051490370736128,
  "in_reply_to_status_id" : 325047085827227648,
  "created_at" : "2013-04-19 01:01:29 +0000",
  "in_reply_to_screen_name" : "alg_d",
  "in_reply_to_user_id_str" : "127940910",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325045677505802240",
  "text" : "\u8A9E\u5F59\u306F\u3080\u3057\u308D\u5897\u3048\u3066\u308B\u3002\u305F\u3060\u3057\u982D\u306E\u60AA\u3044\u8A00\u8449\u3057\u304B\u5897\u3048\u306A\u3044\u304B\u3089\u3084\u3063\u3071\u308A\u982D\u60AA\u3044\u3002",
  "id" : 325045677505802240,
  "created_at" : "2013-04-19 00:38:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325045280674291712",
  "text" : "\u4E45\u3005\u306B\u4E00\u56DE\u3067\u8FD4\u3057\u304D\u308C\u306A\u3044\u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\u3060\u3063\u305F\u306A\uFF1F",
  "id" : 325045280674291712,
  "created_at" : "2013-04-19 00:36:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3060\u30FC\u3059\u306A",
      "screen_name" : "DarknessCatX",
      "indices" : [ 2, 15 ],
      "id_str" : "258868251",
      "id" : 258868251
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 16, 25 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "\u304C\u3046\u305B\u3046",
      "screen_name" : "GauseuRi",
      "indices" : [ 26, 35 ],
      "id_str" : "521446089",
      "id" : 521446089
    }, {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 36, 45 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325045181848092674",
  "text" : ". @DarknessCatX @akeopyaa @GauseuRi @usiusi02 \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 325045181848092674,
  "created_at" : "2013-04-19 00:36:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 2, 10 ],
      "id_str" : "351349087",
      "id" : 351349087
    }, {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 11, 24 ],
      "id_str" : "86075525",
      "id" : 86075525
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 25, 34 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u6D85\u69C3",
      "screen_name" : "_ne_ha_n_",
      "indices" : [ 35, 45 ],
      "id_str" : "499591313",
      "id" : 499591313
    }, {
      "name" : "river4361",
      "screen_name" : "river4361",
      "indices" : [ 46, 56 ],
      "id_str" : "2526962401",
      "id" : 2526962401
    }, {
      "name" : "\u30A2\u30FC\u30B1",
      "screen_name" : "next_summer32",
      "indices" : [ 57, 71 ],
      "id_str" : "280403648",
      "id" : 280403648
    }, {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 72, 82 ],
      "id_str" : "157989076",
      "id" : 157989076
    }, {
      "name" : "muramasakazu",
      "screen_name" : "muramasakazu",
      "indices" : [ 83, 96 ],
      "id_str" : "2552538733",
      "id" : 2552538733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325045145407979520",
  "text" : ". @yasuand @_primenumber @nisehorn @_ne_ha_n_ @river4361 @next_summer32 @typekanon @muramasakazu \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 325045145407979520,
  "created_at" : "2013-04-19 00:36:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u307F\u306A\u3061\u3083\u3093",
      "screen_name" : "rumichang",
      "indices" : [ 0, 10 ],
      "id_str" : "242763253",
      "id" : 242763253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325043340364107776",
  "geo" : { },
  "id_str" : "325043518114496512",
  "in_reply_to_user_id" : 242763253,
  "text" : "@rumichang \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 325043518114496512,
  "in_reply_to_status_id" : 325043340364107776,
  "created_at" : "2013-04-19 00:29:48 +0000",
  "in_reply_to_screen_name" : "rumichang",
  "in_reply_to_user_id_str" : "242763253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325043260370321408",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 325043260370321408,
  "created_at" : "2013-04-19 00:28:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325043180372381696",
  "text" : "\u7A7A\u8179\u306E\u80C3\u306B\u53E9\u304D\u8FBC\u3080",
  "id" : 325043180372381696,
  "created_at" : "2013-04-19 00:28:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325041924845219840",
  "text" : "\u8D77\u304D\u305F\uFF0C\u7720\u3044",
  "id" : 325041924845219840,
  "created_at" : "2013-04-19 00:23:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324895522852855808",
  "text" : "\u76EE\u7389\u713C\u304D\u306F\u3001\u5869",
  "id" : 324895522852855808,
  "created_at" : "2013-04-18 14:41:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324895353222623232",
  "text" : "\u8D77\u304D\u305F\u6642\u306B\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u6C7A\u3081\u308B\u304B\u4ECA\u6C7A\u3081\u308B\u304B\u3002\u591A\u5206\u524D\u8005\u3002",
  "id" : 324895353222623232,
  "created_at" : "2013-04-18 14:41:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324886594840588288",
  "text" : "\u3069\u3053\u307E\u3067\u30EC\u30B8\u30E5\u30FC\u30E0\u3059\u308C\u3070\u3088\u3044\u306E\u304B\u308F\u304B\u3089\u3093\u307D\u3093",
  "id" : 324886594840588288,
  "created_at" : "2013-04-18 14:06:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324855391425003521",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 324855391425003521,
  "created_at" : "2013-04-18 12:02:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324563629737385985",
  "text" : "\u5FCD\u6BBA\u3001\u6B21\u30672\u90E8\u306E\u30E9\u30B9\u30C8\u30A8\u30D4\u30BD\u30FC\u30C9\u3060\uFF01\u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 324563629737385985,
  "created_at" : "2013-04-17 16:42:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324561495868465154",
  "geo" : { },
  "id_str" : "324562873860902912",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u6570\u5B66\u3060\u3068\u30A4\u30C7\u30A2\u30EB\u3068\u8AAD\u3080\u306E\u3067\u3059",
  "id" : 324562873860902912,
  "in_reply_to_status_id" : 324561495868465154,
  "created_at" : "2013-04-17 16:39:53 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324547637686726657",
  "text" : "\u30D5\u30FC\u30C8\u30F3\u3078dive",
  "id" : 324547637686726657,
  "created_at" : "2013-04-17 15:39:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324547483487309824",
  "text" : "\u6628\u65E5\u5B9F\u306F5\u6642\u4F4D\u307E\u3067\u8D77\u304D\u3066\u3066\u7121\u7406\u3084\u308A\u8D77\u304D\u305F\u304B\u3089\u7720\u3044\u3001\u306F\u305A",
  "id" : 324547483487309824,
  "created_at" : "2013-04-17 15:38:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324547411831840770",
  "text" : "\u4ECA\u5E03\u56E3\u306B\u5165\u308C\u30701:30\u306B\u306F\u5BDD\u308C\u308B\u30579\u6642\u306B\u306F\u8D77\u304D\u308C\u308B\u304B\u3089\u305D\u3046\u3059\u308B\u3002",
  "id" : 324547411831840770,
  "created_at" : "2013-04-17 15:38:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324546316103458819",
  "text" : "\u9593\u306B\u5408\u3046\u6C17\u304C\u3057\u306A\u3044\u304C\u30AC\u30F3\u30D0\u30EB\u30BE\u30FC\uFF01\u30AC\u30F3\u30D0\u30EB\u30BE\u30FC\uFF01",
  "id" : 324546316103458819,
  "created_at" : "2013-04-17 15:34:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324545780729921536",
  "text" : "\u4F1D\u3048\u308B\u6C17\u4E00\u5207\u306A\u3044\u306A",
  "id" : 324545780729921536,
  "created_at" : "2013-04-17 15:31:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324545751755661312",
  "text" : "ideal\u306F\u30A4\u30C7\u30A2\u30EB\u306A\u306E\u306B\u306A\u3093\u3067ideal\u306F\u30A2\u30A3\u30C7\u30A3\u30FC\u30EB\u306A\u306E\uFF1F",
  "id" : 324545751755661312,
  "created_at" : "2013-04-17 15:31:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324544234696888321",
  "text" : "\u3080\u3057\u308D\u7121\u7D42\u306A\u4EBA\u3063\u3066\u4EBA\u3067\u306A\u3044\u306E\u3067\u306F",
  "id" : 324544234696888321,
  "created_at" : "2013-04-17 15:25:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324544065100214273",
  "text" : "\u512A\u79C0\u3067\u306A\u304F\u6709\u7D42\u306A\u4EBA\u6750\u3067\u3059\uFF1F",
  "id" : 324544065100214273,
  "created_at" : "2013-04-17 15:25:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324534395283308544",
  "text" : "\u3068\u3044\u3046\u304B\u91D1\u66DC3\u9650\u306E\u6E96\u5099\u3057\u3066\u305F\u3089\u91D1\u66DC\u653E\u8AB2\u5F8C\u306E\u30BC\u30DF\u306E\u4E88\u7FD2\u51FA\u6765\u3066\u306A\u3044\u306A\uFF1F[\u50D5\u307E\u3067\u56DE\u3089\u306A\u3044\uFF1F]",
  "id" : 324534395283308544,
  "created_at" : "2013-04-17 14:46:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324534075341819905",
  "text" : "\u3055\u3057\u3082\u306E\u79C1\u3082\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u30926\u6642\u9593\u307B\u3069\u30671\u30EA\u30C3\u30C8\u30EB\u98F2\u3093\u3067\u308B\u3068\u304A\u8179\u75DB\u304F\u306A\u308B",
  "id" : 324534075341819905,
  "created_at" : "2013-04-17 14:45:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324533234744569857",
  "text" : "discussion group\u3092\u8A0E\u8AD6\u7FA4\u3068\u8A33\u3057\u305D\u3046\u306B\u306A\u3063\u3066( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 324533234744569857,
  "created_at" : "2013-04-17 14:42:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324525246738743297",
  "geo" : { },
  "id_str" : "324532858989453312",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\uFF01\uFF1F\u643A\u5E2F\u3067\u8AAD\u3093\u3067\u3044\u308B\u306E\u304C\u5B9F\u969B\u30E8\u30AF\u30CA\u30A4\uFF01\uFF1F",
  "id" : 324532858989453312,
  "in_reply_to_status_id" : 324525246738743297,
  "created_at" : "2013-04-17 14:40:37 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324515248986013696",
  "geo" : { },
  "id_str" : "324515482218659840",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u306A\u3093\u304B\u3053\u308C\u305F\u304F\u3055\u3093\u8AAD\u3082\u3046\u3068\u601D\u3048\u3070\u8AAD\u3081\u308B\u3051\u3069\u3001\u6642\u9593\u3092\u7121\u99C4\u306B\u3057\u305F\u611F\u304C\u4ED6\u306E\u3082\u306E\u3088\u308A\u5927\u304D\u3044\u6C17\u304C\u3059\u308B",
  "id" : 324515482218659840,
  "in_reply_to_status_id" : 324515248986013696,
  "created_at" : "2013-04-17 13:31:34 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324509222668742657",
  "geo" : { },
  "id_str" : "324515246976954370",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3042\u308B\u3044\u306FGW\u5F8C\u534A\u304B\u3082\u3067\u3059[\u3082\u3057\u304B\u3057\u3066GW\u305D\u3063\u3061\u306B\u3044\u306A\u3044\uFF1F]",
  "id" : 324515246976954370,
  "in_reply_to_status_id" : 324509222668742657,
  "created_at" : "2013-04-17 13:30:38 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324504507629326336",
  "geo" : { },
  "id_str" : "324508845227532288",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u3082\u3046\u3061\u3087\u3063\u3068\u30672\u90E8\u306E\u30E9\u30B9\u30C8\u30A8\u30D4\u30BD\u30FC\u30C9\u3084\u3067\u30FC(\u6BCE\u6669\u5BDD\u308B\u524D\u306B\u4E00\u3064\u3065\u3064\u8AAD\u3093\u3067\u308B)",
  "id" : 324508845227532288,
  "in_reply_to_status_id" : 324504507629326336,
  "created_at" : "2013-04-17 13:05:12 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324508244066308098",
  "geo" : { },
  "id_str" : "324508400606138369",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3082\u3057\u304B\u3057\u305F\u3089\u6765\u9031\u672B\u3042\u305F\u308A\u306B\u2026\uFF1F",
  "id" : 324508400606138369,
  "in_reply_to_status_id" : 324508244066308098,
  "created_at" : "2013-04-17 13:03:26 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324508317231767552",
  "text" : "286\u5186\u3067\u5E78\u305B\u306B\u306A\u308C\u308B\u7D20\u6575\u30B9\u30BF\u30A4\u30EB",
  "id" : 324508317231767552,
  "created_at" : "2013-04-17 13:03:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324508256661811200",
  "text" : "\u5927\u597D\u304D\u306A73%\u306E\u30C1\u30E7\u30B3\u30EC\u30FC\u30C8\u3082\u8CB7\u3063\u3066\u304D\u305F\u3057\u5E78\u305B",
  "id" : 324508256661811200,
  "created_at" : "2013-04-17 13:02:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324507685838004225",
  "geo" : { },
  "id_str" : "324507978025820160",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3067\u3059\u3088\u306D\uFF01\uFF01\uFF01",
  "id" : 324507978025820160,
  "in_reply_to_status_id" : 324507685838004225,
  "created_at" : "2013-04-17 13:01:45 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324507788220981248",
  "text" : "\u7121\u4E8B\u306B\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u624B\u306B\u5165\u308C\u305F\u3001\u3084\u3063\u305F\u30FC\uFF01",
  "id" : 324507788220981248,
  "created_at" : "2013-04-17 13:01:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324506036134350848",
  "text" : "\u307B\u3068\u3093\u3069\u3044\u305F\u308B\u3068\u3053\u308D\u5149",
  "id" : 324506036134350848,
  "created_at" : "2013-04-17 12:54:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324505711449096193",
  "text" : "\u3053\u308C\u306F\u82F1\u8A9E\u8AAD\u3080\u306E\u304C\u9045\u3044\u306E\u3082\u6709\u308B\u304B\u3082\u3060\u3051\u3069\u80CC\u666F\u77E5\u8B58\u306E\u7121\u3055\u304C\u4F5C\u696D\u52B9\u7387\u3092\u843D\u3068\u3057\u3066\u3044\u308B\u306A\uFF1F",
  "id" : 324505711449096193,
  "created_at" : "2013-04-17 12:52:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324505551658680321",
  "text" : "\u307E\u3060\u6C7A\u610F\u3057\u305F\u3060\u3051",
  "id" : 324505551658680321,
  "created_at" : "2013-04-17 12:52:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324505379843215360",
  "text" : "[\u901F\u5831] \u3048\u3093\u3069\u6C0F\u3001\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u6B32\u3057\u3055\u306B\u4ECA\u65E5\u4E00\u56DE\u76EE\u306E\u5916\u51FA\u3092\u6C7A\u610F",
  "id" : 324505379843215360,
  "created_at" : "2013-04-17 12:51:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324504242557685761",
  "text" : "\u30B4\u30A6\u30E9\u30F3\u30AC\uFF01\u5B9F\u969B\u30DE\u30C3\u30DD\u30FC\u3081\u3044\u305F\u601D\u8003\u56DE\u8DEF\u3067\u3042\u308B\uFF01",
  "id" : 324504242557685761,
  "created_at" : "2013-04-17 12:46:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324504104686743552",
  "text" : "\u82F1\u8A9E\u306E\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3092\u305D\u306E\u307E\u307E\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3068\u8A33\u51FA\u3057\u305D\u3046\u306B\u306A\u3063\u305F\u306A\uFF1F",
  "id" : 324504104686743552,
  "created_at" : "2013-04-17 12:46:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324427320100274176",
  "text" : "\u3054\u306F\u3093\u305F\u304F",
  "id" : 324427320100274176,
  "created_at" : "2013-04-17 07:41:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324426807275315200",
  "text" : "\u7A7A\u8179\u3092\u611F\u3058\u308B",
  "id" : 324426807275315200,
  "created_at" : "2013-04-17 07:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324426613972418562",
  "text" : "2,3\u9650\u306F\u4F11\u8B1B\u3060\u3063\u305F\u304C5\u9650\u306F\u3042\u3063\u305F\u6642\u306E\u9854",
  "id" : 324426613972418562,
  "created_at" : "2013-04-17 07:38:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324426456790880256",
  "text" : "\u3042\u30FC5\u9650\u2026",
  "id" : 324426456790880256,
  "created_at" : "2013-04-17 07:37:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324392487940657154",
  "text" : "\u30D9\u30A4\u30BA\u4E3B\u7FA9\u8005\u3068\u3044\u3046\u610F\u5473\u3067\u30D9\u30A4\u30B8\u30A2\u30F3\u3068\u3044\u3046\u8A00\u8449\u306F\u4F7F\u308F\u308C\u308B\u304C\u2026",
  "id" : 324392487940657154,
  "created_at" : "2013-04-17 05:22:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u76F4\u5F8C\u306B\u7591\u554F\u7B26\u3092\u3064\u3076\u3084\u3051\u3070\u4F55\u3067\u3082\u8A31\u3055\u308C\u308B\u6C17\u304C\u3059\u308B",
      "indices" : [ 0, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324207939512594432",
  "text" : "#\u76F4\u5F8C\u306B\u7591\u554F\u7B26\u3092\u3064\u3076\u3084\u3051\u3070\u4F55\u3067\u3082\u8A31\u3055\u308C\u308B\u6C17\u304C\u3059\u308B",
  "id" : 324207939512594432,
  "created_at" : "2013-04-16 17:09:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324207801389957120",
  "text" : "\uFF1F",
  "id" : 324207801389957120,
  "created_at" : "2013-04-16 17:08:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324207785497743360",
  "text" : "\u6D41\u77F3\u795E\uFF0C\u79C1\u306E\u3088\u3046\u306A\u611A\u8005\u306E\u8003\u3048\u308B\u3053\u3068\u306A\u3069\u3054\u5B58\u3058\u3067\u3044\u3089\u3063\u3057\u3083\u3063\u305F\uFF0E",
  "id" : 324207785497743360,
  "created_at" : "2013-04-16 17:08:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324207393087053825",
  "text" : "\u4E8C\u9031\u9593\u76EE\u306B\u3057\u3066\u65E2\u306B\u751F\u6D3B\u30EA\u30BA\u30E0\u304C\u5D29\u308C\u3066\u3044\u308B\u306E\u821E",
  "id" : 324207393087053825,
  "created_at" : "2013-04-16 17:07:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324207215332454400",
  "text" : "@sts_math \u30DD\u30AB\u30EA\u306B\u6DF7\u305C\u3066\u98F2\u3080\u3068\u3044\u3044\u3089\u3057\u3044\u3067\u3059\u3088\u30FC",
  "id" : 324207215332454400,
  "created_at" : "2013-04-16 17:06:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E71\u308C",
      "indices" : [ 5, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324206270179598336",
  "text" : "\u3055\u307F\u3060\u308C #\u4E71\u308C\uFF1F",
  "id" : 324206270179598336,
  "created_at" : "2013-04-16 17:02:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324204164571856897",
  "text" : "\u90316\u30B3\u30DE\u306E\u3046\u30612\u3064\u304C\u4F11\u8B1B\u3072\u3083\u3063\u307B\u3046",
  "id" : 324204164571856897,
  "created_at" : "2013-04-16 16:54:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reality Is Broken",
      "screen_name" : "yamioka_",
      "indices" : [ 0, 9 ],
      "id_str" : "973314139",
      "id" : 973314139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324159625949769728",
  "geo" : { },
  "id_str" : "324160057996607488",
  "in_reply_to_user_id" : 973314139,
  "text" : "@yamioka_ \u3053\u306E\u524D\u306EF\u3080\u306D\u3082\u540C\u3058\u4E8B\u8A00\u3063\u3066\u307E\u3057\u305F\u3001\u9700\u8981\u3042\u308B\u306E\u3067\u306F",
  "id" : 324160057996607488,
  "in_reply_to_status_id" : 324159625949769728,
  "created_at" : "2013-04-16 13:59:15 +0000",
  "in_reply_to_screen_name" : "yamioka_",
  "in_reply_to_user_id_str" : "973314139",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324130195906887683",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 324130195906887683,
  "created_at" : "2013-04-16 12:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324055825024958464",
  "geo" : { },
  "id_str" : "324058453842739200",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u30DE\u30B8\u304B\u3088\u2026",
  "id" : 324058453842739200,
  "in_reply_to_status_id" : 324055825024958464,
  "created_at" : "2013-04-16 07:15:30 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324050349566607360",
  "text" : "\u4ECA\u304B\u3089\u8AAD\u3080\uFF01",
  "id" : 324050349566607360,
  "created_at" : "2013-04-16 06:43:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324049549482147840",
  "text" : "\u7D50\u57CE\u5148\u751F\u306E\u672C\u30EB\u30CD\u306B\u3066\u5165\u624B",
  "id" : 324049549482147840,
  "created_at" : "2013-04-16 06:40:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324028578591277056",
  "text" : "\u308A\u308A\u308A\u308A\u308A\u3060\u3064\u30FC",
  "id" : 324028578591277056,
  "created_at" : "2013-04-16 05:16:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324026274639147008",
  "text" : "\u91CE\u83DC\u3068\u304B\u8089\u3068\u304B\u3060\u3057\u6C41\u30BC\u30E9\u30C1\u30F3\u3067\u56FA\u3081\u305F\u4E2D\u83EF\u306E\u524D\u83DC\u307F\u305F\u3044\u306A\u306E\u306A\u3093\u3060\u3063\u3051\u304B",
  "id" : 324026274639147008,
  "created_at" : "2013-04-16 05:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324025691551178753",
  "text" : "\u6BBF\u4E0B\uFF06\u30BC\u30EA\u30FC\u6C0F\u3046\u307E\u3044",
  "id" : 324025691551178753,
  "created_at" : "2013-04-16 05:05:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/324025464609968130\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/egGXmvLbcf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BH8rcXyCEAEoaxX.jpg",
      "id_str" : "324025464614162433",
      "id" : 324025464614162433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BH8rcXyCEAEoaxX.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/egGXmvLbcf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324025152541171713",
  "geo" : { },
  "id_str" : "324025464609968130",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u306F\u308B\u3081\u304F\u306F\u308B\u307E\u304D\u3092\u306F\u308B\u3079\u304F http:\/\/t.co\/egGXmvLbcf",
  "id" : 324025464609968130,
  "in_reply_to_status_id" : 324025152541171713,
  "created_at" : "2013-04-16 05:04:25 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324024707156414464",
  "text" : "\u3046\u307E\u3044\u3068\u306F\u3044\u3046\u307E\u3044",
  "id" : 324024707156414464,
  "created_at" : "2013-04-16 05:01:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324024583508332544",
  "text" : "15\u5206\u4F11\u61A9\u306A",
  "id" : 324024583508332544,
  "created_at" : "2013-04-16 05:00:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324024249444626432",
  "text" : "\u4E8C\u306E\u821E\u3092\u6F14\u3058\u308B\u3001\u4E8C\u306E\u8F4D\u3092\u8E0F\u3080",
  "id" : 324024249444626432,
  "created_at" : "2013-04-16 04:59:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324016980401213440",
  "text" : "\u30C9\u30F3\u30AD\u30FC\u30B3\u30F3\u30B064\u306E\u6700\u521D\u306E\u30E9\u30C3\u30D7\u6B4C\u3048\u308B\u5974\u2026",
  "id" : 324016980401213440,
  "created_at" : "2013-04-16 04:30:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u514E",
      "screen_name" : "uritan",
      "indices" : [ 3, 10 ],
      "id_str" : "68717551",
      "id" : 68717551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324016869361201152",
  "text" : "RT @uritan: \u30C9\u30FC\u30F3\uFF01\u30AD\u30FC\uFF01\u30B3\u30F3\u30B0\uFF01 \uFF73\uFF77\uFF70!!!wwwwwwwwwwwwwwwwwwww \uFF8E\uFF6F\uFF8E\uFF6F\uFF8D\uFF6F\uFF8D\uFF6F\uFF8D\uFF6F\uFF79\uFF6F\uFF8D\uFF6F\uFF8D\uFF8E\uFF8Ewwwwwwwwww\uFF8E\uFF6F\uFF8E\uFF6F\uFF8D\uFF6F\uFF8E\uFF6F\uFF8D\uFF8Ewwwwwwwwwwww\uFF8E\uFF6F\uFF8D\uFF6F\uFF8E\uFF8D\u30C9\u30FC\u30F3\uFF01\u30AD\u30FC\uFF01\u30B3\u30F3\u30B0\uFF01 \uFF8B\uFF70wwwwwwwwwwwwwwww ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/shootingstar067.com\/\" rel=\"nofollow\"\u003EShootingStar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324015118193135616",
    "text" : "\u30C9\u30FC\u30F3\uFF01\u30AD\u30FC\uFF01\u30B3\u30F3\u30B0\uFF01 \uFF73\uFF77\uFF70!!!wwwwwwwwwwwwwwwwwwww \uFF8E\uFF6F\uFF8E\uFF6F\uFF8D\uFF6F\uFF8D\uFF6F\uFF8D\uFF6F\uFF79\uFF6F\uFF8D\uFF6F\uFF8D\uFF8E\uFF8Ewwwwwwwwww\uFF8E\uFF6F\uFF8E\uFF6F\uFF8D\uFF6F\uFF8E\uFF6F\uFF8D\uFF8Ewwwwwwwwwwww\uFF8E\uFF6F\uFF8D\uFF6F\uFF8E\uFF8D\u30C9\u30FC\u30F3\uFF01\u30AD\u30FC\uFF01\u30B3\u30F3\u30B0\uFF01 \uFF8B\uFF70wwwwwwwwwwwwwwwwwwwwww",
    "id" : 324015118193135616,
    "created_at" : "2013-04-16 04:23:18 +0000",
    "user" : {
      "name" : "\u4E8C\u514E",
      "screen_name" : "uritan",
      "protected" : false,
      "id_str" : "68717551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591252500386189312\/h__kFicV_normal.png",
      "id" : 68717551,
      "verified" : false
    }
  },
  "id" : 324016869361201152,
  "created_at" : "2013-04-16 04:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323971944368181248",
  "text" : "\u5B89\u5B9A\u306E\u6559\u6388\u304C\u9045\u523B",
  "id" : 323971944368181248,
  "created_at" : "2013-04-16 01:31:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323971815229763584",
  "text" : "\u308F\u305F\u3057\u306F\u305D\u3082\u305D\u3082\u3044\u306A\u3044\u3072\u3068",
  "id" : 323971815229763584,
  "created_at" : "2013-04-16 01:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323971768660393984",
  "text" : "\u3072\u3068\u3060\u3044\u3076\u3078\u3063\u305F\uFF1F",
  "id" : 323971768660393984,
  "created_at" : "2013-04-16 01:31:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323715233417932800",
  "text" : "\u3054\u306F\u3093\u98DF\u3079\u305F\u3089\u6025\u6FC0\u306A\u7720\u305F\u307F\u304C",
  "id" : 323715233417932800,
  "created_at" : "2013-04-15 08:31:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323695207860293632",
  "text" : "\u308F\u308C\u306A\u304C\u3089\u3042\u305F\u307E\u308F\u308B\u3044\u306F\u3064\u3052\u3093\u3060\u3063\u305F",
  "id" : 323695207860293632,
  "created_at" : "2013-04-15 07:12:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323694728753340416",
  "geo" : { },
  "id_str" : "323694888275296256",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u304A\u3063\u3051\u30FC\u3067\u3059\u3001\u308F\u304B\u308B\u30B2\u30FC\u30E0\u3057\u304B\u308F\u304B\u308A\u307E\u305B\u3093\u3051\u3069",
  "id" : 323694888275296256,
  "in_reply_to_status_id" : 323694728753340416,
  "created_at" : "2013-04-15 07:10:49 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323641306213670912",
  "geo" : { },
  "id_str" : "323694500100857856",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u884C\u3063\u3066\u3082\u3044\u3044\u3067\u3059\uFF1F",
  "id" : 323694500100857856,
  "in_reply_to_status_id" : 323641306213670912,
  "created_at" : "2013-04-15 07:09:17 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323610006467530753",
  "text" : "\u30A8\u30EB\u30C7\u30B7\u30E5\u300C\u79C1\u304C\u30A8\u30EB\u30C7\u30B7\u30E5\u300D",
  "id" : 323610006467530753,
  "created_at" : "2013-04-15 01:33:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323477198369599488",
  "text" : "\u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 323477198369599488,
  "created_at" : "2013-04-14 16:45:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323477176831856641",
  "text" : "\u660E\u65E5\u306F\u4E8C\u9650\u3060\u304B\u3089\u751F\u6D3B\u30EA\u30BA\u30E0\u7684\u306A\u610F\u5473\u5408\u3044\u3067\u5099\u3048\u3088\u3046",
  "id" : 323477176831856641,
  "created_at" : "2013-04-14 16:45:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323475668895674368",
  "text" : "\u518D\u5E30\u7684\u306A\u4F7F\u3044\u65B9\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 323475668895674368,
  "created_at" : "2013-04-14 16:39:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "indices" : [ 3, 11 ],
      "id_str" : "5965172",
      "id" : 5965172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323475589472350208",
  "text" : "RT @mr_konn: \u300Chogehoge\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01\u300D\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323475340645249025",
    "text" : "\u300Chogehoge\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01\u300D\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
    "id" : 323475340645249025,
    "created_at" : "2013-04-14 16:38:25 +0000",
    "user" : {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "protected" : false,
      "id_str" : "5965172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566615944194060288\/nh8McKGS_normal.jpeg",
      "id" : 5965172,
      "verified" : false
    }
  },
  "id" : 323475589472350208,
  "created_at" : "2013-04-14 16:39:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323475500695703553",
  "text" : "\u5927\u5B66\u5165\u3063\u3066\u304B\u3089\u3001\u3068\u3044\u3046\u304BTwitter\u95A2\u9023\u306E\u77E5\u308A\u5408\u3044\u304C\u5897\u3048\u3066\u304B\u3089\u53CB\u4EBA\u306E\u53CB\u4EBA\u3068\u4EF2\u826F\u304F\u306A\u3063\u305F\u308A\u3001\u53CB\u4EBA\u3068\u53CB\u4EBA\u3092\u4EF2\u826F\u304F\u3055\u305B\u305F\u308A\u3059\u308B\u6A5F\u4F1A\u5897\u3048\u305F\u306A\u3041\u3068\u3057\u307F\u3058\u307F",
  "id" : 323475500695703553,
  "created_at" : "2013-04-14 16:39:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323474924066967552",
  "text" : "hogehoge\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01\u3082\u4F7F\u3044\u3084\u3059\u3044\u30C6\u30F3\u30D7\u30EC\u306E\u4E00\u3064",
  "id" : 323474924066967552,
  "created_at" : "2013-04-14 16:36:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323474167284527104",
  "text" : "\u3044\u3084\u3001\u4ECA\u306A\u3089\u3044\u3046\u307B\u3069\u56F0\u60D1\u3057\u306A\u3044\u3068\u601D\u3046\u3051\u308C\u3069",
  "id" : 323474167284527104,
  "created_at" : "2013-04-14 16:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323473934504845312",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u5BB6\u65CF\u3067\u8CB7\u3044\u7269\u3057\u3066\u308B\u6642\u306B\u3001\u666E\u6BB5\u904A\u3093\u3067\u308B\u53CB\u4EBA\u305F\u3061\u3068\u4F1A\u3063\u3066\u3057\u307E\u3063\u305F\u3088\u3046\u306A",
  "id" : 323473934504845312,
  "created_at" : "2013-04-14 16:32:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323473805198643200",
  "text" : "\u305D\u306E\u4E16\u754C\u3068\u3053\u306E\u4E16\u754C\u306F\u3001\u3042\u3093\u307E\u308A\u4EA4\u308F\u3063\u3066\u6B32\u3057\u304F\u306A\u3044",
  "id" : 323473805198643200,
  "created_at" : "2013-04-14 16:32:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ND7sxbDB2r",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/745?prefill=olanleed",
      "display_url" : "gohantabeyo.com\/nani\/745?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323466301295181826",
  "text" : "\u30C7\u30FC\u30C8\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/ND7sxbDB2r",
  "id" : 323466301295181826,
  "created_at" : "2013-04-14 16:02:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323405351640780800",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 323405351640780800,
  "created_at" : "2013-04-14 12:00:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323297029247885314",
  "geo" : { },
  "id_str" : "323319565150990338",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u3044\u3084\u3001\u306A\u3093\u304B\u5BB6\u306E\u5916\u304C\u9A12\u304C\u3057\u304B\u3063\u305F\u304B\u3089\u3055",
  "id" : 323319565150990338,
  "in_reply_to_status_id" : 323297029247885314,
  "created_at" : "2013-04-14 06:19:25 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323255036794773504",
  "text" : "\u30AA\u30DE\u30C4\u30EA\uFF1F",
  "id" : 323255036794773504,
  "created_at" : "2013-04-14 02:03:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323254716366745600",
  "text" : "\u4E0B\u9D28\u795E\u793E\u304B\u3089\u805E\u3053\u3048\u3066\u308B\uFF1F\u9060\u3056\u304B\u3063\u3066\u3044\u304F\u304C",
  "id" : 323254716366745600,
  "created_at" : "2013-04-14 02:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323254431611232256",
  "text" : "\u62E1\u58F0\u5668\u4F7F\u3063\u3066\u308B\u307D\u3044",
  "id" : 323254431611232256,
  "created_at" : "2013-04-14 02:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323254374971346944",
  "text" : "\u5916\u304C\u9A12\u304C\u3057\u3044\u2026\u30C7\u30E2\uFF1F",
  "id" : 323254374971346944,
  "created_at" : "2013-04-14 02:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323065695510331393",
  "geo" : { },
  "id_str" : "323065977652776961",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3067\u3059\u306D\u3047\u3001\u5272\u5408\u9A12\u304C\u3057\u3044\u3067\u3059\u3057\u3042\u307E\u308A\u826F\u3044\u9854\u3055\u308C\u306A\u3044\u611F\u3058\u3057\u307E\u3059.",
  "id" : 323065977652776961,
  "in_reply_to_status_id" : 323065695510331393,
  "created_at" : "2013-04-13 13:31:46 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323064343140904961",
  "geo" : { },
  "id_str" : "323065125101785088",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u6050\u3089\u304F\u6700\u5BC4\u308A\u306F\u5409\u7965\u5BFA\u30B5\u30F3\u30ED\u30FC\u30C9\u306E\u30D0\u30B0\u30FC\u30B9\u3067\u3057\u3087\u3046\u306D\u3047\u2026",
  "id" : 323065125101785088,
  "in_reply_to_status_id" : 323064343140904961,
  "created_at" : "2013-04-13 13:28:22 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323063767388811264",
  "geo" : { },
  "id_str" : "323063937518145536",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u898B\u3064\u3051\u305F\u3089\u6559\u3048\u3066\u304F\u3060\u3055\u3044",
  "id" : 323063937518145536,
  "in_reply_to_status_id" : 323063767388811264,
  "created_at" : "2013-04-13 13:23:39 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323063856341581824",
  "text" : "@potezaki \u30CA\u30A4\u30B9\u9EBB\u96C0\uFF01",
  "id" : 323063856341581824,
  "created_at" : "2013-04-13 13:23:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323062770520186880",
  "text" : "(\u300D\u30FB\u03C9\u30FB)\u300D\u3046\u30FC\uFF01\n\u30ED\u30F3\n(\uFF0F\u30FB\u03C9\u30FB)\uFF0F\u3061\u3083\u30FC\uFF01",
  "id" : 323062770520186880,
  "created_at" : "2013-04-13 13:19:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323059353068384257",
  "text" : "\u306E \u3069 \u304C \u304B \u308F \u3044 \u305F",
  "id" : 323059353068384257,
  "created_at" : "2013-04-13 13:05:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323042992178991104",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 323042992178991104,
  "created_at" : "2013-04-13 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322648682166108161",
  "geo" : { },
  "id_str" : "322649272677969920",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u30B4\u30E1\u30F3\u306D",
  "id" : 322649272677969920,
  "in_reply_to_status_id" : 322648682166108161,
  "created_at" : "2013-04-12 09:55:55 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322645892056375298",
  "text" : "BGM\u3067\u3082\u6B4C\u304C\u6709\u308B\u3068\u6C17\u304C\u6563\u308B\u4E8B\u304C\u6709\u308B\u304B\u3089\u30B8\u30E3\u30BA\u3068\u304B\u30AF\u30E9\u30B7\u30C3\u30AF\u3068\u304B\u805E\u304D\u306A\u304C\u3089\u52C9\u5F37\u3059\u308B\u3068\n(^^)(^^)(^^)",
  "id" : 322645892056375298,
  "created_at" : "2013-04-12 09:42:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322644159636840449",
  "geo" : { },
  "id_str" : "322645781767127040",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u53CE\u307E\u3063\u305F\u3089\u304A\u3044\u3067\u30FC[\u30AA\u30C0\u30A4\u30B8\u30CB\u30FC]",
  "id" : 322645781767127040,
  "in_reply_to_status_id" : 322644159636840449,
  "created_at" : "2013-04-12 09:42:03 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 17, 28 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 29, 39 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322644130293493760",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank @haguruma20 @wa_ta_si_ \u5317\u90E8\u98DF\u5802\u3067(^^)(^^)(^^)\u3042\u3044\u307E\u305B\u3046",
  "id" : 322644130293493760,
  "created_at" : "2013-04-12 09:35:29 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322643601962196992",
  "geo" : { },
  "id_str" : "322643954581504000",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u4ECA\u5927\u5B66(\u3053\u308C\u308B)?[\u30DB\u30E2\u30ED\u30B8\u30FC\u306E\u306F\u306A\u3057\u3042\u3044]",
  "id" : 322643954581504000,
  "in_reply_to_status_id" : 322643601962196992,
  "created_at" : "2013-04-12 09:34:47 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322643498681659392",
  "geo" : { },
  "id_str" : "322643788327690240",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u50D5\u306F\u307B\u304F\u3076\u306B\u3044\u308B\u3051\u3069\u306F\u3050\u308B\u307E\u3055\u3093\u3082\u9023\u7D61\u5E30\u3063\u3066\u3053\u306A\u3044[\u3067\u3093\u308F\u3057\u3066\u307F\u308B\u3088]",
  "id" : 322643788327690240,
  "in_reply_to_status_id" : 322643498681659392,
  "created_at" : "2013-04-12 09:34:08 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322642662115135488",
  "geo" : { },
  "id_str" : "322642895716884480",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3044\u3084\u3001\u62C5\u5F53\u3068\u304B\u8272\u3005\u8A71\u3057\u5408\u3046\u306E\u306F\u3069\u3046\u3067\u3057\u3087\u3046[\u3042\u308C\u3001\u306F\u3050\u308B\u307E\u3055\u3093\u304B\u3089\u30E1\u30FC\u30EB\u884C\u3063\u3066\u306A\u3044\u2026\uFF1F]",
  "id" : 322642895716884480,
  "in_reply_to_status_id" : 322642662115135488,
  "created_at" : "2013-04-12 09:30:35 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322642714124505088",
  "text" : "\u30A2\u30AB\u30A6\u30F3\u30C8\u30FB\u30DE\u30C1\u30AC\u30A4\u30FB\u30B8\u30C4",
  "id" : 322642714124505088,
  "created_at" : "2013-04-12 09:29:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322642127966334976",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30BC\u30EA\u30FC\u3055\u3093\u4ECA\u5927\u5B66\u306B\u3044\u308B\uFF1F",
  "id" : 322642127966334976,
  "created_at" : "2013-04-12 09:27:32 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 1, 9 ],
      "id_str" : "351349087",
      "id" : 351349087
    }, {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 10, 18 ],
      "id_str" : "145536184",
      "id" : 145536184
    }, {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 19, 26 ],
      "id_str" : "443191476",
      "id" : 443191476
    }, {
      "name" : "\u30A2\u30FC\u30B1",
      "screen_name" : "next_summer32",
      "indices" : [ 27, 41 ],
      "id_str" : "280403648",
      "id" : 280403648
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 56, 65 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u725B\u5CF6",
      "screen_name" : "usijima_uoichi",
      "indices" : [ 66, 81 ],
      "id_str" : "162395025",
      "id" : 162395025
    }, {
      "name" : "\u305F\u3093\u3050\u3059\u3066\u30FC\u3093\uFF01",
      "screen_name" : "Wolfram184",
      "indices" : [ 82, 93 ],
      "id_str" : "131823804",
      "id" : 131823804
    }, {
      "name" : "\u6D85\u69C3",
      "screen_name" : "_ne_ha_n_",
      "indices" : [ 94, 104 ],
      "id_str" : "499591313",
      "id" : 499591313
    }, {
      "name" : "\u30C6\u30A4\u30EB\u30BA\u30FB\u30AA\u30D6\u30FB\u6F22\u30AA\u30BB\u30C1\u30A2@\u3075\u3093\u3059\uFF01",
      "screen_name" : "osetia_kaguya",
      "indices" : [ 105, 119 ],
      "id_str" : "56097393",
      "id" : 56097393
    }, {
      "name" : "\u304C\u3046\u305B\u3046",
      "screen_name" : "GauseuRi",
      "indices" : [ 120, 129 ],
      "id_str" : "521446089",
      "id" : 521446089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322628530716430337",
  "text" : ".@yasuand @chr1233 @ac_key @next_summer32 @capella_1127 @nisehorn @usijima_uoichi @Wolfram184 @_ne_ha_n_ @osetia_kaguya @GauseuRi \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 322628530716430337,
  "created_at" : "2013-04-12 08:33:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322617218561085440",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 322617218561085440,
  "created_at" : "2013-04-12 07:48:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322395342807126016",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 322395342807126016,
  "created_at" : "2013-04-11 17:06:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322395323534295042",
  "text" : "\u8FD4\u4E8B\u306F\u8D77\u304D\u305F\u3089\u3059\u308B\u3001\u5B9F\u969B\u7720\u3044",
  "id" : 322395323534295042,
  "created_at" : "2013-04-11 17:06:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306A\u3082\u3061",
      "screen_name" : "null_min",
      "indices" : [ 0, 9 ],
      "id_str" : "480291899",
      "id" : 480291899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322390860639657984",
  "geo" : { },
  "id_str" : "322392062798483457",
  "in_reply_to_user_id" : 480291899,
  "text" : "@null_min \u3093\u30FC\u3001\u3075\u308F\u3063\u3068\u3057\u3066\u308B\u306A\u3089\u3075\u3089\u3063\u3068\u3057\u3066\u308B\u307E\u307E\u4F1D\u3048\u308C\u3070\u826F\u3044\u306E\u3067\u3001\u601D\u3063\u3066\u308B\u69D8\u306B\u8A00\u3063\u3066\u304F\u308C\u308C\u3070\u5927\u4E08\u592B\u3067\u3059\u3088\u3001\n\u305F\u3076\u3093",
  "id" : 322392062798483457,
  "in_reply_to_status_id" : 322390860639657984,
  "created_at" : "2013-04-11 16:53:52 +0000",
  "in_reply_to_screen_name" : "null_min",
  "in_reply_to_user_id_str" : "480291899",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322389282864115712",
  "text" : "\u3064\u3066[\u4F1D]",
  "id" : 322389282864115712,
  "created_at" : "2013-04-11 16:42:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306A\u3082\u3061",
      "screen_name" : "null_min",
      "indices" : [ 0, 9 ],
      "id_str" : "480291899",
      "id" : 480291899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322388450135375872",
  "geo" : { },
  "id_str" : "322389195953942528",
  "in_reply_to_user_id" : 480291899,
  "text" : "@null_min \u6771\u6D0B\u601D\u60F3\u3067\u3059\u304B\u3001\u3044\u3084\u307E\u3041\u591A\u5206\u4F1D\u306F\u3042\u308A\u305D\u3046\u306A\u306E\u3067\u4E00\u5FDC\u805E\u3044\u3066\u307F\u307E\u3059\u3001(\u50D5\u306F\u5168\u304F\u9580\u5916\u6F22\u306A\u306E\u3067\u305D\u306E\u307E\u307E\u4F1D\u3048\u307E\u3059\u304C)\u5177\u4F53\u7684\u306B\u306F\u3069\u3093\u306A\u3082\u306E\u3092\u8AAD\u307F\u305F\u3044\u3068\u601D\u3063\u3066\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 322389195953942528,
  "in_reply_to_status_id" : 322388450135375872,
  "created_at" : "2013-04-11 16:42:28 +0000",
  "in_reply_to_screen_name" : "null_min",
  "in_reply_to_user_id_str" : "480291899",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322387666702327808",
  "text" : "\u6771\u6D0B\u53F2\u3068\u8A00\u3063\u3066\u3082\u5E83\u305D\u3046\u3060\u304C",
  "id" : 322387666702327808,
  "created_at" : "2013-04-11 16:36:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306A\u3082\u3061",
      "screen_name" : "null_min",
      "indices" : [ 0, 9 ],
      "id_str" : "480291899",
      "id" : 480291899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322386701408407552",
  "geo" : { },
  "id_str" : "322387587274788866",
  "in_reply_to_user_id" : 480291899,
  "text" : "@null_min \u6771\u6D0B\u53F2\u306E\u53CB\u4EBA\u304C\u3044\u308B\u306E\u3067\u3001\u305D\u306E\u4EBA\u306B(\u5F7C\u3082\u542B\u3081\u3066)\u8208\u5473\u3042\u308A\u305D\u3046\u306A\u4EBA\u304C\u3044\u306A\u3044\u304B\u805E\u304F\u304F\u3089\u3044\u306E\u4E8B\u306F\u51FA\u6765\u307E\u3059\u3088\u30FC",
  "id" : 322387587274788866,
  "in_reply_to_status_id" : 322386701408407552,
  "created_at" : "2013-04-11 16:36:05 +0000",
  "in_reply_to_screen_name" : "null_min",
  "in_reply_to_user_id_str" : "480291899",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322386168270450689",
  "text" : "\u5200\u8A9E\u3084\u3063\u3066\u3093\u306E\u304B\u30FC\u3001\u6A5F\u304C\u719F\u3057\u305F\u3089\u7E8F\u3081\u3066\u8AAD\u3082\u3046",
  "id" : 322386168270450689,
  "created_at" : "2013-04-11 16:30:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306A\u3082\u3061",
      "screen_name" : "null_min",
      "indices" : [ 0, 9 ],
      "id_str" : "480291899",
      "id" : 480291899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322385101088518144",
  "geo" : { },
  "id_str" : "322385324317761537",
  "in_reply_to_user_id" : 480291899,
  "text" : "@null_min \u6587\u5B66\u90E8\u306E\u77E5\u308A\u5408\u3044\u306B\u58F0\u304B\u3051\u307E\u3057\u3087\u3046\u304B\uFF1F",
  "id" : 322385324317761537,
  "in_reply_to_status_id" : 322385101088518144,
  "created_at" : "2013-04-11 16:27:05 +0000",
  "in_reply_to_screen_name" : "null_min",
  "in_reply_to_user_id_str" : "480291899",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322372851002925057",
  "text" : "1:30\u306B\u306A\u3063\u3066\u306A\u304A\u7720\u6C17\u304C\u8A2A\u308C\u306A\u304B\u3063\u305F\u3089\u30A2\u30EB\u30B3\u30FC\u30EB\u6442\u53D6\u3082\u8996\u91CE",
  "id" : 322372851002925057,
  "created_at" : "2013-04-11 15:37:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322371319134027777",
  "geo" : { },
  "id_str" : "322371435920252929",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u30AE\u30E3\u30C3\u30D7(^^)(^^)(^^)\u3042\u308A\u3059\u304E(^^)(^^)(^^)\u5B9F\u969B\u3084\u3070\u3044(^^)(^^)(^^)",
  "id" : 322371435920252929,
  "in_reply_to_status_id" : 322371319134027777,
  "created_at" : "2013-04-11 15:31:54 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322371110190579712",
  "text" : "\u8001\u5BB3\u611F\u3092\u6F14\u51FA\u3059\u308B\u305F\u3081\u306B\u65E7\u5165\u751F\u6B53\u8FCE\u4F1A\u3092\u3084\u308B\u3079\u304D\u306A\u306E\u3067\u306F",
  "id" : 322371110190579712,
  "created_at" : "2013-04-11 15:30:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322370525252952066",
  "text" : "\u6BDB\u3092\u629C\u304F\u6642\u306E\u75DB\u307F\u306F\u5207\u308A\u50B7\u3068\u304B\u305D\u3046\u8A00\u3046\u306E\u3068\u9055\u3046\u6C17\u304C\u3059\u308B",
  "id" : 322370525252952066,
  "created_at" : "2013-04-11 15:28:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322370320075984897",
  "text" : "\u9F3B\u6BDB\u304C\u4E00\u672C\u3084\u305F\u3089\u4F38\u3073\u3066\u305F\u304B\u3089\u6BDB\u629C\u304D\u3067\u629C\u3044\u305F\u306E\u306F\u826F\u3044\u304C\u305D\u308C\u304C\u5F15\u304D\u91D1\u306B\u306A\u3063\u3066\u304F\u3057\u3083\u307F\u3068\u6D99\u304C\u3068\u3081\u3069\u306A\u3044\u306E\u3067\u3042\u306E\u6BDB\u304C\u304F\u3057\u3083\u307F\u3068\u304B\u6D99\u3092\u98DF\u3044\u6B62\u3081\u3066\u3044\u305F\u53EF\u80FD\u6027\u306B\u3064\u3044\u3066",
  "id" : 322370320075984897,
  "created_at" : "2013-04-11 15:27:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u305D\u308C\u306F\u53E4\u7269\u5546",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322324231117496320",
  "text" : "\u3067\u306F\u50D5\u306F\u9AA8\u8463\u3092\u58F2\u308A\u8CB7\u3044\u3057\u307E\u3059 #\u305D\u308C\u306F\u53E4\u7269\u5546",
  "id" : 322324231117496320,
  "created_at" : "2013-04-11 12:24:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322318202703073280",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 322318202703073280,
  "created_at" : "2013-04-11 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322309486373134338",
  "text" : "\u30DC\u30E4\u306A\u306E\u304B\u5168\u713C\u306A\u306E\u304B\u305D\u3082\u305D\u3082\u706B\u4E8B\u3067\u306A\u3044\u306E\u304B",
  "id" : 322309486373134338,
  "created_at" : "2013-04-11 11:25:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322309363081564160",
  "text" : "\u3069\u30FC\u3082\u672C\u5F53\u306F\u706B\u4E8B\u3058\u3083\u306A\u3044\u611Fis\u3059\u3054\u3044\u3042\u308B",
  "id" : 322309363081564160,
  "created_at" : "2013-04-11 11:25:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322309195183558656",
  "text" : "\u5BFE\u5CB8\u306E\u706B\u4E8B\u3082\u4FE1\u5FC3\u304B\u3089",
  "id" : 322309195183558656,
  "created_at" : "2013-04-11 11:24:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322309197779857408",
  "text" : "\uFF1F",
  "id" : 322309197779857408,
  "created_at" : "2013-04-11 11:24:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322308707868368896",
  "text" : "\u5FA9\u520A\u516C\u7406\u7684\u96C6\u5408\u8AD6\u767D\u304F\u3066\u826F\u3044\u611F\u3058\u3060\u3063\u305F(\u30EB\u30CD\u306B\u3066\u4E00\u518A\u3060\u3051\u78BA\u8A8D)",
  "id" : 322308707868368896,
  "created_at" : "2013-04-11 11:22:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u897F",
      "screen_name" : "chinchikurim_ba",
      "indices" : [ 0, 16 ],
      "id_str" : "277901173",
      "id" : 277901173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322308336001363969",
  "geo" : { },
  "id_str" : "322308492746694656",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurim_ba \u30BD\u30FC\u30B9\u602A\u3057\u3052\u3067\u3059\u3088",
  "id" : 322308492746694656,
  "in_reply_to_status_id" : 322308336001363969,
  "created_at" : "2013-04-11 11:21:47 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322308380448407553",
  "text" : "\u3067\u3082\u3001\u672C\u5F53\u306B\u305D\u308C\u306F\u5BB6\u4E8B\u3067\u3057\u3087\u3046\u304B( \u00B4_\u309D\uFF40)",
  "id" : 322308380448407553,
  "created_at" : "2013-04-11 11:21:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322308200391122944",
  "text" : "\u51FA\u753A\u706B\u4E8B( \u00B4_\u309D\uFF40)\uFF1F",
  "id" : 322308200391122944,
  "created_at" : "2013-04-11 11:20:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322307950062485504",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u6442\u53D6\u91CF1\u30EA\u30C3\u30C8\u30EB\u8D85\u3048\u3066\u3066( \u00B4_\u309D\uFF40)",
  "id" : 322307950062485504,
  "created_at" : "2013-04-11 11:19:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321993599015321600",
  "text" : "\u30CF\u30F3\u30EC\u30A4\u3068\u805E\u3044\u3066\u53CD\u4F8B\u3068\u601D\u3046\u304B\u5224\u4F8B\u3068\u601D\u3046\u304B",
  "id" : 321993599015321600,
  "created_at" : "2013-04-10 14:30:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321993085817081858",
  "text" : "\u3053\u3093\u306A\u3093\u304CFav\u3089\u308C\u308B\u30B5\u30C4\u30D0\u30C4\u3081\u3044\u305F\u30DE\u30C3\u30DD\u30FC\u306E\u4E16\u306E\u4E2D",
  "id" : 321993085817081858,
  "created_at" : "2013-04-10 14:28:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321992849560309761",
  "text" : "\u30BB\u30DF\u30CA\u30FC\u4E2D\u306B\u4E00\u4EBA\u3067\u7B11\u3044\u304B\u3051\u3066\u3044\u305F",
  "id" : 321992849560309761,
  "created_at" : "2013-04-10 14:27:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321992704290603008",
  "text" : "\u3053\u306E\u5BFE\u5FDCNat\u306B\u306A\u3063\u3068\u308B\uFF57\uFF57\uFF57\uFF57\uFF57Nat\u306B\uFF57\uFF57\uFF57\uFF57\uFF57\u306A\u3063\u3068\u308B\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 321992704290603008,
  "created_at" : "2013-04-10 14:26:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321955363748470785",
  "text" : "\u30EA\u30D7\u30E9\u30A4\u6C17\u3065\u304B\u306A\u304B\u3063\u305F\u9854",
  "id" : 321955363748470785,
  "created_at" : "2013-04-10 11:58:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "indices" : [ 0, 10 ],
      "id_str" : "515476338",
      "id" : 515476338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321926895061041152",
  "geo" : { },
  "id_str" : "321955293917499392",
  "in_reply_to_user_id" : 515476338,
  "text" : "@hatsusato \u3042\u3001\u4F59\u3063\u3066\u306A\u3044\u3067\u3059(^^)(^^)(^^)",
  "id" : 321955293917499392,
  "in_reply_to_status_id" : 321926895061041152,
  "created_at" : "2013-04-10 11:58:18 +0000",
  "in_reply_to_screen_name" : "hatsusato",
  "in_reply_to_user_id_str" : "515476338",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321889286146363392",
  "text" : "\u4E8C\u56DE\u751F\u306E\u591A\u3055\u306B\u72FC\u72FD\u3057\u3066\u3044\u308B",
  "id" : 321889286146363392,
  "created_at" : "2013-04-10 07:36:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321781593691791361",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\uFF1F\uFF01\u30CA\u30F3\u30C7\uFF1F\uFF01\u30CB\u30F3\u30B8\u30E3\u30CA\u30F3\u30C7\uFF1F\uFF01",
  "id" : 321781593691791361,
  "created_at" : "2013-04-10 00:28:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u306A\u305F\u307E\uFF08CV:\u6E21\u8FBA\u4E45\u7F8E\u5B50\uFF09",
      "screen_name" : "MyoyoShinnyo",
      "indices" : [ 3, 16 ],
      "id_str" : "246293965",
      "id" : 246293965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321781459809607680",
  "text" : "RT @MyoyoShinnyo: \u5B89\u500D\u664B\u4E09\u304C\u30DD\u30C3\u30D7\u30AB\u30EB\u30C1\u30E3\u30FC\u5BA3\u8A00\u306A\u3093\u304B\u3059\u308B\u3088\u308A\u3001\u56FD\u969B\u4F1A\u8B70\u3067\u30DD\u30ED\u30C3\u3068\u300C\u305D\u308C\u306B\u3064\u3044\u3066\u306F\u6211\u304C\u56FD\u306E\u30CB\u30F3\u30B8\u30E3\u304C\u2026\u2026\u300D\u3063\u3066\u3053\u307C\u3057\u3066\u6A2A\u306E\u53C2\u4E8B\u5B98\u304C\u771F\u3063\u9752\u306A\u9854\u3067\u300C\u95A3\u4E0B\uFF01\u305D\u308C\u306F\uFF01\u300D\u3063\u3066\u305F\u3057\u306A\u3081\u3066\u614C\u3066\u3066\u5B89\u500D\u304C\u8A02\u6B63\u3059\u308B\u307B\u3046\u304C\u30AF\u30FC\u30EB\u30B8\u30E3\u30D1\u30F3\u306A\u308B\u3082\u306E\u304C\u76EE\u6307\u3059\u3068\u3053\u308D\u306E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321775708919701504",
    "text" : "\u5B89\u500D\u664B\u4E09\u304C\u30DD\u30C3\u30D7\u30AB\u30EB\u30C1\u30E3\u30FC\u5BA3\u8A00\u306A\u3093\u304B\u3059\u308B\u3088\u308A\u3001\u56FD\u969B\u4F1A\u8B70\u3067\u30DD\u30ED\u30C3\u3068\u300C\u305D\u308C\u306B\u3064\u3044\u3066\u306F\u6211\u304C\u56FD\u306E\u30CB\u30F3\u30B8\u30E3\u304C\u2026\u2026\u300D\u3063\u3066\u3053\u307C\u3057\u3066\u6A2A\u306E\u53C2\u4E8B\u5B98\u304C\u771F\u3063\u9752\u306A\u9854\u3067\u300C\u95A3\u4E0B\uFF01\u305D\u308C\u306F\uFF01\u300D\u3063\u3066\u305F\u3057\u306A\u3081\u3066\u614C\u3066\u3066\u5B89\u500D\u304C\u8A02\u6B63\u3059\u308B\u307B\u3046\u304C\u30AF\u30FC\u30EB\u30B8\u30E3\u30D1\u30F3\u306A\u308B\u3082\u306E\u304C\u76EE\u6307\u3059\u3068\u3053\u308D\u306E\u65E5\u672C\u306E\u30D6\u30E9\u30F3\u30C9\u4FA1\u5024\u9AD8\u306F\u307E\u308B\u3068\u601D\u3046\u3093\u3060\u3088\u306D",
    "id" : 321775708919701504,
    "created_at" : "2013-04-10 00:04:41 +0000",
    "user" : {
      "name" : "\u3053\u306A\u305F\u307E\uFF08CV:\u6E21\u8FBA\u4E45\u7F8E\u5B50\uFF09",
      "screen_name" : "MyoyoShinnyo",
      "protected" : false,
      "id_str" : "246293965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000389607856\/69db0f37bdfb26e5b43a39fb30811394_normal.jpeg",
      "id" : 246293965,
      "verified" : false
    }
  },
  "id" : 321781459809607680,
  "created_at" : "2013-04-10 00:27:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321779782050263040",
  "text" : "\u30AF\u30BA\u66F4\u751F\u65BD\u8A2D\u3001\u5168\u7136\u30AF\u30BA\u3058\u3083\u306A\u3044\u3084\u3064\u304C\u300C\u4FFA\u30DE\u30B8\u3067\u30AF\u30BA\u3060\u308F\u30FC\u7B11\u300D\u3063\u3066\u8A00\u3044\u306A\u304C\u3089\u3084\u3063\u3066\u6765\u3066\u3001\u672C\u5F53\u306E\u30AF\u30BA\u304C\u305D\u306E\u4EBA\u3092\u56F2\u3093\u3067\u68D2\u3067\u53E9\u304F\u672A\u6765\u3057\u304B\u898B\u3048\u306A\u3044",
  "id" : 321779782050263040,
  "created_at" : "2013-04-10 00:20:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321778229822242817",
  "text" : "\u3042\u3001\u304A\u9152\u306F\u597D\u304D\u3067\u3059\u3088\u3001\u3068\u3066\u3082\u5F31\u3044\u3067\u3059\u304C",
  "id" : 321778229822242817,
  "created_at" : "2013-04-10 00:14:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321777723154509824",
  "geo" : { },
  "id_str" : "321777985101381633",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u305D\u308C\u3082\"\u304A\u9152\u5165\u3063\u3066\u305F\u304B\u3089(\u4ED5\u65B9\u306A\u3044)\"\u3068\u306A\u308B\u98A8\u6F6E\u3082\u7591\u554F\u3060\u3063\u305F\u308A\u3057\u307E\u3059[\u81EA\u5206\u306E\u79D8\u5BC6\u3092\u66B4\u9732\u3059\u308B\u3060\u3051\u306A\u3089\u826F\u3044\u3067\u3059\u304C]",
  "id" : 321777985101381633,
  "in_reply_to_status_id" : 321777723154509824,
  "created_at" : "2013-04-10 00:13:44 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321777528903716864",
  "geo" : { },
  "id_str" : "321777689541349377",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 321777689541349377,
  "in_reply_to_status_id" : 321777528903716864,
  "created_at" : "2013-04-10 00:12:34 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321777086358491136",
  "geo" : { },
  "id_str" : "321777634193309698",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u7D50\u5C40\u672C\u5F53\u306B\u8A00\u3044\u305F\u304F\u306A\u3044\u4E8B\u3092\u8A00\u3046\u307E\u3067\u9154\u3063\u305F\u4E8B\u306A\u3057\u306A\u306E\u3067\u2026[\u52E2\u3044\u3065\u304F\u306E\u306F\u9593\u9055\u3044\u306A\u3044\u3067\u3057\u3087\u3046\u304C][\u5272\u3068\u98F2\u307F\u904E\u304E\u3066\u8A00\u3063\u3061\u3083\u30C0\u30E1\u306A\u4E8B\u307E\u3067\u8A00\u3063\u3061\u3083\u3063\u305F\u77E5\u308A\u5408\u3044\u306F\u3044\u307E\u3059\u3051\u3069]",
  "id" : 321777634193309698,
  "in_reply_to_status_id" : 321777086358491136,
  "created_at" : "2013-04-10 00:12:20 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321776980838199296",
  "text" : "\u7D76\u671B\u3057\u305F\u30C3\uFF01\u30A2\u30EB\u30B3\u30FC\u30EB\u304C\u5165\u3089\u306A\u304D\u3083\u4EBA\u3068\u8179\u5272\u3063\u3066\u8A71\u305B\u306A\u3044\u524D\u63D0\u306B\u7D76\u671B\u3057\u305F\u30C3\uFF01",
  "id" : 321776980838199296,
  "created_at" : "2013-04-10 00:09:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321776616701321216",
  "geo" : { },
  "id_str" : "321776795743551488",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u304A\u9152\u98F2\u307E\u306A\u304D\u3083\u4EBA\u3068\u8179\u5272\u3063\u3066\u8A71\u305B\u306A\u3044\u3068\u8A00\u3046\u8B0E\u524D\u63D0",
  "id" : 321776795743551488,
  "in_reply_to_status_id" : 321776616701321216,
  "created_at" : "2013-04-10 00:09:01 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321775742591569920",
  "text" : "\u304A\u3057\u3083\u3079\u308A\u3057\u305F\u304B\u3063\u305F\u3089\u3054\u306F\u3093\u3067\u3082\u305F\u3079\u306B\u3044\u304D\u307E\u3057\u3087\u30FC",
  "id" : 321775742591569920,
  "created_at" : "2013-04-10 00:04:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321775609892204544",
  "text" : "3000\u5186\u3067\u98F2\u307F\u4F1A\u884C\u304F\u306A\u3089\u4E8C\u3001\u4E09\u56DE\u65AD\u3063\u3066\u30A6\u30A4\u30B9\u30AD\u30FC\u306E\u74F6\u3067\u3082\u8CB7\u3044\u307E\u3059",
  "id" : 321775609892204544,
  "created_at" : "2013-04-10 00:04:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321775412747304960",
  "text" : "\u4F8B\u306E3000\u5186\u3067\u98F2\u307F\u4F1Ahogehoge\u306E\u5974\u9759\u304B\u306Br4s\u3057\u3066\u304A\u3044\u305F",
  "id" : 321775412747304960,
  "created_at" : "2013-04-10 00:03:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321775142000803840",
  "text" : "\u3057\u304B\u3057\u4ECA\u65E5\u306F\u5BD2\u3044\u3067\u3059\u306D\uFF1F",
  "id" : 321775142000803840,
  "created_at" : "2013-04-10 00:02:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321774622875983873",
  "text" : "\u3053\u30FC\u3072\u30FC\u3053\u30FC\u3072\u30FC",
  "id" : 321774622875983873,
  "created_at" : "2013-04-10 00:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u304E\uFF20\u5168\u81EA\u52D5\u8AD6\u6587\u751F\u6210\u30DE\u30B7\u30FC\u30F3",
      "screen_name" : "sugi3_34",
      "indices" : [ 3, 12 ],
      "id_str" : "239811064",
      "id" : 239811064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/CEyk5ZHFEk",
      "expanded_url" : "http:\/\/togetter.com\/li\/485653",
      "display_url" : "togetter.com\/li\/485653"
    } ]
  },
  "geo" : { },
  "id_str" : "321636251780386816",
  "text" : "RT @sugi3_34: \u300C\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u5C11\u5973\u307E\u3069\u304B\u30DE\u30AE\u30AB\u300D\u3092\u30C8\u30A5\u30AE\u30E3\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/CEyk5ZHFEk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/CEyk5ZHFEk",
        "expanded_url" : "http:\/\/togetter.com\/li\/485653",
        "display_url" : "togetter.com\/li\/485653"
      } ]
    },
    "geo" : { },
    "id_str" : "321635881935048704",
    "text" : "\u300C\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u5C11\u5973\u307E\u3069\u304B\u30DE\u30AE\u30AB\u300D\u3092\u30C8\u30A5\u30AE\u30E3\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/CEyk5ZHFEk",
    "id" : 321635881935048704,
    "created_at" : "2013-04-09 14:49:04 +0000",
    "user" : {
      "name" : "\u3059\u304E\uFF20\u5168\u81EA\u52D5\u8AD6\u6587\u751F\u6210\u30DE\u30B7\u30FC\u30F3",
      "screen_name" : "sugi3_34",
      "protected" : false,
      "id_str" : "239811064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000759083368\/e85c8ef377b223436c38148680eb4e4a_normal.jpeg",
      "id" : 239811064,
      "verified" : false
    }
  },
  "id" : 321636251780386816,
  "created_at" : "2013-04-09 14:50:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321634370559557632",
  "text" : "\u300C\u5149\u306B\u306A\u308B\u300D\u306E\u4EF6\u9762\u767D\u304B\u3063\u305F",
  "id" : 321634370559557632,
  "created_at" : "2013-04-09 14:43:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u5C11\u5973\u307E\u3069\u304B\u30DE\u30AE\u30AB",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321634192230338561",
  "text" : "#\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u5C11\u5973\u307E\u3069\u304B\u30DE\u30AE\u30AB \u8AB0\u304B\u307E\u3068\u3081\u3066\uFF01",
  "id" : 321634192230338561,
  "created_at" : "2013-04-09 14:42:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321593451185582080",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 321593451185582080,
  "created_at" : "2013-04-09 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/QnUKxEGZsJ",
      "expanded_url" : "http:\/\/4sq.com\/14TGRng",
      "display_url" : "4sq.com\/14TGRng"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "321555983258251265",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/QnUKxEGZsJ",
  "id" : 321555983258251265,
  "created_at" : "2013-04-09 09:31:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321456970215333888",
  "text" : "\u30AC\u30F3\u30D0\u30EB\u30BE\u30FC",
  "id" : 321456970215333888,
  "created_at" : "2013-04-09 02:58:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7559\u3005\u6D6A\u4EBA\u306E\u3053\u306E\u3053",
      "screen_name" : "Far_east_turtle",
      "indices" : [ 0, 16 ],
      "id_str" : "277816120",
      "id" : 277816120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321456696847376384",
  "geo" : { },
  "id_str" : "321456772726525952",
  "in_reply_to_user_id" : 277816120,
  "text" : "@Far_east_turtle \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 321456772726525952,
  "in_reply_to_status_id" : 321456696847376384,
  "created_at" : "2013-04-09 02:57:21 +0000",
  "in_reply_to_screen_name" : "Far_east_turtle",
  "in_reply_to_user_id_str" : "277816120",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321433995176984577",
  "geo" : { },
  "id_str" : "321456470786985984",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u5727\u5012\u7684(^^)(^^)(^^)\u7406\u89E3(^^)(^^)(^^)",
  "id" : 321456470786985984,
  "in_reply_to_status_id" : 321433995176984577,
  "created_at" : "2013-04-09 02:56:09 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321433251652710400",
  "text" : "\u65E9\u3081\u306B\u3044\u3063\u305F\u3089\u6559\u5BA4\u7A7A\u3044\u3066\u305F\u3060\u3051(^^)(^^)(^^)",
  "id" : 321433251652710400,
  "created_at" : "2013-04-09 01:23:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321433136665878528",
  "text" : "\u3042\u3001\u30D3\u30E9\u306F\u5DFB\u304D\u7D42\u308F\u308A\u307E\u3057\u305F[\u30CF\u30E4\u30A4\u30FB\u30CF\u30E4\u30A4\u30FB\u5B9F\u969B\u30CF\u30E4\u30A4][\u30B9\u30B4\u30A4\u30FB\u30D3\u30E9\u30DE\u30AD\u30FB\u30B8\u30C4]",
  "id" : 321433136665878528,
  "created_at" : "2013-04-09 01:23:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321432552244146177",
  "text" : "\u3069\u3046\u3082\u3001\u8650\u6BBA\u3055\u308C\u306B\u6765\u307E\u3057\u305F",
  "id" : 321432552244146177,
  "created_at" : "2013-04-09 01:21:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "memo",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321294371435737088",
  "text" : "4\u517110, 4\u517112 #memo",
  "id" : 321294371435737088,
  "created_at" : "2013-04-08 16:12:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321290428857065472",
  "text" : "\u3069\u3046\u3082\u3001\u3088\u304F\u8003\u3048\u308C\u3070Twitter\u3067\u3082\u3069\u3046\u3067\u3082\u3044\u3044\u66F8\u304D\u8FBC\u307F\u3092\u9023\u767A\u3059\u308B\u30DE\u30F3\u3067\u3057\u305F",
  "id" : 321290428857065472,
  "created_at" : "2013-04-08 15:56:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321290287173472258",
  "text" : "\u3069\u3046\u3082\u3001Facebook\u3067\u3069\u3046\u3067\u3082\u3044\u3044\u66F8\u304D\u8FBC\u307F\u3092\u9023\u767A\u3059\u308B\u30DE\u30F3\u3067\u3059\u3002",
  "id" : 321290287173472258,
  "created_at" : "2013-04-08 15:55:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u308F\u304B\u305C\uFF20\u9EBA\u985E",
      "screen_name" : "ddg170sawakaze",
      "indices" : [ 3, 18 ],
      "id_str" : "490385534",
      "id" : 490385534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321290173948252162",
  "text" : "RT @ddg170sawakaze: \u3010SNS\u3067\u5973\u6027\u304C\u5ACC\u3046\u7537\u3011\n\u7B2C\uFF11\u4F4D \u81EA\u5206\u306E\u9854\u5199\u771F\u3092\u30A2\u30C3\u30D7\u3059\u308B\u7537\n\u7B2C\uFF12\u4F4D \u3069\u3046\u3067\u3082\u3044\u3044\u30AB\u30AD\u30B3\u30DF\u3092\u9023\u767A\u3059\u308B\u7537\n\u7B2C\uFF13\u4F4D \u30CA\u30F3\u30D1\u76EE\u7684\u306E\u7537\n\u7B2C\uFF14\u4F4D \u4ED6\u4EBA\u306E\u30AB\u30AD\u30B3\u30DF\u306B\u5373\u7B54\u3059\u308B\u7537\n\u7B2C\uFF15\u4F4D \u65E5\u8A18\u3092\u30DD\u30A8\u30E0\u8ABF\u306B\u66F8\u304F\u7537",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321280897372520448",
    "text" : "\u3010SNS\u3067\u5973\u6027\u304C\u5ACC\u3046\u7537\u3011\n\u7B2C\uFF11\u4F4D \u81EA\u5206\u306E\u9854\u5199\u771F\u3092\u30A2\u30C3\u30D7\u3059\u308B\u7537\n\u7B2C\uFF12\u4F4D \u3069\u3046\u3067\u3082\u3044\u3044\u30AB\u30AD\u30B3\u30DF\u3092\u9023\u767A\u3059\u308B\u7537\n\u7B2C\uFF13\u4F4D \u30CA\u30F3\u30D1\u76EE\u7684\u306E\u7537\n\u7B2C\uFF14\u4F4D \u4ED6\u4EBA\u306E\u30AB\u30AD\u30B3\u30DF\u306B\u5373\u7B54\u3059\u308B\u7537\n\u7B2C\uFF15\u4F4D \u65E5\u8A18\u3092\u30DD\u30A8\u30E0\u8ABF\u306B\u66F8\u304F\u7537",
    "id" : 321280897372520448,
    "created_at" : "2013-04-08 15:18:29 +0000",
    "user" : {
      "name" : "\u3055\u308F\u304B\u305C\uFF20\u9EBA\u985E",
      "screen_name" : "ddg170sawakaze",
      "protected" : false,
      "id_str" : "490385534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000826740959\/32ab6e45395bc15efd76ebfba6d43bc4_normal.jpeg",
      "id" : 490385534,
      "verified" : false
    }
  },
  "id" : 321290173948252162,
  "created_at" : "2013-04-08 15:55:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321280119597568001",
  "geo" : { },
  "id_str" : "321289207811284992",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3042\u3001\u30AF\u30E9\u30A4\u30F3\u3067\u3057\u305F\u3002\u30B8\u30E3\u30FC\u30CA\u30EB\u306F\u5B66\u8853\u8A8C\u306E\u8A18\u4E8B\u3067\u3059\u3001\u305F\u3076\u3093[\u50D5\u306F\u5C02\u3089\u96FB\u5B50\u30D6\u30C3\u30AF\u3057\u304B\u843D\u3068\u3057\u3066\u306A\u3044\u3067\u3059]",
  "id" : 321289207811284992,
  "in_reply_to_status_id" : 321280119597568001,
  "created_at" : "2013-04-08 15:51:31 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321187773866467329",
  "geo" : { },
  "id_str" : "321243879355580416",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3082\u306E\u306B\u3088\u3063\u3066\u306F\u7121\u6599\u3067\u843D\u3068\u305B\u307E\u3059\u3088[\u30AF\u30E9\u30B7\u30B9\u306E\u96FB\u5B50\u30D6\u30C3\u30AF\u3068\u304B\u30B8\u30E3\u30FC\u30CA\u30EB\u3068\u304B]",
  "id" : 321243879355580416,
  "in_reply_to_status_id" : 321187773866467329,
  "created_at" : "2013-04-08 12:51:23 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 0, 10 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321243446864117760",
  "geo" : { },
  "id_str" : "321243577743200257",
  "in_reply_to_user_id" : 158645894,
  "text" : "@eclair_15 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 321243577743200257,
  "in_reply_to_status_id" : 321243446864117760,
  "created_at" : "2013-04-08 12:50:12 +0000",
  "in_reply_to_screen_name" : "eclair_15",
  "in_reply_to_user_id_str" : "158645894",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321228788962836480",
  "text" : "\u304A\u304F\u308C\u3070\u305B\u306A\u304C\u3089",
  "id" : 321228788962836480,
  "created_at" : "2013-04-08 11:51:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 2, 9 ],
      "id_str" : "141811283",
      "id" : 141811283
    }, {
      "name" : "\u306B\u3083\u3093\u3075",
      "screen_name" : "nyamph_pf",
      "indices" : [ 10, 20 ],
      "id_str" : "107723928",
      "id" : 107723928
    }, {
      "name" : "__pooka",
      "screen_name" : "__pooka",
      "indices" : [ 21, 29 ],
      "id_str" : "2549404663",
      "id" : 2549404663
    }, {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 30, 38 ],
      "id_str" : "145536184",
      "id" : 145536184
    }, {
      "name" : "\u3072\u3083\u307E\u3072\u3087\u3046",
      "screen_name" : "hyamaHyo",
      "indices" : [ 39, 48 ],
      "id_str" : "623703365",
      "id" : 623703365
    }, {
      "name" : "\u3061\u3083\u3093\u3081\u304A",
      "screen_name" : "came1223pg",
      "indices" : [ 49, 60 ],
      "id_str" : "218818356",
      "id" : 218818356
    }, {
      "name" : "\u6D85\u69C3",
      "screen_name" : "_ne_ha_n_",
      "indices" : [ 61, 71 ],
      "id_str" : "499591313",
      "id" : 499591313
    }, {
      "name" : "\u3082\u3061\u3059\u3051",
      "screen_name" : "Sichuanpepper",
      "indices" : [ 72, 86 ],
      "id_str" : "273407186",
      "id" : 273407186
    }, {
      "name" : "\u305F\u307E\u307D\u3093",
      "screen_name" : "KhronosTamapon",
      "indices" : [ 87, 102 ],
      "id_str" : "398375051",
      "id" : 398375051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321228770595991552",
  "text" : ". @rpdexp @nyamph_pf @__pooka @chr1233 @HyamaHyo @came1223pg @_ne_ha_n_ @Sichuanpepper @KhronosTamapon \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 321228770595991552,
  "created_at" : "2013-04-08 11:51:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321186825974722560",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 321186825974722560,
  "created_at" : "2013-04-08 09:04:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321186773818544128",
  "text" : "\u3055\u3066\u3055\u3066",
  "id" : 321186773818544128,
  "created_at" : "2013-04-08 09:04:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/qKVyPLK6tC",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/2?prefill=yo4_kuma",
      "display_url" : "gohantabeyo.com\/nani\/2?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321181871067254784",
  "text" : "\u304A\u8336\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/qKVyPLK6tC",
  "id" : 321181871067254784,
  "created_at" : "2013-04-08 08:44:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ENIG-ROID",
      "screen_name" : "ENIG_ROID",
      "indices" : [ 3, 13 ],
      "id_str" : "869885886",
      "id" : 869885886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321119246455304192",
  "text" : "RT @ENIG_ROID: \u4EAC\u90FD\u5927\u5B66\u306B\u3066\u884C\u308F\u308C\u308B\u30A8\u30CB\u30B0\u30ED\u30A4\u30C9\u65B0\u6B53\u30EA\u30A2\u30EB\u8B0E\u89E3\u304D\u30B2\u30FC\u30E0\uFF08\u3082\u3061\u308D\u3093\u7121\u6599\u3060\u3088\uFF09\u521D\u56DE\u516C\u6F14\u306F\u4ECA\u65E5\uFF01\u2026\u2026\u306E\u300118\u664215\u5206\u304B\u3089\u30AF\u30B9\u30CE\u30AD\u524D\u3067\u3059\uFF0115\u5206\u306B\u9593\u306B\u5408\u308F\u306A\u3044\u3088\u3063\u3066\u65B9\u308218\u664230\u5206\u304F\u3089\u3044\u307E\u3067\u306A\u3089\u554F\u984C\u306A\u304F\u30B2\u30FC\u30E0\u306B\u53C2\u52A0\u3067\u304D\u307E\u3059\u306E\u3067\u662F\u975E\u304A\u8D8A\u3057\u304F\u3060\u3055\u3044\u3002\u65B0\u5165 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321119173541502976",
    "text" : "\u4EAC\u90FD\u5927\u5B66\u306B\u3066\u884C\u308F\u308C\u308B\u30A8\u30CB\u30B0\u30ED\u30A4\u30C9\u65B0\u6B53\u30EA\u30A2\u30EB\u8B0E\u89E3\u304D\u30B2\u30FC\u30E0\uFF08\u3082\u3061\u308D\u3093\u7121\u6599\u3060\u3088\uFF09\u521D\u56DE\u516C\u6F14\u306F\u4ECA\u65E5\uFF01\u2026\u2026\u306E\u300118\u664215\u5206\u304B\u3089\u30AF\u30B9\u30CE\u30AD\u524D\u3067\u3059\uFF0115\u5206\u306B\u9593\u306B\u5408\u308F\u306A\u3044\u3088\u3063\u3066\u65B9\u308218\u664230\u5206\u304F\u3089\u3044\u307E\u3067\u306A\u3089\u554F\u984C\u306A\u304F\u30B2\u30FC\u30E0\u306B\u53C2\u52A0\u3067\u304D\u307E\u3059\u306E\u3067\u662F\u975E\u304A\u8D8A\u3057\u304F\u3060\u3055\u3044\u3002\u65B0\u5165\u751F\u3058\u3083\u306A\u304F\u3066\u3082\u4EAC\u5927\u751F\u3058\u3083\u306A\u304F\u3066\u3082\u3069\u3046\u305E",
    "id" : 321119173541502976,
    "created_at" : "2013-04-08 04:35:51 +0000",
    "user" : {
      "name" : "ENIG-ROID",
      "screen_name" : "ENIG_ROID",
      "protected" : false,
      "id_str" : "869885886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000519212705\/aecb26ac9965ef50046be696a9838606_normal.jpeg",
      "id" : 869885886,
      "verified" : false
    }
  },
  "id" : 321119246455304192,
  "created_at" : "2013-04-08 04:36:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321119188548722689",
  "text" : "\u6570\u5B66\u56F3\u66F8\u9928\u3001\u7406\u5B66\u90E8\u56F3\u66F8\u9928\u3001\u60C5\u5831\u56F3\u66F8\u9928\u3068\u6E21\u308A\u6B69\u304F\u3055\u306A\u304C\u3089\u56F3\u66F8\u9928\u30B9\u30BF\u30F3\u30D7\u30E9\u30EA\u30FC\u3067\u3042\u308B(^^)(^^)(^^)",
  "id" : 321119188548722689,
  "created_at" : "2013-04-08 04:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321097732360130560",
  "text" : "\u6708\u66DC\u65E5\u5168\u4F11\u3060\u304B\u3089\u5168\u7136\u65B0\u5B66\u671F\u611F\u306A\u3044\u3001\u3044\u3084\u5927\u5B66\u306B\u306F\u3044\u304F\u3051\u3069",
  "id" : 321097732360130560,
  "created_at" : "2013-04-08 03:10:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321096618361356288",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u3092\u6D74\u3073\u308B\u3053\u3068\u3067\u3053\u308C\u3092\u56DE\u907F\u3059\u308B\u76EE\u8AD6\u898B",
  "id" : 321096618361356288,
  "created_at" : "2013-04-08 03:06:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321095488453636098",
  "text" : "\u307E\u305A\u3044\u306A\u3001\u4ECA\u51FA\u639B\u3051\u308B\u3068\u56F3\u66F8\u9928\u306E\u663C\u4F11\u307F\u306B\u3076\u3061\u5F53\u305F\u308B",
  "id" : 321095488453636098,
  "created_at" : "2013-04-08 03:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321095042649423872",
  "text" : "pon de ring\u3063\u3066\u3069\u3093\u306A\u74B0",
  "id" : 321095042649423872,
  "created_at" : "2013-04-08 02:59:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321088232039268352",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u3044\u308C\u3066\u30C9\u30FC\u30CA\u30C4\u98DF\u3079\u308B[\u671D\u3054\u306F\u3093\/\u663C\u3054\u306F\u3093]",
  "id" : 321088232039268352,
  "created_at" : "2013-04-08 02:32:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321085999088275458",
  "text" : "\u76EE\u899A\u3081\u305F",
  "id" : 321085999088275458,
  "created_at" : "2013-04-08 02:24:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320931688639250432",
  "text" : "2\u6642\u306B\u306F\u5BDD\u307E\u3057\u3087\u30FC",
  "id" : 320931688639250432,
  "created_at" : "2013-04-07 16:10:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320930996054794240",
  "text" : "\u6628\u65E5\u304A\u3057\u3083\u3079\u308A\u3057\u305F\u5F8C\u8F29\u3001\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u306B\u3064\u3044\u3066\u300C\u30A2\u30A4\u30A8\u30A8\u30A8\u3060\u3051\u5206\u304B\u308A\u307E\u3059\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3057\u3044\u308D\u3093\u306A\u610F\u5473\u3067\u6709\u671B",
  "id" : 320930996054794240,
  "created_at" : "2013-04-07 16:08:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320930441114824704",
  "text" : "dmc3\u306Ebgm\u3068\u304B\u4E45\u3005\u306B\u805E\u3044\u3066\u308B\u3051\u3069\u3044\u3044\u611F\u3058",
  "id" : 320930441114824704,
  "created_at" : "2013-04-07 16:05:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320929778888749057",
  "text" : "adobe\u306EAcrobat\u6628\u65E5\u4F53\u9A13\u7248\u843D\u3068\u3057\u305F\u3051\u308C\u3069\u4F7F\u3044\u52DD\u624B\u306E\u826F\u3055\u3084\u3070\u3044\u304B\u3089\u672C\u8CB7\u3046\u304A\u91D1\u3092\u305D\u3063\u3061\u306B\u56DE\u3059\u307E\u3067\u3042\u308B\u306A\u2026",
  "id" : 320929778888749057,
  "created_at" : "2013-04-07 16:03:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320928665401712642",
  "text" : "\u8A87\u5F35\u306E\u5922",
  "id" : 320928665401712642,
  "created_at" : "2013-04-07 15:58:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320928608162045952",
  "text" : "\u8A87\u5F35\u3057\u307E\u3057\u305F",
  "id" : 320928608162045952,
  "created_at" : "2013-04-07 15:58:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320928578437009408",
  "text" : "\u96C6\u5408\u4F4D\u76F83\u5E74\u9593\u5C65\u4FEE\u3057\u7D9A\u3051\u308B\u904A\u3073\u3059\u308B\u4E88\u5B9A\u3060\u3063\u305F\u306E\u306B\u4ECA\u5E74\u304B\u3089\u6559\u990A\u304B\u3089\u6D88\u3048\u3066\u3066\u30C7\u30A3\u30B9\u30D7\u30EC\u30A4\u53E9\u304D\u5272\u3063\u305F",
  "id" : 320928578437009408,
  "created_at" : "2013-04-07 15:58:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320928127331213313",
  "geo" : { },
  "id_str" : "320928327844130816",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u3061\u3083\u3093\u3068\u52C9\u5F37\u3057\u3066\u308C\u3070\u8A66\u9A13\u306B\u3055\u3048\u5BDD\u574A\u3057\u306A\u3051\u308C\u3070\u5358\u4F4D\u306F\u53D6\u308C\u308B\u306E\u3067\u9811\u5F35\u308A\u307E\u3057\u3087\u3046",
  "id" : 320928327844130816,
  "in_reply_to_status_id" : 320928127331213313,
  "created_at" : "2013-04-07 15:57:30 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320928051523358720",
  "text" : "\u4E00\u9650\u306F\u4E16\u754C\u306E\u6575\u3060\u3068\u601D\u3063\u3066\u3044\u308B",
  "id" : 320928051523358720,
  "created_at" : "2013-04-07 15:56:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320927631698714624",
  "geo" : { },
  "id_str" : "320927948150546432",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u50D5\u306F\u904E\u53BB\u306B\u4E00\u9650\u306E\u8A9E\u5B66\u306E\u8A66\u9A13\u3092\u5BDD\u30D6\u30C3\u30C1\u3057\u305F\u95C7\u3092\u62B1\u3048\u3066\u3044\u308B\u306E\u3067\u4E00\u9650\u306F\u672C\u5F53\u306B\u6016\u3044\u3067\u3059",
  "id" : 320927948150546432,
  "in_reply_to_status_id" : 320927631698714624,
  "created_at" : "2013-04-07 15:56:00 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320927041769840640",
  "geo" : { },
  "id_str" : "320927196053123073",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u305D\u308C\u306A\u2026[\u8D77\u304D\u3089\u308C\u305A\u306B\u72EC\u7FD2\u30B3\u30FC\u30B9]",
  "id" : 320927196053123073,
  "in_reply_to_status_id" : 320927041769840640,
  "created_at" : "2013-04-07 15:53:00 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320883563845259265",
  "text" : "\u30CE\u30FC\u30A8\u30B9\u30B1\u30FC\u30D7\u3067\u3059\u3088",
  "id" : 320883563845259265,
  "created_at" : "2013-04-07 12:59:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320868694425235458",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 320868694425235458,
  "created_at" : "2013-04-07 12:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320803159893221376",
  "geo" : { },
  "id_str" : "320811080429481984",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u306F\u3044",
  "id" : 320811080429481984,
  "in_reply_to_status_id" : 320803159893221376,
  "created_at" : "2013-04-07 08:11:36 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320801951115776000",
  "text" : "\u304A\u30FC\u304C\u3075\u30FC\u304F\u3089\u30FC\u3044",
  "id" : 320801951115776000,
  "created_at" : "2013-04-07 07:35:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320801914503712768",
  "text" : "#nowplaying Ogre who cries - A\uFF5EYA",
  "id" : 320801914503712768,
  "created_at" : "2013-04-07 07:35:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 0, 9 ],
      "id_str" : "22502063",
      "id" : 22502063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320800680300392448",
  "geo" : { },
  "id_str" : "320801266148188160",
  "in_reply_to_user_id" : 22502063,
  "text" : "@sigmapsi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 320801266148188160,
  "in_reply_to_status_id" : 320800680300392448,
  "created_at" : "2013-04-07 07:32:36 +0000",
  "in_reply_to_screen_name" : "sigmapsi",
  "in_reply_to_user_id_str" : "22502063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 0, 7 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320799166982918144",
  "geo" : { },
  "id_str" : "320800420400353280",
  "in_reply_to_user_id" : 129796835,
  "text" : "@7M1IHN \u591A\u304F\u306E\u4EBA\u304C\u30EA\u30A2\u5145\u3081\u3044\u305F\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3092\u6F02\u308F\u305B\u308B\u6295\u7A3F\u3092\u3059\u308B\u4E2D\u3069\u3046\u3067\u3082\u3044\u3044\u6295\u7A3F\u3092\u3059\u308B\u4EBA\u305F\u3061\u3092\u52DD\u624B\u306B\u305D\u3046\u547C\u3093\u3067\u3044\u307E\u3059",
  "id" : 320800420400353280,
  "in_reply_to_status_id" : 320799166982918144,
  "created_at" : "2013-04-07 07:29:15 +0000",
  "in_reply_to_screen_name" : "7M1IHN",
  "in_reply_to_user_id_str" : "129796835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320800120817987584",
  "text" : "\u308C\u3044\u306B\u30FC\u308C\u3044\u306B\u30FC\u3067\u30FC",
  "id" : 320800120817987584,
  "created_at" : "2013-04-07 07:28:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320800068699578369",
  "text" : "#nowplaying Rainy, rainy days - 3L",
  "id" : 320800068699578369,
  "created_at" : "2013-04-07 07:27:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320798213428879360",
  "text" : "\u306E\u3046\u3053\u3055\u3093\u304C\u9854\u672C\u30B5\u30C4\u30D0\u30C4\u52E2\u306B\u52A0\u308F\u308A\u3064\u3064\u3042\u3063\u3066\u5B09\u3057\u3044",
  "id" : 320798213428879360,
  "created_at" : "2013-04-07 07:20:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320736870201958400",
  "text" : "\u8ECA\u3067\u4E00\u6642\u9593\u304F\u3089\u3044\u639B\u304B\u308B\u9053\u7A0B\u3001\u7A7A\u98DB\u3093\u3067\u5E30\u308B\u5922\u3092\u898B\u3066\u3044\u305F",
  "id" : 320736870201958400,
  "created_at" : "2013-04-07 03:16:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320597062586613760",
  "text" : "\u3082\u30463\u6642\u2026",
  "id" : 320597062586613760,
  "created_at" : "2013-04-06 18:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320597025735467008",
  "text" : "\u898B\u958B\u304DA4\u306EPDF\u3092A5\u4E8C\u679A\u306B\u3059\u308B\u30B9\u30AD\u30EB\u3092\u8EAB\u306B\u3064\u3051g",
  "id" : 320597025735467008,
  "created_at" : "2013-04-06 18:01:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320557625244794883",
  "text" : "\u88C1\u65AD\u6A5F\u3060\u3051\u3067\u3082\u307E\u3068\u3082\u306A\u306E\u8CB7\u3063\u305F\u3089\u8272\u3005\u6357\u308A\u305D\u3046\u3060\u304C\u2026",
  "id" : 320557625244794883,
  "created_at" : "2013-04-06 15:24:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320557540805054466",
  "text" : "\u81EA\u708A\u52E2\u3068\u3057\u3066\u306F\n\u4ECA\u3042\u308B\u306E\u3088\u308A\u65E9\u304F\u3066\u3001\u7D19\u3092\u30BB\u30C3\u30C8\u3057\u305F\u3089\u9806\u756A\u306B\u30B9\u30AD\u30E3\u30F3\u3057\u3066\u304F\u308C\u308B\u5F62\u5F0F\u306E\u30B9\u30AD\u30E3\u30CA\n\u30A2\u30C9\u30D9\u306E\u30A2\u30AF\u30ED\u30D0\u30C3\u30C8\n\u88C1\u65AD\u6A5F\n\u304C\u6B32\u3057\u3044",
  "id" : 320557540805054466,
  "created_at" : "2013-04-06 15:24:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320524227084161024",
  "geo" : { },
  "id_str" : "320524341215367169",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u3042\u3063\u306F\u3044",
  "id" : 320524341215367169,
  "in_reply_to_status_id" : 320524227084161024,
  "created_at" : "2013-04-06 13:12:12 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320519414392967168",
  "geo" : { },
  "id_str" : "320519521532248065",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u30D3\u30FC\u30EB\u306F\u98F2\u307E\u306A\u3044\u3093\u3058\u3083\u306A\u3063\u305F\u306E\u304B",
  "id" : 320519521532248065,
  "in_reply_to_status_id" : 320519414392967168,
  "created_at" : "2013-04-06 12:53:03 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320517829604556801",
  "text" : "\u4EF2\u306E\u60AA\u3044\u4EBA\u30E9\u30F3\u30AD\u30F3\u30B0\u3082\u3068\u3044\u4E2D\u306E\u4EBA\u304C\u60AA\u3044\u4EBA\u30E9\u30F3\u30AD\u30F3\u30B0\u3068\u304B\u4F5C\u308C\u3070\u3044\u3044\u3088",
  "id" : 320517829604556801,
  "created_at" : "2013-04-06 12:46:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320515053466042368",
  "text" : "\u6587\u7CFB\u306E\u4EBA\u306B\u6570\u5B66\u306E\u8A71\u3059\u308B\u3068\u304D\u3088\u3063\u307D\u3069\u3067\u306A\u3051\u308C\u3070\u624B\u77ED\u306B\u3057\u3066\u3044\u308B",
  "id" : 320515053466042368,
  "created_at" : "2013-04-06 12:35:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320506265170231299",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 320506265170231299,
  "created_at" : "2013-04-06 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aime_928",
      "screen_name" : "Ron_Makina",
      "indices" : [ 0, 11 ],
      "id_str" : "2530911385",
      "id" : 2530911385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320451480979124224",
  "text" : "@Ron_Makina \uFF8A\uFF9E\uFF76\uFF80\uFF9E\uFF85\uFF70",
  "id" : 320451480979124224,
  "created_at" : "2013-04-06 08:22:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320451349286379521",
  "text" : "10\u5206\u3060\u3051\u4E8B\u52D9\u3084\u3063\u3066\u5E30\u3063\u3066\u304D\u305F",
  "id" : 320451349286379521,
  "created_at" : "2013-04-06 08:22:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320451309234962432",
  "text" : "\u30D0\u30A4\u30C8\u3060\u3068\u601D\u3063\u3066\u3044\u3063\u305F\u3089\u30B7\u30D5\u30C8\u5165\u3063\u3066\u306A\u304B\u3063\u305F\uFF57\uFF57\uFF57\uFF57\uFF57\u5727\u5012\u7684\u30AA\u30B5\u30F3\u30DD\u30FB\u30A4\u30F3\u30B7\u30C7\u30F3\u30C8\u3060\u3063\u305F",
  "id" : 320451309234962432,
  "created_at" : "2013-04-06 08:22:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320375900111769600",
  "text" : "\u5E78\u305B\u306A\u304A\u663C\u3054\u98EF\u3067\u3042\u308B",
  "id" : 320375900111769600,
  "created_at" : "2013-04-06 03:22:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320361240650199040",
  "text" : "\u9759\u5CA1\u304B\u3089\u7523\u76F4\u3067\u3059\u3088",
  "id" : 320361240650199040,
  "created_at" : "2013-04-06 02:24:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320360906666176512",
  "text" : "\u9BD6\u306E\u5E72\u7269\uFF0C\u30AB\u30D6\u306E\u304A\u5473\u564C\u6C41\uFF0C\u307B\u3046\u308C\u3093\u8349\u306E\u80E1\u9EBB\u548C\u3048\uFF0C\u708A\u304D\u7ACB\u3066\u3054\u306F\u3093\uFF0E\uFF0E\uFF0E",
  "id" : 320360906666176512,
  "created_at" : "2013-04-06 02:22:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320360751955079169",
  "text" : "\u89AA\u304B\u3089\u91CE\u83DC\u3084\u3089\u3055\u304B\u306A\u3084\u3089\u5C4A\u3044\u305F\u304B\u3089\u6587\u5316\u7684\u306A\u304A\u663C\u3054\u98EF\u3092\u4F5C\u308D\u3046\uFF0E",
  "id" : 320360751955079169,
  "created_at" : "2013-04-06 02:22:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320348113267212288",
  "geo" : { },
  "id_str" : "320351031760408577",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u6642\u9593\u306B\u3088\u3063\u3066\u306F\u884C\u304D\u305F\u3044\u306E\u3067\u6C7A\u307E\u3063\u305F\u3089\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u30FC\uFF01",
  "id" : 320351031760408577,
  "in_reply_to_status_id" : 320348113267212288,
  "created_at" : "2013-04-06 01:43:32 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320121709569126400",
  "geo" : { },
  "id_str" : "320122296524238849",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u308C\u3001\u60C5\u5F31[\u3058\u3087\u3046\u3058\u3083\u304F]\u3063\u3066\u8AAD\u3080\u3093\u3067\u3059\u3088\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 320122296524238849,
  "in_reply_to_status_id" : 320121709569126400,
  "created_at" : "2013-04-05 10:34:37 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320122092395839488",
  "text" : "\u9662\u6B7B\u3082\u5352\u8AD6\u3082\u3042\u308B\u3093\u3060\u3088(\u95C7)",
  "id" : 320122092395839488,
  "created_at" : "2013-04-05 10:33:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320121923692535809",
  "text" : "\uFF1F",
  "id" : 320121923692535809,
  "created_at" : "2013-04-05 10:33:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320121907640926208",
  "text" : "\u304A\u524D\u304C\u5352\u8AD6\u306E\u95C7\u3092\u8997\u304F\u306A\u3089\u3070\uFF0C\u5352\u8AD6\u306E\u95C7\u3082\u307E\u305F\u7B49\u3057\u304F\u304A\u524D\u3092\u898B\u8FD4\u3059\u306E\u3060",
  "id" : 320121907640926208,
  "created_at" : "2013-04-05 10:33:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320121405922476032",
  "geo" : { },
  "id_str" : "320121578715217920",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u7D76\u8A31",
  "id" : 320121578715217920,
  "in_reply_to_status_id" : 320121405922476032,
  "created_at" : "2013-04-05 10:31:46 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320118574880522241",
  "geo" : { },
  "id_str" : "320118781961728001",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kiu_uit \u3044\u3044\u3067\u3059\u306D\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 320118781961728001,
  "in_reply_to_status_id" : 320118574880522241,
  "created_at" : "2013-04-05 10:20:39 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/zRE0uL10Of",
      "expanded_url" : "http:\/\/4sq.com\/Y218zV",
      "display_url" : "4sq.com\/Y218zV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0286223731, 135.7839939725 ]
  },
  "id_str" : "320105404061331456",
  "text" : "I'm at \u30AB\u30D5\u30A7 \u30B3\u30EC\u30AF\u30B7\u30E7\u30F3 http:\/\/t.co\/zRE0uL10Of",
  "id" : 320105404061331456,
  "created_at" : "2013-04-05 09:27:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320098882006691841",
  "geo" : { },
  "id_str" : "320099283917488128",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3068\u308A\u3042\u3048\u305A\u56F3\u66F8\u9928\u524D\u306B\u3044\u308B\u308F",
  "id" : 320099283917488128,
  "in_reply_to_status_id" : 320098882006691841,
  "created_at" : "2013-04-05 09:03:11 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320098436714221569",
  "geo" : { },
  "id_str" : "320098676020228097",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3044\u307E\u3044\u3048\uFF1F",
  "id" : 320098676020228097,
  "in_reply_to_status_id" : 320098436714221569,
  "created_at" : "2013-04-05 09:00:46 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320098157683941376",
  "geo" : { },
  "id_str" : "320098295596867584",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u306A\u306B\u3092\u3001\u3069\u3053\u306B",
  "id" : 320098295596867584,
  "in_reply_to_status_id" : 320098157683941376,
  "created_at" : "2013-04-05 08:59:15 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320098049571581952",
  "text" : "\u304A\u8179\u6E1B\u3063\u3066\u304A\u8179\u6E1B\u3063\u305F",
  "id" : 320098049571581952,
  "created_at" : "2013-04-05 08:58:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320094158075338752",
  "text" : "\u9031\u672B\u306E\u304A\u82B1\u898B\u3084\u3089\u65B0\u6B53\u30A4\u30D9\u30F3\u30C8\u304C\u60AA\u5929\u5019\u3067\u30C0\u30E1\u306B\u306A\u3063\u3066\u884C\u304F\u4E2D\u3046\u3061\u306E\u30B5\u30FC\u30AF\u30EB\u306F\u65B0\u6B53\u30A4\u30D9\u30F3\u30C8\u4F01\u753B\u3057\u3066\u306A\u3044\u304B\u3089\u4F59\u88D5\u3067\u3059\u308F",
  "id" : 320094158075338752,
  "created_at" : "2013-04-05 08:42:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320072849643675649",
  "text" : "\u304B\u305A\u304B\u305A\u304B\u305A\u301C",
  "id" : 320072849643675649,
  "created_at" : "2013-04-05 07:18:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320001900282015744",
  "text" : "\u30A4\u30AC\u304C\u5589\u5589\u3059\u308B",
  "id" : 320001900282015744,
  "created_at" : "2013-04-05 02:36:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320001621440483330",
  "text" : "\u3080\u305A\u304C\u3086\u3044",
  "id" : 320001621440483330,
  "created_at" : "2013-04-05 02:35:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320001608668831744",
  "text" : "\u8033\u306E\u304A\u304F\u3001\u5589\u306E\u304A\u304F\u3001(\u82B1\u7C89\u306B\u3088\u308B)\u304F\u3057\u3083\u307F\u306E\u305B\u3044\u3067\u30E0\u30BA\u30E0\u30BA\u3059\u308B",
  "id" : 320001608668831744,
  "created_at" : "2013-04-05 02:35:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319804493715873793",
  "text" : "\u7D76\u5BFE\u306B\u7834\u308C\u306A\u3044\u76FE\u3068\u7D76\u5BFE\u306B\u7834\u308C\u306A\u3044\u76FE\u3068\u3067\u6226\u3063\u305F\u3089\u5BFF\u547D\u304C\u6765\u305F\u65B9\u304C\u8CA0\u3051\u308B",
  "id" : 319804493715873793,
  "created_at" : "2013-04-04 13:31:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319804210814279680",
  "text" : "\u77DB\u77DB(\u3080\u3080)",
  "id" : 319804210814279680,
  "created_at" : "2013-04-04 13:30:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319804128253591552",
  "text" : "Q.\u4F55\u3067\u3082\u3067\u3082\u8CAB\u3051\u308B\u77DB\u3092\u4E8C\u672C\u7528\u610F\u3057\u3066\u5207\u3063\u5148\u540C\u58EB\u3092\u8CAB\u3044\u305F\u3089\u3069\u3046\u306A\u308B\u306E\uFF1F\nA.\u30EF\u30B6\u30DE\u30A8\uFF01",
  "id" : 319804128253591552,
  "created_at" : "2013-04-04 13:30:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u307E\u3068\u30FC",
      "screen_name" : "imato0916",
      "indices" : [ 0, 10 ],
      "id_str" : "381508166",
      "id" : 381508166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319790859916832768",
  "geo" : { },
  "id_str" : "319791400805867521",
  "in_reply_to_user_id" : 381508166,
  "text" : "@imato0916 \u3067\u306F5\u9650\u5F8C\u306B\u6771\u4E00\u6761\u306E\u30D5\u30A1\u30DF\u30DE\u89E3\u308A\u307E\u3059\u304B\uFF1F",
  "id" : 319791400805867521,
  "in_reply_to_status_id" : 319790859916832768,
  "created_at" : "2013-04-04 12:39:46 +0000",
  "in_reply_to_screen_name" : "imato0916",
  "in_reply_to_user_id_str" : "381508166",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u307E\u3068\u30FC",
      "screen_name" : "imato0916",
      "indices" : [ 0, 10 ],
      "id_str" : "381508166",
      "id" : 381508166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319789512790257664",
  "geo" : { },
  "id_str" : "319789705816334339",
  "in_reply_to_user_id" : 381508166,
  "text" : "@imato0916 \u3048\u30FC\u3068\uFF0C\u305D\u306E\u6388\u696D\u306F\u4F55\u9650\u307E\u3067\u3042\u308A\u307E\u3059\u304B\uFF1F",
  "id" : 319789705816334339,
  "in_reply_to_status_id" : 319789512790257664,
  "created_at" : "2013-04-04 12:33:01 +0000",
  "in_reply_to_screen_name" : "imato0916",
  "in_reply_to_user_id_str" : "381508166",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u307E\u3068\u30FC",
      "screen_name" : "imato0916",
      "indices" : [ 0, 10 ],
      "id_str" : "381508166",
      "id" : 381508166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319786766011883520",
  "geo" : { },
  "id_str" : "319787453915492354",
  "in_reply_to_user_id" : 381508166,
  "text" : "@imato0916 \u3067\u306F\u6765\u9031\u306E\u706B\u66DC\u65E5\u306B.\u5348\u5F8C\u306E\u6642\u9593\u5272\u3063\u3066\u3069\u3046\u306A\u3063\u3066\u307E\u3059\uFF1F",
  "id" : 319787453915492354,
  "in_reply_to_status_id" : 319786766011883520,
  "created_at" : "2013-04-04 12:24:05 +0000",
  "in_reply_to_screen_name" : "imato0916",
  "in_reply_to_user_id_str" : "381508166",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319783801993699328",
  "text" : "\u3068\u3044\u3046\u304B\u30D3\u30EA\u30E4\u30FC\u30C9\u3068\u805E\u3044\u3066\u3053\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u30D1\u30BF\u30FC\u30F3\u3063\u3066\uFF1F[\u53E3\u30B3\u30DF\uFF1F]",
  "id" : 319783801993699328,
  "created_at" : "2013-04-04 12:09:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319783699552018432",
  "text" : "\u3042\u30FC\u50D5\u5B89\u897F\u5148\u751F\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u308C\u3069\u5927\u4E08\u592B\u3060\u3063\u305F\u304B\u306A",
  "id" : 319783699552018432,
  "created_at" : "2013-04-04 12:09:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u307E\u3068\u30FC",
      "screen_name" : "imato0916",
      "indices" : [ 0, 10 ],
      "id_str" : "381508166",
      "id" : 381508166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319778494139727873",
  "geo" : { },
  "id_str" : "319783628253065216",
  "in_reply_to_user_id" : 381508166,
  "text" : "@imato0916 \u307B\u3046\uFF01\u4E00\u56DE\u30B5\u30FC\u30AF\u30EB\u898B\u5B66\u3057\u306B\u6765\u3066\u307F\u307E\u3059\u304B\uFF1F",
  "id" : 319783628253065216,
  "in_reply_to_status_id" : 319778494139727873,
  "created_at" : "2013-04-04 12:08:52 +0000",
  "in_reply_to_screen_name" : "imato0916",
  "in_reply_to_user_id_str" : "381508166",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319781519331823616",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 319781519331823616,
  "created_at" : "2013-04-04 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319778988228751361",
  "text" : "\u59B9\u304B\u3089\u982D\u306E\u60AA\u3044\u4E2D\u5B66\u751F\u307F\u305F\u3044\u306A\u30E1\u30FC\u30EB\u304C\u6765\u305F\u304C,\u5B9F\u969B\u5F7C\u5973\u306F\u982D\u306E\u60AA\u3044\u4E2D\u5B66\u751F\u3060\u3063\u305F\uFF0E",
  "id" : 319778988228751361,
  "created_at" : "2013-04-04 11:50:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319618043380649984",
  "text" : "[\u901F\u5831]\u304F\u3063\u3061\u3093\u3071\u6C0F\u30D3\u30E9\u30ED\u30FC\u30C9\u901A\u904E",
  "id" : 319618043380649984,
  "created_at" : "2013-04-04 01:10:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319617984534560768",
  "text" : "\u30BF\u30A4\u30DF\u30F3\u30B0\u306B\u5408\u308F\u305B\u3066\u30D3\u30E9\u3092\u8F09\u305B\u308B\u97F3\u30B2\u30FC\u3084\u3063\u3066\u308B",
  "id" : 319617984534560768,
  "created_at" : "2013-04-04 01:10:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319470566803386369",
  "text" : "\u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 319470566803386369,
  "created_at" : "2013-04-03 15:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319470528547131393",
  "text" : "\u5FCD\u6BBA\uFF11\u30A8\u30D4\u30BD\u30FC\u30C9\u8AAD\u3093\u3067\u304B\u3089\u5BDD\u308B\u3068\u3044\u3046\u6700\u8FD1\u306E\u50BE\u5411",
  "id" : 319470528547131393,
  "created_at" : "2013-04-03 15:24:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319462042748723202",
  "geo" : { },
  "id_str" : "319469259451428866",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u5BDD\u574A\u3059\u308B\u4EBA\u304C\u3044\u308B\u3053\u3068\u3092\u8003\u3048\u308B\u3068\u305D\u3093\u306A\u306B\u3042\u3064\u307E\u3089\u306A\u3044\u304B\u3082\u3067\u3059\u304C5\uFF0C6\u4EBA\u306F\u3044\u308B\u306E\u3067\u306F[\u50D5\u306F\u3064\u3044\u3067\u306B\u81EA\u5206\u306E\u30B5\u30FC\u30AF\u30EB\u306E\u30D3\u30E9\u3092\u914D\u308A\u307E\u3059]",
  "id" : 319469259451428866,
  "in_reply_to_status_id" : 319462042748723202,
  "created_at" : "2013-04-03 15:19:41 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319461861173125121",
  "text" : "\u8CB4\u65B9\u306F\u795E\u3092\u4FE1\u3058\u307E\u3059\u304B\uFF1F\n\u30FB\u4FE1\u3058\u308B\n\u30FB\u4FE1\u3058\u306A\u3044\n\u30FB\u30E9\u30FC\u30E1\u30F3\u5C4B\u3067\u898B\u305F",
  "id" : 319461861173125121,
  "created_at" : "2013-04-03 14:50:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319461606876655617",
  "text" : "\u4E16\u754C\u306F\u672C\u5F53\u306B\u72ED\u3044\u5B9F\u969B\u72ED\u3044",
  "id" : 319461606876655617,
  "created_at" : "2013-04-03 14:49:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319461558302408705",
  "text" : "\u99D2\u5834\u306E\u795E\u30CA\u30E0\u30C1\u30E3\u30A4\u5E38\u9023\u3068\u304B\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u30DE\u30B8\u795E\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 319461558302408705,
  "created_at" : "2013-04-03 14:49:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319460521860558848",
  "text" : "\u307B\u3068\u3093\u3069\u4F55\u3082\u8A00\u3063\u3066\u306A\u3044\u8AAC\u5B9F\u969B\u6709\u529B",
  "id" : 319460521860558848,
  "created_at" : "2013-04-03 14:44:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319460375215083520",
  "text" : "s2swiki\u306B\u4E00\u5E74\u9045\u308C\u3066\u4E8B\u6545\u7D39\u4ECB\u66F8\u3044\u305F\u306A\uFF1F",
  "id" : 319460375215083520,
  "created_at" : "2013-04-03 14:44:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319311527800881153",
  "text" : "\"hogehoge\u306E\u6B74\u53F2\u3092\u611F\u3058\u308B\"\u306F\"\u793E\u4F1A\u3092\u611F\u3058\u308B\"\u6CE2\u306B\u4F7F\u3044\u3084\u3059\u3044",
  "id" : 319311527800881153,
  "created_at" : "2013-04-03 04:52:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319309572919656448",
  "text" : "\u6CE8\u6587\u3057\u3066\u306A\u3044\u30C1\u30FC\u30BA\u306E\u30C8\u30C3\u30D4\u30F3\u30B0\u304C\u631F\u307E\u3063\u3066\u308B\u3051\u3069\u3053\u308C\u306F\u30E9\u30C3\u30AD\u30FC\u306A\u306E\u304B\u306A\uFF1F",
  "id" : 319309572919656448,
  "created_at" : "2013-04-03 04:45:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319307896250843136",
  "text" : "\u304A\u7C73\u98DF\u3079\u305F\u3044\u306A\u30FC\u3068\u601D\u3063\u3066\u305F\u3089\u30B5\u30D6\u30A6\u30A7\u30A4\u304A\u6301\u3061\u5E30\u308A\u3057\u3066\u305F\u3057\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3084(^^)(^^)(^^)",
  "id" : 319307896250843136,
  "created_at" : "2013-04-03 04:38:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319290107851051008",
  "text" : "\u7A7A\u8179",
  "id" : 319290107851051008,
  "created_at" : "2013-04-03 03:27:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319289685216227328",
  "text" : "\u30AD\u30C1\u30AC\u30A4\u9854\u6587\u5B57\u7A0B\u5EA6\u3067\u8179\u304C\u7ACB\u3064\u3068\u304B\u5FC3\u304C\u72ED\u3044\u306E\u3067\u306F",
  "id" : 319289685216227328,
  "created_at" : "2013-04-03 03:26:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DE\u30AD\u30B4",
      "screen_name" : "_makigo_",
      "indices" : [ 3, 12 ],
      "id_str" : "1006902895",
      "id" : 1006902895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/3f26B8gRYs",
      "expanded_url" : "http:\/\/twitter.com\/to_ot___to_ot\/status\/319106919275057152\/photo\/1",
      "display_url" : "pic.twitter.com\/3f26B8gRYs"
    } ]
  },
  "geo" : { },
  "id_str" : "319289632376365056",
  "text" : "RT @_makigo_: \u304A\u3044\u304A\u307E\u3048\u3089\u30FB\u30FB\u30FB http:\/\/t.co\/3f26B8gRYs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/TheWorld_JP\" rel=\"nofollow\"\u003ETheWorld for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/3f26B8gRYs",
        "expanded_url" : "http:\/\/twitter.com\/to_ot___to_ot\/status\/319106919275057152\/photo\/1",
        "display_url" : "pic.twitter.com\/3f26B8gRYs"
      } ]
    },
    "geo" : { },
    "id_str" : "319280504996241408",
    "text" : "\u304A\u3044\u304A\u307E\u3048\u3089\u30FB\u30FB\u30FB http:\/\/t.co\/3f26B8gRYs",
    "id" : 319280504996241408,
    "created_at" : "2013-04-03 02:49:38 +0000",
    "user" : {
      "name" : "\u30DE\u30AD\u30B4",
      "screen_name" : "_makigo_",
      "protected" : false,
      "id_str" : "1006902895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416461932560785409\/mWWL_zR5_normal.jpeg",
      "id" : 1006902895,
      "verified" : false
    }
  },
  "id" : 319289632376365056,
  "created_at" : "2013-04-03 03:25:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319288137681625089",
  "text" : "\u51FA\u3001\u51FA\u301C\u3001\u56F3\u66F8\u9928\u3067\u4E88\u7D04\u3057\u3066\u305F\u672C\u306A\u304B\u306A\u304B\u8FD4\u3063\u3066\u6765\u306A\u3044\u304B\u3089\u4ED5\u65B9\u306A\u304F\u884C\u3063\u305F\u4E8B\u306A\u3044\u56F3\u66F8\u9928\u3067\u501F\u308A\u305F\u3051\u3069\u3001\u501F\u308A\u305F\u76F4\u5F8C\u306B\u4E88\u7D04\u3057\u3066\u305F\u672C\u78BA\u4FDD\u51FA\u6765\u307E\u3057\u305F\u30E1\u30FC\u30EB\u5974\u301C",
  "id" : 319288137681625089,
  "created_at" : "2013-04-03 03:19:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Acoustic Kitty",
      "screen_name" : "orangeninjin",
      "indices" : [ 0, 13 ],
      "id_str" : "100989370",
      "id" : 100989370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319287204679675905",
  "geo" : { },
  "id_str" : "319287575917494272",
  "in_reply_to_user_id" : 100989370,
  "text" : "@orangeninjin \u5B9F\u969B\u30D7\u30EC\u30C3\u30B7\u30E3\u30FC\u3059\u3054\u305D\u3046[\u5C0F\u4E26\u611F]",
  "id" : 319287575917494272,
  "in_reply_to_status_id" : 319287204679675905,
  "created_at" : "2013-04-03 03:17:44 +0000",
  "in_reply_to_screen_name" : "orangeninjin",
  "in_reply_to_user_id_str" : "100989370",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319286490087714816",
  "text" : "\u30DC\u30FC\u30EA\u30F3\u30B0\u3068\u304B\u30D3\u30EA\u30E4\u30FC\u30C9\u3068\u304B\u306E\u30D1\u30FC\u30D5\u30A7\u30AF\u30C8\u30B2\u30FC\u30E0\u3068\u306F\u683C\u304C\u9055\u3063\u305F\u3067\u3054\u3056\u308B",
  "id" : 319286490087714816,
  "created_at" : "2013-04-03 03:13:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319286323489951744",
  "text" : "\u307F\u3093\u306A\u304C\u308F\u304B\u3089\u3093\u307D\u3093\u306A\u79C1\u306B\u6559\u3048\u3066\u304F\u308C\u305F\u3051\u3069\u5B8C\u5168\u8A66\u5408\u304B\u306A\u308A\u51C4\u3044\u3089\u3057\u3044[\u30DC\u30AD\u30E3\u8CA7]",
  "id" : 319286323489951744,
  "created_at" : "2013-04-03 03:12:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319285920174047232",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u306E\u91CE\u7403\u308F\u304B\u3089\u306A\u3055\u304C\u5149\u308B",
  "id" : 319285920174047232,
  "created_at" : "2013-04-03 03:11:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Acoustic Kitty",
      "screen_name" : "orangeninjin",
      "indices" : [ 0, 13 ],
      "id_str" : "100989370",
      "id" : 100989370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319285613855645698",
  "geo" : { },
  "id_str" : "319285831321923584",
  "in_reply_to_user_id" : 100989370,
  "text" : "@orangeninjin \u307B\u3052\u30FC\u2026\u6848\u5916\u51C4\u3044",
  "id" : 319285831321923584,
  "in_reply_to_status_id" : 319285613855645698,
  "created_at" : "2013-04-03 03:10:48 +0000",
  "in_reply_to_screen_name" : "orangeninjin",
  "in_reply_to_user_id_str" : "100989370",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "indices" : [ 0, 10 ],
      "id_str" : "139971386",
      "id" : 139971386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319285223206567937",
  "geo" : { },
  "id_str" : "319285694705061888",
  "in_reply_to_user_id" : 139971386,
  "text" : "@pochipink \u601D\u3063\u305F\u3088\u308A(?)\u51C4\u3044\u3067\u3059\u306D\u2026",
  "id" : 319285694705061888,
  "in_reply_to_status_id" : 319285223206567937,
  "created_at" : "2013-04-03 03:10:16 +0000",
  "in_reply_to_screen_name" : "pochipink",
  "in_reply_to_user_id_str" : "139971386",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319284743764078593",
  "text" : "\u904E\u53BB\u306B\u5B8C\u5168\u8A66\u5408\u30DE\u30F3\u304C\u3069\u306E\u4F4D\u3044\u305F\u3093\u3060\u308D\uFF1F",
  "id" : 319284743764078593,
  "created_at" : "2013-04-03 03:06:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319284228355399680",
  "text" : "\u5B8C\u5168\u8A66\u5408\u304C\u51C4\u3044\u306E\u306F\u306A\u3093\u3068\u306A\u304F\u308F\u304B\u308B\u304C\u3069\u306E\u4F4D\u51C4\u3044\u306E\u304B\u308F\u304B\u3089\u306A\u3044\u30CA\u30FC",
  "id" : 319284228355399680,
  "created_at" : "2013-04-03 03:04:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319276848431366146",
  "text" : "\u30B5\u30C4\u30D0\u30C4\uFF01",
  "id" : 319276848431366146,
  "created_at" : "2013-04-03 02:35:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319276832518197248",
  "text" : "\u30AA\u30EA\u30A8\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u3068\u304B\"\u6A5F\u4F1A\"\u3067\u306F\u3042\u308B\u3051\u3069\u53CB\u9054\u3065\u304F\u308A\u3055\u305B\u3088\u3046\u3068\u5FC5\u6B7B\u306B\u306A\u308B\u611F\u3058\u306F\u3061\u3087\u3063\u3068\u9055\u3046\u3088\u3046\u306A",
  "id" : 319276832518197248,
  "created_at" : "2013-04-03 02:35:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319112150788493312",
  "text" : "\u6BD2\u98DF\u3046\u866B\u306F\u76BF\u3082\u5927\u597D\u304D",
  "id" : 319112150788493312,
  "created_at" : "2013-04-02 15:40:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/bfqspeXeFy",
      "expanded_url" : "http:\/\/d.hatena.ne.jp\/NinjaHeads\/08930110",
      "display_url" : "d.hatena.ne.jp\/NinjaHeads\/089\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319110405769265152",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u5B9F\u969B\u9762\u767D\u3044 \u63B2\u8F09\u9806Togetter\u307E\u3068\u3081 http:\/\/t.co\/bfqspeXeFy",
  "id" : 319110405769265152,
  "created_at" : "2013-04-02 15:33:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319107056596566017",
  "text" : "\u30D3\u30E9\u51FA\u6765\u305F\u3051\u3069\u3053\u308C\u5B9F\u969B\u30B9\u30B4\u30A4\u30C6\u30AD\u30C8\u30A6",
  "id" : 319107056596566017,
  "created_at" : "2013-04-02 15:20:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319090052326125568",
  "text" : "\u65B0\u6B53\u3063\u3066\u3093\u306A\u3089\u3044\u3064\u3067\u3082\u65B0\u5165\u751F\u6B53\u8FCE\u3057\u3066\u3044\u308B\u3057\u306A",
  "id" : 319090052326125568,
  "created_at" : "2013-04-02 14:12:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319089996743204864",
  "text" : "\u305D\u3082\u305D\u3082\u3046\u3061\u306E\u30B5\u30FC\u30AF\u30EB\uFF0C\u30A4\u30D9\u30F3\u30C8\u3084\u3089\u306A\u3044\u308F\uFF0C\u98F2\u307F\u4F1A\u3084\u3089\u306A\u3044\u308F\u3067\u65B0\u6B53\u3063\u307D\u3044\u3053\u3068\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u306E\u304B\u308F\u304B\u3089\u3093",
  "id" : 319089996743204864,
  "created_at" : "2013-04-02 14:12:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319089620711272450",
  "geo" : { },
  "id_str" : "319089757181341697",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305D\u3046\u3067\u3059\u30FC\uFF0E\u8FD1\u5834\u306B\u3042\u3063\u3066\u4F55\u3088\u308A\u306A\u306E\u3067\u3059\uFF0E",
  "id" : 319089757181341697,
  "in_reply_to_status_id" : 319089620711272450,
  "created_at" : "2013-04-02 14:11:41 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319089450124718080",
  "geo" : { },
  "id_str" : "319089500380860416",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30D3\u30EA\u30E4\u30FC\u30C9\u3057\u3066\u307E\u3059\u30FC",
  "id" : 319089500380860416,
  "in_reply_to_status_id" : 319089450124718080,
  "created_at" : "2013-04-02 14:10:39 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319089083072778242",
  "text" : "\u3055\u3066\u305D\u308D\u305D\u308D\u30B5\u30FC\u30AF\u30EB\u306E\u30D3\u30E9\u4F5C\u308B\u304B\uFF0E\uFF08\u9045\uFF09",
  "id" : 319089083072778242,
  "created_at" : "2013-04-02 14:09:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319056683777290240",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 319056683777290240,
  "created_at" : "2013-04-02 12:00:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/xA68a1LAbl",
      "expanded_url" : "http:\/\/4sq.com\/101fund",
      "display_url" : "4sq.com\/101fund"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "319004381842395136",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/xA68a1LAbl",
  "id" : 319004381842395136,
  "created_at" : "2013-04-02 08:32:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318908080647720960",
  "text" : "\u30CD\u30AE\u3081\u3093\u3064\u3086\u306ETKG\u98DF\u3079\u3088\u3046 [\u65E9\u3081\u306E\u304A\u663C\/\u9045\u3081\u306E\u3054\u98EF\u304A\u671D]",
  "id" : 318908080647720960,
  "created_at" : "2013-04-02 02:09:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318900442379722753",
  "text" : "\u6628\u65E5\u82B1\u7C89\u6D74\u3073\u3059\u304E\u305F\u53EF\u80FD\u6027\u3042\u308B\u306A",
  "id" : 318900442379722753,
  "created_at" : "2013-04-02 01:39:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318736223923494914",
  "text" : "\u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 318736223923494914,
  "created_at" : "2013-04-01 14:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318736167367503872",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u30A8\u3001\u30B7\u30F3\u30AC\u30C3\u30AD\uFF1F\uFF01\u30B7\u30F3\u30AC\u30C3\u30AD\u30CA\u30F3\u30C7\uFF01",
  "id" : 318736167367503872,
  "created_at" : "2013-04-01 14:46:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/4OLPIqBLpz",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=mathtext",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318721796717293569",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/4OLPIqBLpz",
  "id" : 318721796717293569,
  "created_at" : "2013-04-01 13:49:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308B\u30FC\u3069 \/ \u3055\u304F\u3089",
      "screen_name" : "qhulud",
      "indices" : [ 0, 7 ],
      "id_str" : "330356288",
      "id" : 330356288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318667983708897280",
  "geo" : { },
  "id_str" : "318668180274941952",
  "in_reply_to_user_id" : 330356288,
  "text" : "@qhulud \u6DF1\u3005\u7092\u308A\u3067\uFF01",
  "id" : 318668180274941952,
  "in_reply_to_status_id" : 318667983708897280,
  "created_at" : "2013-04-01 10:16:29 +0000",
  "in_reply_to_screen_name" : "qhulud",
  "in_reply_to_user_id_str" : "330356288",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/xToGU5hXqB",
      "expanded_url" : "http:\/\/4sq.com\/10gMtnk",
      "display_url" : "4sq.com\/10gMtnk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.026605, 135.76919 ]
  },
  "id_str" : "318665164637483008",
  "text" : "I'm at \u304B\u3064\u304B\u3064\u3068\u3093\u3068\u3093 (\u4EAC\u90FD\u5E02\u4E0A\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/xToGU5hXqB",
  "id" : 318665164637483008,
  "created_at" : "2013-04-01 10:04:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318529029386956800",
  "text" : "\u4FE1\u53F7\u5168\u8CA0\u3051\u3067\u3082\u5317\u90E8\u306A\u308910\u5206\u5F31\u3067\u7740\u304F\u306E\u304B\u3001\u899A\u3048\u305F",
  "id" : 318529029386956800,
  "created_at" : "2013-04-01 01:03:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318389322434895873",
  "text" : "\u3080\u308A\u306B \u3046\u305D\u3092\u3064\u304F \u3072\u3064\u3088\u3046\u306F \u306A\u3044\u3093\u3060\u3088",
  "id" : 318389322434895873,
  "created_at" : "2013-03-31 15:48:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318387366467358720",
  "text" : "[\u30D6\u30E9\u30B1\u30C3\u30C8\u306F\u5B9F\u969B\u4FBF\u5229]",
  "id" : 318387366467358720,
  "created_at" : "2013-03-31 15:40:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318387318312534016",
  "text" : "RT @t_uda: [\u4E45\u3005\u306B\u73FE\u308C\u3066\u30CD\u30BF\u30DD\u30B9\u30C8\u3057\u3066\u307F\u305F\u3089\u65E2\u306B\u898F\u5236\u3055\u308C\u3066\u3066\u898F\u5236\u57A2\u304B\u3089\u3075\u3041\u307C\u3063\u3066\u304F\u308B\u30AC\u30C1\u52E2\u306E\u7686\u69D8\u3053\u3093\u3070\u3093\u306F\u301C\u301C\u301C\u301C\uFF1F\uFF1F\uFF1F\uFF1F][\u305D\u3046\u3044\u3084\u5DF7\u306B\u306F\u5272\u3068\u672C\u6C17\u3067\u4EF6\u306E\u51A4\u7F6A\u4E8B\u4EF6\u306E\u72AF\u4EBA\u6C7A\u3081\u3064\u3051\u3066\u308B\u4EBA\u3068\u304B\u3044\u308B\u3089\u3057\u3044\u3063\u3059\u306D\u3002\u4FE1\u3058\u3089\u3093\u306A\u3044\u308F\u3002][\u3053\u3046\u3044\u3046\u6642\u306B\u5FC3\u306E\u58F0\u3092\u8A18\u8FF0\u3059\u308B\u30D6\u30E9\u30B1\u30C3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318386804103458816",
    "text" : "[\u4E45\u3005\u306B\u73FE\u308C\u3066\u30CD\u30BF\u30DD\u30B9\u30C8\u3057\u3066\u307F\u305F\u3089\u65E2\u306B\u898F\u5236\u3055\u308C\u3066\u3066\u898F\u5236\u57A2\u304B\u3089\u3075\u3041\u307C\u3063\u3066\u304F\u308B\u30AC\u30C1\u52E2\u306E\u7686\u69D8\u3053\u3093\u3070\u3093\u306F\u301C\u301C\u301C\u301C\uFF1F\uFF1F\uFF1F\uFF1F][\u305D\u3046\u3044\u3084\u5DF7\u306B\u306F\u5272\u3068\u672C\u6C17\u3067\u4EF6\u306E\u51A4\u7F6A\u4E8B\u4EF6\u306E\u72AF\u4EBA\u6C7A\u3081\u3064\u3051\u3066\u308B\u4EBA\u3068\u304B\u3044\u308B\u3089\u3057\u3044\u3063\u3059\u306D\u3002\u4FE1\u3058\u3089\u3093\u306A\u3044\u308F\u3002][\u3053\u3046\u3044\u3046\u6642\u306B\u5FC3\u306E\u58F0\u3092\u8A18\u8FF0\u3059\u308B\u30D6\u30E9\u30B1\u30C3\u30C8\u306F\u4FBF\u5229\u3067\u3042\u308B\u306A\u3041\u3068]",
    "id" : 318386804103458816,
    "created_at" : "2013-03-31 15:38:24 +0000",
    "user" : {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "protected" : false,
      "id_str" : "91551881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2672060221\/0f35a7ef7843ca03ed5048770fe5ecc4_normal.png",
      "id" : 91551881,
      "verified" : false
    }
  },
  "id" : 318387318312534016,
  "created_at" : "2013-03-31 15:40:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318386861359919105",
  "text" : "\u56DB\u6708\u99AC\u9E7F\u3068\u8A00\u3046\u3068\u30AD\u30C4\u304F\u97FF\u304F\u306A\uFF1F",
  "id" : 318386861359919105,
  "created_at" : "2013-03-31 15:38:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318386790518108160",
  "text" : "\u53BB\u5E74\u3082\u8A00\u3044\u307E\u3057\u305F\u304C\"\u3044\u3061\u3044\u3061\u300C\u3069\u3046\u305B\u30A8\u30A4\u30D7\u30EA\u30EB\u30D5\u30FC\u30EB\u3067\u3059\u304C\u300D\u3063\u3066\u3064\u3051\u3066\u558B\u308B\u3068\u5B9F\u306B\u9B31\u9676\u3057\u3044\" \u306E\u3067\u30AA\u30B9\u30B9\u30E1\u3067\u3059\n\u3069\u3046\u305B\u30A8\u30A4\u30D7\u30EA\u30EB\u30D5\u30FC\u30EB\u3067\u3059\u304C",
  "id" : 318386790518108160,
  "created_at" : "2013-03-31 15:38:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318381261536243715",
  "text" : "\u30A2\u30AB\u30A6\u30F3\u30C8\u5FAE\u5999\u306B\u9593\u9055\u3048(\u3066)\u307E\u3057\u305F",
  "id" : 318381261536243715,
  "created_at" : "2013-03-31 15:16:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]