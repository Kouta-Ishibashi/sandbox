Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340473838812950528",
  "text" : "\u5589\u3084\u3089\u80A9\u3084\u3089\u306E\u30CF\u30FC\u30C9\u30A6\u30A7\u30A2\u306E\u4E0D\u8ABF\u3088\u308A\u982D\u3068\u304B\u7CBE\u795E\u3068\u304B\u795E\u7D4C\u306E\u30BD\u30D5\u30C8\u30A6\u30A7\u30A2\u306E\u65B9\u304C\u5FC3\u914D\u5EA6\u306F\u9AD8\u3044\u6C17\u304C\u3057\u307E\u3059[\u3053\u306E\u4F8B\u3048\u306F\u9069\u5207\u306A\u306E\u304B\u77E5\u3089\u3093]",
  "id" : 340473838812950528,
  "created_at" : "2013-05-31 14:24:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340473138544525314",
  "geo" : { },
  "id_str" : "340473373748510721",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u307E\u3041\u74B0\u5883\u5909\u308F\u3063\u3066\u308B\u3057\u3001\u4F55\u304C\u8981\u56E0\u304B\u306F\u5206\u304B\u3089\u306A\u3044\u3051\u308C\u3069\u3001\u675E\u6182\u3068\u3044\u3046\u304B\u3001\u5927\u4E8B\u306A\u3044\u3068\u3044\u3044\u306D\u3002",
  "id" : 340473373748510721,
  "in_reply_to_status_id" : 340473138544525314,
  "created_at" : "2013-05-31 14:22:32 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340472592446144512",
  "text" : "\u3042\u30FC\u91CE\u7403\u3068\u304B\u30AC\u30F3\u30C0\u30E0\u306E\u4E2D\u8EAB\u304C\u3069\u3046\u3053\u3046\u3068\u3044\u3046\u8A71\u3067\u306F\u306A\u3044\u306E\u3067",
  "id" : 340472592446144512,
  "created_at" : "2013-05-31 14:19:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340472428734074881",
  "text" : "\u308F\u304B\u308A\u3084\u3059\u3044\u4F8B\u306F\u91CE\u7403\u3068\u304B\u30AC\u30F3\u30C0\u30E0\u306A[\u91CE\u7403\u3068\u304B\u30AC\u30F3\u30C0\u30E0\u306B\u4F8B\u3048\u3089\u308C\u3066\u3082\u308F\u304B\u3089\u3093\u307D\u3093]",
  "id" : 340472428734074881,
  "created_at" : "2013-05-31 14:18:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340472275373547520",
  "text" : "\u50D5\u3082\u305F\u307E\u306B\u3084\u308B\u3051\u308C\u3069\u3001\u76F8\u624B\u306E\u77E5\u8B58\u3092\u7121\u610F\u8B58\u306B\u4EEE\u5B9A\u3057\u3059\u304E\u308B\u306E\u306F\u826F\u304F\u306A\u3044[\u77E5\u8B58\u3068\u3044\u3046\u304B\u77E5\u3063\u3066\u3044\u308B\u3053\u3068]",
  "id" : 340472275373547520,
  "created_at" : "2013-05-31 14:18:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340471558797660161",
  "geo" : { },
  "id_str" : "340471851471998976",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3093\u30FC\u3001\u304A\u5927\u4E8B\u306B\u306A\u3055\u3063\u3066\u304F\u3060\u3055\u3044\u306A\u30FC",
  "id" : 340471851471998976,
  "in_reply_to_status_id" : 340471558797660161,
  "created_at" : "2013-05-31 14:16:29 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340471537767415809",
  "text" : "\u7D50\u5C40\u307E\u308C\u3044\u3093\u306F\u300C\u795E\u69D8\u304C\u5618\u3092\u3064\u304F\u300D\u3092\u8AAD\u3093\u3067\u3044\u308B\u306E\u304B\u554F\u984C",
  "id" : 340471537767415809,
  "created_at" : "2013-05-31 14:15:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340471318195625985",
  "geo" : { },
  "id_str" : "340471425452359681",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u308F\u304B\u3063\u305F\u3089\u6559\u3048\u3066\u307B\u3057\u2026",
  "id" : 340471425452359681,
  "in_reply_to_status_id" : 340471318195625985,
  "created_at" : "2013-05-31 14:14:48 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    }, {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 13, 22 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340470997490749440",
  "geo" : { },
  "id_str" : "340471124884332544",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella @iwa_bj21 \u30AD\u30C1\u30E7\u30CF\u30CA\u697D\u3057\u307F\u306B\u3057\u3066\u307E\u3059\u3057",
  "id" : 340471124884332544,
  "in_reply_to_status_id" : 340470997490749440,
  "created_at" : "2013-05-31 14:13:36 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0430\u043B\u044F White",
      "screen_name" : "getty_on_r318",
      "indices" : [ 0, 14 ],
      "id_str" : "2884913343",
      "id" : 2884913343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340470694875906050",
  "geo" : { },
  "id_str" : "340470881371443200",
  "in_reply_to_user_id" : 379262851,
  "text" : "@getty_on_r318 \u771F\u306E\u6DF1\u591C\u52E2\u306F2\u6642\u904E\u304E\u3066\u304B\u3089[\u3042\u304F\u307E\u3067\u3053\u3058\u3093\u306E\u306A\u3093\u3068\u304B]",
  "id" : 340470881371443200,
  "in_reply_to_status_id" : 340470694875906050,
  "created_at" : "2013-05-31 14:12:38 +0000",
  "in_reply_to_screen_name" : "komorin95",
  "in_reply_to_user_id_str" : "379262851",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340469597482385408",
  "text" : "\u5B9F\u969B\u6BCD\u89AA\u304C\u5DE6\u534A\u8EAB\u304C\u6020\u3044\u3063\u3066\u8A00\u3044\u51FA\u3057\u305F\u6642\u306F\u901F\u653B\u75C5\u9662\u9023\u308C\u3066\u3063\u3066\u6B63\u89E3\u3060\u3063\u305F\u3002[\u8133\u306B\u8EFD\u3044\u7AAE\u3055\u304F\u304C\u3042\u3063\u305F]",
  "id" : 340469597482385408,
  "created_at" : "2013-05-31 14:07:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340469222759096320",
  "text" : "\u65E5\u3005\u3044\u308D\u3093\u306A\u4EBA\u306B\u8A00\u3063\u3066\u308B\u3051\u3069\u4F53\u306E\u4E0D\u8ABF\u7D9A\u304F\u306A\u3089\u75C5\u9662\u8A00\u3063\u305F\u65B9\u304C\u3044\u3044\u3067\u3059\u3088\u3002\u4F55\u3082\u306A\u3044\u306A\u3089\u306A\u3044\u3067\u826F\u3044\u306E\u3067\u3059\u304B\u3089\u3002",
  "id" : 340469222759096320,
  "created_at" : "2013-05-31 14:06:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340467719478603776",
  "geo" : { },
  "id_str" : "340468122085646336",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu \u5FC3\u7642\u5185\u79D1\u3068\u304B\u795E\u7D4C\u79D1\u3058\u3083\u306A\u3044\u3060\u308D\u3046\u304B[\u8981\u51FA\u5178]",
  "id" : 340468122085646336,
  "in_reply_to_status_id" : 340467719478603776,
  "created_at" : "2013-05-31 14:01:40 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340467427999621120",
  "text" : "\u7406\u4E0D\u5C3D",
  "id" : 340467427999621120,
  "created_at" : "2013-05-31 13:58:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u306B\uFF08\u59B9\uFF09",
      "screen_name" : "funiimouto",
      "indices" : [ 3, 14 ],
      "id_str" : "292901585",
      "id" : 292901585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340467408080875520",
  "text" : "RT @funiimouto: \u50D5\u300CL\u30C1\u30AD\u4E0B\u3055\u3044wwwww\u300D\n\n\u30ED\u30FC\u30BD\u30F3\u5E97\u54E1\u300C\u3046\u308B\u305B\u3047\u6B7B\u306D\uFF01\uFF01\uFF01\uFF08\u8179\u30D1\u30F3\uFF09\u300D\n\n\u50D5\u300C\u3050\u308F\u3041\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\uFF01\uFF01\uFF01\uFF01\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/589lab.net\/works\/cerisier\/\" rel=\"nofollow\"\u003ECerisier\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340467368339841025",
    "text" : "\u50D5\u300CL\u30C1\u30AD\u4E0B\u3055\u3044wwwww\u300D\n\n\u30ED\u30FC\u30BD\u30F3\u5E97\u54E1\u300C\u3046\u308B\u305B\u3047\u6B7B\u306D\uFF01\uFF01\uFF01\uFF08\u8179\u30D1\u30F3\uFF09\u300D\n\n\u50D5\u300C\u3050\u308F\u3041\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\uFF01\uFF01\uFF01\uFF01\u300D",
    "id" : 340467368339841025,
    "created_at" : "2013-05-31 13:58:40 +0000",
    "user" : {
      "name" : "\u3075\u306B\uFF08\u59B9\uFF09",
      "screen_name" : "funiimouto",
      "protected" : false,
      "id_str" : "292901585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561846964774375424\/sAxenHIN_normal.jpeg",
      "id" : 292901585,
      "verified" : false
    }
  },
  "id" : 340467408080875520,
  "created_at" : "2013-05-31 13:58:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340466610911453186",
  "geo" : { },
  "id_str" : "340467156363931648",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu \u610F\u601D\u306B\u53CD\u3057\u3066\u6025\u306B\u7720\u3063\u305F\u308A\u3057\u306A\u304D\u3083\u9055\u3046\u3068\u601D\u3046[\u3068\u306F\u3044\u3048\u7D9A\u304F\u306A\u3089\u75C5\u9662\u3044\u304F\u3079\u3057]",
  "id" : 340467156363931648,
  "in_reply_to_status_id" : 340466610911453186,
  "created_at" : "2013-05-31 13:57:50 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/tk7vsL5Ba0",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=ahh_Jun",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340302420003405825",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/tk7vsL5Ba0",
  "id" : 340302420003405825,
  "created_at" : "2013-05-31 03:03:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340075531477331969",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 340075531477331969,
  "created_at" : "2013-05-30 12:01:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339942586108219392",
  "text" : "\u3042\u3042\u3042\u3042\u30FC\u30FC\u30FC\u30FC\u30FC\u308F\u30FC\u96E8\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC",
  "id" : 339942586108219392,
  "created_at" : "2013-05-30 03:13:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339778233123876865",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u304B\u3089\u3060\u304C\u3086\u3063\u304F\u308A\u304A\u3075\u308D\u306F\u3044\u308B\u304B\u2026",
  "id" : 339778233123876865,
  "created_at" : "2013-05-29 16:20:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339777832672710656",
  "text" : "\u30A8\u30F3\u30B8\u30F3\u97F3\u3068\u4F3C\u305F\u8DA3\u3092\u611F\u3058\u308B",
  "id" : 339777832672710656,
  "created_at" : "2013-05-29 16:18:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/sCfKZB5gKq",
      "expanded_url" : "http:\/\/twitpic.com\/cu394n",
      "display_url" : "twitpic.com\/cu394n"
    } ]
  },
  "geo" : { },
  "id_str" : "339777802180100096",
  "text" : "\u78BA\u304B\u306B\u300C\u306A\u3093\u3066\u4E16\u754C\u3060\u300D http:\/\/t.co\/sCfKZB5gKq",
  "id" : 339777802180100096,
  "created_at" : "2013-05-29 16:18:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339769563489124352",
  "geo" : { },
  "id_str" : "339777468745523201",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u80A9\u3053\u308A\u8D77\u56E0\u3060\u304B\u3089\u5927\u4E08\u592B\u3060\u305C\u30FC\u3001[\u982D\u75DB\u6FC0\u3057\u3044\u3063\u3066\u8A00\u308F\u306A\u3044\u304B]",
  "id" : 339777468745523201,
  "in_reply_to_status_id" : 339769563489124352,
  "created_at" : "2013-05-29 16:17:15 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339768900713594880",
  "text" : "\u982D\u75DB\u306F\u3052\u3057\u3059\u304E\u2026",
  "id" : 339768900713594880,
  "created_at" : "2013-05-29 15:43:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339632076305342464",
  "in_reply_to_user_id" : 1310287776,
  "text" : "@iclo_cl \u3053\u3044\u3057\u3061\u3083\u3093\u304C\u53EF\u611B\u3044\u3068\u304B[\u4ECA\u307E\u3067\u306E\u30AD\u30E3\u30E9\u306F\u3067\u306A\u3044\u3093\u3067\u3059\u304B\u306D\u30FC]",
  "id" : 339632076305342464,
  "created_at" : "2013-05-29 06:39:31 +0000",
  "in_reply_to_screen_name" : "1clo_cl",
  "in_reply_to_user_id_str" : "1310287776",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339631866099421184",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u53CD\u5247\u304C\u7A4D\u307F\u91CD\u306A\u308B\u3051\u3069\u306A",
  "id" : 339631866099421184,
  "created_at" : "2013-05-29 06:38:41 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339631756946837505",
  "in_reply_to_user_id" : 1310287776,
  "text" : "@iclo_cl \u3057\u3093\u304D\u308D\u3046\u3067\u3059\u304B",
  "id" : 339631756946837505,
  "created_at" : "2013-05-29 06:38:15 +0000",
  "in_reply_to_screen_name" : "1clo_cl",
  "in_reply_to_user_id_str" : "1310287776",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339631615552655360",
  "text" : "\u304A\u901A\u591C\u307F\u305F\u3044\u306A\u5408\u30B3\u30F3\u3084\u308A\u305F\u3044(?)",
  "id" : 339631615552655360,
  "created_at" : "2013-05-29 06:37:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339631296076722176",
  "text" : "\u76F8\u624B\u306E\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u5982\u4F55\u306B\u4F9D\u3089\u305A\u306B\u767A\u8A71\u3092\u7D9A\u3051\u308B\u7CBE\u795E\u529B\u3092\u935B\u3048\u308B\u30B2\u30FC\u30E0\u306B\u306A\u308A\u305D\u3046",
  "id" : 339631296076722176,
  "created_at" : "2013-05-29 06:36:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339631144091930624",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u307E\u3041\u76F8\u624B\u304C\u771F\u9854\u3067\u3082\u6C17\u306B\u305B\u305A\u8A71\u3057\u7D9A\u3051\u308C\u3070\u826F\u3044\u3067\u3059\u304B\u3089\u306D\uFF01",
  "id" : 339631144091930624,
  "created_at" : "2013-05-29 06:35:49 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339630645972185088",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \"\"\"\u76F8\u624B\u304C\u771F\u9854\u3060\u3063\u305F\u6642\u306E\u6050\u308D\u3057\u3055\"\"\"\u306A",
  "id" : 339630645972185088,
  "created_at" : "2013-05-29 06:33:50 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339630341021130752",
  "text" : "\uFF1F",
  "id" : 339630341021130752,
  "created_at" : "2013-05-29 06:32:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339630336294141952",
  "text" : "\u3068\u306F\u3044\u3048\u98F2\u307F\u306E\u5E2D\u305D\u306E\u3082\u306E\u306F\u4F59\u308A\u597D\u304D\u3067\u306A\u3044\u304B\u3089\u76DB\u308A\u4E0A\u304C\u308B\u5408\u30B3\u30F3\u306B\u306F\u884C\u304D\u305F\u304F\u306A\u3044(?)",
  "id" : 339630336294141952,
  "created_at" : "2013-05-29 06:32:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339630170371657728",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u666E\u6BB5\u3068\u5909\u308F\u3089\u305A\u3069\u3046\u3067\u3082\u826F\u3044\u8A71\u3092\u3057\u6563\u3089\u3059\u53EF\u80FD\u6027",
  "id" : 339630170371657728,
  "created_at" : "2013-05-29 06:31:57 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339629614710288384",
  "text" : "\u305D\u306E\u6280\u8853\u306F\u6C42\u3081\u3066\u306A\u3044\uFF01",
  "id" : 339629614710288384,
  "created_at" : "2013-05-29 06:29:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339629552756211712",
  "text" : "\u3048\u3093\u3069\u300C\u9AEA\u5207\u308A\u305F\u3044\u300D\n\u53CB\u4EBA\u300C\u306F\u3055\u307F\u304F\u3089\u3044\u5BB6\u306B\u3042\u308B\u3060\u308D\u300D\n\u3048\u3093\u3069\u300C\u3042\u308B\u7A0B\u5EA6\u6280\u8853\u304C\u3042\u308B\u4EBA\u306B\u5207\u3063\u3066\u3082\u3089\u3044\u305F\u3044\u300D\n\u53CB\u4EBA\u300C\u50D5\u3001\u30A8\u30FC\u30B9\u30B3\u30F3\u30D0\u30C3\u30C8\u5F97\u610F\u3060\u3088\uFF1F\u300D\n\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30A8\u30FC\u30B9\u30B3\u30F3\u30D0\u30C3\u30C8\u5F97\u610F\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y^Y^Y^Y^Y^Y\uFFE3",
  "id" : 339629552756211712,
  "created_at" : "2013-05-29 06:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339562328569823232",
  "text" : "\u6025\u306B\u8179\u75DB\u304C\u6765\u305F\u306E\u3067",
  "id" : 339562328569823232,
  "created_at" : "2013-05-29 02:02:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339428764884824064",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 339428764884824064,
  "created_at" : "2013-05-28 17:11:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339413328105463808",
  "text" : "\u91DD\u3068\u304B\u51FA\u305B\u307E\u305B\u3093\u3057",
  "id" : 339413328105463808,
  "created_at" : "2013-05-28 16:10:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339413229052784641",
  "text" : "\u9AEA\u9577\u3059\u304E\u3066\u5F8C\u8F29\u306B\u300C\u9B3C\u592A\u90CE\u307F\u305F\u3044\u300D\u3068\u307E\u3067\u8A00\u308F\u308C\u305F",
  "id" : 339413229052784641,
  "created_at" : "2013-05-28 16:09:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339397368032133120",
  "text" : "\u539F\u8AD6\u6587\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3059\u308C\u3070\u3044\u3044\u3068\u3044\u3046\u6C17\u3065\u304D",
  "id" : 339397368032133120,
  "created_at" : "2013-05-28 15:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339397234397429761",
  "text" : "\u7D19\u306E\u8AD6\u6587\u306F\u308F\u304B\u3089\u306A\u3044\u5358\u8A9E\u9577\u62BC\u3057\u3057\u3066\u3082\u8F9E\u66F8\u304C\u958B\u304B\u306A\u3044\u304B\u3089\u306A\u3041\u2026",
  "id" : 339397234397429761,
  "created_at" : "2013-05-28 15:06:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "qvus",
      "screen_name" : "qvus",
      "indices" : [ 0, 5 ],
      "id_str" : "1950684002",
      "id" : 1950684002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339396048315379712",
  "text" : "@qvus \u3044\u3064\u3082\u9069\u5F53\u306A\u3053\u3068\u3044\u3046\u5074\u306A\u306E\u3067\u65B0\u9BAE\u3067\u3057\u305F(?)",
  "id" : 339396048315379712,
  "created_at" : "2013-05-28 15:01:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "qvus",
      "screen_name" : "qvus",
      "indices" : [ 0, 5 ],
      "id_str" : "1950684002",
      "id" : 1950684002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339395604369252354",
  "text" : "@qvus \u306A\u308B\u307B\u3069\u3001\u3057\u304B\u3057\u4E00\u676F\u98DF\u308F\u3055\u308C\u307E\u3057\u305F\u306D[\u7121\u6559\u990A]",
  "id" : 339395604369252354,
  "created_at" : "2013-05-28 14:59:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "qvus",
      "screen_name" : "qvus",
      "indices" : [ 0, 5 ],
      "id_str" : "1950684002",
      "id" : 1950684002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339395016726306817",
  "text" : "@qvus \u3061\u308A\u3068\u3066\u3061\u3093 \u307F\u305F\u3044\u306A\u3082\u306E\u3067\u3059\u304B",
  "id" : 339395016726306817,
  "created_at" : "2013-05-28 14:57:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "qvus",
      "screen_name" : "qvus",
      "indices" : [ 0, 5 ],
      "id_str" : "1950684002",
      "id" : 1950684002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339394780276592640",
  "text" : "@qvus \u8150\u3063\u305F\u9BDB\u3092\u4F7F\u3046\u3082\u306E\u3067\u306F\u306A\u304F\u3066\u9BDB\u3092\u8150\u3089\u305B\u308B\u3082\u306E\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u30FC",
  "id" : 339394780276592640,
  "created_at" : "2013-05-28 14:56:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339394370409205760",
  "text" : "\u8150\u3063\u3066\u3082\u9BDB\u3060\u304C\u8150\u3063\u305F\u9BDB\u304C\u4F55\u306B\u4F7F\u3048\u308B\u306E\u3060\u308D\u3046\u304B(\u3044\u3084\u3001\u4F55\u306B\u3082\u4F7F\u3048\u306A\u3044)",
  "id" : 339394370409205760,
  "created_at" : "2013-05-28 14:54:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339393912546422784",
  "geo" : { },
  "id_str" : "339394093694205952",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u8150\u308B\u7A0B\u3042\u3063\u305F\u306E\u3067\u3059\u304C\u8150\u308B\u7A0B\u3042\u3063\u305F\u306E\u3067\u8150\u3063\u3066\u3057\u307E\u3044\u307E\u3057\u305F",
  "id" : 339394093694205952,
  "in_reply_to_status_id" : 339393912546422784,
  "created_at" : "2013-05-28 14:53:52 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339393772477624321",
  "geo" : { },
  "id_str" : "339393848851718144",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u30A2\u30C3\u30CF\u30A4",
  "id" : 339393848851718144,
  "in_reply_to_status_id" : 339393772477624321,
  "created_at" : "2013-05-28 14:52:53 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339393794111844352",
  "text" : "\u30D1\u30D5\u30A7\u306F\u306A\u3044\u3051\u3069\u304A\u9152\u306A\u3089\u3061\u3087\u3063\u3068\u3060\u3051",
  "id" : 339393794111844352,
  "created_at" : "2013-05-28 14:52:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339393510295867393",
  "geo" : { },
  "id_str" : "339393707646275584",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3048\u3063\u3048\u3063",
  "id" : 339393707646275584,
  "in_reply_to_status_id" : 339393510295867393,
  "created_at" : "2013-05-28 14:52:20 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339393433007452160",
  "geo" : { },
  "id_str" : "339393627497328640",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u307E\u3041\u53D7\u304B\u3063\u305F\u672B\u306B\u59CB\u3081\u3055\u305B\u305F\u3089\u30A2\u30AB\u30A6\u30F3\u30C8\u5BA3\u4F1D\u3057\u305F\u3089\u3044\u3044",
  "id" : 339393627497328640,
  "in_reply_to_status_id" : 339393433007452160,
  "created_at" : "2013-05-28 14:52:01 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339393331832426497",
  "text" : "\u306D\u3053\u3063\u304B\u308F\u3044\u304C\u308A",
  "id" : 339393331832426497,
  "created_at" : "2013-05-28 14:50:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339393274311741440",
  "text" : "\u75C5\u3093\u3067\u306A\u3044\u3051\u3069\u30A2\u30CB\u30DE\u30EB\u30BB\u30E9\u30D4\u30FC\u53D7\u3051\u305F\u3044",
  "id" : 339393274311741440,
  "created_at" : "2013-05-28 14:50:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339392782919684096",
  "geo" : { },
  "id_str" : "339392862645018624",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3084\u3089\u305B\u306A\u304F\u3066\u3088\u3057\u306A\u306E\u3067\u306F",
  "id" : 339392862645018624,
  "in_reply_to_status_id" : 339392782919684096,
  "created_at" : "2013-05-28 14:48:58 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339390030504153088",
  "text" : "\u30AA\u30CF\u30AE\u4E2D\u6BD2\u306E\u53EF\u80FD\u6027",
  "id" : 339390030504153088,
  "created_at" : "2013-05-28 14:37:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339389922966380544",
  "text" : "\u7518\u3044\u3082\u306E\u3001\u7279\u306B\u3042\u3093\u3053\u6B32\u304C",
  "id" : 339389922966380544,
  "created_at" : "2013-05-28 14:37:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5F53\u305F\u308A\u524D\u306E\u4E8B\u3092\u540D\u8A00\u3063\u307D\u304F\u8A00\u3063\u305F\u5974\u304C\u512A\u52DD",
      "indices" : [ 30, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339389466626117632",
  "text" : "\u300C\u304A\u524D\u304C\u93E1\u3092\u8997\u304D\u8FBC\u3080\u6642\u3001\u304A\u524D\u3082\u307E\u305F\u93E1\u3092\u8997\u304D\u8FBC\u3093\u3067\u3044\u308B\u306E\u3060\u300D #\u5F53\u305F\u308A\u524D\u306E\u4E8B\u3092\u540D\u8A00\u3063\u307D\u304F\u8A00\u3063\u305F\u5974\u304C\u512A\u52DD",
  "id" : 339389466626117632,
  "created_at" : "2013-05-28 14:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339387447496564740",
  "text" : "\u97F3\u30B2\u30FC\u3067\u601D\u3044\u51FA\u3059\u306E\u3082\u3069\u3046\u306A\u3093\u3060\u308D\u3046\u306A",
  "id" : 339387447496564740,
  "created_at" : "2013-05-28 14:27:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339387389971689472",
  "text" : "\u97F3\u30B2\u30FC\u3067\u601D\u3044\u51FA\u3057\u305F\u304C\u3042\u3093\u307F\u3064\u51B7\u3084\u3057\u3066\u305F\u3093\u3060\u3063\u305F",
  "id" : 339387389971689472,
  "created_at" : "2013-05-28 14:27:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yPXgQte7v4",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/kyoto.html",
      "display_url" : "sx9.jp\/weather\/kyoto.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339367957715099648",
  "text" : "http:\/\/t.co\/yPXgQte7v4 \u3084\u3093\u3067\u308B",
  "id" : 339367957715099648,
  "created_at" : "2013-05-28 13:10:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339350405089751040",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 339350405089751040,
  "created_at" : "2013-05-28 12:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339295217297526784",
  "text" : "\u30CF\u30C8\u30E0\u30AE\u3060\u3063\u305F\u306A\uFF1F",
  "id" : 339295217297526784,
  "created_at" : "2013-05-28 08:20:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339292977052667904",
  "text" : "\u307E\u3041\u30C6\u30F3\u30D7\u30EC\u3063\u3059\u306D",
  "id" : 339292977052667904,
  "created_at" : "2013-05-28 08:12:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/xw9WpFqqLV",
      "expanded_url" : "http:\/\/twitpic.com\/ctrvka",
      "display_url" : "twitpic.com\/ctrvka"
    } ]
  },
  "geo" : { },
  "id_str" : "339292916050714624",
  "text" : "\u5927\u9EA6\u7384\u7C73\u8336\u6708\u898B\u8349\u30FC\u266A\n\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u7DBE\u9DF9\u3000\uFF1C\n\uFFE3Y^Y^Y\uFFE3 http:\/\/t.co\/xw9WpFqqLV",
  "id" : 339292916050714624,
  "created_at" : "2013-05-28 08:11:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/kTXZpvKkLb",
      "expanded_url" : "http:\/\/4sq.com\/13eOuRg",
      "display_url" : "4sq.com\/13eOuRg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "339292465079148544",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/kTXZpvKkLb",
  "id" : 339292465079148544,
  "created_at" : "2013-05-28 08:10:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339262811668635648",
  "text" : "pdf\u3067\u4F55\u304C\u554F\u984C\u306A\u306E\u304B\u77E5\u308A\u305F\u3044\u306A\u30FC",
  "id" : 339262811668635648,
  "created_at" : "2013-05-28 06:12:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339225338078965760",
  "text" : "\u304A\u306A\u304B\u3078\u3063\u305F\u304A\u306A\u304B\u3078\u3063\u305F",
  "id" : 339225338078965760,
  "created_at" : "2013-05-28 03:43:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339216689638043649",
  "text" : "\u751F\u6D3B\u30EA\u30BA\u30E0\u6539\u5584\u30011\u65E5\u3067\u5D29\u308C\u305F",
  "id" : 339216689638043649,
  "created_at" : "2013-05-28 03:08:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339215679431507969",
  "text" : "\u4E8C\u5EA6\u5BDD\u3057\u305F\u30894\u6642\u9593\u307B\u3069\u306A\u304B\u3063\u305F\u3053\u3068\u306B\u306A\u3063\u305F\u6642\u306E\u9854",
  "id" : 339215679431507969,
  "created_at" : "2013-05-28 03:04:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339048419794501632",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 339048419794501632,
  "created_at" : "2013-05-27 16:00:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339040105652170752",
  "text" : "\u306B\u3068\u308A\u3082\u3067\u308B\u306E\u304B",
  "id" : 339040105652170752,
  "created_at" : "2013-05-27 15:27:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339039812759732224",
  "text" : "\u6771\u65B9\u3001\u5168\u304F\u60C5\u5831\u4ED5\u5165\u308C\u3066\u306A\u3044\u3051\u3069\u3057\u3093\u304D\u308D\u3046\u306B\u3053\u3044\u3057\u3061\u3083\u3093\u304C\u53C2\u6226\u3059\u308B\u3093\u3067\u3059\u306D\u30FC",
  "id" : 339039812759732224,
  "created_at" : "2013-05-27 15:26:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3042\u308A\u3092\u308A\u306F\u3079\u308A\u3044\u307E\u30EF\u30D8\u30A4\u30D8\u30A4",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339038746899017728",
  "text" : "#\u3042\u308A\u3092\u308A\u306F\u3079\u308A\u3044\u307E\u30EF\u30D8\u30A4\u30D8\u30A4",
  "id" : 339038746899017728,
  "created_at" : "2013-05-27 15:21:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339038583824457728",
  "text" : "17\u6642\u3059\u304E\u306B\u304A\u5915\u98EF\u306B\u3042\u305F\u308B\u3082\u306E\u3092\u98DF\u3079\u305F\u306E\u3067\u5730\u7344\u3081\u3044\u305F\u7A7A\u8179\u611F\u304C\u30A8\u30F3\u30C9=\u30B5\u30F3\u3092\u8972\u3046\uFF01\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D",
  "id" : 339038583824457728,
  "created_at" : "2013-05-27 15:21:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339038069963501568",
  "text" : "\u3068\u3001\u300C\u795E\u69D8\u304C\u5618\u3092\u3064\u304F\u300D\u3092\u8AAD\u3093\u3067\u3044\u3066\u601D\u3063\u305F",
  "id" : 339038069963501568,
  "created_at" : "2013-05-27 15:19:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339037849645113345",
  "text" : "\u5B50\u4F9B\u3068\u304B\u52D5\u7269\u306E\u63CF\u5199\u304C\u4E0A\u624B\u306A\u4F5C\u54C1\u306F\u826F\u3044\u4F5C\u54C1\u3001\u3068\u3044\u3046\u6307\u6A19(\u6CD5\u5247\u3067\u306A\u304F)\u306E\u53CD\u4F8B\u3092\u63A2\u3057\u3066\u3044\u308B",
  "id" : 339037849645113345,
  "created_at" : "2013-05-27 15:18:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339037429333897217",
  "text" : "\u30D5\u30A9\u30F3\u30CE\u30A4\u30DE\u30F3\u306E\"\u30D5\u30A9\u30F3\u30CE\u30A4\"\u3063\u3066\u4F55\uFF1F",
  "id" : 339037429333897217,
  "created_at" : "2013-05-27 15:16:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338993012040421376",
  "geo" : { },
  "id_str" : "339036465768062976",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u306F\u3044\u3001\u307E\u3041\u6975\u7AEF\u306A(?)\u4F8B\u3067\u3057\u305F",
  "id" : 339036465768062976,
  "in_reply_to_status_id" : 338993012040421376,
  "created_at" : "2013-05-27 15:12:47 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338992531884871681",
  "text" : "\u304B\u305F\u3044\u305F\u3044 \u3042\u3041\u30DF\u30BC\u30E9\u30D6\u30EB \u304B\u305F\u3044\u305F\u3044",
  "id" : 338992531884871681,
  "created_at" : "2013-05-27 12:18:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338991850826375170",
  "text" : "\u306A\u3093\u3067\u3082\u3044\u3044\u3058\u3083\u3093\u306D\u3001\u3082\u3046\u3002\u9577\u3081\u306E\u6587\u7AE0\u306A\u3089\u3002",
  "id" : 338991850826375170,
  "created_at" : "2013-05-27 12:15:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EAC\u5927\u82F1\u4F5C\u6587",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338991727320899584",
  "text" : "\u6C17\u52E2\u3068\u3068\u3082\u306B\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u306E\u53F3\u8155\u304C\u30E0\u30C1\u306E\u3088\u3046\u306B\u3057\u306A\u308A\u3001\u76EE\u306B\u3082\u6B62\u307E\u3089\u306C\u901F\u5EA6\u3067\uFF12\u679A\u306E\u30B9\u30EA\u30B1\u30F3\u304C\u5C04\u51FA\u3055\u308C\u305F\u3002 \n\u300C\u30A4\u30E4\u30FC\u30C3\uFF01\u300D \n\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D  #\u4EAC\u5927\u82F1\u4F5C\u6587",
  "id" : 338991727320899584,
  "created_at" : "2013-05-27 12:15:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338989141989683200",
  "text" : "\u3055\u3066\u3001\u3069\u3046\u3057\u305F\u3044\u3093\u3060",
  "id" : 338989141989683200,
  "created_at" : "2013-05-27 12:04:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338983319876280320",
  "text" : "\u76EE\u75DB\u3081\u3044\u305F",
  "id" : 338983319876280320,
  "created_at" : "2013-05-27 11:41:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338961717549748224",
  "text" : "\u8AB0\u304C\u300C\u795E\u69D8\u304C\u3046\u305D\u3092\u3064\u304F\u300D\u8AAD\u3093\u3067\u308B\u4EBA\u3044\u307E\u305B\u3093\u304B\u306D",
  "id" : 338961717549748224,
  "created_at" : "2013-05-27 10:15:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338960404061495296",
  "text" : "\u3042\u30FC\u3001\u4F8B\u4F1A\u3001\u305D\u3046\u8A00\u3046\u306E\u3082\u3042\u3063\u305F\u306A",
  "id" : 338960404061495296,
  "created_at" : "2013-05-27 10:10:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nicovideo.jp\/\" rel=\"nofollow\"\u003Eniconico \u30CB\u30B3\u30EC\u30DD\u9023\u643A\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sm16161443",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/32rWFm4ut4",
      "expanded_url" : "http:\/\/nico.ms\/sm16161443",
      "display_url" : "nico.ms\/sm16161443"
    } ]
  },
  "geo" : { },
  "id_str" : "338950362121785344",
  "text" : "[My List] FF7\u3000\u6226\u95D8BGM\u3000\u300C\u66F4\u306B\u95D8\u3046\u8005\u9054\u300D\u3000\u306B\u6B4C\u8A5E\u3092\u4ED8\u3051\u3066\u6B4C\u3063\u3066\u307F\u305F http:\/\/t.co\/32rWFm4ut4 #sm16161443",
  "id" : 338950362121785344,
  "created_at" : "2013-05-27 09:30:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338939455694069760",
  "text" : "\u305D\u308C\u306A",
  "id" : 338939455694069760,
  "created_at" : "2013-05-27 08:47:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3084\u3075\u307F",
      "screen_name" : "ayafmy",
      "indices" : [ 3, 10 ],
      "id_str" : "84863232",
      "id" : 84863232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338939429207023616",
  "text" : "RT @ayafmy: Word\u3064\u304B\u3046\u306A\u3089LaTeX\u3064\u304B\u304A\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338939372940431360",
    "text" : "Word\u3064\u304B\u3046\u306A\u3089LaTeX\u3064\u304B\u304A\u3046",
    "id" : 338939372940431360,
    "created_at" : "2013-05-27 08:46:58 +0000",
    "user" : {
      "name" : "\u3042\u3084\u3075\u307F",
      "screen_name" : "ayafmy",
      "protected" : false,
      "id_str" : "84863232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599119928361226241\/iesRd57I_normal.jpg",
      "id" : 84863232,
      "verified" : false
    }
  },
  "id" : 338939429207023616,
  "created_at" : "2013-05-27 08:47:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338857133888139265",
  "text" : "goonew\u3068\u304B\u3044\u3046\u8B0E\u98F2\u307F\u7269\u304A\u3044\u3057\u3044",
  "id" : 338857133888139265,
  "created_at" : "2013-05-27 03:20:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3046\u3057\u3046\u3057\u306F\u3059\u3054\u3044",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338824641575546880",
  "text" : "#\u3046\u3057\u3046\u3057\u306F\u3059\u3054\u3044",
  "id" : 338824641575546880,
  "created_at" : "2013-05-27 01:11:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338800234794741760",
  "text" : "\u3042\u30681\u30DA\u30FC\u30B8\u5206\u3067\u96C6\u4E2D\u529B\u304C\u5207\u308C\u305F\u306A\u30FC",
  "id" : 338800234794741760,
  "created_at" : "2013-05-26 23:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338781619806691329",
  "text" : "7\u6642\u306B\u8D77\u304D\u308B\u3068\u307B\u3089\uFF0C\u5348\u524D\u306F\u3053\u3093\u306A\u306B\u3082\u9577\u3044\u3093\u3060\u305C[\u666E\u6BB5\u306E\u751F\u6D3B\u30EA\u30BA\u30E0\u3067\u306F\u6B7B\u306B\u81F3\u308B\u8A00\u660E\u306A]",
  "id" : 338781619806691329,
  "created_at" : "2013-05-26 22:20:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338781079274156032",
  "text" : "ang-pang\u3068\u51B7\u3048\u305F\u30B3\u30FC\u30D2\u30FC[\u98A8\u5473\u306F\u52A3\u308A\u307E\u3059]",
  "id" : 338781079274156032,
  "created_at" : "2013-05-26 22:17:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338779914264256512",
  "text" : "\u3053\u3093\u306A\u3053\u3068\u3082\u3042\u308D\u3046\u304B\u3068\u3001\"\"\"\"\u3053\u3057\u3042\u3093\u3071\u3093\"\"\"\"\u3092\u8CB7\u3063\u3066\u3042\u308B",
  "id" : 338779914264256512,
  "created_at" : "2013-05-26 22:13:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338776681386999808",
  "text" : "\u30EA\u30B6\u30D9\u30FC\u30B7\u30E7\u30F3 \u9054\u6210(\u30AF\u30EA\u30A2)!![\u8D77\u304D\u305F]",
  "id" : 338776681386999808,
  "created_at" : "2013-05-26 22:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338636576911421440",
  "text" : "\u30AA\u30E4\u30B9\u30DF\uFF01\uFF01",
  "id" : 338636576911421440,
  "created_at" : "2013-05-26 12:43:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338636325693579264",
  "text" : "\u982D\u60AA\u3044\u4E0A\u306B\u4F1D\u308F\u308A\u306B\u304F\u3044",
  "id" : 338636325693579264,
  "created_at" : "2013-05-26 12:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u307F\u3085",
      "screen_name" : "kamyuri96",
      "indices" : [ 14, 24 ],
      "id_str" : "311187890",
      "id" : 311187890
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 46, 56 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338636147838291969",
  "text" : "3\u9650\u304F\u3089\u3044\u304F\u308C\u3066\u3084\u308B RT @kamyuri96: 14\u6642\u306B\u8D77\u304D\u308B\u3093\u3067\u3059\u306D\u308F\u304B\u308A\u307E\u3059 RT @end313124 \u30EA\u30B6\u30D9\u30FC\u30B7\u30E7\u30F3 \u4E03\u6642(\u30BB\u30D6\u30F3)\u2026!![\u76EE\u899A\u307E\u3057\u30927\u6642\u306B\u30BB\u30C3\u30C8\u3057\u306A\u304C\u3089]",
  "id" : 338636147838291969,
  "created_at" : "2013-05-26 12:42:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338636020297916417",
  "text" : "\u3053\u308C\u8D77\u304D\u3066\u300C\u30EA\u30B6\u30D9\u30FC\u30B7\u30E7\u30F3\u9054\u6210(\u30AF\u30EA\u30A2)\u300D\u3063\u3066\u545F\u3044\u3066\u4E8C\u5EA6\u5BDD\u3059\u308B\u3084\u3064\u3067\u306F",
  "id" : 338636020297916417,
  "created_at" : "2013-05-26 12:41:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338635839947022336",
  "text" : "\u30EA\u30B6\u30D9\u30FC\u30B7\u30E7\u30F3 \u4E03\u6642(\u30BB\u30D6\u30F3)\u2026!![\u76EE\u899A\u307E\u3057\u30927\u6642\u306B\u30BB\u30C3\u30C8\u3057\u306A\u304C\u3089]",
  "id" : 338635839947022336,
  "created_at" : "2013-05-26 12:40:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338635277830610945",
  "text" : "\u3064\u307E\u308A\u5BDD\u308B",
  "id" : 338635277830610945,
  "created_at" : "2013-05-26 12:38:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338635263045685248",
  "text" : "\u751F\u6D3B\u30EA\u30BA\u30E0\u6539\u5584\u306E\u76EE\u6A19\u306E\u5143\u3001\u751F\u6D3B\u30EA\u30BA\u30E0\u3092\u6539\u5584\u3059\u308B",
  "id" : 338635263045685248,
  "created_at" : "2013-05-26 12:38:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338626047249625088",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 338626047249625088,
  "created_at" : "2013-05-26 12:01:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338604789485146112",
  "text" : "20\u6642\u307E\u3067\u306E\u4E88\u5B9A\u3060\u304C\u30AD\u30EA\u304C\u3088\u3044\u304B\u3089\u30AD\u30EA\u3042\u3052\u3088\u3046",
  "id" : 338604789485146112,
  "created_at" : "2013-05-26 10:37:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338602823371599872",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u30DE\u30B7\u30E5\u30DE\u30ED\u306E\u65B9\u304C\u597D\u304D\u306A\u3093\u3060\u3051\u3069",
  "id" : 338602823371599872,
  "created_at" : "2013-05-26 10:29:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338602785840967681",
  "text" : "\u305D\u3046\u3044\u3048\u3070joy\u306B\u767D\u91D1\u30C7\u30A3\u30B9\u30B3\u5165\u3063\u3066\u305F\u3051\u3069\u30DE\u30B7\u30E5\u30DE\u30EDJustice\u5165\u3063\u3066\u306A\u304F\u3066\u706B\u6190\u3061\u3083\u3093\u304B\u308F\u3044\u305D\u3046",
  "id" : 338602785840967681,
  "created_at" : "2013-05-26 10:29:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338594389993607170",
  "text" : "\u7A81\u7136\u717D\u308B",
  "id" : 338594389993607170,
  "created_at" : "2013-05-26 09:56:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338594330820366336",
  "text" : "@koketomi \u304A\u524D\u306E\u982D\u306E\u4E2D\u3082\u306A(^^)(^^)(^^)",
  "id" : 338594330820366336,
  "created_at" : "2013-05-26 09:55:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338593082964594688",
  "text" : "\u7D50\u69CB\u5589\u4E7E\u304F",
  "id" : 338593082964594688,
  "created_at" : "2013-05-26 09:50:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338593055026335744",
  "text" : "\u30D5\u30E9\u30F3\u30B9\u30D1\u30F3\u3082\u3050\u3082\u3050",
  "id" : 338593055026335744,
  "created_at" : "2013-05-26 09:50:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338580435900719105",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 338580435900719105,
  "created_at" : "2013-05-26 09:00:41 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338564144737423361",
  "text" : "\u5BC6\u5EA6\u306E\u9AD8\u3044\u5165\u6D74\u3067\u3042\u3063\u305F\uFF0E\u3042\u3064\u3044\uFF0E",
  "id" : 338564144737423361,
  "created_at" : "2013-05-26 07:55:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338542530838814720",
  "text" : "\u3084\u3051\u3069\u304C\u6C17\u306B\u306A\u308B\u304C\u304A\u3075\u308D\u5C4B\u3055\u3093\u3044\u304F\u307E\u3059",
  "id" : 338542530838814720,
  "created_at" : "2013-05-26 06:30:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338520360100171777",
  "text" : "\u76EE\u304C\u899A\u3081\u305F \u30A2\u30A4\u30B9\u98DF\u3079\u305F\u3044 \u30A4\u30F3\u30AC\u30AA\u30DB\u30FC",
  "id" : 338520360100171777,
  "created_at" : "2013-05-26 05:01:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338518343571095552",
  "text" : "\u3051\u3051\u3051\u7D50\u5C40\u307B\u307C14\u6B21(^^)(^^)(^^)",
  "id" : 338518343571095552,
  "created_at" : "2013-05-26 04:53:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338454147693170688",
  "text" : "\u30CA\u30E0\u30A2\u30DF\u30C0\u30D6\u30C4\uFF0113\u6642\u306B\u8D77\u304D\u308B\u663C\u5BDD\u3081\u3044\u305F\u5371\u967A\u884C\u70BA\uFF01\u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 338454147693170688,
  "created_at" : "2013-05-26 00:38:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 0, 7 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338419379723186178",
  "geo" : { },
  "id_str" : "338453415854215168",
  "in_reply_to_user_id" : 129796835,
  "text" : "@7M1IHN \u305F\u3076\u3093\u3082\u3068\u3082\u3068\u304B\u306A\u308A\u8EFD\u5EA6\u306A\u306E\u3067\u5927\u4E08\u592B\u3067\u3059\u3002\u30D2\u30EA\u30D2\u30EA\u306F\u304A\u3055\u307E\u308A\u307E\u3057\u305F\u304C\u89E6\u3063\u305F\u308A\u64E6\u308C\u305F\u308A\u3059\u308B\u3068\u75DB\u3044\u3067\u3059\u3002",
  "id" : 338453415854215168,
  "in_reply_to_status_id" : 338419379723186178,
  "created_at" : "2013-05-26 00:35:57 +0000",
  "in_reply_to_screen_name" : "7M1IHN",
  "in_reply_to_user_id_str" : "129796835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338452999519232000",
  "text" : "\u304A\u9152\u306F\u597D\u304D\u3060\u3051\u3069\u304A\u9152\u306E\u5E2D\u306F\u5ACC\u3044\u306A\u3093\u3060\u306A\u305F\u3076\u3093",
  "id" : 338452999519232000,
  "created_at" : "2013-05-26 00:34:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338452920959897601",
  "text" : "\u300C\u4E7E\u676F\uFF01\u300D\u3068\u304B\u8A00\u308F\u308C\u3066\u30A2\u30EB\u30CF\u30E9\u3081\u3044\u305F\u3053\u3068\u3055\u308C\u305F\u3089\u3001\u643A\u5E2F\u3068\u304B\u8377\u7269\u3068\u304B\u9000\u907F\u3055\u305B\u305F\u4E0A\u3067\u305D\u306E\u4EBA\u306B\u6CE8\u304C\u308C\u305F\u304A\u9152\u304B\u3051\u3066\u300C\u3042\u306A\u305F\u306F\u3068\u3082\u304B\u304F\u3053\u308C\u3067\u676F\u306F\u4E7E\u304D\u307E\u3057\u305F\u306D\u300D\u3068\u304B\u8A00\u3046\u5371\u967A\u304C\u3042\u308B",
  "id" : 338452920959897601,
  "created_at" : "2013-05-26 00:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338450571990298625",
  "text" : "\u9B31\u9676\u3057\u3044\u3060\u3051\u3067\u4ED6\u306B\u5BB3\u306F\u306A\u3044\u306F\u305A\u3067\u3059[\u9B31\u9676\u3057\u3044\u306E\u306F\u5BB3\u3067\u3059\u306D]",
  "id" : 338450571990298625,
  "created_at" : "2013-05-26 00:24:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338450407514832896",
  "text" : "\u79C1\u30EC\u30D9\u30EB\u306E\u8A00\u8449\u9063\u3044\u306B\u306A\u308B\u3068\u76F8\u624B\u304C\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u305B\u305A\u3068\u3082\u4F1A\u8A71\u304C\u7D9A\u304F[\u5384\u4ECB]",
  "id" : 338450407514832896,
  "created_at" : "2013-05-26 00:23:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338450260189929472",
  "text" : "\"\u4E2D\u8EAB\u306E\u306A\u3044\u8A00\u8449\u9063\u3044\"\u3092\u81EA\u79F0\u3057\u3066\u3082\u3044\u3044\u3068\u601D\u3046\u30EC\u30D9\u30EB\u3067\u6700\u8FD1\u306F\u4E2D\u8EAB\u306E\u306A\u3044\u4F1A\u8A71\u304C\u6357\u308B",
  "id" : 338450260189929472,
  "created_at" : "2013-05-26 00:23:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338449871038214144",
  "text" : "\u3069\u3046\u3067\u3082\u826F\u3044\u3053\u3068\u306F\u5927\u3005\u7684\u306B\u30C9\u30E4\u9854\u3067\u3001\u5927\u5207\u306A\u3053\u3068\u306F\u3057\u308C\u3063\u3068\u9759\u304B\u306B\u8A00\u3046\u30E1\u30BD\u30C3\u30C9",
  "id" : 338449871038214144,
  "created_at" : "2013-05-26 00:21:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338442213602238464",
  "text" : "\u80CC\u4E2D\u306Binfinity\u3068\u66F8\u304B\u308C\u305F\u30B7\u30E3\u30C4\u3092\u7740\u305F\u5E7C\u7A1A\u5712\u5E74\u9577\u304B\u3089\u5C0F\u5B66\u6821\u4F4E\u5B66\u5E74\u306E\u7537\u306E\u5B50",
  "id" : 338442213602238464,
  "created_at" : "2013-05-25 23:51:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338439224934154240",
  "text" : "\u3072\u3069\u304F\u6B63\u3057\u3044\u671D\u3054\u306F\u3093\u3092\u98DF\u3079\u3066\u3044\u308B",
  "id" : 338439224934154240,
  "created_at" : "2013-05-25 23:39:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338437197566976000",
  "text" : "\u601D\u3044\u7ACB\u3063\u305F\u3088\u3046\u306B\u30C9\u30F3\u30AF\u306B\u3044\u308B",
  "id" : 338437197566976000,
  "created_at" : "2013-05-25 23:31:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338431214761418752",
  "text" : "\u304A\u8179\u6E1B\u3063\u305Fof the world\u3067\u3059\u306A",
  "id" : 338431214761418752,
  "created_at" : "2013-05-25 23:07:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338407028676505600",
  "text" : "\u5F8C\u725B\u4E73\u3082\u5207\u3089\u3057\u3066\u305F",
  "id" : 338407028676505600,
  "created_at" : "2013-05-25 21:31:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338406953497792512",
  "text" : "[\u60B2\u5831]\u4FFA\u6C0F\u6C34\u84B8\u6C17\u3067\u5DE6\u624B\u306E\u6307\u3092\u3084\u3051\u3069",
  "id" : 338406953497792512,
  "created_at" : "2013-05-25 21:31:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338402561394606083",
  "text" : "tex\u53E9\u304F\u304F\u3089\u3044\u306E\u4F5C\u696D\u306A\u3089\u51FA\u6765\u308B\u304B\u306A",
  "id" : 338402561394606083,
  "created_at" : "2013-05-25 21:13:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338402433434804224",
  "text" : "\u51B7\u305F\u3044\u51B7\u305F\u3044\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u3067\u3082\u6DF9\u308C\u307E\u3059\u304B",
  "id" : 338402433434804224,
  "created_at" : "2013-05-25 21:13:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338402326538756096",
  "text" : "\u305D\u3057\u3066\u5BDD\u308B\u3053\u3068\u3092\u8AE6\u3081\u308B",
  "id" : 338402326538756096,
  "created_at" : "2013-05-25 21:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338401217027911680",
  "text" : "\u7720\u6C17\u304C\u306A\u3044\u3067\u306F\u306A\u3044\u304C\u3053\u308C\u5FAE\u5999\u904E\u304E\u308B\u306A\u20269",
  "id" : 338401217027911680,
  "created_at" : "2013-05-25 21:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338401084341092353",
  "text" : "\u30ED\u30AF\u30B8\u2026\u30ED\u30AF\u30B8\u2026",
  "id" : 338401084341092353,
  "created_at" : "2013-05-25 21:08:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338382517067476993",
  "text" : "\u5E03\u56E3\u306E\u4E0A\u3067gdgd\u3059\u308B\u3053\u30681\u6642\u9593\u8D85\uFF87\uFF70\uFF9D",
  "id" : 338382517067476993,
  "created_at" : "2013-05-25 19:54:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338382355884544000",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F of \u7A7A\u8179",
  "id" : 338382355884544000,
  "created_at" : "2013-05-25 19:53:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338382069895921664",
  "text" : "\u571F\u66DC\u3068\u65E5\u66DC\u304C\u4E00\u4F53\u5316\u3059\u308B\u304B\u308F\u308A\u306B\u751F\u6D3B\u30EA\u30BA\u30E0\u304C\u6539\u5584\u3059\u308B\u6CD5",
  "id" : 338382069895921664,
  "created_at" : "2013-05-25 19:52:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338381867566903296",
  "text" : "\u3053\u308C\u5BDD\u306A\u3044\u65B9\u304C\u826F\u3044\u306E\u3060\u308D\u3046\u304B\u2026",
  "id" : 338381867566903296,
  "created_at" : "2013-05-25 19:51:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338380264659099648",
  "text" : "\u751F\u6D3B\u30EA\u30BA\u30E0 is \u30C7\u30C3\u30C9",
  "id" : 338380264659099648,
  "created_at" : "2013-05-25 19:45:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338330205489856513",
  "text" : "\u521D\u590F\u3060\u306A\u30FC\u30FC\u30FC\u30FC\u6C57\u3070\u3080\u306A\u30FC\u30FC\u30FC",
  "id" : 338330205489856513,
  "created_at" : "2013-05-25 16:26:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338293602771947522",
  "text" : "TL\u8997\u3044\u305F\u3089\u4F55\u3084\u3089\u7729\u3057\u3044",
  "id" : 338293602771947522,
  "created_at" : "2013-05-25 14:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338264154550976512",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 338264154550976512,
  "created_at" : "2013-05-25 12:03:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 2, 16 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337914115844608000",
  "text" : "\u3042\u3068@coscos2coscos \u304C\u4EBA\u9593\u3067\u3042\u308B\u3053\u3068\u304C\u5206\u304B\u3063\u305F\u306E\u3082\u5927\u304D\u306A\u53CE\u7A6B\u306A",
  "id" : 337914115844608000,
  "created_at" : "2013-05-24 12:52:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5168\u65E5\u672C\u3082\u3046\u5E30\u308A\u305F\u3044\u5354\u4F1A",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337913951734079488",
  "text" : "#\u5168\u65E5\u672C\u3082\u3046\u5E30\u308A\u305F\u3044\u5354\u4F1A",
  "id" : 337913951734079488,
  "created_at" : "2013-05-24 12:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337913823820382208",
  "text" : "\u975E\u5E38\u306B\u6709\u610F\u7FA9\u3060\u3063\u305F(^^)(^^)(^^)(^^)(^^)",
  "id" : 337913823820382208,
  "created_at" : "2013-05-24 12:51:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337913744308969472",
  "text" : "\u50D5\u306F\u5BB6\u3067\u304A\u3068\u306A\u3057\u304F\u30C4\u30A4\u30C3\u30BF\u30FC\u3092\u3084\u308B\u3079\u304D\u4EBA\u9593\u3060\u3068\u6C17\u4ED8\u3044\u305F\u98F2\u307F\u4F1A\u3067\u3057\u305F\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 337913744308969472,
  "created_at" : "2013-05-24 12:51:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/MDv1CadGJ7",
      "expanded_url" : "http:\/\/4sq.com\/10XMoTT",
      "display_url" : "4sq.com\/10XMoTT"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0288035055, 135.7727571917 ]
  },
  "id_str" : "337913093579501568",
  "text" : "I'm at \u305C\u3093 (\u4EAC\u90FD\u5E02, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/MDv1CadGJ7",
  "id" : 337913093579501568,
  "created_at" : "2013-05-24 12:48:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337878447886065664",
  "geo" : { },
  "id_str" : "337878598432223232",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u8CB4\u69D8\u5E79\u4E8B\u306E\u304F\u305B\u306B\u30EA\u30D7\u30E9\u30A4\u98DB\u3070\u3057\u3066\u306A\u3044\u3067\u65E9\u304F\u6765\u306A\u3055\u3044",
  "id" : 337878598432223232,
  "in_reply_to_status_id" : 337878447886065664,
  "created_at" : "2013-05-24 10:31:50 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337878480920383488",
  "text" : "\u3089\u3053\u3089\u3053\u3089\u3053\u301C",
  "id" : 337878480920383488,
  "created_at" : "2013-05-24 10:31:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337875230385127424",
  "text" : "\u5E74\u306B\u6570\u5EA6\u3057\u304B\u306A\u3044\u30B5\u30FC\u30AF\u30EB\u306E\u98F2\u307F\u4F1A\u3060\u304C\u3001\u5834\u6240\u304C\u7814\u7A76\u5BA4\u3067\u306E\u98F2\u307F\u4F1A\u306E\u5834\u6240\u3068\u88AB\u3063\u3066\u308B\u3053\u3068\u304C\u5224\u660E\u3057\u3066\u306C\u30FC\u3093",
  "id" : 337875230385127424,
  "created_at" : "2013-05-24 10:18:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337807083539939328",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u571F\u66DC\u65E5\u30D0\u30A4\u30C8\u306A\u306E\u306721\u6642\u4EE5\u964D\u304B\u3089\u53C2\u52A0\u3068\u304B\u53EF\u80FD\u3067\u3059\uFF1F(\u305D\u308C\u307E\u3067\u3084\u3063\u3066\u3044\u308B\u306E\u304B)",
  "id" : 337807083539939328,
  "created_at" : "2013-05-24 05:47:39 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337763519875383297",
  "text" : "\u306A\u3069\u3068\u610F\u5473\u4E0D\u660E\u306E\u4F9B\u8FF0\u3092\u3057\u3066\u304A\u308A\u3001\u660E\u65E5\u306B\u3082\u66F8\u985E\u9001\u691C\u3055\u308C\u308B\u898B\u8FBC\u307F\u3001\u8B66\u5BDF\u3067\u306F\u4ECA\u5F8C\u4F59\u7F6A\u3092\u8FFD\u6C42\u3057\u3066\u3044\u304F\u6A21\u69D8\u3067\u3059",
  "id" : 337763519875383297,
  "created_at" : "2013-05-24 02:54:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337763127980605441",
  "text" : "\uFF1F\uFF1F\uFF1F\u300C\u4FFA\u304C\u30B4\u30DF\u3092\u6D6E\u304B\u3079\u3066\u7F6E\u3044\u305F\u3068\u3053\u308D\u306B\u81EA\u8EE2\u8ECA\u304A\u3044\u305F\u3084\u3064\u51FA\u3066\u6765\u3044\u300D",
  "id" : 337763127980605441,
  "created_at" : "2013-05-24 02:52:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337762740372402176",
  "text" : "@potezaki \u30B4\u30DF\u304C\u6D6E\u3044\u3066\u3044\u305F\u3068\u3053\u308D\u306B\u307D\u3066\u3056\u304D\u304C\u81EA\u8EE2\u8ECA\u306E\u30AB\u30B4\u3092\u5408\u308F\u305B\u3066\u7F6E\u3044\u3066\u3057\u307E\u3063\u305F\u53EF\u80FD\u6027",
  "id" : 337762740372402176,
  "created_at" : "2013-05-24 02:51:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337758843788488704",
  "text" : "\u3053\u306E\u3068\u3066\u3082\u6691\u3044\u4E2D\u309230\u5206\u6B69\u3044\u305F\u672B\u306B\u30E9\u30FC\u30E1\u30F3\u3092\u98DF\u3079\u308B\u3068\u304B\u3044\u3046\u30DE\u30BE\u30D2\u30B9\u30C6\u30A3\u30C3\u30AF\u307B\u3052\u307B\u3052",
  "id" : 337758843788488704,
  "created_at" : "2013-05-24 02:35:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337751233160937472",
  "text" : "\u5DEB\u5973\u3055\u3093\u304C\u5FD9\u3057\u305D\u3046\u3060\u3051\u3069\u4F55\u304B\u3042\u308B\u306E\u304B\u306A[\u4E0B\u9D28\u795E\u793E]",
  "id" : 337751233160937472,
  "created_at" : "2013-05-24 02:05:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337751233202892800",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3001\u6728\u9670\u306F\u305D\u3053\u305D\u3053\u6DBC\u3057\u3044",
  "id" : 337751233202892800,
  "created_at" : "2013-05-24 02:05:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337750215954161664",
  "text" : "\u3066\u304F\u3066\u304F\u3042\u308B\u3044\u3066\u884C\u304D\u307E\u3059\u304B\u30FC\u30FC",
  "id" : 337750215954161664,
  "created_at" : "2013-05-24 02:01:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337747840711405568",
  "text" : "\u304A\u6C17\u306B\u5165\u308A\u306E\u670D\u304C\u64E6\u308A\u5207\u308C\u3066\u884C\u304F\u306E\u306F\u3001\u54C0\u3057\u3044",
  "id" : 337747840711405568,
  "created_at" : "2013-05-24 01:52:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C6\u30A4\u30EB\u30BA\u30FB\u30AA\u30D6\u30FB\u6F22\u30AA\u30BB\u30C1\u30A2@\u3075\u3093\u3059\uFF01",
      "screen_name" : "osetia_kaguya",
      "indices" : [ 0, 14 ],
      "id_str" : "56097393",
      "id" : 56097393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337741675583660032",
  "geo" : { },
  "id_str" : "337741747906031617",
  "in_reply_to_user_id" : 56097393,
  "text" : "@osetia_kaguya \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 337741747906031617,
  "in_reply_to_status_id" : 337741675583660032,
  "created_at" : "2013-05-24 01:28:02 +0000",
  "in_reply_to_screen_name" : "osetia_kaguya",
  "in_reply_to_user_id_str" : "56097393",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNIpGD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337736357176819712",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNIpGD",
  "id" : 337736357176819712,
  "created_at" : "2013-05-24 01:06:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337599487331692544",
  "text" : "\u6700\u8FD1\u30C8\u30FC\u30C8\u30FC\u30ED\u30B8\u30FC\u30CD\u30BF\u3092\u983B\u767A\u3057\u3059\u304E\u3066\u308B\u304B\u3089\u81EA\u7C9B\u3057\u3088\u3046",
  "id" : 337599487331692544,
  "created_at" : "2013-05-23 16:02:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337599354548404225",
  "text" : "\u9AEA\u306E\u6BDB\u304C\u90AA\u9B54\u3067\u300C\u9AEA\u306E\u6BDB\u304C\u90AA\u9B54\u3063\u300D\u3063\u3066\u6C17\u5206",
  "id" : 337599354548404225,
  "created_at" : "2013-05-23 16:02:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337599049182089216",
  "text" : "Google+\u3060\u304B\u3067\u30B0\u30EB\u30FC\u30D7\u5316\u3057\u3066\u304F\u308C\u305F\u3089\u30D5\u30A1\u30A4\u30EB\u3082\u6295\u3052\u3084\u3059\u3044\u306E\u3060\u304C",
  "id" : 337599049182089216,
  "created_at" : "2013-05-23 16:01:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 0, 9 ],
      "id_str" : "134141604",
      "id" : 134141604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337598571421515776",
  "geo" : { },
  "id_str" : "337598874497720322",
  "in_reply_to_user_id" : 134141604,
  "text" : "@nf_spitz \u3069\u3053\u306B\u9001\u308C\u3070\uFF1F(\u3042\u308C\u306A\u3089DM\u3067\u3069\u3046\u305E)[\u305F\u3060\u6700\u5F8C\u306E\u5FAE\u5206\u65B9\u7A0B\u5F0F\u306E\u554F\u984C\u3046\u3084\u3080\u3084\u306B\u306A\u3063\u305F\u306E\u3067\u5B8C\u6210\u7248\u306F\u6765\u9031\u306B\u306A\u308B\u304B\u3068]",
  "id" : 337598874497720322,
  "in_reply_to_status_id" : 337598571421515776,
  "created_at" : "2013-05-23 16:00:18 +0000",
  "in_reply_to_screen_name" : "nf_spitz",
  "in_reply_to_user_id_str" : "134141604",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337598407147397120",
  "text" : "\u98A8\u5442\u4E0A\u308A\u306E\u6247\u98A8\u6A5Fis\u6C17\u6301\u3061\u3044\u3044",
  "id" : 337598407147397120,
  "created_at" : "2013-05-23 15:58:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337594177363779586",
  "text" : "\u9006\u304B\u307E\u3063\u3066\u3068\u547D\u540D\u3057\u3088\u3046",
  "id" : 337594177363779586,
  "created_at" : "2013-05-23 15:41:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337594064356663296",
  "text" : "\u732B\u304C\u304B\u307E\u3063\u3066\u30FC\u3063\u3066\u64E6\u308A\u5BC4\u3063\u3066\u6765\u305F\u306E\u3092\u300C\u4ECA\u306F\u5FD9\u3057\u3044\u3093\u3060\u3088\u300D\u3063\u3066\u3042\u3057\u3089\u3044\u305F\u3044\u6C17\u5206",
  "id" : 337594064356663296,
  "created_at" : "2013-05-23 15:41:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337593733673525248",
  "text" : "\u304A\u3075\u308D\u30FC\u3069",
  "id" : 337593733673525248,
  "created_at" : "2013-05-23 15:39:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337593682540785666",
  "text" : "\u304A\u3075\u308D\u304A\u3076\u304A\u3075\u308D",
  "id" : 337593682540785666,
  "created_at" : "2013-05-23 15:39:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337539378782019584",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 337539378782019584,
  "created_at" : "2013-05-23 12:03:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337465803563749376",
  "geo" : { },
  "id_str" : "337465864230154240",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u30CA\u30A4\u30B9\u30D0\u30FC\u30F3\uFF01",
  "id" : 337465864230154240,
  "in_reply_to_status_id" : 337465803563749376,
  "created_at" : "2013-05-23 07:11:46 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337465244307841024",
  "text" : "\u3088\u304F\u8003\u3048\u305F\u3089\u30D0\u30B9\u30BF\u30AA\u30EB\u6D17\u6FEF\u3057\u3066\u308B\u306A\uFF1F",
  "id" : 337465244307841024,
  "created_at" : "2013-05-23 07:09:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337462092619710465",
  "text" : "\u304A\u98A8\u5442\u5C4B\u3055\u3093\u306B\u884C\u3053\u3046\u304B\u8FF7\u3063\u3066\u3044\u308B",
  "id" : 337462092619710465,
  "created_at" : "2013-05-23 06:56:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337461977121185793",
  "text" : "\u307E\u3068\u3081\u3066\u6383\u9664\u3059\u308B\u306E\u3084\u3081\u305F\u3044(\u4E00\u6642\u9593\u306B\u53CA\u3076\u6383\u9664\u306E\u5F8C)",
  "id" : 337461977121185793,
  "created_at" : "2013-05-23 06:56:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B9\u30E9\u30B9\u30C6",
      "screen_name" : "slapstick123",
      "indices" : [ 0, 13 ],
      "id_str" : "137764483",
      "id" : 137764483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337410567365091329",
  "geo" : { },
  "id_str" : "337410754695286784",
  "in_reply_to_user_id" : 137764483,
  "text" : "@slapstick123 \u3078\u3061\u3087\u7D75\u304B\u308F\u3044\u3044\u3067\u3059\u306D\uFF01[\u305D\u3093\u306A\u30C8\u30A5\u30B2\u30C3\u30BF\u30FC\u3082\u3042\u308A\u307E\u3057\u305F\u306D\u78BA\u304B]",
  "id" : 337410754695286784,
  "in_reply_to_status_id" : 337410567365091329,
  "created_at" : "2013-05-23 03:32:47 +0000",
  "in_reply_to_screen_name" : "slapstick123",
  "in_reply_to_user_id_str" : "137764483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337410262552436736",
  "text" : "\u30B9\u30E9\u30B9\u30C6\u3055\u3093\u304C\u6A2A\u3092\u5411\u3044\u3066\u3044\u306A\u3044\uFF1F\uFF01",
  "id" : 337410262552436736,
  "created_at" : "2013-05-23 03:30:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337400449579757569",
  "text" : "\u5BDD\u3059\u304E\u305F\u4EBA\u300C\u5BDD\u3059\u304E\u305F\uFF01\u300D",
  "id" : 337400449579757569,
  "created_at" : "2013-05-23 02:51:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337252885907775491",
  "text" : "\u308F\u305F\u3057\u3060\u3051\u3067\u3059\u304B\u306D",
  "id" : 337252885907775491,
  "created_at" : "2013-05-22 17:05:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337252727778336768",
  "geo" : { },
  "id_str" : "337252843360776192",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u308F\u304B\u308B\u30FC",
  "id" : 337252843360776192,
  "in_reply_to_status_id" : 337252727778336768,
  "created_at" : "2013-05-22 17:05:18 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337252802235604992",
  "text" : "\u3068\u306F\u3044\u3048\u5C0F\u6CC9\u3055\u3093\u304C\"\u6642\u304C\u6765\u305F\u3089hogehoge\"\u3063\u3066\u8A00\u3063\u3066\u308B\u3068\u8981\u3089\u306C\u5B97\u6559\u8272\u304C\uFF1F\uFF1F",
  "id" : 337252802235604992,
  "created_at" : "2013-05-22 17:05:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337252509557092352",
  "text" : "\u30AA\u30C8\u30B2\u30A8\u30E0\u306E\u30D2\u30C8\u30B2\u30CE\u30E0\u611F",
  "id" : 337252509557092352,
  "created_at" : "2013-05-22 17:03:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337250151385161728",
  "text" : "\u3061\u306A\u307F\u306B\u30D5\u30EC\u30FC\u30D0\u30FC\u30C6\u30A3\u30FC\u3068\u304B\u305D\u3046\u3044\u3046\u306E\u306F\u7D50\u69CB\u597D\u304D",
  "id" : 337250151385161728,
  "created_at" : "2013-05-22 16:54:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337249703550935040",
  "geo" : { },
  "id_str" : "337250063850041344",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u6614\u3063\u3066\u3044\u3046\u306E\u304C10\u5E74\u5358\u4F4D\u3067\u6614\u306A\u306E\u3067\u305F\u3076\u3093\u50D5\u306E\u5473\u899A\u306E\u5909\u5316\u306B\u4F9D\u308B\u3068\u3053\u308D\u304C\u5927\u304D\u3044\u6C17\u304C\u3057\u3066\u6765\u307E\u3057\u305F",
  "id" : 337250063850041344,
  "in_reply_to_status_id" : 337249703550935040,
  "created_at" : "2013-05-22 16:54:15 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337249374390321152",
  "geo" : { },
  "id_str" : "337249570314670082",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u898B\u4E8B\u306A\u898B\u89E3\u306E\u4E0D\u4E00\u81F4\u3067\u3059\u306D\u3047\u3001\u4ECA\u5EA6\u98F2\u3080\u6642\u306F\u610F\u8B58\u3057\u3066\u98F2\u3093\u3067\u307F\u307E\u3059",
  "id" : 337249570314670082,
  "in_reply_to_status_id" : 337249374390321152,
  "created_at" : "2013-05-22 16:52:18 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337248939420053505",
  "geo" : { },
  "id_str" : "337249258552049664",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u306F\u3044[\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F]",
  "id" : 337249258552049664,
  "in_reply_to_status_id" : 337248939420053505,
  "created_at" : "2013-05-22 16:51:03 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337249136023830531",
  "text" : "\u8336\u8272\u3044\u304A\u8336\u304C\u597D\u304D\u306A\u306E\u3067\u3059\u3001\u7384\u7C73\u8336\u3068\u304B\u3082\u597D\u304D\u3060\u304B\u3089\u9244\u5247\u3067\u306F\u306A\u3044\u3051\u308C\u3069",
  "id" : 337249136023830531,
  "created_at" : "2013-05-22 16:50:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337248501731831808",
  "geo" : { },
  "id_str" : "337249037394796544",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u751F\u8336\u5ACC\u3044\u306A\u3093\u3067\u3059\uFF1F\u6700\u8FD1\u4E45\u3005\u306B\u98F2\u3093\u3067\u6614\u3088\u308A\u306F\u7F8E\u5473\u3057\u304F\u306A\u3063\u3066\u307E\u3057\u305F\u304C[\u4F0A\u53F3\u885B\u9580\u3082\u307B\u3046\u3058\u8336\u304C\u597D\u304D\u3067\u3059]",
  "id" : 337249037394796544,
  "in_reply_to_status_id" : 337248501731831808,
  "created_at" : "2013-05-22 16:50:10 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337248770158886912",
  "geo" : { },
  "id_str" : "337248828325507073",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 337248828325507073,
  "in_reply_to_status_id" : 337248770158886912,
  "created_at" : "2013-05-22 16:49:21 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337248546300506112",
  "geo" : { },
  "id_str" : "337248781756137472",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u534A\u5206\u50D5\u304C\u8CB7\u3044\u307E\u3059\u3088![\u3042\u308C\uFF1F]",
  "id" : 337248781756137472,
  "in_reply_to_status_id" : 337248546300506112,
  "created_at" : "2013-05-22 16:49:10 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337248395225874433",
  "text" : "\u30B5\u30F3\u30C8\u30EA\u30FC\u306F\u304A\u3044\u3057\u3044\u30A6\u30A3\u30B9\u30AD\u30FC\u3068\u304B\u304A\u3044\u3057\u3044\u70CF\u9F8D\u8336\u3068\u304B\u4F5C\u3063\u3066\u308B\u3057\u826F\u3044\u4F01\u696D\u3060\uFF01\uFF01\uFF01\uFF01",
  "id" : 337248395225874433,
  "created_at" : "2013-05-22 16:47:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337248146180669440",
  "text" : "\u70CF\u9F8D\u8336\u306E\u65B9\u304C\u307E\u3057\u3060\u306A\uFF1F",
  "id" : 337248146180669440,
  "created_at" : "2013-05-22 16:46:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 3, 14 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/kycjYKf8Go",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B008UI3K4C",
      "display_url" : "amazon.co.jp\/dp\/B008UI3K4C"
    } ]
  },
  "geo" : { },
  "id_str" : "337248120691892224",
  "text" : "RT @Maleic1618: http:\/\/t.co\/kycjYKf8Go",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/kycjYKf8Go",
        "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B008UI3K4C",
        "display_url" : "amazon.co.jp\/dp\/B008UI3K4C"
      } ]
    },
    "geo" : { },
    "id_str" : "337247912557948928",
    "text" : "http:\/\/t.co\/kycjYKf8Go",
    "id" : 337247912557948928,
    "created_at" : "2013-05-22 16:45:42 +0000",
    "user" : {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "protected" : true,
      "id_str" : "520458209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3586149917\/79a30ec1ce8c9452c9e4aecbcd434c16_normal.png",
      "id" : 520458209,
      "verified" : false
    }
  },
  "id" : 337248120691892224,
  "created_at" : "2013-05-22 16:46:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337247863014834176",
  "geo" : { },
  "id_str" : "337248034398285825",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u5FAE\u5999\u3067\u3057\u305F\u304B\u2026[\u52E2\u3044\u3060\u3051\u3067\u6295\u3052\u307E\u3057\u305F\u3059\u307F\u307E\u305B\u3093]",
  "id" : 337248034398285825,
  "in_reply_to_status_id" : 337247863014834176,
  "created_at" : "2013-05-22 16:46:11 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337247922162896896",
  "text" : "\uFF1F",
  "id" : 337247922162896896,
  "created_at" : "2013-05-22 16:45:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337247902919434241",
  "text" : "\u3082\u3046\u30B5\u30F3\u30C8\u30EA\u30FC\u70CF\u9F8D\u8336\u306E\u3064\u3069\u3044\u3092\u3084\u308B\u307E\u3067\u3042\u308B\uFF01",
  "id" : 337247902919434241,
  "created_at" : "2013-05-22 16:45:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/9JVpVAglKW",
      "expanded_url" : "http:\/\/twitpic.com\/csfxy0",
      "display_url" : "twitpic.com\/csfxy0"
    } ]
  },
  "in_reply_to_status_id_str" : "337247104202338304",
  "geo" : { },
  "id_str" : "337247466187530240",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u3053\u308C\u3067\u3059\uFF01 http:\/\/t.co\/9JVpVAglKW",
  "id" : 337247466187530240,
  "in_reply_to_status_id" : 337247104202338304,
  "created_at" : "2013-05-22 16:43:56 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337247328471773184",
  "text" : "\u30E6\u30FC\u30D5\u30A9\u3068\u30DB\u30EB\u30F3\u306E\u8B0E\u306E\u9023\u5E2F\u611Fis\u5FD8\u308C\u3066\u305F",
  "id" : 337247328471773184,
  "created_at" : "2013-05-22 16:43:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337247159911079938",
  "text" : "\u30DB\u30EB\u30F3\u5439\u304D\u3067\u306A\u3044\u3072\u3068\u304C\u30DB\u30EB\u30F3\u3068\u8A00\u3046\u30EF\u30FC\u30C9\u306B\u53CD\u5FDC\u3059\u308B\u30B7\u30C1\u30E5\u30A8\u30FC\u30B7\u30E7\u30F3\u3092\u3001\u50D5\u306F\u307E\u3060\u77E5\u3089\u306A\u3044",
  "id" : 337247159911079938,
  "created_at" : "2013-05-22 16:42:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337246856700633088",
  "text" : "@DAIKICHIinKUS \u30DB\u30EB\u30CB\u30B9\u30C8\u306A\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 337246856700633088,
  "created_at" : "2013-05-22 16:41:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337246510079172608",
  "geo" : { },
  "id_str" : "337246679017345024",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30AA\u30E4\u30B9\u30DF\u30CA\u30B5\u30A4\uFF01",
  "id" : 337246679017345024,
  "in_reply_to_status_id" : 337246510079172608,
  "created_at" : "2013-05-22 16:40:48 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337246615767220225",
  "text" : "\u3053\u308C\u3082\u307E\u305F\u53CD\u5247\u304B\u3082",
  "id" : 337246615767220225,
  "created_at" : "2013-05-22 16:40:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337246138027626497",
  "geo" : { },
  "id_str" : "337246522964054016",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u305D\u308C is \u30DD\u30B9\u30C8\u3057\u3088\u3046\u304B is \u8FF7\u3063\u305F",
  "id" : 337246522964054016,
  "in_reply_to_status_id" : 337246138027626497,
  "created_at" : "2013-05-22 16:40:11 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337246243334017024",
  "text" : "\u97F3\u30B2\u30FC\u30DE\u30FC\u306Fvim\u4F7F\u3046\u306E\uFF1F",
  "id" : 337246243334017024,
  "created_at" : "2013-05-22 16:39:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337245995064770562",
  "text" : "\u3068\u306F\u3044\u3048\u30DB\u30EB\u30F3\u5439\u3044\u3066\u305F\u9803\u306B\u5C0F\u6307\u306F\u81EA\u7136\u3068\u935B\u3048\u3089\u308C\u3066\u308B\u306F\u305A[\u8981\u51FA\u5178][\u4F55\u5E74\u524D\u3060\u3088]",
  "id" : 337245995064770562,
  "created_at" : "2013-05-22 16:38:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337245723198365696",
  "text" : "\u97F3\u30B2\u30FC\u30DE\u30FC\u306E\u5F8C\u8F29\u3088\u308D\u3057\u304F\u5C0F\u6307\u304C\u8171\u9798\u708E\u306B\u3067\u3082\u306A\u3063\u305F\u3089vim\u3092\u899A\u3048\u308B",
  "id" : 337245723198365696,
  "created_at" : "2013-05-22 16:37:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337245450908360704",
  "text" : "\u5F90\u3005\u306B\u30DE\u30A6\u30B9\u3092\u4F7F\u308F\u306A\u304F\u306A\u3063\u3066\u884C\u304F\u306E\u697D\u3057\u3044\u304B\u3082[\u305D\u3057\u3066\u9177\u4F7F\u3055\u308C\u308B\u5C0F\u6307]",
  "id" : 337245450908360704,
  "created_at" : "2013-05-22 16:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337245315604287488",
  "text" : "\u898B\u958B\u304D4\u679A\u5F31\u30921\u6642\u9593\u534A\u304B\u2026\u3082\u3046\u3061\u3087\u3044\u901F\u5EA6\u3092\u51FA\u3057\u305F\u3044\u3001\u5177\u4F53\u7684\u306B\u306F\u540C\u91CF\u30921\u6642\u9593\u3067\u3002",
  "id" : 337245315604287488,
  "created_at" : "2013-05-22 16:35:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337239673262985216",
  "text" : "\u307E\u3060\u5C0F\u6307\u306F\u6523\u308A\u307E\u305B\u3093\u304C\u6642\u9593\u306E\u554F\u984C\u304B\u3068\u601D\u308F\u308C\u307E\u3059",
  "id" : 337239673262985216,
  "created_at" : "2013-05-22 16:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337239562537553921",
  "text" : "\u3057\u3063\u304B\u3057\u3053\u308Cemacs\u306E\u65E5\u672C\u8A9E\u5165\u529B\u3082\u3046\u3061\u3087\u3044\u8CE2\u304F\u306A\u3089\u306A\u3044\u304B\u306A\u2026",
  "id" : 337239562537553921,
  "created_at" : "2013-05-22 16:12:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337239400159252481",
  "text" : "\u57FA\u672C\u7684\u306B\u5E03\u3092\u611B\u3057\u3066\u3044\u308B\u306E\u3067\u8584\u7740\u306F\u597D\u304D\u3067\u306A\u3044\u3067\u3057",
  "id" : 337239400159252481,
  "created_at" : "2013-05-22 16:11:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337238873610518528",
  "text" : "\u591A\u304F\u306E\u4EBA\u306B\u305D\u306E\u683C\u597D\u6691\u304F\u306A\u3044\uFF1F\u3063\u3066\u805E\u304B\u308C\u308B\u3051\u3069\u305F\u3076\u3093\u9577\u8896\u3092\u7740\u7D9A\u3051\u307E\u3059",
  "id" : 337238873610518528,
  "created_at" : "2013-05-22 16:09:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337218784253341696",
  "text" : "\u4EE5\u4E0A\u3067\u3059\uFF01",
  "id" : 337218784253341696,
  "created_at" : "2013-05-22 14:49:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337218745325993984",
  "text" : "\u53CD\u5247\u30AC\u30C1\u52E2\u3067\u3059\u306D\uFF01",
  "id" : 337218745325993984,
  "created_at" : "2013-05-22 14:49:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337218656209612800",
  "text" : "\uFF1F",
  "id" : 337218656209612800,
  "created_at" : "2013-05-22 14:49:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337218621631787009",
  "text" : "\u53CD\u5247\u52DD\u3061\u3092\u7A4D\u307F\u91CD\u306D\u3066\u53CD\u5247\u52DD\u3061\u306E\u5C71\u3092\u4F5C\u308B\u306E\u304C\u5B50\u4F9B\u306E\u9803\u304B\u3089\u306E\u5922\u3067\u3059",
  "id" : 337218621631787009,
  "created_at" : "2013-05-22 14:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337218473547661314",
  "text" : "\u308F\u304B\u308B",
  "id" : 337218473547661314,
  "created_at" : "2013-05-22 14:48:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337218462013333506",
  "text" : "RT @kagakuma: end\u3055\u3093\u3055\u3063\u304D\u304B\u3089\u53CD\u5247\u52DD\u3061\u3092\u7A4D\u307F\u91CD\u306D\u3066\u308B\u611F\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337218389003079681",
    "text" : "end\u3055\u3093\u3055\u3063\u304D\u304B\u3089\u53CD\u5247\u52DD\u3061\u3092\u7A4D\u307F\u91CD\u306D\u3066\u308B\u611F\u3042\u308B",
    "id" : 337218389003079681,
    "created_at" : "2013-05-22 14:48:23 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 337218462013333506,
  "created_at" : "2013-05-22 14:48:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337218135851671552",
  "text" : "\u3059\u3054\u3044\u52E2\u3044\u3067TeX\u6253\u3064\u4EBA\u300C\u30A4\u30E4\u30FC\u30C3\uFF01\u30A4\u30E4\u30FC\u30C3\uFF01\u30A4\u30E4\u30FC\u30C3\uFF01\u300D",
  "id" : 337218135851671552,
  "created_at" : "2013-05-22 14:47:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337217922395156480",
  "text" : "\u65E5\u4ED8\u5909\u308F\u3063\u305F\u3059\u3054\u3044\u52E2\u3044\u3067TeX\u6253\u3064\u4E88\u5B9A",
  "id" : 337217922395156480,
  "created_at" : "2013-05-22 14:46:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337217566734966787",
  "text" : "1\u65E51\u30C4\u30A4\u30FC\u30C8\u3092\u5FD7\u3057\u3066\u308B\u5F8C\u8F29\u304C\u3044\u308B\u304C\u3001\u5F7C\u306F\u4E0B\u304B\u30891\u3092\u76EE\u6307\u3057\u3066\u308B\u304B\u3089\u30E4\u30D0\u30A4",
  "id" : 337217566734966787,
  "created_at" : "2013-05-22 14:45:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337216655379795969",
  "text" : "\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\u4F1A\u8A71\u306F\u30C6\u30F3\u30D7\u30EC\u3068\u898B\u5206\u3051\u304C\u3064\u304B\u306A\u3044",
  "id" : 337216655379795969,
  "created_at" : "2013-05-22 14:41:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337216225157476352",
  "text" : "\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F  \uFF1E \u30DE\u30B8\u30EC\u30B9 \uFF1C  \uFFE3^\uFF39^\uFF39^\uFF39^\uFF39^\uFFE3\u306E",
  "id" : 337216225157476352,
  "created_at" : "2013-05-22 14:39:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337216115556093952",
  "text" : "\u30DB\u30B0\u30EF\u30FC\u30C4\u306B\u7406\u5B66\u90E8\u304C\u3042\u3063\u305F\u3089\u3001\u3067\u3082\u304A\u304B\u3057\u3044\u306A\u3001\u3042\u305D\u3053\u5B66\u90E8\u3068\u304B\u306A\u3044\u304B\u3089[\u9B54\u6CD5\u5B66\u90E8\u306E\u5358\u79D1\uFF1F]",
  "id" : 337216115556093952,
  "created_at" : "2013-05-22 14:39:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337215952255070208",
  "text" : "\u3044\u3044\u304B\u3001\u3088\u304F\u8003\u3048\u308C\u3070\u308F\u304B\u308B\u3053\u3068\u3060\u304C\u30DB\u30B0\u30EF\u30FC\u30C4\u306F\u7406\u5B66\u90E8\u3058\u3083\u306A\u3044\u3093\u3060\u305C",
  "id" : 337215952255070208,
  "created_at" : "2013-05-22 14:38:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 0, 7 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337215345964228609",
  "geo" : { },
  "id_str" : "337215395863875584",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_key \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 337215395863875584,
  "in_reply_to_status_id" : 337215345964228609,
  "created_at" : "2013-05-22 14:36:30 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337215352696078337",
  "text" : "\u4EE5\u4E0A\u3001\u30CE\u30EA\u30C4\u30C3\u30B3\u30DF\u3067\u3057\u305F\u3001\u4EE5\u4E0A\uFF01",
  "id" : 337215352696078337,
  "created_at" : "2013-05-22 14:36:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337215253471436801",
  "text" : "\u3044\u3084\u3044\u3084\u3001\u81EA\u5206\u3067\u8ABF\u3079\u308D\u3088\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 337215253471436801,
  "created_at" : "2013-05-22 14:35:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337215198068883456",
  "text" : "\u826F\u3044\u53CB\u4EBA\u3092\u6301\u3063\u305F[\u5177\u4F53\u7684\u306B\u306F\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u70CF\u9F8D\u8336\u3092\u7BB1\u8CB7\u3044\u3057\u305F\u3044\u3068\u3044\u3046\u982D\u306E\u60AA\u3044\u30C4\u30A4\u30FC\u30C8\u306B\u5BFE\u3057\u3066\u53C2\u8003\u753B\u50CF\u3092\u9001\u3063\u3066\u304F\u308C\u308B\u3088\u3046\u306A]",
  "id" : 337215198068883456,
  "created_at" : "2013-05-22 14:35:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337214123597254656",
  "text" : "\u793E\u4F1A\u4EBA\u306B\u306A\u3063\u305F\u3089\u3053\u3046\u3044\u3046\u982D\u306E\u60AA\u3044\u8CB7\u3044\u7269\u3057\u305F\u3044",
  "id" : 337214123597254656,
  "created_at" : "2013-05-22 14:31:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/IrBayTzBiW",
      "expanded_url" : "http:\/\/twitpic.com\/csex0r",
      "display_url" : "twitpic.com\/csex0r"
    } ]
  },
  "geo" : { },
  "id_str" : "337214058170302465",
  "text" : "\u53CB\u4EBA\u304B\u3089\u3053\u3093\u306A\u753B\u50CF\u304C\u5C4A\u3044\u305F\u3057\u3053\u308C\u30926\u500B\u983C\u3093\u3060\u3089\u3044\u3044\u306E\u304B\uFF01[\u5B9F\u969B\u91D1\u92AD\u7684\u306B\u7121\u7406\u306A] http:\/\/t.co\/IrBayTzBiW",
  "id" : 337214058170302465,
  "created_at" : "2013-05-22 14:31:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337170756498771968",
  "text" : "\u307B\u3089\u304A\u3082\u3057\u308D\u3044",
  "id" : 337170756498771968,
  "created_at" : "2013-05-22 11:39:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337170737167212544",
  "text" : "\u4F8B\uFF1A\u30BF\u30DE\u300C\u30A4\u30E4\u30FC\u30C3\uFF01\u300D\u30AB\u30C4\u30AA\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D",
  "id" : 337170737167212544,
  "created_at" : "2013-05-22 11:39:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337170508112072705",
  "text" : "\u3061\u306A\u307F\u306B\u5DE6\u8155\u306F\u3061\u3083\u3093\u3068\u6301\u3063\u3066\u3044\u304B\u308C\u307E\u3057\u305F\uFF0E\u307B\u3093\u3068\u3046\u306B\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF0E",
  "id" : 337170508112072705,
  "created_at" : "2013-05-22 11:38:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337170413429878785",
  "text" : "\u5927\u62B5\u306E\u30CD\u30BF\u30DD\u30B9\u30C8\u306F\u30AB\u30AE\u62EC\u5F27\u306E\u306A\u304B\u306B\u30A4\u30E4\u30FC\u30C3\u3068\u30B0\u30EF\u30FC\u30C3\u5165\u308C\u3066\u304A\u3051\u3070\u9762\u767D\u3044\u3068\u3044\u3046\u4E16\u754C\u306E\u771F\u7406\u306B\u6C17\u4ED8\u3044\u3066\u3057\u307E\u3063\u305F",
  "id" : 337170413429878785,
  "created_at" : "2013-05-22 11:37:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337169932196397056",
  "text" : "\u3042\u308C\u3053\u308C\u306A\u3093\u304B\u9055\u3046",
  "id" : 337169932196397056,
  "created_at" : "2013-05-22 11:35:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30DB\u30B0\u30EF\u30FC\u30C4\u304C\u7406\u5B66\u90E8\u3060\u3063\u305F\u3089",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337169895018086401",
  "text" : "\u30C0\u30F3\u30D6\u30EB\u30C9\u30A2 \u300C\u81EA\u660E\uFF01\u300D \u30F4\u30A9\u30EB\u30C7\u30E2\u30FC\u30C8\u300C\u30B0\u30EF\u30FC\u30C3\u300D #\u30DB\u30B0\u30EF\u30FC\u30C4\u304C\u7406\u5B66\u90E8\u3060\u3063\u305F\u3089",
  "id" : 337169895018086401,
  "created_at" : "2013-05-22 11:35:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337169583276429312",
  "text" : "\u66A6\u7269\u8A9E\u306E\u6240\u70BA\u3082\u3042\u308B\u3051\u3069\u30C9\u30FC\u30CA\u30C4\u98DF\u3079\u305F\u304F\u306A\u3063\u305F\u3093\u3060\u3051\u3069\u3053\u308C\u8AB0\u306B\u6587\u53E5\u8A00\u3048\u3070\u3044\u3044\u3093\u3060",
  "id" : 337169583276429312,
  "created_at" : "2013-05-22 11:34:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337169419409182720",
  "text" : "\u305D\u3082\u305D\u3082\u3053\u308C\u3068\u308A\u3042\u3048\u305A\u304B\u308F\u3044\u3044\u3063\u3066\u8A00\u3063\u3068\u3051\u3070\u3044\u3044\u3068\u601D\u3063\u3066\u308B\u7CFB\u5973\u5B50\u306B\u5BFE\u3059\u308B\u8B66\u544A\u3060\u3063\u305F\u6C17\u3082\u3057\u3066\u304D\u305F",
  "id" : 337169419409182720,
  "created_at" : "2013-05-22 11:33:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337169220972453888",
  "text" : "\uFF1F",
  "id" : 337169220972453888,
  "created_at" : "2013-05-22 11:33:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337169191687823360",
  "text" : "\u304B\u308F\u3044\u3044\u3063\u3066\u8A00\u3044\u904E\u304E\u308B\u3068\u304B\u308F\u3044\u3044\u306E\u30A4\u30F3\u30D5\u30EC\u304C\u8D77\u304D\u3066\u4FA1\u5024\u304C\u4E0B\u304C\u308B\u3068\u805E\u3044\u305F\u304B\u3089\u3042\u307E\u308A\u8A00\u308F\u306A\u3044\u3088\u3046\u306B\u3057\u305F\u3089\u6700\u8FD1\u30C7\u30D5\u30EC\u3057\u59CB\u3081\u305F",
  "id" : 337169191687823360,
  "created_at" : "2013-05-22 11:32:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337168875483435009",
  "text" : "\u300C\u30C9\u30FC\u30CA\u30C4\u98DF\u3079\u3066\u308B\u304B\u308F\u3044\u3044\u300D\u306F\u3053\u308C\u3067\u4E00\u8A9E",
  "id" : 337168875483435009,
  "created_at" : "2013-05-22 11:31:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337168582624571392",
  "geo" : { },
  "id_str" : "337168793480617984",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u30C9\u30FC\u30CA\u30C4\u98DF\u3079\u3066\u308B\u304B\u308F\u3044\u3044",
  "id" : 337168793480617984,
  "in_reply_to_status_id" : 337168582624571392,
  "created_at" : "2013-05-22 11:31:19 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337168396426813442",
  "text" : "\u7D50\u5C40\u3048\u3093\u3069\u3055\u3093\u30DD\u30C6\u30F3\u30B7\u30E3\u30EB\u304C\u4F55\u306A\u306E\u304B\u3088\u304F\u89E3\u3063\u3066\u306A\u3044\u306A",
  "id" : 337168396426813442,
  "created_at" : "2013-05-22 11:29:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337168040548511745",
  "text" : "\u5358\u829D\u3063\u3066\u306A\u3093\u3067\u5ACC\u308F\u308C\u3066\u308B(?)\u3093\u3060\u308D\u3046\uFF0E",
  "id" : 337168040548511745,
  "created_at" : "2013-05-22 11:28:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337167593255354368",
  "text" : "\u306A\u3044",
  "id" : 337167593255354368,
  "created_at" : "2013-05-22 11:26:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337167570941648897",
  "text" : "\u4F55\u3088\u308A\u7269\u7406\u7684\u306B\u7F6E\u304F\u3068\u3053\u3042\u3093\u306E\u304B",
  "id" : 337167570941648897,
  "created_at" : "2013-05-22 11:26:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337167512934424576",
  "text" : "\uFF16\u00D7\uFF11\uFF12\u306772\u672C\uFF0C144\u30EA\u30C3\u30C8\u30EB\u7A0B\u5EA6\u304B\uFF0E\u3044\u304F\u3089\u304B\u304B\u308B\u306E\u3084\u3089\uFF0E",
  "id" : 337167512934424576,
  "created_at" : "2013-05-22 11:26:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337167419745394689",
  "text" : "\u30B5\u30F3\u30C8\u30EA\u30FC\u70CF\u9F8D\u8336\u7BB1\u8CB7\u3044\u3057\u305F\u3044\u3057\uFF0C\u6B32\u3092\u8A00\u3048\u3070\u7BB1\u3092\u30C0\u30FC\u30B9\u8CB7\u3044\u3057\u305F\u3044\uFF0E",
  "id" : 337167419745394689,
  "created_at" : "2013-05-22 11:25:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337166111034470401",
  "text" : "\u53CB\u4EBA\u300C\u6700\u8FD1\u77E5\u3089\u306A\u3044\u4EBA\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u308B\u3093\u3060\u3051\u3069\u300D\n\u3048\u3093\u3069\u300C\u3048\u3063\u666E\u901A\u3067\u306F\u300D",
  "id" : 337166111034470401,
  "created_at" : "2013-05-22 11:20:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337151397285990400",
  "text" : "(\u6642\u7CFB\u5217\u7684\u306B)\u6700\u5F8C\u306E2\u7AE0\u304C\u6025\u6FC0\u904E\u304E\u3066\u89E3\u3089\u306A\u3044\u3053\u3068\u3060\u3089\u3051\u3067\u7D42\u308F\u3063\u3066\u3044\u308B\uFF0E\u7D9A\u7DE8\u304C\u697D\u3057\u307F\u3059\u304E\u308B\uFF0E",
  "id" : 337151397285990400,
  "created_at" : "2013-05-22 10:22:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337151204029243392",
  "text" : "\u66A6\u7269\u8A9E\u8AAD\u307F\u7D42\u3048\u305F\uFF0E\u306A \u3093 \u3060 \u3053 \u308C \u306F\u30FB\u30FB\u30FB",
  "id" : 337151204029243392,
  "created_at" : "2013-05-22 10:21:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337145079296843776",
  "text" : "\u305F\u307E\u3054\u308C\u305F\u3059\u3068\u307E\u3068\u306E\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u304C\u304A\u3044\u3057\u3059\u304E\u3066\u6D99\u304C\u3068\u307E\u3089\u306A\u3044",
  "id" : 337145079296843776,
  "created_at" : "2013-05-22 09:57:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336983342056624128",
  "text" : "\u66A6\u7269\u8A9E\u6B32\u3057\u3055\u306B\u65E9\u8D77\u304D\u3057\u305F\u7BC0\u3042\u308B\u3002\u8CB7\u3063\u3066\u3044\u304F\u3068\u3057\u3088\u3046\u3002",
  "id" : 336983342056624128,
  "created_at" : "2013-05-21 23:14:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336980452227293185",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 336980452227293185,
  "created_at" : "2013-05-21 23:02:55 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336863008976412672",
  "text" : "\uFF1F",
  "id" : 336863008976412672,
  "created_at" : "2013-05-21 15:16:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336862998545178624",
  "text" : "\u304B\u307E\u3063\u3066\u6B32\u3057\u3044\u6642\u306B\u306F\u3082\u3046\u3042\u308C\u3060\u3088\u306D\u3001\u300C\u304B\u304F\u304B\u304F\u3057\u304B\u3058\u304B\u306E\u4E8B\u60C5\u3067\u4ECA\u304B\u307E\u3063\u3066\u6B32\u3057\u3044\u306E\u3067\u304B\u307E\u3063\u3066\u6B32\u3057\u3044\u3067\u3059\u300D\u307F\u305F\u3044\u306B\u66F8\u985E\u3067\u63D0\u51FA\u3057\u3066\u6B32\u3057\u3044",
  "id" : 336862998545178624,
  "created_at" : "2013-05-21 15:16:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336862260234432514",
  "text" : "\u3069\u3046\u3084\u3089\u79C1\u3075\u3064\u3046\u306E\u3072\u3068\u3089\u3057\u3044",
  "id" : 336862260234432514,
  "created_at" : "2013-05-21 15:13:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336862155271979008",
  "text" : "( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 336862155271979008,
  "created_at" : "2013-05-21 15:12:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336861963869114368",
  "text" : "\u512A\u3057\u3055\u3068\u306C\u304F\u3082\u308A\u306B\u5305\u307E\u308C\u3066\u6D88\u3048\u53BB\u308A\u305F\u3044",
  "id" : 336861963869114368,
  "created_at" : "2013-05-21 15:12:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336861595592450048",
  "geo" : { },
  "id_str" : "336861716568764416",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3080\u3057\u308D\u8CB7\u3063\u3066\u304F\u308C\u308B\u696D\u8005\u3092\u3067\u3059\u306D\u2026",
  "id" : 336861716568764416,
  "in_reply_to_status_id" : 336861595592450048,
  "created_at" : "2013-05-21 15:11:06 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336861245732954112",
  "text" : "\u4F53\u304C\u3060\u308B\u3044\u306E\u306F5\u6708\u75C5\u304B\u590F\u30D0\u30C6\u304B\u5358\u306A\u308B\u6020\u60F0\u304B",
  "id" : 336861245732954112,
  "created_at" : "2013-05-21 15:09:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336861059212247042",
  "text" : "\u3053\u3046\u3044\u3046\u306E\u597D\u304D",
  "id" : 336861059212247042,
  "created_at" : "2013-05-21 15:08:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3081\u305D\uFF20\u5B87\u5B99\u306E\u97F3\u697D",
      "screen_name" : "mesology",
      "indices" : [ 3, 12 ],
      "id_str" : "335244035",
      "id" : 335244035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336861031143968768",
  "text" : "RT @mesology: (=\uFF9F\u03C9\uFF9F)&lt; \u81EA\u7136\u306A\u30D7\u30ED\u30B8\u30A7\u30AF\u30B7\u30E7\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30F3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336860877137534976",
    "text" : "(=\uFF9F\u03C9\uFF9F)&lt; \u81EA\u7136\u306A\u30D7\u30ED\u30B8\u30A7\u30AF\u30B7\u30E7\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30A9\u30F3\uFF01",
    "id" : 336860877137534976,
    "created_at" : "2013-05-21 15:07:46 +0000",
    "user" : {
      "name" : "\u3081\u305D\uFF20\u5B87\u5B99\u306E\u97F3\u697D",
      "screen_name" : "mesology",
      "protected" : false,
      "id_str" : "335244035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591283003680129026\/1PrTxRkb_normal.jpg",
      "id" : 335244035,
      "verified" : false
    }
  },
  "id" : 336861031143968768,
  "created_at" : "2013-05-21 15:08:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336839409842405377",
  "text" : "\u3042\u3051\u304A\u3074\u3083\u3042\u3068\u3042\u3084\u3075\u307F\u6C0F\u3064\u306A\u304C\u308A\u3042\u308B\u306E\u610F\u5916",
  "id" : 336839409842405377,
  "created_at" : "2013-05-21 13:42:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336832383116537856",
  "geo" : { },
  "id_str" : "336832506076737536",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30B5\u30A4\u30D0\u30FC\u3067\u30D1\u30F3\u30AF\u306A\u3093\u3067\u3059\u3088\uFF01\uFF01\uFF01[\u3054\u308A\u304A\u3057]",
  "id" : 336832506076737536,
  "in_reply_to_status_id" : 336832383116537856,
  "created_at" : "2013-05-21 13:15:02 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336831867783360513",
  "geo" : { },
  "id_str" : "336832034951540736",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u96FB\u6CE2\u00D7\u30B5\u30A4\u30D0\u30FC\u30D1\u30F3\u30AF\u25CB",
  "id" : 336832034951540736,
  "in_reply_to_status_id" : 336831867783360513,
  "created_at" : "2013-05-21 13:13:09 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336830756770963456",
  "text" : "\u3072\u3084\u3080\u304E\u304C\u304A\u3044\u3057\u304F\u3066\u5E78\u305B",
  "id" : 336830756770963456,
  "created_at" : "2013-05-21 13:08:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336814229942308864",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 336814229942308864,
  "created_at" : "2013-05-21 12:02:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/wUqazFk4eV",
      "expanded_url" : "http:\/\/4sq.com\/11UrtaP",
      "display_url" : "4sq.com\/11UrtaP"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "336797464290021376",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/wUqazFk4eV",
  "id" : 336797464290021376,
  "created_at" : "2013-05-21 10:55:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336723510082805761",
  "text" : "\u9644\u5C5E\u56F3\u66F8\u9928\u306E\u65B0\u3057\u3044\u30B5\u30FC\u30D3\u30B9\u3068\u3057\u3066\u5165\u308A\u53E3\u306B\u91D1\u5C5E\u30D0\u30C3\u30C8\u7F6E\u3044\u3066\u90AA\u9B54\u306A\u81EA\u8EE2\u8ECA\u3092\u6BB4\u6253\u3067\u304D\u308B\u3001\u3063\u3066\u3044\u3046\u306E\u306F\u3069\u3046\u3060\u308D\u3046",
  "id" : 336723510082805761,
  "created_at" : "2013-05-21 06:01:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 3, 14 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336723338531569664",
  "text" : "RT @Maleic1618: \u9644\u5C5E\u56F3\u66F8\u9928\uFF0C\u975E\u5E38\u306B\u81EA\u8EE2\u8ECA\u306E\u7F6E\u304D\u65B9\u304C\u30AF\u30BD\u306A\u306E\u3067\u884C\u304F\u6C17\u304C\u5931\u305B\u307E\u3059\uFF0E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336722850343952385",
    "text" : "\u9644\u5C5E\u56F3\u66F8\u9928\uFF0C\u975E\u5E38\u306B\u81EA\u8EE2\u8ECA\u306E\u7F6E\u304D\u65B9\u304C\u30AF\u30BD\u306A\u306E\u3067\u884C\u304F\u6C17\u304C\u5931\u305B\u307E\u3059\uFF0E",
    "id" : 336722850343952385,
    "created_at" : "2013-05-21 05:59:18 +0000",
    "user" : {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "protected" : true,
      "id_str" : "520458209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3586149917\/79a30ec1ce8c9452c9e4aecbcd434c16_normal.png",
      "id" : 520458209,
      "verified" : false
    }
  },
  "id" : 336723338531569664,
  "created_at" : "2013-05-21 06:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336723233325850624",
  "text" : "\u3042\u3044\u3059\u305F\u3079\u305F\u3044",
  "id" : 336723233325850624,
  "created_at" : "2013-05-21 06:00:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336715530239086592",
  "text" : "\u3059\u3054\u3044\u7720\u6C17\u304C\u3059\u3054\u3044",
  "id" : 336715530239086592,
  "created_at" : "2013-05-21 05:30:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336715320507125760",
  "text" : "\u5589\u4E7E\u3044\u305Fof \u5589\u4E7E\u3044\u305F",
  "id" : 336715320507125760,
  "created_at" : "2013-05-21 05:29:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336714826640404480",
  "text" : "\u6A5F\u80FD\/\u6628\u65E5",
  "id" : 336714826640404480,
  "created_at" : "2013-05-21 05:27:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336714767400067073",
  "text" : "emacs\u306E\u65E5\u672C\u8A9E\u5165\u529B\u306E\u554F\u984C\u3082\u89E3\u6C7A\u3057\u305F\u3067\u3059\u3057\u3002",
  "id" : 336714767400067073,
  "created_at" : "2013-05-21 05:27:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336714675637071872",
  "text" : "\u6A5F\u80FD\u6563\u3005\u7E4B\u304C\u3089\u306A\u304B\u3063\u305FMIAKO\u304C\u3064\u306A\u304C\u3063\u305F\u6642\u306E\u9854\u3057\u3066\u308B\u3002",
  "id" : 336714675637071872,
  "created_at" : "2013-05-21 05:26:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336525999862853633",
  "text" : "LaTeX\u306Ecomplete\u6A5F\u80FD\u307E\u3067\u306F\u5B8C\u307A\u304D\u306B\u3057\u305F\uFF0E\u306C\u30FC\u3093\uFF0E",
  "id" : 336525999862853633,
  "created_at" : "2013-05-20 16:57:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336518287808659456",
  "geo" : { },
  "id_str" : "336519455242874880",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u30CA\u30A4\u30B9\u30B3\u30ED\u30C3\u30B1\u305D\u3070\uFF01",
  "id" : 336519455242874880,
  "in_reply_to_status_id" : 336518287808659456,
  "created_at" : "2013-05-20 16:31:05 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336513889619562496",
  "text" : "\u3053\u308C\u306F\u3067\u3082\u81EA\u610F\u8B58\u904E\u5270\u3068\u304B\u305D\u3046\u3044\u3046\u306E\u3067\u306F\u306A\u3044\u3068\u601D\u3046\u306E\uFF0E\u30A8\u30B4\u30B5\u306B\u5F15\u3063\u304B\u304B\u3063\u305F\u3057\uFF0E",
  "id" : 336513889619562496,
  "created_at" : "2013-05-20 16:08:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336513607716175872",
  "text" : "@coxff2006 \uFF71\uFF6F\uFF8A\uFF72",
  "id" : 336513607716175872,
  "created_at" : "2013-05-20 16:07:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336513330682421248",
  "text" : "@coxff2006 \u3088\u3073\u307E\u3057\u305F\uFF1F",
  "id" : 336513330682421248,
  "created_at" : "2013-05-20 16:06:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336511968762540032",
  "text" : "\u518D\u8D77\u52D5\u3059\u308C\u3070\u5143\u306B\u623B\u308B\u3051\u308C\u3069\u3053\u308C\u975E\u52B9\u7387\u3059\u304E\u308B\uFF0E",
  "id" : 336511968762540032,
  "created_at" : "2013-05-20 16:01:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "emacs",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "TeX",
      "indices" : [ 82, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336511856330035201",
  "text" : "emac\uFF53\u3067\u65E5\u672C\u8A9E\u5165\u529B\u4E2D\u306B\u30D0\u30C3\u30AF\u30B9\u30E9\u30C3\u30B7\u30E5\u3092\u4E8C\u9023\u6253\u3059\u308B\u3068\u5DE6\u4E0B\u306BAaU\u3068\u304B\u51FA\u3066\u5143\u306B\u623B\u3089\u306A\u3044\u306E\u3067\u3059\u304C\uFF0C\u3053\u308C\u3092\u56DE\u907F\u3059\u308B\u306A\u308A\u5143\u306B\u623B\u3059\u65B9\u6CD5\u3054\u5B58\u77E5\u306E\u65B9\u3044\u307E\u305B\u3093\u304B #emacs #TeX",
  "id" : 336511856330035201,
  "created_at" : "2013-05-20 16:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336507793395834880",
  "text" : "\u3068\u601D\u3063\u305F\u304C\u3053\u306E\u524D\u306ES2S\u306A\u3093\u3061\u3083\u3089\u3067\u306F\u305D\u3093\u306A\u611F\u3058\u306E\u713C\u8089\u3092\u697D\u3057\u3093\u3060\u306A[\u504F\u3063\u305F\u713C\u8089]",
  "id" : 336507793395834880,
  "created_at" : "2013-05-20 15:44:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336507687019884544",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u5185\u81D3\u7CFB\u3070\u3063\u304B\u308A\u30DB\u30EB\u30E2\u30F3\u3068\u304B\u30EC\u30D0\u30FC\u3068\u304B\u8CB7\u3063\u3066\u6765\u3066\u713C\u8089\u3084\u308A\u305F\u3044\u306A\uFF0E",
  "id" : 336507687019884544,
  "created_at" : "2013-05-20 15:44:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336507424695517184",
  "geo" : { },
  "id_str" : "336507511010099201",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u9244\u677F\u3067\u3084\u308B\u5974\u3067\u3059\uFF1F",
  "id" : 336507511010099201,
  "in_reply_to_status_id" : 336507424695517184,
  "created_at" : "2013-05-20 15:43:37 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336504798914420736",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u308B\uFF0E",
  "id" : 336504798914420736,
  "created_at" : "2013-05-20 15:32:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336504395359473664",
  "text" : "\uFF7C\uFF9E\uFF6D\uFF70\uFF6F\u3063\u3066\u51FA\u6765\u308B",
  "id" : 336504395359473664,
  "created_at" : "2013-05-20 15:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336504346957205504",
  "text" : "\u713C\u77F3\u3068\u6C34\u306E",
  "id" : 336504346957205504,
  "created_at" : "2013-05-20 15:31:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336503827719131136",
  "text" : "\u8C5A\u3068\u771F\u73E0\u306E\u62B1\u304D\u5408\u308F\u305B\u8CA9\u58F2\uFF0E\u3069\u3046\u8003\u3048\u3066\u3082\u524D\u8005\u306F\u98DF\u6599\u3060\u306A\uFF1F",
  "id" : 336503827719131136,
  "created_at" : "2013-05-20 15:28:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336503736056811520",
  "text" : "\u306E\u308C\u3093\u3068\u7FA9\u624B\u306E\u62B1\u304D\u5408\u308F\u305B\u3082\u30EF\u30F3\u30C1\u30E3\u30F3",
  "id" : 336503736056811520,
  "created_at" : "2013-05-20 15:28:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nrlzp6rl(\u30AA\u30BF\u30DE\u86C7\u30AF\u30B7)",
      "screen_name" : "Otama_ja_kushi",
      "indices" : [ 3, 18 ],
      "id_str" : "501919709",
      "id" : 501919709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336503675281358849",
  "text" : "RT @Otama_ja_kushi: \u306C\u304B\u3068\u91D8\u306E\u62B1\u304D\u5408\u308F\u305B\u8CA9\u58F2\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336503644063145985",
    "text" : "\u306C\u304B\u3068\u91D8\u306E\u62B1\u304D\u5408\u308F\u305B\u8CA9\u58F2\u3002",
    "id" : 336503644063145985,
    "created_at" : "2013-05-20 15:28:15 +0000",
    "user" : {
      "name" : "nrlzp6rl(\u30AA\u30BF\u30DE\u86C7\u30AF\u30B7)",
      "screen_name" : "Otama_ja_kushi",
      "protected" : false,
      "id_str" : "501919709",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2154943775\/picture-1_normal.jpg",
      "id" : 501919709,
      "verified" : false
    }
  },
  "id" : 336503675281358849,
  "created_at" : "2013-05-20 15:28:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336503077559496704",
  "text" : "\u9B3C\u306F\u91D1\u68D2\u3068\u306E\u30BB\u30C3\u30C8\u3082\u3042\u308B\u304B\u3089\u9078\u3079\u308B\u30AE\u30D5\u30C8\u306B\u3057\u3088\u3046\uFF0E",
  "id" : 336503077559496704,
  "created_at" : "2013-05-20 15:26:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336502702127329280",
  "text" : "\u5F18\u6CD5\u3068\u7B46\u3092\u62B1\u304D\u5408\u308F\u305B\u8CA9\u58F2\u3057\u3066\u8AA4\u3063\u305F\u3089\u717D\u308B\u904A\u3073\u3092\u63D0\u4F9B\u3057\u3066\u3044\u304F\u304B",
  "id" : 336502702127329280,
  "created_at" : "2013-05-20 15:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336502527933685760",
  "text" : "\u85EA\u3092\u3064\u3064\u3044\u3066\u3078\u3073\u3092\u51FA\u3059\u904A\u3073\u304C\u3053\u308C\u4E00\u3064\u3067\u3067\u304D\u3066\u3057\u307E\u3046",
  "id" : 336502527933685760,
  "created_at" : "2013-05-20 15:23:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 3, 16 ],
      "id_str" : "86075525",
      "id" : 86075525
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 18, 28 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336502468424908804",
  "text" : "RT @_primenumber: @end313124 \u85EA\u3068\u86C7\u306E\u62B1\u304D\u5408\u308F\u305B\u8CA9\u58F2\u3057\u307E\u3057\u3087\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/shootingstar067.com\/\" rel=\"nofollow\"\u003EShootingStar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "336502162249097216",
    "geo" : { },
    "id_str" : "336502418160381953",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u85EA\u3068\u86C7\u306E\u62B1\u304D\u5408\u308F\u305B\u8CA9\u58F2\u3057\u307E\u3057\u3087\u3046",
    "id" : 336502418160381953,
    "in_reply_to_status_id" : 336502162249097216,
    "created_at" : "2013-05-20 15:23:23 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "protected" : false,
      "id_str" : "86075525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829246455\/df79f6a468f8240ff902e4e4c9c324b5_normal.png",
      "id" : 86075525,
      "verified" : false
    }
  },
  "id" : 336502468424908804,
  "created_at" : "2013-05-20 15:23:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336502396723265538",
  "text" : "\u753B\u9762\u306E\u524D\u3067\u5272\u3068\u771F\u9854\u306A\u65B9\u306Eend",
  "id" : 336502396723265538,
  "created_at" : "2013-05-20 15:23:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336502266708238337",
  "text" : "\u3042\u3068\u6708\u3068\u3059\u3063\u307D\u3093\u3042\u305F\u308A\u3092NASA\u3042\u305F\u308A\u306B\u62B1\u304D\u5408\u308F\u305B\u3066\u307F\u3066\u307B\u3057\u3044",
  "id" : 336502266708238337,
  "created_at" : "2013-05-20 15:22:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336502162249097216",
  "text" : "\u72AC\u3068\u68D2\uFF0C\u732B\u3068\u6753\u5B50\u306E\u62B1\u304D\u5408\u308F\u305B\u8CA9\u58F2\u3068\u304B\u3069\u3046\u3060\u308D\u3046\uFF0E",
  "id" : 336502162249097216,
  "created_at" : "2013-05-20 15:22:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336502108599746560",
  "text" : "\u300C\u732B\u3082\u6753\u5B50\u3082\u300D\u306E\u6753\u5B50\u306F\u3057\u3083\u3082\u3058\u3068\u304B\u304A\u305F\u307E\u307F\u305F\u3044\u306A\u3082\u306E\u3089\u3057\u3044",
  "id" : 336502108599746560,
  "created_at" : "2013-05-20 15:22:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336501090646364162",
  "geo" : { },
  "id_str" : "336501230270570496",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u50D5\u306F\u3053\u306E\u524D\u6B69\u3044\u3066\u3044\u306A\u304B\u3063\u305F\u306E\u3067\u5225\u306B\u96FB\u67F1\u306B\u306F\u3076\u3064\u304B\u308A\u305D\u3046\u306B\u306A\u308A\u307E\u305B\u3093\u3067\u3057\u305F\uFF0E",
  "id" : 336501230270570496,
  "in_reply_to_status_id" : 336501090646364162,
  "created_at" : "2013-05-20 15:18:39 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336501013047541760",
  "text" : "\u30BF\u30B3\u306F\u929B\u3067\u7A81\u304D\u523A\u3057\u3066\u3082\u7D50\u69CB\u304C\u3093\u3070\u3063\u3066\u629C\u3051\u3088\u3046\u3068\u3059\u308B\uFF0E",
  "id" : 336501013047541760,
  "created_at" : "2013-05-20 15:17:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336500904494780416",
  "text" : "\u30BF\u30B3\u3082\u6B69\u3051\u3070\u68D2\u306B\u5F53\u305F\u308B \n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E \u524D\u63D0\u304C\u507D \uFF1C\n\uFFE3Y^Y^Y^Y^Y\uFFE3",
  "id" : 336500904494780416,
  "created_at" : "2013-05-20 15:17:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336500459927916544",
  "text" : "\u30C8\u30E0\u30BD\u30F3\u30AC\u30BC\u30EB\u3082\u6B69\u3051\u3070\u68D2\u306B\u5F53\u305F\u308B\uFF1F",
  "id" : 336500459927916544,
  "created_at" : "2013-05-20 15:15:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336500327052361729",
  "text" : "\u72AC\u3082\uFF0C\u3068\u3044\u3046\u3053\u3068\u306F\u307B\u304B\u306E\u52D5\u7269\u3082\u68D2\u306B\u5F53\u305F\u308B\u306E\u304B\u3082\u3057\u308C\u306A\u3044\u306A\uFF1F",
  "id" : 336500327052361729,
  "created_at" : "2013-05-20 15:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336500248811819008",
  "text" : "\u72AC\u3082\u6B69\u3051\u3070\u68D2\u306B\u5F53\u305F\u308B\uFF0E\u3053\u308C\u72AC\u76EE\u7DDA\u3067\u66F8\u304B\u308C\u3066\u3044\u308B\u3051\u3069\u5F53\u3089\u308C\u305F\u68D2\u306F\u52D5\u3044\u3066\u3044\u306A\u3044\u308F\u3051\u3060\u3088\u306D\uFF0E",
  "id" : 336500248811819008,
  "created_at" : "2013-05-20 15:14:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336499266321268738",
  "text" : "\u6563\u5207\u308A\u982D\u3092\u53E9\u3044\u3066\u307F\u308C\u3070\u6587\u660E\u958B\u5316\u306E\u97F3\u304C\u3059\u308B\uFF3C\uFF77\uFF6C\uFF8A\uFF9E\uFF70\uFF9D\uFF0F",
  "id" : 336499266321268738,
  "created_at" : "2013-05-20 15:10:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336499065464426498",
  "text" : "\u6563\u5207\u308A\u982D\u3092\u53E9\u3044\u3066\u307F\u308C\u3070\uFF0C\u75DB\u304C\u308B",
  "id" : 336499065464426498,
  "created_at" : "2013-05-20 15:10:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336498278013206528",
  "text" : "\u306E\uFF1F",
  "id" : 336498278013206528,
  "created_at" : "2013-05-20 15:06:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336498253719805953",
  "text" : "\u5DE8\u4EBA\u306E\u661F\u304B\u3089\u6765\u305F\u5DE8\u4EBA\u306E\u4EBA\u306F\u5DE8\u4EBA\u306E",
  "id" : 336498253719805953,
  "created_at" : "2013-05-20 15:06:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336498039449591808",
  "text" : "hogehoge\u661F\u304B\u3089\u304D\u305Fhogehoge\u661F\u4EBA\u306Fhogehoge\u69CB\u6587\u3068\u3057\u3066\u4E88\u5099\u6821\u3068\u304B\u3067\u6559\u3048\u305F\u3089\u3044\u3044\u3068\u601D\u3046\uFF0E",
  "id" : 336498039449591808,
  "created_at" : "2013-05-20 15:05:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336497732644663296",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 336497732644663296,
  "created_at" : "2013-05-20 15:04:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336497709802479617",
  "text" : "\u7B54\u3048\uFF0E\u6025\u6FC0\u306A\u74B0\u5883\u306E\u5909\u5316\u306B\u3064\u3044\u3066\u3044\u3051\u306A\u3044",
  "id" : 336497709802479617,
  "created_at" : "2013-05-20 15:04:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336497605729206273",
  "text" : "\u305D\u3046\u3059\u308B\u3068\u706B\u661F\u304B\u3089\u51FA\u767A\u3057\u3066\u6C34\u661F\u3092\u7D4C\u7531\u3057\u3066\u304D\u305F\u6C34\u661F\u4EBA\u306F\u3069\u3046\u306A\u308B\u3093\u3060\u308D\u3046\uFF1F",
  "id" : 336497605729206273,
  "created_at" : "2013-05-20 15:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336497448765751296",
  "text" : "\u6C34\u661F\u304B\u3089\u304D\u3066\u3044\u306A\u3044\u65B9\u306E\u6C34\u661F\u4EBA\u306F\u6C34\u3068\u306F\u9650\u3089\u306A\u3044\uFF1F",
  "id" : 336497448765751296,
  "created_at" : "2013-05-20 15:03:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336497349100703746",
  "text" : "\u6C34\u661F\u304B\u3089\u6765\u305F\u6C34\u661F\u4EBA\u306F\u6C34\uFF0E",
  "id" : 336497349100703746,
  "created_at" : "2013-05-20 15:03:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336495948647776256",
  "text" : "\u6211\u3005\u306F\u30D0\u30CA\u30CA\u304C\u304A\u3084\u3064\u3067\u3042\u308B\u304B\u306B\u3064\u3044\u3066\u3055\u3048\u5171\u901A\u306E\u898B\u89E3\u3092\u6301\u3066\u306A\u3044\u3067\u3044\u308B\u306E\u306B\uFF0E",
  "id" : 336495948647776256,
  "created_at" : "2013-05-20 14:57:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336495797313085440",
  "text" : "\u306A\u3093\u3067\u3082\u304B\u3093\u3067\u3082\u7DDA\u5F15\u304D\u3057\u3088\u3046\u3068\u3059\u308B\u306A\u3088\u306A\u30FC\uFF0E\u4E16\u306E\u4E2D\u306E\u5927\u62B5\u306E\u3082\u306E\u3054\u3068\u306F\u5883\u754C\u8A2D\u5B9A\u304C\u96E3\u3057\u3044\u3088\uFF0E",
  "id" : 336495797313085440,
  "created_at" : "2013-05-20 14:57:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336495275470356482",
  "text" : "\u88DC\u5B8C\u306F\u5927\u4E8B",
  "id" : 336495275470356482,
  "created_at" : "2013-05-20 14:55:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336494859781292033",
  "text" : "\u9759\u304B\u306B\u717D\u3089\u308C\u3066\u3044\u305F\u3088\u3046\u306A\u6C17\u304C\u3057\u3066\u304D\u305F",
  "id" : 336494859781292033,
  "created_at" : "2013-05-20 14:53:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336494781213601792",
  "text" : "\u307E\u308C\u3044\u3093\u304F\u3093\u304C\u30DE\u30B9\u30AB\u30C3\u30C8\u30AA\u30D6\u30A2\u30EC\u30AD\u30B5\u30F3\u30C9\u30EA\u30A2\u306E\u30B8\u30E5\u30FC\u30B9\u98F2\u3093\u3067\u305F\u306E\u3067\u30DE\u30B9\u30AB\u30C3\u30C8\u30AA\u30D6\u30A2\u30EC\u30AD\u30B5\u30F3\u30C9\u30EA\u30A2\u306E\u8A71\u3057\u305F\u3089\u300C\u3048\u3093\u3069\u3055\u3093\u305D\u3046\u3044\u3046(\u3069\u3046\u3067\u3082\u3044\u3044)\u3053\u3068\u3088\u304F\u5FA1\u5B58\u3058\u3067\u3059\u306D\u300D\u3063\u3066\u8A00\u308F\u308C\u305F",
  "id" : 336494781213601792,
  "created_at" : "2013-05-20 14:53:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336494377151107072",
  "text" : "@i_horse \uFF12\uFF43\uFF48\u306E\u30A2\u30F3\u30AB\u30FC\u3058\u3083\u306A\u3044\u306E",
  "id" : 336494377151107072,
  "created_at" : "2013-05-20 14:51:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336494102751346693",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u5730\u9707\u306F\u8D77\u304D\u308B\u3063\u3066\u8A00\u308F\u305A\u306B\u6765\u308B\u3063\u3066\u3044\u3046\u3088\u306D\uFF0E\u4ECA\u307E\u3067\u4F55\u51E6\u306B\u5C45\u305F\u3093\u3060\u308D\u3046\uFF0E",
  "id" : 336494102751346693,
  "created_at" : "2013-05-20 14:50:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336493342516973568",
  "text" : "\u30A2\u30FC\u30B9\u30AF\u30A8\u30A4\u30AF\uFF1D\u30B5\u30F3",
  "id" : 336493342516973568,
  "created_at" : "2013-05-20 14:47:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336493173989838848",
  "text" : "\u3053\u3046\u3044\u3046\u306E\u306B\u5F31\u3044",
  "id" : 336493173989838848,
  "created_at" : "2013-05-20 14:46:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336492742014271488",
  "geo" : { },
  "id_str" : "336492833634664448",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3044\u3084\u307E\u3041\u305D\u3046\u3044\u3046\u6587\u5316\u306A\u3093\u3067\u3057\u3087\u3046\u3051\u308C\u3069\uFF0E\u9055\u548C\u611F\uFF0E",
  "id" : 336492833634664448,
  "in_reply_to_status_id" : 336492742014271488,
  "created_at" : "2013-05-20 14:45:17 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 0, 14 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336492590767673347",
  "geo" : { },
  "id_str" : "336492688457220098",
  "in_reply_to_user_id" : 115541150,
  "text" : "@mearythindong \uFF71\uFF6F\uFF8A\uFF72",
  "id" : 336492688457220098,
  "in_reply_to_status_id" : 336492590767673347,
  "created_at" : "2013-05-20 14:44:43 +0000",
  "in_reply_to_screen_name" : "mearythindong",
  "in_reply_to_user_id_str" : "115541150",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336492605925912577",
  "text" : "\u305D\u3046\u3044\u3046\u30B2\u30FC\u30E0\u3058\u3083\u306A\u3044\u304B\u3089",
  "id" : 336492605925912577,
  "created_at" : "2013-05-20 14:44:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336492563898974209",
  "text" : "\u3048\uFF0C\u306A\u306B\uFF1F\u3053\u308C\u5730\u9707\u304C\u3042\u3063\u3066\u304B\u3089\u6700\u901F\u3067\u30DD\u30B9\u30C8\u3059\u308B\u904A\u3073\u3060\u3063\u305F\u306E\uFF1F",
  "id" : 336492563898974209,
  "created_at" : "2013-05-20 14:44:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336492114982612992",
  "text" : "\u3068\u3053\u308D\u3067emacs\u306E\u65E5\u672C\u8A9E\u5165\u529B\u304C\u4E0D\u81EA\u7531\u904E\u304E\u3066\u672A\u3060\u901F\u5EA6\u304C\u51FA\u306A\u3044\u306E\u3067\u3059\u304C\u30FC",
  "id" : 336492114982612992,
  "created_at" : "2013-05-20 14:42:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336491843736989696",
  "text" : "\u5947\u5999\u306A\u63FA\u308C\u65B9\u3060\u3063\u305F\u306A",
  "id" : 336491843736989696,
  "created_at" : "2013-05-20 14:41:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336491132454305794",
  "text" : "\u3058\u3057\u3093\uFF01",
  "id" : 336491132454305794,
  "created_at" : "2013-05-20 14:38:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3083\u307E\u3072\u3087\u3046",
      "screen_name" : "hyamaHyo",
      "indices" : [ 0, 9 ],
      "id_str" : "623703365",
      "id" : 623703365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336388040081694720",
  "geo" : { },
  "id_str" : "336388191617708032",
  "in_reply_to_user_id" : 623703365,
  "text" : "@HyamaHyo \u306F\u3044",
  "id" : 336388191617708032,
  "in_reply_to_status_id" : 336388040081694720,
  "created_at" : "2013-05-20 07:49:29 +0000",
  "in_reply_to_screen_name" : "hyamaHyo",
  "in_reply_to_user_id_str" : "623703365",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3083\u307E\u3072\u3087\u3046",
      "screen_name" : "hyamaHyo",
      "indices" : [ 0, 9 ],
      "id_str" : "623703365",
      "id" : 623703365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 10, 13 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336387557422161920",
  "geo" : { },
  "id_str" : "336387956090753024",
  "in_reply_to_user_id" : 623703365,
  "text" : "@HyamaHyo #\u306F\u3044",
  "id" : 336387956090753024,
  "in_reply_to_status_id" : 336387557422161920,
  "created_at" : "2013-05-20 07:48:33 +0000",
  "in_reply_to_screen_name" : "hyamaHyo",
  "in_reply_to_user_id_str" : "623703365",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336386604170113024",
  "text" : "@i_horse \u305D\u308C\u306A\u2026",
  "id" : 336386604170113024,
  "created_at" : "2013-05-20 07:43:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/o0ksRTe8ca",
      "expanded_url" : "http:\/\/twitpic.com\/crvnb5",
      "display_url" : "twitpic.com\/crvnb5"
    } ]
  },
  "geo" : { },
  "id_str" : "336384661771141121",
  "text" : "\u30D2\u30C8\u30AB\u30E9\u3067\u901A\u3055\u308C\u305F\u90E8\u5C4B http:\/\/t.co\/o0ksRTe8ca",
  "id" : 336384661771141121,
  "created_at" : "2013-05-20 07:35:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336373506788954113",
  "text" : "@desole_mi MISSLIM\u3068\u3044\u3046\u6CB3\u539F\u753A\u901A\u308A\u306E\u304A\u5E97\u3067\u3059\u3002\u7D05\u8336\u304A\u3044\u3057\u3044\u3002",
  "id" : 336373506788954113,
  "created_at" : "2013-05-20 06:51:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/DFjyqw5EHl",
      "expanded_url" : "http:\/\/twitpic.com\/crvbnk",
      "display_url" : "twitpic.com\/crvbnk"
    } ]
  },
  "geo" : { },
  "id_str" : "336366822620278784",
  "text" : "\u7D05\u8336\u3068\u30B1\u30FC\u30AD http:\/\/t.co\/DFjyqw5EHl",
  "id" : 336366822620278784,
  "created_at" : "2013-05-20 06:24:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336315410003668994",
  "text" : "\u304A\u3044\u3057\u3044",
  "id" : 336315410003668994,
  "created_at" : "2013-05-20 03:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336315235382206464",
  "text" : "11\u6642\u306B\u713C\u304D\u3042\u304C\u3063\u305F\u30D0\u30B1\u30C3\u30C8\u3001\u307B\u306E\u304B\u306B\u6696\u304B\u3044",
  "id" : 336315235382206464,
  "created_at" : "2013-05-20 02:59:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336164050381709314",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 336164050381709314,
  "created_at" : "2013-05-19 16:58:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 3, 14 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336163163600982016",
  "text" : "RT @nonamea774: \u306E\u306A\u3061\u3083\u3093\u306F\u3001\u540D\u524D\u306B\u306F\u5927\u4E8B\u306A\u610F\u5473\u304C\u7121\u3044\u3068\u3044\u3046\u3053\u3068\u3092\u540D\u524D\u3092\u901A\u3058\u3066\u65E5\u3005\u4E3B\u5F35\u3057\u3066\u304A\u308A\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336162989528997888",
    "text" : "\u306E\u306A\u3061\u3083\u3093\u306F\u3001\u540D\u524D\u306B\u306F\u5927\u4E8B\u306A\u610F\u5473\u304C\u7121\u3044\u3068\u3044\u3046\u3053\u3068\u3092\u540D\u524D\u3092\u901A\u3058\u3066\u65E5\u3005\u4E3B\u5F35\u3057\u3066\u304A\u308A\u307E\u3059\u3002",
    "id" : 336162989528997888,
    "created_at" : "2013-05-19 16:54:36 +0000",
    "user" : {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "protected" : false,
      "id_str" : "122305557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599956952429432832\/8y-IRC09_normal.png",
      "id" : 122305557,
      "verified" : false
    }
  },
  "id" : 336163163600982016,
  "created_at" : "2013-05-19 16:55:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336162905617743872",
  "text" : "\u52DD\u624B\u306B\u7D0D\u5F97\u3059\u308B\u65B9\u306Eend",
  "id" : 336162905617743872,
  "created_at" : "2013-05-19 16:54:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3072\u3089\u3081\u304D",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336162528050675713",
  "text" : "\u3086\u3048\u306Bnoname\u306A\u306E\u304B\uFF01#\u3072\u3089\u3081\u304D",
  "id" : 336162528050675713,
  "created_at" : "2013-05-19 16:52:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336162359339012096",
  "text" : "\u5B89\u5FC3\u9662\u3055\u3093\u307F\u305F\u3044\u306B\u500B\u3005\u4EBA\u306E\"\u306E\u306A\u3061\u3083\u3093\"\u304B\u500B\u6027\u3092\u6301\u3063\u3066\u305F\u308A\u3057\u305D\u3046",
  "id" : 336162359339012096,
  "created_at" : "2013-05-19 16:52:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 3, 14 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336162187984896000",
  "text" : "RT @nonamea774: \u306E\u306A\u3061\u3083\u3093\u304C\u30EA\u30A2\u30EB\u306B\u76F4\u63A5\u5E72\u6E09\u3059\u308B\u306E\u306F\u56F0\u96E3\u306A\u306E\u3067\u3001\u306E\u306A\u3061\u3083\u3093\u306E\u4EE3\u7406\u304C\u6D3E\u9063\u3055\u308C\u307E\u3059\u3002 \u73FE\u5728\u306E\u4EAC\u90FD\u30A8\u30EA\u30A2\u3067\u306E\u306E\u306A\u3061\u3083\u3093\u306E\u4EE3\u7406\u306F\u4EE3\u7406No. 4 \u304C\u62C5\u5F53\u3057\u3066\u304A\u308A\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336162112164478977",
    "text" : "\u306E\u306A\u3061\u3083\u3093\u304C\u30EA\u30A2\u30EB\u306B\u76F4\u63A5\u5E72\u6E09\u3059\u308B\u306E\u306F\u56F0\u96E3\u306A\u306E\u3067\u3001\u306E\u306A\u3061\u3083\u3093\u306E\u4EE3\u7406\u304C\u6D3E\u9063\u3055\u308C\u307E\u3059\u3002 \u73FE\u5728\u306E\u4EAC\u90FD\u30A8\u30EA\u30A2\u3067\u306E\u306E\u306A\u3061\u3083\u3093\u306E\u4EE3\u7406\u306F\u4EE3\u7406No. 4 \u304C\u62C5\u5F53\u3057\u3066\u304A\u308A\u307E\u3059\u3002",
    "id" : 336162112164478977,
    "created_at" : "2013-05-19 16:51:07 +0000",
    "user" : {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "protected" : false,
      "id_str" : "122305557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599956952429432832\/8y-IRC09_normal.png",
      "id" : 122305557,
      "verified" : false
    }
  },
  "id" : 336162187984896000,
  "created_at" : "2013-05-19 16:51:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336161702544551937",
  "text" : "\"\u5C0F\u91CE\u5BFA\u5149\"\u304C\u4E00\u4EBA\u3067\u306A\u3044\u3088\u3046\u306B\"\u306E\u306A\u3061\u3083\u3093\"\u3082\u4E00\u4EBA\u3067\u306A\u3044\u53EF\u80FD\u6027\u3001\u3044\u3084\u6982\u5FF5\u3068\u8A00\u3046\u7DDA\u3082\u3042\u308B\u3002",
  "id" : 336161702544551937,
  "created_at" : "2013-05-19 16:49:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336161242588798976",
  "text" : "\u79C1\u3082\u77E5\u308A\u305F\u3044",
  "id" : 336161242588798976,
  "created_at" : "2013-05-19 16:47:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 3, 14 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336161218437976065",
  "text" : "RT @nonamea774: emacs \u3067tex \u66F8\u304F\u6642\u306E\u3044\u3044\u611F\u3058\u306E\u8A2D\u5B9A\u4F55\u304B\u306A\u3044\u3067\u3059\u304B [auto-complete-mode \u3050\u3089\u3044\u3057\u304B\u5165\u308C\u3066\u3044\u306A\u3044]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336160624969134081",
    "text" : "emacs \u3067tex \u66F8\u304F\u6642\u306E\u3044\u3044\u611F\u3058\u306E\u8A2D\u5B9A\u4F55\u304B\u306A\u3044\u3067\u3059\u304B [auto-complete-mode \u3050\u3089\u3044\u3057\u304B\u5165\u308C\u3066\u3044\u306A\u3044]",
    "id" : 336160624969134081,
    "created_at" : "2013-05-19 16:45:13 +0000",
    "user" : {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "protected" : false,
      "id_str" : "122305557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599956952429432832\/8y-IRC09_normal.png",
      "id" : 122305557,
      "verified" : false
    }
  },
  "id" : 336161218437976065,
  "created_at" : "2013-05-19 16:47:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336160012919517184",
  "text" : "\u305D\u308C\u306F\u305D\u308C\u3068\u3057\u3066emacs\u306E\u64CD\u4F5C\u306B\u6163\u308C\u3066\u304A\u304F\u306E\u306F\u60AA\u304F\u306A\u3044[vim\u3082\u8AE6\u3081\u305F\u308F\u3051\u3067\u306F\u306A\u3044\u304C\u2026]",
  "id" : 336160012919517184,
  "created_at" : "2013-05-19 16:42:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336159841540255744",
  "text" : "\u305F\u3060\u307E\u3041\u30CE\u30FC\u30C8pc\u306E\u5DE6\u53F3\u306E\u30AD\u30FC\u30DC\u30FC\u30C9\u304C\u52B9\u304B\u306A\u3044\u90FD\u5408\u4E0Aemacs\u306E\u65B9\u304C\u826F\u3055\u305D\u3046\u306A\u306E\u3067\u3059\u3088",
  "id" : 336159841540255744,
  "created_at" : "2013-05-19 16:42:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336159516854976513",
  "text" : "\u81EA\u7531\u5EA6\u3068\u304B\u4ED6\u306E\u30D7\u30E9\u30B0\u30A4\u30F3\u3067\u30AB\u30B9\u30BF\u30E0\u3067\u304D\u308B\u3068\u3044\u3046\u70B9\u3067\u3001\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305Femacser\u306E\u901F\u5EA6\u306B\u306F\u305F\u3076\u3093\u52DD\u3066\u306A\u3044\u3051\u3069\u3001\u305F\u3060\u305D\u3053\u305D\u3053\u306E\u65E9\u3055\u3067tex\u3092\u6253\u3066\u308B\u3088\u3046\u306B\u306A\u308A\u305F\u3044\u3060\u3051\u306A\u3089texmaker\u306E\u65B9\u304C\u826F\u3055\u305D\u3046[\u52D5\u4F5C\u306E\u65E9\u3055\u3067\u306A\u304F]",
  "id" : 336159516854976513,
  "created_at" : "2013-05-19 16:40:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336158910400569344",
  "text" : "\u305D\u306E\u70B9texmaker\u306F\u30C7\u30D5\u30A9\u3067360\u8FD1\u304F\u5165\u3063\u3066\u305F\u304B\u3089\u795E\u30A8\u30C7\u30A3\u30BF\u3060\u3063\u305F\u306E\u3067\u306F.[\u81EA\u5206\u3067\u8FFD\u52A0\u3067\u304D\u308B\u3057\u3001\u305D\u308C\u3068\u306F\u3079\u3064\u306B\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u3082\u4F5C\u308C\u308B\u3057]",
  "id" : 336158910400569344,
  "created_at" : "2013-05-19 16:38:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336158671593676803",
  "text" : "autocomplete\u306Btex\u306E\u30B3\u30DE\u30F3\u30C9\u304C\u30C7\u30D5\u30A9\u30EB\u30C8\u3067\u5165\u3063\u3066\u308B\u306E\u304B\u3001\u5165\u3063\u3066\u305F\u3068\u3057\u3066\u3069\u306E\u4F4D\u5145\u5B9F\u3057\u3066\u308B\u306E\u304B\u3001\u306B\u3082\u4F9D\u308B\u3088\u306A\u30FC",
  "id" : 336158671593676803,
  "created_at" : "2013-05-19 16:37:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336158286309101569",
  "text" : "emacs\u306E\u5965\u6DF1\u3055\u3068\u95C7\u6DF1\u3055\u3092\u611F\u3058\u305F(?)[\u3053\u306E\u65E5\u307F\u305F\u95C7\u306F\u95C7\u3067\u306A\u3044\u3068\u50D5\u306F\u307E\u3060\u77E5\u3089\u306A\u3044]",
  "id" : 336158286309101569,
  "created_at" : "2013-05-19 16:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336157800940064769",
  "text" : "auto-complete\u3068\u306E\u9023\u643A\u8A2D\u5B9A\u3082\u3042\u308B\u6A21\u69D8\u3060\u304C\u60C5\u5F31\u306B\u3066\u3088\u304F\u308F\u304B\u3089\u3093\u307D\u3093\u3067\u3057\u305F(\u4ECA\u5F8C\u306E\u8AB2\u984C\u306A)",
  "id" : 336157800940064769,
  "created_at" : "2013-05-19 16:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336157413881294848",
  "text" : "\u4ED6\u4EBA\u304C\u4F5C\u3063\u305F\u306E\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3067\u3082\u826F\u3044\u306E\u3060\u304C\u771F\u306B\u9700\u8981\u306B\u5408\u308F\u305B\u308B\u3068\u81EA\u5206\u3067\u4F5C\u3063\u305F\u65B9\u304C\u826F\u3044\u3088\u306A\u2026",
  "id" : 336157413881294848,
  "created_at" : "2013-05-19 16:32:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336157267185508354",
  "text" : "yasnippet\u3068auto-complete\u3092\u5165\u308C\u305F\u3051\u3069\u5F8C\u8005\u306F\u3046\u307E\u304F\u52D5\u304B\u305A(\u7AF6\u5408\u3057\u3066\u308B\uFF1F)\u524D\u8005\u306F\u524D\u8005\u3067\u88DC\u5B8C\u7528\u306E\u30D5\u30A1\u30A4\u30EB\u3092\u4F5C\u3089\u306A\u304D\u3083\u306A\u3089\u306A\u3044\u6A21\u69D8",
  "id" : 336157267185508354,
  "created_at" : "2013-05-19 16:31:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336130749361168385",
  "text" : "\u4EBA\u6BBA\u8A9E\u4F7F\u3046\u3068\u30CB\u30F3\u30B8\u30E3\u30D8\u30C3\u30BA\u3092\u7099\u308A\u51FA\u305B\u308B\u3053\u3068\u306B\u6C17\u3065\u3044\u305F",
  "id" : 336130749361168385,
  "created_at" : "2013-05-19 14:46:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336130049294086147",
  "text" : "emacs\u30CB\u30E5\u30FC\u30D3\u30FC\u3060\u304B\u3089\u3046\u307E\u304F\u6271\u3048\u306A\u3044\u30B5\u30F3\u30B7\u30BF\u3081\u3044\u305F\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u91CD\u70B9",
  "id" : 336130049294086147,
  "created_at" : "2013-05-19 14:43:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336129370961899522",
  "geo" : { },
  "id_str" : "336129709979086848",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU \u4E00\u90E8\u306E\u6700\u5F8C\u7D50\u69CB\u71B1\u3044\u5C55\u958B\u306A\u306E\u3067\u305C\u3072\u305C\u3072",
  "id" : 336129709979086848,
  "in_reply_to_status_id" : 336129370961899522,
  "created_at" : "2013-05-19 14:42:22 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336128208577638400",
  "geo" : { },
  "id_str" : "336128566913806336",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU \u3068\u3044\u3046\u304B\u3081\u308B\u3059\u3055\u3093\u5FCD\u6BBA\u308F\u304B\u308B\u4EBA\u3060\u3063\u305F\u3093\u3067\u3059\u304B[\u50D5\u3082\u6700\u8FD1\u8AAD\u3093\u3060\u3070\u304B\u308A\u3067\u3059\u304C]",
  "id" : 336128566913806336,
  "in_reply_to_status_id" : 336128208577638400,
  "created_at" : "2013-05-19 14:37:49 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336128151891628032",
  "text" : "\u3055\u3055\u304F\u308C\u5148\u8F29\u30CE\u30EA\u304C\u826F\u3044\u304B\u3089\u611B\u3055\u308C\u3066\u3044\u308B\u3002\u9045\u523B\u3059\u308B\u3051\u3069\u3002",
  "id" : 336128151891628032,
  "created_at" : "2013-05-19 14:36:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79C1\u81EA\u8EAB\u8A00\u308F\u305A\u3082\u304C\u306A\u30D8\u30C3\u30C9\u30F3\u30DB\u30DB",
      "screen_name" : "ysgr_sasakure",
      "indices" : [ 0, 14 ],
      "id_str" : "281368452",
      "id" : 281368452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336127751255887873",
  "geo" : { },
  "id_str" : "336128013739634689",
  "in_reply_to_user_id" : 281368452,
  "text" : "@ysgr_sasakure \u3075\u3075\u3075\u3075\u3075\u3075",
  "id" : 336128013739634689,
  "in_reply_to_status_id" : 336127751255887873,
  "created_at" : "2013-05-19 14:35:38 +0000",
  "in_reply_to_screen_name" : "ysgr_sasakure",
  "in_reply_to_user_id_str" : "281368452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79C1\u81EA\u8EAB\u8A00\u308F\u305A\u3082\u304C\u306A\u30D8\u30C3\u30C9\u30F3\u30DB\u30DB",
      "screen_name" : "ysgr_sasakure",
      "indices" : [ 0, 14 ],
      "id_str" : "281368452",
      "id" : 281368452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336126479316422656",
  "geo" : { },
  "id_str" : "336127070205784064",
  "in_reply_to_user_id" : 281368452,
  "text" : "@ysgr_sasakure \u65B0\u8AAC\uFF1A\u3055\u3055\u304F\u308C\u5148\u8F29\u304C\u9045\u523B\u3059\u308B\u306E\u306F\u30B8\u30C8\u76EE\u3067\u898B\u3089\u308C\u305F\u3044\u304B\u3089",
  "id" : 336127070205784064,
  "in_reply_to_status_id" : 336126479316422656,
  "created_at" : "2013-05-19 14:31:53 +0000",
  "in_reply_to_screen_name" : "ysgr_sasakure",
  "in_reply_to_user_id_str" : "281368452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79C1\u81EA\u8EAB\u8A00\u308F\u305A\u3082\u304C\u306A\u30D8\u30C3\u30C9\u30F3\u30DB\u30DB",
      "screen_name" : "ysgr_sasakure",
      "indices" : [ 0, 14 ],
      "id_str" : "281368452",
      "id" : 281368452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336125580615512064",
  "geo" : { },
  "id_str" : "336125872882982912",
  "in_reply_to_user_id" : 281368452,
  "text" : "@ysgr_sasakure (\uFF7C\uFF9E\uFF84\uFF70)",
  "id" : 336125872882982912,
  "in_reply_to_status_id" : 336125580615512064,
  "created_at" : "2013-05-19 14:27:07 +0000",
  "in_reply_to_screen_name" : "ysgr_sasakure",
  "in_reply_to_user_id_str" : "281368452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336125428098035712",
  "geo" : { },
  "id_str" : "336125682927161344",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU \uFF71\uFF6F\uFF8A\uFF72",
  "id" : 336125682927161344,
  "in_reply_to_status_id" : 336125428098035712,
  "created_at" : "2013-05-19 14:26:22 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336125572751179777",
  "text" : "S2S\u306E\u4F8B\u4F1A\u3067\u805E\u3051\u308C\u3070\u3044\u3044\u3051\u308C\u3069\u3088\u304F\u8003\u3048\u305F\u3089emacser\u3063\u3066\u3044\u306A\u3044\u306E\u3067\u306F",
  "id" : 336125572751179777,
  "created_at" : "2013-05-19 14:25:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79C1\u81EA\u8EAB\u8A00\u308F\u305A\u3082\u304C\u306A\u30D8\u30C3\u30C9\u30F3\u30DB\u30DB",
      "screen_name" : "ysgr_sasakure",
      "indices" : [ 0, 14 ],
      "id_str" : "281368452",
      "id" : 281368452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336125021414117376",
  "geo" : { },
  "id_str" : "336125274267717633",
  "in_reply_to_user_id" : 281368452,
  "text" : "@ysgr_sasakure \u306A\u308B\u307B\u3069\u30FC(\uFF7C\uFF9E\uFF84\uFF70",
  "id" : 336125274267717633,
  "in_reply_to_status_id" : 336125021414117376,
  "created_at" : "2013-05-19 14:24:44 +0000",
  "in_reply_to_screen_name" : "ysgr_sasakure",
  "in_reply_to_user_id_str" : "281368452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336124626977558529",
  "geo" : { },
  "id_str" : "336124960047259649",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU \uFF72\uFF9D\uFF76\uFF9E\uFF75\uFF8E\uFF70",
  "id" : 336124960047259649,
  "in_reply_to_status_id" : 336124626977558529,
  "created_at" : "2013-05-19 14:23:30 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/E88q6SguiL",
      "expanded_url" : "http:\/\/togetter.com\/li\/427269",
      "display_url" : "togetter.com\/li\/427269"
    } ]
  },
  "geo" : { },
  "id_str" : "336124841180676097",
  "text" : "\u4E45\u3005\u306B\u672C\u5F53\u306B\u3072\u3069\u3044\u307E\u3068\u3081\u3092\u898B\u305F\u3002 \u3055\u3055\u304F\u308C\u5148\u8F29\u3001\u771F\u306E\u59FF http:\/\/t.co\/E88q6SguiL",
  "id" : 336124841180676097,
  "created_at" : "2013-05-19 14:23:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336124309489725440",
  "text" : "auto-complete\uFF08-latex\uFF09\u3059\u3054\u3044\u4FBF\u5229\u305D\u3046\u306A\u306E\u306B\u5168\u304F\u52D5\u304F\u6C17\u914D\u3092\u898B\u305B\u306A\u3044",
  "id" : 336124309489725440,
  "created_at" : "2013-05-19 14:20:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336124155630075904",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\uFF1F\uFF01\u30CA\u30F3\u30C7\uFF1F\uFF01\u30D7\u30E9\u30B0\u30A4\u30F3\u30A6\u30B4\u30AB\u30CA\u30A4\u30CA\u30F3\u30C7\uFF1F\uFF01",
  "id" : 336124155630075904,
  "created_at" : "2013-05-19 14:20:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336119616927584256",
  "text" : "\u3058\u3087\u3046\u3058\u3083\u304F\u3064\u3089\u3044\u306A",
  "id" : 336119616927584256,
  "created_at" : "2013-05-19 14:02:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336119559922798594",
  "text" : "\u30D7\u30E9\u30B0\u30A4\u30F3\u304C\u53CD\u6620\u3055\u308C\u306A\u3044\u306E\u3060\u304C\u4F55\u304C\u307E\u305A\u3044\u306E\u3060\u308D\u3046\u3002.emacs\u3082\u7DE8\u96C6\u3057\u3066\u308B\u306E\u306B\u3002",
  "id" : 336119559922798594,
  "created_at" : "2013-05-19 14:02:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336105040735502336",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8",
  "id" : 336105040735502336,
  "created_at" : "2013-05-19 13:04:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336104736648466432",
  "text" : "emacs\u306E\u30D7\u30E9\u30B0\u30A4\u30F3yasnippet\u3092\u5165\u308C\u3066\u307F\u305F\u3051\u3069\u3069\u3046\u3082\u52D5\u3044\u3066\u306A\u3044\u3063\u307D\u3044\u60C5\u5F31",
  "id" : 336104736648466432,
  "created_at" : "2013-05-19 13:03:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336089033828597760",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 336089033828597760,
  "created_at" : "2013-05-19 12:00:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336072405443284993",
  "text" : "\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u3068\u70CF\u9F8D\u8336\u3067\u6E80\u305F\u3055\u308C\u308B\u4EBA\u751F\u3060\u304B\u3089\u7D50\u69CB\u5B89\u4E0A\u304C\u308A\u3060\u3068\u601D\u3046",
  "id" : 336072405443284993,
  "created_at" : "2013-05-19 10:54:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336065278544855041",
  "text" : "\u4ECA\u65E5\u306E\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u3092\u4F5C\u308B",
  "id" : 336065278544855041,
  "created_at" : "2013-05-19 10:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336057230489165824",
  "text" : "\u5973\u6027\u5C02\u7528\u8ECA\u4E21\u3058\u3083\u306A\u3044\u3053\u3068\u306F\u308F\u304B\u3063\u3066\u305F\u304B\u3089\u305D\u306E\u4F4D\u306E\u5E74\u306E\u5973\u306E\u5B50\u304C\u305D\u3093\u306A\u3053\u3068\u3092\u3044\u3044\u3060\u3059\u3053\u3068\u306B\u30AE\u30E7\u30C3\u3068\u3057\u305F",
  "id" : 336057230489165824,
  "created_at" : "2013-05-19 09:54:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336057173505347586",
  "text" : "\u5C0F\u5B66\u6821\u4E2D\u5B66\u5E74\u304F\u3089\u3044\u306E\u5973\u306E\u5B50\u304C\u300C\u306A\u3093\u3067\u3053\u3053\u5973\u6027\u5C02\u7528\u8ECA\u4E21\u306A\u306E\u306B\u7537\u306E\u4EBA\u3044\u308B\u306E\uFF1F\u300D\u3063\u3066\u6BCD\u89AA\u306B\u805E\u3044\u3066\u3066\u30AE\u30E7\u30C3\u3068\u3057\u305F[\u4F11\u65E5\u3067\u3059\u3057]",
  "id" : 336057173505347586,
  "created_at" : "2013-05-19 09:54:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336055080463790080",
  "text" : "\u6642\u9593\u306E\u4F7F\u3044\u65B9\u304C\u4E0B\u624Bof the end",
  "id" : 336055080463790080,
  "created_at" : "2013-05-19 09:45:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336054837693263872",
  "text" : "\u8155\u306E\u4E00\u672C\u304F\u3089\u3044\u6301\u3063\u3066\u3044\u304B\u308C\u3066\u3082\u3044\u3044\u304B\u3089\u52C9\u5F37\u3067\u304D\u308B\u3088\u3046\u306B\u306A\u308A\u305F\u3044[\u3053\u3093\u306A\u3053\u3068\u8003\u3048\u308B\u6687\u304C\u3042\u3063\u305F\u3089\u52C9\u5F37\u3059\u3079\u304D]",
  "id" : 336054837693263872,
  "created_at" : "2013-05-19 09:44:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336054248192217088",
  "text" : "\u3082\u3046\u4E8C\u5EA6\u3068\u6674\u308C\u306A\u3044\u3088\u3046\u306A\u91CD\u305F\u3044\u7A7A\u6A21\u69D8 of the world",
  "id" : 336054248192217088,
  "created_at" : "2013-05-19 09:42:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336052960352141312",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u2026\u30A2\u30E1\u2026\u30A2\u30E1\u2026",
  "id" : 336052960352141312,
  "created_at" : "2013-05-19 09:37:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336051369951780865",
  "geo" : { },
  "id_str" : "336052620034732033",
  "in_reply_to_user_id" : 1086277044,
  "text" : "@minasemidori TL\u898B\u308B\u9650\u308A\u3044\u308D\u3093\u306A\u3068\u3053\u308D\u3067\u96E8\u3067\u3059\u306D[\u5927\u962A\u4EAC\u90FD\u6771\u4EAC\u3046\u3093\u306C\u3093]",
  "id" : 336052620034732033,
  "in_reply_to_status_id" : 336051369951780865,
  "created_at" : "2013-05-19 09:36:02 +0000",
  "in_reply_to_screen_name" : "soranomidori",
  "in_reply_to_user_id_str" : "1086277044",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suiminngakushuu",
      "screen_name" : "suiminngakushuu",
      "indices" : [ 0, 16 ],
      "id_str" : "473882586",
      "id" : 473882586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336051881908527104",
  "geo" : { },
  "id_str" : "336052425972645888",
  "in_reply_to_user_id" : 473882586,
  "text" : "@suiminngakushuu \u975E\u30CB\u30F3\u30B8\u30E3\u5B58\u5728\u306A\u306E\u3067\u96E8\u3092\u907F(\u3088)\u3051\u308B\u306E\u306F\u7121\u7406\u3067\u3057",
  "id" : 336052425972645888,
  "in_reply_to_status_id" : 336051881908527104,
  "created_at" : "2013-05-19 09:35:16 +0000",
  "in_reply_to_screen_name" : "suiminngakushuu",
  "in_reply_to_user_id_str" : "473882586",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336051241908072448",
  "text" : "\u96E8\u3092\u56DE\u907F\u3059\u308B\u306E\u7121\u7406\u305D\u3046",
  "id" : 336051241908072448,
  "created_at" : "2013-05-19 09:30:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336050941683978240",
  "geo" : { },
  "id_str" : "336051085909307392",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u5F8C\u534A\u3078\u7D9A\u304F",
  "id" : 336051085909307392,
  "in_reply_to_status_id" : 336050941683978240,
  "created_at" : "2013-05-19 09:29:57 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336049764800020480",
  "text" : "\u96E8\u3092\u56DE\u907F\u3059\u308B\u30DE\u30F3\u306F\u96E8\u3092\u56DE\u907F\u3059\u308B\u3088\uFF1F",
  "id" : 336049764800020480,
  "created_at" : "2013-05-19 09:24:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336049514823708672",
  "text" : "\u7D42\u70B9\u307E\u3067",
  "id" : 336049514823708672,
  "created_at" : "2013-05-19 09:23:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335959321491931136",
  "text" : "\u73FE\u5B9F\u306E\u4F1A\u8A71\u306A\u3089\u5272\u3068\u52B9\u679C\u7684",
  "id" : 335959321491931136,
  "created_at" : "2013-05-19 03:25:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335959291850801152",
  "text" : "\u96D1\u3067\u3042\u308B\u3053\u3068\u304C\u9762\u767D\u307F\u3092\u751F\u3080\u306E\u306F(\u6587\u7AE0\u3092\u6295\u3052\u5408\u3046Twitter\u3067\u306F)\u96E3\u3057\u3044",
  "id" : 335959291850801152,
  "created_at" : "2013-05-19 03:25:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335958893811347456",
  "text" : "\u3075\u308A\u304C\u96D1\u3060\u3068\u8FD4\u3057\u3082\u96D1\u306B\u306A\u308B\u3088\u306D\u3047",
  "id" : 335958893811347456,
  "created_at" : "2013-05-19 03:23:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335958628836196352",
  "geo" : { },
  "id_str" : "335958724395016192",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u3042\u3063\u306F\u3044",
  "id" : 335958724395016192,
  "in_reply_to_status_id" : 335958628836196352,
  "created_at" : "2013-05-19 03:22:56 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335957874993930241",
  "geo" : { },
  "id_str" : "335958403736281090",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 10\u5206\u307B\u3069\u524D\u306B\u7740\u304D\u307E\u3057\u305F(\u771F\u9854)",
  "id" : 335958403736281090,
  "in_reply_to_status_id" : 335957874993930241,
  "created_at" : "2013-05-19 03:21:39 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335957756211261440",
  "text" : "30\u5206\u3082\u65E9\u304F\u3064\u3044\u3066\u3057\u307E\u3063\u305F\u3089\u3057\u3044",
  "id" : 335957756211261440,
  "created_at" : "2013-05-19 03:19:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335950091879849984",
  "geo" : { },
  "id_str" : "335950696190971904",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u3067\u306F\u305D\u3046\u3067\u306A\u3044\u306E\u3067\u3057\u3087\u3046",
  "id" : 335950696190971904,
  "in_reply_to_status_id" : 335950091879849984,
  "created_at" : "2013-05-19 02:51:02 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335949679181324288",
  "text" : "\u306A\u305C\u306A\u3089\u5168\u65B9\u4F4D\u306B\u98DB\u3076\u304B\u3089",
  "id" : 335949679181324288,
  "created_at" : "2013-05-19 02:46:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335949598440955904",
  "text" : "\u5168\u65B9\u4F4D\u30EA\u30D7\u306F\u5168\u65B9\u4F4D\u306B\u523A\u3055\u308B",
  "id" : 335949598440955904,
  "created_at" : "2013-05-19 02:46:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335949237437202432",
  "geo" : { },
  "id_str" : "335949520951197696",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u305D\u3046\u601D\u3046\u306A\u3089\u305D\u3046\u3067\u3057\u3087\u3046\uFF1F",
  "id" : 335949520951197696,
  "in_reply_to_status_id" : 335949237437202432,
  "created_at" : "2013-05-19 02:46:22 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335949119057178624",
  "text" : "\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u9762\u767D\u304F\u306A\u3044\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y\uFFE3",
  "id" : 335949119057178624,
  "created_at" : "2013-05-19 02:44:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335946359783968768",
  "text" : "\u808C\u5BD2\u3044\u7A0B\u5EA6\u306E\u670D\u88C5of the world",
  "id" : 335946359783968768,
  "created_at" : "2013-05-19 02:33:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335945897504538624",
  "geo" : { },
  "id_str" : "335946012294270976",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u96E8\u304C\u964D\u308A\u305D\u3046\u3001\u306A",
  "id" : 335946012294270976,
  "in_reply_to_status_id" : 335945897504538624,
  "created_at" : "2013-05-19 02:32:25 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335945932606693376",
  "text" : "\u6587\u5EAB\u672C\u6301\u3063\u3066\u3053\u306A\u304B\u3063\u305F\u306E\u304C\u5931\u6557",
  "id" : 335945932606693376,
  "created_at" : "2013-05-19 02:32:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335945616490385408",
  "text" : "\u96E8\u3081\u304F\u7A7A\u6A21\u69D8\u306A",
  "id" : 335945616490385408,
  "created_at" : "2013-05-19 02:30:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335945093007699968",
  "text" : "\u5411\u304B\u3044\u306B\u5EA7\u3063\u305F\u7537\u5973\u3001\u540C\u6642\u306B\u6765\u305F\u304B\u3089\u30AB\u30C3\u30D7\u30EB\u304B\u4F55\u304B\u304B\u3068\u601D\u3063\u305F\u304C\u5973\u6027\u306E\u65B9\u3060\u3051\u304C\u98AF\u723D\u3068\u304A\u308A\u3066\u884C\u3063\u305F\u304B\u3089\u3069\u3046\u3082\u9055\u3046\u3089\u3057\u3044[\u3088\u304F\u8003\u3048\u308C\u3070\u4E00\u8A00\u3082\u3057\u3083\u3079\u3063\u3066\u306A\u304B\u3063\u305F]",
  "id" : 335945093007699968,
  "created_at" : "2013-05-19 02:28:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335939736826961921",
  "text" : "\u4E16\u754C\u306B\u5BFE\u3057\u3066\u3057\u3070\u3057\u3070\u7533\u3057\u8A33 of the world",
  "id" : 335939736826961921,
  "created_at" : "2013-05-19 02:07:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335931223446786048",
  "text" : "\u3053\u308C\u4EE5\u4E0A(\u4E8C\u5EA6\u5BDD\u3092\u7E70\u308A\u8FD4\u3057\u3066\u306F)\u3044\u3051\u306A\u3044",
  "id" : 335931223446786048,
  "created_at" : "2013-05-19 01:33:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335753990031675392",
  "text" : "\u732B\u3068\u304B\u72AC\u3068\u304B\u732B\u3068\u622F\u308C\u305F\u3044",
  "id" : 335753990031675392,
  "created_at" : "2013-05-18 13:49:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335753537017479169",
  "text" : "\u5225\u306B\u4ECA\u3059\u3050\u7D44\u3080\u308F\u3051\u3058\u3083\u306A\u3044\u304C",
  "id" : 335753537017479169,
  "created_at" : "2013-05-18 13:47:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335753481623310336",
  "text" : "[\u3086\u308B\u307C]\u4FBF\u5229\u306ATeX\u306E\u30DE\u30AF\u30ED\u306E\u7A2E\u985E",
  "id" : 335753481623310336,
  "created_at" : "2013-05-18 13:47:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335744952581648385",
  "text" : "\u306D\u3001\u7720\u3044",
  "id" : 335744952581648385,
  "created_at" : "2013-05-18 13:13:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335733391964119042",
  "text" : "\u4F55\u304B\u8A00\u3063\u305F\u3042\u3068\u306B\u6ED1\u3063\u305F\u611F\u3058\u3092\u5BDF\u3057\u305F\u3089\u300C\u4EE5\u4E0A\u3067\u3059\uFF01\u300D\u3063\u3066\u8A00\u3046\u3068\u826F\u3044",
  "id" : 335733391964119042,
  "created_at" : "2013-05-18 12:27:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335732443275476992",
  "text" : "\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E \u3044\u307E\u306E\u306A\u3057 \uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y\uFFE3",
  "id" : 335732443275476992,
  "created_at" : "2013-05-18 12:23:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335732367673131009",
  "text" : "\u3044\u307E\u306E\u306A\u3057",
  "id" : 335732367673131009,
  "created_at" : "2013-05-18 12:23:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335732286832140289",
  "text" : "\u75C5\u9662\u3063\u3066\u85AC\u81ED\u3044\u3088\u306D",
  "id" : 335732286832140289,
  "created_at" : "2013-05-18 12:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335732244998148096",
  "text" : "\u533B\u5B66\u90E8\u751F\u3063\u307D\u3044\u30C4\u30A4\u30FC\u30C8\u3057\u307E\u30FC\u3059",
  "id" : 335732244998148096,
  "created_at" : "2013-05-18 12:22:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "muramasakazu",
      "screen_name" : "muramasakazu",
      "indices" : [ 0, 13 ],
      "id_str" : "2552538733",
      "id" : 2552538733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335731015848976385",
  "geo" : { },
  "id_str" : "335731202193489921",
  "in_reply_to_user_id" : 428905830,
  "text" : "@muramasakazu \u8EAB\u3092\u6301\u3063\u3066\u5B66\u3076\u3079\u3057[\u3046\u3057\u3046\u3057\u306F\u3059\u3054\u3044]",
  "id" : 335731202193489921,
  "in_reply_to_status_id" : 335731015848976385,
  "created_at" : "2013-05-18 12:18:50 +0000",
  "in_reply_to_screen_name" : "REIN_LIEBEN",
  "in_reply_to_user_id_str" : "428905830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335730834566963201",
  "text" : "\u9AD8\u5EA6\u306A\u60C5\u5831\u6226\u306A",
  "id" : 335730834566963201,
  "created_at" : "2013-05-18 12:17:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335730784113684481",
  "text" : "\u306E\u3046\u3053\u3055\u3093\u304C\u533B\u5B66\u90E8\u3068\u304B\u8A00\u3046\u30C7\u30DE\u6D41\u3059\u306E\u826F\u304F\u306A\u3044\u3068\u601D\u3046",
  "id" : 335730784113684481,
  "created_at" : "2013-05-18 12:17:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "muramasakazu",
      "screen_name" : "muramasakazu",
      "indices" : [ 0, 13 ],
      "id_str" : "2552538733",
      "id" : 2552538733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335730533650796544",
  "geo" : { },
  "id_str" : "335730669147795456",
  "in_reply_to_user_id" : 428905830,
  "text" : "@muramasakazu \u3055\u3059\u304C\u306B\u8AA0\u610F\u3092\u898B\u305B\u305F\u65B9\u304C\u3044\u3044\u306E\u3067\u306F[1000\u70B9\u4F9B\u8A17\u306A]",
  "id" : 335730669147795456,
  "in_reply_to_status_id" : 335730533650796544,
  "created_at" : "2013-05-18 12:16:43 +0000",
  "in_reply_to_screen_name" : "REIN_LIEBEN",
  "in_reply_to_user_id_str" : "428905830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "muramasakazu",
      "screen_name" : "muramasakazu",
      "indices" : [ 0, 13 ],
      "id_str" : "2552538733",
      "id" : 2552538733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335730275759833090",
  "geo" : { },
  "id_str" : "335730361810169858",
  "in_reply_to_user_id" : 428905830,
  "text" : "@muramasakazu \u3046\u3057\u3046\u3057\u306F\u307B\u3093\u3068\u3046\u306B\u3059\u3054\u3044",
  "id" : 335730361810169858,
  "in_reply_to_status_id" : 335730275759833090,
  "created_at" : "2013-05-18 12:15:30 +0000",
  "in_reply_to_screen_name" : "REIN_LIEBEN",
  "in_reply_to_user_id_str" : "428905830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335730271792017410",
  "text" : "\u30BF\u30FC\u30AD\u30FC\u30D6\u30EC\u30B9\u30C8\u306F\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u306B\u306A\u308B\u305F\u3081\u306B\u3046\u307E\u308C\u3066\u304D\u305F\u98DF\u6750",
  "id" : 335730271792017410,
  "created_at" : "2013-05-18 12:15:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335730118486028288",
  "geo" : { },
  "id_str" : "335730237021245441",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u306F\u3044\uFF0E[\u30BF\u30FC\u30AD\u30FC\u30D6\u30EC\u30B9\u30C8\u306F\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u306B\u306A\u308B\u305F\u3081\u306B\u3046\u307E\u308C\u3066\u304D\u305F\u98DF\u6750\u3067\u3059\u306D]",
  "id" : 335730237021245441,
  "in_reply_to_status_id" : 335730118486028288,
  "created_at" : "2013-05-18 12:15:00 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335729716050919425",
  "text" : "\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u306A\u30891\u5E74\u98DF\u3079\u7D9A\u3051\u3066\u3082\u98FD\u304D\u306A\u3044\u81EA\u4FE1\u3042\u308B",
  "id" : 335729716050919425,
  "created_at" : "2013-05-18 12:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335729000020332544",
  "text" : "\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u3068\u30C9\u30AF\u307A\u306E\u30B8\u30E3\u30F3\u30AF\u611F\u3084\u3070\u3044\uFF0E\u304C\u30EC\u30BF\u30B9\u3068\u30C8\u30DE\u30C8\u3068\u30D4\u30FC\u30DE\u30F3\u305F\u3063\u3077\u308A\uFF0E",
  "id" : 335729000020332544,
  "created_at" : "2013-05-18 12:10:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335728643705819136",
  "text" : "\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u3046\u3081\u3047\u3047\u3047\u3047\u3047\u3047\u3047\u3047\u3047\u3047\u3047\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 335728643705819136,
  "created_at" : "2013-05-18 12:08:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335726638052540417",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 335726638052540417,
  "created_at" : "2013-05-18 12:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335632727577612290",
  "text" : "\u5FC3\u7DBA\u697C\u3001\u767D\u84EE\u3067\u308B\u306E\u304B",
  "id" : 335632727577612290,
  "created_at" : "2013-05-18 05:47:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNIpGD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335625298919960578",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNIpGD",
  "id" : 335625298919960578,
  "created_at" : "2013-05-18 05:18:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335372756126408704",
  "text" : "\u3067\u3082\u3082\u3046\u3061\u3087\u3044\u9811\u5F35\u308B",
  "id" : 335372756126408704,
  "created_at" : "2013-05-17 12:34:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335372722542620673",
  "text" : "\u3053\u3061\u3068\u30894\u6642\u9593\u534A\u306E\u7761\u7720\u3067\u4E00\u65E5\u9811\u5F35\u3063\u3066\u304D\u305F\u3093\u3058\u3083\u3053\u3089",
  "id" : 335372722542620673,
  "created_at" : "2013-05-17 12:34:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335372567001067520",
  "text" : "\u5E30\u5B85\u3057\u3066\u96A3\u4EBA\u304C\u3046\u308B\u3055\u3044\u3067\u3042\u308D\u3046\u3053\u3068\u3092\u899A\u609F\u3057\u305F[\u5B9F\u969B\u91D1\u66DC\u591C\u306A]",
  "id" : 335372567001067520,
  "created_at" : "2013-05-17 12:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335242259345833985",
  "text" : "\u663C\u98DF\u3092\u7D4C\u3066\u7761\u9B54\u306E\u30D1\u30EF\u30FC\u30A2\u30C3\u30D7\u304C\u61F8\u5FF5\u3055\u308C\u308B",
  "id" : 335242259345833985,
  "created_at" : "2013-05-17 03:55:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335242168744693760",
  "text" : "\u7761\u9B54\u3068\u306E\u653B\u9632\u3001\u5F8C\u534A\u6226\u306B\u7D9A\u304F",
  "id" : 335242168744693760,
  "created_at" : "2013-05-17 03:55:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335002624128598018",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 335002624128598018,
  "created_at" : "2013-05-16 12:03:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334892284489383937",
  "text" : "15\u6642\u958B\u5E55\u3092\u76EE\u6A19\u306B[\u65E9\u3044\u5206\u306B\u306F\u826F\u3057]",
  "id" : 334892284489383937,
  "created_at" : "2013-05-16 04:45:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334892156898660352",
  "text" : "\u3054\u306F\u3093\u708A\u3044\u3066\u3001\u6D17\u6FEF\u6A5F\u56DE\u3057\u3066\u3001\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u3001\u3054\u306F\u3093\u98DF\u3079\u3066\u3001\u30B3\u30FC\u30D2\u30FC\u98F2\u3093\u3067\u52C9\u5F37\u3057\u3088",
  "id" : 334892156898660352,
  "created_at" : "2013-05-16 04:44:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334742621937348608",
  "text" : "\u4ECA\u6708\u306E\u30C6\u30FC\u30DE\u306F\"\u914D\u616E\"",
  "id" : 334742621937348608,
  "created_at" : "2013-05-15 18:50:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334741387536908288",
  "text" : "\u78BA\u5B9F\u306B\u300C(\u4E2D\u8EAB\u306E\u306A\u3044\u3053\u3068\u3092)\u3088\u304F\u558B\u308B\u5148\u8F29\u300D\u3068\u8A00\u3046\u30A4\u30E1\u30FC\u30B8\u3092\u4E0E\u3048\u305F",
  "id" : 334741387536908288,
  "created_at" : "2013-05-15 18:45:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334741028068270080",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u4E00\u56DE\u751F\u306B\"\u4E2D\u8EAB\u306E\u306A\u3044\u4F1A\u8A71\"\u3092\u307E\u304F\u3057\u7ACB\u3066\u305F\u4EF6\u306B\u3064\u3044\u3066\u306F\u3061\u3087\u3063\u3068\u53CD\u7701\u3057\u3066\u3044\u307E\u3059",
  "id" : 334741028068270080,
  "created_at" : "2013-05-15 18:44:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 8, 11 ]
    }, {
      "text" : "\u662F\u975E",
      "indices" : [ 12, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334739382680555520",
  "geo" : { },
  "id_str" : "334739855529623552",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 #\u306F\u3044 #\u662F\u975E",
  "id" : 334739855529623552,
  "in_reply_to_status_id" : 334739382680555520,
  "created_at" : "2013-05-15 18:39:35 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334738774862987265",
  "text" : "\u9EBB\u96C0\u3068\u304B\u3084\u3063\u3066\u308B\u5834\u5408\u3058\u3083\u306A\u3044\u306A\uFF1F",
  "id" : 334738774862987265,
  "created_at" : "2013-05-15 18:35:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334738674405236736",
  "text" : "1-1-1-2-1\u3067\u7406\u60F3\u7684\u306A\u9EBB\u96C0\u3067\u3057\u305F:\u6559\u8A13\u306F\u30AB\u30F3\u306F\u3057\u3059\u304E\u306A\u3044\u3053\u3068",
  "id" : 334738674405236736,
  "created_at" : "2013-05-15 18:34:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334606447725907968",
  "text" : "\u713C\u3044\u305F\u8089\u306F\u3053\u308C\u3059\u306A\u308F\u3061\u713C\u8089\u3067\u3042\u308B\uFF1F",
  "id" : 334606447725907968,
  "created_at" : "2013-05-15 09:49:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334606408685338624",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u307F\u3093\u306A\u3088\u308A\u306F\u3084\u304F\u3064\u3044\u305F\u306A\uFF1F",
  "id" : 334606408685338624,
  "created_at" : "2013-05-15 09:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334606112026394624",
  "text" : "\u713C\u304D\u91CE\u83DC\u304C\u98DF\u3044\u305F\u3051\u308C\u3070\u713C\u304D\u91CE\u83DC\u5C4B\u306B\u884C\u3051\u3070\u3044\u3044\u3093\u3060",
  "id" : 334606112026394624,
  "created_at" : "2013-05-15 09:48:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334513824633851904",
  "geo" : { },
  "id_str" : "334605987199733760",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u3070\u98DF\u3079\u306B\u884C\u304F(^^)(^^)(^^)(^^)(^^)",
  "id" : 334605987199733760,
  "in_reply_to_status_id" : 334513824633851904,
  "created_at" : "2013-05-15 09:47:38 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334464995737862144",
  "geo" : { },
  "id_str" : "334465150314758144",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4E16\u9593\u306F\u51B7\u305F\u3044\u305E\uFF1F",
  "id" : 334465150314758144,
  "in_reply_to_status_id" : 334464995737862144,
  "created_at" : "2013-05-15 00:28:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334463529044279296",
  "text" : "\u4E94\u6708\u3060\u3068\u8A00\u3046\u306E\u306B\u3053\u306E\u71B1\u3055\u306F\u2026",
  "id" : 334463529044279296,
  "created_at" : "2013-05-15 00:21:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334461438993260545",
  "text" : "\u4ED9\u53F0\u306E\u854E\u9EA6\u5C4B\u3055\u3093\u3067\u5375\u306E\u3066\u3093\u3076\u3089\u3068\u305D\u3070\u3092\u98DF\u3079\u305F\u5922\u898B\u305F(\u5473\u304C\u6FC3\u304B\u3063\u305F)",
  "id" : 334461438993260545,
  "created_at" : "2013-05-15 00:13:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334461226811809793",
  "text" : "\u4EAC\u90FD\u4ED9\u53F0\u6771\u4EAC\u304C(\u7121\u7406\u3057\u3066)\u6B69\u3051\u3070\u6B69\u3051\u308B\u8DDD\u96E2\u306B\u306A\u3063\u3066\u308B\u5922\u307F\u305F",
  "id" : 334461226811809793,
  "created_at" : "2013-05-15 00:12:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334460444695728129",
  "text" : "\u9019\u3044\u5BC4\u308B\u7761\u9B54\u304C\u7720\u3044(?)",
  "id" : 334460444695728129,
  "created_at" : "2013-05-15 00:09:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334459776798978049",
  "text" : "\u306D\u3080\u305F\u3044\u306D\u3080\u305F\u3044\u306D\u3080\u3044\u306D\u3080\u3044",
  "id" : 334459776798978049,
  "created_at" : "2013-05-15 00:06:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334341410390155265",
  "text" : "\u4E16\u306E\u4E2D\u306B\u306F\u305F\u3060\u53D7\u3051\u5165\u308C\u306A\u304F\u3061\u3083\u306A\u3089\u306A\u3044\u3053\u3068\u304C\u305F\u304F\u3055\u3093\u3042\u308B\u3053\u3068\u3060\u306A\u3041(\u3048\u3044\u305F\u3093)",
  "id" : 334341410390155265,
  "created_at" : "2013-05-14 16:16:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334340810004910080",
  "text" : "\u3069\u3093\u306A\u5C0F\u3055\u306A\u7406\u7531\u3067\u3082\u6587\u53E5\u306F\u8A00\u3048\u306A\u3044",
  "id" : 334340810004910080,
  "created_at" : "2013-05-14 16:13:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334340758398177282",
  "text" : "\u30EA\u30E0\u30FC\u30D6\u3059\u308B\u306E\u3082\u30D6\u30ED\u30C3\u30AF\u3059\u308B\u306E\u3082\u3001\u30EA\u30E0\u30FC\u30D6\u3055\u308C\u308B\u306E\u3082\u30D6\u30ED\u30C3\u30AF\u3055\u308C\u308B\u306E\u3082\u305D\u308C\u76F8\u5FDC\u306E\u7406\u7531\u304C\u3042\u308B\u3060\u308D\u3046\u3057\u3001\u53D7\u3051\u5165\u308C\u308B\u3057\u304B\u306A\u3044\u3068\u601D\u3063\u3066\u3044\u308B",
  "id" : 334340758398177282,
  "created_at" : "2013-05-14 16:13:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334339831662510080",
  "text" : "\u30D3\u30F3\u306E\u30C7\u30B6\u30A4\u30F3\u304C\u5B9F\u969B\u7D20\u6575",
  "id" : 334339831662510080,
  "created_at" : "2013-05-14 16:10:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334339745675096064",
  "text" : "\u5B9F\u5BB6\u3067\u4F55\u5E74\u3082\u4F55\u5E74\u3082\u7720\u3063\u3066\u3044\u305F\u3068\u601D\u3057\u304D\u30A6\u30A3\u30B9\u30AD\u30FC\u3092\u958B\u3051\u308B[\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u30ED\u30FC\u30E4\u30EB15\u5E74\u306E\u6A21\u69D8]",
  "id" : 334339745675096064,
  "created_at" : "2013-05-14 16:09:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334288481092268033",
  "text" : "\u3067\u3082\u4E2D\u8EAB\u306A\u3044\u306A",
  "id" : 334288481092268033,
  "created_at" : "2013-05-14 12:45:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334288439312797696",
  "text" : "\u4E2D\u8EAB\u306E\u306A\u3044\u4F1A\u8A71\u306B\u304B\u3051\u3066\u306F\u81EA\u4FE1\u3042\u308B",
  "id" : 334288439312797696,
  "created_at" : "2013-05-14 12:45:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334287834087301120",
  "text" : "Skype\u306F\u4F55\u3082\u8003\u3048\u305A\u306B\u627F\u8A8D\u6295\u3052\u308B",
  "id" : 334287834087301120,
  "created_at" : "2013-05-14 12:43:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334287236231225344",
  "text" : "\u30B0\u30EC\u30FC\u30D7\u30D5\u30EB\u30FC\u30C4\u30B8\u30E5\u30FC\u30B9\uFF54\uFF42\uFF54\uFF42",
  "id" : 334287236231225344,
  "created_at" : "2013-05-14 12:41:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334286699867799553",
  "text" : "0\u6642\u5BDD\u30667\u6642\u306B\u8D77\u304D\u308B\u30DE\u30F3\u306B\u300C\u4E00\u9650\u51FA\u308B\u306E\u306F\u5F53\u305F\u308A\u524D\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u300D\u3068\u8A00\u308F\u308C\u3066\u5373\u6B7B",
  "id" : 334286699867799553,
  "created_at" : "2013-05-14 12:38:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334277031372132352",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 334277031372132352,
  "created_at" : "2013-05-14 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/tP2RtMVifb",
      "expanded_url" : "http:\/\/4sq.com\/12wzkXm",
      "display_url" : "4sq.com\/12wzkXm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "334218318103851008",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/tP2RtMVifb",
  "id" : 334218318103851008,
  "created_at" : "2013-05-14 08:07:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334182715488358401",
  "text" : "\u3053\u3053\u304B\u3089\u3042\u30681\u30DA\u30FC\u30B8\u3082\u524A\u308B\u306E\u304B\u2026",
  "id" : 334182715488358401,
  "created_at" : "2013-05-14 05:45:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334175988126720002",
  "text" : "\u3080\u3057\u308D\u4E00\u4EBA\u3067\u3054\u98EF\u98DF\u3079\u308C\u306A\u3044\u4EBA\u306F\u3061\u3087\u3063\u3068\u30A2\u30EC\u306A\u6C17\u304C\u304C\u304C",
  "id" : 334175988126720002,
  "created_at" : "2013-05-14 05:18:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334175760048852993",
  "text" : "\u5B9F\u969B\u4E00\u4EBA\u3067\u3054\u98EF\u98DF\u3079\u308B\u306E\u7D50\u69CB\u597D\u304D\u306A\u3093\u3060\u3051\u3069\u3053\u308C\u306F\u30DE\u30A4\u30CE\u30EA\u30C6\u30A3\u30FC\u306A\u306E\u304B(\u3044\u3084\u305D\u3093\u306A\u3053\u3068\u306F\u306A\u3044)",
  "id" : 334175760048852993,
  "created_at" : "2013-05-14 05:18:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334175137718996992",
  "text" : "\u6357\u3089\u306A\u307F\u304C\u6357\u3063\u3066\u308B\u3001\u3064\u307E\u308A\u6357\u3063\u3066\u3044\u306A\u3044",
  "id" : 334175137718996992,
  "created_at" : "2013-05-14 05:15:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334173752109694976",
  "geo" : { },
  "id_str" : "334173998701223937",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u307C\u3063\u3061\u98EF\u3092\u6065\u3058\u3066\u306F\u306A\u3089\u306A\u3044(\u6212\u3081)",
  "id" : 334173998701223937,
  "in_reply_to_status_id" : 334173752109694976,
  "created_at" : "2013-05-14 05:11:04 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334173086414946304",
  "text" : "\u30A2\u30AF\u30B7\u30E7\u30F3=\u30DD\u30C6\u30F3\u30B7\u30E3\u30EB",
  "id" : 334173086414946304,
  "created_at" : "2013-05-14 05:07:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334172995042045952",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\uFF1F\uFF01\u30AB\u30C4\u30C9\u30A6\u30C7\u30F3\u30A4\uFF1F\uFF01\u30AB\u30C4\u30C9\u30A6\u30C7\u30F3\u30A4\u30CA\u30F3\u30C7\uFF1F\uFF01",
  "id" : 334172995042045952,
  "created_at" : "2013-05-14 05:07:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3083\u308B",
      "screen_name" : "_shalu_",
      "indices" : [ 3, 11 ],
      "id_str" : "111832032",
      "id" : 111832032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_shalu_\/status\/334170152075661312\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/toXKNhtpB1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKM1-5lCEAEgHx9.jpg",
      "id_str" : "334170152079855617",
      "id" : 334170152079855617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKM1-5lCEAEgHx9.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 771
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 771
      } ],
      "display_url" : "pic.twitter.com\/toXKNhtpB1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334172007824490497",
  "text" : "RT @_shalu_: http:\/\/t.co\/toXKNhtpB1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_shalu_\/status\/334170152075661312\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/toXKNhtpB1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKM1-5lCEAEgHx9.jpg",
        "id_str" : "334170152079855617",
        "id" : 334170152079855617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKM1-5lCEAEgHx9.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 771
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 771
        } ],
        "display_url" : "pic.twitter.com\/toXKNhtpB1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334170152075661312",
    "text" : "http:\/\/t.co\/toXKNhtpB1",
    "id" : 334170152075661312,
    "created_at" : "2013-05-14 04:55:47 +0000",
    "user" : {
      "name" : "\u3057\u3083\u308B",
      "screen_name" : "_shalu_",
      "protected" : false,
      "id_str" : "111832032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535121801618014208\/YriwYBCa_normal.png",
      "id" : 111832032,
      "verified" : false
    }
  },
  "id" : 334172007824490497,
  "created_at" : "2013-05-14 05:03:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334166980309426177",
  "text" : "\u308A\u3060\u3063",
  "id" : 334166980309426177,
  "created_at" : "2013-05-14 04:43:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334166811572584448",
  "text" : "\u7537\u6027\u306E\u96C6\u5408\u304B\u3089\u5973\u6027\u306E\u96C6\u5408\u3078\u306E\u5199\u50CF\u304C\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u30A8",
  "id" : 334166811572584448,
  "created_at" : "2013-05-14 04:42:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334166033193656320",
  "text" : "\u5B58\u5728\u3059\u308C\u3070\uFF0E\uFF0E\uFF0E",
  "id" : 334166033193656320,
  "created_at" : "2013-05-14 04:39:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "indices" : [ 3, 13 ],
      "id_str" : "139971386",
      "id" : 139971386
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 15, 31 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334166006673055744",
  "text" : "RT @pochipink: @Jelly_in_a_tank \u6771\u5317\u5927M\uFF11\u306E\u6570\u5B66\u7CFB\u306F\u5973\u6027\uFF10\u4EBA\u3067\u3059\u7B11",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
        "screen_name" : "Jelly_in_a_tank",
        "indices" : [ 0, 16 ],
        "id_str" : "138430452",
        "id" : 138430452
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "334165662597517313",
    "geo" : { },
    "id_str" : "334165842885476352",
    "in_reply_to_user_id" : 138430452,
    "text" : "@Jelly_in_a_tank \u6771\u5317\u5927M\uFF11\u306E\u6570\u5B66\u7CFB\u306F\u5973\u6027\uFF10\u4EBA\u3067\u3059\u7B11",
    "id" : 334165842885476352,
    "in_reply_to_status_id" : 334165662597517313,
    "created_at" : "2013-05-14 04:38:40 +0000",
    "in_reply_to_screen_name" : "Jelly_in_a_tank",
    "in_reply_to_user_id_str" : "138430452",
    "user" : {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "protected" : true,
      "id_str" : "139971386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576397464820789248\/Ns-Cf1nH_normal.jpeg",
      "id" : 139971386,
      "verified" : false
    }
  },
  "id" : 334166006673055744,
  "created_at" : "2013-05-14 04:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334165882026733569",
  "text" : "\u5B58\u5728\u3059\u308C\u3070\u4E00\u610F\u30FB\u30FB\u30FB\u30A2\u30A4\u30A8\u30A8\u30A8",
  "id" : 334165882026733569,
  "created_at" : "2013-05-14 04:38:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3060\u30FC\u3059\u306A",
      "screen_name" : "DarknessCatX",
      "indices" : [ 0, 13 ],
      "id_str" : "258868251",
      "id" : 258868251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334165406459777024",
  "geo" : { },
  "id_str" : "334165450336382977",
  "in_reply_to_user_id" : 258868251,
  "text" : "@DarknessCatX \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 334165450336382977,
  "in_reply_to_status_id" : 334165406459777024,
  "created_at" : "2013-05-14 04:37:06 +0000",
  "in_reply_to_screen_name" : "DarknessCatX",
  "in_reply_to_user_id_str" : "258868251",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3046\u3057\u3046\u3057\u306F\u307B\u3093\u3068\u3046\u306B\u3059\u3054\u3044",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334163751169298432",
  "text" : "#\u3046\u3057\u3046\u3057\u306F\u307B\u3093\u3068\u3046\u306B\u3059\u3054\u3044",
  "id" : 334163751169298432,
  "created_at" : "2013-05-14 04:30:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334134174824931328",
  "text" : "\u6700\u8FD1\u8D77\u304D\u308B\u3068\u5589\u3044\u305F\u3044\u3093\u3060\u3051\u3069\u53E3\u958B\u3051\u3066\u5BDD\u3066\u308B\u306E\u304B\u3082",
  "id" : 334134174824931328,
  "created_at" : "2013-05-14 02:32:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suiminngakushuu",
      "screen_name" : "suiminngakushuu",
      "indices" : [ 0, 16 ],
      "id_str" : "473882586",
      "id" : 473882586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333994306006302720",
  "geo" : { },
  "id_str" : "333996130742444032",
  "in_reply_to_user_id" : 473882586,
  "text" : "@suiminngakushuu \u307B\u3046\u2026",
  "id" : 333996130742444032,
  "in_reply_to_status_id" : 333994306006302720,
  "created_at" : "2013-05-13 17:24:17 +0000",
  "in_reply_to_screen_name" : "suiminngakushuu",
  "in_reply_to_user_id_str" : "473882586",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333993777922457601",
  "text" : "\u9EBB\u96C0\u30B8\u30A7\u30F3\u30AC\u3068\u304B\u9EBB\u96C0\u795E\u7D4C\u8870\u5F31\u3068\u304B\u9EBB\u96C0\u30B9\u30D4\u30FC\u30C9\u3068\u304B\u8ED2\u4E26\u307F\u30AF\u30BD\u30B2\u30FC",
  "id" : 333993777922457601,
  "created_at" : "2013-05-13 17:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333993164140589058",
  "geo" : { },
  "id_str" : "333993442822742016",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u9EBB\u96C0\u724C\u3067\u3084\u308B\u9EBB\u96C0\u4EE5\u5916\u306E\u30B2\u30FC\u30E0\u306F\u5927\u62B5\u308D\u304F\u306A\u3082\u3093\u306B\u306A\u3089\u306A\u3044\u3067\u3059",
  "id" : 333993442822742016,
  "in_reply_to_status_id" : 333993164140589058,
  "created_at" : "2013-05-13 17:13:36 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333993185267290112",
  "text" : "\u30B2\u30FC\u30E0\u6027\u306E\u306A\u3044\u30B2\u30FC\u30E0\u306B\u306F\u8A73\u3057\u3044\u3067\u3059\u3088[UMA\u3057\u308A\u3068\u308A\u3068\u304B\uFF1F]",
  "id" : 333993185267290112,
  "created_at" : "2013-05-13 17:12:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333992909785423874",
  "geo" : { },
  "id_str" : "333993058951626752",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u9EBB\u96C0\u4E03\u4E26\u3079\u3068\u304B\u3067\u3059\u304B\u306D",
  "id" : 333993058951626752,
  "in_reply_to_status_id" : 333992909785423874,
  "created_at" : "2013-05-13 17:12:05 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333992877275373569",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u65B0\u6B53\u30B3\u30F3\u30D1\u884C\u3051\u307E\u3059\uFF1F[\u5B9F\u969B\u9045\u3044\u306A\uFF1F]",
  "id" : 333992877275373569,
  "created_at" : "2013-05-13 17:11:21 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E71\u308C",
      "indices" : [ 7, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333990533296951296",
  "text" : "\u9AEA\u306E\u6BDB\u306E\u4E71\u308C #\u4E71\u308C",
  "id" : 333990533296951296,
  "created_at" : "2013-05-13 17:02:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333990304690622464",
  "text" : "\u3080\u3057\u308D\u7A4D\u6975\u7684\u306B\u7DBA\u9E97\u306A\u9AEA\u3092\u4FDD\u3061\u305F\u3044\u3068",
  "id" : 333990304690622464,
  "created_at" : "2013-05-13 17:01:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333990166035300353",
  "text" : "\u7F8E\u5BB9\u9662\u306B\u91D1\u3092\u304B\u3051\u308B\u3053\u3068\u3068\u9ED2\u9AEA\u3067\u3044\u308B\u3053\u3068\u306F\u307E\u308B\u3067\u77DB\u76FE\u3057\u306A\u3044\u3067\u3057",
  "id" : 333990166035300353,
  "created_at" : "2013-05-13 17:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333989989463511040",
  "text" : "\u3042\u3068\u306F\"\u50B7\u307F\"\u304C\u5ACC\u306A\u306E\u3067\u305D\u3081\u307E\u305B\u3093",
  "id" : 333989989463511040,
  "created_at" : "2013-05-13 16:59:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333989844197969920",
  "text" : "\u50D5\u306F\u751F\u307E\u308C\u305F\u6642\u306B\u9ED2\u9AEA\u3060\u3063\u305F\u3088\u3046\u306A\u306E\u3067\u305D\u308C\u3092\u7DAD\u6301\u3057\u3066\u307E\u3059",
  "id" : 333989844197969920,
  "created_at" : "2013-05-13 16:59:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333989652379885569",
  "text" : "\u773A\u3081\u308B\u306E\u304C\u597D\u304D\u3068\u304B\u306A\u3089\u308F\u304B\u308B",
  "id" : 333989652379885569,
  "created_at" : "2013-05-13 16:58:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333989371952889856",
  "text" : "\u3044\u305A\u308C\u306B\u3057\u3066\u3082\u9AEA\u578B\u304B\u3048\u305F\u3089\u597D\u304D\u3058\u3083\u306A\u304F\u306A\u308B\u611F\u3058\u3059\u308B\u304B\u3089\u306C\u30FC\u3093",
  "id" : 333989371952889856,
  "created_at" : "2013-05-13 16:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333989233654128640",
  "text" : "\u9ED2\u9AEA\u30ED\u30F3\u30B0\u30B9\u30C8\u30EC\u30FC\u30C8\u306E\u5973\u5B50\u304C\u597D\u304D\u3068\u8A00\u3046\u8A00\u660E\u306F\u3001\"\u9ED2\u9AEA\u30ED\u30F3\u30B0\u30B9\u30C8\u30EC\u30FC\u30C8\u306E\u9AEA\u578B\u305D\u306E\u3082\u306E\"\u304C\u597D\u304D\u306A\u306E\u304B\"\u9ED2\u9AEA\u30ED\u30F3\u30B0\u30B9\u30C8\u30EC\u30FC\u30C8\u306E\u305D\u306E\u5B50\"\u304C\u597D\u304D\u306A\u306E\u304B\u3088\u304F\u5206\u304B\u3089\u306A\u304F\u306A\u308B",
  "id" : 333989233654128640,
  "created_at" : "2013-05-13 16:56:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333987529755860992",
  "text" : "iPhone\u306E\u753B\u9762\u304C\u6697\u3044\u3068\u601D\u3063\u305F\u3089\u524D\u9AEA\u304C\u90AA\u9B54\u3060\u3063\u305F",
  "id" : 333987529755860992,
  "created_at" : "2013-05-13 16:50:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333976410467213312",
  "text" : "\u3042\u3001\u65B0\u6B53\u30B3\u30F3\u30D1\u53C2\u52A0\u8868\u660E\u3057\u306A\u304D\u3083[\u9045\u3044]",
  "id" : 333976410467213312,
  "created_at" : "2013-05-13 16:05:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333975990059532288",
  "text" : "\u4ED8\u5C5E\u306E3\u56DE\u306E\u90E8\u5C4B\u3063\u3066\u6301\u3061\u8FBC\u3081\u308B\u306E\u304B\u306D[\u305D\u3082\u305D\u3082\u30D6\u30EB\u30FC\u30EC\u30A4\u307F\u308C\u3093\u306E\u304B]",
  "id" : 333975990059532288,
  "created_at" : "2013-05-13 16:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333975588949868545",
  "geo" : { },
  "id_str" : "333975864708583424",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305C\u3072\u3084\u308A\u307E\u3057\u3087\u3046\uFF01\uFF01",
  "id" : 333975864708583424,
  "in_reply_to_status_id" : 333975588949868545,
  "created_at" : "2013-05-13 16:03:45 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333975586529738756",
  "text" : "\u5E83\u304F\u3066\u5927\u304D\u3044\u30B9\u30AF\u30EA\u30FC\u30F3\u304C\u3042\u3063\u3066\u30D6\u30EB\u30FC\u30EC\u30A4\u304C\u898B\u3089\u308C\u308B\u7A7A\u9593\u306A\u3044\u304B\u306A\u30FC",
  "id" : 333975586529738756,
  "created_at" : "2013-05-13 16:02:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333975159474114560",
  "text" : "s2s\u9EBB\u96C0\u30BB\u30DF\u30CA\u30FC\u3068\u732B\u7269\u8A9E(\u9ED2)\u5316\u7269\u8A9E\u507D\u7269\u8A9E\u4E00\u6C17\u4E0A\u6620\u4F1A\u3084\u308A\u305F\u3044[\u5F8C\u8005\u306F\u307E\u3041\u3069\u3063\u3061\u3067\u3082\u826F\u3044]",
  "id" : 333975159474114560,
  "created_at" : "2013-05-13 16:00:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333973386910916608",
  "geo" : { },
  "id_str" : "333973530398056448",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u753B\u50CF\u306F\u885D\u6483\u7684\u3067\u306F\u306A\u3055\u305D\u3046\u3060\u306A\uFF1F",
  "id" : 333973530398056448,
  "in_reply_to_status_id" : 333973386910916608,
  "created_at" : "2013-05-13 15:54:29 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333939081442639872",
  "geo" : { },
  "id_str" : "333971649462407168",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30C8\u30E9\u30A4\u30A2\u30F3\u30B0\u30EB\u3092\u8907\u6570\u7528\u610F\u3059\u308B\u3058\u3083\u308D\uFF1F\u6295\u3052\u308B\u3058\u3083\u308D\uFF1F\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9\u3058\u3083\uFF01",
  "id" : 333971649462407168,
  "in_reply_to_status_id" : 333939081442639872,
  "created_at" : "2013-05-13 15:47:00 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333927225588076544",
  "text" : "\u5B8C\u6210\u3059\u308B\u6C17\u914D\u3092\u898B\u305B\u306A\u3044\u306A\uFF1F",
  "id" : 333927225588076544,
  "created_at" : "2013-05-13 12:50:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 3, 12 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333927194730565632",
  "text" : "RT @d_adagio: \u306A\u304A\u3001\u66F2\u5B8C\u6210\u4E88\u5B9A\u306F\u5F53\u5206\u5148[3\u5E74\u524D\u3050\u3089\u3044\u304B\u3089\u8A00\u3063\u3066\u308B]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333927134735245312",
    "text" : "\u306A\u304A\u3001\u66F2\u5B8C\u6210\u4E88\u5B9A\u306F\u5F53\u5206\u5148[3\u5E74\u524D\u3050\u3089\u3044\u304B\u3089\u8A00\u3063\u3066\u308B]",
    "id" : 333927134735245312,
    "created_at" : "2013-05-13 12:50:07 +0000",
    "user" : {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "protected" : false,
      "id_str" : "1290456272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3416914088\/63eeb5ef4882f75f0de18db51d8205d0_normal.jpeg",
      "id" : 1290456272,
      "verified" : false
    }
  },
  "id" : 333927194730565632,
  "created_at" : "2013-05-13 12:50:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333927150254161923",
  "text" : "\u306E\u3053\u304E\u308A\u3068\u72AC\u7B1B\u3067\u594F\u3067\u308B\u30E1\u30ED\u30C7\u30A3\u306F\u306A\u3093\u3068\u72AC\u306B\u3082\u5C4A\u304F",
  "id" : 333927150254161923,
  "created_at" : "2013-05-13 12:50:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333926951737782272",
  "geo" : { },
  "id_str" : "333927016686571520",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u3048\uFF0C\u9055\u3046\u306E\uFF1F",
  "id" : 333927016686571520,
  "in_reply_to_status_id" : 333926951737782272,
  "created_at" : "2013-05-13 12:49:39 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333926482659405826",
  "text" : "\u30D0\u30A4\u30AA\u30EA\u30F3\u306F\u30AA\u30EF\u30B3\u30F3\uFF0C\u3053\u308C\u304B\u3089\u306F\u72AC\u7B1B\u306E\u6642\u4EE3",
  "id" : 333926482659405826,
  "created_at" : "2013-05-13 12:47:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333926267013443584",
  "geo" : { },
  "id_str" : "333926371816513536",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u3048\uFF0C\u30D0\u30A4\u30AA\u30EA\u30F3\u3068\u304B\u30AA\u30EF\u30B3\u30F3\u3067\u306F\uFF0E[\u7434\u304C\u5165\u3063\u3066\u305F\u9060\u3044\u8A18\u61B6\u3082]",
  "id" : 333926371816513536,
  "in_reply_to_status_id" : 333926267013443584,
  "created_at" : "2013-05-13 12:47:05 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333925617592569858",
  "text" : "\u30EC\u30FC\u30EB\u30AC\u30F3\u3068\u9032\u6483\u306E\u5DE8\u4EBA\u540C\u3058\u30AF\u30FC\u30EB\u3068\u304B\u30DF\u30B5\u30AB\u3068\u30DF\u30AB\u30B5\u3092\u6DF7\u540C\u3055\u305B\u308B\u30DE\u30F3\u304C\u30DF\u30B5\u30AB\u3068\u30DF\u30AB\u30B5\u3092\u6DF7\u540C\u3055\u305B\u3088\u3046\u3068\u3057\u3066\u3044\u308B\u306B\u9055\u3044\u306A\u3044",
  "id" : 333925617592569858,
  "created_at" : "2013-05-13 12:44:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333924525144170496",
  "text" : "\u50D5\u306E\u53CB\u4EBA\u306B\u300C\u72AC\u7B1B\u306A\u3089\u30B7\u30E7\u30D1\u30F3\u30D4\u30A2\u30CE\u30B3\u30F3\u30AF\u30FC\u30EB\u72D9\u3048\u308B\u300D\u3063\u3066\u8C6A\u8A9E\u3057\u3066\u308B\u53CB\u4EBA\u304C\u3044\u308B\u304B\u3089\u5927\u4E08\u592B\uFF0E",
  "id" : 333924525144170496,
  "created_at" : "2013-05-13 12:39:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333923961169645570",
  "text" : "\u3061\u306A\u307F\u306B\u78BA\u304B\u4E00\u66F2\u76EE\u306B\u4E88\u5B9A\u3055\u308C\u3066\u308B\u306E\u306F\u30AD\u30E9\u30AD\u30E9\u661F\u306E\u5909\u594F\u66F2(\u548C\u592A\u9F13\uFF0C\u306E\u3053\u304E\u308A\uFF0C\u30D6\u30D6\u30BC\u30E9\uFF0C\u30C8\u30E9\u30A4\u30A2\u30F3\u30B0\u30EB\uFF0C\u72AC\u7B1B\uFF0C\u72ACver)",
  "id" : 333923961169645570,
  "created_at" : "2013-05-13 12:37:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333923496474337281",
  "text" : "\u548C\u592A\u9F13(\u30D9\u30FC\u30B9)\uFF0C\u306E\u3053\u304E\u308A(\u30BD\u30D7\u30E9\u30CE)\uFF0C\u30D6\u30D6\u30BC\u30E9(\u30EA\u30BA\u30E0)\uFF0C\u30C8\u30E9\u30A4\u30A2\u30F3\u30B0\u30EB(\u30B8\u30E3\u30B0\u30EA\u30F3\u30B0)\uFF0C\u72AC\u7B1B(\u8D85\u97F3\u6CE2)\uFF0C\u72AC(\u72AC)\u306E\u7DE8\u6210\u3067\u30D0\u30F3\u30C9\u7D44\u3080\u4E88\u5B9A\u3042\u308B\u3051\u3069\u8CEA\u554F\u3042\u308B\uFF1F",
  "id" : 333923496474337281,
  "created_at" : "2013-05-13 12:35:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333922961499234304",
  "text" : "\u98A8\u5442\u4E0A\u308A\u306E\uFF84\uFF9E\uFF78\u307A",
  "id" : 333922961499234304,
  "created_at" : "2013-05-13 12:33:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333919736423407616",
  "geo" : { },
  "id_str" : "333922535076941824",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3044\u304D\u307E\u305B\u3046",
  "id" : 333922535076941824,
  "in_reply_to_status_id" : 333919736423407616,
  "created_at" : "2013-05-13 12:31:51 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333920122320330753",
  "geo" : { },
  "id_str" : "333922499534417921",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u548C\u592A\u9F13\u306F\u30EA\u30BA\u30E0\u3058\u3083\u306A\u3044\u306E\u304B\uFF0E[\u72AC\u3068\u72AC\u7B1B\u306F\u5225\u7269\u3060\u308D]",
  "id" : 333922499534417921,
  "in_reply_to_status_id" : 333920122320330753,
  "created_at" : "2013-05-13 12:31:42 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333919605871497216",
  "text" : "\u304A\u3075\u308D\u306F\u3044\u308B\u307E\u3059",
  "id" : 333919605871497216,
  "created_at" : "2013-05-13 12:20:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333919566453407744",
  "text" : "\u9C3B\u713C\u304F\u5302\u3044\u3060\u3051\u3067\u307F\u3093\u306A\u3067\u3054\u98EF\u98DF\u3079\u308B\u3075\u308A\u3057\u305F\u3089\u5B9F\u969B\u30A8\u30B3\u3060\u306A",
  "id" : 333919566453407744,
  "created_at" : "2013-05-13 12:20:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333919390233939970",
  "geo" : { },
  "id_str" : "333919459054059521",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u79C1\u3082\u884C\u3063\u305F\u3053\u3068\u306A\u3044\u306E\u3067\u3059\u304C",
  "id" : 333919459054059521,
  "in_reply_to_status_id" : 333919390233939970,
  "created_at" : "2013-05-13 12:19:37 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333919195068768256",
  "geo" : { },
  "id_str" : "333919405874483201",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u9C3B\u713C\u304F\u5302\u3044\u3060\u3051\u3067\u307F\u3093\u306A\u3067\u3054\u98EF\u98DF\u3079\u308B\u30D5\u30EA\u3057\u307E\u3059",
  "id" : 333919405874483201,
  "in_reply_to_status_id" : 333919195068768256,
  "created_at" : "2013-05-13 12:19:24 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 49, 58 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 60, 70 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333919159983407105",
  "text" : "\u306E\u3053\u304E\u308A\uFF0C\u30D6\u30D6\u30BC\u30E9\uFF0C\u30C8\u30E9\u30A4\u30A2\u30F3\u30B0\u30EB(\u30B8\u30E3\u30B0\u30EA\u30F3\u30B0)\uFF0C\u72AC\u7B1B\uFF0C\u72AC\u306E\u7DE8\u6210\u306E\u4F55\u304C\u60AA\u3044\u3093\u3060\u3088\uFF01\uFF01\uFF01\uFF01 RT @d_adagio: @end313124 \u304A\u524D\u3089\u304C\u63D0\u793A\u3057\u305F\u697D\u5668\u7DE8\u6210\u3053\u305D\u73FE\u4EE3\u82B8\u8853\u3060\u3068\u601D\u3046\n\u7F36\u30B3\u30FC\u30D2\u30FC\u306E\u4E0A\u306B\u7F36\u30B3\u30FC\u30D2\u30FC\u304C\u6A2A\u306B\u7F6E\u3044\u3066\u3042\u3063\u305F\u3089\u73FE\u4EE3\u82B8\u8853",
  "id" : 333919159983407105,
  "created_at" : "2013-05-13 12:18:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5225\u306B\u304A\u3054\u3089\u306A\u3044",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333918682008924160",
  "geo" : { },
  "id_str" : "333918954772901890",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u4E09\u6761\u3042\u305F\u308A\u306B\u6642\u3005\u843D\u8A9E\u3084\u308B\u9C3B\u5C4B\u304C\u3042\u3063\u3066\u306A #\u5225\u306B\u304A\u3054\u3089\u306A\u3044",
  "id" : 333918954772901890,
  "in_reply_to_status_id" : 333918682008924160,
  "created_at" : "2013-05-13 12:17:37 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30A2\u30CA\u30B4\u306F\u4ECA\u6708\u98DF\u3079\u305F",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333918759859408896",
  "text" : "\u30A6\u30C4\u30DC\u306E\u65B9\u304C\u6700\u8FD1\u98DF\u3079\u305F\u611F\u3042\u308B\u30EC\u30D9\u30EB\uFF0E#\u30A2\u30CA\u30B4\u306F\u4ECA\u6708\u98DF\u3079\u305F",
  "id" : 333918759859408896,
  "created_at" : "2013-05-13 12:16:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333918639088611328",
  "text" : "\u3082\u3046\u306A\u3093\u304B\u6885\u3068\u9C3B\u3068\u51FA\u3066\u304D\u3066\u3082\u4E00\u7DD2\u306B\u98DF\u3079\u3061\u3083\u3046\u304F\u3089\u3044\u30A6\u30CA\u30AE\u98DF\u3079\u3066\u306A\u3044",
  "id" : 333918639088611328,
  "created_at" : "2013-05-13 12:16:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333918555022176258",
  "text" : "\u30A6\u30CA\u30AEis \u66AB\u304F\u98DF\u3079\u3066\u306A\u3044",
  "id" : 333918555022176258,
  "created_at" : "2013-05-13 12:16:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333918472067227648",
  "geo" : { },
  "id_str" : "333918505055420416",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u308F\u304B\u308B",
  "id" : 333918505055420416,
  "in_reply_to_status_id" : 333918472067227648,
  "created_at" : "2013-05-13 12:15:50 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333918311278575616",
  "geo" : { },
  "id_str" : "333918397387665408",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \u5927\u4F53\u30E1\u30F3\u30D0\u30FC\u304C\u5272\u308C\u3066\u3066\u30A6\u30B1\u308B\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 333918397387665408,
  "in_reply_to_status_id" : 333918311278575616,
  "created_at" : "2013-05-13 12:15:24 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333918276054827008",
  "text" : "\u304A\u98A8\u5442\u306Binto the bath\u3059\u308B\u6240\u5B58",
  "id" : 333918276054827008,
  "created_at" : "2013-05-13 12:14:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333914508550606848",
  "geo" : { },
  "id_str" : "333917755948539904",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \uFF4B\uFF57\uFF53\uFF4B\uFF1C\u5065\u5EB7\u9EBB\u96C0\u90E8",
  "id" : 333917755948539904,
  "in_reply_to_status_id" : 333914508550606848,
  "created_at" : "2013-05-13 12:12:51 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333916069825769472",
  "geo" : { },
  "id_str" : "333916607560699904",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u78BA\u304B\u6D5C\u7530\u5C71\u306E\u99C5\u524D\u306B\u3042\u308A\u307E\u3057\u305F\u306D\u305D\u3046\u3044\u3048\u3070",
  "id" : 333916607560699904,
  "in_reply_to_status_id" : 333916069825769472,
  "created_at" : "2013-05-13 12:08:17 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333916177321562112",
  "text" : "\u3053\u3046\u3057\u3066\u8A00\u8449\u4E00\u3064\u4E00\u3064\u306B\u9762\u767D\u3044\u30A8\u30D4\u30BD\u30FC\u30C9\u304C\u4ED8\u968F\u3059\u308B\u3088\u3046\u306B\u306A\u308C\u3070\u3044\u305A\u308C\u4EFB\u610F\u306E\u8A00\u8449\u306F\u9762\u767D\u30A8\u30D4\u30BD\u30FC\u30C9\u3067\u8986\u308F\u308C\uFF0C\u4F55\u304B\u8A00\u3046\u3060\u3051\u3067\u672C\u5F53\u306B\u9762\u767D\u3044\u4E16\u754C\u306B\u306A\u308B\u306E\u3067\u306F\u306A\u3044\u304B\u3068\u671F\u5F85\u3057\u3066\u3044\u308B\uFF0E",
  "id" : 333916177321562112,
  "created_at" : "2013-05-13 12:06:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 65, 74 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333915640362569729",
  "text" : "\u73FE\u4EE3\u82B8\u8853\u3068\u8A00\u3046\u3068\u9053\u7AEF\u306B\u843D\u3061\u3066\u3044\u308B\u7F36\u30B3\u30FC\u30D2\u30FC\u306E\u3054\u307F\u3092\u6307\u3055\u3057\u3066\u300C\u3053\u308C\u73FE\u4EE3\u82B8\u8853\u3058\u3083\u306D\uFF1F\u300D\u3068\u9A12\u304E\u51FA\u3057\u305F\u53CB\u4EBA\u3068\u4F55\u3082\u8A00\u308F\u305A\u306B\u305D\u308C\u3092\u8E74\u308A\u98DB\u3070\u3057\u305F@d_adagio \u306E\u30A4\u30E1\u30FC\u30B8\u3057\u304B\u306A\u3044\u306A\uFF1F",
  "id" : 333915640362569729,
  "created_at" : "2013-05-13 12:04:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333915094574579712",
  "text" : "FaceBook\u306B\u304A\u3051\u308B\u50D5\u306E\u5F79\u5272\u306F\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3044\u30DD\u30B9\u30C8\u3092\u3057\u3066\u305D\u308C\u306B\u30A4\u30A4\u30CD\u3092\u62BC\u3055\u305B\u308B\u3053\u3068\u3067\u300C\u79C1\u304C\u666E\u6BB5\u8EFD\u3044\u6C17\u6301\u3061\u3067\u62BC\u3057\u3066\u3044\u308B\u30A4\u30A4\u30CD\u306F\u672C\u5F53\u306B\u201D\u3044\u3044\u306D\u201D\u3068\u601D\u3063\u3066\u62BC\u3057\u3066\u3044\u308B\u306E\u304B\uFF1F\u300D\u3063\u3066\u81EA\u554F\u3055\u305B\u308B\u3053\u3068\u3060\u304B\u3089\u306D",
  "id" : 333915094574579712,
  "created_at" : "2013-05-13 12:02:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333914604960894976",
  "geo" : { },
  "id_str" : "333914790944706561",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u30A4\u30A4\u30CD\u62BC\u3057\u3066\u304F\u3060\u3055\u3044\u3063\u3066\u66F8\u304F\u3058\u3083\u308D\uFF1F\u307F\u3093\u306A\u512A\u3057\u3044\u304B\u3089\u62BC\u3057\u3066\u304F\u308C\u308B\u3058\u3083\u308D\uFF1F\u307B\u3089\uFF01",
  "id" : 333914790944706561,
  "in_reply_to_status_id" : 333914604960894976,
  "created_at" : "2013-05-13 12:01:04 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333914410269683712",
  "text" : "\u306B\u3085\u30FC\u304F\u308C\u3089\u3063\u3077\u30FC\u306F\u306A\u3093\u3067\u3082\u304A\u304A\u3048\u308B\u3059\u3050\u308C\u3082\u306E\u30FC\u30FC",
  "id" : 333914410269683712,
  "created_at" : "2013-05-13 11:59:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333914075274809344",
  "text" : "\u30B5\u30E9\u30F3\u30E9\u30C3\u30D7\u4F7F\u3063\u3066\u308B\u4EBA\u306B\u5411\u304B\u3063\u3066\u30AF\u30EC\u30E9\u30C3\u30D7\u306E\u6B4C\u3092\u6B4C\u3046\u306Eis \u697D\u3057\u3044",
  "id" : 333914075274809344,
  "created_at" : "2013-05-13 11:58:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333913734642798595",
  "text" : "\u6211\u306A\u304C\u3089\u30DD\u30A8\u30C3\u30C8\u3060\u3063\u305F",
  "id" : 333913734642798595,
  "created_at" : "2013-05-13 11:56:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333913693421187073",
  "text" : "RT @shigmax: \u4E45\u3005\u306B\u611F\u9298\u3092\u53D7\u3051\u308B\u30CF\u30A4\u30AF\u306B\u51FA\u4F1A\u3048\u305F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333910322643623936",
    "text" : "\u4E45\u3005\u306B\u611F\u9298\u3092\u53D7\u3051\u308B\u30CF\u30A4\u30AF\u306B\u51FA\u4F1A\u3048\u305F\u2026",
    "id" : 333910322643623936,
    "created_at" : "2013-05-13 11:43:19 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 333913693421187073,
  "created_at" : "2013-05-13 11:56:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30ED\u30FC\u30BD\u30F3\u30D6\u30E9\u30F3\u30C9\u306E\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u306F\u98F2\u3080\u30E8\u30FC\u30B0\u30EC\u30C3\u30C8",
      "indices" : [ 16, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333913614614421504",
  "text" : "\u8AB0\u304B\u3068\u3053\u306E\u611F\u899A\u3092\u5206\u304B\u3061\u5408\u3044\u305F\u3044\uFF0E#\u30ED\u30FC\u30BD\u30F3\u30D6\u30E9\u30F3\u30C9\u306E\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u306F\u98F2\u3080\u30E8\u30FC\u30B0\u30EC\u30C3\u30C8",
  "id" : 333913614614421504,
  "created_at" : "2013-05-13 11:56:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333913508322369536",
  "text" : "\u7D50\u8AD6\uFF1A\u30ED\u30FC\u30BD\u30F3\u30D6\u30E9\u30F3\u30C9\u306E\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u306F\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u3068\u8A00\u3046\u3088\u308A\u306F\u98F2\u3080\u30E8\u30FC\u30B0\u30EC\u30C3\u30C8",
  "id" : 333913508322369536,
  "created_at" : "2013-05-13 11:55:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333913301132120064",
  "text" : "\u3067\u3082\u305D\u306E\u9867\u307F\u306A\u3044\u59FF\u52E2\uFF0C\u5ACC\u3044\u3058\u3083\u306A\u3044\u305C",
  "id" : 333913301132120064,
  "created_at" : "2013-05-13 11:55:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333913076195815424",
  "geo" : { },
  "id_str" : "333913189395881984",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u3042\u30FC\uFF0C\u306F\u3044\uFF08\uFF7C\uFF9E\uFF84\uFF70\uFF09",
  "id" : 333913189395881984,
  "in_reply_to_status_id" : 333913076195815424,
  "created_at" : "2013-05-13 11:54:42 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333912690923810817",
  "text" : "\u9AEA\u3092\u5207\u3063\u305F\u53CB\u4EBA\u304C\u5225\u306E\u53CB\u4EBA\u306B\u300Cend\u4F4D\u9AEA\u9577\u3044\u3068\u9762\u63A5\u3067\u306F\u306D\u3089\u308C\u3061\u3083\u3046\u300D\u3068\u304B\u8A00\u308F\u308C\u3066\u9AEA\u304C\u9577\u3044\u3053\u3068\u3092\u81EA\u899A\u3057\u305F",
  "id" : 333912690923810817,
  "created_at" : "2013-05-13 11:52:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4FF3\u53E5",
      "indices" : [ 22, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333909901946531840",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8 \u3050\u3072\u3083\u3079\u308D\u30D5\u30D2\u30D2 \u30A4\u30F3\u30AC\u30AA\u30DB\u30FC #\u4FF3\u53E5",
  "id" : 333909901946531840,
  "created_at" : "2013-05-13 11:41:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333894226104430592",
  "geo" : { },
  "id_str" : "333899762514411520",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u57A2\u6D88\u305B\u3001\u307B\u3069\u306E\u30A4\u30F3\u30D1\u30AF\u30C8\u3092\u4FDD\u3063\u305F\u307E\u307E\u5197\u8AC7\u3067\u3042\u308B\u3053\u3068\u3092\u5F37\u8ABF\u3059\u308B\u306E\u306F\u96E3\u3057\u3044\u3067\u3059\u306D\u30FC\u30FC",
  "id" : 333899762514411520,
  "in_reply_to_status_id" : 333894226104430592,
  "created_at" : "2013-05-13 11:01:21 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333899199596883969",
  "text" : "\u30E9\u30F3\u30DC\u30FC\u6012\u308A\u306E\u5E73\u8B1D\u308A\u300C\u30CF\u30A4\u30C9\u30FC\u30E2\uFF01\u30B9\u30DF\u30DE\u30BB\u30F3\u30C7\u30B7\u30BF\uFF01\uFF01\uFF01\uFF01\uFF01\u300D",
  "id" : 333899199596883969,
  "created_at" : "2013-05-13 10:59:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333893992993406976",
  "text" : "\u300C\u306A\u30FC\u306B\u304Chogehoge\u3058\u3083\u3001\u57A2\u6D88\u305B\u300D\u306E\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u9762\u767D\u3044\u3057\u73FE\u5B9F\u3067\u3082\u4F7F\u3044\u305F\u3044\u3051\u3069\u57A2\u6D88\u305B\u306E\u90E8\u5206\u304C\u975E\u30C4\u30A4\u30C3\u30BF\u30E9\u30FC\u306B\u306F\u30AD\u30E7\u30C8\u30F3\u3068\u3055\u308C\u304C\u3061\u3060\u304B\u3089\u6539\u5909\u3092\u8003\u3048\u3066\u6B32\u3057\u3044(\u30DE\u30EB\u30CA\u30B2)",
  "id" : 333893992993406976,
  "created_at" : "2013-05-13 10:38:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333893508777787392",
  "text" : "\u307E\u305F\u4E00\u679A\u306E\u30C7\u30A3\u30B9\u30D7\u30EC\u30A4\u304C\u53E9\u304D\u5272\u3089\u308C\u305F\u611F\u3058is\u3059\u308B",
  "id" : 333893508777787392,
  "created_at" : "2013-05-13 10:36:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "indices" : [ 3, 11 ],
      "id_str" : "16331213",
      "id" : 16331213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/mOztehMQTz",
      "expanded_url" : "http:\/\/twitpic.com\/cq9hw5",
      "display_url" : "twitpic.com\/cq9hw5"
    } ]
  },
  "geo" : { },
  "id_str" : "333893444743331840",
  "text" : "RT @kazoo04: \u30DE\u30B8\u3067\u30D6\u30C1\u30AE\u30EC\u3066\u308B\nhttp:\/\/t.co\/mOztehMQTz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/mOztehMQTz",
        "expanded_url" : "http:\/\/twitpic.com\/cq9hw5",
        "display_url" : "twitpic.com\/cq9hw5"
      } ]
    },
    "geo" : { },
    "id_str" : "333893251645988865",
    "text" : "\u30DE\u30B8\u3067\u30D6\u30C1\u30AE\u30EC\u3066\u308B\nhttp:\/\/t.co\/mOztehMQTz",
    "id" : 333893251645988865,
    "created_at" : "2013-05-13 10:35:29 +0000",
    "user" : {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "protected" : false,
      "id_str" : "16331213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583129549694640129\/aPkbezAe_normal.png",
      "id" : 16331213,
      "verified" : false
    }
  },
  "id" : 333893444743331840,
  "created_at" : "2013-05-13 10:36:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333893148684218368",
  "text" : "\u601D\u3044\u51FA\u3057\u305F\u3088\u3046\u306B\u7A7A\u8179\u304C\u6EA2\u308C\u51FA\u3057\u305F\u3002\u3054\u98EF\u708A\u304B\u306A\u304D\u3083\u3002",
  "id" : 333893148684218368,
  "created_at" : "2013-05-13 10:35:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333892919880736768",
  "text" : "(\u305D\u308C\u3092\u5C02\u9580\u306B\u3057\u306A\u3044)\u5927\u62B5\u306E\u4EBA\u306F\u6570\u5B66\u3084\u3089\u6B74\u53F2\u3084\u3089\u53E4\u6587\u3084\u3089\u3092\u5FD8\u308C\u308B\u3088",
  "id" : 333892919880736768,
  "created_at" : "2013-05-13 10:34:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333892559350931456",
  "text" : "@lgcisvlc \u307E\u3041\u305D\u306E\u306F\u305A\u3067\u3059\u3051\u308C\u3069(\u3057\u308D\u3081)",
  "id" : 333892559350931456,
  "created_at" : "2013-05-13 10:32:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333891571877548032",
  "text" : "@lgcisvlc \u305D\u3089\u77E5\u3089\u3093\u3084\u308D\u30FC(\u3057\u308D\u3081)",
  "id" : 333891571877548032,
  "created_at" : "2013-05-13 10:28:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/xs4ONeNJ8N",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=MORIMOTOA",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "333823785960620033",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/xs4ONeNJ8N",
  "id" : 333823785960620033,
  "created_at" : "2013-05-13 05:59:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333790382393544704",
  "text" : "\u3053\u3080\u304E\u3042\u3058(^^)(^^)(^^)",
  "id" : 333790382393544704,
  "created_at" : "2013-05-13 03:46:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333790041799270400",
  "text" : "\u30D0\u30B2\u30C3\u30C8mgmg",
  "id" : 333790041799270400,
  "created_at" : "2013-05-13 03:45:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333767984994725890",
  "text" : "\u306E\u3069\u3044\u305F\u307F \u30A4\u30F3\u30AC\u30AA\u30DB\u30FC",
  "id" : 333767984994725890,
  "created_at" : "2013-05-13 02:17:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333651548347432960",
  "geo" : { },
  "id_str" : "333651715238805504",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 333651715238805504,
  "in_reply_to_status_id" : 333651548347432960,
  "created_at" : "2013-05-12 18:35:42 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3046\u3057\u3046\u3057\u306F\u3059\u3054\u3044",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333651323729883136",
  "text" : "#\u3046\u3057\u3046\u3057\u306F\u3059\u3054\u3044",
  "id" : 333651323729883136,
  "created_at" : "2013-05-12 18:34:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333650931109490688",
  "geo" : { },
  "id_str" : "333651040303984640",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u8FD1\u65E5\u4F01\u753B\u3057\u307E\u3059",
  "id" : 333651040303984640,
  "in_reply_to_status_id" : 333650931109490688,
  "created_at" : "2013-05-12 18:33:01 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 3, 12 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333650550866452480",
  "text" : "RT @kur_rage: \u9EBB\u96C0\u306E\u5F79\u899A\u3048\u305F\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.youtube.com\/watch?v=_8oxXbWE8AI\" rel=\"nofollow\"\u003E\u30B7\u30CA\u30D7\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333649891475746816",
    "text" : "\u9EBB\u96C0\u306E\u5F79\u899A\u3048\u305F\u3044",
    "id" : 333649891475746816,
    "created_at" : "2013-05-12 18:28:27 +0000",
    "user" : {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "protected" : true,
      "id_str" : "1223342047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000156529724\/4b88df87fc3bf81618a6639b5c6e97fe_normal.jpeg",
      "id" : 1223342047,
      "verified" : false
    }
  },
  "id" : 333650550866452480,
  "created_at" : "2013-05-12 18:31:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333650541571895296",
  "text" : "s2s\u3067\u9EBB\u96C0\u6559\u3048\u308B\u4F1A\u306E\u9700\u8981\u306E\u9AD8\u307E\u308A\u3092\u611F\u3058\u308B",
  "id" : 333650541571895296,
  "created_at" : "2013-05-12 18:31:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333630774089760769",
  "text" : "\u6765\u308B\u3079\u304D\u8179\u75DB\u306B\u306A\u3059\u8853\u306A\u3057",
  "id" : 333630774089760769,
  "created_at" : "2013-05-12 17:12:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333630682712645632",
  "text" : "\u3068\u304B\u3044\u3044\u3064\u3064\u3054\u304F\u3054\u304F\u98F2\u3093\u3067\u308B\u3001\u5589\u4E7E\u3044\u3066\u305F\u307F\u305F\u3044\u3001",
  "id" : 333630682712645632,
  "created_at" : "2013-05-12 17:12:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333630327073431552",
  "text" : "\u306A\u3093\u304B\u30E8\u30FC\u30B0\u30EC\u30C3\u30C8\u307F\u305F\u3044\u306A\u5473\u3059\u308B[\u6279\u5224\u306B\u306A\u3063\u3066\u308B\uFF1F]",
  "id" : 333630327073431552,
  "created_at" : "2013-05-12 17:10:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333630195678453760",
  "text" : "\u3042\u30FC\u3001\u3084\u3063\u3071\u308A\u30ED\u30FC\u30BD\u30F3\u30D6\u30E9\u30F3\u30C9\u306E\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u306F\u30C0\u30E1\u3060\u306A\u3001\u8A66\u3057\u306B\u8CB7\u3063\u3066\u898B\u305F\u304C",
  "id" : 333630195678453760,
  "created_at" : "2013-05-12 17:10:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333629570706182144",
  "text" : "\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u8CB7\u3063\u3066\u304D\u305F",
  "id" : 333629570706182144,
  "created_at" : "2013-05-12 17:07:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E71\u308C",
      "indices" : [ 7, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333629431715344384",
  "text" : "\u96C6\u4E2D\u529B\u306E\u4E71\u308C #\u4E71\u308C",
  "id" : 333629431715344384,
  "created_at" : "2013-05-12 17:07:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333627480814530561",
  "text" : "\u30EA\u30E0\u3089\u308C\u30D6\u30ED\u3089\u308C\u3092\u308F\u3056\u308F\u3056\u5831\u544A\u3059\u308B\u3053\u3068\u306E\u30E1\u30EA\u30C3\u30C8is\u4F55",
  "id" : 333627480814530561,
  "created_at" : "2013-05-12 16:59:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333625898534313987",
  "text" : "API\u67AF\u308C\u305F\u307F\u305F\u3044",
  "id" : 333625898534313987,
  "created_at" : "2013-05-12 16:53:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333625612847681536",
  "text" : "\u5927\u96D1\u628A\u306B\u307E\u3068\u3081\u305F\u3001",
  "id" : 333625612847681536,
  "created_at" : "2013-05-12 16:51:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/ZuAx1mLO5F",
      "expanded_url" : "http:\/\/togetter.com\/li\/501910",
      "display_url" : "togetter.com\/li\/501910"
    } ]
  },
  "geo" : { },
  "id_str" : "333625504173273089",
  "text" : "\u300C\u3053\u306ETL\u306A\u30FC\u3093\u3060\uFF1F\u300D\u3092\u30C8\u30A5\u30AE\u30E3\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/ZuAx1mLO5F",
  "id" : 333625504173273089,
  "created_at" : "2013-05-12 16:51:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333624398655410176",
  "text" : "Q.\u3053\u306E\u4E00\u9023\u306E\u306A\u305E\u306A\u305E\u3081\u3044\u305F\u3082\u306E\u3001\u306A\u30FC\u3093\u3060\uFF1F",
  "id" : 333624398655410176,
  "created_at" : "2013-05-12 16:47:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333623751247814656",
  "text" : "\u3084\u3070\u3044",
  "id" : 333623751247814656,
  "created_at" : "2013-05-12 16:44:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "indices" : [ 3, 11 ],
      "id_str" : "5965172",
      "id" : 5965172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333623730066567168",
  "text" : "RT @mr_konn: Q. \u4E0B\u306F\u5927\u706B\u4E8B\u3001\u4E0B\u306F\u5927\u706B\u4E8B\u3001\u306A\u301C\u3093\u3060\uFF1F A. \u3068\u306B\u304B\u304F\u3084\u3070\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333623680133390336",
    "text" : "Q. \u4E0B\u306F\u5927\u706B\u4E8B\u3001\u4E0B\u306F\u5927\u706B\u4E8B\u3001\u306A\u301C\u3093\u3060\uFF1F A. \u3068\u306B\u304B\u304F\u3084\u3070\u3044",
    "id" : 333623680133390336,
    "created_at" : "2013-05-12 16:44:18 +0000",
    "user" : {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "protected" : false,
      "id_str" : "5965172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566615944194060288\/nh8McKGS_normal.jpeg",
      "id" : 5965172,
      "verified" : false
    }
  },
  "id" : 333623730066567168,
  "created_at" : "2013-05-12 16:44:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333623491574259713",
  "text" : "Q.\u4E0A\u306F\u5927\u706B\u4E8B\u3001\u4E0A\u306F\u6D2A\u6C34\u3001\u3069\u30FC\u3063\u3061\u3060\uFF1F\nA.\u4E21\u65B9",
  "id" : 333623491574259713,
  "created_at" : "2013-05-12 16:43:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333622606550941696",
  "text" : "\u305F\u307E\u306B\u601D\u3044\u3064\u304F(\u601D\u3044\u51FA\u3059)\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u304F\u3069\u3046\u3067\u3082\u3044\u3044\u30CD\u30BF\u3092\u6295\u4E0B\u3067\u304D\u308B\u304B\u3089Twitter\u306F\u4FBF\u5229",
  "id" : 333622606550941696,
  "created_at" : "2013-05-12 16:40:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333622099308601344",
  "text" : "\u4E0D\u826F\u8A2D\u5B9A\u554F\u984C\u3060\u306A\uFF1F",
  "id" : 333622099308601344,
  "created_at" : "2013-05-12 16:38:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "indices" : [ 3, 11 ],
      "id_str" : "5965172",
      "id" : 5965172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333622063908651010",
  "text" : "RT @mr_konn: Q. \u4E0A\u306F\u5927\u706B\u4E8B\u3001\u4E0B\u306F\u306A\u301C\u3093\u3060\uFF1F A. \u77E5\u3089\u3093",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333621899022200832",
    "text" : "Q. \u4E0A\u306F\u5927\u706B\u4E8B\u3001\u4E0B\u306F\u306A\u301C\u3093\u3060\uFF1F A. \u77E5\u3089\u3093",
    "id" : 333621899022200832,
    "created_at" : "2013-05-12 16:37:13 +0000",
    "user" : {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "protected" : false,
      "id_str" : "5965172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566615944194060288\/nh8McKGS_normal.jpeg",
      "id" : 5965172,
      "verified" : false
    }
  },
  "id" : 333622063908651010,
  "created_at" : "2013-05-12 16:37:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333621981884858370",
  "text" : "(\u306A\u3093\u3067\u3053\u3093\u306A\u306A\u305E\u306A\u305E\u3092\u51FA\u3057\u305F\u304B\u3068\u8A00\u3046\u610F\u5473\u3067)\u306A\u305E\u306A\u305E",
  "id" : 333621981884858370,
  "created_at" : "2013-05-12 16:37:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333621816537006080",
  "text" : "Q.\u4E0A\u306F\u6D2A\u6C34\u3001\u4E0B\u306F\u6D2A\u6C34\u3001\u306A\u30FC\u3093\u3060\uFF1F\nA.\u6D2A\u6C34",
  "id" : 333621816537006080,
  "created_at" : "2013-05-12 16:36:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333621683783073792",
  "text" : "Q.\u4E0A\u306F\u5927\u706B\u4E8B\u3001\u4E0B\u306F\u5927\u706B\u4E8B\u3001\u306A\u30FC\u3093\u3060\uFF1F\nA.\u5927\u706B\u4E8B",
  "id" : 333621683783073792,
  "created_at" : "2013-05-12 16:36:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333597654460280833",
  "text" : "\u65E5\u66DC is \u3069\u3053",
  "id" : 333597654460280833,
  "created_at" : "2013-05-12 15:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333552210359238656",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 333552210359238656,
  "created_at" : "2013-05-12 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333546488313556992",
  "text" : "\u3053\u306E\u30DA\u30FC\u30B9\u3084\u3070\u3044\u306A\uFF1F[\u30EC\u30B8\u30E5\u30E1\u30E1\u30A4\u30AB\u30FC]",
  "id" : 333546488313556992,
  "created_at" : "2013-05-12 11:37:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333546352615256065",
  "text" : "\u3082\u3057\u304B\u3057\u3066:\u4ECA\u65E5\u6696\u304B\u3044",
  "id" : 333546352615256065,
  "created_at" : "2013-05-12 11:37:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feru",
      "screen_name" : "Feru54604",
      "indices" : [ 0, 10 ],
      "id_str" : "78560756",
      "id" : 78560756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333443259001098240",
  "geo" : { },
  "id_str" : "333443401548722178",
  "in_reply_to_user_id" : 78560756,
  "text" : "@Feru54604 \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 333443401548722178,
  "in_reply_to_status_id" : 333443259001098240,
  "created_at" : "2013-05-12 04:47:56 +0000",
  "in_reply_to_screen_name" : "Feru54604",
  "in_reply_to_user_id_str" : "78560756",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333442173531979776",
  "text" : "\u8D77\u304D\u305F\u30892\u6642\u306E\u9854( \u00B4_\u309D\uFF40)",
  "id" : 333442173531979776,
  "created_at" : "2013-05-12 04:43:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333305437308993536",
  "text" : "\u30D3\u30C3\u30B0\u30A2\u30A4\u30C7\u30A3\u30A2\u9762\u767D\u304B\u3063\u305F\u3001\u30C6\u30EC\u30B9\u30C8\u30EC\u30FC\u30B7\u30E7\u30F3\u3068\u4E26\u3093\u3067\u7B11\u3048\u308B\u30B2\u30FC\u30E0\u3060\u3063\u305F",
  "id" : 333305437308993536,
  "created_at" : "2013-05-11 19:39:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333305195926794240",
  "text" : "\u50C5\u5DEE\u3067\u52DD\u3063\u305F(?)",
  "id" : 333305195926794240,
  "created_at" : "2013-05-11 19:38:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333305088376451073",
  "text" : "\u300C\u4FFA\u81EA\u8EAB\u304C\u9707\u3048\u308B\u4E8B\u3060\u3001\u30D1\u30FC\u30BD\u30CA\u30EB\u3063\u3066\u3044\u3046\u306E\u306F\u3001\u305D\u3046\u3044\u3046\u610F\u5473\u3060\u300D",
  "id" : 333305088376451073,
  "created_at" : "2013-05-11 19:38:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333304884633952256",
  "text" : "\u30D1\u30FC\u30BD\u30CA\u30EB\u30D0\u30A4\u30D6\u30EC\u30FC\u30B7\u30E7\u30F3",
  "id" : 333304884633952256,
  "created_at" : "2013-05-11 19:37:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333304702500491264",
  "text" : "\u30A2\u30DF\u30E5\u30FC\u30BA\u30E1\u30F3\u30C8\u30E2\u30F3\u30B9\u30BF\u30FC\u3042\u305F\u308A\u3082\u8A9E\u5442\u304C\u826F\u304B\u3063\u305F",
  "id" : 333304702500491264,
  "created_at" : "2013-05-11 19:36:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 9, 25 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 49, 59 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6628\u65E5\u4E00\u756A\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333304593708638208",
  "text" : "\u5371\u967A\u30D0\u30C8\u30EB RT @Jelly_in_a_tank: \u30D1\u30CE\u30E9\u30DE\u98DB\u884C\u6A5F\u30DE\u30B7\u30FC\u30F3\u3001\u63A5\u7740\u6027\u30D3\u30FC\u30EB RT @end313124: \u7A7A\u98DB\u3076\u98DB\u884C\u6A5F\u30DE\u30B7\u30FC\u30F3 #\u6628\u65E5\u4E00\u756A\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA",
  "id" : 333304593708638208,
  "created_at" : "2013-05-11 19:36:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333303769578217473",
  "text" : "\u7A7A\u304C\u660E\u308B\u3093\u3067\u6765\u305F\u2026",
  "id" : 333303769578217473,
  "created_at" : "2013-05-11 19:33:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6628\u65E5\u4E00\u756A\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA",
      "indices" : [ 11, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333297019085004800",
  "text" : "\u7A7A\u98DB\u3076\u98DB\u884C\u6A5F\u30DE\u30B7\u30FC\u30F3 #\u6628\u65E5\u4E00\u756A\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA",
  "id" : 333297019085004800,
  "created_at" : "2013-05-11 19:06:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333296157981827072",
  "text" : "\u5E30\u5B85\u3057\u305F\u30894\u6642\u306E\u9854",
  "id" : 333296157981827072,
  "created_at" : "2013-05-11 19:02:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333189830538297345",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 333189830538297345,
  "created_at" : "2013-05-11 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333186549992787968",
  "text" : "\u5927\u5B66\u4E00\u56DE\u306E\u6642\u306B\u30D5\u30EA\u30FC\u30BB\u30EB\u57CB\u3081\u308B\u306E\u306B\u304D\u3064\u3081\u306B\u8A66\u7B97\u3057\u3066\u5352\u696D\u307E\u3067\u306B\u7D42\u308F\u3089\u306A\u3044\u7D50\u679C\u51FA\u3066\u95C7\u3092\u611F\u3058\u305F",
  "id" : 333186549992787968,
  "created_at" : "2013-05-11 11:47:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333186363774083074",
  "text" : "\u30DE\u30A4\u30F3\u30B9\u30A4\u30FC\u30D1\u30FC\u306E\u30BF\u30A4\u30E0\u30A2\u30BF\u30C3\u30AB\u30FC\u3088\u308A\u30BD\u30EA\u30C6\u30A3\u30A2\u306E\u30BF\u30A4\u30E0\u30A2\u30BF\u30C3\u30AB\u30FC\u306E\u65B9\u304C\u5E0C\u5C11\u306A\u5370\u8C61[\u305D\u3057\u3066\u30D5\u30EA\u30FC\u30BB\u30EB\u30B3\u30F3\u30D7\u30EA\u30FC\u30BF\u30FC\u306E\u65B9\u304C\u306A\u304A\u3084\u3070\u3044]",
  "id" : 333186363774083074,
  "created_at" : "2013-05-11 11:46:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333183988208394242",
  "text" : "\u300C\u82E5\u8005\u306Ehogehoge\u96E2\u308C\u304C\u53EB\u3070\u308C\u308B\u6628\u4ECA\u300D\u3001\u3068\u3044\u3046\u30C6\u30F3\u30D7\u30EC\u3001\u4F55\u5165\u308C\u3066\u3082\u9762\u767D\u3044\u611F\u3058\u306B\u306A\u308B\u5272\u306B\u4E2D\u8EAB\u304C\u306A\u3044\u304B\u3089\u7D50\u69CB\u6C17\u306B\u5165\u3063\u3066\u308B",
  "id" : 333183988208394242,
  "created_at" : "2013-05-11 11:37:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333116301646127104",
  "geo" : { },
  "id_str" : "333183613657047041",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u25CB\u25CB\u306E\u7CBE\u3001\u82E5\u8005\u306Ehogehoge\u96E2\u308C\u304C\u53EB\u3070\u308C\u308B\u6628\u4ECA",
  "id" : 333183613657047041,
  "in_reply_to_status_id" : 333116301646127104,
  "created_at" : "2013-05-11 11:35:38 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333115114439979009",
  "text" : "\u3069\u3093\u3066\u3093",
  "id" : 333115114439979009,
  "created_at" : "2013-05-11 07:03:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332923092697497600",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u30B5\u30F3\u30B8\uFF1F\uFF01\u30B5\u30F3\u30B8\u30CA\u30F3\u30C7\uFF1F\uFF01",
  "id" : 332923092697497600,
  "created_at" : "2013-05-10 18:20:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3080\u308ABABEL",
      "screen_name" : "CKPOMHOCTb",
      "indices" : [ 0, 11 ],
      "id_str" : "190136474",
      "id" : 190136474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332901103727435776",
  "geo" : { },
  "id_str" : "332922635505782784",
  "in_reply_to_user_id" : 190136474,
  "text" : "@CKPOMHOCTb \u307E\u3041\u983B\u5EA6\u3067\u8A00\u3048\u3070\u3042\u3063\u3061\u306E\u65B9\u304C\u9AD8\u3044\u306E\u3067\u3059\u304C\uFF0C\u50D5\u3082\u50D5\u3067\u6642\u3005\u9A12\u3005\u3057\u304F\u3057\u3066\u3044\u308B\u306E\u3067(\u305F\u3076\u3093\uFF09\u5927\u4EBA\u3057\u304F\u6211\u6162\u3057\u307E\u3059\uFF0E",
  "id" : 332922635505782784,
  "in_reply_to_status_id" : 332901103727435776,
  "created_at" : "2013-05-10 18:18:36 +0000",
  "in_reply_to_screen_name" : "CKPOMHOCTb",
  "in_reply_to_user_id_str" : "190136474",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332889486348398592",
  "text" : "\u5B9F\u969B\u3046\u308B\u3055\u3044",
  "id" : 332889486348398592,
  "created_at" : "2013-05-10 16:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332889465817296897",
  "text" : "\u96A3\u306E\u90E8\u5C4B\u3067\u5973\u5B50\u4F1A\u3081\u3044\u305F\u4E8B\u304C\u884C\u308F\u308C\u3066\u3044\u308B\u3088\u3046\u3060\u304C\u9A12\u304E\u58F0\u306F\u30AE\u30E3\u30FC\u30AE\u30E3\u30FC\u3057\u3066\u3066\u30A2\u30EC",
  "id" : 332889465817296897,
  "created_at" : "2013-05-10 16:06:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332759988709756928",
  "text" : "\u73FE\u4EE3\u306E\u3046\u3093\u3058\u3083\u3089\u307A\u30FC\u3068\u3046\u3093\u3058\u3083\u3089\u307A\u30FC\u89E3\u6790",
  "id" : 332759988709756928,
  "created_at" : "2013-05-10 07:32:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332729843940745217",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u8A3C\u660E\u529B",
  "id" : 332729843940745217,
  "created_at" : "2013-05-10 05:32:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ytb",
      "screen_name" : "ytb_at_twt",
      "indices" : [ 3, 14 ],
      "id_str" : "42124943",
      "id" : 42124943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332729805894193152",
  "text" : "RT @ytb_at_twt: \u300C\u4EBA\u9593\u529B\u300D\u300C\u30B3\u30DF\u30E5\u529B\u300D\u306B\u6B21\u3050\u7B2C\u4E09\u306E\u529B\u300C\u8A3C\u660E\u529B\u300D\uFF01\u541B\u3082\u8AD6\u7406\u5B66\u3092\u5B66\u3093\u3067\u8A3C\u660E\u529B\u30A2\u30C3\u30D7\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332701048265392128",
    "text" : "\u300C\u4EBA\u9593\u529B\u300D\u300C\u30B3\u30DF\u30E5\u529B\u300D\u306B\u6B21\u3050\u7B2C\u4E09\u306E\u529B\u300C\u8A3C\u660E\u529B\u300D\uFF01\u541B\u3082\u8AD6\u7406\u5B66\u3092\u5B66\u3093\u3067\u8A3C\u660E\u529B\u30A2\u30C3\u30D7\uFF01\uFF01",
    "id" : 332701048265392128,
    "created_at" : "2013-05-10 03:38:05 +0000",
    "user" : {
      "name" : "ytb",
      "screen_name" : "ytb_at_twt",
      "protected" : false,
      "id_str" : "42124943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576633081404092416\/lWcL34j-_normal.jpeg",
      "id" : 42124943,
      "verified" : false
    }
  },
  "id" : 332729805894193152,
  "created_at" : "2013-05-10 05:32:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332665474104057856",
  "text" : "\u7A7A\u8179\u304C\u304A\u8179\u6E1B\u3063\u305F\uFF01",
  "id" : 332665474104057856,
  "created_at" : "2013-05-10 01:16:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332653004140445696",
  "text" : "\u6EA2\u308C\u51FA\u308B\u7720\u305F\u307F\u3068\u9759\u304B\u306B\u6226\u3063\u3066\u3044\u308B",
  "id" : 332653004140445696,
  "created_at" : "2013-05-10 00:27:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332652208728457216",
  "text" : "\u7761\u7720\u304C\u7720\u305F\u3044(\u932F\u4E71)",
  "id" : 332652208728457216,
  "created_at" : "2013-05-10 00:24:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332531651018117120",
  "text" : "@ayuretti \u3069\u3061\u3089\u3082\u3055\u3057\u3066\u4F7F\u3063\u3066\u306A\u3044\u304B\u3089\u3042\u308C\u3060\u304C\u3001\u306A\u308C\u308C\u3070\u5927\u5DEE\u306A\u3044\u3089\u3057\u3044\u3067",
  "id" : 332531651018117120,
  "created_at" : "2013-05-09 16:24:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332530171691278336",
  "text" : "@ayuretti \uFF71\uFF72\uFF74\uFF74\uFF74\uFF74\u2026",
  "id" : 332530171691278336,
  "created_at" : "2013-05-09 16:19:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332529818203721728",
  "text" : "\u64CD\u4F5C\u306E\u8EFD\u3055\u3068\u901F\u3055\u306Fvim\u3060\u3051\u3069\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA\u3068\u304B\u591A\u69D8\u6027\u3067\u306Femacs\u3068\u3044\u3046\u611F\u3058\u306A\u306E\u304B\u306A\u3002\uFF3B\u3067\u3001TeX\u306F\uFF1F\uFF3D",
  "id" : 332529818203721728,
  "created_at" : "2013-05-09 16:17:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332529600888467456",
  "text" : "TeX\u306B\u7684\u3092\u7D5E\u3063\u305F\u6BD4\u8F03\u3092\u3057\u305F\u30DA\u30FC\u30B8\u304C\u306A\u3044\u306E\u304C\u6B8B\u5FF5",
  "id" : 332529600888467456,
  "created_at" : "2013-05-09 16:16:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332529082115960832",
  "text" : "[vi \u306E\u30B3\u30DE\u30F3\u30C9\u306F Ctrl \u3068\u304B Alt \u3068\u3044\u3063\u305F\u4FEE\u98FE\u30AD\u30FC\u3092\u307B\u3068\u3093\u3069\u4F7F\u308F\u305A\u306B\u5165\u529B\u3067\u304D\u308B\u3002\u3053\u308C\u306B\u3088\u308A\u8171\u9798\u708E\u306B\u306A\u308B\u53EF\u80FD\u6027\u304C\u6E1B\u308B\u3002]  \u3046\u3051\u308B\uFF57\uFF57\uFF57\uFF57\uFF57\u3010wiki\uFF1A\u30A8\u30C7\u30A3\u30BF\u6226\u4E89\u3011",
  "id" : 332529082115960832,
  "created_at" : "2013-05-09 16:14:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332524724032790529",
  "text" : "\u4E21\u65B9\u4F7F\u3046\u306B\u3083\u3093\u3055\u3093\u306B\u306A\u308A\u305F\u3044\u4EBA\u751F\u3060\u3063\u305F",
  "id" : 332524724032790529,
  "created_at" : "2013-05-09 15:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332524638976487424",
  "text" : "\u30A8\u30C7\u30A3\u30BF\u6226\u4E89,\u6226\u3046\u524D\u304B\u3089\u3069\u3061\u3089\u3067\u3082\u306A\u3044\u4F55\u304B\u306B\u8CA0\u3051\u3066\u3044\u308B\u611F\u3058\u3059\u308B\uFF0E",
  "id" : 332524638976487424,
  "created_at" : "2013-05-09 15:57:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332523427753783297",
  "text" : "\u524D\u4EF6\u304C\u6E80\u305F\u3055\u308C\u306A\u3044\u3068\u3044\u3046\u8840\u3082\u6D99\u3082\u306A\u3044\u7D50\u672B\u304C\u898B\u3048\u308B\uFF01\u30CA\u30E0\u30B5\u30F3\uFF01",
  "id" : 332523427753783297,
  "created_at" : "2013-05-09 15:52:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332522806774476801",
  "text" : "\u306F\u3084\u304F\u3082vim\u3092\u6271\u3046\u30E2\u30C1\u30D9\u4E0B\u304C\u3063\u3066\u308B\u306A\uFF1F",
  "id" : 332522806774476801,
  "created_at" : "2013-05-09 15:49:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332522733483200514",
  "text" : "@ayuretti \u591A\u5206\u3084\u3089\u306A\u3044[vim\u843D\u3068\u3057\u3066\u6765\u305F\u3051\u3069emacs\u3088\u308A\u76F4\u611F\u7684\u3067\u306A\u3044][\u306A\u304Aemacs\u3082\u76F4\u611F\u7684\u3067\u306F\u306A\u3044]",
  "id" : 332522733483200514,
  "created_at" : "2013-05-09 15:49:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332517983853355010",
  "text" : "vim\u3082\u8A66\u3057\u3066\u307F\u3088\u3046\u3063\u3068",
  "id" : 332517983853355010,
  "created_at" : "2013-05-09 15:30:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332517820162244609",
  "text" : "\u5DE6\u624B\u306E\u5C0F\u6307\u3092\u935B\u3048\u308B\u5FC5\u8981\u6027\u304C\u3042\u308B\u306A\uFF1F",
  "id" : 332517820162244609,
  "created_at" : "2013-05-09 15:30:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332517760875769856",
  "text" : "\u3053\u308C\u6163\u308C\u305F\u3089emacs\u306E\u65B9\u304C\u901F\u5EA6\u3067\u305D\u3046\u3060\u306A[\u4F55\u3088\u308A\u5DE6\u53F3\u306E\u30AB\u30FC\u30BD\u30EB\u306E\u52B9\u304B\u306A\u3044\u306E\u3092\u30AB\u30D0\u30FC\u3067\u304D\u308B]",
  "id" : 332517760875769856,
  "created_at" : "2013-05-09 15:29:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332499098395631616",
  "text" : "\u5931\u3063\u305FTeX\u529B\u3092\u53D6\u308A\u623B\u3057\u306B",
  "id" : 332499098395631616,
  "created_at" : "2013-05-09 14:15:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332497384015798275",
  "geo" : { },
  "id_str" : "332497875621781504",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u304A\u3068\u3068\u3044\u307E\u3067\u3044\u305F\u306E\u3067\u3059\u304C\u5FD9\u3057\u304B\u3063\u305F\u306E\u3067\u2026\u591A\u5206\u6B21\u306F8\u6708\u3067\u3059\u304B\u306D",
  "id" : 332497875621781504,
  "in_reply_to_status_id" : 332497384015798275,
  "created_at" : "2013-05-09 14:10:45 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332496901259792385",
  "text" : "\u6C17\u306B\u306A\u3063\u3066\u591C\u3057\u304B\u7720\u308C\u306A\u3044",
  "id" : 332496901259792385,
  "created_at" : "2013-05-09 14:06:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332496312442449920",
  "text" : "\u3053\u308C\u306A\u3093\u3067\u8A3C\u660E\u306E\u30E9\u30D9\u30EB\u3064\u3044\u3066\u3093\u306E\u304B\u308F\u304B\u3089\u3093\u307D\u3093",
  "id" : 332496312442449920,
  "created_at" : "2013-05-09 14:04:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8A3C\u660E\u3068\u306F\u306A\u3093\u305F\u3063\u305F\u306E\u304B",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332496233874718720",
  "text" : "[\u8A3C\u660E]1,2\u306F\u5BB9\u6613.3,4\u306F\u7701\u7565.5\u306F4\u3088\u308A\u51FA\u308B.\u25A1 #\u8A3C\u660E\u3068\u306F\u306A\u3093\u305F\u3063\u305F\u306E\u304B",
  "id" : 332496233874718720,
  "created_at" : "2013-05-09 14:04:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332493302676987905",
  "text" : "\u3064\u3044\u3063\u305F\u3041\u3092 \u3084\u3063\u3066\u3044\u308B\u3070\u3042\u3044\u3058\u3083 \u306A\u3044\u3093\u3060\u306A\u3041 (\u3048\u3044\u305F\u3093)",
  "id" : 332493302676987905,
  "created_at" : "2013-05-09 13:52:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332493200700895233",
  "text" : "ubuntu\u5F04\u308A\u305F\u3044\u3057\u30BC\u30DF\u306E\u4E88\u7FD2\u3057\u306A\u304D\u3083\u3060\u3057\u30EC\u30B8\u30E5\u30E1\u4F5C\u3089\u306A\u304D\u3083\u3060\u3057(^^)(^^)(^^)\u5FD9\u3057\u3044(^^)(^^)(^^)",
  "id" : 332493200700895233,
  "created_at" : "2013-05-09 13:52:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332492477959385088",
  "text" : "\u3089\u3053\u3089\u3053\u3089\u3053\u301C\uFF1F",
  "id" : 332492477959385088,
  "created_at" : "2013-05-09 13:49:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332492212426387456",
  "text" : "\u5E38\u4EBA\u306E3\u500D\u306E\u8A08\u7B97\u529B\u3068\u304B\uFF1F\u5E38\u4EBA\u306E3\u500D\u306Etex\u30BF\u30A4\u30D4\u30F3\u30B0\u3068\u304B\uFF1F",
  "id" : 332492212426387456,
  "created_at" : "2013-05-09 13:48:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3068\u306F",
      "indices" : [ 8, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332492037880430592",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u6570\u5B66\u529B #\u3068\u306F",
  "id" : 332492037880430592,
  "created_at" : "2013-05-09 13:47:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332492006637064193",
  "text" : "\u975E\u30CB\u30F3\u30B8\u30E3\u5B58\u5728\u3060\u304B\u3089\u30CB\u30F3\u30B8\u30E3\u6570\u5B66\u529B\u7121\u304F\u3066\u3064\u3089\u3044",
  "id" : 332492006637064193,
  "created_at" : "2013-05-09 13:47:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332491567938039810",
  "text" : "\u300C\u30AD\u30A7\u30A7\u30A7\u30A7\u300D\u3082\u300C\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u300D\u3082\u65E5\u5E38\u3067\u4F7F\u3046\u3068\u7570\u69D8\u306A\u9055\u548C\u611F\u304C\u3042\u3063\u3066\u826F\u3044\u611F\u3058\u3059\u308B(^^)(^^)(^^)",
  "id" : 332491567938039810,
  "created_at" : "2013-05-09 13:45:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 0, 14 ],
      "id_str" : "205210585",
      "id" : 205210585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332491140018339840",
  "geo" : { },
  "id_str" : "332491333577093120",
  "in_reply_to_user_id" : 205210585,
  "text" : "@yasuhitoakita \u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u2026",
  "id" : 332491333577093120,
  "in_reply_to_status_id" : 332491140018339840,
  "created_at" : "2013-05-09 13:44:45 +0000",
  "in_reply_to_screen_name" : "yasuhitoakita",
  "in_reply_to_user_id_str" : "205210585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332490710060236801",
  "text" : "(\u300D\u30FB\u03C9\u30FB)\u300D\u30A4\u30E4\u30FC\u30C3\uFF01(\uFF0F\u30FB\u03C9\u30FB)\uFF0F\u30B0\u30EF\u30FC\u30C3\uFF01",
  "id" : 332490710060236801,
  "created_at" : "2013-05-09 13:42:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332465104425730049",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 332465104425730049,
  "created_at" : "2013-05-09 12:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332443272750460929",
  "geo" : { },
  "id_str" : "332447756897615872",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30AA\u30BD\u30DE\u30C4\u30B5\u30DE\u30C7\u30B7\u30BF\u30FC\uFF01\uFF01\uFF01",
  "id" : 332447756897615872,
  "in_reply_to_status_id" : 332443272750460929,
  "created_at" : "2013-05-09 10:51:36 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332437063603458048",
  "text" : "\u3060\u304C\u3053\u306E\u8F9B\u3055\u304C\u305F\u307E\u3089\u306A\u3044\uFF0E\u4E00\u5473\u305B\u3093\u3079\u3044\u5927\u597D\u304D\uFF0E\u3042\u306E\u982D\u60AA\u3044\u611F\u3058\u304C\uFF0E",
  "id" : 332437063603458048,
  "created_at" : "2013-05-09 10:09:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332436933479395328",
  "text" : "\u3051\u3069\u8F9B\u304F\u3066\u60B6\u7D76\u3057\u3066\u3044\u308B",
  "id" : 332436933479395328,
  "created_at" : "2013-05-09 10:08:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332436897639043072",
  "text" : "\u51B7\u9EA6\u306E\u3064\u3051\u6C41\u306B\u4E00\u5473\u305B\u3093\u3079\u3044\u7815\u3044\u3066\u30C8\u30C3\u30D4\u30F3\u30B0\u3057\u305F\u3089\u304A\u3044\u3057\u304B\uFF54\u3063\u305F",
  "id" : 332436897639043072,
  "created_at" : "2013-05-09 10:08:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332432351915282432",
  "text" : "\u5B9F\u969B\u51B7\u9EA6\u5B9F\u969B\u7F8E\u5473\u3057\u3044",
  "id" : 332432351915282432,
  "created_at" : "2013-05-09 09:50:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332432333254819840",
  "text" : "\u3072\u3084\u3080\u304E\u3086\u3067\u307E\u3059[\u30D0\u30AB\u306E\u4E00\u3064\u899A\u3048]",
  "id" : 332432333254819840,
  "created_at" : "2013-05-09 09:50:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u501F\u308A\u65C5\u884C\u306E\u30C8\u30DE\u30B8\u30A6\u30B9",
      "screen_name" : "kagyu_phis",
      "indices" : [ 0, 11 ],
      "id_str" : "129850436",
      "id" : 129850436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332416039595958272",
  "geo" : { },
  "id_str" : "332416302914342912",
  "in_reply_to_user_id" : 129850436,
  "text" : "@kagyu_phis \u3044\u3048\u3044\u3048\uFF0C\u3084\u3063\u3071\u308AYaTeX\u3067\u3059\u304B\u30FC\uFF0E[\u3053\u306E\u524Dkeno\u3055\u3093\u306Bauctex\u306A\u308B\u3082\u306E\u3092\u6559\u3048\u3066\u3044\u305F\u3060\u3044\u305F\u306E\u3067\u4ECA\u305D\u308C\u3092\u305B\u3063\u305B\u3068\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u3057\u3066\u307E\u3059\uFF0E]",
  "id" : 332416302914342912,
  "in_reply_to_status_id" : 332416039595958272,
  "created_at" : "2013-05-09 08:46:37 +0000",
  "in_reply_to_screen_name" : "kagyu_phis",
  "in_reply_to_user_id_str" : "129850436",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332412034597658624",
  "text" : "19\u6642\u307E\u3067\u9069\u5F53\u306B\u3044\u308D\u3044\u308D\u5165\u308C\u3066\u307F\u3088\u3046\uFF0EVim\u3082emacs\u3082TeXmaker\u3082",
  "id" : 332412034597658624,
  "created_at" : "2013-05-09 08:29:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332411258542383104",
  "text" : "\u6771\u4EAC\u304B\u3089\u8F38\u5165\u3057\u3066\u304D\u305F\u30C9\u30AF\u30DA\u304C\u51B7\u3048\u3066\u308B\u304B\u3089\u30AB\u30C1\u30B0\u30DF",
  "id" : 332411258542383104,
  "created_at" : "2013-05-09 08:26:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332411096235380736",
  "text" : "\u305D\u3057\u3066\u30CE\u30FC\u30C8PC\u5DE6\u53F3\u306E\u30AD\u30FC\u304C\u52B9\u304B\u306A\u304F\u306A\u3063\u3066\u308B\u306E\u5B9F\u969B\u81F4\u547D\u7684\u3060\u306A\uFF1F",
  "id" : 332411096235380736,
  "created_at" : "2013-05-09 08:25:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332411026454769665",
  "text" : "\u3046\u30FC\u3080\uFF0E\u3069\u3046\u3057\u305F\u3082\u306E\u304B\uFF0ETeX\u5C02\u7528\u306E\u30A8\u30C7\u30A3\u30BF\u3068\u306F\u3044\u3048\uFF0C\u3053\u3053\u3067emacs\u5165\u308C\u306A\u3044\u3053\u3068\u306B\u306F\u304A\u305D\u3089\u304F\u590F\u4EE5\u964D\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u3092\u518D\u958B\u3059\u308B\u307E\u3067emacs\u5165\u3089\u306A\u3044\u3057\u6163\u308C\u306A\u3044\u3060\u308D\u3046\u306A\uFF0E",
  "id" : 332411026454769665,
  "created_at" : "2013-05-09 08:25:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332410421308977152",
  "text" : "TeXmaker\u77E5\u540D\u5EA6\u5B9F\u969B\u4F4E\u3044\u611F\u3058\u3059\u308B\uFF0E\u81EA\u5206\u4EE5\u5916\u3064\u304B\u3063\u3066\u308B\u4EBA\u77E5\u3089\u306A\u3044\uFF0E",
  "id" : 332410421308977152,
  "created_at" : "2013-05-09 08:23:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u501F\u308A\u65C5\u884C\u306E\u30C8\u30DE\u30B8\u30A6\u30B9",
      "screen_name" : "kagyu_phis",
      "indices" : [ 0, 11 ],
      "id_str" : "129850436",
      "id" : 129850436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332409598730452992",
  "geo" : { },
  "id_str" : "332410355059941376",
  "in_reply_to_user_id" : 129850436,
  "text" : "@kagyu_phis \u30D7\u30E9\u30B0\u30A4\u30F3\u540C\u58EB\u3067\u7AF6\u5408\u3057\u305F\u308A\u3059\u308B\uFF0C\u307F\u305F\u3044\u306A\u66F8\u304D\u8FBC\u307F\u3082\u3061\u3089\u307B\u3089\u3067\u3059\u306D\uFF0ETeX\u5C02\u7528\u306E\u30A8\u30C7\u30A3\u30BF\u3063\u3066\u7D50\u5C40TeXmaker\u3050\u3089\u3044\u3057\u304B\u77E5\u3089\u306A\u3044\u306E\u3067\u3059\u304C\uFF0C\u4F7F\u3044\u3084\u3059\u3044\u306E\u3054\u5B58\u77E5\u3067\u3059\u304B\uFF1F",
  "id" : 332410355059941376,
  "in_reply_to_status_id" : 332409598730452992,
  "created_at" : "2013-05-09 08:22:59 +0000",
  "in_reply_to_screen_name" : "kagyu_phis",
  "in_reply_to_user_id_str" : "129850436",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332408739254644738",
  "text" : "YATEX\u3001auctex\u306F\u30AA\u30B9\u30B9\u30E1\u3055\u308C\u305F\u3051\u3069vim\u52E2\u306F\u3069\u3046\u3057\u3066\u308B\u3093\u3060\u308D",
  "id" : 332408739254644738,
  "created_at" : "2013-05-09 08:16:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332408529140973569",
  "text" : "emacs\u3068vim\u3001\u3069\u3063\u3061\u3082\u6163\u308C\u3066\u306A\u3044\u3051\u3069tex\u6253\u3064\u306A\u3089\u3069\u3063\u3061\u304C\u3044\u3044\u3093\u3060\u308D\u3046?[\u305D\u3057\u3066\u3069\u306E\u30A2\u30D7\u30EA\u304C\uFF1F][texmaker\u5B9F\u969B\u4F7F\u3044\u3084\u3059\u304B\u3063\u305F\u304C]",
  "id" : 332408529140973569,
  "created_at" : "2013-05-09 08:15:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332325990107848704",
  "text" : "\u3072\u3084\u3080\u304E\u3086\u3067\u308B",
  "id" : 332325990107848704,
  "created_at" : "2013-05-09 02:47:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332205075491610625",
  "text" : "\u30AA\u30E4\u30B9\u30DF\uFF01\uFF01\uFF01",
  "id" : 332205075491610625,
  "created_at" : "2013-05-08 18:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332203317969166336",
  "text" : "\u305F\u3060\u307E\u3041Windows\u5ACC\u3046\u4EBA\u306E\u6C17\u6301\u3061\u304C\u3060\u3044\u3076\u5206\u304B\u3063\u305F[\u6C37\u5C71\u306E\u4E00\u89D2\u306A]",
  "id" : 332203317969166336,
  "created_at" : "2013-05-08 18:40:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332203035835105280",
  "text" : "windows\u5ACC\u3044\u306B\u306A\u308B\u307B\u3069\u3067\u306F\u306A\u3044\u3051\u3069windowsupdate\u306B\u306F\u4ECA\u5F8C\u8B66\u6212\u3092\u6020\u3089\u306A\u3044\u5FC3\u7A4D\u3082\u308A\u3067",
  "id" : 332203035835105280,
  "created_at" : "2013-05-08 18:39:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332202723065872385",
  "text" : "\u4E00\u65E5\u3067\u60C5\u5F37\u306B\u306A\u3063\u305F\u611F\u3058\u304C\u3057\u3066\u308B\u304C\u6C17\u306E\u305B\u3044\u306A\u3093\u3060\u305C[\u3046\u3060\u3061\u3083\u3093\u3068\u306E\u306A\u3055\u3093\u306E\u8A00\u3063\u3066\u308B\u4E8B\u534A\u5206\u3082\u308F\u304B\u3089\u3093\u307D\u3093\u3060\u3063\u305F\u306A][\u656C\u79F0\u9006\u306A]",
  "id" : 332202723065872385,
  "created_at" : "2013-05-08 18:37:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332202292193415169",
  "text" : "\u304D\u3063\u304B\u308A\u30D1\u30FC\u30C6\u30A3\u30B7\u30E7\u30F3\u5206\u3051\u305F\u3057\u3001\u4EEE\u88C5\u30C7\u30A3\u30B9\u30AF\u3067\u306A\u304F\u3061\u3083\u3093\u3068grub\u304B\u3089\u8D77\u52D5\u3057\u3066\u308B\u3057\u3001\u591A\u5206\u5927\u4E08\u592B",
  "id" : 332202292193415169,
  "created_at" : "2013-05-08 18:36:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332201144283709440",
  "text" : "\u3068\u308A\u3042\u3048\u305Aubuntu\u3067\u30CD\u30C3\u30C8\u306B\u7E4B\u304C\u308B\u3068\u3053\u308D\u307E\u3067\u6765\u305F\u3057\u304A\u7D42\u3044\u306B\u3057\u3066\u5BDD\u3088\u5BDD\u3088",
  "id" : 332201144283709440,
  "created_at" : "2013-05-08 18:31:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332190260173873152",
  "text" : "\u3082\u30463\u6642 of the world",
  "id" : 332190260173873152,
  "created_at" : "2013-05-08 17:48:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332143413220761600",
  "text" : "\u307E\u305F\u5F8C\u8F29\u306B\u300C\u6700\u8FD1TL\u306B\u3044\u306A\u3044\u3067\u3059\u306D\u300D\u3063\u3066\u717D\u3089\u308C\u305F",
  "id" : 332143413220761600,
  "created_at" : "2013-05-08 14:42:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/DBE81TGkm1",
      "expanded_url" : "http:\/\/togetter.com\/li\/491791",
      "display_url" : "togetter.com\/li\/491791"
    } ]
  },
  "geo" : { },
  "id_str" : "332115225732083714",
  "text" : "\u307E\u3068\u3081\u3092\u66F4\u65B0\u3057\u307E\u3057\u305F\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01 \u300C\u8D77\u52D5\u3057\u306A\u304B\u3063\u305Fend\u3055\u3093\u306EUbuntu\u300D http:\/\/t.co\/DBE81TGkm1",
  "id" : 332115225732083714,
  "created_at" : "2013-05-08 12:50:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332113711366029312",
  "text" : "Uda\u3055\u3093\u300C(\u753B\u9762\u3092\u898B\u306A\u304C\u3089)\u3053\u308C\u306F\u30AA\u30C0\u30D6\u30C4\u306A\u306E\u3067\u306F...\u300D\n\u306E\u306A\u3061\u3083\u3093\u300C\u3053\u308C\u306F\u53B3\u3057\u3044\u3067\u3059\u306D...\u300D\nend\u300C\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8...\u300D",
  "id" : 332113711366029312,
  "created_at" : "2013-05-08 12:44:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332113205067411456",
  "text" : "\u3055\u30FC\u3066\u4ECA\u5EA6\u306FWindows\u304C\u60AA\u3055\u3057\u306A\u3044\u3088\u3046\u306A\u5F62\u3067\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u3057\u307E\u3059\u304B\u30A1\uFF01[\u524A\u3089\u308C\u3066\u3044\u304F\u7761\u7720\u6642\u9593\u3047\u3047\u3047]",
  "id" : 332113205067411456,
  "created_at" : "2013-05-08 12:42:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332112284841279490",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\uFF01\uFF01\uFF01",
  "id" : 332112284841279490,
  "created_at" : "2013-05-08 12:38:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332112250712252416",
  "text" : "\u30CA\u30E0\u30A2\u30DF\u30C0\u30D6\u30C4\uFF01\u30A8\u30F3\u30C9\uFF1D\u30B5\u30F3\u306EUbuntu\u306E\u30C7\u30FC\u30BF\u304C\u7206\u767A\u56DB\u6563\uFF01",
  "id" : 332112250712252416,
  "created_at" : "2013-05-08 12:38:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332111934667235328",
  "text" : "\u60AA\u3055\u3057\u305FWindowsU\uFF50date\u3092\u5C0F\u4E00\u6642\u9593\u554F\u3044\u8A70\u3081\u305F\u3044\uFF0E",
  "id" : 332111934667235328,
  "created_at" : "2013-05-08 12:37:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332111784314036224",
  "text" : "\u3010\u901F\u5831\u3011Ubuntu\u304C\u8D77\u52D5\u3057\u306A\u3044\u554F\u984C\uFF0C\u5426\u5B9A\u7684\u306B\u89E3\u6C7A\uFF0E",
  "id" : 332111784314036224,
  "created_at" : "2013-05-08 12:36:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332033513824079872",
  "geo" : { },
  "id_str" : "332034339846115328",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u30D0\u30A4\u30C8\u3067\u3057\u2026",
  "id" : 332034339846115328,
  "in_reply_to_status_id" : 332033513824079872,
  "created_at" : "2013-05-08 07:28:50 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331999662179483648",
  "text" : "\u30DE\u30A4\u30EA\u30B9\u98DB\u3093\u3067\u304F\u308B\u306E\u304B\u3001\u3073\u3063\u304F\u308A\u3057\u305F",
  "id" : 331999662179483648,
  "created_at" : "2013-05-08 05:11:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nicovideo.jp\/\" rel=\"nofollow\"\u003Eniconico \u30CB\u30B3\u30EC\u30DD\u9023\u643A\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sm20577495",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/UDXqEjKCej",
      "expanded_url" : "http:\/\/nico.ms\/sm20577495",
      "display_url" : "nico.ms\/sm20577495"
    } ]
  },
  "geo" : { },
  "id_str" : "331996821041848320",
  "text" : "[My List] \u3010\u6700\u9AD8\u97F3\u8CEA320k\u3011sister's noise FULL\u3010\u3068\u3042\u308B\u79D1\u5B66\u306E\u8D85\u96FB\u78C1\u7832S OP\u3011 http:\/\/t.co\/UDXqEjKCej #sm20577495",
  "id" : 331996821041848320,
  "created_at" : "2013-05-08 04:59:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331994863967039488",
  "text" : "\u6628\u591CIPad\u306E\u5145\u96FB\u5FD8\u308C\u305F\u306A\uFF1F",
  "id" : 331994863967039488,
  "created_at" : "2013-05-08 04:51:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331988075188207617",
  "text" : "\u60B2\u9CF4\u4F1D\u304B\uFF0E\u826F\u3044\u306A\u30FC\uFF0E\u571F\u66DC\u65E5\u3060\u3068\u884C\u3051\u306A\u3044\u3051\u308C\u3069\uFF0E",
  "id" : 331988075188207617,
  "created_at" : "2013-05-08 04:24:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 3, 18 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/uFrZNxv8xR",
      "expanded_url" : "http:\/\/www.gaccoh.jp\/?p=4215",
      "display_url" : "gaccoh.jp\/?p=4215"
    } ]
  },
  "geo" : { },
  "id_str" : "331987973451153410",
  "text" : "RT @mircea_morning: GACCOH\u5C0F\u8AAC\u8AAD\u66F8\u4F1A \/ \u6B21\u56DE\u30FB\u897F\u5C3E\u7DAD\u65B0\u300C\u60B2\u9CF4\u4F1D\u300D2013.5.11.Sat 14:00- http:\/\/t.co\/uFrZNxv8xR\u3000\u4EAC\u90FD\u306E\u65B9\u3001\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059\u30FC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/uFrZNxv8xR",
        "expanded_url" : "http:\/\/www.gaccoh.jp\/?p=4215",
        "display_url" : "gaccoh.jp\/?p=4215"
      } ]
    },
    "geo" : { },
    "id_str" : "331981444018733057",
    "text" : "GACCOH\u5C0F\u8AAC\u8AAD\u66F8\u4F1A \/ \u6B21\u56DE\u30FB\u897F\u5C3E\u7DAD\u65B0\u300C\u60B2\u9CF4\u4F1D\u300D2013.5.11.Sat 14:00- http:\/\/t.co\/uFrZNxv8xR\u3000\u4EAC\u90FD\u306E\u65B9\u3001\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059\u30FC",
    "id" : 331981444018733057,
    "created_at" : "2013-05-08 03:58:38 +0000",
    "user" : {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "protected" : false,
      "id_str" : "199550192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494419651342774272\/VcykhvGX_normal.jpeg",
      "id" : 199550192,
      "verified" : false
    }
  },
  "id" : 331987973451153410,
  "created_at" : "2013-05-08 04:24:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331949174427906048",
  "text" : "\u6012\u9CF4\u308B\u5927\u4EBA\u306F\u30A2\u30EC",
  "id" : 331949174427906048,
  "created_at" : "2013-05-08 01:50:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331948857757925376",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 331948857757925376,
  "created_at" : "2013-05-08 01:49:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331948807233347584",
  "text" : "\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\"\u8D77\u3053\u3055\u308C\u305F\"\u306F,\"\u8D77\u304D\u3089\u308C\u305F\"\u3068\u533A\u5225\u304C\u3064\u304B\u306A\u3044",
  "id" : 331948807233347584,
  "created_at" : "2013-05-08 01:48:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3084\u30BF\u30B3\u30B9(\u261D \u055E\u0A0A \u055E)\u261D",
      "screen_name" : "miya_tacos",
      "indices" : [ 0, 11 ],
      "id_str" : "747261714",
      "id" : 747261714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331786593511821312",
  "geo" : { },
  "id_str" : "331786628047708160",
  "in_reply_to_user_id" : 747261714,
  "text" : "@miya_tacos \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 331786628047708160,
  "in_reply_to_status_id" : 331786593511821312,
  "created_at" : "2013-05-07 15:04:31 +0000",
  "in_reply_to_screen_name" : "miya_tacos",
  "in_reply_to_user_id_str" : "747261714",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331785965028909056",
  "text" : "\u30B7\u30E7\u30C3\u30AE\u30E7\u30FB\u30E0\u30C3\u30B8\u30E7\uFF01\u3058\u3083\u306D\u30FC\u3088\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 331785965028909056,
  "created_at" : "2013-05-07 15:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331785883193860096",
  "text" : "\u30BA\u30EB\u30A4\uFF01",
  "id" : 331785883193860096,
  "created_at" : "2013-05-07 15:01:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331784836568215552",
  "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71\uFF0C\u691C\u7D22\u3067\u898B\u3066\u308B\u3068\u660E\u3089\u304B\u306B\u6587\u5B57\u901A\u308A\u306E\u89E3\u91C8\u3067\u30CD\u30BF\u30C4\u30A4\u3057\u3066\u308B\u4EBA\u304C\u3044\u3066\u305D\u308C\u306F\u305D\u308C\u3067\u9762\u767D\u3044\uFF0E",
  "id" : 331784836568215552,
  "created_at" : "2013-05-07 14:57:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331784183401816065",
  "text" : "\u304B\u308A\u3093\u3068\u3046\u3068\u725B\u4E73\u3068\u304B\u8A00\u3046\u795E\u30B3\u30F3\u30D3\u30CD\u30FC\u30B7\u30E7\u30F3",
  "id" : 331784183401816065,
  "created_at" : "2013-05-07 14:54:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331783535482531842",
  "text" : "\u3053\u306E\u30B6\u30DE\u3060\u3088",
  "id" : 331783535482531842,
  "created_at" : "2013-05-07 14:52:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u6839\u30DE\u30F3\u306E\u4E2D\u306E\u5C0F\u4EBA",
      "screen_name" : "L1fer___daicon",
      "indices" : [ 3, 18 ],
      "id_str" : "161787322",
      "id" : 161787322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
      "indices" : [ 79, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331783494822928384",
  "text" : "RT @L1fer___daicon: \u3042\u308B\u3068\u3053\u308D\u306B\u304A\u3058\u3044\u3055\u3093\u3068\u304A\u3070\u3042\u3055\u3093\u3068\u30CB\u30F3\u30B8\u30E3\u304C\u5C45\u307E\u3057\u305F\u3002\n\u304A\u3058\u3044\u3055\u3093\u30FB\u304A\u3070\u3042\u3055\u3093\u300C\u30A2\u30A4\u30A8\u30A8\u30A8\uFF01\uFF1F\u30CB\u30F3\u30B8\u30E3\u30CA\u30F3\u30C7\uFF01\uFF1F\u300D\n#\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
        "indices" : [ 59, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331772311621468160",
    "text" : "\u3042\u308B\u3068\u3053\u308D\u306B\u304A\u3058\u3044\u3055\u3093\u3068\u304A\u3070\u3042\u3055\u3093\u3068\u30CB\u30F3\u30B8\u30E3\u304C\u5C45\u307E\u3057\u305F\u3002\n\u304A\u3058\u3044\u3055\u3093\u30FB\u304A\u3070\u3042\u3055\u3093\u300C\u30A2\u30A4\u30A8\u30A8\u30A8\uFF01\uFF1F\u30CB\u30F3\u30B8\u30E3\u30CA\u30F3\u30C7\uFF01\uFF1F\u300D\n#\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
    "id" : 331772311621468160,
    "created_at" : "2013-05-07 14:07:37 +0000",
    "user" : {
      "name" : "\u5927\u6839\u30DE\u30F3\u306E\u4E2D\u306E\u5C0F\u4EBA",
      "screen_name" : "L1fer___daicon",
      "protected" : false,
      "id_str" : "161787322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472956775738527745\/OJ3syfKs_normal.jpeg",
      "id" : 161787322,
      "verified" : false
    }
  },
  "id" : 331783494822928384,
  "created_at" : "2013-05-07 14:52:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u306E\u3055\u307E",
      "screen_name" : "Tonosamaner",
      "indices" : [ 3, 15 ],
      "id_str" : "243054019",
      "id" : 243054019
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331783452456259585",
  "text" : "RT @Tonosamaner: \u300C\u67AF\u308C\u6728\u306B\u82B1\u3092\u54B2\u304B\u305B\u307E\u3057\u3087\u3001\u30A4\u30E4\u30FC\u30C3\uFF01\u300D\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u300C\u30A4\u30E4\u30FC\u30C3\u300D\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u300C\u30A4\u30E4\u30FC\u30C3\u300D\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u300C\u30A4\u30E4\u30FC\u30C3\u300D\u300C\u30B5\u30E8\u30CA\u30E9\uFF01\u300D\u54C0\u308C\u30A4\u30B8\u30EF\u30EB\u723A\u3055\u3093\u306F\u7206\u767A\u56DB\u6563\uFF01\u300C\u6C5A\u3044\u82B1\u304C\u54B2\u3044\u305F\u306A\u3001\u30A4\u30B8\uFF1D\u30EF\u30EB\u30B8\u30A4\u30B5\u30F3\u300D #\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329845194369400832",
    "text" : "\u300C\u67AF\u308C\u6728\u306B\u82B1\u3092\u54B2\u304B\u305B\u307E\u3057\u3087\u3001\u30A4\u30E4\u30FC\u30C3\uFF01\u300D\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u300C\u30A4\u30E4\u30FC\u30C3\u300D\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u300C\u30A4\u30E4\u30FC\u30C3\u300D\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u300C\u30A4\u30E4\u30FC\u30C3\u300D\u300C\u30B5\u30E8\u30CA\u30E9\uFF01\u300D\u54C0\u308C\u30A4\u30B8\u30EF\u30EB\u723A\u3055\u3093\u306F\u7206\u767A\u56DB\u6563\uFF01\u300C\u6C5A\u3044\u82B1\u304C\u54B2\u3044\u305F\u306A\u3001\u30A4\u30B8\uFF1D\u30EF\u30EB\u30B8\u30A4\u30B5\u30F3\u300D #\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
    "id" : 329845194369400832,
    "created_at" : "2013-05-02 06:29:57 +0000",
    "user" : {
      "name" : "\u3068\u306E\u3055\u307E",
      "screen_name" : "Tonosamaner",
      "protected" : false,
      "id_str" : "243054019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586331914904043521\/dkApXc15_normal.jpg",
      "id" : 243054019,
      "verified" : false
    }
  },
  "id" : 331783452456259585,
  "created_at" : "2013-05-07 14:51:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30B9\u30DE\u30B9\u30AF\u30DE\u30F3\u6BD2\u5CF6",
      "screen_name" : "poiism",
      "indices" : [ 3, 10 ],
      "id_str" : "363472412",
      "id" : 363472412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331783435528052737",
  "text" : "RT @poiism: \u30A6\u30E9\u30B7\u30DE\uFF1D\u30B5\u30F3\u306F\u300E\u958B\u3051\u305F\u3089\u5B9F\u969B\u6B7B\u306C\u300F\u3068\u8A00\u308F\u308C\u3066\u3044\u305F\u30BF\u30DE\u30C6\u30DC\u30C3\u30AF\u30B9\u3092\u6211\u6162\u3067\u304D\u305A\u306B\u958B\u5C01\uFF01\u300CWasshoi!!\u300D\u30D6\u30C3\u30C0\uFF01\u306A\u3093\u3068\u4E2D\u304B\u3089\u30CB\u30F3\u30B8\u30E3\u304C\u98DB\u3073\u51FA\u3057\u3066\u304D\u305F\u3067\u306F\u306A\u3044\u304B\uFF01\uFF01\u300C\u7D04\u675F\u3092\u7834\u308B\u8005\u306B\u306F\u6B7B\u3092\u3001\u30A4\u30E4\u30FC\u30C3\uFF01\uFF01\u300D\u30A6\u30E9\u30B7\u30DE\uFF1D\u30B5\u30F3\u306F\u30CF\u30A4\u30AF\u3059\u3089\u8A60\u3081\u305A\u306B\u7206\u767A\u56DB\u6563\uFF01\u3000#\u5510\u7A81\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329804396961619968",
    "text" : "\u30A6\u30E9\u30B7\u30DE\uFF1D\u30B5\u30F3\u306F\u300E\u958B\u3051\u305F\u3089\u5B9F\u969B\u6B7B\u306C\u300F\u3068\u8A00\u308F\u308C\u3066\u3044\u305F\u30BF\u30DE\u30C6\u30DC\u30C3\u30AF\u30B9\u3092\u6211\u6162\u3067\u304D\u305A\u306B\u958B\u5C01\uFF01\u300CWasshoi!!\u300D\u30D6\u30C3\u30C0\uFF01\u306A\u3093\u3068\u4E2D\u304B\u3089\u30CB\u30F3\u30B8\u30E3\u304C\u98DB\u3073\u51FA\u3057\u3066\u304D\u305F\u3067\u306F\u306A\u3044\u304B\uFF01\uFF01\u300C\u7D04\u675F\u3092\u7834\u308B\u8005\u306B\u306F\u6B7B\u3092\u3001\u30A4\u30E4\u30FC\u30C3\uFF01\uFF01\u300D\u30A6\u30E9\u30B7\u30DE\uFF1D\u30B5\u30F3\u306F\u30CF\u30A4\u30AF\u3059\u3089\u8A60\u3081\u305A\u306B\u7206\u767A\u56DB\u6563\uFF01\u3000#\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
    "id" : 329804396961619968,
    "created_at" : "2013-05-02 03:47:50 +0000",
    "user" : {
      "name" : "\u30AC\u30B9\u30DE\u30B9\u30AF\u30DE\u30F3\u6BD2\u5CF6",
      "screen_name" : "poiism",
      "protected" : false,
      "id_str" : "363472412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483136987688235008\/vF-btPWt_normal.jpeg",
      "id" : 363472412,
      "verified" : false
    }
  },
  "id" : 331783435528052737,
  "created_at" : "2013-05-07 14:51:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u84BC\uFF20\u30CB\u30B3\u30CB\u30B3\u6280\u8853\u90E8",
      "screen_name" : "blaues",
      "indices" : [ 3, 10 ],
      "id_str" : "18827101",
      "id" : 18827101
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331783411956068352",
  "text" : "RT @blaues: \u300C\u89AA\u65B9\uFF01\u7A7A\u304B\u3089\u5973\u306E\u5B50\u304C\uFF01\u300D\u300CWasshoi!\u300D\u7A7A\u4E2D\u4E09\u56DE\u8EE2\u30A8\u30F3\u30C8\u30EA\u30FC\u3092\u6C7A\u3081\u305F\u30CB\u30F3\u30B8\u30E3\u306F\u305D\u306E\u307E\u307E\u5C11\u5973\u3092\u30A2\u30E9\u30D0\u30DE\u843D\u3068\u3057\u3067\u5730\u9762\u306B\u53E9\u304D\u3064\u3051\u308B\uFF01\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u5C11\u5973\u306F\u810A\u9AC4\u7C89\u7815\uFF01\u7206\u767A\u56DB\u6563\uFF01 #\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
        "indices" : [ 87, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329783680929251329",
    "text" : "\u300C\u89AA\u65B9\uFF01\u7A7A\u304B\u3089\u5973\u306E\u5B50\u304C\uFF01\u300D\u300CWasshoi!\u300D\u7A7A\u4E2D\u4E09\u56DE\u8EE2\u30A8\u30F3\u30C8\u30EA\u30FC\u3092\u6C7A\u3081\u305F\u30CB\u30F3\u30B8\u30E3\u306F\u305D\u306E\u307E\u307E\u5C11\u5973\u3092\u30A2\u30E9\u30D0\u30DE\u843D\u3068\u3057\u3067\u5730\u9762\u306B\u53E9\u304D\u3064\u3051\u308B\uFF01\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D\u5C11\u5973\u306F\u810A\u9AC4\u7C89\u7815\uFF01\u7206\u767A\u56DB\u6563\uFF01 #\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
    "id" : 329783680929251329,
    "created_at" : "2013-05-02 02:25:31 +0000",
    "user" : {
      "name" : "\u84BC\uFF20\u30CB\u30B3\u30CB\u30B3\u6280\u8853\u90E8",
      "screen_name" : "blaues",
      "protected" : false,
      "id_str" : "18827101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1222531322\/egg_normal.jpg",
      "id" : 18827101,
      "verified" : false
    }
  },
  "id" : 331783411956068352,
  "created_at" : "2013-05-07 14:51:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331782951996125185",
  "text" : "\u7AE5\u8A71\u306B\u306A\u308B\u3088\u3046\u306A\u8A71\u306E\u88CF\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u5C45\u3066\u3082\u5B9F\u969B\u4E0D\u601D\u8B70\u3067\u306A\u3044\uFF0E",
  "id" : 331782951996125185,
  "created_at" : "2013-05-07 14:49:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331782628204228608",
  "text" : "\u4ECA\u65E5\u3082\u4E16\u754C\u306B\u306F\u3068\u3042\u308B\u5149\u304C\u6E80\u3061\u3066\u3044\u308B\u3053\u3068\u3060\u306A\u3041(\u8A60\u5606)",
  "id" : 331782628204228608,
  "created_at" : "2013-05-07 14:48:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331781773132439553",
  "text" : "\u77E5\u6075\u888B\u3088\u308A\u306F\u307E\u3068\u3082\u3060\u3068\u601D\u3046\u306E(\u9707\u3048\u58F0)",
  "id" : 331781773132439553,
  "created_at" : "2013-05-07 14:45:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331781712839331840",
  "text" : "\u3042\u307E\u308A\u306B\u89E3\u6C7A\u3067\u304D\u306A\u3044\u3082\u3093\u3060\u304B\u3089\u30D5\u30A9\u30FC\u30E9\u30E0\u306B\u6295\u3052\u3066\u3057\u307E\u3063\u305F\uFF0E\u60C5\u5F31\u306E\u6557\u5317\uFF0E",
  "id" : 331781712839331840,
  "created_at" : "2013-05-07 14:44:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71",
      "indices" : [ 8, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331758524860342275",
  "text" : "\u95A2\u4FC2\u306A\u3044\u3051\u3069 \n#\u5510\u7A81\u306B\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u6BBA\u3059\u7AE5\u8A71 \u3053\u306E\u30BF\u30B0\uFF0C\u30AF\u30BD\u30EF\u30ED\u30BF\u3067\u3059",
  "id" : 331758524860342275,
  "created_at" : "2013-05-07 13:12:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/B22zAESEHa",
      "expanded_url" : "http:\/\/okirakurak.exblog.jp\/17259103\/",
      "display_url" : "okirakurak.exblog.jp\/17259103\/"
    } ]
  },
  "geo" : { },
  "id_str" : "331756826108502016",
  "text" : "\u3046\u30FC\u3093\uFF0C\u75C7\u72B6\u3068\u3057\u3066\u306Fhttp:\/\/t.co\/B22zAESEHa\n\u306E\uFF13\u4EE5\u4E0B\u3068\u540C\u69D8\u306A\u3093\u3060\u3051\u308C\u3069\u3053\u306E\u30DA\u30FC\u30B8\u306B\u306F\u539F\u56E0\u3068\u304B\u89E3\u6C7A\u7B56\u306F\u7121\u3057\uFF0E\uFF87\uFF70\uFF9D",
  "id" : 331756826108502016,
  "created_at" : "2013-05-07 13:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331752266279305216",
  "text" : "\u60C5\u5F31\u3045\u60C5\u5F31\u3045",
  "id" : 331752266279305216,
  "created_at" : "2013-05-07 12:47:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331752117708673024",
  "text" : "\u3053\u308C\u3069\u3046\u3057\u305F\u3089\u3088\u3044\u306E\u3060\u308D\u3046...",
  "id" : 331752117708673024,
  "created_at" : "2013-05-07 12:47:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331752051044384768",
  "text" : "Unetbootin\u3067USB\u30C7\u30A3\u30B9\u30AF\u4F5C\u6210\u3057\u3066\u8D77\u52D5\u3057\u305F\u304C\uFF0CDefaoult\u3057\u304B\u9078\u629E\u80A2\u304C\u306A\u3044\u753B\u9762\u306710\u79D2\u3067\u30AA\u30FC\u30C8\u30DE\u30C1\u30C3\u30AF\u30D6\u30FC\u30C8\u3059\u308B\u3088\u219210\u79D2\u5F85\u3064\u219210\u79D2\u3067\uFF08\uFF52\uFF59\u306E\u30EB\u30FC\u30D7\u306B\u7A81\u5165\u306A",
  "id" : 331752051044384768,
  "created_at" : "2013-05-07 12:47:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331740302102638592",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 331740302102638592,
  "created_at" : "2013-05-07 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNIpGD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331687579764273152",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNIpGD",
  "id" : 331687579764273152,
  "created_at" : "2013-05-07 08:30:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331665227328417792",
  "text" : "\u30AD\u30E7\u30FC\u30C8\u306B\u306F\u3064\u3044\u305F\u3002\u30C1\u30AB\u30C6\u30C4\u30C1\u30AB\u30C6\u30C4\u3002",
  "id" : 331665227328417792,
  "created_at" : "2013-05-07 07:02:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u3046\u305B\u3046",
      "screen_name" : "GauseuRi",
      "indices" : [ 0, 9 ],
      "id_str" : "521446089",
      "id" : 521446089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331616174506909696",
  "geo" : { },
  "id_str" : "331616265007415297",
  "in_reply_to_user_id" : 521446089,
  "text" : "@GauseuRi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 331616265007415297,
  "in_reply_to_status_id" : 331616174506909696,
  "created_at" : "2013-05-07 03:47:33 +0000",
  "in_reply_to_screen_name" : "GauseuRi",
  "in_reply_to_user_id_str" : "521446089",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331615527480987648",
  "text" : "\u3067\u3093\u3057\u3083 is \u304D\u305F",
  "id" : 331615527480987648,
  "created_at" : "2013-05-07 03:44:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331615338988978176",
  "text" : "\u3067\u3093\u3057\u3083 is \u3053\u306A\u3044",
  "id" : 331615338988978176,
  "created_at" : "2013-05-07 03:43:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331615230650114049",
  "text" : "\u306C\u306C\u306C\u306C\u306C\u306C\u306C\u306C\u306C\u306C\u306C",
  "id" : 331615230650114049,
  "created_at" : "2013-05-07 03:43:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3057\u30FC",
      "screen_name" : "oPAKILAo",
      "indices" : [ 0, 9 ],
      "id_str" : "547544213",
      "id" : 547544213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331614510148370432",
  "geo" : { },
  "id_str" : "331614607925977089",
  "in_reply_to_user_id" : 547544213,
  "text" : "@oPAKILAo \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 331614607925977089,
  "in_reply_to_status_id" : 331614510148370432,
  "created_at" : "2013-05-07 03:40:58 +0000",
  "in_reply_to_screen_name" : "oPAKILAo",
  "in_reply_to_user_id_str" : "547544213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331614198201200640",
  "text" : "\u79C1\u306F\u672A\u3060\u306B\u963F\u4F50\u30F6\u8C37\u306B\u3044\u308B\u3067\u3059\u3088",
  "id" : 331614198201200640,
  "created_at" : "2013-05-07 03:39:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331613704657453056",
  "text" : "\u30CD\u30EB\u8CB7\u3063\u305F\u3063\u305F",
  "id" : 331613704657453056,
  "created_at" : "2013-05-07 03:37:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331417794493181952",
  "text" : "\u85C1\u4EBA\u5F62\u3063\u3066\u3069\u3053\u3067\u58F2\u3063\u3066\u308B\u3093\u3060\u308D\uFF1F",
  "id" : 331417794493181952,
  "created_at" : "2013-05-06 14:38:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "3dzin",
      "indices" : [ 0, 6 ],
      "id_str" : "3231433158",
      "id" : 3231433158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331417500371779586",
  "text" : "@3dzin \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 331417500371779586,
  "created_at" : "2013-05-06 14:37:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331416978365505536",
  "text" : "\u5E30\u7701\u3057\u3066\u308B\u9593\u904A\u3073\u6563\u3089\u3057\u305F\u3057\u6563\u8CA1\u3057\u305F\u304B\u3089\u4EAC\u90FD\u5E30\u3063\u305F\u3089\u771F\u9762\u76EE\u3067\u8CEA\u7D20\u306A\u5B66\u751F\u3057\u307E\u3059\u3057",
  "id" : 331416978365505536,
  "created_at" : "2013-05-06 14:35:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331415512393342976",
  "text" : "\u306C\u30FC\u3093",
  "id" : 331415512393342976,
  "created_at" : "2013-05-06 14:29:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331415457938694147",
  "text" : "\u53BB\u5E74\u672B\u306B\u3082\u306B\u305F\u3088\u3046\u306A\u3053\u3068\u3044\u3063\u3066\u305F\n 12\u670810\u65E5\n\u3076\u3093\u3051\u3044 \u308A\u3051\u3044 \u305D\u3093\u306A\u306E\u3072\u3068\u306E\u304B\u3063\u3066 \u307B\u3093\u3068\u3046\u306B\u304B\u3057\u3053\u3044\u3072\u3068\u306A\u3089 \u3059\u304D\u306A\u3076\u3093\u3084\u3067\u304B\u3066\u308B\u3088\u3046\u306B \u304C\u3093\u3070\u308B\u3079\u304D\nposted at 19:40:44",
  "id" : 331415457938694147,
  "created_at" : "2013-05-06 14:29:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331414935206780930",
  "text" : "\u3076\u3093\u3051\u3044 \u308A\u3051\u3044 \u305D\u3093\u306A\u306E\u3072\u3068\u306E\u304B\u3063\u3066 \u307B\u3093\u3068\u3046\u306B\u304B\u3057\u3053\u3044\u304C\u304F\u305B\u3044\u306A\u3089 \u3058\u3075\u3093\u306E\u3059\u304D\u306A\u3076\u3093\u3084\u3092 \u307E\u306A\u3079\u308B\u3088\u3046 \u304C\u3093\u3070\u308B\u3079\u304D",
  "id" : 331414935206780930,
  "created_at" : "2013-05-06 14:27:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331413614848262145",
  "text" : "\u622F\u8A00\u3067\u3059\u3088",
  "id" : 331413614848262145,
  "created_at" : "2013-05-06 14:22:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331413599027335169",
  "text" : "\u6587\u7CFB\u3042\u30FC\u3060\u7406\u7CFB\u3053\u30FC\u3060\u306E\u8AD6\u306F\u307E\u3068\u3082\u306B\u7D0D\u5F97\u3067\u304D\u305F\u8A66\u3057\u306A\u3057",
  "id" : 331413599027335169,
  "created_at" : "2013-05-06 14:22:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331412240932683776",
  "text" : "\u307E\u3041\u3042\u308C\u521D\u5BFE\u9762\u3067\u3084\u3063\u3066\u305F\u3089\u78BA\u5B9F\u306B\u30E0\u30E9\u30CF\u30C1\u3060\u306A",
  "id" : 331412240932683776,
  "created_at" : "2013-05-06 14:16:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 3, 12 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331412144635658241",
  "text" : "RT @d_adagio: \u305D\u306E\u5206\u697D\u3057\u3055\u3001\u9762\u767D\u3055\u3082\u7570\u5E38",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331412038511390720",
    "text" : "\u305D\u306E\u5206\u697D\u3057\u3055\u3001\u9762\u767D\u3055\u3082\u7570\u5E38",
    "id" : 331412038511390720,
    "created_at" : "2013-05-06 14:16:01 +0000",
    "user" : {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "protected" : false,
      "id_str" : "1290456272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3416914088\/63eeb5ef4882f75f0de18db51d8205d0_normal.jpeg",
      "id" : 1290456272,
      "verified" : false
    }
  },
  "id" : 331412144635658241,
  "created_at" : "2013-05-06 14:16:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331411443780055042",
  "text" : "\u672C\u5F53\u306B\u30B9\u30B4\u30A4\u30B5\u30C4\u30D0\u30C4\u3060\u3063\u305F",
  "id" : 331411443780055042,
  "created_at" : "2013-05-06 14:13:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 3, 12 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331411372833390592",
  "text" : "RT @d_adagio: \u9AD8\u6821\u540C\u671F\u3068\u306E\u4F1A\u8A71\u306E\u6BBA\u4F10\u5EA6\u306F\u7570\u5E38",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331411195364012033",
    "text" : "\u9AD8\u6821\u540C\u671F\u3068\u306E\u4F1A\u8A71\u306E\u6BBA\u4F10\u5EA6\u306F\u7570\u5E38",
    "id" : 331411195364012033,
    "created_at" : "2013-05-06 14:12:40 +0000",
    "user" : {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "protected" : false,
      "id_str" : "1290456272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3416914088\/63eeb5ef4882f75f0de18db51d8205d0_normal.jpeg",
      "id" : 1290456272,
      "verified" : false
    }
  },
  "id" : 331411372833390592,
  "created_at" : "2013-05-06 14:13:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331409873931743232",
  "text" : "\u4FFA\u305F\u3061\u306EGW\u306F\u307E\u3060\u307E\u3060\u3053\u308C\u304B\u3089\u3060\uFF01[\u5B8C]",
  "id" : 331409873931743232,
  "created_at" : "2013-05-06 14:07:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331408895119605761",
  "text" : "\u30C9\u30AF\u30DA\u95A2\u897F\u306B\u8F38\u5165\u3059\u308B[23\u7F36]",
  "id" : 331408895119605761,
  "created_at" : "2013-05-06 14:03:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331393484269420544",
  "geo" : { },
  "id_str" : "331407404371673090",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30C0\u30C3\u30C4\uFF01",
  "id" : 331407404371673090,
  "in_reply_to_status_id" : 331393484269420544,
  "created_at" : "2013-05-06 13:57:37 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331392160752619520",
  "text" : "\u3061\u3087\u3063\u3068\u3060\u3051\u30A2\u30EB\u30B3\u30FC\u30EB",
  "id" : 331392160752619520,
  "created_at" : "2013-05-06 12:57:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331391854752960512",
  "text" : "\u30CF\u30FC\u30B2\u30F3\u30C0\u30C3\u30C4\u30AF\u30EA\u30FC\u30DF\u30FC\u30DF\u30F3\u30C8\u306A\u3046",
  "id" : 331391854752960512,
  "created_at" : "2013-05-06 12:55:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quina",
      "screen_name" : "tacorice917",
      "indices" : [ 7, 19 ],
      "id_str" : "259665471",
      "id" : 259665471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/fHiJZ7qLy7",
      "expanded_url" : "http:\/\/4sq.com\/YoQgzq",
      "display_url" : "4sq.com\/YoQgzq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.7037163886, 139.5790283382 ]
  },
  "id_str" : "331244896033849345",
  "text" : "I'm at @Tacorice917 (\u6B66\u8535\u91CE\u5E02, \u6771\u4EAC\u90FD) http:\/\/t.co\/fHiJZ7qLy7",
  "id" : 331244896033849345,
  "created_at" : "2013-05-06 03:11:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331240478651584513",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u30DE\u30B8\u30AD\u30C1\u3081\u3044\u3066\u305F",
  "id" : 331240478651584513,
  "created_at" : "2013-05-06 02:54:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331240429607604224",
  "text" : "\u30B7\u30E5\u30F3\u30DF\u30F3\u30F3\u30F3\u30F3\u30F3\u30FC\u30FC\u30FC\u30FC\u30FC\u30A2\u30AB\u30C4\u30AD\u30F2\u30A9\u30A9\u30A9\u30A9\u30AA\u30A9\u30A9\u30A1\u30AA\u30A9\u30A9\u30A9\u30AA\u30DC\u30A8\u30BA\u30A5\u30A5\u30A5\u30A6\u30A6\u30A5\u30A5\u30A5\u30A6\u30A5\u30A5",
  "id" : 331240429607604224,
  "created_at" : "2013-05-06 02:54:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331059286388113409",
  "text" : "\u7533\u3057\u8A33 of the world\u306F\u4E0D\u610F\u6253\u3061\u306B\u3082\u4FBF\u5229\u306A",
  "id" : 331059286388113409,
  "created_at" : "2013-05-05 14:54:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331052116263182336",
  "text" : "@umichoco11 \u305F\u307E\u306E\u5E30\u7701\u3067\u3059\u3057\u8D05\u6CA2\u304C\u8A31\u3055\u308C\u308B\u306E\u3067\u3059[\u3068\u306F\u3044\u3048\u79C1\u304C\u80B2\u3064\u306E\u306B\u306F\u306B\u306F\u7D50\u69CB\u304A\u91D1\u639B\u304B\u3063\u3066\u308B\u306E\u3067\u7533\u3057\u8A33 of the world]",
  "id" : 331052116263182336,
  "created_at" : "2013-05-05 14:25:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331050446061989889",
  "text" : "@umichoco11 \u30D5\u30A5\u30FC(^^)(^^)(^^)\u30AB\u30C1\u30B0\u30DF\u30E4\u30C3\u30BF\u30FC\uFF01",
  "id" : 331050446061989889,
  "created_at" : "2013-05-05 14:19:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331049867763929089",
  "text" : "\u5E78\u305B\u306A\u308A\u3084",
  "id" : 331049867763929089,
  "created_at" : "2013-05-05 14:16:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331049824952668160",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u4ECA\u65E5\u306F\u671D\u304B\u3089\u8CB7\u3044\u7269\u3067\u98DF\u6599\u8ABF\u9054\u3057\u305F\u3057\u3001\u304A\u663C\u30A2\u30A6\u30C8\u30EC\u30C3\u30C8\u3067\u6B32\u3057\u3044\u3082\u306E\u8CB7\u3063\u3066\u591C\u306F\u30C4\u30AD\u30B8\u3081\u3044\u305F\u3001\u5834\u6240\u3067\u30AA\u30FC\u30AC\u30CB\u30C3\u30AF\u30FB\u30B9\u30B7\u98DF\u3079\u305F\u3057\u5B9F\u969B\u30AB\u30C1\u30B0\u30DF\u3060\u3063\u305F",
  "id" : 331049824952668160,
  "created_at" : "2013-05-05 14:16:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331048580729155584",
  "text" : "\u30DD\u30FC\u30BF\u30EB=\u30B8\u30C4\u3067\u3001\u30CD\u30AA\u30B5\u30A4\u30BF\u30DE\u3068\u30AC\u30A4\u30AA\u30F3\u30B7\u30C6\u30A3\u304C\u3064\u306A\u304C\u3063\u3066\u305F\u3089\u304F\u3063\u3061\u3093\u3071\u90B8\u884C\u3063\u3066\u305F\u304C\u6B8B\u5FF5\u3060\u306A\uFF1F",
  "id" : 331048580729155584,
  "created_at" : "2013-05-05 14:11:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331047846390419457",
  "text" : "\u51B7\u8535\u5EAB\u306B\u306F\u30CF\u30FC\u30B2\u30F3\u30C0\u30C3\u30C4\u306E\u306A\u3093\u3061\u3083\u3089\u30DF\u30F3\u30C8\u304C\u5165\u3063\u3066\u3044\u308B\u306E\u3060\u3088(^^)(^^)(^^)",
  "id" : 331047846390419457,
  "created_at" : "2013-05-05 14:08:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331047528852226048",
  "geo" : { },
  "id_str" : "331047722721374208",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u30CA\u30A4\u30B9\u30C0\u30C3\u30C4\uFF01",
  "id" : 331047722721374208,
  "in_reply_to_status_id" : 331047528852226048,
  "created_at" : "2013-05-05 14:08:22 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331015447463997440",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 331015447463997440,
  "created_at" : "2013-05-05 12:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330975179821953026",
  "text" : "\u30C4\u30AD\u30B8\u3081\u3044\u305F\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u306E\u753A\u3067\u30AA\u30FC\u30AC\u30CB\u30C3\u30AF\u30FB\u30B9\u30B7\u3092\u98DF\u3079\u308B",
  "id" : 330975179821953026,
  "created_at" : "2013-05-05 09:20:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330701162540064769",
  "geo" : { },
  "id_str" : "330701354345586691",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305D\u308C\u3042\u3093\u307E\u308A\u8912\u3081\u3066\u306A\u3044\u5370\u8C61",
  "id" : 330701354345586691,
  "in_reply_to_status_id" : 330701162540064769,
  "created_at" : "2013-05-04 15:12:01 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330700580764921856",
  "text" : "\uFF1F",
  "id" : 330700580764921856,
  "created_at" : "2013-05-04 15:08:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330700570086219776",
  "text" : "C\u7121\u9650\u7D1A\u5FAE\u5206\u53EF\u80FD\u306A\u5165\u7720",
  "id" : 330700570086219776,
  "created_at" : "2013-05-04 15:08:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330700245103157248",
  "geo" : { },
  "id_str" : "330700412510412803",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u304A\u3084\u3059\u307F",
  "id" : 330700412510412803,
  "in_reply_to_status_id" : 330700245103157248,
  "created_at" : "2013-05-04 15:08:17 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330699568054411264",
  "text" : "\u300C\u30D0\u30BA\u30EF\u30FC\u30C9\u3068\u3044\u3046\u8A00\u8449\u81EA\u4F53\u304C\u30D0\u30BA\u30EF\u30FC\u30C9\u300D\u3068\u3044\u3046\u69CB\u9020\u7D50\u69CB\u6C17\u306B\u5165\u3063\u3066\u3044\u308B",
  "id" : 330699568054411264,
  "created_at" : "2013-05-04 15:04:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330698361307033602",
  "geo" : { },
  "id_str" : "330698646792314880",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u3082\u3061\u308D\u3093\u30AC\u30E9\u30C3\u3068\u5909\u308F\u3063\u305F\u308F\u3051\u3067\u306F\u306A\u3044\u3067\u3059\u304C\u306D\u30FC\u3001\u30DE\u30A4\u30CA\u30FC\u30C1\u30A7\u30F3\u30B8\u3068\u3044\u3046\u304B\u306A\u3093\u3068\u3044\u3046\u304B",
  "id" : 330698646792314880,
  "in_reply_to_status_id" : 330698361307033602,
  "created_at" : "2013-05-04 15:01:16 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330698262082363392",
  "geo" : { },
  "id_str" : "330698344307490819",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u304A\u3084\u3059\u307F",
  "id" : 330698344307490819,
  "in_reply_to_status_id" : 330698262082363392,
  "created_at" : "2013-05-04 15:00:04 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330697713719058432",
  "geo" : { },
  "id_str" : "330698157228949504",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u307E\u3041\u3053\u3053\u6570\u5E74(\u7279\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u30AA\u30D5\u306B\u53C2\u52A0\u3059\u308B\u524D\u5F8C)\u3067\u3060\u3044\u3076\u6027\u683C\u304C\u5909\u308F\u3063\u305F\u307D\u3044\u3067\u3059\u3057\u3001\u3069\u3061\u3089\u3082\u5927\u4E8B\u306A\u610F\u898B\u3067\u3059\u306D",
  "id" : 330698157228949504,
  "in_reply_to_status_id" : 330697713719058432,
  "created_at" : "2013-05-04 14:59:19 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330697744039673856",
  "text" : "\u4ECA\u307E\u3067\u306B\u306A\u3044\u30BF\u30A4\u30D7\u306E\u3048\u3089\u30FC",
  "id" : 330697744039673856,
  "created_at" : "2013-05-04 14:57:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/eFYZ8hdZBv",
      "expanded_url" : "http:\/\/twitpic.com\/co5rbv",
      "display_url" : "twitpic.com\/co5rbv"
    } ]
  },
  "geo" : { },
  "id_str" : "330697716076277760",
  "text" : "\u30A2\u30A4\u30B3\u30F3\u30D0\u30B0\u3063\u305F\u306A\uFF1F http:\/\/t.co\/eFYZ8hdZBv",
  "id" : 330697716076277760,
  "created_at" : "2013-05-04 14:57:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Principia MISOmatica",
      "screen_name" : "noumisoko",
      "indices" : [ 0, 10 ],
      "id_str" : "416068558",
      "id" : 416068558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330697188869025792",
  "geo" : { },
  "id_str" : "330697507803910144",
  "in_reply_to_user_id" : 416068558,
  "text" : "@noumisoko \u3093\u30FC\u3001\u81EA\u5206\u3067\u3082\u4EBA\u5F53\u305F\u308A\u306F\u60AA\u304F\u306A\u3044\u3068\u306F\u601D\u3046\u306E\u3067\u3059\u304C\u2026",
  "id" : 330697507803910144,
  "in_reply_to_status_id" : 330697188869025792,
  "created_at" : "2013-05-04 14:56:44 +0000",
  "in_reply_to_screen_name" : "noumisoko",
  "in_reply_to_user_id_str" : "416068558",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330696954990444544",
  "text" : "\u9AD8\u6821\u306E\u53CB\u4EBA\u306B\u306F\u300C\u9762\u63A5\u3067\u640D\u3057\u306A\u3055\u305D\u3046\u300D\u3068\u8A00\u308F\u308C\u3001\u5927\u5B66\u306E\u53CB\u4EBA\/\u5148\u8F29\u306B\u306F\u300C\u9762\u63A5\u3067\u640D\u3057\u305D\u3046\u300D\u3068\u8A00\u308F\u308C\u305F\u3057\u3082\u3046\u308F\u3051\u308F\u304B\u3089\u3093",
  "id" : 330696954990444544,
  "created_at" : "2013-05-04 14:54:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330696355448229888",
  "text" : "\u5358\u4F4D\u3068\u3044\u3046\u5236\u5EA6\u7684\u306A\u3082\u306E\u3082\u3042\u308B\u3051\u3069\u306A\uFF1F",
  "id" : 330696355448229888,
  "created_at" : "2013-05-04 14:52:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330696259281227776",
  "text" : "\u3042\u30014\u5E74\u3076\u308A\u306B\u3042\u3063\u305F\u9AD8\u6821\u306E\u53CB\u4EBA\u306B\u3001\u3067\u3059",
  "id" : 330696259281227776,
  "created_at" : "2013-05-04 14:51:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330696170324242432",
  "text" : "\u3048\u3093\u3069\u304F\u3093\u5148\u751F\u306B\u306A\u3089\u306A\u3044\u306E\uFF1F\u3063\u3066\u805E\u304B\u308C\u305F\u3051\u3069\u3001\u5411\u3044\u3066\u3044\u306A\u3044\u6C17\u3057\u304B\u3057\u306A\u3044",
  "id" : 330696170324242432,
  "created_at" : "2013-05-04 14:51:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330696030465167360",
  "text" : "@CreatioExNihil0 \u3080\u3080\u3080\uFF01\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01",
  "id" : 330696030465167360,
  "created_at" : "2013-05-04 14:50:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330689635573448704",
  "text" : "\u9662\u6B7B\u3068\u5C31\u6D3B\u306E\u95C7\u3092\u4E57\u308A\u8D8A\u3048\u306A\u3044\u3068\u2026",
  "id" : 330689635573448704,
  "created_at" : "2013-05-04 14:25:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330689356794851329",
  "text" : "\u5B89\u5FC3\u611F\/\u5B89\u5B9A\u611F",
  "id" : 330689356794851329,
  "created_at" : "2013-05-04 14:24:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330653130347933696",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 330653130347933696,
  "created_at" : "2013-05-04 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330570292596445185",
  "text" : "\u304A\u3082\u3066\u3055\u3093\u3069\u3046",
  "id" : 330570292596445185,
  "created_at" : "2013-05-04 06:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330557414841655297",
  "geo" : { },
  "id_str" : "330566026636951553",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u307E\u305F\u9023\u7D61\u3057\u3084\u3059\uFF01",
  "id" : 330566026636951553,
  "in_reply_to_status_id" : 330557414841655297,
  "created_at" : "2013-05-04 06:14:17 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330566023944216576",
  "text" : "\u3057\u3082\u304D\u305F\u3056\u308F",
  "id" : 330566023944216576,
  "created_at" : "2013-05-04 06:14:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330565435638550529",
  "text" : "\u30EB\u30F3\u30D0\u30EB\u30F3\u30D0\u30EB\u30F3\u30D0\u30EB\u30F3\u30D0\u30EB\u30F3\u30D0\u30EB\u30F3\u30D0",
  "id" : 330565435638550529,
  "created_at" : "2013-05-04 06:11:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/PWp2Kw0cAa",
      "expanded_url" : "http:\/\/twitpic.com\/co1cye",
      "display_url" : "twitpic.com\/co1cye"
    } ]
  },
  "geo" : { },
  "id_str" : "330565436418703360",
  "text" : "#nowplaying \u7A7A\u60F3\u30EB\u30F3\u30D0 - \u5927\u69FB\u30B1\u30F3\u30C2\u3068\u7D76\u671B\u5C11\u5973\u9054 http:\/\/t.co\/PWp2Kw0cAa",
  "id" : 330565436418703360,
  "created_at" : "2013-05-04 06:11:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330562676122058752",
  "text" : "\u660E\u502B\u9928\u306B\u884C\u304F\u3088\u30FC\u30FC\u30FC",
  "id" : 330562676122058752,
  "created_at" : "2013-05-04 06:00:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330341664046608387",
  "geo" : { },
  "id_str" : "330556289694449664",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u7D42\u308A(\u3089\u305B)\u307E\u3059\u3088\u3001\u671D\u96C6\u307E\u3063\u3066\u591C\u4E2D\u307E\u3067\u3084\u308C\u3070\u3001\u305F\u3076\u3093",
  "id" : 330556289694449664,
  "in_reply_to_status_id" : 330341664046608387,
  "created_at" : "2013-05-04 05:35:35 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330320348623028225",
  "text" : "\u9AD8\u6821\u540C\u671F\u3067KU\u6765\u305F\u4EBA\u3067\u96C6\u307E\u308B\u3068\u30B7\u30F3\u30B0\u30EB\u30C8\u30F3",
  "id" : 330320348623028225,
  "created_at" : "2013-05-03 13:58:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330319097902542848",
  "geo" : { },
  "id_str" : "330320189977686016",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u4E00\u4EBA\u98F2\u307F\u306B\u306A\u308B\u56F3",
  "id" : 330320189977686016,
  "in_reply_to_status_id" : 330319097902542848,
  "created_at" : "2013-05-03 13:57:25 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330317594169069568",
  "geo" : { },
  "id_str" : "330318200325677059",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u7FA4\u8AD6\u4E00\u65E5\u30BC\u30DF\u2026(\u30B4\u30B4\u30B4\u30B4\u30B4",
  "id" : 330318200325677059,
  "in_reply_to_status_id" : 330317594169069568,
  "created_at" : "2013-05-03 13:49:30 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330314829598449664",
  "text" : "\u5409\u7965\u5BFA\u3067\u5E73\u6CC9\u3055\u3093\u305D\u3063\u304F\u308A\u306E\u4EBA\u898B\u305F\u3051\u3069\u4ED6\u4EBA\u306E\u7A7A\u4F3C\uFF1F",
  "id" : 330314829598449664,
  "created_at" : "2013-05-03 13:36:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330134392011886592",
  "text" : "\u5B9F\u5BB6\u3068\u5409\u7965\u5BFA\u306E\u8DDD\u96E2\u611F\u3001\u4E0B\u5BBF\u3068\u5927\u5B66\u306E\u8DDD\u96E2\u611F\u306B\u8FD1\u3057\u3044[\u5B9F\u969B\u5F8C\u8005\u306E\u65B9\u304C\u305F\u3076\u3093\u8FD1\u3044]",
  "id" : 330134392011886592,
  "created_at" : "2013-05-03 01:39:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330133647581667329",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u5B89\u5B9A\u306E10\u5206\u524D\u5230\u7740",
  "id" : 330133647581667329,
  "created_at" : "2013-05-03 01:36:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330132475848310786",
  "text" : "\u6954\u3092\u6253\u3061\u8FBC\u3093\u3067\u304A\u3044\u305F",
  "id" : 330132475848310786,
  "created_at" : "2013-05-03 01:31:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330132237515382784",
  "text" : "\u78BA\u304B\u306B\u5409\u7965\u5BFA\u3068\u8A00\u308F\u308C\u305F\u304C\u5409\u7965\u5BFA\u306E\u4F55\u51E6\u304B\u306F\u6307\u5B9A\u3057\u3066\u3044\u306A\u3044\u304B\u3089\u305F\u3076\u3093\u5F7C\u306F\u9045\u523B",
  "id" : 330132237515382784,
  "created_at" : "2013-05-03 01:30:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330131382137401344",
  "text" : "\u3042\u3001\u6628\u65E5\u4E00\u756A\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA\u306F\u300C\u5973\u533B\u304C\u6559\u3048\u308B\u672C\u5F53\u306B\u982D\u306E\u60AA\u3044\u4F1A\u8A71\u300D\u3067\u3057\u305F",
  "id" : 330131382137401344,
  "created_at" : "2013-05-03 01:27:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330118084671205376",
  "text" : "\u305D\u3046\u3044\u3084\u30AF\u30ED\u30FC\u30F3\u3068\u3044\u3046\u8868\u73FE\u306F\u907F\u3051\u3066\u308B\u306E\u304B",
  "id" : 330118084671205376,
  "created_at" : "2013-05-03 00:34:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330117511754444800",
  "text" : "\u30B5\u30C8\u30B7\u3068\u30ED\u30B1\u30C3\u30C8\u56E3\u306E\u751F\u5B58\u80FD\u529B\u5C0B\u5E38\u3058\u3083\u306A\u3044[\u7279\u306B\u5F8C\u8005\u306A]",
  "id" : 330117511754444800,
  "created_at" : "2013-05-03 00:32:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330107153518043137",
  "text" : "\u30DF\u30E5\u30A6\u30C4\u30FC\u306E\u3046\u3093\u3058\u3083\u3089\u307A\u30FC\u3084\u3063\u3066\u308B",
  "id" : 330107153518043137,
  "created_at" : "2013-05-02 23:50:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329945289794387968",
  "text" : "\u59B9\u304C\u4F5C\u3063\u305F\u3068\u304B\u3044\u3046\u30B9\u30B3\u30FC\u30F3\u3068\u30B3\u30FC\u30D2\u30FC\u3092\u6234\u3044\u3066\u3044\u308B",
  "id" : 329945289794387968,
  "created_at" : "2013-05-02 13:07:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329934923102289921",
  "text" : "\u306A\u3093\u3067500km\u3082\u79FB\u52D5\u3057\u3066\u5E30\u5B85\u3057\u3066\u81EA\u5206\u306E\u304A\u5915\u98EF\u4F5C\u3063\u3066\u3044\u308B\u306E\u304B",
  "id" : 329934923102289921,
  "created_at" : "2013-05-02 12:26:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329934812376875008",
  "text" : "[\u901F\u5831] \u5B9F\u5BB6\u306B\u304A\u5915\u98EF\u304C\u7528\u610F\u3055\u308C\u3066\u304A\u3089\u305A\u3001\u307E\u3055\u304B\u306E\u5B9F\u5BB6\u3067\u81EA\u708A",
  "id" : 329934812376875008,
  "created_at" : "2013-05-02 12:26:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329928308403875841",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 329928308403875841,
  "created_at" : "2013-05-02 12:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "indices" : [ 0, 13 ],
      "id_str" : "181966634",
      "id" : 181966634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329925061727367168",
  "geo" : { },
  "id_str" : "329925625693470720",
  "in_reply_to_user_id" : 181966634,
  "text" : "@zweisleeping \u56DB\u5DDD\u4EAD\u30B9\u30AD\u30FC\u306A\u306E\u3067\u305D\u3046\u3060\u3068\u601D\u3063\u3066\u307E\u3057\u305F\u3001\u304A\u6642\u9593\u3042\u308A\u307E\u3057\u305F\u3089[\u65B0\u5BBF\u306B\u3082\u5E97\u8217\u304C\u3042\u3063\u305F\u3088\u3046\u306A]",
  "id" : 329925625693470720,
  "in_reply_to_status_id" : 329925061727367168,
  "created_at" : "2013-05-02 11:49:33 +0000",
  "in_reply_to_screen_name" : "zweisleeping",
  "in_reply_to_user_id_str" : "181966634",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329924936061825025",
  "text" : "\u3053\u30FC\u3048\u3093\u3058\u30FC",
  "id" : 329924936061825025,
  "created_at" : "2013-05-02 11:46:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329924537523249154",
  "text" : "\u3081\u3052\u305F\u3044\u306A\u3052\u305F\u3044\u3064\u3089\u3044\u3064\u3089\u3044\n\u306E\u30B4\u30ED\u306E\u826F\u3055",
  "id" : 329924537523249154,
  "created_at" : "2013-05-02 11:45:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329924395713847296",
  "text" : "\u5149\u304CGoogle\u307E\u3067\u7167\u3089\u3057\u59CB\u3081\u305F\u2026",
  "id" : 329924395713847296,
  "created_at" : "2013-05-02 11:44:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329924309323743232",
  "text" : "RT @koizumi_fifty: \u3042\u306E\u3001\u30B0\u30FC\u30B0\u30EB\u5148\u751F\u3001\u3061\u3087\u3063\u3068\u3001\u300C\u3060\u3044\u3059\u3046\u3068\u307D\u300D\u306E\u6642\u70B9\u3067\u300C\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u306E\u5149\u300D\u30B5\u30B8\u30A7\u30B9\u30C8\u3057\u3066\u304F\u308B\u306E\u6B62\u3081\u3066\u3044\u305F\u3060\u304D\u305F\u3044\u3093\u3067\u3059\u3051\u3069\u2026\u2026\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329924085398245376",
    "text" : "\u3042\u306E\u3001\u30B0\u30FC\u30B0\u30EB\u5148\u751F\u3001\u3061\u3087\u3063\u3068\u3001\u300C\u3060\u3044\u3059\u3046\u3068\u307D\u300D\u306E\u6642\u70B9\u3067\u300C\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u306E\u5149\u300D\u30B5\u30B8\u30A7\u30B9\u30C8\u3057\u3066\u304F\u308B\u306E\u6B62\u3081\u3066\u3044\u305F\u3060\u304D\u305F\u3044\u3093\u3067\u3059\u3051\u3069\u2026\u2026\u3002",
    "id" : 329924085398245376,
    "created_at" : "2013-05-02 11:43:26 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 329924309323743232,
  "created_at" : "2013-05-02 11:44:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329922160363720704",
  "text" : "\u56DB\u8C37\u3075\u3075\u3075",
  "id" : 329922160363720704,
  "created_at" : "2013-05-02 11:35:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "indices" : [ 0, 13 ],
      "id_str" : "181966634",
      "id" : 181966634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329920090684403712",
  "geo" : { },
  "id_str" : "329921265215348736",
  "in_reply_to_user_id" : 181966634,
  "text" : "@zweisleeping \u8D64\u5742\u306B\u3042\u308B\u9673\u9EBB\u5A46\u8C46\u8150\u306E\u304A\u5E97\u8F9B\u304F\u3066\u30AA\u30B9\u30B9\u30E1\u3067\u3059(^^)(^^)(^^)",
  "id" : 329921265215348736,
  "in_reply_to_status_id" : 329920090684403712,
  "created_at" : "2013-05-02 11:32:13 +0000",
  "in_reply_to_screen_name" : "zweisleeping",
  "in_reply_to_user_id_str" : "181966634",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329919818155323392",
  "geo" : { },
  "id_str" : "329920395023093762",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u4FFA\u3082\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3051\u3069\u3001\u523A\u5BA2\u3092\u9001\u308B\u306E\u306F\u52D8\u5F01\u3057\u3066\u304F\u308C",
  "id" : 329920395023093762,
  "in_reply_to_status_id" : 329919818155323392,
  "created_at" : "2013-05-02 11:28:46 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "indices" : [ 0, 13 ],
      "id_str" : "181966634",
      "id" : 181966634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329918663534714882",
  "geo" : { },
  "id_str" : "329919568120258561",
  "in_reply_to_user_id" : 181966634,
  "text" : "@zweisleeping \u306A\u308B\u307B\u3069\u30FC\u3044\u3064\u307E\u3067\u3044\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 329919568120258561,
  "in_reply_to_status_id" : 329918663534714882,
  "created_at" : "2013-05-02 11:25:29 +0000",
  "in_reply_to_screen_name" : "zweisleeping",
  "in_reply_to_user_id_str" : "181966634",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329918462115864576",
  "geo" : { },
  "id_str" : "329919474109120512",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u8CA1\u95A5\u306E\u529B\u3067\u91D1\u584A\u3092\u98F2\u3081\u308B\u5589\u3092\u79FB\u690D\u3057\u305F\u3093\u3058\u3083\u306A\u3044\u306E\u304B",
  "id" : 329919474109120512,
  "in_reply_to_status_id" : 329918462115864576,
  "created_at" : "2013-05-02 11:25:06 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329918429731618816",
  "text" : "\u6771\u4EAC\u306B\u7F8E\u8853\u9928\u306E\u305F\u3081\u306B\u304F\u308B\u3068\u3044\u3046\u306E\u3082\u3042\u308B\u3093\u3060\u306A",
  "id" : 329918429731618816,
  "created_at" : "2013-05-02 11:20:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329917994291564544",
  "geo" : { },
  "id_str" : "329918184289353728",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u753B\u50CF\u898B\u3066\u306A\u3044\u3051\u3069\u91D1\u584A\u306E\u753B\u50CF\u3068\u304B\u8CBC\u308B\u306E\u6B62\u3081\u308D\u3088\u306A\uFF01\uFF01\uFF01",
  "id" : 329918184289353728,
  "in_reply_to_status_id" : 329917994291564544,
  "created_at" : "2013-05-02 11:19:59 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "indices" : [ 0, 13 ],
      "id_str" : "181966634",
      "id" : 181966634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329916806603087872",
  "geo" : { },
  "id_str" : "329917913383436288",
  "in_reply_to_user_id" : 181966634,
  "text" : "@zweisleeping \u65C5\u884C\u3067\u3059\uFF1F",
  "id" : 329917913383436288,
  "in_reply_to_status_id" : 329916806603087872,
  "created_at" : "2013-05-02 11:18:54 +0000",
  "in_reply_to_screen_name" : "zweisleeping",
  "in_reply_to_user_id_str" : "181966634",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329916510107750400",
  "text" : "\u54C1\u5DDD\u3041",
  "id" : 329916510107750400,
  "created_at" : "2013-05-02 11:13:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "indices" : [ 0, 13 ],
      "id_str" : "181966634",
      "id" : 181966634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329916267681181697",
  "geo" : { },
  "id_str" : "329916369921519617",
  "in_reply_to_user_id" : 181966634,
  "text" : "@zweisleeping \u4E0B\u5317\u306B\u3044\u308B\u3093\u3067\u3059\u304B",
  "id" : 329916369921519617,
  "in_reply_to_status_id" : 329916267681181697,
  "created_at" : "2013-05-02 11:12:46 +0000",
  "in_reply_to_screen_name" : "zweisleeping",
  "in_reply_to_user_id_str" : "181966634",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329915528669978626",
  "text" : "\u307E\u305F\u3046\u3068\u3046\u3068\u3057\u3066\u3044\u305F\u306A\uFF1F",
  "id" : 329915528669978626,
  "created_at" : "2013-05-02 11:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329891871067357184",
  "text" : "\u306A\u3054\u3084\u306A\u3054\u3084",
  "id" : 329891871067357184,
  "created_at" : "2013-05-02 09:35:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329886491637583873",
  "text" : "\u65B0\u5E79\u7DDA\u304B\u3089\u5916\u773A\u3081\u3066\u308B\u3068\u3084\u3063\u3071\u308A\u4E00\u5EA6\u539F\u4ED8\u3067\u6771\u6D77\u9053\u3086\u3063\u305F\u308A\u5B9F\u5BB6\u307E\u3067\u5E30\u3063\u3066\u307F\u305F\u3044\u3068\u601D\u3046",
  "id" : 329886491637583873,
  "created_at" : "2013-05-02 09:14:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329885919601635328",
  "text" : "\u30E8\u30FC\u30B0\u30EB\u30C8\u306B\u30D6\u30EB\u30FC\u30D9\u30EA\u30FC\u5165\u308C\u305F\u4EBA\u306B\u4ECA\u98DF\u3079\u3066\u308B\u30E8\u30FC\u30B0\u30EB\u30C8\u4E00\u53E3\u3042\u3052\u3066\u3082\u826F\u3044\u4F4D\u611F\u8B1D\u3057\u3066\u308B",
  "id" : 329885919601635328,
  "created_at" : "2013-05-02 09:11:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329884959164739584",
  "text" : "\u30E8\u30FC\u30B0\u30EB\u30C8\u7F8E\u5473\u3057\u3044",
  "id" : 329884959164739584,
  "created_at" : "2013-05-02 09:07:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329884345429016576",
  "text" : "\u30B9\u30B4\u30A4\u30CF\u30E4\u30A4\uFF01\u30CF\u30E4\u30A4\u30E4\u30C3\u30BF\u30FC\uFF01",
  "id" : 329884345429016576,
  "created_at" : "2013-05-02 09:05:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329884129053257729",
  "text" : "\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u306F\u98F2\u3093\u3067\u3082\u98F2\u307E\u308C\u308B\u306A(^^)(^^)(^^)",
  "id" : 329884129053257729,
  "created_at" : "2013-05-02 09:04:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329884029606305792",
  "text" : "\u51FA\u767A(^^)(^^)(^^)",
  "id" : 329884029606305792,
  "created_at" : "2013-05-02 09:04:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329882934003761155",
  "text" : "\u58F2\u3063\u3066\u305F\u304B\u3089\u8CB7\u3063\u3061\u3083\u3063\u305F\uFF01",
  "id" : 329882934003761155,
  "created_at" : "2013-05-02 08:59:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329882409485086720",
  "text" : "\u30E8\u30FC\u30B0\u30EB\u30C8\u98DF\u3079\u305F\u304F\u3066\u3046\u304A\u30FC\u3063\u3066\u306A\u3063\u3066\u308B",
  "id" : 329882409485086720,
  "created_at" : "2013-05-02 08:57:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329880968074780672",
  "text" : "( \u00B4_\uFF40)",
  "id" : 329880968074780672,
  "created_at" : "2013-05-02 08:52:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329880676172185600",
  "text" : "\u6CE3\u3044\u3066\u99AC\u8B16\u3082\u65AC\u308B\uFF01",
  "id" : 329880676172185600,
  "created_at" : "2013-05-02 08:50:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329880585797500928",
  "text" : "\u9AA8\u5207\u308A\u5305\u4E01\u3067\u8089\u3082\u65AC\u308B\uFF01\uFF01",
  "id" : 329880585797500928,
  "created_at" : "2013-05-02 08:50:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329880309258665984",
  "text" : "\u65B0\u5E79\u7DDA(^^)(^^)(^^)\u65B0\u5E79\u7DDA(^^)(^^)(^^)",
  "id" : 329880309258665984,
  "created_at" : "2013-05-02 08:49:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329880126970019840",
  "text" : "\u51FD\u6570\u61D0\u77F3\u98DF\u3079\u305F\u3044(^^)(^^)(^^)",
  "id" : 329880126970019840,
  "created_at" : "2013-05-02 08:48:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "3dzin",
      "indices" : [ 0, 6 ],
      "id_str" : "3231433158",
      "id" : 3231433158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329879831917498368",
  "text" : "@3dzin \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 329879831917498368,
  "created_at" : "2013-05-02 08:47:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329879797784248320",
  "text" : "\u5973\u533B\u3063\u3066\u982D\u826F\u3055\u305D\u3046\u306A\u306E\u306B\u306D(^^)(^^)(^^)",
  "id" : 329879797784248320,
  "created_at" : "2013-05-02 08:47:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329879757921599488",
  "text" : "\u300C\u5973\u533B\u304C\u6559\u3048\u308B\u672C\u5F53\u306B\u982D\u306E\u60AA\u3044\u4F1A\u8A71\u300D",
  "id" : 329879757921599488,
  "created_at" : "2013-05-02 08:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329878098034167808",
  "text" : "\u5BB6\u65CF\u9023\u308C\u591A\u3044\u304B\u3089\u9023\u4F11\u3092\u611F\u3058\u308B",
  "id" : 329878098034167808,
  "created_at" : "2013-05-02 08:40:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329877856320626688",
  "text" : "\u30A2\u30D0\u30FC(^^)(^^)(^^)",
  "id" : 329877856320626688,
  "created_at" : "2013-05-02 08:39:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329877399833571328",
  "text" : "\u30D0\u30B9\u3067\u304B\u306A\u308A\u3046\u3068\u3046\u3068\u3057\u305F\u304C\u4EAC\u90FD\u99C5\u7740\u3044\u305F\u3089\u3057",
  "id" : 329877399833571328,
  "created_at" : "2013-05-02 08:37:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329836195276259328",
  "text" : "\uFF1F",
  "id" : 329836195276259328,
  "created_at" : "2013-05-02 05:54:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329836192319279104",
  "text" : "\u304A\u8179\u6E1B\u3063\u3066\u6B7B\u306B\u305D\u3046\/\u6B7B\u3093\u3060\u3089\u304A\u8179\u6E1B\u308A\u305D\u3046",
  "id" : 329836192319279104,
  "created_at" : "2013-05-02 05:54:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329764434476150784",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u3060\u3044\u3076\u9178\u5473\u304C\u5F37\u3044",
  "id" : 329764434476150784,
  "created_at" : "2013-05-02 01:09:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329758949379276801",
  "text" : "\u304A\u306F\u3088\u3046\uFF1F",
  "id" : 329758949379276801,
  "created_at" : "2013-05-02 00:47:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329650825146290176",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3063\u305B\u30FC",
  "id" : 329650825146290176,
  "created_at" : "2013-05-01 17:37:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329650811980374016",
  "text" : "\u5927\u4EBA\u3057\u304F\u5BDD\u308B\u304B",
  "id" : 329650811980374016,
  "created_at" : "2013-05-01 17:37:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329647277654298624",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8?!\u30CA\u30F3\u30C7?!\u30CB\u30B8\u30CB\u30B8\u30E5\u30C3\u30D7\u30F3\u30CA\u30F3\u30C7?!",
  "id" : 329647277654298624,
  "created_at" : "2013-05-01 17:23:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329646899823013888",
  "text" : "\uFF1F",
  "id" : 329646899823013888,
  "created_at" : "2013-05-01 17:22:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329646867963064321",
  "text" : "\u5272\u308C\u305F\u30D3\u30B9\u30B1\u30C3\u30C8\u306F\u3046\u3057\u3046\u3057\u304C\u7F8E\u5473\u3057\u304F\u3044\u305F\u3060\u304D\u307E\u3057\u305F",
  "id" : 329646867963064321,
  "created_at" : "2013-05-01 17:21:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329646832621854722",
  "text" : "RT @ShinoderaHyo: \u30B7\u30FC\u3001\u9759\u304B\u306B\u3002\u3046\u3057\u3046\u3057\u306F\u7559\u5E74\u306B\u5305\u307E\u308C\u3066\u5272\u308C\u3066\u3057\u307E\u3046\u30D3\u30B9\u30B1\u30C3\u30C8\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329646252327313408",
    "text" : "\u30B7\u30FC\u3001\u9759\u304B\u306B\u3002\u3046\u3057\u3046\u3057\u306F\u7559\u5E74\u306B\u5305\u307E\u308C\u3066\u5272\u308C\u3066\u3057\u307E\u3046\u30D3\u30B9\u30B1\u30C3\u30C8\u3002",
    "id" : 329646252327313408,
    "created_at" : "2013-05-01 17:19:25 +0000",
    "user" : {
      "name" : "\u3072\u3087\u3046@Node\u3092\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u306B\u3059\u308B",
      "screen_name" : "shinohyo",
      "protected" : false,
      "id_str" : "413872542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606606941838663681\/TyHaKibn_normal.jpg",
      "id" : 413872542,
      "verified" : false
    }
  },
  "id" : 329646832621854722,
  "created_at" : "2013-05-01 17:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329646709036707840",
  "text" : "\u5E30\u7701\u3061\u3085\u3046\u30D1\u30E9\u30B5\u30A4\u30C8\u306E\u30D1\u30E9\u30B5\u30A4\u30C8\u30B7\u30F3\u30B0\u30EB\u611F",
  "id" : 329646709036707840,
  "created_at" : "2013-05-01 17:21:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329644748988100609",
  "text" : "\u4E00\u8A00\u30AB\u30FC\u30C9\u306B\u66F8\u3053\u3046\u304B\u306A\uFF0E\u6642\u8A08\u53F0\u30B7\u30E7\u30C3\u30D7\u3068\u304B\u306E\uFF0E",
  "id" : 329644748988100609,
  "created_at" : "2013-05-01 17:13:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329644657036378112",
  "text" : "\u7D50\u69CB\u3075\u3041\u307C\u3089\u308C\u3066\u308B\u306E\u306F\u307F\u3093\u306A\u5996\u602A\u300C\u5317\u90E8\u98DF\u5802\u306E\u30C7\u30B6\u30FC\u30C8\u306E\u201D\u30D7\u30EA\u30F3\u98DF\u3079\u305F\u3044\u3068\u601D\u3063\u305F\u3089\u30E8\u30FC\u30B0\u30EB\u30C8\u3060\u3063\u305For\u30E8\u30FC\u30B0\u30EB\u30C8\u98DF\u3079\u305F\u3044\u3068\u601D\u3063\u305F\u3089\u30D7\u30EA\u30F3\u3060\u3063\u305F\u201D\u7387\u304C\u9AD8\u3044\u300D\u306E\u88AB\u5BB3\u306B\u3042\u3063\u3066\u308B\u3063\u3066\u3053\u3068\u304B...",
  "id" : 329644657036378112,
  "created_at" : "2013-05-01 17:13:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329644293427957760",
  "text" : "\u5996\u602A\u300C\u5317\u90E8\u98DF\u5802\u306E\u30C7\u30B6\u30FC\u30C8\u306E\u201D\u30D7\u30EA\u30F3\u98DF\u3079\u305F\u3044\u3068\u601D\u3063\u305F\u3089\u30E8\u30FC\u30B0\u30EB\u30C8\u3060\u3063\u305For\u30E8\u30FC\u30B0\u30EB\u30C8\u98DF\u3079\u305F\u3044\u3068\u601D\u3063\u305F\u3089\u30D7\u30EA\u30F3\u3060\u3063\u305F\u201D\u7387\u304C\u9AD8\u3044\u300D\u306E\u4ED5\u696D\u3060\u3068\u601D\u3046",
  "id" : 329644293427957760,
  "created_at" : "2013-05-01 17:11:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329644143758413824",
  "text" : "\u5317\u90E8\u98DF\u5802\u306E\u30C7\u30B6\u30FC\u30C8\u306E\u201D\u30D7\u30EA\u30F3\u98DF\u3079\u305F\u3044\u3068\u601D\u3063\u305F\u3089\u30E8\u30FC\u30B0\u30EB\u30C8\u3060\u3063\u305For\u30E8\u30FC\u30B0\u30EB\u30C8\u98DF\u3079\u305F\u3044\u3068\u601D\u3063\u305F\u3089\u30D7\u30EA\u30F3\u3060\u3063\u305F\u201D\u7387\u304C\u9AD8\u3044",
  "id" : 329644143758413824,
  "created_at" : "2013-05-01 17:11:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329642818182213632",
  "text" : "\u54B2\u304F\u3089\u3044\u3044\u308D\u3044\u308D\u30AD\u30E3\u30E9\u304C\u3044\u308B\u3068\u597D\u307F\u304C\u89E3\u308A\u3084\u3059\u3044\u3068\u304B\u3042\u308B\u306E\u304B\u306A",
  "id" : 329642818182213632,
  "created_at" : "2013-05-01 17:05:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329642493501116417",
  "text" : "\u3059\u3053\u3084\u3093\u5B9F\u969B\u304B\u308F\u3044\u3044",
  "id" : 329642493501116417,
  "created_at" : "2013-05-01 17:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329642412324564993",
  "geo" : { },
  "id_str" : "329642464078073856",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u308F\u304B\u308B",
  "id" : 329642464078073856,
  "in_reply_to_status_id" : 329642412324564993,
  "created_at" : "2013-05-01 17:04:22 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329642362198433793",
  "text" : "\u6F2B\u753B\u3042\u3093\u307E\u308A\u8CB7\u308F\u306A\u3044\u4EE3\u308F\u308A\u306B\u8CB7\u3044\u59CB\u3081\u305F\u3089\u8A70\u3093\u306A\u304F\u306A\u3063\u3066\u3082\u7D50\u69CB\u8CB7\u3044\u7D9A\u3051\u3066\u3057\u307E\u3046\uFF0E\u632B\u6298\u3057\u3066\u308B\u3084\u3064\u306F\u91D1\u92AD\u7684\u306A\uFF0E",
  "id" : 329642362198433793,
  "created_at" : "2013-05-01 17:03:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329642169717633026",
  "text" : "\u3044\u3084\uFF0C\u597D\u304D\u3060\u3063\u305F\u308A\u5370\u8C61\u306B\u6B8B\u3063\u3066\u308B\u308F\u308A\u306B\u3083\u3042\u540D\u524D\u3092\u307B\u3068\u3093\u3069\u899A\u3048\u3066\u306A\u3044\u3042\u305F\u308A\u611B\u3092\u611F\u3058\u306A\u3044\uFF0E",
  "id" : 329642169717633026,
  "created_at" : "2013-05-01 17:03:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329642064054726657",
  "text" : "\u305D\u3057\u3066\u4E5D\u5DDE\u306E\u8896\u9577\u3044\u5B50",
  "id" : 329642064054726657,
  "created_at" : "2013-05-01 17:02:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329641894550323200",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u5CA9\u624B\u306E\u30E1\u30F3\u30D0\u30FC\u304C\u5168\u4F53\u7684\u306B\u597D\u304D\u3060\u306A\u30FC\uFF0E\u3060\u308B\u3044\u5B50\u3068\u30C8\u30E8\u30CD\uFF0E",
  "id" : 329641894550323200,
  "created_at" : "2013-05-01 17:02:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329641741797957634",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u54B2\u4E21\u65B9\u3068\u3082\u8AAD\u3093\u3060\u3051\u308C\u3069\u5DFB\u3092\u5897\u3059\u3054\u3068\u306B\u80FD\u529B\u6F2B\u753B\u5316\u304C\u8457\u3057\u3044\u306A",
  "id" : 329641741797957634,
  "created_at" : "2013-05-01 17:01:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329639967007580161",
  "text" : "\u545F\u3044\u3066\u304B\u3089\u610F\u5473\u3092\u8003\u3048\u308B\u30B9\u30BF\u30A4\u30EB",
  "id" : 329639967007580161,
  "created_at" : "2013-05-01 16:54:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329639567248478208",
  "text" : "\u3058\u308F\u3058\u308F\u6765\u308B\u7CFB\u3067\u8CAC\u3081\u3066\u3044\u304FShozo\u30F3",
  "id" : 329639567248478208,
  "created_at" : "2013-05-01 16:52:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329639126313885697",
  "text" : "\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF0E",
  "id" : 329639126313885697,
  "created_at" : "2013-05-01 16:51:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329639098241388547",
  "text" : "\u7A7A\u3092\u81EA\u7531\u306B\u98DB\u3076\u30BF\u30A4\u30AC\u30FC\u266A",
  "id" : 329639098241388547,
  "created_at" : "2013-05-01 16:51:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329638607998550016",
  "text" : "\u6700\u8FD1\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA\u3092\u65E5\u4ED8\u5909\u3063\u305F\u3089\u3064\u3076\u3084\u304Fbot\u306B\u306A\u308A\u3064\u3064\u3042\u308B",
  "id" : 329638607998550016,
  "created_at" : "2013-05-01 16:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329637450106433538",
  "text" : "\u6628\u65E5\u4E00\u756A\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA\u306F\u201D\u6876\u5C4B\u306F\u306A\u305C\u6F70\u308C\u306A\u3044\u306E\u304B\u201D\u3067\u3057\u305F\uFF0E",
  "id" : 329637450106433538,
  "created_at" : "2013-05-01 16:44:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/M58UOdZsUi",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=acoacopon",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329462020015542272",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/M58UOdZsUi",
  "id" : 329462020015542272,
  "created_at" : "2013-05-01 05:07:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329294722218729472",
  "text" : "\u30AA\u30E4\u30B9\u30DF\uFF01\uFF01\uFF01",
  "id" : 329294722218729472,
  "created_at" : "2013-04-30 18:02:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329290053501202432",
  "geo" : { },
  "id_str" : "329291103763308546",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30A2\u30D7\u30EA\uFF1F\u30AC\u30E9\u30B1\u30FC\u81EA\u4F53\u306B\u304B\u306A\u308A\u304A\u4E16\u8A71\u306B\u306A\u3063\u3066\u305F",
  "id" : 329291103763308546,
  "in_reply_to_status_id" : 329290053501202432,
  "created_at" : "2013-04-30 17:48:11 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329288975057551361",
  "text" : "\u30C4\u30A4\u30FC\u30C8\u6570\u304C\u6E1B\u3063\u305F\u8981\u56E0\u306E\u4E00\u3064\u306B\u3001\u5C65\u4FEE\u3057\u3066\u3044\u308B\u6388\u696D\u304C\u5C11\u306A\u304F\u306A\u3063\u305F\u4E8B\u304C\u6319\u3052\u3089\u308C\u308B",
  "id" : 329288975057551361,
  "created_at" : "2013-04-30 17:39:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329287815416393728",
  "text" : "\u4EBA\u4E16\u3067\u306A\u304F\u4EBA\u751F\u306A",
  "id" : 329287815416393728,
  "created_at" : "2013-04-30 17:35:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329287725209509888",
  "text" : "\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3044\u4EBA\u4E16\u306F\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3044\u3088\u306A\u3041\u2026",
  "id" : 329287725209509888,
  "created_at" : "2013-04-30 17:34:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329287226670338048",
  "text" : "\u6628\u65E5\u4E00\u756A\u9762\u767D\u304B\u3063\u305F\u30D5\u30EC\u30FC\u30BA\u304C\u300C\u4EBA\u3092\u546A\u308F\u3070\u74DC\u4E8C\u3064\u300D\u3060\u3063\u305F\u3057\u3001\u4ECA\u5F8C\u3082\u672C\u5F53\u306B\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3044\u4EBA\u751F\u3092\u9001\u308B\u4E8B\u304C\u61F8\u5FF5\u3055\u308C\u308B",
  "id" : 329287226670338048,
  "created_at" : "2013-04-30 17:32:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329284820914032641",
  "text" : "\u65B0\u4F5C\u3082\u307E\u3041\u307E\u3041\u3088\u3044\u611F\u3058[\u60B2\u9CF4\u4F1D\u60B2\u75DB\u4F1D]",
  "id" : 329284820914032641,
  "created_at" : "2013-04-30 17:23:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329284728182161408",
  "text" : "\u306A\u3093\u3060\u304B\u3093\u3060\u3067\u622F\u8A00(\u96F6\u5D0E)\u3068\u5316\u7269\u304C\u9762\u767D\u3044",
  "id" : 329284728182161408,
  "created_at" : "2013-04-30 17:22:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329284536187883521",
  "text" : "\u3042\u3001\u4E16\u754C\u30B7\u30EA\u30FC\u30BA\u306F\u8AAD\u307F\u304B\u3051\u3060\u3063\u305F\u306A\u2026",
  "id" : 329284536187883521,
  "created_at" : "2013-04-30 17:22:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329284404755185664",
  "text" : "\u897F\u5C3E\u7DAD\u65B0\u306E\u30B7\u30EA\u30FC\u30BA\u3067\u5200\u8A9E\u3068\u308A\u3059\u304B\u3060\u3051\u306F\u30CE\u30FC\u30BF\u30C3\u30C1",
  "id" : 329284404755185664,
  "created_at" : "2013-04-30 17:21:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329283897970028544",
  "geo" : { },
  "id_str" : "329284268964593664",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3044\u3044\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u30FC\u5206\u304B\u308B\u4EBA\u306B\u306F\u5206\u304B\u308B\u3057\u5206\u304B\u3089\u3093\u4EBA\u306B\u306F\u8A00\u308F\u306A\u304D\u3083\u5206\u304B\u308A\u307E\u3059\u307E\u3044",
  "id" : 329284268964593664,
  "in_reply_to_status_id" : 329283897970028544,
  "created_at" : "2013-04-30 17:21:02 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329284131601125378",
  "text" : "\u56FA\u6709\u306E\u30D5\u30EC\u30FC\u30BA\u3068\u304B\u9854\u6587\u5B57\u3068\u304B\u3042\u308B\u3068\u30AD\u30E3\u30E9\u304C\u7ACB\u3063\u3066\u3088\u3044\u3088\u306A\u30FC",
  "id" : 329284131601125378,
  "created_at" : "2013-04-30 17:20:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329283632042758144",
  "geo" : { },
  "id_str" : "329283757603422209",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u56FA\u6709\u306E\u6328\u62F6\u306B\u3057\u305F\u3089\u30AD\u30E3\u30E9\u304C\u7ACB\u3064\u306E\u3067\u306F(\u63D0\u6848)",
  "id" : 329283757603422209,
  "in_reply_to_status_id" : 329283632042758144,
  "created_at" : "2013-04-30 17:19:00 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329282773552623617",
  "text" : "\u3089\u3053\u3089\u3053\u301C\uFF01\u306B\u7A7A\u76EE",
  "id" : 329282773552623617,
  "created_at" : "2013-04-30 17:15:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u304F\u307B\u304F\u3068",
      "screen_name" : "hokuhokuto",
      "indices" : [ 3, 14 ],
      "id_str" : "176634531",
      "id" : 176634531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329282719982944256",
  "text" : "RT @hokuhokuto: \u59D4\u54E1\u9577\u300C\u3053\u3089\u305D\u3053\u30FC\uFF01\u751F\u304D\u3066\u3061\u3083\u30C0\u30E1\u3067\u3057\u3087\u30FC\uFF01\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329282605205819392",
    "text" : "\u59D4\u54E1\u9577\u300C\u3053\u3089\u305D\u3053\u30FC\uFF01\u751F\u304D\u3066\u3061\u3083\u30C0\u30E1\u3067\u3057\u3087\u30FC\uFF01\u300D",
    "id" : 329282605205819392,
    "created_at" : "2013-04-30 17:14:25 +0000",
    "user" : {
      "name" : "\u307B\u304F\u307B\u304F\u3068",
      "screen_name" : "hokuhokuto",
      "protected" : false,
      "id_str" : "176634531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607914634943725569\/xYEJu6fx_normal.jpg",
      "id" : 176634531,
      "verified" : false
    }
  },
  "id" : 329282719982944256,
  "created_at" : "2013-04-30 17:14:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329282558313496576",
  "text" : "\u30C7\u30FC\u30BF\u53D6\u308A\u304C\u30C7\u30FC\u30BF\u3068\u8A00\u3046\u6614\u304B\u3089\u3042\u308B\u8AFA\u3092\u5177\u73FE\u5316\u3057\u305F\u306E\u304C\u4ECA\u306EGoogle",
  "id" : 329282558313496576,
  "created_at" : "2013-04-30 17:14:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329282027507556352",
  "text" : "\u30DD\u30FC\u30BF\u30EB=\u30B8\u30C4\u4F7F\u3048\u305F\u3089\u30DD\u30FC\u30BF\u30EB=\u30B8\u30C4\u5C4B\u3055\u3093\u3084\u308B",
  "id" : 329282027507556352,
  "created_at" : "2013-04-30 17:12:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329281713186422786",
  "text" : "\u3082\u3057\u30EC\u30FC\u30EB\u30AC\u30F3\u6483\u3066\u308B\u306A\u3089\u30EC\u30FC\u30EB\u30AC\u30F3\u5C4B\u3055\u3093\u3084\u308B\u306E\u306B\u306A\u3041\u3001\u3063\u3066\u601D\u3046(^^)(^^)(^^)",
  "id" : 329281713186422786,
  "created_at" : "2013-04-30 17:10:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329281044354330624",
  "text" : "\u8CA7\u4E4F\u91D1\u306A\u3057",
  "id" : 329281044354330624,
  "created_at" : "2013-04-30 17:08:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329280836874682370",
  "text" : "\u65E9\u8D77\u304D\u306F\u4E8C\u675F\u4E09\u6587\u306E\u5F97",
  "id" : 329280836874682370,
  "created_at" : "2013-04-30 17:07:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329280705433583617",
  "text" : "\u6EF2\u307F\u51FA\u308B\u6771\u65B9\u611F\u306F\u3053\u306E\u305F\u3081\u304B",
  "id" : 329280705433583617,
  "created_at" : "2013-04-30 17:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329280615239278593",
  "text" : "\u3082\u3046\u6B4C\u3057\u304B\u805E\u3053\u3048\u306A\u3044\/\u591C\u304C\u304A\u308A\u3066\u304F\u308B\/\u6771\u306E\u56FD\u306E\u7720\u3089\u306A\u3044\u591C",
  "id" : 329280615239278593,
  "created_at" : "2013-04-30 17:06:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329280440047374338",
  "text" : "\u3082\u3046\u591C\u3057\u304B\u7720\u308C\u306A\u3044",
  "id" : 329280440047374338,
  "created_at" : "2013-04-30 17:05:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329260819999240192",
  "text" : "\u3059\u304E\u305F\u308B\u306F\u306A\u304A\u3059\u304E\u305F\u308B\u304C\u3054\u3068\u3057",
  "id" : 329260819999240192,
  "created_at" : "2013-04-30 15:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329254492157661184",
  "text" : "\u304A\u3063\u3055\u3093\u3082\u30CF\u30BF\u30C1\u904E\u304E\u308C\u3070\u305F\u3060\u306E\u304A\u3063\u3055\u3093",
  "id" : 329254492157661184,
  "created_at" : "2013-04-30 15:22:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329254358103490561",
  "text" : "\uFF87\uFF70\uFF9D\uFF1F",
  "id" : 329254358103490561,
  "created_at" : "2013-04-30 15:22:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329253830237769729",
  "text" : "\u611F\u5606\u3068\u7C21\u5358\u3092\u639B\u3051\u305F\u9AD8\u5EA6\u306A\u30AE\u30E3\u30B0",
  "id" : 329253830237769729,
  "created_at" : "2013-04-30 15:20:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329253588549390337",
  "geo" : { },
  "id_str" : "329253750072029184",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u306A\u308B\u307B\u3069(\u611F\u5606)",
  "id" : 329253750072029184,
  "in_reply_to_status_id" : 329253588549390337,
  "created_at" : "2013-04-30 15:19:45 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329253546790891521",
  "text" : "\u4EBA\u3092\u546A\u308F\u3070\u74DC\u4E8C\u3064\u3068\u8A00\u3046\u304B\u3089\u306A\u2026",
  "id" : 329253546790891521,
  "created_at" : "2013-04-30 15:18:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329253289940111360",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u98F2\u3093\u3067\u3001\u305D\u306E\u5F8C\u3067\u304A\u9152\u98F2\u3093\u3067\u5BDD\u305F\u3089\u3069\u3046\u306A\u308B\u306E\u3060\u308D\u3046\uFF1F",
  "id" : 329253289940111360,
  "created_at" : "2013-04-30 15:17:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329252844190449665",
  "geo" : { },
  "id_str" : "329252932237266944",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 329252932237266944,
  "in_reply_to_status_id" : 329252844190449665,
  "created_at" : "2013-04-30 15:16:30 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "river4361",
      "screen_name" : "river4361",
      "indices" : [ 0, 10 ],
      "id_str" : "2526962401",
      "id" : 2526962401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329250865703690241",
  "geo" : { },
  "id_str" : "329252476035403777",
  "in_reply_to_user_id" : 320494295,
  "text" : "@river4361 \u3069\u3046\u3082\u3001\u6700\u8FD1\u30DD\u30B9\u30C8\u6570\u5C11\u306A\u304F\u3066\u5927\u4EBA\u3057\u3044\u661F\u304B\u3089\u6765\u305F\u3001\u6700\u8FD1\u30DD\u30B9\u30C8\u6570\u5C11\u306A\u304F\u3066\u5927\u4EBA\u3057\u3044\u30DE\u30F3\u3067\u3059",
  "id" : 329252476035403777,
  "in_reply_to_status_id" : 329250865703690241,
  "created_at" : "2013-04-30 15:14:42 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329249579121930241",
  "text" : "\u3042\u308F\u3066\u3066\u304A\u3075\u308D\u306F\u3044\u308B",
  "id" : 329249579121930241,
  "created_at" : "2013-04-30 15:03:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329249242994597888",
  "text" : "\u5F8C\u8F29\u306B\u300C\u6700\u8FD1\u30DD\u30B9\u30C8\u6570\u5C11\u306A\u304F\u3066\u5927\u4EBA\u3057\u3044\u3067\u3059\u306D\u300D\u3068\u717D\u3089\u308C\u305F\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u3053\u3061\u3089",
  "id" : 329249242994597888,
  "created_at" : "2013-04-30 15:01:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329249122903289856",
  "text" : "\u304A\u91D1\u304C\u964D\u3063\u3066\u3053\u306A\u3044\u3002\u56F0\u308B\u3002",
  "id" : 329249122903289856,
  "created_at" : "2013-04-30 15:01:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]