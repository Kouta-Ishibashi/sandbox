Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31981215737184256",
  "text" : "@koketomi \u3042\u3055\u3063\u3066\u8A66\u9A13\u3067\u30C6\u30F3\u30D1\u3063\u3066\u3044\u308B\u306E\u3067\u3059\uFF57\u3044\u308D\u3093\u306A\u610F\u5473\u3067\u3082\u3046\u6587\u7CFB\u3058\u3083\u306A\u3044\u3068\u601D\u3046\u3002",
  "id" : 31981215737184256,
  "created_at" : "2011-01-31 07:44:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31980459126689794",
  "text" : "\u7559\u6570\u5B9A\u7406\u3092\u4F7F\u3048\u3070\u4E00\u822C\u306B\u539F\u59CB\u95A2\u6570\u306E\u6C42\u307E\u3089\u306A\u3044\u51FD\u6570\u307E\u3067\u7A4D\u5206\u3067\u304D\u308B\u3053\u3068\u307E\u3067\u306F\u7406\u89E3\u3057\u305F\u3002\u524D\u5F8C\u306E\u8A08\u7B97\u3092\u7406\u89E3\u3057\u306A\u304F\u3066\u306F\u3002\u3002",
  "id" : 31980459126689794,
  "created_at" : "2011-01-31 07:41:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31898853644963840",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u71B1\u529B\u5B66\u306E\u8A66\u9A13\u3060\u3002",
  "id" : 31898853644963840,
  "created_at" : "2011-01-31 02:17:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u016Fske",
      "screen_name" : "cassis1988",
      "indices" : [ 3, 14 ],
      "id_str" : "92017972",
      "id" : 92017972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31895402231889920",
  "text" : "RT @cassis1988: \u3010\u7814\u7A76\u5BA47\u3064\u306E\u5927\u7F6A\u3011\u6020\u60F0\u300C\u3054\u98EF\u98DF\u3079\u305F\u3089\u672C\u6C17\u51FA\u3059\u300D\u66B4\u98DF\u300C\u751F\u5354\u884C\u3053\u3046\u305C\uFF01\u300D\u50B2\u6162\u300C\u5352\u8AD6\u3068\u304B\u306A\u3093\u3068\u304B\u306A\u308B\u3067\u3057\u3087\u300D\u61A4\u6012\u300C\u307E\u305F\u5B9F\u9A13\u5931\u6557\u3057\u307E\u3057\u305F\u300D\u5F37\u6B32\u300C\u30A4\u30E9\u30EC\u3068\u304B\u30DE\u30C8\u30E9\u30DC\u3068\u304B\u5168\u90E8\u306E\u30D1\u30BD\u30B3\u30F3\u306B\u5C0E\u5165\u3057\u308D\u300D\u8272\u6B32\u300C\u5973\u306E\u5B50\u3001\u5C02\u653B\u306B1\u4EBA\u304F\u3089\u3044\u6765\u3044\u3088\u300D\u5AC9\u59AC\u300C\u751F\u547D\u7406\u5DE5\u30A7\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flight.co.jp\/iPhone\/TweetMe\/\" rel=\"nofollow\"\u003ETweetMe for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "31685154669862912",
    "text" : "\u3010\u7814\u7A76\u5BA47\u3064\u306E\u5927\u7F6A\u3011\u6020\u60F0\u300C\u3054\u98EF\u98DF\u3079\u305F\u3089\u672C\u6C17\u51FA\u3059\u300D\u66B4\u98DF\u300C\u751F\u5354\u884C\u3053\u3046\u305C\uFF01\u300D\u50B2\u6162\u300C\u5352\u8AD6\u3068\u304B\u306A\u3093\u3068\u304B\u306A\u308B\u3067\u3057\u3087\u300D\u61A4\u6012\u300C\u307E\u305F\u5B9F\u9A13\u5931\u6557\u3057\u307E\u3057\u305F\u300D\u5F37\u6B32\u300C\u30A4\u30E9\u30EC\u3068\u304B\u30DE\u30C8\u30E9\u30DC\u3068\u304B\u5168\u90E8\u306E\u30D1\u30BD\u30B3\u30F3\u306B\u5C0E\u5165\u3057\u308D\u300D\u8272\u6B32\u300C\u5973\u306E\u5B50\u3001\u5C02\u653B\u306B1\u4EBA\u304F\u3089\u3044\u6765\u3044\u3088\u300D\u5AC9\u59AC\u300C\u751F\u547D\u7406\u5DE5\u30A7\u300D",
    "id" : 31685154669862912,
    "created_at" : "2011-01-30 12:08:24 +0000",
    "user" : {
      "name" : "J\u016Fske",
      "screen_name" : "cassis1988",
      "protected" : false,
      "id_str" : "92017972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507501222694100993\/hfz7yBRz_normal.jpeg",
      "id" : 92017972,
      "verified" : false
    }
  },
  "id" : 31895402231889920,
  "created_at" : "2011-01-31 02:03:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31738305062117376",
  "text" : "x' y' z' \u306Be \u03C0 6\u3092\u4EE3\u5165\u3057\u305F\u3089\u8A08\u7B97\u304C\u5927\u5909\u306A\u4E8B\u306B\uFF57\uFF57",
  "id" : 31738305062117376,
  "created_at" : "2011-01-30 15:39:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31738046411968513",
  "text" : "a; b; c &gt; 0 \u306B\u5BFE\u3057\u3066\u3001\u6B21\u306E\u5F0F\u3067\u5B9A\u7FA9\u3055\u308C\u308B\u66F2\u9762\nx^2\/a^2 + y^2\/b^2 + z^2\/c^2 = 1\n\u3053\u306E\u66F2\u9762\u4E0A\u306E\u70B9\u3092(x', y', z') \u3068\u3057\u6CD5\u7DDA\u30D9\u30AF\u30C8\u30EB\u3068Z\u8EF8\u3068\u306E\u89D2\u5EA6\u3092\u03B8\u3068\u3059\n\u308B. \u3053\u306E\u3068\u304D\u4EFB\u610F\u306B(x', y', z')\u3092\u6C7A\u3081\u3066cos\u03B8\u3092\u6C42\u3081\u3088\u3002",
  "id" : 31738046411968513,
  "created_at" : "2011-01-30 15:38:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "31711098369474560",
  "geo" : { },
  "id_str" : "31725219001409537",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 owl\u3063\u3066\u3075\u304F\u308D\u3046\u3058\u3083\u3042\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3063\u3051\uFF1F",
  "id" : 31725219001409537,
  "in_reply_to_status_id" : 31711098369474560,
  "created_at" : "2011-01-30 14:47:36 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31247274843574272",
  "text" : "Index\u3084\u3089Fractale\u3084\u3089\u307F\u3066\u308B\u5834\u5408\u3058\u3083\u306A\u3044\u306A\u30FC\u3002\u9762\u767D\u304B\u3063\u305F\u3002",
  "id" : 31247274843574272,
  "created_at" : "2011-01-29 07:08:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30879440238018560",
  "text" : "\u3053 \u308C \u306F \u3072 \u3069 \u3044\u3000http:\/\/twitvideo.jp\/04cp5",
  "id" : 30879440238018560,
  "created_at" : "2011-01-28 06:46:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "indices" : [ 3, 12 ],
      "id_str" : "119635653",
      "id" : 119635653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30596286163976193",
  "text" : "RT @nanjolno: \u660E\u65E5\u5165\u8A66\u306E\u4EBA\u304C\u3044\u308B\u306E\u306D\u3002\u9811\u5F35\u3063\u3066\u4E0B\u3055\u3044\uFF01\u5BD2\u3055\u5BFE\u7B56\u5FD8\u308C\u305A\u306B\u3002\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "30584597423063040",
    "text" : "\u660E\u65E5\u5165\u8A66\u306E\u4EBA\u304C\u3044\u308B\u306E\u306D\u3002\u9811\u5F35\u3063\u3066\u4E0B\u3055\u3044\uFF01\u5BD2\u3055\u5BFE\u7B56\u5FD8\u308C\u305A\u306B\u3002\u3002",
    "id" : 30584597423063040,
    "created_at" : "2011-01-27 11:15:10 +0000",
    "user" : {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "protected" : false,
      "id_str" : "119635653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590128712906977281\/lWxpoTSQ_normal.jpg",
      "id" : 119635653,
      "verified" : true
    }
  },
  "id" : 30596286163976193,
  "created_at" : "2011-01-27 12:01:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30526464185077761",
  "text" : "Latin\u306F\u307E\u305A\u512A\u304C\u53D6\u308C\u305F\u306F\u305A\u3002\u81EA\u5206\u3078\u306E\u3054\u8912\u7F8E(\u7B11)\u306B\u3075\u305F\u3070\u306E\u685C\u9905\u3068\u8C46\u3082\u3061\u3068\u8CB7\u3063\u3066\u304D\u305F\u3002\u307E\u3041\u7518\u3044\u3082\u3093\u98DF\u3079\u305F\u304B\u3063\u305F\u3060\u3051\u3060\u3051\u3069\uFF57\uFF57",
  "id" : 30526464185077761,
  "created_at" : "2011-01-27 07:24:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30413294963523584",
  "text" : "\u307E\u305F\u96EA \u3057\u304B\u3082(\u8907\u6570\u4EBA\u3067\uFF09\u6559\u5BA4\u96E3\u6C11\u306A\u3046\uFF57",
  "id" : 30413294963523584,
  "created_at" : "2011-01-26 23:54:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30201076116361216",
  "text" : "\u304A\u304B\u305A\u304C\u3067\u304D\u3066\u3054\u98EF\u304C\u708A\u3051\u3066\u306A\u3044\u3044\u3064\u3082\u306E\u30D1\u30BF\u30FC\u30F3\u306F\u3044\u308A\u307E\u3057\u305F\u30FC",
  "id" : 30201076116361216,
  "created_at" : "2011-01-26 09:51:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "30076955025997825",
  "geo" : { },
  "id_str" : "30109639060234241",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u8A70\u3081\u66FF\u3048\u7528\u306E\u82AF\u3092\u7B46\u7BB1\u306B\u5FCD\u3070\u305B\u3066\u304A\u304F\u306E\u304C\u5B89\u5B9A\uFF01",
  "id" : 30109639060234241,
  "in_reply_to_status_id" : 30076955025997825,
  "created_at" : "2011-01-26 03:47:52 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E09\u68EE\u3059\u305A\u3053 4\/8 2nd\u30A2\u30EB\u30D0\u30E0\u767A\u58F2\uFF01",
      "screen_name" : "mimori_suzuko",
      "indices" : [ 3, 17 ],
      "id_str" : "114700374",
      "id" : 114700374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29892189777559552",
  "text" : "RT @mimori_suzuko: \u3061\u306A\u307F\u306B\u3001\u5834\u672B\u306E\u30E9\u30FC\u30E1\u30F3\u5C4B\u3055\u3093\u3067\u98DF\u3079\u305F\u8089\u91CE\u83DC\u7092\u3081\u5B9A\u98DF\u3002\uFF62\u3089\u3081\u3048\u3093\uFF63\u3082\u304D\u3063\u3068\u3042\u3093\u306A\u611F\u3058\u306A\u306E\u3060\u308D\u3046\u3088\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29891447511588864",
    "text" : "\u3061\u306A\u307F\u306B\u3001\u5834\u672B\u306E\u30E9\u30FC\u30E1\u30F3\u5C4B\u3055\u3093\u3067\u98DF\u3079\u305F\u8089\u91CE\u83DC\u7092\u3081\u5B9A\u98DF\u3002\uFF62\u3089\u3081\u3048\u3093\uFF63\u3082\u304D\u3063\u3068\u3042\u3093\u306A\u611F\u3058\u306A\u306E\u3060\u308D\u3046\u3088\u3002",
    "id" : 29891447511588864,
    "created_at" : "2011-01-25 13:20:51 +0000",
    "user" : {
      "name" : "\u4E09\u68EE\u3059\u305A\u3053 4\/8 2nd\u30A2\u30EB\u30D0\u30E0\u767A\u58F2\uFF01",
      "screen_name" : "mimori_suzuko",
      "protected" : false,
      "id_str" : "114700374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574808428163375104\/55ELhXO__normal.png",
      "id" : 114700374,
      "verified" : false
    }
  },
  "id" : 29892189777559552,
  "created_at" : "2011-01-25 13:23:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29890448323518464",
  "geo" : { },
  "id_str" : "29891998546665473",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u9AD8\u91CE\u5DDD\u3068\u5317\u5927\u8DEF\u901A\u308A\u306E\u4EA4\u70B9\u3042\u305F\u308A\u3067\u3059\u3002",
  "id" : 29891998546665473,
  "in_reply_to_status_id" : 29890448323518464,
  "created_at" : "2011-01-25 13:23:02 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29890117686530049",
  "text" : "\u3068\u306F\u3044\u3048\u30CE\u30EA\u3067\u30D0\u30B9\u964D\u308A\u3061\u3083\u3063\u305F\u304B\u3089gdgd\uFF12\uFF10\u5206\u307B\u3069\u6B69\u304B\u306A\u3044\u3068\u5E30\u308C\u306A\u3044\u3002\u305B\u3063\u304B\u304F\u3042\u3063\u305F\u307E\u3063\u305F\u306E\u306B\u306A\u30FC\u3002",
  "id" : 29890117686530049,
  "created_at" : "2011-01-25 13:15:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29889877042532352",
  "text" : "\u5317\u5927\u8DEF\u306B\u3042\u308B\u591C\u4E2D\u307E\u3067\u3084\u3063\u3066\u308B\u30AB\u30EC\u30FC\u3046\u3069\u3093\u306E\u304A\u5E97\u5BC4\u3063\u3066\u307F\u305F\u3002\u7F8E\u5473\u3057\u304B\u3063\u305F\u3041\u3002",
  "id" : 29889877042532352,
  "created_at" : "2011-01-25 13:14:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29518177113214976",
  "geo" : { },
  "id_str" : "29520492591316992",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u30D0\u30A4\u30C8\u306E\u8A71\u2015\uFF1F",
  "id" : 29520492591316992,
  "in_reply_to_status_id" : 29518177113214976,
  "created_at" : "2011-01-24 12:46:48 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29472888830562305",
  "text" : "\u6696\u623F\u3068\u70AC\u71F5\u306B\u5B8C\u5168\u306B\u4F9D\u5B58\u3057\u305F\u751F\u6D3B\u3092\u3057\u3066\u3044\u305F\u3089\u96FB\u6C17\u4EE3\u304C\u5927\u5909\u306A\u4E8B\u306B\uFF57\u3067\u3082\u3084\u3081\u306A\u3044(\u30AD\u30EA\u30C3",
  "id" : 29472888830562305,
  "created_at" : "2011-01-24 09:37:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28827887616393216",
  "geo" : { },
  "id_str" : "28833777224523777",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u304A\u524D\u304C\u8A00\u3046\u304B\uFF57",
  "id" : 28833777224523777,
  "in_reply_to_status_id" : 28827887616393216,
  "created_at" : "2011-01-22 15:18:02 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28761002069729280",
  "text" : "\u7D05\u7389\u3084\u3063\u3068\u51FA\u305F\u3002\u3075\u3045\u3002",
  "id" : 28761002069729280,
  "created_at" : "2011-01-22 10:28:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28730355636772864",
  "text" : "\u30D5\u30E9\u30AF\u30BF\u30EB\u306E\u30CD\u30C3\u30B5\u3001\u30C6\u30F3\u30B7\u30E7\u30F3\u9AD8\u3044\u6642\u306E\u82B1\u6FA4\u3055\u3093\u305D\u306E\u307E\u307E\u306E\u30A4\u30E1\u30FC\u30B8\u3002\u3053\u306E\u3042\u3068\u3069\u3046\u306A\u308B\u306E\u304B\u306A\u30FC#fractal",
  "id" : 28730355636772864,
  "created_at" : "2011-01-22 08:27:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28399020627992577",
  "text" : "\u30D0\u30A4\u30C8\u524D\u306B\u306A\u3093\u304B\u304A\u8179\u306B\u5165\u308C\u308C\u3070\u826F\u304B\u3063\u305F\u306A\u3041\u3002\u305B\u3081\u3066\u3054\u98EF\u708A\u3044\u3066\u51FA\u308C\u3070\u2026",
  "id" : 28399020627992577,
  "created_at" : "2011-01-21 10:30:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28148498956296192",
  "text" : "8\u6642\u9593\u5F31\u3076\u3063\u7D9A\u3051\u3067\u9EBB\u96C0\u3002\u30C6\u30B9\u30C8\u524D\uFF1F\u305D\u306E\u5E7B\u60F3\u3092(ry",
  "id" : 28148498956296192,
  "created_at" : "2011-01-20 17:54:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 47, 61 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27873982313136128",
  "geo" : { },
  "id_str" : "27951940042231810",
  "in_reply_to_user_id" : 109537708,
  "text" : "\u8A08\u7B97\u3057\u306A\u3044\u3068\u89E3\u3051\u306A\u3044\u554F\u984C\u306E\u7B54\u3048\u306E\u6570\u5B57\u3060\u3051\u899A\u3048\u308B\u3068\u304B\u3002\u3002\u3002\u305D\u308C\u3067\u3082\u5927\u5B66\u751F\u304B\u3087\u3001\u3068\u601D\u3063\u3066\u3057\u307E\u3046\u3002 @OhgakiRintaro \u5927\u5B66\u751F\u4EE5\u524D\u306B\u6570\u5F0F\u3092\u6271\u3046\u8CC7\u683C\u306A\u3057\u3002",
  "id" : 27951940042231810,
  "in_reply_to_status_id" : 27873982313136128,
  "created_at" : "2011-01-20 04:53:56 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27707470499553280",
  "geo" : { },
  "id_str" : "27710481057714176",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u602A\u3057\u304F\u3066\u7570\u306A\u3063\u3066\u3044\u308B\u306E\u304C\u602A\u7570\u3067\u3059\u3002",
  "id" : 27710481057714176,
  "in_reply_to_status_id" : 27707470499553280,
  "created_at" : "2011-01-19 12:54:28 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27699632335224832",
  "geo" : { },
  "id_str" : "27703635647401984",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u91CD\u3055\u304C\u307B\u307C\u7121\u304B\u3063\u305F\u308A\u3001\u30D2\u30ED\u30A4\u30F3\u304C\u4E3B\u4EBA\u516C\u306E\u53E3\u3092\u30DB\u30C1\u30AD\u30B9\u3067\u7DB4\u3058\u305F\u308A\u3059\u308B\u306E\u306F\u6709\u308A\u304C\u3061\u3067\u3057\u3087\u3046\u304B\uFF57",
  "id" : 27703635647401984,
  "in_reply_to_status_id" : 27699632335224832,
  "created_at" : "2011-01-19 12:27:16 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27641146402410496",
  "geo" : { },
  "id_str" : "27642519177142272",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u306A\u3093\u304B\u7A7F\u3044\u305F\u307E\u307E\u8170\u4E0B\u308D\u3059\u306E\u6C17\u304C\u5F15\u3051\u308B\u3088\u306A\u3002\u7406\u7531\u306F\u308F\u304B\u3093\u306A\u3044\u304C\u3002",
  "id" : 27642519177142272,
  "in_reply_to_status_id" : 27641146402410496,
  "created_at" : "2011-01-19 08:24:24 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27636392418869249",
  "text" : "\u534A\u5E74\u306E\u6240\u7528\u6642\u9593\uFF16\uFF10\u5206\u8DB3\u3089\u305A\u3067\uFF12\u5358\u4F4D\u3002\u7D20\u6674\u3089\u3057\u3044\u5927\u5B66\u3060\u3002",
  "id" : 27636392418869249,
  "created_at" : "2011-01-19 08:00:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7530\u6751\u3086\u304B\u308A6\/27 28\u4EE3\u3005\u6728\u7B2C1\u30E9\u30A4\u30D6",
      "screen_name" : "yukari_tamura",
      "indices" : [ 3, 17 ],
      "id_str" : "95407005",
      "id" : 95407005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27600873416818689",
  "text" : "RT @yukari_tamura: \u30E2\u30F3\u30CF\u30F3\u3057\u3066\u305F\u3089\u30EA\u30A2\u30EB\u3067\u6599\u7406\u304C\u7126\u3052\u305F\u3002\u3002\u4E0A\u624B\u306B\u3084\u3051\u306A\u304B\u3063\u305F\u3002\u3002(\u00B4\uFF65_\uFF65`)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for iPhone\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27599665004290048",
    "text" : "\u30E2\u30F3\u30CF\u30F3\u3057\u3066\u305F\u3089\u30EA\u30A2\u30EB\u3067\u6599\u7406\u304C\u7126\u3052\u305F\u3002\u3002\u4E0A\u624B\u306B\u3084\u3051\u306A\u304B\u3063\u305F\u3002\u3002(\u00B4\uFF65_\uFF65`)",
    "id" : 27599665004290048,
    "created_at" : "2011-01-19 05:34:07 +0000",
    "user" : {
      "name" : "\u7530\u6751\u3086\u304B\u308A6\/27 28\u4EE3\u3005\u6728\u7B2C1\u30E9\u30A4\u30D6",
      "screen_name" : "yukari_tamura",
      "protected" : false,
      "id_str" : "95407005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1337207153\/yukari_normal.png",
      "id" : 95407005,
      "verified" : false
    }
  },
  "id" : 27600873416818689,
  "created_at" : "2011-01-19 05:38:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27581243264606208",
  "text" : "\u306A\u3093\u3067\u5317\u90E8\u98DF\u5802\u3063\u3066\u6642\u9593\u305A\u3089\u3057\u3066\u3082\u305D\u3053\u305D\u3053\u6DF7\u3093\u3067\u308B\u3093\u3060\u308D\u3002\u4E0D\u601D\u8B70\u3002",
  "id" : 27581243264606208,
  "created_at" : "2011-01-19 04:20:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27537872135389184",
  "text" : "\u4E00\u9650\u30C6\u30B9\u30C8\u308F\u305A\u30FC\u3002\u305F\u3076\u3093\u5927\u4E08\u592B\u304B\u306A\u3002",
  "id" : 27537872135389184,
  "created_at" : "2011-01-19 01:28:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27179541726240768",
  "geo" : { },
  "id_str" : "27188511144673280",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3048\u3001\u30EF\u30AF\u30EF\u30AF\u3055\u3093\u3058\u3083\u306A\u3044\u306E\u304B\u2026",
  "id" : 27188511144673280,
  "in_reply_to_status_id" : 27179541726240768,
  "created_at" : "2011-01-18 02:20:20 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26950819047804928",
  "geo" : { },
  "id_str" : "26978447737753600",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u4E80\u30EC\u30B9\u3060\u304C\u307C\u3063\u3061\u934B\u5927\u597D\u304D\u306A\u79C1\u304C\u901A\u308A\u307E\u3059\u3088\u3063\u3068",
  "id" : 26978447737753600,
  "in_reply_to_status_id" : 26950819047804928,
  "created_at" : "2011-01-17 12:25:37 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26849307860664321",
  "geo" : { },
  "id_str" : "26850057466683392",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u3082\u9045\u523B\u3057\u305F\u8A18\u61B6\u304C\u3042\u308B\u3002\u3042\u3093\u306A\u3093\u6642\u9593\u901A\u308A\u306B\u96C6\u307E\u308B\u610F\u5473\u306A\u3044\u3063\u3066\uFF57",
  "id" : 26850057466683392,
  "in_reply_to_status_id" : 26849307860664321,
  "created_at" : "2011-01-17 03:55:27 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26848491405836288",
  "geo" : { },
  "id_str" : "26849515063476224",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30B7\u30E9\u30D0\u30B9\u306E\u898B\u65B9\u306F\u77E5\u3089\u306A\u3044\u304C\u597D\u304D\u306A\u304F\u3068\u3082\u7D4C\u6E08\u3068\u306F\u5358\u4F4D\u306E\u4E92\u63DB\u5236\u5EA6\u304C\u3042\u3063\u305F\u306F\u305A\u3002",
  "id" : 26849515063476224,
  "in_reply_to_status_id" : 26848491405836288,
  "created_at" : "2011-01-17 03:53:17 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26840626863542272",
  "geo" : { },
  "id_str" : "26840949451661312",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5F8C\u8005\u306F\u30DE\u30B8\u3067\u4F53\u306B\u60AA\u3044\u304B\u3089\u904E\u5270\u6442\u53D6\u306B\u306F\u6C17\u3092\u3064\u3051\u3066\u306A\u30FC",
  "id" : 26840949451661312,
  "in_reply_to_status_id" : 26840626863542272,
  "created_at" : "2011-01-17 03:19:15 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26840653929390080",
  "text" : "\u96EA\u304C\u6B8B\u3063\u3066\u308B\u3068\u6674\u308C\u3066\u3066\u3001\u65E5\u306A\u305F\u306B\u3044\u3066\u3082\u306A\u304A\u7A7A\u6C17\u304C\u51B7\u305F\u3044\u3002\u3055\u306A\u304C\u3089\u30B9\u30AD\u30FC\u5834\u3002",
  "id" : 26840653929390080,
  "created_at" : "2011-01-17 03:18:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26555098503053312",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u30012000\u5B57\u4EE5\u4E0A\u306E\u3064\u3082\u308A\u30671700\u5B57\u7A0B\u5EA6\u66F8\u3044\u305F\u3068\u3053\u308D\u30673000\u5B57\u4EE5\u4E0A\u3060\u3063\u305F\u3053\u3068\u306B\u6C17\u304C\u4ED8\u3044\u3066\u3057\u307E\u3063\u305F\u3002\u6C34\u5897\u3057\u306E\u305F\u3081\u306B\u3082\u69CB\u6210\u3092\u8003\u3048\u306A\u304A\u3055\u306D\u3070\u3002",
  "id" : 26555098503053312,
  "created_at" : "2011-01-16 08:23:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26546816149360640",
  "text" : "@koketomi \u5730\u7406\u7684\u306B\u5357\u3060\u304B\u3089\u306A\u3001\u9759\u5CA1\u3002\u3068\u308A\u3042\u3048\u305A\u5916\u306B\u51FA\u305F\u304F\u306A\u3044\uFF57",
  "id" : 26546816149360640,
  "created_at" : "2011-01-16 07:50:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26545990479642625",
  "text" : "\u7A93\u3092\u958B\u3051\u305F\u3089\u8EFD\u304F\u96EA\u666F\u8272\u3060\u3063\u305F\u4EF6\u306B\u3064\u3044\u3066",
  "id" : 26545990479642625,
  "created_at" : "2011-01-16 07:47:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26542775818260480",
  "geo" : { },
  "id_str" : "26543436463087616",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u7D42\u308F\u3063\u305F\u2026\u306E\u304B\uFF1F",
  "id" : 26543436463087616,
  "in_reply_to_status_id" : 26542775818260480,
  "created_at" : "2011-01-16 07:37:03 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26509157330849792",
  "text" : "\u3067\u3082\u753B\u50CF\u691C\u7D22\u3067\u30A2\u30CB\u30E1\u306E\u753B\u50CF\u304C\u5F15\u3063\u639B\u304B\u308B\u306E\u306F\u9B31\u9676\u3057\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u6B32\u3057\u3044\u306E\u306F\u30D5\u30E9\u30AF\u30BF\u30EB\u56F3\u5F62\u306E\u753B\u50CF\u306A\u306E\u306B\u3002",
  "id" : 26509157330849792,
  "created_at" : "2011-01-16 05:20:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26508964229283841",
  "text" : "\u30D5\u30E9\u30AF\u30BF\u30EB\u3002\u81EA\u5DF1\u76F8\u4F3C\u5F62\u3002\u95A2\u4FC2\u306A\u3044\u3051\u3069\u30AA\u30FC\u30D7\u30CB\u30F3\u30B0\u306F\u30D5\u30E9\u30AF\u30BF\u30EB\u56F3\u5F62\u306E\u30AA\u30F3\u30D1\u30EC\u30FC\u30C9\u3060\u3063\u305F\u306A\u3041\u3002\u5B9F\u306F\u6570\u5B66\u7528\u8A9E\u3060\u3063\u305F\u308A\u3002\u3067\u3082\u307E\u3041\u4E16\u754C\u89B3\u3082\u72EC\u7279\u3067\u9762\u767D\u3044\u304B\u3089\u3001\u3082\u3046\u3061\u3087\u3063\u3068\u898B\u3066\u307F\u3088\u3046\u304B\u306A\uFF03fractal",
  "id" : 26508964229283841,
  "created_at" : "2011-01-16 05:20:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25980529480306690",
  "text" : "\u6B21\u5C40\u3055\u3063\u304D\u632F\u308A\u8FBC\u3093\u3060CPU\u304C\u6570\u3048\u5F79\u6E80\u30C4\u30E2\u3063\u305F\uFF57\uFF57\u306A\u306B\u3053\u308C\u8352\u308C\u3059\u304E\uFF57\uFF57",
  "id" : 25980529480306690,
  "created_at" : "2011-01-14 18:20:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25979963509313536",
  "text" : "\u304A\u4F11\u307F\u3001\u3068\u304B\u3044\u3044\u306A\u304C\u3089\u5E03\u56E3\u3067\u643A\u5E2F\u9EBB\u96C0\u3084\u3063\u3066\u305F\u3089\u89AA\u3067\u6E05\u8001\u982D\u548C\u4E86\u3063\u305F\u3002\u3063\u3066\u306A\u3093\u3067\u3067\u3059\u304B\u30FC\u3002",
  "id" : 25979963509313536,
  "created_at" : "2011-01-14 18:18:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25978439592841216",
  "text" : "\u304A\u4F11\u307F",
  "id" : 25978439592841216,
  "created_at" : "2011-01-14 18:11:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25978365915693057",
  "text" : "\u305D\u306E\u30EC\u30DD\u30FC\u30C8\u306E\u70BA\u306B\u305F\u307E\u305F\u307E\u4ECA\u6708\u7279\u96C6\u3060\u3063\u305F\u306E\u3067\u6570\u5B66\u96D1\u8A8C\u3092\u8CB7\u3063\u3066\u3001\u5C0E\u5165\u90E8\u8AAD\u3093\u3060\u3089\u53C2\u8003\u6587\u732E\u306E\uFF13\u3064\u306E\u5185\uFF12\u3064\u3092\u56F3\u66F8\u9928\u3067\u501F\u308A\u3066\u3044\u305F\u3002\u30D4\u30F3\u30DD\u30A4\u30F3\u30C8\uFF01",
  "id" : 25978365915693057,
  "created_at" : "2011-01-14 18:11:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25975879083491328",
  "text" : "\u4ECA\u65E5\u30BB\u30F3\u30BF\u30FC\u306E\u4EBA\u306F\u9811\u5F35\u3063\u3066\uFF01",
  "id" : 25975879083491328,
  "created_at" : "2011-01-14 18:01:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25975730953265152",
  "text" : "\u307E\u3041\u9069\u5F53\u306A\u3068\u3053\u308D\u3067\u7D42\u308F\u3089\u305B\u308B\u3051\u3069\u2015\u3002\u4ECA\u306F\u3082\u3046\u3084\u3081\u3066\u5BDD\u307E\u3059\u3002",
  "id" : 25975730953265152,
  "created_at" : "2011-01-14 18:01:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25975598207737856",
  "text" : "\u4EEE\u306B\u3053\u306E\u307E\u307E\uFF47\uFF44\uFF47\uFF44\u7D9A\u3051\u3066\u3044\u304F\u3068\u30EA\u30FC\u30DE\u30F3\u4E88\u60F3\u307E\u3067\uFF57\uFF57",
  "id" : 25975598207737856,
  "created_at" : "2011-01-14 18:00:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25975350815105025",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u66F8\u304D\u59CB\u3081\u305F\u3051\u3069\u3001\u3053\u308C\u3069\u3053\u3067\u6253\u3061\u6B62\u3081\u306B\u3059\u308C\u3070\u3044\u3044\u3093\u3060\uFF1F\uFF57",
  "id" : 25975350815105025,
  "created_at" : "2011-01-14 17:59:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25055523623665664",
  "text" : "\u3054\u98EF\u98DF\u3079\u305F\u3089\u7720\u306A\u3063\u305F\u3002 \u56F3\u66F8\u9928\u6696\u304B\u3044\u304B\u3089\u5C1A\u66F4\u3002",
  "id" : 25055523623665664,
  "created_at" : "2011-01-12 05:04:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24965994355097600",
  "text" : "\u307E\u3060\u5E03\u56E3\u3060\u304C\u3082\u3046\u5BD2\u3044",
  "id" : 24965994355097600,
  "created_at" : "2011-01-11 23:08:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24863503185608704",
  "text" : "\u732B\u306A\u306E\u304B\u72AC\u306A\u306E\u304B\u30B5\u30EB\u306A\u306E\u304B\uFF57\u3088\u304F\u8AAD\u3080\u3068\u9762\u767D\u3044\uFF57http:\/\/digimaga.net\/2010\/01\/boston-cat-summoned-for-jury-duty",
  "id" : 24863503185608704,
  "created_at" : "2011-01-11 16:21:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24611964613296129",
  "text" : "\u5BD2\u3044\u3001\u3068\u8A00\u3046\u3088\u308A\u51B7\u305F\u3044",
  "id" : 24611964613296129,
  "created_at" : "2011-01-10 23:42:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9EBB\u96C0\u30FB\u540D\u8A00\u30FB\u73CD\u8A00 bot",
      "screen_name" : "mj_meigen",
      "indices" : [ 3, 13 ],
      "id_str" : "150944798",
      "id" : 150944798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24611599096483840",
  "text" : "RT @mj_meigen: \u3084\u3063\u3071 \u4ED6\u4EBA\u540C\u5FD7\u306E\u632F\u308A\u3053\u307F\u306F \u3044\u3064\u898B\u3066\u3082\u3044\u3044\u3082\u3093\u3060 http:\/\/amzn.to\/9YwqLd \u5FB3\u5DDD\u5EB7\u5175\u885B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "24607481971875840",
    "text" : "\u3084\u3063\u3071 \u4ED6\u4EBA\u540C\u5FD7\u306E\u632F\u308A\u3053\u307F\u306F \u3044\u3064\u898B\u3066\u3082\u3044\u3044\u3082\u3093\u3060 http:\/\/amzn.to\/9YwqLd \u5FB3\u5DDD\u5EB7\u5175\u885B",
    "id" : 24607481971875840,
    "created_at" : "2011-01-10 23:24:15 +0000",
    "user" : {
      "name" : "\u9EBB\u96C0\u30FB\u540D\u8A00\u30FB\u73CD\u8A00 bot",
      "screen_name" : "mj_meigen",
      "protected" : false,
      "id_str" : "150944798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/953549805\/prof-mei_normal.gif",
      "id" : 150944798,
      "verified" : false
    }
  },
  "id" : 24611599096483840,
  "created_at" : "2011-01-10 23:40:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24355024729538561",
  "geo" : { },
  "id_str" : "24357757679304704",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6795\u5143\u3067\u6563\u4E71\u3057\u3066\u308B\u306E\u306F\u30B6\u30E9\u3060\u3063\u305F\u304C\u30D9\u30C3\u30C8\u306E\u68AF\u5B50\u306F\u306A\u3044\u308F\uFF57",
  "id" : 24357757679304704,
  "in_reply_to_status_id" : 24355024729538561,
  "created_at" : "2011-01-10 06:51:56 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24344717164544000",
  "text" : "\u3046\u3093\u3001\u30EC\u30DD\u30FC\u30C8\u3068\u3042\u3059\u306E\u30C6\u30B9\u30C8\u306E\u4E88\u7FD2\u3068\u63D0\u51FA\u8AB2\u984C\u3092\u3084\u308D\u3046\u3002\u6210\u4EBA\u5F0F\uFF1F\u6C17\u306E\u305B\u3044\u2606",
  "id" : 24344717164544000,
  "created_at" : "2011-01-10 06:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24061602907033600",
  "text" : "http:\/\/www.nicovideo.jp\/watch\/sm13198530 \u300012:05\u79D2\uFF5E\u3001\u683C\u95D8\u6280\u306F\u3055\u3063\u3071\u308A\u308F\u304B\u3093\u306A\u3044\u304C\u3053\u308C\u304C\u5834\u9055\u3044\u3060\u3063\u3066\u306E\u306F\u5206\u304B\u308B\u3002\u3046\u3093\u3002",
  "id" : 24061602907033600,
  "created_at" : "2011-01-09 11:15:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23679854729756672",
  "text" : "@koketomi\u3000\u306A\u3093\u304B\u3057\u3087\u3063\u3061\u3085\u3046\u602A\u6211\u3057\u3066\u308B\u5370\u8C61\u3060\u304C\u5927\u4E08\u592B\u304B\uFF1F",
  "id" : 23679854729756672,
  "created_at" : "2011-01-08 09:58:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23632453381914624",
  "geo" : { },
  "id_str" : "23637547997462530",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5730\u5B66\u306F\u3082\u3063\u3068\u306A\u3044\uFF57",
  "id" : 23637547997462530,
  "in_reply_to_status_id" : 23632453381914624,
  "created_at" : "2011-01-08 07:10:05 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    }, {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 15, 24 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23419875468775424",
  "text" : "@nico_reflexio @koketomi \u3044\u3084\u3001ref\u304C\u58CA\u308C\u3066\u3044\u308B\u306E\u306F\u524D\u63D0\u3068\u3044\u3046\u6587\u8108\u3067\u666E\u6BB5\u3068\u3069\u3053\u304C\u9055\u3046\u306E\u304B\u3001\u3068\u3044\u3046\u610F\u5473\u3067\u8A00\u3063\u305F\u3002\u58CA\u308C\u3066\u3044\u306A\u3044\u3068\u306F\u4E00\u5207\u601D\u3063\u3066\u3044\u306A\u3044\u3001\u5B89\u5FC3\u3057\u308D\u3002",
  "id" : 23419875468775424,
  "created_at" : "2011-01-07 16:45:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23410403706933248",
  "text" : "@nico_reflexio \u3069\u3053\u304C\u5D29\u58CA\u3057\u3066\u3044\u305F\u306E\u304B\uFF4B\uFF57\uFF53\uFF4B",
  "id" : 23410403706933248,
  "created_at" : "2011-01-07 16:07:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23319033893883905",
  "geo" : { },
  "id_str" : "23322703301705728",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa mjk\u8AB0\u3060\u3088\uFF57",
  "id" : 23322703301705728,
  "in_reply_to_status_id" : 23319033893883905,
  "created_at" : "2011-01-07 10:19:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23031536920043520",
  "text" : "\u70AC\u71F5\u3001\u871C\u67D1\u3001\u6B64\u308C\u4EE5\u4E0A\u306F\u8A00\u308F\u306A\u304F\u3066\u3082\u3044\u3044\u3060\u308D\u3046\u3002",
  "id" : 23031536920043520,
  "created_at" : "2011-01-06 15:02:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23031063798358017",
  "text" : "@chisa10404 \u5FEB\u697D\u4EE5\u5916\u3092\u6C42\u3081\u308B\u306E\u304C\u697D\u3057\u3044\u3053\u3068\u3082\u3042\u308B\u3063\u3066\u306E\u306F\u5FD8\u308C\u306A\u3044\u3088\u3046\u306B\u306D\u3002\u82E5\u5E72\u77DB\u76FE\u3092\u306F\u3089\u3093\u3067\u3044\u308B\u3051\u308C\u3069\u3002",
  "id" : 23031063798358017,
  "created_at" : "2011-01-06 15:00:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23023151294189569",
  "geo" : { },
  "id_str" : "23029777514369024",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u500B\u4EBA\u7684\u306B\u306F\u3001\u3089\u304D\u3059\u305F\u306F\u4FDD\u5065\u5BA4\u306E\u5148\u751F\u3067\uFF26\uFF21\u3067\u3059\u3002\u3000\u30A2\u30CB\u30E1\u51FA\u3066\u306A\u3044\u3051\u3069\u2190",
  "id" : 23029777514369024,
  "in_reply_to_status_id" : 23023151294189569,
  "created_at" : "2011-01-06 14:55:01 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22942458803396609",
  "geo" : { },
  "id_str" : "22948658223775744",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u706B\u3092\u3064\u3051\u3088\u3046",
  "id" : 22948658223775744,
  "in_reply_to_status_id" : 22942458803396609,
  "created_at" : "2011-01-06 09:32:41 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22922984205320192",
  "text" : "\uFF19\uFF10\u5206\u8FD1\u304F\u6687\u3001\u3069\u3046\u3082\u6700\u8FD1\u4F59\u308A\u306B\u65E9\u304F\u52D5\u304D\u3059\u304E\u308B\u5ACC\u3044\u304C\u3042\u308B\u306A\u30FC",
  "id" : 22922984205320192,
  "created_at" : "2011-01-06 07:50:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22615295495512064",
  "text" : "\u3063\u3066\u304B\u7528\u3044\u306A\u3044\u3067\u89E3\u304F\u3068\u00D7\u8CB0\u3046\u3093\u3060\u3088\u306D\u30FCorz",
  "id" : 22615295495512064,
  "created_at" : "2011-01-05 11:28:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22615136141312000",
  "text" : "tanZ\u306Etaylor\u5C55\u958B\u3001tanZ=cotZ-2cot2Z\u3092\u7528\u3044\u3066\u89E3\u3051\u3063\u3066\u2026\u2026\u7528\u3044\u306A\u3044\u307B\u3046\u304C\u697D\u306A\u3093\u3067\u3059\u3051\u3069\u3002",
  "id" : 22615136141312000,
  "created_at" : "2011-01-05 11:27:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22271954337665025",
  "geo" : { },
  "id_str" : "22272572544516097",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6570\u5B66\u8005\u3092\u601D\u3044\u6D6E\u304B\u3079\u305F\u4FFA\u306F\u3082\u3046\u99C4\u76EE\u3060\u3002",
  "id" : 22272572544516097,
  "in_reply_to_status_id" : 22271954337665025,
  "created_at" : "2011-01-04 12:46:09 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22219527416717312",
  "text" : "\u307E\u3060\u6CB3\u539F\u753A\u4E09\u6761\u2026",
  "id" : 22219527416717312,
  "created_at" : "2011-01-04 09:15:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22209735411376129",
  "text" : "\u4EAC\u90FD\u99C5\u306A\u3046\u3002\u6642\u9593\u5E2F\u306E\u305B\u3044\u3067\u3082\u3042\u308B\u304B\u3082\u3060\u304C\u3053\u3063\u3061\u306E\u65B9\u304C\u5BD2\u3044\u3002",
  "id" : 22209735411376129,
  "created_at" : "2011-01-04 08:36:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22207022749454336",
  "text" : "\u6570\u5B66\u306E\u6559\u79D1\u66F8\u3067\u306F\u5B9A\u7FA9\u306B\u91CD\u304D\u3092\u7F6E\u304F\u304B\u3089\u5C11\u3057\u3067\u3082\u66D6\u6627\u3060\u3068\u6CE8\u3068\u304B\u65AD\u308A\u304C\u5165\u308B\u3002\u66D6\u6627\u3055\u306B\u9003\u3052\u308B\u4ED6\u306E\u6587\u7AE0\u3088\u308A\u304B\u306A\u308A\u8AAD\u307F\u306B\u304F\u3044\u3051\u3069\u3001\u660E\u78BA\u3067\u3042\u308B\u3002",
  "id" : 22207022749454336,
  "created_at" : "2011-01-04 08:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22206099927072770",
  "text" : "@koketomi \u304A\u5B88\u308A\u30C6\u30FC\u30D6\u30EB\u7406\u8AD6\u304C\u78BA\u7ACB\u3055\u308C\u305F\u3089\u3057\u3044\u304C\u4F7F\u3063\u3066\u308B\u30FC\uFF1F",
  "id" : 22206099927072770,
  "created_at" : "2011-01-04 08:22:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22170487194910720",
  "text" : "\u3084\u3063\u3071\u308A\u7121\u304B\u3063\u305F\u308F\u3041\u3001\u5927\u4EBA\u3057\u304F\u6570\u5B66\u304B\u30D5\u30E9\u30F3\u30B9\u8A9E\u304B\u306A\u3041",
  "id" : 22170487194910720,
  "created_at" : "2011-01-04 06:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22155710250876929",
  "text" : "\u3069\u3046\u3067\u3082\u3044\u3044\u304C\u99C5\u5730\u4E0B\u3068\u99C5\u8FD1\u3063\u3066\u3084\u3084\u3053\u3057\u3044\u3088\u306D\u3002",
  "id" : 22155710250876929,
  "created_at" : "2011-01-04 05:01:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22155544210968576",
  "text" : "\u6771\u4EAC\u99C5\u3067\u63A2\u3059\u304B\u30FC\u3002\u99C5\u30CA\u30AB\u306E\u672C\u5C4B\u306B\u3042\u308B\u3068\u3044\u3044\u306A\u3041\u3002",
  "id" : 22155544210968576,
  "created_at" : "2011-01-04 05:01:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22152479483371520",
  "text" : "\u306A\u3093\u3067\u5316\u7269\u8A9E\u898B\u3064\u304B\u3089\u306A\u3044\u3093\u3060\uFF01\u50BE\u7269\u8A9E\u3057\u304B\u7F6E\u3044\u3066\u306A\u3044\u3068\u304Borz",
  "id" : 22152479483371520,
  "created_at" : "2011-01-04 04:48:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21768580253097984",
  "text" : "@chisa10404 petit\u306A\u306E\u304B\u6FC0\u306A\u306E\u304B\u2026\uFF57",
  "id" : 21768580253097984,
  "created_at" : "2011-01-03 03:23:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21765938755928065",
  "text" : "\u99C5\u524D\u3067\u304A\u3070\u3061\u3083\u3093\u304C\u300C\u826F\u3044\u304A\u5E74\u3092\u301C\u300D\u3063\u3066\u304A\u5225\u308C\u3057\u3066\u305F\u3051\u3069\u3001\u6765\u5E74\u307E\u3067\u4F1A\u308F\u306A\u3044\u3064\u3082\u308A\uFF1F\u305D\u308C\u3068\u3082\u4FFA\u304C\u4F55\u304B\u52D8\u9055\u3044\u3057\u3066\u308B\uFF1F",
  "id" : 21765938755928065,
  "created_at" : "2011-01-03 03:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21592197954535424",
  "text" : "\u6771\u4EAC\u306A\u3046\u3002\u5E74\u8CC0\u72B6\u3001\u8FD1\u6240\u306E\u30AB\u30D5\u30A7\u3068\u90F5\u8CAF\u9280\u884C\u304B\u3089\u3057\u304B\u6765\u3066\u3044\u306A\u304B\u3063\u305F\u3002\u81EA\u5206\u3082\u51FA\u3057\u3066\u3044\u306A\u3044\u3051\u3069\u5207\u306A\u304F\u306A\u3063\u305F\u3002",
  "id" : 21592197954535424,
  "created_at" : "2011-01-02 15:42:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21495473139355649",
  "text" : "\u6771\u3001\u30EA\u30F3\u30B7\u30E3\u30F3\u3001\u30C8\u30A4\u30C8\u30A4\u3001\u6DF7\u8001\u982D \u8DF3\u6E80\u306A\u304C\u3089\u3042\u307E\u308A\u898B\u306A\u3044\u5F79\u306E\u7D44\u307F\u5408\u308F\u305B",
  "id" : 21495473139355649,
  "created_at" : "2011-01-02 09:18:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21170259184582656",
  "text" : "\u4F53\u8ABF\u5D29\u58CA\u306A\u3046\u301C",
  "id" : 21170259184582656,
  "created_at" : "2011-01-01 11:45:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]