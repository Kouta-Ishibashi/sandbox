Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64164863928320000",
  "geo" : { },
  "id_str" : "64165808166797312",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u305D\u306E\u767A\u8A00\u306E\u6D45\u306F\u304B\u306A\u3053\u3068\u3002\u904E\u53BB\u306B\u5165\u90E8\u3057\u305F\u672C\u4EBA\u3082\u81EA\u4ED6\u3068\u3082\u306B\u8A8D\u3081\u308B\u30A2\u30DB\u3063\u3066\u3053\u3068\u306B\u306A\u308B\u3088\u306D\u3002",
  "id" : 64165808166797312,
  "in_reply_to_status_id" : 64164863928320000,
  "created_at" : "2011-04-30 03:14:55 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64145822094331904",
  "geo" : { },
  "id_str" : "64146277063073792",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u767D\u7C73\u306B\u5869\u304B\u3051\u3066\u3082\u5473\u6C17\u306A\u3044\u3051\u3069\u5869\u3080\u3059\u3073\u306F\u98DF\u3079\u3089\u308C\u308B\u4E0D\u601D\u8B70",
  "id" : 64146277063073792,
  "in_reply_to_status_id" : 64145822094331904,
  "created_at" : "2011-04-30 01:57:18 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64021125885214720",
  "geo" : { },
  "id_str" : "64021793639378946",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3084\u3059\u307F",
  "id" : 64021793639378946,
  "in_reply_to_status_id" : 64021125885214720,
  "created_at" : "2011-04-29 17:42:39 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64020725052358656",
  "text" : "\u3084\u3063\u3071iPhone\u306B\u4E57\u308A\u63DB\u3048\u3088\u3046\u304B\u306A\u30FC\u3002\u30D3\u30EA\u30E4\u30FC\u30C9\u306E\u30AD\u30E5\u30FC\u8CB7\u3046\u4E88\u5B9A\u3060\u3057\u306A\u30FC\u3002\u51FA\u8CBB\u304C\u5D69\u3080\u306E\u306F\u56F0\u308B\u306A\u30FC\u3002",
  "id" : 64020725052358656,
  "created_at" : "2011-04-29 17:38:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64019771888377856",
  "text" : "\u3068\u308A\u3042\u3048\u305AiPod Touch \u306B\u8272\u3005\u5165\u308C\u3066\u307F\u305F\u3002\u304A\u3059\u3059\u3081\u306E\u30A2\u30D7\u30EA\u3042\u3063\u305F\u3089\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u30FC\u3002\u5B8C\u5168\u306B\u65B0\u3057\u3044\u304A\u3082\u3061\u3083\u8CB7\u3063\u305F\u5B50\u4F9B\u306E\u56F3\u3067\u3059w",
  "id" : 64019771888377856,
  "created_at" : "2011-04-29 17:34:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 41, 51 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63997105043279872",
  "text" : "\u3042\u308A\u307E\u3059\u304B\uFF1F\u3063\u3066\u805E\u304D\u305F\u304B\u3063\u305F\u306E\u306B\u62EC\u5F27\u306E\u4E2D\u57CB\u3081\u3066\u6E80\u8DB3\u3057\u305F\u3002\u53CD\u7701\u306F\u3057\u3066\u3044\u306A\u3044\u3002 RT @end313124: ipod\u3067\u304A\u52E7\u3081\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u306E\u30D6\u30E9\u30A6\u30B6\uFF08\u306A\u3093\u304B\u56FA\u6709\u540D\u8A5E\u304C\u3042\u3063\u305F\u3051\u3069\u899A\u3048\u3066\u306A\u3044\uFF09",
  "id" : 63997105043279872,
  "created_at" : "2011-04-29 16:04:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63996718932434944",
  "text" : "ipod\u3067\u304A\u52E7\u3081\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u306E\u30D6\u30E9\u30A6\u30B6\uFF08\u306A\u3093\u304B\u56FA\u6709\u540D\u8A5E\u304C\u3042\u3063\u305F\u3051\u3069\u899A\u3048\u3066\u306A\u3044\uFF09",
  "id" : 63996718932434944,
  "created_at" : "2011-04-29 16:03:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AB (\u975E\u516C\u5F0Fbot)",
      "screen_name" : "miruka_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "118009758",
      "id" : 118009758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63963637462732800",
  "geo" : { },
  "id_str" : "63964014882979840",
  "in_reply_to_user_id" : 118009758,
  "text" : "@miruka_bot 5",
  "id" : 63964014882979840,
  "in_reply_to_status_id" : 63963637462732800,
  "created_at" : "2011-04-29 13:53:04 +0000",
  "in_reply_to_screen_name" : "miruka_bot",
  "in_reply_to_user_id_str" : "118009758",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 27, 33 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "\u305F\u3064\u304D",
      "screen_name" : "katoutatuki",
      "indices" : [ 61, 73 ],
      "id_str" : "532962852",
      "id" : 532962852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63960653647446016",
  "text" : "\u901A\u8CA9\u304C\u3042\u3063\u305F\u304B\uFF01\u6771\u4EAC\u306E\u53CB\u9054\u306B\u304A\u4F7F\u3044\u983C\u3093\u3058\u3083\u3063\u305F\u3002RT @hyuki: #mathgirl \u30AB\u30D0\u30FC\u5916\u3057\u305F\u4E2D\u306E\u6F2B\u753B\u3082\u3002 RT @katoutatuki: \u6F2B\u753B\u3068\u3044\u3048\u3070\u300E\u6570\u5B66\u30AC\u30FC\u30EB \u30B2\u30FC\u30C7\u30EB\u306E\u4E0D\u5B8C\u5168\u6027\u5B9A\u7406\u300F\u306E\u30B3\u30DF\u30C3\u30AF\u7248\u304C\u3068\u3089\u306E\u3042\u306A\u304B\u3089\u5C4A\u3044\u305F\u3002\u3068\u3089\u7279\u5178\u306E\u30C6\u30C8\u30E9\u3061\u3083\u3093\u30AB\u30FC\u30C9\u304C\u304B\u308F\u3044\u3044\uFF01",
  "id" : 63960653647446016,
  "created_at" : "2011-04-29 13:39:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63960032886272000",
  "text" : "\u70AC\u71F5\u5E03\u56E3\u306F\u3057\u307E\u3063\u3061\u3083\u3063\u305F\u3051\u3069\u307E\u3060\u65E5\u304C\u843D\u3061\u308B\u3068\u51B7\u3048\u308B\u306A\u30FC",
  "id" : 63960032886272000,
  "created_at" : "2011-04-29 13:37:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63947035031781376",
  "geo" : { },
  "id_str" : "63947456974557184",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u308B\u3068\u601D\u3046\u3002\u3066\u304BKU\u306B\u306F\u3042\u308B\u3002",
  "id" : 63947456974557184,
  "in_reply_to_status_id" : 63947035031781376,
  "created_at" : "2011-04-29 12:47:16 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63937901142089728",
  "geo" : { },
  "id_str" : "63941876629254145",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305F\u3060\u3067\u3055\u3048\u6DF7\u3080\u306E\u306B\u3042\u306E\u6709\u69D8\u3060\u304B\u3089\u306A\u3002\u7E4B\u304C\u308B\u307E\u3067\u30A4\u30FC\u30E2\u30D0\u30A4\u30EB\u3068\u304B\u5951\u7D04\u3059\u308B\u306E\u3082\u3042\u308A\u304B\u3082\u3057\u308C\u306A\u3044\u306D\u3002",
  "id" : 63941876629254145,
  "in_reply_to_status_id" : 63937901142089728,
  "created_at" : "2011-04-29 12:25:06 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63926087876489216",
  "text" : "\u30E1\u30E2 \u5869\u5927\u3055\u3058\uFF12\u3000\u3000\u30C1\u30EA\u30D1\u30A6\u30C0\u30FC\u5927\u3055\u3058\uFF11 \u3057\u3087\u3046\u304C\u5927\u3055\u3058\uFF11\u3000\u9ED2\u3053\u3057\u3087\u3046\u3000\u5927\u3055\u3058\uFF11\u3000\u30EC\u30E2\u30F3\u6C41\u5C11\u3057",
  "id" : 63926087876489216,
  "created_at" : "2011-04-29 11:22:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63924644310294528",
  "text" : "\u81F3\u9AD8\u306E\u30AB\u30EC\u30FC\u4F5C\u308A\u306A\u3046\u30FC",
  "id" : 63924644310294528,
  "created_at" : "2011-04-29 11:16:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63917164326957056",
  "text" : "\u3042\u30FC\u65B0\u7389\u306D\u304E\u306E\u76EE\u3078\u306E\u653B\u6483\u6027\u3063\u3066\u4F55\u3068\u304B\u306A\u3089\u306A\u3044\u3082\u306E\u304B\u306A\u3002\u3002\u3002",
  "id" : 63917164326957056,
  "created_at" : "2011-04-29 10:46:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63906584765538305",
  "text" : "\u4EBA\u53C2\u3068\u30E8\u30FC\u30B0\u30EB\u30C8\u3068\u2026\u2026\u8CB7\u3044\u7269\u884C\u3063\u3066\u304F\u308B\u3002",
  "id" : 63906584765538305,
  "created_at" : "2011-04-29 10:04:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63893476479221760",
  "geo" : { },
  "id_str" : "63894831830802432",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3093\u306A\u306E\u5F8C\u3067\u3082\u3044\u3044\u3068\u601D\u3046\u3051\u3069\u306A\u30FC\u3002\u3057\u304B\u3057\u3084\u3063\u3068\u5927\u5B66\u5165\u5B66\u3063\u307D\u304F\u306A\u3063\u3066\u304D\u305F\u306A\uFF57\uFF57",
  "id" : 63894831830802432,
  "in_reply_to_status_id" : 63893476479221760,
  "created_at" : "2011-04-29 09:18:09 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63828753477939200",
  "text" : "\u8D77\u5E8A\u3002\u5589\u306E\u75DB\u307F\u306F\u98A8\u90AA\u6C17\u5473\u304B\u306A\u30FC\u3002",
  "id" : 63828753477939200,
  "created_at" : "2011-04-29 04:55:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63707786764226561",
  "geo" : { },
  "id_str" : "63707930033266688",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u541B\u304C\u805E\u3044\u3066\u304D\u305F\u3093\u3060\u308D\u3046\uFF1F",
  "id" : 63707930033266688,
  "in_reply_to_status_id" : 63707786764226561,
  "created_at" : "2011-04-28 20:55:28 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63707537157001216",
  "geo" : { },
  "id_str" : "63707693973635072",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u8E0F\u307E\u306A\u3044\u3002",
  "id" : 63707693973635072,
  "in_reply_to_status_id" : 63707537157001216,
  "created_at" : "2011-04-28 20:54:32 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63707036084482048",
  "geo" : { },
  "id_str" : "63707512129589248",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u3084\u3063\u3068\u5BDD\u308B\u3093\u3060\u3088!",
  "id" : 63707512129589248,
  "in_reply_to_status_id" : 63707036084482048,
  "created_at" : "2011-04-28 20:53:49 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63706887903916032",
  "text" : "\u5E30\u5B85\u2026\u5BDD\u308B\u306E\u4E00\u629E\u3002\u98A8\u90AA\u6C17\u5473\u3002",
  "id" : 63706887903916032,
  "created_at" : "2011-04-28 20:51:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63277143488081920",
  "geo" : { },
  "id_str" : "63278283558625280",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u74B0\u5883\u3067\u3059\u304B\u306D\u3002\u4E00\u5E74\u3044\u308B\u3068\u81EA\u7136\u306B\u2026\u3002\u6C17\u306B\u969C\u3063\u305F\u3089\u3059\u3093\u307E\u305B\u3093\u3002",
  "id" : 63278283558625280,
  "in_reply_to_status_id" : 63277143488081920,
  "created_at" : "2011-04-27 16:28:13 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63276720001789953",
  "text" : "\u5BDD\u308B\u3088\u3002\u4ECA\u65E5\uFF12\u9650\u3084\u3057\u306A\u3002\uFF13\u9650\u306E\u4E88\u7FD2\u3084\u3063\u3066\u306A\u3044\u3051\u3069\u306A\u3093\u3068\u304B\u306A\u308B\u3084\u308D\u2190",
  "id" : 63276720001789953,
  "created_at" : "2011-04-27 16:22:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63274830597853185",
  "text" : "\u501F\u308A\u7269\u306Eipodtouch\u30CD\u30C3\u30C8\u306B\u3064\u306A\u3052\u3066\u300C\u4FBF\u5229\u306D\u30FC\u3001\u9762\u767D\u30FC\u300D\u3063\u3066\u9023\u547C\u3057\u3066\u305F\u3089\u3053\u3093\u306A\u6642\u9593\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3002\u4ECA\u65E5ID\u306E\u767B\u9332\u3057\u3066\u3044\u308D\u3044\u308D\u843D\u3068\u3057\u3066\u904A\u3093\u3067\u307F\u3088\u3046\u3002",
  "id" : 63274830597853185,
  "created_at" : "2011-04-27 16:14:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63267075317174272",
  "geo" : { },
  "id_str" : "63267452431237122",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u7D39\u4ECB\u3057\u3066\u307B\u3057\u3044\u30EC\u30D9\u30EB\u2026",
  "id" : 63267452431237122,
  "in_reply_to_status_id" : 63267075317174272,
  "created_at" : "2011-04-27 15:45:10 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63261982903635968",
  "text" : "@yurily924 \u306A\u308B\u307B\u3069\u3002\u4E0A\u4E0B\u306E\u4EBA\u3068\u8A71\u3059\u6A5F\u4F1A\u3063\u3066\u610F\u5916\u306B\u306A\u3044\u3067\u3059\u304B\u3089\u306D\u3047\u3002\u7A81\u7136\u3059\u307F\u307E\u305B\u3093\u306D\u3001\u30A2\u30C4\u304F\u8A9E\u3063\u3066\u308B\u306E\u30A4\u30DE\u30A4\u30C1\u89E3\u3089\u306A\u304B\u3063\u305F\u3082\u3093\u3067\u6C17\u306B\u306A\u3063\u3061\u3083\u3044\u307E\u3057\u305F\u3002",
  "id" : 63261982903635968,
  "created_at" : "2011-04-27 15:23:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "indices" : [ 27, 39 ],
      "id_str" : "94825321",
      "id" : 94825321
    }, {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u3000\u658E\u85E4\u3000\u6ECB",
      "screen_name" : "Lantis_Saito",
      "indices" : [ 72, 85 ],
      "id_str" : "96513941",
      "id" : 96513941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63259402735583233",
  "text" : "\u30D2\u30C8\u30AB\u30E9\u307F\u3093\u306A\u3067\u884C\u3053\u3046\u305C\u3001\u307F\u305F\u3044\u306A\u30DC\u30B1\u3067\u3059\u306D\uFF57 RT @milkyholmes: \u79C1\u3082\u6C17\u306B\u306A\u3063\u3066\u3044\u307E\u3059\u3001\u4ECA\u5EA6\u307F\u3093\u306A\u3067\u4E00\u7DD2\u306B\u884C\u304D\u307E\u305B\u3093\u304B\uFF1F\u3000RT @Lantis_Saito: \u3072\u3068\u308A\u713C\u8089\u5C02\u9580\u5E97\u300C\u3072\u3068\u308A\u300D\u3002\u884C\u3063\u3066\u307F\u305F\u3044\u3002http:\/\/bit.ly\/emVsy8",
  "id" : 63259402735583233,
  "created_at" : "2011-04-27 15:13:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63257659482185729",
  "text" : "@yurily924\u3000M\u30BB\u30DF\u30CA\u30FC\u3063\u3066\u4F55\u306E\u7565\u3067\u3059\u304B\uFF1F\u5168\u4F53\u50CF\u304C\u898B\u3048\u306A\u3044\u306E\u3067\u5DEE\u652F\u3048\u306A\u304B\u3063\u305F\u3089\u3055\u3089\u3063\u3068\u8AAC\u660E\u3057\u3066\u3082\u3089\u3048\u307E\u305B\u3093\u304B\u30FC\uFF1F\u8FF7\u60D1\u3060\u3063\u305F\u3089\u7121\u8996\u3057\u3066\u304F\u3060\u3055\u3044m(_ _)m",
  "id" : 63257659482185729,
  "created_at" : "2011-04-27 15:06:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63253640378462208",
  "geo" : { },
  "id_str" : "63254363929444352",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6B63\u3057\u3044\u2026",
  "id" : 63254363929444352,
  "in_reply_to_status_id" : 63253640378462208,
  "created_at" : "2011-04-27 14:53:10 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63254107410018304",
  "text" : "\u5E30\u5B85\u3002\u7A7A\u8179\u3045\u2026\u3067\u3082\u3053\u306E\u6642\u9593\u304B\u3089\u306A\u3093\u304B\u4F5C\u3063\u3066\u98DF\u3079\u308B\u306E\u306F\u6C17\u304C\u5F15\u3051\u308B\u3002\u304B\u3068\u3044\u3063\u3066\u30B3\u30F3\u30D3\u30CB\u306A\u3093\u304B\u306B\u51FA\u76F4\u3059\u6C17\u3082\u306A\u3044\u3002",
  "id" : 63254107410018304,
  "created_at" : "2011-04-27 14:52:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63253334450114560",
  "text" : "\u3082\u3057\u88CF\u30C9\u30E9\u304C\u6697\u523B\u306B\u4E57\u3063\u305F\u3089",
  "id" : 63253334450114560,
  "created_at" : "2011-04-27 14:49:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63243854610051072",
  "text" : "\uFF11\uFF13\uFF05 \u9593\u306B\u5408\u3046\u304B\uFF1F\u307E\u3041\u30C4\u30A4\u30C3\u30BF\u30FC\u3084\u3081\u308A\u3083\u3044\u3044\u3093\u3060\u3051\u3069\u3002\u30D0\u30A4\u30C8\u5F8C\u3063\u3066\u6563\u3005\u558B\u3063\u3066\u3093\u306E\u306B\u3064\u3076\u3084\u304D\u305F\u304F\u306A\u308B\u3002",
  "id" : 63243854610051072,
  "created_at" : "2011-04-27 14:11:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63242698680840193",
  "text" : "\u3042\u3068\uFF11\uFF17\uFF05\uFF6A\u2026\u79FB\u52D5\u4E2D\u30B7\u30E3\u30ED\u306E\u5192\u967A\u8AAD\u307F\u305F\u3044\u304C\u30E1\u30FC\u30EB\u306E\u51E6\u7406\u306B\u8FFD\u308F\u308C\u958B\u3051\u306A\u3044\u2026\uFF08\u30B7\u30E3\u30FC\u30ED\u30C3\u30AF\u30DB\u30FC\u30E0\u30BA\u7684\u306A\u610F\u5473\u3067)",
  "id" : 63242698680840193,
  "created_at" : "2011-04-27 14:06:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63240357051244544",
  "text" : "\u4ED6\u4EBA\u306B\uFF34\uFF2C\u5168\u90E8\u8AAD\u3080\u5FC5\u8981\u7121\u3044\u3001\u3068\u304B\u5049\u305D\u3046\u306B\u8AED\u3057\u3064\u3064\uFF13\uFF10\uFF10\u4EF6\u8FD1\u304F\u30D1\u30E9\u30D1\u30E9\u898B\u3066\u3057\u307E\u3063\u305F\u3002\u305D\u3057\u3066\u3042\u3068\uFF12\uFF12\uFF05\u3057\u304B\u96FB\u6C60\u304C\u306A\u3044\u3002",
  "id" : 63240357051244544,
  "created_at" : "2011-04-27 13:57:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63185693760946176",
  "geo" : { },
  "id_str" : "63185946732015616",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u306F\u306A\u304D\u3068\u304B\u3053\u3063\u3066\u308A\u898B\u3066\u305D\u3046\u3002",
  "id" : 63185946732015616,
  "in_reply_to_status_id" : 63185693760946176,
  "created_at" : "2011-04-27 10:21:18 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63185709288267778",
  "text" : "@mo5nya \u9762\u767D\u3044\u306A\u3089\u898B\u3066\u307F\u3088\u3046\u304B\u306A\u30FC\u3002\u5B8C\u7D50\u3057\u305F\u304B\u3089\u6B21\u5F85\u3064\u5FC5\u8981\u306A\u3044\u3067\u3059\u3082\u3093\u306D\u3002",
  "id" : 63185709288267778,
  "created_at" : "2011-04-27 10:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63185468266782720",
  "text" : "\u8A00\u8449\u904A\u3073\u306F\u30C4\u30A4\u30C3\u30BF\u30FC\u306A\u3089\u8A31\u3055\u308C\u308B\u2026\u3088\u306D\uFF1F",
  "id" : 63185468266782720,
  "created_at" : "2011-04-27 10:19:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63184974953717760",
  "text" : "\u3064\u307E\u308A\u591C\u306B\u306F\u6B62\u3093\u3067\u307B\u3057\u3044\u306A\u30FC\u3063\u3066\u3053\u3068\u3002\u6C17\u6E29\u5DEE\u6FC0\u3057\u3044\u3057\u3042\u3093\u307E\u308A\u6FE1\u308C\u308B\u3068\u75C5\u307F\u305D\u3046\u3002",
  "id" : 63184974953717760,
  "created_at" : "2011-04-27 10:17:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63184658745139200",
  "text" : "\u96E8\u8DB3\u306B\u6CE2\u304C\u3042\u308B\u306A\u30FC\u3002\u3042\u3057\u306A\u307F\u3092\u305D\u308D\u3048\u3066\u307B\u3057\u3044\u306A\u3002\u51FA\u6765\u308C\u3070\u5F31\u3081\uFF08\u591C\u96E8)\u3067\u3002",
  "id" : 63184658745139200,
  "created_at" : "2011-04-27 10:16:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63184296554409984",
  "text" : "\u6B32\u304C\u3042\u308B\u3068\u3088\u304F\u306A\u3044\u3002\u6709\u308B\u306E\u304B\u7121\u3044\u306E\u304B\u3002",
  "id" : 63184296554409984,
  "created_at" : "2011-04-27 10:14:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63184086642073600",
  "text" : "\u3064\u307E\u308A\u96E8\u5ACC\u3044\u3002\u5BB6\u306B\u3044\u308B\u3068\u304D\u306F\u597D\u304D\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 63184086642073600,
  "created_at" : "2011-04-27 10:13:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63183965510565888",
  "text" : "\u96E8\u306B\u3082\u8CA0\u3051\u305A\u3002\u8CA0\u3051\u305A\u5ACC\u3044\u3002",
  "id" : 63183965510565888,
  "created_at" : "2011-04-27 10:13:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 36, 46 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63183771704365056",
  "text" : "\u00D7\u8AAD\u8005\u25CB\u8AAD\u66F8\u2026\u3044\u3084\u78BA\u304B\u306B\u8AAD\u8005\u3084\u3063\u3066\u305F\u308F\u3051\u3060\u3057\u3053\u308C\u3067\u3044\u3044!\uFF08\uFF77\uFF98\uFF6F RT @end313124: \u8AAD\u8005\u3057\u3066\u3066\u4E57\u308A\u63DB\u3048\u99C5\u3092\u898B\u9003\u3057\u30D5\u30EA\u30C6\u30F3\u3060\u3063\u305F\u308F\u30FC\u3002\u7126\u308B\u3002\u307E\u3041\u3059\u3050\u6298\u308A\u8FD4\u305B\u308B\u96FB\u8ECA\u304C\u3042\u3063\u3066\u826F\u304B\u3063\u305F\u308F\u30FC\u3002",
  "id" : 63183771704365056,
  "created_at" : "2011-04-27 10:12:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63182949012619264",
  "text" : "RT @NISIOISIN_BOT: \u306A\u3089\u3070\u670D\u5F93\u306E\u8A3C\u3068\u3057\u3066\u5102\u306E\u982D\u3092\u64AB\u3067\u3066\u307F\u3088\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63182855609659392",
    "text" : "\u306A\u3089\u3070\u670D\u5F93\u306E\u8A3C\u3068\u3057\u3066\u5102\u306E\u982D\u3092\u64AB\u3067\u3066\u307F\u3088\uFF01",
    "id" : 63182855609659392,
    "created_at" : "2011-04-27 10:09:01 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 63182949012619264,
  "created_at" : "2011-04-27 10:09:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63182878615416832",
  "text" : "\u8AAD\u8005\u3057\u3066\u3066\u4E57\u308A\u63DB\u3048\u99C5\u3092\u898B\u9003\u3057\u30D5\u30EA\u30C6\u30F3\u3060\u3063\u305F\u308F\u30FC\u3002\u7126\u308B\u3002\u307E\u3041\u3059\u3050\u6298\u308A\u8FD4\u305B\u308B\u96FB\u8ECA\u304C\u3042\u3063\u3066\u826F\u304B\u3063\u305F\u308F\u30FC\u3002",
  "id" : 63182878615416832,
  "created_at" : "2011-04-27 10:09:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63175221737291776",
  "text" : "\u300C\u5098\u306E\u964D\u308B\u307E\u3044\u300D\u3063\u3066\u5909\u63DB\u30DF\u30B9\u3057\u305D\u3046\u306B\u306A\u3063\u305F\u3002\u964D\u308B\u307E\u3044\u3068\u601D\u3063\u3066\u5098\u6301\u3063\u3066\u51FA\u308B\u3068\u96E8\u304C\u964D\u308B\u6CD5\u5247\u306E\u3053\u3068\u304B\u306A\uFF1F",
  "id" : 63175221737291776,
  "created_at" : "2011-04-27 09:38:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63174888302710784",
  "text" : "\u9053\u884C\u304F\u4EBA\u3005\u306E\u5098\u306E\u30EA\u30FC\u30C1\u304C\u6016\u3044\u3002\u6FE1\u308C\u305F\u5098\u304C\u89E6\u308C\u308B\u3060\u3051\u3067\u3082\u4E0D\u5FEB\u306A\u306E\u306B\u523A\u3055\u308C\u305D\u3046\u306B\u306A\u308B\u3002\u3061\u3083\u3093\u3068\u5098\u306E\u632F\u308B\u821E\u3044\u3092\u610F\u8B58\u3057\u3066\u307B\u3057\u3044\u3002",
  "id" : 63174888302710784,
  "created_at" : "2011-04-27 09:37:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63070160499642369",
  "text" : "RT @magokoro84: \u6687\u306A\u3093\u3067\u4ED6\u5B66\u90E8\u306E\u8B1B\u7FA9\u8074\u8B1B\u3057\u3088\u3046\u3068\u3057\u305F\u3089\u3001\n\u4FFA\u300C\u6587\u5B66\u90E8\u306A\u3093\u3067\u3059\u304C\u25CB\u5B66\u90E8\u306E\u8B1B\u7FA9\u8074\u8B1B\u3067\u304D\u307E\u3059\u304B\uFF1F\u300D\n\u25CB\u5B66\u90E8\u6559\u52D9\u300C\u6587\u5B66\u90E8\u306B\u805E\u3044\u3066\u304F\u3060\u3055\u3044\u300D\n\u2193\n\u4FFA\u300C\u25CB\u5B66\u90E8\u306E\u8B1B\u7FA9\u8074\u8B1B\u3067\u304D\u307E\u3059\u304B\u300D\n\u6587\u5B66\u90E8\u6559\u52D9\u300C\u25CB\u5B66\u90E8\u306B\u805E\u3044\u3066\u304F\u3060\u3055\u3044\u300D\n\u3068\u8A00\u308F\u308C\u3084\u308B\u6C17\u306A\u304F\u3057\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63065100352892930",
    "text" : "\u6687\u306A\u3093\u3067\u4ED6\u5B66\u90E8\u306E\u8B1B\u7FA9\u8074\u8B1B\u3057\u3088\u3046\u3068\u3057\u305F\u3089\u3001\n\u4FFA\u300C\u6587\u5B66\u90E8\u306A\u3093\u3067\u3059\u304C\u25CB\u5B66\u90E8\u306E\u8B1B\u7FA9\u8074\u8B1B\u3067\u304D\u307E\u3059\u304B\uFF1F\u300D\n\u25CB\u5B66\u90E8\u6559\u52D9\u300C\u6587\u5B66\u90E8\u306B\u805E\u3044\u3066\u304F\u3060\u3055\u3044\u300D\n\u2193\n\u4FFA\u300C\u25CB\u5B66\u90E8\u306E\u8B1B\u7FA9\u8074\u8B1B\u3067\u304D\u307E\u3059\u304B\u300D\n\u6587\u5B66\u90E8\u6559\u52D9\u300C\u25CB\u5B66\u90E8\u306B\u805E\u3044\u3066\u304F\u3060\u3055\u3044\u300D\n\u3068\u8A00\u308F\u308C\u3084\u308B\u6C17\u306A\u304F\u3057\u305F",
    "id" : 63065100352892930,
    "created_at" : "2011-04-27 02:21:06 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 63070160499642369,
  "created_at" : "2011-04-27 02:41:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 21, 31 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63053500107599872",
  "text" : "\u30AA\u30E0\u30E9\u30A4\u30B9\u4E91\u3005\u30CD\u30BF\u3058\u3083\u306A\u3044\u3088\uFF01\uFF1E\uFF1C RT @end313124: \u3044\u307Eiphone\u3063\u3066\u5E7E\u3089\u3059\u308B\u306E\u30FC\uFF1F\uFF1F\u3066\u304B\uFF14\uFF1F\uFF15\u304C\u51FA\u305F\u3093\u3060\u3063\u3051\uFF1F",
  "id" : 63053500107599872,
  "created_at" : "2011-04-27 01:35:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63053244225687552",
  "text" : "\u3044\u307Eiphone\u3063\u3066\u5E7E\u3089\u3059\u308B\u306E\u30FC\uFF1F\uFF1F\u3066\u304B\uFF14\uFF1F\uFF15\u304C\u51FA\u305F\u3093\u3060\u3063\u3051\uFF1F",
  "id" : 63053244225687552,
  "created_at" : "2011-04-27 01:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63050980706615296",
  "geo" : { },
  "id_str" : "63052438562816000",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u8108\u7D61\u306A\u304F\u8A00\u3044\u305F\u3044\u3053\u3068\u3092\u8A00\u3046\u5834\u6240\uFF08\u3068\u52DD\u624B\u306B\u7406\u89E3\u3057\u3066\u308B)\u304B\u3089\u5927\u4E08\u592B\u3067\u3059\u3088\u3063",
  "id" : 63052438562816000,
  "in_reply_to_status_id" : 63050980706615296,
  "created_at" : "2011-04-27 01:30:47 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62906777469059072",
  "text" : "\u5BDD\u308B\u3002\u4ECA\u65E5\u5348\u5F8C\u306F\u96E8\u306E\u4E88\u5831\u3060\u3051\u3069\u964D\u3089\u306A\u3044\u3068\u3044\u3044\u306A\u3001\u3046\u3093\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 62906777469059072,
  "created_at" : "2011-04-26 15:51:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62876097708175362",
  "geo" : { },
  "id_str" : "62876916004294659",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u66F8\u3044\u305F\u3084\u3064\u3082\u982D\u60AA\u3044\u3051\u3069\u5B9F\u884C\u3059\u308B\u3084\u3064\uFF08\u305D\u3093\u306A\u3084\u3064\u304C\u3044\u305F\u3089\uFF09\u3082\u982D\u60AA\u3044\u3088\u306D\u3002\u3046\u3093\u3002",
  "id" : 62876916004294659,
  "in_reply_to_status_id" : 62876097708175362,
  "created_at" : "2011-04-26 13:53:19 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 76, 87 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62875901754478592",
  "text" : "\u3053\u308C\u306E\u305B\u3044\u3058\u3083\u3093\uFF1F\u3000http:\/\/kirei.biglobe.ne.jp\/news\/detail\/20110426162331_pch19894 RT @magokoro84: \u3068\u3053\u308D\u3067\u4F55\u3067\u30AA\u30E0\u30E9\u30A4\u30B9TL\u306B\u306A\u3063\u3066\u3093\u3060\u3044",
  "id" : 62875901754478592,
  "created_at" : "2011-04-26 13:49:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62873879760216064",
  "text" : "\u5E30\u5B85\u3002",
  "id" : 62873879760216064,
  "created_at" : "2011-04-26 13:41:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62775616801476608",
  "text" : "\u307E\u3041\uFF15\u9650\u3082\u30B5\u30FC\u30AF\u30EB\u3082\u643A\u5E2F\u898B\u308B\u4F59\u88D5\u7121\u3044\u3057\u5927\u4E08\u592B\u304B\u306A\u3002",
  "id" : 62775616801476608,
  "created_at" : "2011-04-26 07:10:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62775483942711297",
  "text" : "\u30D0\u30C3\u30C6\u30EA\u30FC\u3042\u3068\uFF14\u5272\u304B\u30FC\u3002\u6301\u3064\u304B\u306A\u30FC\uFF1F\u4E00\u6642\u5E30\u5B85\u3057\u305F\u3068\u304D\u5145\u96FB\u3057\u3068\u304D\u3083\u3042\u3088\u304B\u3063\u305F",
  "id" : 62775483942711297,
  "created_at" : "2011-04-26 07:10:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62775140936728576",
  "text" : "\u6905\u5B50\u51B7\u3066\u3047\u2026@\u5171\u5317",
  "id" : 62775140936728576,
  "created_at" : "2011-04-26 07:08:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62693519743131648",
  "text" : "\u4ECA\u65E5\u306F\u30C1\u30A7\u30EB\u30CE\u30D6\u30A4\u30EA\u304B\u3089\uFF12\uFF15\u5E74\u306A\u306E\u304B",
  "id" : 62693519743131648,
  "created_at" : "2011-04-26 01:44:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62690218133827584",
  "text" : "\u30A2\u30AB\u30C7\u30DF\u30C3\u30AF\u30D5\u30A3\u30D5\u30C6\u30A3\u3067\u3082\u3044\u3044\u306A\u30FC",
  "id" : 62690218133827584,
  "created_at" : "2011-04-26 01:31:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62690039074783232",
  "text" : "\u30A2\u30AB\u30C7\u30DF\u30C3\u30AF\u30D5\u30A3\u30D5\u30C6\u30A3\u30FC\u30F3\u2026",
  "id" : 62690039074783232,
  "created_at" : "2011-04-26 01:30:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62687810305531904",
  "geo" : { },
  "id_str" : "62688423303069696",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u2026\u304A\u3081\uFF1F",
  "id" : 62688423303069696,
  "in_reply_to_status_id" : 62687810305531904,
  "created_at" : "2011-04-26 01:24:19 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62667775415558144",
  "geo" : { },
  "id_str" : "62667948166361089",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u58F0\u304C\u5C0F\u3055\u3044\uFF01\u3082\u3046\u4E00\u5EA6\uFF01",
  "id" : 62667948166361089,
  "in_reply_to_status_id" : 62667775415558144,
  "created_at" : "2011-04-26 00:02:57 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62667658176372736",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 62667658176372736,
  "created_at" : "2011-04-26 00:01:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62667290457554944",
  "text" : "\u5BD2\u3044\u3002\u5E03\u56E3\u304C\u96E2\u3057\u3066\u304F\u308C\u306A\u3044\u30EC\u30D9\u30EB\u3002",
  "id" : 62667290457554944,
  "created_at" : "2011-04-26 00:00:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "indices" : [ 3, 12 ],
      "id_str" : "119635653",
      "id" : 119635653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62549304950267904",
  "text" : "RT @nanjolno: \u5916\u98DF\u306F\u7F8E\u5473\u3057\u3044\u3051\u3069\u3001\u7D9A\u304F\u3068\u306A\u3093\u304B\u5473\u6C17\u306A\u304F\u306A\u3063\u3066\u304F\u308B\u3093\u3067\u3059\u3088\u306D\u3002\u3002\u5143\u6C17\u3082\u6E1B\u3063\u3066\u304F\u308B\u3057\u2025\u3002\u304D\u3063\u3068\u304A\u4ED5\u4E8B\u3067\u4F5C\u308B\u304B\u305D\u3046\u3067\u306A\u3044\u304B\u306E\u9055\u3044\u3060\u3068\u601D\u3046\u3093\u3067\u3059\u3051\u3069\u3002\u3042\u3093\u307E\u81EA\u708A\u3057\u306A\u3044\u3051\u3069\u3001\u305F\u307E\u306B\u3059\u308B\u3068\u3084\u3063\u3071\u826F\u3044\u306D\u2025\uFF01\u7D9A\u3051\u3089\u308C\u308B\u4EBA\u306F\u3059\u3054\u3044\u5C0A\u656C\u3059\u308B\u3002\u3064\u3044\u3064\u3044\u5916\u98DF\u3068\u304B\u30B3\u30F3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62549021641801728",
    "text" : "\u5916\u98DF\u306F\u7F8E\u5473\u3057\u3044\u3051\u3069\u3001\u7D9A\u304F\u3068\u306A\u3093\u304B\u5473\u6C17\u306A\u304F\u306A\u3063\u3066\u304F\u308B\u3093\u3067\u3059\u3088\u306D\u3002\u3002\u5143\u6C17\u3082\u6E1B\u3063\u3066\u304F\u308B\u3057\u2025\u3002\u304D\u3063\u3068\u304A\u4ED5\u4E8B\u3067\u4F5C\u308B\u304B\u305D\u3046\u3067\u306A\u3044\u304B\u306E\u9055\u3044\u3060\u3068\u601D\u3046\u3093\u3067\u3059\u3051\u3069\u3002\u3042\u3093\u307E\u81EA\u708A\u3057\u306A\u3044\u3051\u3069\u3001\u305F\u307E\u306B\u3059\u308B\u3068\u3084\u3063\u3071\u826F\u3044\u306D\u2025\uFF01\u7D9A\u3051\u3089\u308C\u308B\u4EBA\u306F\u3059\u3054\u3044\u5C0A\u656C\u3059\u308B\u3002\u3064\u3044\u3064\u3044\u5916\u98DF\u3068\u304B\u30B3\u30F3\u30D3\u30CB\u3067\u6E08\u307E\u305B\u3061\u3083\u3046\u3051\u3069\u3001\u7D9A\u304F\u3068\u99C4\u76EE\u306D",
    "id" : 62549021641801728,
    "created_at" : "2011-04-25 16:10:23 +0000",
    "user" : {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "protected" : false,
      "id_str" : "119635653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590128712906977281\/lWxpoTSQ_normal.jpg",
      "id" : 119635653,
      "verified" : true
    }
  },
  "id" : 62549304950267904,
  "created_at" : "2011-04-25 16:11:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62549087148457984",
  "text" : "\u6628\u65E5\u304B\u3089\u4ECA\u65E5\u306B\u304B\u3051\u3066\u306F\u3042\u3093\u307E\uFF34\uFF2C\u8FFD\u3048\u3066\u306A\u304B\u3063\u305F\u306A\u30FC\u3001\u304A\u4F11\u307F\u306A\u3055\u3044\u3002\u5FC3\u5730\u597D\u3044\u5922\u3092\u3002",
  "id" : 62549087148457984,
  "created_at" : "2011-04-25 16:10:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 0, 9 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62512077398478848",
  "in_reply_to_user_id" : 187163335,
  "text" : "@bukuburi \u3069\u306E\u89E3\u653E\u3082\u534A\u5206\u304F\u3089\u3044\u307E\u3067\u306F\u601D\u3044\u3064\u3044\u3066\u3044\u305F\u3060\u3051\u306B\u89E3\u3051\u306A\u304F\u3066\u6094\u3057\u304B\u3063\u305F\u3067\u3059(\uFF1E\uFF1C)\u6F38\u5316\u5F0F\u3082\u5834\u5408\u5206\u3051\u3082\u8A70\u3081\u304C\u7518\u304B\u3063\u305F\u3067\u3059\u2026\u3002\u53CD\u7701\u3002",
  "id" : 62512077398478848,
  "created_at" : "2011-04-25 13:43:35 +0000",
  "in_reply_to_screen_name" : "bukuburi",
  "in_reply_to_user_id_str" : "187163335",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62508933956382720",
  "geo" : { },
  "id_str" : "62509737572450304",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u82E5\u5E72\u9060\u3044\u304B\u3089\u7533\u3057\u8A33\u306A\u3044\u3093\u3060\u3051\u3069\u306D\u30FC\u3002\u307E\u3041\u305F\u3060\u98EF\u3060\u3057\u304A\u3044\u3067\uFF57",
  "id" : 62509737572450304,
  "in_reply_to_status_id" : 62508933956382720,
  "created_at" : "2011-04-25 13:34:17 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62507816912564226",
  "geo" : { },
  "id_str" : "62508601587138560",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u663C\u3054\u98EF\u98DF\u3079\u306B\u6765\u306A\u3044\uFF1F\uFF57\u4F5C\u308A\u3059\u304E\u305F\uFF57",
  "id" : 62508601587138560,
  "in_reply_to_status_id" : 62507816912564226,
  "created_at" : "2011-04-25 13:29:46 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62506938398810112",
  "geo" : { },
  "id_str" : "62507593993699329",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u660E\u65E5\uFF13\u9650\u3042\u308B\uFF1F",
  "id" : 62507593993699329,
  "in_reply_to_status_id" : 62506938398810112,
  "created_at" : "2011-04-25 13:25:46 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "indices" : [ 3, 18 ],
      "id_str" : "158991353",
      "id" : 158991353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62506513138331648",
  "text" : "RT @sorayama_asobi: \u300C\u6570\u5B66\u3063\u3066\u306A\u3093\u3067\u52C9\u5F37\u3057\u306A\u3044\u3068\u3044\u3051\u306A\u3044\u306E\uFF1F\u5C06\u6765\u5F79\u306B\u7ACB\u3064\u304B\u308F\u304B\u3093\u306A\u3044\u306E\u306B\u300D\u3068\u304B\u8A00\u3063\u3066\u304D\u305F\u751F\u5F92\u306B\u306F\u300C\u304A\u524D\u3063\u3066\u306A\u3093\u3067\u751F\u304D\u3066\u308B\u306E\uFF1F\u5C06\u6765\u5F79\u306B\u7ACB\u3064\u304B\u308F\u304B\u3093\u306A\u3044\u306E\u306B\u300D\u3063\u3066\u8A00\u3063\u3066\u3084\u308A\u305F\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62504865481498624",
    "text" : "\u300C\u6570\u5B66\u3063\u3066\u306A\u3093\u3067\u52C9\u5F37\u3057\u306A\u3044\u3068\u3044\u3051\u306A\u3044\u306E\uFF1F\u5C06\u6765\u5F79\u306B\u7ACB\u3064\u304B\u308F\u304B\u3093\u306A\u3044\u306E\u306B\u300D\u3068\u304B\u8A00\u3063\u3066\u304D\u305F\u751F\u5F92\u306B\u306F\u300C\u304A\u524D\u3063\u3066\u306A\u3093\u3067\u751F\u304D\u3066\u308B\u306E\uFF1F\u5C06\u6765\u5F79\u306B\u7ACB\u3064\u304B\u308F\u304B\u3093\u306A\u3044\u306E\u306B\u300D\u3063\u3066\u8A00\u3063\u3066\u3084\u308A\u305F\u3044",
    "id" : 62504865481498624,
    "created_at" : "2011-04-25 13:14:55 +0000",
    "user" : {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "protected" : false,
      "id_str" : "158991353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1864231491\/totoro_t_normal.jpg",
      "id" : 158991353,
      "verified" : false
    }
  },
  "id" : 62506513138331648,
  "created_at" : "2011-04-25 13:21:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62495465433858048",
  "text" : "\u5727\u629C\u3044\u3066\u308B\u6642\u306E\u3053\u306E\u4F55\u3068\u3082\u8A00\u3048\u306A\u3044\u97F3\u306F\u8E0F\u5207\u306E\u4E0D\u5354\u548C\u97F3\u306B\u4F3C\u3066\u306A\u3093\u304B\u4E0D\u5B89\u3092\u717D\u308B\u30FB\u30FB\u30FB\u6C17\u304C\u3059\u308B\u3002",
  "id" : 62495465433858048,
  "created_at" : "2011-04-25 12:37:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62494004813631488",
  "text" : "\u5727\u529B\u9003\u304C\u3057\u3066\u308B\u306A\u3046\u30FC\u3002\u629C\u3051\u305F\u3089\u3058\u3083\u304C\u3044\u3082\u3068\u7389\u306D\u304E\u3092\u5225\u3067\u52A0\u5727\u3057\u3088\u3046\u3002\uFF08\u4E00\u56DE\u3067\u52A0\u5727\u3067\u304D\u306A\u91CF\u4F5C\u3063\u3066\u3069\u3046\u3059\u308B\u306E\u3060\u308D\u3046\uFF09",
  "id" : 62494004813631488,
  "created_at" : "2011-04-25 12:31:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62493763712454656",
  "text" : "\u307E\u3041\u6625\u30AD\u30E3\u30D9\u30C4\u3001\u65B0\u7389\u306D\u304E\u3001\u3057\u3093\u3058\u3083\u304C\u3001\u4E5D\u6761\u30CD\u30AE\u3001\u4F7F\u3063\u3066\u30E2\u30C4\u716E\u8FBC\u307F\u4F5C\u3063\u3066\u307E\u305A\u304F\u306A\u3063\u305F\u3089\u304A\u304B\u3057\u3044\u306E\u306F\u4E16\u754C\u306E\u65B9(\uFF77\uFF98\uFF6F",
  "id" : 62493763712454656,
  "created_at" : "2011-04-25 12:30:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62493456630677504",
  "text" : "\u4E0B\u5BBF\u3092\u59CB\u3081\u3066\u4E00\u5E74\u5F31\u3001\u6700\u9AD8\u306E\u6599\u7406\u304C\u3067\u304D\u305D\u3046\u306A\u6C17\u304C\u3059\u308B\u3002",
  "id" : 62493456630677504,
  "created_at" : "2011-04-25 12:29:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62453537711456256",
  "text" : "\u611A\u75F4\u611A\u75F4\u8A00\u3046\u306E\u306F\u5ACC\u3044\u3060\u3051\u308C\u3069\u3001\u3055\u3059\u304C\u306B\u4ED8\u304D\u5408\u3044\u304D\u308C\u307E\u305B\u3093\u3002\u4EE5\u4E0A\uFF01",
  "id" : 62453537711456256,
  "created_at" : "2011-04-25 09:50:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62452900726718464",
  "text" : "\u51FA\u304B\u3051\u306A\u304F\u3066\u826F\u304F\u306A\u3063\u305F\u3002\u3051\u3069\u30D0\u30A4\u30C8\u30C9\u30BF\u30AD\u30E3\u30F3\u591A\u904E\u304E\u3001\u3055\u3059\u304C\u306B\u3061\u3087\u3063\u3068\u30A4\u30E9\u30A4\u30E9\u3002",
  "id" : 62452900726718464,
  "created_at" : "2011-04-25 09:48:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62449848196153344",
  "text" : "@haru_urah_rah \u6C17\u6301\u3061\u3044\u3044\u304F\u3089\u3044\u306E\u6B63\u8AD6\u3063\u3066\u6982\u3057\u3066\u6C17\u6301\u3061\u60AA\u304C\u3089\u308C\u307E\u3059\u3088\u306D\u3002\u8B70\u8AD6\u3068\u55A7\u5629\u304C\u3054\u3063\u3061\u3083\u306B\u306A\u3063\u3066\u308B\u4EBA\u3082\u3061\u3089\u307B\u3089\u3002",
  "id" : 62449848196153344,
  "created_at" : "2011-04-25 09:36:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62447876810354688",
  "geo" : { },
  "id_str" : "62449249786400768",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3082\u3057\u3083\u3082\u3057\u3083",
  "id" : 62449249786400768,
  "in_reply_to_status_id" : 62447876810354688,
  "created_at" : "2011-04-25 09:33:56 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62447919495782400",
  "text" : "\u5E30\u5B85\u3002\u3067\u3082\u307E\u305F\uFF12\uFF5E\uFF13\uFF10\u5206\u51FA\u306A\u3044\u3068\u3002\uFF15\u9650\u3042\u308B\u3068\u5348\u5F8C\u77ED\u3057\u3002",
  "id" : 62447919495782400,
  "created_at" : "2011-04-25 09:28:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "indices" : [ 3, 15 ],
      "id_str" : "258721812",
      "id" : 258721812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62391099934769152",
  "text" : "RT @MyMathCloud: Old mathematicians never die; they just lose some of their functions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62390932103901184",
    "text" : "Old mathematicians never die; they just lose some of their functions.",
    "id" : 62390932103901184,
    "created_at" : "2011-04-25 05:42:12 +0000",
    "user" : {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "protected" : false,
      "id_str" : "258721812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2965777663\/5bb5d3206072ca9112470f291e368645_normal.png",
      "id" : 258721812,
      "verified" : false
    }
  },
  "id" : 62391099934769152,
  "created_at" : "2011-04-25 05:42:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62367459864354817",
  "text" : "\u96E8\u3001\u96F7\u3001\u5F37\u98A8\u3001\u7A93\u8FBA\u306B\u3066\u3002  \u5E30\u308A\u307E\u3067\u306B\u6B62\u307E\u306A\u3044\u3068\u56F0\u308B\u306A\u30FC",
  "id" : 62367459864354817,
  "created_at" : "2011-04-25 04:08:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62363953375883264",
  "text" : "\u30E9\u30A6\u30F3\u30B8\u7A93\u969B\u306A\u3089\u96FB\u6CE2\u307E\u3068\u3082\u306D\u3002\uFF13\u9650\u5229\u7528\u3057\u3066\u30D5\u30E9\u8A9E\u7247\u4ED8\u3051\u3088\u3046\u3063\u3068\u3002",
  "id" : 62363953375883264,
  "created_at" : "2011-04-25 03:54:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62361348041998337",
  "text" : "\u304A\u663C\u3067\u820C\u706B\u50B7\u3057\u305F\u304B\u3082\u30FC\u3002",
  "id" : 62361348041998337,
  "created_at" : "2011-04-25 03:44:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62361161437429761",
  "text" : "\u30D3\u30E9\u304C\u8FF7\u5B50\u306B\u306A\u3063\u3066\u307E\u30FC\u3059\u3002\uFF12\uFF10\u679A\u3061\u3087\u3044\u3057\u304B\u7121\u3044\u3082\u3093\u306D(\u00B4\u0414`)",
  "id" : 62361161437429761,
  "created_at" : "2011-04-25 03:43:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3083\u3093\u3075",
      "screen_name" : "nyamph_pf",
      "indices" : [ 3, 13 ],
      "id_str" : "107723928",
      "id" : 107723928
    }, {
      "name" : "\u308C\u3044@\u65B0M1",
      "screen_name" : "rei_vn",
      "indices" : [ 26, 33 ],
      "id_str" : "91373133",
      "id" : 91373133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62360905127694336",
  "text" : "RT @nyamph_pf: \u4EAC\u5927\u751F\u306F3\/1 RT @rei_vn: \u300C\u6771\u5927\u751F\u306E1\/3\u306F\u982D\u304A\u304B\u3057\u3044\u300D\u3068\u3044\u3046\u540D\u8A00\u304C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u308C\u3044@\u65B0M1",
        "screen_name" : "rei_vn",
        "indices" : [ 11, 18 ],
        "id_str" : "91373133",
        "id" : 91373133
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62352169516531713",
    "text" : "\u4EAC\u5927\u751F\u306F3\/1 RT @rei_vn: \u300C\u6771\u5927\u751F\u306E1\/3\u306F\u982D\u304A\u304B\u3057\u3044\u300D\u3068\u3044\u3046\u540D\u8A00\u304C",
    "id" : 62352169516531713,
    "created_at" : "2011-04-25 03:08:10 +0000",
    "user" : {
      "name" : "\u306B\u3083\u3093\u3075",
      "screen_name" : "nyamph_pf",
      "protected" : false,
      "id_str" : "107723928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569217172480606208\/M7UhW7u3_normal.png",
      "id" : 107723928,
      "verified" : false
    }
  },
  "id" : 62360905127694336,
  "created_at" : "2011-04-25 03:42:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62355081189801984",
  "text" : "\u3053\u306E\u643A\u5E2F\uFF12\u5E74\u306B\u306A\u3063\u305F\u3089\uFF49\uFF30\uFF48\uFF4F\uFF4E\uFF45\u306B\u3057\u3088\u3046\u304B\u306A\u30FC",
  "id" : 62355081189801984,
  "created_at" : "2011-04-25 03:19:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62354783205457920",
  "text" : "RT @wwwwww_bot: \u731B\u53CD\u767A\u307E\u304F\u3089",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62354642406875136",
    "text" : "\u731B\u53CD\u767A\u307E\u304F\u3089",
    "id" : 62354642406875136,
    "created_at" : "2011-04-25 03:17:59 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 62354783205457920,
  "created_at" : "2011-04-25 03:18:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62354742059335680",
  "text" : "\u3063\u3066\u3082\uFF15\u9650\u5F8C\u30D0\u30A4\u30C8\u3042\u308B\u304B\u3089\u305A\u3044\u3076\u3093\u5148\u304B\u3002",
  "id" : 62354742059335680,
  "created_at" : "2011-04-25 03:18:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62354580922572800",
  "text" : "\u501F\u308A\u305F\u306F\u3044\u3044\u304C\u4F7F\u3044\u65B9\u304C\u3044\u307E\u3072\u3068\u3064\u308F\u304B\u3093\u306A\u3044\u3084\u3002\u5BB6\u5E30\u3063\u305F\u3089\u30CD\u30C3\u30C8\u306B\u7E4B\u3044\u3067\u5F04\u3063\u3066\u307F\u3088\u3046\u3002",
  "id" : 62354580922572800,
  "created_at" : "2011-04-25 03:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62353620460515328",
  "text" : "\u7A7A\u8179\u3067\u8179\u75DB\u3060\u3063\u305F\u304C\u30CB\u9650\u3067iPod touch\u501F\u308A\u305F\u3002",
  "id" : 62353620460515328,
  "created_at" : "2011-04-25 03:13:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62307831939989504",
  "text" : "\u3053\u3063\u3061\u306F\u4E00\u5FDC\u6674\u308C\u9593\u304C\u898B\u3048\u305F\u3002\u9045\u308C\u3070\u305B\u306A\u304C\u3089\u51FA\u304B\u3051\u307E\u3059\u3002",
  "id" : 62307831939989504,
  "created_at" : "2011-04-25 00:11:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62306979380596737",
  "text" : "\u96E8\u964D\u308B\u5EA6\u306B\u8ECA\u3067\u52D5\u3051\u305F\u3089\u697D\u306A\u306E\u306B\u3001\u3068\u601D\u3046\u3002\u30DE\u30A4\u30AB\u30FC\u901A\u5B66\u7981\u6B62\u3060\u3057\u305D\u3093\u306A\u304A\u91D1\u306F\u306A\u3044\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 62306979380596737,
  "created_at" : "2011-04-25 00:08:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62306721217003521",
  "text" : "\u4E2D\u83EF\u8857\u3067\u8089\u307E\u3093\u98DF\u3079\u305F\u3044\u306A\u30FC\u3002\u6A2A\u6D5C\u3061\u3087\u3063\u3068\u4EAC\u90FD\u99C5\u304F\u3089\u3044\u307E\u3067\u6765\u3066\u304F\u308C\u306A\u3044\u304B\u306A\u30FC\u3002",
  "id" : 62306721217003521,
  "created_at" : "2011-04-25 00:07:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62305789540433920",
  "geo" : { },
  "id_str" : "62306125973950464",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3072\u3087\u3046\u3067\u3059\u304B\u305D\u3046\u3067\u3059\u304B\u3002\u3069\u3053\u306B\u3044\u308B\u306E\uFF1F",
  "id" : 62306125973950464,
  "in_reply_to_status_id" : 62305789540433920,
  "created_at" : "2011-04-25 00:05:12 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62304091824594944",
  "text" : "\u660E\u308B\u304F\u306A\u3063\u3066\u304D\u305F\u2026\u3042\u3068\uFF11\uFF10\u5206\u7D4C\u3063\u3066\u982D\u4E0A\u53CA\u3073\u98A8\u4E0A\u306B\u96F2\u304C\u8A8D\u3081\u3089\u308C\u306A\u304B\u3063\u305F\u3089\u51FA\u304B\u3051\u308B\u3068\u3057\u3088\u3046\u3002",
  "id" : 62304091824594944,
  "created_at" : "2011-04-24 23:57:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62303694967934976",
  "text" : "RT @wwwwww_bot: \u30A2\u30B3\u30AE\u306E\u5F26\u5F35\u308A\u66FF\u3048 \u2192\u53E4\u3044\u5F26\u3092\u5916\u3057\u3066\u6307\u677F\u306A\u3069\u6E05\u6383 \u2192\u30C8\u30A4\u30EC\u306B\u884C\u304F\u2192\u65B0\u3057\u3044\u5F26\u3092\u5F35\u308B\u2192\u97F3\u3092\u51FA\u3057\u305F\u3089\u30AE\u30BF\u30FC\u304B\u3089\u300C\u306B\u3083\u30FC\uFF01\u300D\u2192\u30B5\u30A6\u30F3\u30C9\u30DB\u30FC\u30EB\u306E\u4E2D\u304B\u3089\u3053\u3093\u306A\u72B6\u614B\u3067\u732B\u30CF\u30B1\u30FC\u30F3\u3000||\u03A6|(|\u00B4|\u0414|`|)|\u03A6|| \u2192\u3000\uFF3F|\uFFE3|\u25CB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62301704976211968",
    "text" : "\u30A2\u30B3\u30AE\u306E\u5F26\u5F35\u308A\u66FF\u3048 \u2192\u53E4\u3044\u5F26\u3092\u5916\u3057\u3066\u6307\u677F\u306A\u3069\u6E05\u6383 \u2192\u30C8\u30A4\u30EC\u306B\u884C\u304F\u2192\u65B0\u3057\u3044\u5F26\u3092\u5F35\u308B\u2192\u97F3\u3092\u51FA\u3057\u305F\u3089\u30AE\u30BF\u30FC\u304B\u3089\u300C\u306B\u3083\u30FC\uFF01\u300D\u2192\u30B5\u30A6\u30F3\u30C9\u30DB\u30FC\u30EB\u306E\u4E2D\u304B\u3089\u3053\u3093\u306A\u72B6\u614B\u3067\u732B\u30CF\u30B1\u30FC\u30F3\u3000||\u03A6|(|\u00B4|\u0414|`|)|\u03A6|| \u2192\u3000\uFF3F|\uFFE3|\u25CB",
    "id" : 62301704976211968,
    "created_at" : "2011-04-24 23:47:38 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 62303694967934976,
  "created_at" : "2011-04-24 23:55:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62301609325113345",
  "text" : "\u3053\u3053\u6570\u65E5\u5929\u6C17\u3082\u5927\u6C17\u3082\u4E0D\u5B89\u5B9A\u307F\u305F\u3044\u3060\u306D\u30FC\u3002\u53BB\u5E74\u3053\u306E\u6642\u671F\u3053\u3053\u307E\u3067\u8352\u308C\u3066\u306A\u304B\u3063\u305F\u3068\u601D\u3046\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 62301609325113345,
  "created_at" : "2011-04-24 23:47:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62301288335020032",
  "text" : "\u69D8\u5B50\u898B\u3066\u6B62\u3093\u3060\u3089\u884C\u304D\u305F\u3044\u3093\u3060\u3051\u3069\u306A\u3041\u3002\u3053\u308C\u306A\u3089\u5927\u4EBA\u3057\u304F\u5BDD\u574A\u3057\u3068\u3051\u3070\u826F\u304B\u3063\u305F\u304B\u306A\uFF08\uFF1F)",
  "id" : 62301288335020032,
  "created_at" : "2011-04-24 23:45:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62301030842511360",
  "text" : "\u5929\u6C17\u4E88\u5831\u3081\u3002\u9069\u5F53\u306A\u3053\u3068\u8A00\u3046\u306A\u3088\u30FC\u3002\u6628\u591C\u306F\u6674\u308C\u306E\u30DE\u30FC\u30AF\u3060\u3063\u305F\u306E\u306B\u96F7\u9CF4\u3063\u3066\u308B\u2026\u3002\u4E00\u9650\u884C\u3051\u306A\u3044\u3058\u3083\u3093\u2190",
  "id" : 62301030842511360,
  "created_at" : "2011-04-24 23:44:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62295094535000064",
  "text" : "\u5BDD\u574A\u2026\u304B\u306A\uFF1F\u4E00\u9650\u30AE\u30EA\u30AE\u30EA\u3060\u306A\u30FC\u3002\u5317\u90E8\u3060\u304B\u3089\u9593\u306B\u5408\u3046\uFF1F",
  "id" : 62295094535000064,
  "created_at" : "2011-04-24 23:21:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62192776086953984",
  "text" : "\u4ECA\u5EA6\u3053\u305D\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 62192776086953984,
  "created_at" : "2011-04-24 16:34:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62188984759095296",
  "text" : "\u4ECA\u65E5\u4E00\u9650\u3060\u3057\u305D\u308D\u305D\u308D\u5BDD\u307E\u3059\u3002\uFF08\u2190\u3068\u8A00\u3044\u3064\u3064\u3044\u3064\u3082\u3082\u3046\u5C11\u3057\u5F35\u308A\u4ED8\u3044\u3066\u3057\u307E\u3046\uFF09",
  "id" : 62188984759095296,
  "created_at" : "2011-04-24 16:19:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62188218279411713",
  "text" : "\u4F8B\u306E\u78BA\u7387\u8003\u3048\u3066\u3044\u305F\u3089\u3053\u3093\u306A\u6642\u9593\u3002\u7B54\u3048\u3089\u3057\u304D\u3082\u306E\u306F\u51FA\u305F\u3051\u3069\u78BA\u8A3C\u304C\u6301\u3066\u306A\u3044\u3002\u767A\u8868\u5F85\u3061\u304B\u306A\u30FC\u3002",
  "id" : 62188218279411713,
  "created_at" : "2011-04-24 16:16:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62187853530144768",
  "text" : "\u4E00\u9650\u306A\u3093\u3060\u3051\u3069\u306A\u30FC\u3001\u5BDD\u306A\u304D\u3083\u306A\u30FC\u3002",
  "id" : 62187853530144768,
  "created_at" : "2011-04-24 16:15:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62185004096163840",
  "geo" : { },
  "id_str" : "62185173608968192",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u308C\u3063\u3066\u5F7C\u5973\u3063\u3066\u547C\u3076\u3093\u3060\u305C\uFF57\uFF57\uFF57\uFF57",
  "id" : 62185173608968192,
  "in_reply_to_status_id" : 62185004096163840,
  "created_at" : "2011-04-24 16:04:35 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62184627149869056",
  "geo" : { },
  "id_str" : "62184771941441536",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306A\u306B\u305D\u308C\u30FC\u3001\u5973\u53CB\u9054\u3067\u3082\u306A\u3044\u308F\u3051\u30FC\uFF1F",
  "id" : 62184771941441536,
  "in_reply_to_status_id" : 62184627149869056,
  "created_at" : "2011-04-24 16:02:59 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62161366101917696",
  "geo" : { },
  "id_str" : "62161739810209792",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math 00101",
  "id" : 62161739810209792,
  "in_reply_to_status_id" : 62161366101917696,
  "created_at" : "2011-04-24 14:31:28 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "indices" : [ 3, 16 ],
      "id_str" : "96289411",
      "id" : 96289411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62147004855353344",
  "text" : "RT @d_v_osorezan: \u30BC\u30A6\u30B9\u304C\u30E1\u30FC\u30EB\u306B\u6DFB\u4ED8\u3057\u3066\u9001\u3063\u3066\u6765\u305F\u300C\u7BB1.zip\u300D\u3092\u3051\u3057\u3066\u89E3\u51CD\u3057\u3066\u306F\u306A\u3089\u306A\u3044\u3068\u8A00\u308F\u308C\u3066\u3044\u305F\u306E\u306B\u3082\u95A2\u308F\u3089\u305A\u3001\u30D1\u30F3\u30C9\u30E9\u306F\u597D\u5947\u5FC3\u306B\u8CA0\u3051\u3066\u89E3\u51CD\u3057\u3066\u3057\u307E\u3046\u3002\u3059\u308B\u3068\u30D5\u30A9\u30EB\u30C0\u304B\u3089\u306F\u30DE\u30EB\u30A6\u30A7\u30A2\u3001\u30C8\u30ED\u30A4\u306E\u6728\u99AC\u3001\u30EF\u30FC\u30E0\u3001\u30B9\u30D1\u30A4\u30A6\u30A7\u30A2\u304C\u4E00\u6589\u306B\u98DB\u3073\u51FA\u3057\u305F\u3002\u304B\u304F\u3057 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62146111732858880",
    "text" : "\u30BC\u30A6\u30B9\u304C\u30E1\u30FC\u30EB\u306B\u6DFB\u4ED8\u3057\u3066\u9001\u3063\u3066\u6765\u305F\u300C\u7BB1.zip\u300D\u3092\u3051\u3057\u3066\u89E3\u51CD\u3057\u3066\u306F\u306A\u3089\u306A\u3044\u3068\u8A00\u308F\u308C\u3066\u3044\u305F\u306E\u306B\u3082\u95A2\u308F\u3089\u305A\u3001\u30D1\u30F3\u30C9\u30E9\u306F\u597D\u5947\u5FC3\u306B\u8CA0\u3051\u3066\u89E3\u51CD\u3057\u3066\u3057\u307E\u3046\u3002\u3059\u308B\u3068\u30D5\u30A9\u30EB\u30C0\u304B\u3089\u306F\u30DE\u30EB\u30A6\u30A7\u30A2\u3001\u30C8\u30ED\u30A4\u306E\u6728\u99AC\u3001\u30EF\u30FC\u30E0\u3001\u30B9\u30D1\u30A4\u30A6\u30A7\u30A2\u304C\u4E00\u6589\u306B\u98DB\u3073\u51FA\u3057\u305F\u3002\u304B\u304F\u3057\u3066\u30CD\u30C3\u30C8\u306B\u306F\u30A6\u30A3\u30EB\u30B9\u304C\u8513\u5EF6\u3063\u305F\u306E\u3067\u3042\u308B\u3002",
    "id" : 62146111732858880,
    "created_at" : "2011-04-24 13:29:22 +0000",
    "user" : {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "protected" : false,
      "id_str" : "96289411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3457427933\/e9c1859b77927509e49bcdd8ea328bdb_normal.jpeg",
      "id" : 96289411,
      "verified" : false
    }
  },
  "id" : 62147004855353344,
  "created_at" : "2011-04-24 13:32:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62146690194485248",
  "text" : "@mo5nya \u8EAB\u9577\u3082\u3067\u3059\u3002\u5927\u304D\u304F\u306A\u3044\u3082\u306E\u3067\uFF3E\uFF3E\uFF1B",
  "id" : 62146690194485248,
  "created_at" : "2011-04-24 13:31:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62145331760087040",
  "text" : "1,\u6016\u304F\u3066\u899A\u3048\u3066\u306A\u3044 2,Sat  3,\u5869 4,\u6B64\u308C\u4F5C\u3063\u305F\u4EBA\u3082\u306D\u3002 end313124\u3055\u3093\u306B\u8CEA\u554F\u3002\uFF11.\u8EAB\u9577\u30FB\u4F53\u91CD 2.\u597D\u304D\u306A\u66DC\u65E5 3.\u597D\u304D\u306A\u30E9\u30FC\u30E1\u30F3\u306E\u5473 4.\u3042\u306A\u305F\u3072\u3087\u3063\u3068\u3057\u3066\u6687\u3067\u3059\u306D\uFF1F http:\/\/shindanmaker.com\/53703",
  "id" : 62145331760087040,
  "created_at" : "2011-04-24 13:26:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62144875218468865",
  "text" : "RT @wwwwww_bot: \u751F\u524D\u60AA\u3044\u884C\u3044\u3092\u3057\u305F\u8005\u306F\u5730\u7344\u306B\u3001\n\u826F\u3044\u884C\u3044\u3092\u3057\u305F\u8005\u306F\u5929\u56FD\u306B\u3001\n\u4E2D\u304F\u3089\u3044\u306E\u884C\u3044\u3092\u3057\u305F\u8005\u306F\u4E2D\u56FD\u306B\u884C\u304F\u3068\u3044\u3046\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62143226676641792",
    "text" : "\u751F\u524D\u60AA\u3044\u884C\u3044\u3092\u3057\u305F\u8005\u306F\u5730\u7344\u306B\u3001\n\u826F\u3044\u884C\u3044\u3092\u3057\u305F\u8005\u306F\u5929\u56FD\u306B\u3001\n\u4E2D\u304F\u3089\u3044\u306E\u884C\u3044\u3092\u3057\u305F\u8005\u306F\u4E2D\u56FD\u306B\u884C\u304F\u3068\u3044\u3046\u3002",
    "id" : 62143226676641792,
    "created_at" : "2011-04-24 13:17:54 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 62144875218468865,
  "created_at" : "2011-04-24 13:24:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yhenkantter",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62114709427589120",
  "text" : "\u5E0C\u5C11\u4FA1\u5024 \u4EBA \u7406\u7CFB  end313124\u306F\u300E\u304D\u300F\u300E\u3072\u300F\u300E\u308A\u300F\u306E\u4E88\u6E2C\u5909\u63DB\u3092\u6652\u3057\u307E\u3057\u3087\u3046 http:\/\/shindanmaker.com\/54292 #yhenkantter",
  "id" : 62114709427589120,
  "created_at" : "2011-04-24 11:24:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62100059562573824",
  "text" : "\u30DA\u30F3\u30CD\u3067\u30B9\u30FC\u30D7\u30D1\u30B9\u30BF\u306A\u3046\u3002\u30D1\u30F3\u304C\u6B32\u3057\u3044\u306A\u3002",
  "id" : 62100059562573824,
  "created_at" : "2011-04-24 10:26:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62063606807801856",
  "text" : "\u7D42\u308F\u3089\u306A\u304B\u3063\u305F\u3002\u5F8C30\u5206\u30A1\uFF01",
  "id" : 62063606807801856,
  "created_at" : "2011-04-24 08:01:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DB\u30EA\u30A3\u30FB\u30BB\u30F3\uFF08\u30B5\u30FC\u30AF\u30E9\u4F1A\u9577\uFF09",
      "screen_name" : "holysen",
      "indices" : [ 37, 45 ],
      "id_str" : "119406614",
      "id" : 119406614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62054873516093441",
  "text" : "\u805E\u3044\u3066\u306F\u3044\u305F\u3051\u3069\u3053\u308C\u306F\u3072\u3069\u3044\u2026RT @kouennnoyuugu: RT @holysen: \u4ECA\u5E74\u306E\u7406\u5B66\u90E8\u65B0\u6B53\u518A\u5B50\uFF62\u4FFA\u306E\u3068\u3042\u308B\u7406\u5B66\u304C\u3053\u3093\u306A\u306B\u73FE\u5B9F\u5145\u8DB3\u306A\u308F\u3051\u3058\u3083\u306A\u3044\u3093\u3060\u304B\u3089\u306D\u3063!! \uFF5E\u50D5\u3068\u5951\u7D04\u3057\u3066\u975E\u30EA\u30A2\u306B\u306A\u3063\u3066\u5927\u4E08\u592B\u304B\uFF1F\uFF5E\uFF63\u306E\u8868\u7D19 http:\/\/twitpic.com\/4hz91r",
  "id" : 62054873516093441,
  "created_at" : "2011-04-24 07:26:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62048401214287872",
  "text" : "\u96C6\u4E2D\u5207\u308C\u305F\u30FC\u3002\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u6C17\u5206\u8EE2\u63DB\u3057\u3088\u3046\u3002\u76EE\u6A19\u306F17\u6642\u3002",
  "id" : 62048401214287872,
  "created_at" : "2011-04-24 07:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62020504034344960",
  "text" : "\u3055\u3041\u7D50\u5C40\u6628\u65E5\u3084\u308C\u306A\u304B\u3063\u305F\uFF08\u3084\u3089\u306A\u304B\u3063\u305F\uFF09\u82F1\u8A9E\u306E\u8AB2\u984C\u3092\u7247\u4ED8\u3051\u3088\u3046\u3002",
  "id" : 62020504034344960,
  "created_at" : "2011-04-24 05:10:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61815458533351424",
  "geo" : { },
  "id_str" : "61817191166775296",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6B63\u76F4\u95A2\u897F\u570F\u306E\u9032\u5B66\u6821\u5168\u90E8\u7206\u767A\u3057\u308D\u3068\u601D\u3063\u3066\u307E\u3057\u305F\u3002\u3054\u3081\u3093\u306A\u3055\u3044\u3002",
  "id" : 61817191166775296,
  "in_reply_to_status_id" : 61815458533351424,
  "created_at" : "2011-04-23 15:42:21 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61812788116459520",
  "text" : "\u53CB\u4EBA\u3068\u306E\u30C1\u30E3\u30C3\u30C8\n\u81EA\u5206\u300C\uFF4B\uFF1F\u300D\uFF08\u643A\u5E2F\u3067\u306E\u30ED\u30B0\u30A4\u30F3\uFF1F\u306E\u610F\uFF09\n\u53CB\u4EBA\u300C\uFF4C\u300D\n\u81EA\u5206\u300C\u30A2\u30A4\uFF1F\u30A8\u30EB\uFF1F\u300D\n\u53CB\u4EBA\u300C\uFF4B\u306E\u6B21\u306F\u306A\u3093\u3067\u3057\u3087\u3046\u304B\u300D\n\u81EA\u5206\u300C\uFF4B\uFF0B\uFF11\u3060\u308D\u300D",
  "id" : 61812788116459520,
  "created_at" : "2011-04-23 15:24:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61809325143887872",
  "geo" : { },
  "id_str" : "61810289879949312",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u51FA\u9858\u3057\u305F\u305C\u30FC\u3063\u3066\u3044\u3046\u305F\u3081\u306B\u51FA\u9858\u3057\u305F\u3089\u3057\u3044\uFF57\u7D4C\u6E08\u8AD6\u6587\u578B\u3002\u3061\u306A\u307F\u306B\u4ECA\u305D\u3044\u3064\u8D77\u696D\u3057\u3066\u666E\u901A\u3058\u3083\u306A\u3044\u793E\u4F1A\u4EBA\u3084\u3063\u3066\u308B\u3002",
  "id" : 61810289879949312,
  "in_reply_to_status_id" : 61809325143887872,
  "created_at" : "2011-04-23 15:14:56 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61808486618636289",
  "geo" : { },
  "id_str" : "61809226514837506",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u52E2\u3044\u3067\u4EAC\u5927\u306B\u51FA\u9858\u3057\u3066\u53D7\u3051\u306B\u6765\u306A\u304B\u3063\u305F\u77E5\u308A\u5408\u3044\u306A\u3089\u3044\u308B\u3002",
  "id" : 61809226514837506,
  "in_reply_to_status_id" : 61808486618636289,
  "created_at" : "2011-04-23 15:10:42 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61807273130995712",
  "geo" : { },
  "id_str" : "61808200776822784",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u76DB\u5927\u306A\u8AE6\u3081 \u304B \u81F4\u547D\u7684\u306A\u5BDD\u574A",
  "id" : 61808200776822784,
  "in_reply_to_status_id" : 61807273130995712,
  "created_at" : "2011-04-23 15:06:38 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61795608175976448",
  "text" : "@haru_urah_rah \u305D\u306E\u3042\u305F\u308A\u3092\u697D\u3057\u3081\u308B\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u65B9\u304C\u7D20\u6570\u3067\u3059\u3001\uFF08\u3068\u601D\u3046\u7537\u306E\u5B50\u3082\u5909\u308F\u3063\u3066\u308B\u306E\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u304C\uFF09",
  "id" : 61795608175976448,
  "created_at" : "2011-04-23 14:16:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61792345263308800",
  "geo" : { },
  "id_str" : "61793373060734976",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E00\u5DFB\u3060\u3063\u305F\u3089\u304B\u306A\u308A\u8AAD\u307F\u3084\u3059\u3044\u3068\u601D\u3046\u3002\u6700\u901F\u3067\u6708\u66DC\u306B\u6301\u3063\u3066\u3044\u3051\u308B\u3051\u3069\u3002",
  "id" : 61793373060734976,
  "in_reply_to_status_id" : 61792345263308800,
  "created_at" : "2011-04-23 14:07:42 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61791469639450624",
  "geo" : { },
  "id_str" : "61792100538257408",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8CB8\u3059\u305C\uFF3E\uFF3E",
  "id" : 61792100538257408,
  "in_reply_to_status_id" : 61791469639450624,
  "created_at" : "2011-04-23 14:02:39 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61783956323962880",
  "geo" : { },
  "id_str" : "61785374313299968",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306B\u305B\u307B\u6848\u5916\u77E5\u3089\u308C\u3066\u306A\u3044\u3088\u306A\u30FC",
  "id" : 61785374313299968,
  "in_reply_to_status_id" : 61783956323962880,
  "created_at" : "2011-04-23 13:35:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61781643446325248",
  "text" : "TL\u306A\u3093\u304B\u4ECA\u306E\u6642\u9593\u9A12\u304C\u3057\u3044\u306A\u3002\u307E\u3041\u4F11\u65E5\u3060\u304B\u3089\uFF1F\u6628\u65E5\u3044\u306A\u304B\u3063\u305F\u304B\u3089\u304B\u3089\u305D\u3046\u611F\u3058\u308B\u3060\u3051\uFF1F",
  "id" : 61781643446325248,
  "created_at" : "2011-04-23 13:21:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61776458862956544",
  "geo" : { },
  "id_str" : "61779645321842688",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3082\u3057\u3083\u3082\u3057\u3083",
  "id" : 61779645321842688,
  "in_reply_to_status_id" : 61776458862956544,
  "created_at" : "2011-04-23 13:13:09 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61755418220838912",
  "text" : "@mo5nya \u597D\u304D\u3067\u3059\u3002\u5927\u597D\u304D\u306A\u306E\u3067\u3059\u304C\u4E0B\u5BBF\u3067\u306F\u98FC\u3048\u306A\u3044\u3093\u3067\u3059\u2026\u3002",
  "id" : 61755418220838912,
  "created_at" : "2011-04-23 11:36:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61747561542860800",
  "text" : "@koketomi \u7B11\u3048\u3070\u3044\u3044\u3068\u601D\u3046\u3088\u3002",
  "id" : 61747561542860800,
  "created_at" : "2011-04-23 11:05:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61730381367476224",
  "text" : "\u306A\u3093\u304B\u6700\u8FD1\u732B\u3068\u304B\u732B\u3068\u304B\u732B\u3068\u304B\u898B\u306A\u3044\u306A\u30FC\u2026\u72AC\u306A\u3089\u6563\u6B69\u3057\u3066\u308B\u4EBA\u305F\u307E\u306B\u3044\u308B\u3051\u3069\u3002",
  "id" : 61730381367476224,
  "created_at" : "2011-04-23 09:57:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61729756978221056",
  "text" : "\u53BB\u5E74\u5F8C\u671F\u9031\u4F11\uFF13\u65E5\u3060\u3063\u305F\u306E\u306F\u5931\u6557\u304B\u306A\u2026\uFF12\u65E5\u306E\u4F11\u307F\u304C\u77ED\u304F\u611F\u3058\u3066\u3057\u307E\u3046\u2026\u3002",
  "id" : 61729756978221056,
  "created_at" : "2011-04-23 09:54:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Cushing",
      "screen_name" : "Montberte",
      "indices" : [ 3, 13 ],
      "id_str" : "193318094",
      "id" : 193318094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61666274022920192",
  "text" : "RT @Montberte: Philosophy is a game with objectives and no rules. Mathematics is a game with rules and no objectives.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61653260049715200",
    "text" : "Philosophy is a game with objectives and no rules. Mathematics is a game with rules and no objectives.",
    "id" : 61653260049715200,
    "created_at" : "2011-04-23 04:50:57 +0000",
    "user" : {
      "name" : "Steve Cushing",
      "screen_name" : "Montberte",
      "protected" : false,
      "id_str" : "193318094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447061043252961280\/JIhyrCjs_normal.jpeg",
      "id" : 193318094,
      "verified" : false
    }
  },
  "id" : 61666274022920192,
  "created_at" : "2011-04-23 05:42:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3089\u3081\u304D\u30E1\u30E2",
      "screen_name" : "shh7",
      "indices" : [ 3, 8 ],
      "id_str" : "129790485",
      "id" : 129790485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61645050660134912",
  "text" : "RT @shh7: \u3053\u308C\u306F\uFF57\uFF57\u3000\u3088\u304F\u3067\u304D\u3066\u307E\u3059\uFF57 RT fladdict: \u4ED5\u4E8B\u4E2D\u306B\u30B3\u30C3\u30BD\u30EA\u3084\u308B\u3088\u3046\u30D6\u30ED\u30C3\u30AF\u5D29\u3057 http:\/\/bit.ly\/CgNTN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/d.hatena.ne.jp\/fta7\/\" rel=\"nofollow\"\u003E\u3072\u3089\u3081\u304D\u7BB1\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61641278873538560",
    "text" : "\u3053\u308C\u306F\uFF57\uFF57\u3000\u3088\u304F\u3067\u304D\u3066\u307E\u3059\uFF57 RT fladdict: \u4ED5\u4E8B\u4E2D\u306B\u30B3\u30C3\u30BD\u30EA\u3084\u308B\u3088\u3046\u30D6\u30ED\u30C3\u30AF\u5D29\u3057 http:\/\/bit.ly\/CgNTN",
    "id" : 61641278873538560,
    "created_at" : "2011-04-23 04:03:20 +0000",
    "user" : {
      "name" : "\u3072\u3089\u3081\u304D\u30E1\u30E2",
      "screen_name" : "shh7",
      "protected" : false,
      "id_str" : "129790485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580367888176922624\/1HfOwc_R_normal.jpg",
      "id" : 129790485,
      "verified" : false
    }
  },
  "id" : 61645050660134912,
  "created_at" : "2011-04-23 04:18:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61622857981100032",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 61622857981100032,
  "created_at" : "2011-04-23 02:50:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61622713302781952",
  "text" : "\u4E45\u3005\u306B\u5BDD\u574A\u3068\u3044\u3046\u304B\u663C\u307E\u3067\u5BDD\u305F\u30FC\u3002\u96E8\u3002\u5BD2\u3044\u306A\u3002",
  "id" : 61622713302781952,
  "created_at" : "2011-04-23 02:49:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61482072556048384",
  "text" : "\u9EBB\u96C0\u308F\u305A\u30FC\u3002\u30CB\u4F4D\u3001\u30CB\u4F4D\u3001\u4E00\u4F4D\u3068\u307E\u305A\u307E\u305A\u3002\u4E00\u4EBA\u51C4\u304F\u30C4\u30A4\u3066\u3066\u5730\u5473\u3067\u3057\u305F\u304C\u5B89\u5B9A\u3057\u3066\u305F\u306E\u3067\u826F\u3057\u304B\u306A\u3002",
  "id" : 61482072556048384,
  "created_at" : "2011-04-22 17:30:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30B3",
      "screen_name" : "akoatt",
      "indices" : [ 3, 10 ],
      "id_str" : "138639404",
      "id" : 138639404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61457748298170368",
  "text" : "RT @akoatt: \u5FAE\u5206\u7A4D\u5206\u3044\u3044\u6C17\u5206\u3002\u2026\u3053\u308C\u3063\u3066\u5168\u56FD\u7684\u306A\u8A00\u8449\u306A\u306E\uFF1F\u79C1\u306E\u307E\u308F\u308A\u3060\u3051\u3060\u3063\u305F\u306E\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61455387064401920",
    "text" : "\u5FAE\u5206\u7A4D\u5206\u3044\u3044\u6C17\u5206\u3002\u2026\u3053\u308C\u3063\u3066\u5168\u56FD\u7684\u306A\u8A00\u8449\u306A\u306E\uFF1F\u79C1\u306E\u307E\u308F\u308A\u3060\u3051\u3060\u3063\u305F\u306E\uFF1F",
    "id" : 61455387064401920,
    "created_at" : "2011-04-22 15:44:40 +0000",
    "user" : {
      "name" : "\u30A2\u30B3",
      "screen_name" : "akoatt",
      "protected" : false,
      "id_str" : "138639404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/865101676\/aco_normal.jpg",
      "id" : 138639404,
      "verified" : false
    }
  },
  "id" : 61457748298170368,
  "created_at" : "2011-04-22 15:54:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61255409821945857",
  "text" : "@nico_reflexio \u3058\u3083\u3042\u30A2\u30F3\u30C7\u30C3\u30C8\u7CFB\u306E\u4F55\u306A\u306E\uFF1F",
  "id" : 61255409821945857,
  "created_at" : "2011-04-22 02:30:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 25, 34 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61062167973216256",
  "geo" : { },
  "id_str" : "61225878016897024",
  "in_reply_to_user_id" : 187163335,
  "text" : "\uFF4E\u56DE\u76EE\u306B\u592A\u90CE\u304C\u52DD\u3064\u78BA\u7387\u3058\u3083\u306A\u3044\u3058\u3083\u3093orz QT @bukuburi: \uFF11\u500B\u306E\u30B5\u30A4\u30B3\u30ED\uFF08\u7ACB\u65B9\u4F53\uFF09\u3092\u4F7F\u3063\u3066\u4EE5\u4E0B\u306E\u30EB\u30FC\u30EB\u3067\u30B2\u30FC\u30E0\u3092\u3057\u307E\u3059\u3002\n\u25CF2\u9023\u7D9A\u30672\u4EE5\u4E0B\u304C\u51FA\u305F\u6642\u70B9\u3067\u592A\u90CE\u306E\u52DD\u3061\n\u25CF3\u9023\u7D9A\u30673\u4EE5\u4E0A\u304C\u51FA\u305F\u6642\u70B9\u3067\u82B1\u5B50\u306E\u52DD\u3061\n\u52DD\u3061\u304C\u6C7A\u307E\u308B\u307E\u3067\u632F\u308A\u7D9A\u3051\u305F\u6642\u3001\u592A\u90CE\u304C\u52DD\u3064\u78BA\u7387\u306F\u3044\u304F\u3089\uFF1F#math",
  "id" : 61225878016897024,
  "in_reply_to_status_id" : 61062167973216256,
  "created_at" : "2011-04-22 00:32:41 +0000",
  "in_reply_to_screen_name" : "bukuburi",
  "in_reply_to_user_id_str" : "187163335",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61204532708913152",
  "text" : "@nico_reflexio \u30CB\u2026\u30CB\u30D5\u30E9\u30E0\uFF01",
  "id" : 61204532708913152,
  "created_at" : "2011-04-21 23:07:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6383\u9664\u6A5F",
      "screen_name" : "siritori",
      "indices" : [ 3, 12 ],
      "id_str" : "50046492",
      "id" : 50046492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61204357730942977",
  "text" : "RT @siritori: \u8FD1\u3044\u3046\u3061\u306B\uFF62\u5927\u5B66\u4E00\u5E74\u751F\u304B\u3089\u59CB\u3081\u308B\u30D1\u30FC\u30D5\u30A7\u30AF\u30C8C\u8A00\u8A9E\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u6559\u5BA4\uFF63\u3068\u3057\u306610\u6570\u4EBA\u304F\u3089\u3044\u96C6\u3081\u3066\u30E9\u30A6\u30F3\u30B8\u3042\u305F\u308A\u3067\u30BB\u30DF\u30CA\u30FC\u958B\u304D\u305F\u3044\u306A\u3041\u3002\u6559\u3048\u308B\u7DF4\u7FD2\u306B\u3082\u306A\u308B\u3057\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61199714451857408",
    "text" : "\u8FD1\u3044\u3046\u3061\u306B\uFF62\u5927\u5B66\u4E00\u5E74\u751F\u304B\u3089\u59CB\u3081\u308B\u30D1\u30FC\u30D5\u30A7\u30AF\u30C8C\u8A00\u8A9E\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u6559\u5BA4\uFF63\u3068\u3057\u306610\u6570\u4EBA\u304F\u3089\u3044\u96C6\u3081\u3066\u30E9\u30A6\u30F3\u30B8\u3042\u305F\u308A\u3067\u30BB\u30DF\u30CA\u30FC\u958B\u304D\u305F\u3044\u306A\u3041\u3002\u6559\u3048\u308B\u7DF4\u7FD2\u306B\u3082\u306A\u308B\u3057\u3002",
    "id" : 61199714451857408,
    "created_at" : "2011-04-21 22:48:43 +0000",
    "user" : {
      "name" : "\u6383\u9664\u6A5F",
      "screen_name" : "siritori",
      "protected" : false,
      "id_str" : "50046492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550920219946782720\/usHldePr_normal.png",
      "id" : 50046492,
      "verified" : false
    }
  },
  "id" : 61204357730942977,
  "created_at" : "2011-04-21 23:07:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61204170333626368",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u4ECA\u671D\u306F\u5BD2\u3044\u3002\u307E\u305F\u96E8\u3089\u3057\u3044\u3002\u305A\u3044\u3076\u3093\u4E0D\u5B89\u5B9A\u3060\u306A\u3041\u2026\u3002",
  "id" : 61204170333626368,
  "created_at" : "2011-04-21 23:06:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61100461624799232",
  "text" : "\u5BDD\u308B\u3068\u3044\u3044\u3064\u3064\u643A\u5E2F\u304B\u3089\u30C1\u30E9\u30C1\u30E9\u307F\u3066\u3057\u307E\u3046\u3002\u4ECA\u65E5\u4E00\u9650\u3060\u304B\u3089\u5BDD\u306A\u304D\u3083\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 61100461624799232,
  "created_at" : "2011-04-21 16:14:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61099815072837634",
  "text" : "\u9045\u304F\u306A\u3063\u3066\u3059\u307F\u307E\u305B\u3093\u3002\u8208\u5473\u306F\u3042\u308A\u307E\u3059\u3088\u3002",
  "id" : 61099815072837634,
  "created_at" : "2011-04-21 16:11:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61097270468296704",
  "text" : "\u306D\u308B",
  "id" : 61097270468296704,
  "created_at" : "2011-04-21 16:01:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61091315101868032",
  "text" : "\u306A\u3093\u304B\u30D0\u30B0\u306A\u304F\u306A\u3063\u305F\u3002\u306A\u3093\u3060\u3063\u305F\u3093\u3060\u308D\u3002\u3053\u308C\u3067\u5BDD\u308C\u308B\u30A1\uFF01",
  "id" : 61091315101868032,
  "created_at" : "2011-04-21 15:37:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 34, 39 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61091057240248320",
  "text" : "\u300C\u3053\u308C\u9593\u9055\u3044\u306A\u304F\u9593\u9055\u3063\u3066\u308B\u3088\u306D\u300D \u307F\u305F\u3044\u306A\u81EA\u5DF1\u8A00\u53CA\u3082\u597D\u304D\u3067\u3059\u3002RT @np2i: @haru_urah_rah \u3057\u308A\u3068\u308A\u3084\u56DE\u6587\u3068\u3044\u3063\u305F\u30B2\u30FC\u30E0\u30FB\u30D1\u30BA\u30EB\u7684\u306A\u300C\u8A00\u8449\u904A\u3073\u300D\u3067\u306F\u306A\u304F\u3066\u3001\u300C\u304F\u3060\u3089\u306A\u3044\u8A00\u8449\u904A\u3073\u306F\u3084\u3081\u308D\u300D\u3068\u3044\u3063\u305F\u6587\u8108\u3067\u306E\u8A00\u8449\u904A\u3073\u304C\u597D\u304D\u3067\u3059\u3002\u3069\u3046\u3067\u3082\u3044\u3044\u60C5\u5831\u3067\u3057\u305F\uFF57",
  "id" : 61091057240248320,
  "created_at" : "2011-04-21 15:36:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61087709808173056",
  "text" : "\u30C0\u30E1\u3060\u3001\u30D0\u30B0\uFF08\uFF1F\uFF09\u304C\u53D6\u308C\u306A\u3044\u3002\u3002\u3002\u8A70\u307E\u3063\u305F\u306A\u3001\u56F0\u3063\u305F\u306A\u3002\u7720\u305F\u3044\u3093\u3060\u3051\u3069\u3002",
  "id" : 61087709808173056,
  "created_at" : "2011-04-21 15:23:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61078686551642112",
  "geo" : { },
  "id_str" : "61078977846059008",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 5",
  "id" : 61078977846059008,
  "in_reply_to_status_id" : 61078686551642112,
  "created_at" : "2011-04-21 14:48:57 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61078663797538816",
  "text" : "\u5E74\u9F62\u5165\u308C\u308B\u3068\uFF11\uFF10\u5E74\u5F8C\u306F\u4F55\u6B73\u3067\u3059\u306D\u3001\u3063\u3066\u6559\u3048\u3066\u304F\u308C\u308B\u7C21\u5358\u306A\u30D7\u30ED\u30B0\u30E9\u30E0\u3092\u7D44\u3093\u3067\u7DF4\u7FD2\u3057\u3066\u3044\u308B\u304C\u3001\u3069\u3046\u3044\u3046\u308F\u3051\u304B\u3053\u3046\u306A\u3063\u305F\u3002",
  "id" : 61078663797538816,
  "created_at" : "2011-04-21 14:47:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61078519526080513",
  "text" : "\u3042\u306A\u305F\u306E\u540D\u524D\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002\nend313124\nend313124\u3055\u3093\u3001\u3053\u3093\u306B\u3061\u306F\u3002\n\u5E74\u9F62\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\n20\n\u4ECA 2147344384 \u6B73\u3068\u3059\u308B\u3068\u3001\uFF11\uFF10\u5E74\u5F8C\u306F 2147344394 \u6B73\u3067\u3059\u306D\u3002",
  "id" : 61078519526080513,
  "created_at" : "2011-04-21 14:47:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 0, 9 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61063638009659392",
  "geo" : { },
  "id_str" : "61064161236496384",
  "in_reply_to_user_id" : 187163335,
  "text" : "@bukuburi \u8A70\u307E\u3089\u306A\u3044\u6388\u696D\u4E2D\u306B\u3067\u3082\u8003\u3048\u3066\u307F\u307E\u30FC\u3059\u3002\u89E3\u7B54\u3063\u3066DM\u3067\u3044\u3044\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 61064161236496384,
  "in_reply_to_status_id" : 61063638009659392,
  "created_at" : "2011-04-21 13:50:05 +0000",
  "in_reply_to_screen_name" : "bukuburi",
  "in_reply_to_user_id_str" : "187163335",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61062241373519872",
  "geo" : { },
  "id_str" : "61062880916811776",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u9AD8\u3044\u30A6\u30A3\u30B9\u30AD\u30FC\u3063\u3066\u7F8E\u5473\u3057\u3044\u3089\u3057\u3044\u304B\u3089\u306A\u3041\u3002\u3046\u3089\u3084\u307E\u3057\u3044\u3002",
  "id" : 61062880916811776,
  "in_reply_to_status_id" : 61062241373519872,
  "created_at" : "2011-04-21 13:44:59 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61054432460283904",
  "text" : "\u3080\u3045\u3001\u8A9E\u5B66\u3084\u3093\u306A\u304D\u3083\u3044\u3051\u306A\u3044\u306A\u30FC\u3068\u601D\u3044\u3064\u3064\u7DDA\u5F62\u4EE3\u6570\u3084\u308A\u305F\u3044\u306A\u30FC\u3068\u601D\u3044\u3064\u3064\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u3084\u308B\u304B\u306A\u30FC\u3068\u601D\u3044\u3064\u3064\u2026\u30B7\u30E3\u30EF\u30FC\u3092\u6D74\u3073\u3088\u3046",
  "id" : 61054432460283904,
  "created_at" : "2011-04-21 13:11:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61001620871323648",
  "text" : "\u3061\u3087\u3063\u3068\u6C17\u306B\u306A\u3063\u3066twilog stats\u898B\u3066\u307F\u305F\u3089\u6587\u5B57\u6570\u304C 33.3\u6587\u5B57\/\u4EF6\n\u4E00\u56DE\u306B\u3064\u304D\u6587\u5B57\u6570\u304C\u591A\u3044\u30A4\u30E1\u30FC\u30B8",
  "id" : 61001620871323648,
  "created_at" : "2011-04-21 09:41:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61000361976143873",
  "geo" : { },
  "id_str" : "61001044909502464",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u50D5\u304C\u95A2\u6771\u306B\u3044\u305F\u3089\u30A4\u30F3\u30AB\u30EC\u3067\u3082\u53C2\u52A0\u3057\u305F\u304B\u3063\u305F\u3067\u3059\uFF57\u6848\u5916\u7121\u3044\u3082\u3093\u3067\u3059\u3088\u306D\u3002",
  "id" : 61001044909502464,
  "in_reply_to_status_id" : 61000361976143873,
  "created_at" : "2011-04-21 09:39:17 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61000330145566720",
  "text" : "@haru_urah_rah \u6848\u5916\u52DF\u96C6\u3057\u3066\u6765\u308B\u3082\u306E\u306A\u306E\u3067\u3059\u306D\u3002\u4E2D\u9AD8\u751F\uFF08\u51FA\u6765\u308C\u3070\u9AD8\u6821\u751F\uFF09\u306E\u5BB6\u5EAD\u6559\u5E2B\u3001\u500B\u4EBA\u5951\u7D04\u3067\u3084\u308A\u305F\u3044\u306E\u3067\u3059\u304C\u30B3\u30CD\u306A\u304F\u3057\u3066\u898B\u3064\u304B\u3089\u305A\u3001\u30D4\u30F3\u30CF\u30CD\u6211\u6162\u3057\u3066\u696D\u8005\u901A\u3057\u3066\u3084\u3063\u3066\u307E\u3059\u304C\u3002",
  "id" : 61000330145566720,
  "created_at" : "2011-04-21 09:36:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60999791655665664",
  "text" : "\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u3084\u308A\u59CB\u3081\u305F\u306E\u306F\u3044\u3044\u3051\u308C\u3069\u3001\u66F8\u3044\u305F\u30D7\u30ED\u30B0\u30E9\u30E0\u3092\u30B3\u30F3\u30D1\u30A4\u30E9\u3059\u308B\u307E\u3067\u306F\uFF08\u305F\u3076\u3093\uFF09OK\u306A\u3093\u3060\u3051\u3069\u3001\u306A\u305C\u304B\u5B9F\u884C\u3059\u308B\u3068\u4E00\u77AC\u51FA\u3066\u3059\u3050\u7A93\u304C\u9589\u3058\u3066\u3057\u307E\u3046\u3002\u74B0\u5883\u5909\u6570\u306E\u8A2D\u5B9A\u306A\u306E\u304B\u306A\u3001\u4E00\u901A\u308A\u8ABF\u3079\u3066\u3084\u3063\u305F\u3051\u3069\u3002\u3061\u306A\u307F\u306B\u30B3\u30DE\u30F3\u30C9\u30D7\u30ED\u30F3\u30D7\u30C8\u3067\u958B\u3051\u3070\u554F\u984C\u306A\u3057\u3002\u539F\u56E0\u601D\u3044\u5F53\u305F\u308B\u8061\u660E\u306A\u4EBA\u3044\u307E\u3059\u304B\u306D\u2026\u3002",
  "id" : 60999791655665664,
  "created_at" : "2011-04-21 09:34:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 0, 9 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60905976332697600",
  "geo" : { },
  "id_str" : "60913010943868928",
  "in_reply_to_user_id" : 187163335,
  "text" : "@bukuburi \u50D5\u306F\u5148\u306B\u5076\u6570\u9664\u5916\u3057\u3066\uFF13\u30D1\u30BF\u30FC\u30F3\u8A66\u3057\u307E\u3057\u305F\u3002\u5FAE\u3005\u305F\u308B\u5DEE\u3067\u3059\u304C\u30FC\u3002",
  "id" : 60913010943868928,
  "in_reply_to_status_id" : 60905976332697600,
  "created_at" : "2011-04-21 03:49:28 +0000",
  "in_reply_to_screen_name" : "bukuburi",
  "in_reply_to_user_id_str" : "187163335",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60904105492758528",
  "text" : "@nico_reflexio \u3068\u308A\u307E\uFF4E\u306F\u5076\u6570\u3058\u3083\u306A\u3044\u3053\u3068\u3092\u793A\u3059\u3068\u3053\u308D\u304B\u3089\u3002\u5947\u6570\u306A\u3089\uFF16\u3067\u5272\u3063\u305F\u5270\u4F59\u3067\uFF13\u30D1\u30BF\u30FC\u30F3\u3002",
  "id" : 60904105492758528,
  "created_at" : "2011-04-21 03:14:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6570\u5B66\u554F\u984Cbot",
      "screen_name" : "mathematics_bot",
      "indices" : [ 8, 24 ],
      "id_str" : "96739891",
      "id" : 96739891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60895075177218048",
  "text" : "\u826F\u554F\u306A\u308A RT @mathematics_bot: 2^n\uFF0Bn^2\u304C\u7D20\u6570\u3067\u3042\u308B\u3088\u3046\u306A2\u4EE5\u4E0A\u306E\u6574\u6570n\u306B\u3064\u3044\u3066\u3001n\u30926\u3067\u5272\u3063\u305F\u6642\u306E\u4F59\u308A\u304C3\u3067\u3042\u308B\u3053\u3068\u3092\u793A\u305B\u3002\uFF08\u7B2C24\u56DE\u30B7\u30E5\u30D7\u30EA\u30F3\u30AC\u30FC\u6570\u5B66\u30B3\u30F3\u30C6\u30B9\u30C8\uFF09 #math",
  "id" : 60895075177218048,
  "created_at" : "2011-04-21 02:38:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 64, 74 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 75, 84 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60863961217773568",
  "text" : "\u4ECA\u601D\u3048\u3070\u8A00\u8449\u306E\u7DBE\u3068\u3044\u3046\u304B\u8272\u3005\u89E3\u91C8\u3067\u304D\u3061\u3083\u3046\u8868\u73FE\u3067\u3057\u305F\u306D\u3002\u307E\u3041\u305D\u308C\u3082\u4E00\u8208\u3002 RT @haru_urah_rah: @mo5nya @end313124 @bukuburi \n\u540C\u3058\u7A7A\u6C17\u3063\u3066\u8003\u3048\u3061\u3083\u3046\u3068\u2026\u3002\u7B11",
  "id" : 60863961217773568,
  "created_at" : "2011-04-21 00:34:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60856846768013312",
  "text" : "\u8D77\u5E8A\u3002\u7A7A\u8179\u3002\u5BDD\u8DB3\u308A\u306A\u3044\u2026\u3002",
  "id" : 60856846768013312,
  "created_at" : "2011-04-21 00:06:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60752654292357120",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 60752654292357120,
  "created_at" : "2011-04-20 17:12:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60752595257536512",
  "text" : "\u52D5\u304D\u59CB\u3081\u3066\u3057\u307E\u3048\u3070\u7D50\u69CB\u306A\u30DA\u30FC\u30B9\u3067\u52D5\u304B\u305B\u305D\u3046\u3060\u3051\u3069\u3001\u3082\u3046\u982D\u306E\u65B9\u304C\u52D5\u304D\u305D\u3046\u306B\u306A\u3044\u308F\u30FC\u3002",
  "id" : 60752595257536512,
  "created_at" : "2011-04-20 17:12:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60752022533718016",
  "text" : "exe\u30D5\u30A1\u30A4\u30EB\u3092\u30AF\u30EA\u30C3\u30AF\u3059\u308B\u3068\u4E00\u77AC\u3067\u6D88\u3048\u308B\u304C\u3001\u30B3\u30DE\u30F3\u30C9\u30D7\u30ED\u30F3\u30D7\u30C8\u3067\u52D5\u304B\u305B\u3070\u666E\u901A\u306B\u52D5\u304F\u3002\u6B63\u5E38\u306A\u306E\u304B\u306A\uFF1F\u3082\u3046\u5BDD\u3088\u3046\u3002",
  "id" : 60752022533718016,
  "created_at" : "2011-04-20 17:09:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60738507299225600",
  "text" : "\u518D\u8D77\u52D5\u3057\u3066\u3082\u30C0\u30E1\u306A\u3089\u5BDD\u3088",
  "id" : 60738507299225600,
  "created_at" : "2011-04-20 16:16:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 38, 47 ],
      "id_str" : "187163335",
      "id" : 187163335
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 64, 74 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60732112894038016",
  "text" : "\u89E3\u3051\u305F\u3051\u3069\u3001\u3069\u3046\u3044\u3046\u308F\u3051\u304B\u3059\u3054\u304F\u6642\u9593\u304C\u2026\u3002\u304D\u3063\u3068\u540C\u3058\u7A7A\u6C17\u3060\u3063\u305F\u306E\u3067\u3059\u306DRT @bukuburi: @haru_urah_rah @end313124 \u3059\u3070\u3089\u3057\u3044\u3067\u3059\uFF01\uFF01\u30D1\u30C1\u30D1\u30C1\u30D1\u30C1(^-^)\/\n\u3053\u306E\u8A71\u306F\u30AA\u30C1\u304C\u3042\u3063\u3066\u30014\u756A\u76EE\u306B\u96E3\u3057\u3044\u306E\u304C5557\u306A\u306E\u3067\u3059\uFF08\u81EA\u5206\u57FA\u6E96\uFF09\u266A( \u00B4\u25BD\uFF40)",
  "id" : 60732112894038016,
  "created_at" : "2011-04-20 15:50:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60720783948914688",
  "geo" : { },
  "id_str" : "60721399257509888",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5358\u4F4D\u306F\uFF11\uFF10\uFF10\u3067\u3042\u3063\u3066\u308B\u3051\u3069\uFF1F(\uFF84\uFF9E\uFF94  \u3063\u3066\u7B54\u3048\u308B\u306E\u304C\uFF22\uFF21",
  "id" : 60721399257509888,
  "in_reply_to_status_id" : 60720783948914688,
  "created_at" : "2011-04-20 15:08:04 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60716428902416384",
  "text" : "\u5E30\u5B85\u30A1\uFF01",
  "id" : 60716428902416384,
  "created_at" : "2011-04-20 14:48:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60710894803496960",
  "text" : "\u305D\u3046\u3044\u3084\u5B9F\u306F\u30D6\u30ED\u30C3\u30AF\u3068\u30EA\u30E0\u30FC\u30D6\u306E\u9055\u3044\u304C\u3088\u304F\u5206\u304B\u3063\u3066\u3044\u306A\u3044\u3002\u3044\u3084\u3001\u81EA\u5206\u3067\u8ABF\u3079\u308A\u3083\u826F\u3044\u3093\u3060\u3051\u3069\u3055\u3002",
  "id" : 60710894803496960,
  "created_at" : "2011-04-20 14:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60709423068348417",
  "text" : "\u6708\u304C\u660E\u308B\u304F\u3066\u5947\u9E97\u3060\u3002\u30DB\u30F3\u30C8\u306B\uFF14\u6708\u4E0B\u65EC\u304B\u3057\u3089\uFF1F",
  "id" : 60709423068348417,
  "created_at" : "2011-04-20 14:20:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60709103516925952",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u4E95\u306E\u982D\u7DDA\u3063\u3066\u5168\u99C5\u306B\u5F85\u5408\u5BA4\u307F\u305F\u3044\u306E\u51FA\u6765\u305F\u306E\u304B\u306A\u3002",
  "id" : 60709103516925952,
  "created_at" : "2011-04-20 14:19:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60708853314109441",
  "text" : "\u5BD2\u3044\u3002\u96FB\u8ECA\u6765\u306A\u3044\u306E\u306F\u6211\u6162\u3059\u308B\u304B\u3089\u3042\u3063\u305F\u304B\u3044\u5F85\u5408\u5BA4\u304C\u6B32\u3057\u3044\u3002",
  "id" : 60708853314109441,
  "created_at" : "2011-04-20 14:18:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60708192518287360",
  "text" : "\u30A2\u30D7\u30EA\u3092\u591A\u91CD\u8D77\u52D5\u3059\u308B\u30A2\u30D7\u30EA\u306A\u3044\u304B\u306A\u30FC\u3001\u3068\u304B\u4E00\u77AC\u8003\u3048\u305F\u304C\u305D\u306E\u30A2\u30D7\u30EA\u3092\u591A\u91CD\u8D77\u52D5\u3057\u305F\u3089\u5927\u5909\u306A\u3053\u3068\u306B\u306A\u308B\u5373\u5EA7\u306B\u6C17\u3065\u3044\u305F\u3002\n\u3053\u308C\u306B\u6C17\u3065\u304F\u306E\u304C\u4EBA\u306B\u3044\u3046\u524D\u3067\u3088\u304B\u3063\u305F\u3002\n\u3042\u3001\u3067\u3082\u3053\u308C\u306F\u4EBA\u306B\u8AAD\u307E\u308C\u308B\u306E\u304B\u3002\uFF08\u4E00\u884C\u524D\u306B\u623B\u308B\uFF09",
  "id" : 60708192518287360,
  "created_at" : "2011-04-20 14:15:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60707423895302144",
  "text" : "\u8AB0\u3082\u3044\u306A\u3044\u90E8\u5C4B\u3067saezuri\u304C\u9CF4\u3044\u3066\u3044\u308B\u3068\u601D\u3046\u3068\u80F8\u71B1\u3002",
  "id" : 60707423895302144,
  "created_at" : "2011-04-20 14:12:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60706974739873792",
  "text" : "\u3055\u3001\u4E57\u308A\u63DB\u3048\u3060\u3002",
  "id" : 60706974739873792,
  "created_at" : "2011-04-20 14:10:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60706784544956416",
  "text" : "\u305D\u3046\u3044\u3084\u300Cjigtwi\u3088\u308A\u300D\u3068\u304B\u3063\u3066\u8868\u793A\u3001bot\u306F\u9055\u3046\u307F\u305F\u3044\u3060\u3051\u3069\u8A2D\u5B9A\u3068\u304B\u3067\u5909\u3048\u3089\u308C\u308B\u3082\u3093\u306A\u306E\u304B\u306D\u3002bot\u306E\u30D7\u30ED\u30B0\u30E9\u30E0\u306E\u4E00\u90E8\u3063\u3066\u6C17\u304C\u3059\u308B\u3051\u3069\u3002",
  "id" : 60706784544956416,
  "created_at" : "2011-04-20 14:09:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moonAge",
      "screen_name" : "moonAge_bot",
      "indices" : [ 3, 15 ],
      "id_str" : "94838486",
      "id" : 94838486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60704915110117376",
  "text" : "RT @moonAge_bot: \u73FE\u5728\u306E\u6708\u9F62\u306F\u301016.97\u3011\u3067\u3059\u3000(04\/20 10:30)\uFF0F\u5341\u516D\u591C\uFF08\u3044\u3056\u3088\u3044\uFF09\/\u65E2\u671B\uFF08\u304D\u307C\u3046\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/d.hatena.ne.jp\/bardothodol\/20091210\/p1\" rel=\"nofollow\"\u003E\u6708\u9F62\u8868\u793A\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60696726004183040",
    "text" : "\u73FE\u5728\u306E\u6708\u9F62\u306F\u301016.97\u3011\u3067\u3059\u3000(04\/20 10:30)\uFF0F\u5341\u516D\u591C\uFF08\u3044\u3056\u3088\u3044\uFF09\/\u65E2\u671B\uFF08\u304D\u307C\u3046\uFF09",
    "id" : 60696726004183040,
    "created_at" : "2011-04-20 13:30:01 +0000",
    "user" : {
      "name" : "moonAge",
      "screen_name" : "moonAge_bot",
      "protected" : false,
      "id_str" : "94838486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608127633457479680\/inCgogK9_normal.jpg",
      "id" : 94838486,
      "verified" : false
    }
  },
  "id" : 60704915110117376,
  "created_at" : "2011-04-20 14:02:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "indices" : [ 3, 11 ],
      "id_str" : "5452512",
      "id" : 5452512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60704818657890304",
  "text" : "RT @sanakan: \u4E00\u756A\u30D4\u30F3\u30C8\u304C\u5408\u3063\u305F\u3082\u306E\u3002\u624B\u524D\u306E\u5F71\u306F\u96FB\u7DDA\u3000\u3000\u3000https:\/\/picasaweb.google.com\/lh\/photo\/uHROmIRU1lIu2klr_Th3Ig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/cheebow.info\/chemt\/archives\/2007\/04\/twitterwindowst.html\" rel=\"nofollow\"\u003ETwit for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60704271909404674",
    "text" : "\u4E00\u756A\u30D4\u30F3\u30C8\u304C\u5408\u3063\u305F\u3082\u306E\u3002\u624B\u524D\u306E\u5F71\u306F\u96FB\u7DDA\u3000\u3000\u3000https:\/\/picasaweb.google.com\/lh\/photo\/uHROmIRU1lIu2klr_Th3Ig",
    "id" : 60704271909404674,
    "created_at" : "2011-04-20 14:00:00 +0000",
    "user" : {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "protected" : false,
      "id_str" : "5452512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443764967045464064\/qjI5wq51_normal.jpeg",
      "id" : 5452512,
      "verified" : false
    }
  },
  "id" : 60704818657890304,
  "created_at" : "2011-04-20 14:02:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60700812929794048",
  "text" : "\u606F\u767D\u3044\u3057\u2026\u3002\u6625\u88C5\u5099\u3067\u306F\u5BD2\u3059\u304E\u308B\u3002",
  "id" : 60700812929794048,
  "created_at" : "2011-04-20 13:46:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60700584273121280",
  "text" : "\u808C\u5BD2\u3044\u3093\u3058\u3083\u306A\u304F\u3066\u5BD2\u3044",
  "id" : 60700584273121280,
  "created_at" : "2011-04-20 13:45:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 16, 25 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60699984890310656",
  "text" : "\u9045\u308C\u3070\u305B\u306A\u304C\u3089\u89E3\u3051\u307E\u3057\u305F RT @bukuburi: \u6570\u5B57\u56DB\u6587\u5B57\u3001\u4E26\u3079\u66FF\u3048\u3068\u62EC\u5F27\u3068\u56DB\u5247\u6F14\u7B97\u3060\u3051\u306710\u3092\u3064\u304F\u308B\u3002\n\u554F1.1199\n\u554F2.3478\n\u554F3.1158",
  "id" : 60699984890310656,
  "created_at" : "2011-04-20 13:42:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60649583092563968",
  "text" : "\u5929\u6C17\u3084\u3089\u6C17\u6E29\u306E\u8A71\u591A\u3044\u306A\u3002\u30C1\u30E9\u30B7\u306E\u88CF\u3089\u3057\u3044\u3068\u8A00\u3048\u3070\u305D\u308C\u307E\u3067\u3060\u3051\u3069\u3002",
  "id" : 60649583092563968,
  "created_at" : "2011-04-20 10:22:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60649029914214400",
  "text" : "\u5927\u5B66\u306B\u9577\u8896\u4E8C\u679A\u3067\u884C\u3063\u305F\u3089\u5BD2\u3059\u304E\u3060\u3063\u305F\u306E\u3067\u3001\u51FA\u76F4\u3057\u305F\u4ECA\u306F\u4E09\u679A\u3002\u305D\u308C\u3067\u3082\u5C11\u3057\u808C\u5BD2\u3044\u3002",
  "id" : 60649029914214400,
  "created_at" : "2011-04-20 10:20:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60648549767069696",
  "text" : "\u982D\u75DB\u306E\u524D\u89E6\u308C\u307F\u305F\u3044\u306E\u304C\u3042\u308B\u3002\u80A9\u51DD\u308A\uFF1F\u9996\u51DD\u308A\uFF1F",
  "id" : 60648549767069696,
  "created_at" : "2011-04-20 10:18:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60647964602925056",
  "text" : "\u30DB\u30FC\u30E0\u30B7\u30C3\u30AF\u3067\u306F\u306A\u3044\u3051\u308C\u3069\u90FD\u5FC3\u90E8\u3078\u306E\u5BB9\u6613\u306A\u30A2\u30AF\u30BB\u30B9\u306F\u6642\u3005\u604B\u3057\u3044\u3002",
  "id" : 60647964602925056,
  "created_at" : "2011-04-20 10:16:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60616107484127232",
  "text" : "@ayu167 \u3058\u3087\u3066\u3044\u306E\u307E\u3061\u304C\u3044\u3067\u306F\uFF1F",
  "id" : 60616107484127232,
  "created_at" : "2011-04-20 08:09:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60584458432163841",
  "text" : "@np2i \u5927\u5B66\u306B\u3082\u5B66\u90E8\u306B\u3082\u3088\u308A\u307E\u3059\u304C\u3001\u5358\u4F4D\u306B\u306A\u3089\u306A\u304F\u3066\u3082\u8074\u8B1B\u3067\u304D\u308B\u30B7\u30B9\u30C6\u30E0\u306F\u3042\u308B\u3093\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u306D\uFF1F",
  "id" : 60584458432163841,
  "created_at" : "2011-04-20 06:03:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60576644393467904",
  "text" : "@np2i \u57FA\u790E\u8AD6\u7406\u5B66\u6F14\u7FD2 \u307F\u305F\u3044\u306A\u540D\u524D\u3060\u3063\u305F\u3068\u601D\u3044\u307E\u3059\u3002\u6587\u5B66\u90E8\u306E\u79D1\u76EE\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u3002",
  "id" : 60576644393467904,
  "created_at" : "2011-04-20 05:32:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "math",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60573963843145728",
  "text" : "\u6388\u696D\u3067\u6271\u3046\u5F62\u5F0F\u7684\u4F53\u7CFB\u306B\u3064\u3044\u3066\u307B\u3068\u3093\u3069\u5168\u90E8\u6570\u5B66\u30AC\u30FC\u30EB\u3067\u4E88\u7FD2\u6E08\u307F\u3060\u3063\u305F\u3002\u7406\u89E3\u304C\u6DF1\u307E\u308B\u3053\u3068\u3053\u306E\u4E0A\u306A\u3044\u3002 #mathgirl #math",
  "id" : 60573963843145728,
  "created_at" : "2011-04-20 05:22:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Springer Japan",
      "screen_name" : "SpringerJapan",
      "indices" : [ 18, 32 ],
      "id_str" : "72223432",
      "id" : 72223432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60565334075256832",
  "text" : "\u884C\u3063\u3066\u307F\u305F\u3044\u3002\u7269\u7406\u7684\u306B\u7121\u7406\u3002\u3002RT @SpringerJapan: \u6771\u5927\u30FB\u658E\u85E4\u6BC5\u6559\u6388\u8B1B\u6F14\u300C\u30D5\u30A7\u30EB\u30DE\u30FC\u306E\u6700\u7D42\u5B9A\u7406\u2015\u305D\u306E\u8A3C\u660E\u306E\u4E3B\u5F79\u305F\u3061\n\u300D4\u670822\u65E5(\u91D1)  16:30\uFF5E\u3001\u7B2C\uFF17\u56DE\u4E2D\u592E\u5927\u5B66\u7406\u5DE5\u5B66\u90E8\u6570\u5B66\u79D1\u8AC7\u8A71\u4F1A\u306B\u3066\u3002 http:\/\/bit.ly\/e9Ve9Z (M)",
  "id" : 60565334075256832,
  "created_at" : "2011-04-20 04:47:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60375509225320448",
  "text" : "@nico_reflexio \u3064\u65E6",
  "id" : 60375509225320448,
  "created_at" : "2011-04-19 16:13:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60361358478278656",
  "geo" : { },
  "id_str" : "60363514090487808",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u5927\u4E08\u592B\uFF1F\u30EA\u30B5\u3061\u3083\u3093\uFF1F",
  "id" : 60363514090487808,
  "in_reply_to_status_id" : 60361358478278656,
  "created_at" : "2011-04-19 15:25:57 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60359736905838592",
  "text" : "\u65E5\u66DC\u3042\u305F\u308A\u306B\u79CB\u8449\u539F\u884C\u304F\u30D5\u30A9\u30ED\u30A2\u30FC\u3055\u3093\u3044\u306A\u3044\u304B\u306A\u30FC\uFF1F",
  "id" : 60359736905838592,
  "created_at" : "2011-04-19 15:10:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 21, 26 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60343218046373888",
  "text" : "\u50D5\u3082\u5730\u7406\u3067\u3057\u305F\u30FC\u3002\u502B\u7406\u3082\u53D7\u3051\u305F\u3051\u3069\u3002RT @np2i: @haru_urah_rah @kouennnoyuugu \u30BB\u30F3\u30BF\u30FC\u73FE\u793E\u3092\u53D7\u3051\u305F\u540C\u5FD7\u304B\u3068\u601D\u3063\u305F\u3089\u5730\u7406\u30E1\u30A4\u30F3\u3067\u3057\u305F\u304B\u3002",
  "id" : 60343218046373888,
  "created_at" : "2011-04-19 14:05:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60342652532563970",
  "geo" : { },
  "id_str" : "60342990228553730",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u304A\u6C17\u306B\u53EC\u3059\u3088\u3046\u306B\uFF57",
  "id" : 60342990228553730,
  "in_reply_to_status_id" : 60342652532563970,
  "created_at" : "2011-04-19 14:04:24 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60342322755416064",
  "geo" : { },
  "id_str" : "60342891045863424",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u305D\u306E\u5358\u8A9E\u306F\u308F\u304F\u308F\u304F\u3059\u308B\u30EF\u30FC\u30C9\u3060\u308D\uFF57\uFF57\uFF57\u308F\u304B\u3063\u3066\u308B\u3068\u306F\u601D\u3046\u3051\u3069\u5225\u306B\u6570\u5B66\u597D\u304D\u306A\u4EBA\u306F\u597D\u304D\u3060\u304C\u3001\u6570\u5B66\u5ACC\u3044\u306E\u4EBA\u304C\u5ACC\u3044\u306A\u308F\u3051\u3067\u306F\u306A\u3044\u304B\u3089\u306D\u30FC\u3002",
  "id" : 60342891045863424,
  "in_reply_to_status_id" : 60342322755416064,
  "created_at" : "2011-04-19 14:04:00 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 78, 88 ]
    }, {
      "text" : "math",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60341600030699520",
  "text" : "\u3010\uFF32\uFF34\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 60341600030699520,
  "created_at" : "2011-04-19 13:58:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60341505784676354",
  "text" : "\u88AB\u30D5\u30A9\u30ED\u30A2\u5897\u3048\u3066\u306A\u3044\u3057\u3082\u3063\u304B\u3044\u3084\u3063\u3066\u304A\u3053\u3046\u3002",
  "id" : 60341505784676354,
  "created_at" : "2011-04-19 13:58:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AB (\u975E\u516C\u5F0Fbot)",
      "screen_name" : "miruka_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "118009758",
      "id" : 118009758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60340863766761472",
  "geo" : { },
  "id_str" : "60341319389818880",
  "in_reply_to_user_id" : 118009758,
  "text" : "@miruka_bot 5",
  "id" : 60341319389818880,
  "in_reply_to_status_id" : 60340863766761472,
  "created_at" : "2011-04-19 13:57:46 +0000",
  "in_reply_to_screen_name" : "miruka_bot",
  "in_reply_to_user_id_str" : "118009758",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60339614241660928",
  "text" : "\u3042\u3001\u305D\u308C\u724C\u3092\u89E6\u308B\u9EBB\u96C0\u3058\u3083\u306A\u3044\u3063\uFF01",
  "id" : 60339614241660928,
  "created_at" : "2011-04-19 13:50:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60339526891089920",
  "text" : "\uFF34\uFF2C\u306B\u5929\u9CF3\u306E\u500B\u5BA4\uFF35\uFF32\uFF2C\u8CBC\u308A\u4ED8\u3051\u305F\u3089\u4EBA\u96C6\u307E\u308B\u3093\u3058\u3083\u306D\uFF1F\u3068\u304B\u3075\u3068\u601D\u3063\u3066\u307F\u305F\u3002",
  "id" : 60339526891089920,
  "created_at" : "2011-04-19 13:50:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60339188565942273",
  "text" : "\u305D\u308D\u305D\u308D\u724C\u3092\u89E6\u308B\u9EBB\u96C0\u3092\u3084\u308A\u305F\u3044\u9803\u3060\u306A\u30FC\u3002\u30BB\u30C3\u30C6\u30A3\u30F3\u30B0\u3067\u304D\u308B\u304B\u306A\u30FC\u3002",
  "id" : 60339188565942273,
  "created_at" : "2011-04-19 13:49:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60337350248636416",
  "geo" : { },
  "id_str" : "60337984263819265",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u9EBB\u96C0\u3064\u3044\u3066\u308B\u306E\u304B\uFF57",
  "id" : 60337984263819265,
  "in_reply_to_status_id" : 60337350248636416,
  "created_at" : "2011-04-19 13:44:31 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60334143468355584",
  "geo" : { },
  "id_str" : "60334734458363904",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u3063\u305F\u304B\u304F\u3057\u3066\u6CA2\u5C71\u5BDD\u308B\u306E\u304C\u4E00\u756A\u3068\u601D\u3046\u3088\u30FC",
  "id" : 60334734458363904,
  "in_reply_to_status_id" : 60334143468355584,
  "created_at" : "2011-04-19 13:31:36 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60333001954967552",
  "text" : "\u3055\u3063\u304D\u307F\u305F\u3044\u306A\u306E\u3063\u3066\u4F55\u56DE\u3082\u540C\u3058\u306E\u3092\u6D41\u3057\u305F\u307B\u3046\u304C\u3044\u3044\u306E\u304B\u306A\uFF1F\u9B31\u9676\u3057\u304F\u306A\u3044\u3060\u308D\u3046\u304B\uFF1F",
  "id" : 60333001954967552,
  "created_at" : "2011-04-19 13:24:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60332449514795008",
  "text" : "\uFF21\uFF30\uFF29\u5236\u9650\u306E\u30AB\u30A6\u30F3\u30BF\u30FC\u3092\u3064\u3051\u308B\u6A5F\u80FD\u304C\u3042\u3063\u305F\u3002\u306A\u3093\u304B\u3084\u308B\u30681\u6E1B\u3063\u3066\u3001350\u56DE\u3084\u3063\u305F\u308960\u5206\u5236\u9650\u3002\u5C11\u3057\u6C17\u3092\u4ED8\u3051\u3088\u3046\u3002\u81EA\u52D5\u66F4\u65B0\u30671\u5206\u306B1\u300160\u5206\u306760\u6E1B\u308B\u304B\u3089\u5B9F\u8CEA290 \u3084\u305F\u3089\u3081\u3063\u305F\u3089\u66F4\u65B0\u30DC\u30BF\u30F3\u62BC\u3059\u306E\u306F\u3084\u3081\u306B\u3057\u3088\u3046\u3002",
  "id" : 60332449514795008,
  "created_at" : "2011-04-19 13:22:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60331096381997056",
  "text" : "\uFF21\uFF30\uFF29\u5236\u9650\u306A\u3093\u3068\u304B\u306A\u3089\u3093\u304B\u306A\u30FC",
  "id" : 60331096381997056,
  "created_at" : "2011-04-19 13:17:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u305F\u304B(\u03B8\u03C9\u03B8)",
      "screen_name" : "Cutiebuono",
      "indices" : [ 28, 39 ],
      "id_str" : "203850426",
      "id" : 203850426
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 44, 55 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 60, 70 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60329076593926144",
  "text" : "\u305D\u308C\uFF32\uFF34\u3057\u3066\u3069\u30FC\u3059\u3093\u3067\u3059\u304B\uFF57\uFF57\uFF57\uFF57\u3068\u304B\u8A00\u3044\u3064\u3064\u4FFA\u3082RT @Cutiebuono: RT @magokoro84: RT @end313124: \u3088\u304B\u3063\u305F\u3089\uFF32\uFF34\u3057\u3066\u304F\u308C\u308B\u3068\u3046\u308C\u3057\u3044\u306A\u3002\u88AB\u30D5\u30A9\u30ED\u30A2\u30FC\u5897\u3084\u3057\u3002",
  "id" : 60329076593926144,
  "created_at" : "2011-04-19 13:09:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60328644228288514",
  "text" : "\u3088\u304B\u3063\u305F\u3089\uFF32\uFF34\u3057\u3066\u304F\u308C\u308B\u3068\u3046\u308C\u3057\u3044\u306A\u3002\u88AB\u30D5\u30A9\u30ED\u30A2\u30FC\u5897\u3084\u3057\u3002",
  "id" : 60328644228288514,
  "created_at" : "2011-04-19 13:07:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "math",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60328520567631872",
  "text" : "\u3010\uFF32\uFF34\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 60328520567631872,
  "created_at" : "2011-04-19 13:06:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60325690205159424",
  "text" : "\u81EA\u5DF1\u7D39\u4ECB\u5897\u3084\u3057\u3066\u307F\u307E\u3057\u305F\u3002\u6C17\u306B\u306A\u308B\u4EBA\u306F\u3069\u3046\u305E\u3002\u77E5\u3089\u306A\u3044\u4EBA\u3082\u5897\u3048\u3066\uFF08\u5897\u3084\u3057\u3066\uFF09\u6765\u305F\u3057\u306D\u3047",
  "id" : 60325690205159424,
  "created_at" : "2011-04-19 12:55:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 12, 18 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60318849169489920",
  "text" : "\u795E\u201D\u30D0\u30EB\u30B9\u201D\u308B\u6CB3\u3000RT @hyuki: \u30AF\u30A4\u30BA\u3002\u5316\u7269\u8A9E\u306E\u307B\u3081\u6BBA\u3057\u30AD\u30E3\u30E9\u306B\u3057\u3066\u30D0\u30B9\u30B1\u306E\u30A8\u30FC\u30B9\u3001\u795E\u539F\u99FF\u6CB3\u304C\u30E9\u30D4\u30E5\u30BF\u306B\u4F4F\u3081\u306A\u3044\u7406\u7531\u306F\uFF1F",
  "id" : 60318849169489920,
  "created_at" : "2011-04-19 12:28:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 71, 76 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 80, 92 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60211286339887104",
  "text" : "\u7D20\u6575\u3068\u7D20\u6570\u3092\u3088\u304F\u898B\u9593\u9055\u3048\u308B\u6587\u5B66\u90E8\u306A\u3089\u3053\u3053\u306B\u3002 RT @haru_urah_rah: \u7D20\u6570\u306A\u4EF2\u9593\u304C\u6CA2\u5C71\u3044\u307E\u3059\u3088\uFF01\u306A\u3093\u3066\u7D20\u6570\u306A\u306E\uFF01\u7B11\u7B11-&gt; @np2i RT @undefined_k: \u3059\u3093\u3052\u3047\u3001\u3088\u304F\u5206\u304B\u308B\uFF01\u201C@yurily924: \u7D20\u6575\u3068\u7D20\u6570\u3092\u826F\u304F\u898B\u9593\u9055\u3048\u308B\u7406\u5B66\u90E8\u306F\u79C1\u3060\u3051\uFF1F\uFF1F",
  "id" : 60211286339887104,
  "created_at" : "2011-04-19 05:21:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60166649059352577",
  "geo" : { },
  "id_str" : "60167066161909760",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6301\u3061\u70B9\u7A81\u7136\u805E\u304B\u308C\u3066\u3082\u56F0\u3089\u306A\u3044\u3088\u3046\u306B\u70B9\u68D2\u8A08\u7B97\u6A5F\u3092\u4F5C\u3063\u305F\u3093\u3060\u306A\u3001\u3068\u601D\u3046\u3068\u80F8\u71B1\u3002",
  "id" : 60167066161909760,
  "in_reply_to_status_id" : 60166649059352577,
  "created_at" : "2011-04-19 02:25:21 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60152924977893376",
  "text" : "\u7121\u7CD6\u306E\u7D05\u8336\u3092\u624B\u306B\u3068\u3063\u305F\u306F\u305A\u306A\u306E\u306B\u3001\u98F2\u3080\u3068\u304D\u5348\u5F8C\u30C6\u30A3\u30FC\u306E\u30B9\u30C8\u30EC\u30FC\u30C8\uFF08\u7B11\uFF09\u3068\u6C17\u3065\u3044\u305F\u3002\u7A7A\u9593\u5EA7\u6A19\u304C\u30BA\u30EC\u3066\u305F\u306A\u3002",
  "id" : 60152924977893376,
  "created_at" : "2011-04-19 01:29:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60151456828899328",
  "text" : "\u6700\u9AD8\u6C17\u6E29\u524D\u65E5\u5DEE\uFF15\u5EA6\u304B\u3002\u808C\u5BD2\u3044\u308F\u3051\u3060\u3002",
  "id" : 60151456828899328,
  "created_at" : "2011-04-19 01:23:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60150031667298304",
  "text" : "\u85AC\u306E\u307F\u640D\u306D\u305F\uFF67\u2026\u3002\u82B1\u7C89\u306F\u5C11\u306A\u305D\u3046\u3060\u3051\u3069\u9F3B\u708E\u3068\u4F75\u767A\u3060\u304B\u3089\u5BD2\u3055\u3067\u3082\u3060\u3081\u3002\u96E8\u964D\u308A\u305D\u3046\u3060\u3057\u6182\u9B31\u306D\u3047\u2026\u3002",
  "id" : 60150031667298304,
  "created_at" : "2011-04-19 01:17:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60124277516668928",
  "text" : "\u304A\u306F\u3088\u30FC",
  "id" : 60124277516668928,
  "created_at" : "2011-04-18 23:35:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60003406059798528",
  "text" : "\u3053\u306E\u6642\u9593\u306B\u7720\u304F\u306A\u308B\u306E\u306F\u826F\u304D\u54C9\u3002",
  "id" : 60003406059798528,
  "created_at" : "2011-04-18 15:35:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B7\u30E3\u30FC\u30ED\u30C3\u30AF\u30FB\u30B7\u30A7\u30EA\u30F3\u30D5\u30A9\u30FC\u30C9",
      "screen_name" : "sharo_bot",
      "indices" : [ 0, 10 ],
      "id_str" : "216702459",
      "id" : 216702459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60002203062120448",
  "geo" : { },
  "id_str" : "60003087481450496",
  "in_reply_to_user_id" : 216702459,
  "text" : "@sharo_bot \u3064\u30D0\u30CA\u30CA",
  "id" : 60003087481450496,
  "in_reply_to_status_id" : 60002203062120448,
  "created_at" : "2011-04-18 15:33:45 +0000",
  "in_reply_to_screen_name" : "sharo_bot",
  "in_reply_to_user_id_str" : "216702459",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60001215009931264",
  "text" : "@haru_urah_rah \u4ECA\u65E5\u306F\u3088\u304F\u5BDD\u3066\u201D\u4ECA\u65E5\u201D\u2190\u3082\u96C6\u4E2D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 60001215009931264,
  "created_at" : "2011-04-18 15:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59991983845945344",
  "geo" : { },
  "id_str" : "59992307809787904",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u3084\u3001\u3042\u306E\u30D3\u30E9\u3067\u65B0\u5165\u751F\u6765\u305F\u304B\u3089\u305D\u3063\u3061\u512A\u5148\u3067\u3044\u3044\u304B\u306A\u30FC\u3068\u3002\u307E\u3041\u53BB\u5E74\u3082\u51FA\u3066\u305F\u3057\u5E73\u6C17\u304B\u306A\u30FC\u3002",
  "id" : 59992307809787904,
  "in_reply_to_status_id" : 59991983845945344,
  "created_at" : "2011-04-18 14:50:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59991104929538048",
  "text" : "@koketomi \u304A\u3048\u304A\u3048\u3063\u3066\u5168\u7136\u3054\u6A5F\u5ACC\u306B\u805E\u3053\u3048\u306A\u3044\u3060\u304C\uFF57\uFF57",
  "id" : 59991104929538048,
  "created_at" : "2011-04-18 14:46:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59990417470529536",
  "geo" : { },
  "id_str" : "59990904823496705",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u660E\u65E5\u306E\u8AAC\u660E\u4F1A\u884C\u304F?",
  "id" : 59990904823496705,
  "in_reply_to_status_id" : 59990417470529536,
  "created_at" : "2011-04-18 14:45:20 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59989131111043072",
  "geo" : { },
  "id_str" : "59990347824107520",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30D5\u30E9\u8A9E\u5F8C\u671F\u5206call\u53D6\u3063\u3066\u305F\u3063\u3051\uFF1F",
  "id" : 59990347824107520,
  "in_reply_to_status_id" : 59989131111043072,
  "created_at" : "2011-04-18 14:43:08 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59987059766607872",
  "geo" : { },
  "id_str" : "59987979220946944",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3082\u3057\u3083\u3082\u3057\u3083",
  "id" : 59987979220946944,
  "in_reply_to_status_id" : 59987059766607872,
  "created_at" : "2011-04-18 14:33:43 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59987059766607872",
  "geo" : { },
  "id_str" : "59987305838018560",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math 5",
  "id" : 59987305838018560,
  "in_reply_to_status_id" : 59987059766607872,
  "created_at" : "2011-04-18 14:31:02 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59984049632055296",
  "text" : "RT @Kaibun_bot: \u8001\u5A46\u300C\u30B3\u30CA\u30F3\u5909\u306A\u5B50\u300D\u300C\u30D0\u30FC\u30ED\u30FC\u300D\u3000\uFF08\u308D\u30FC\u3070\u3053\u306A\u3093\u3078\u3093\u306A\u3053\u3070\u30FC\u308D\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59983597876154368",
    "text" : "\u8001\u5A46\u300C\u30B3\u30CA\u30F3\u5909\u306A\u5B50\u300D\u300C\u30D0\u30FC\u30ED\u30FC\u300D\u3000\uFF08\u308D\u30FC\u3070\u3053\u306A\u3093\u3078\u3093\u306A\u3053\u3070\u30FC\u308D\uFF09 #kaibun",
    "id" : 59983597876154368,
    "created_at" : "2011-04-18 14:16:18 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 59984049632055296,
  "created_at" : "2011-04-18 14:18:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59964548790222849",
  "text" : "RT @tameninaru: \u30B2\u30B2\u30B2\u306E\u9B3C\u592A\u90CE\u306E\u306D\u305A\u307F\u7537\u306E\u672C\u540D\u306F\u3001\u306D\u305A\u307F\u30DA\u30B1\u30DA\u30B1\u3002\u30CF\u30F3\u30AC\u30EA\u30FC\u51FA\u8EAB\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59964403470172160",
    "text" : "\u30B2\u30B2\u30B2\u306E\u9B3C\u592A\u90CE\u306E\u306D\u305A\u307F\u7537\u306E\u672C\u540D\u306F\u3001\u306D\u305A\u307F\u30DA\u30B1\u30DA\u30B1\u3002\u30CF\u30F3\u30AC\u30EA\u30FC\u51FA\u8EAB\u3002",
    "id" : 59964403470172160,
    "created_at" : "2011-04-18 13:00:02 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 59964548790222849,
  "created_at" : "2011-04-18 13:00:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59964322260066304",
  "text" : "RT @wwwwww_bot: \u3055\u3057\u3059\u305B\u305D\u3000\u3000\u3055\u3068\u3046\u3058\u3087\u3046\u3086\u3000\u3057\u3087\u3046\u3086\u3000\u3059\u3058\u3087\u3046\u3086\u3000\u305B\u3046\u3086\u3000\u30BD\u30A4\u30BD\u30FC\u30B9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59961309738971136",
    "text" : "\u3055\u3057\u3059\u305B\u305D\u3000\u3000\u3055\u3068\u3046\u3058\u3087\u3046\u3086\u3000\u3057\u3087\u3046\u3086\u3000\u3059\u3058\u3087\u3046\u3086\u3000\u305B\u3046\u3086\u3000\u30BD\u30A4\u30BD\u30FC\u30B9",
    "id" : 59961309738971136,
    "created_at" : "2011-04-18 12:47:44 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 59964322260066304,
  "created_at" : "2011-04-18 12:59:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59960182922424320",
  "text" : "\u30D0\u30B9\u9154\u3044\uFF6A\u2026",
  "id" : 59960182922424320,
  "created_at" : "2011-04-18 12:43:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59957542624837632",
  "geo" : { },
  "id_str" : "59957915683008512",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod mixi\u3068\u304B\u9AD8\u6821\u306E\u53CB\u4EBA\u3068\u306E\u9023\u7D61\u7528\u307F\u305F\u3044\u306B\u306A\u3063\u3066\u307E\u3059\u3002\u6B63\u76F4\u5EC3\u308C\u305F\u611F\u304C\u2026\u3002",
  "id" : 59957915683008512,
  "in_reply_to_status_id" : 59957542624837632,
  "created_at" : "2011-04-18 12:34:15 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59956079072788482",
  "text" : "\u7A7A\u3092\u98DB\u3076\u5922\u306E\u723D\u5FEB\u611F\u306F\u7570\u5E38",
  "id" : 59956079072788482,
  "created_at" : "2011-04-18 12:26:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59954160400990208",
  "text" : "\u305B\u3063\u304B\u304F\u545F\u3044\u3066\u3044\u308B\u306E\u3060\u304B\u3089\u88AB\u30D5\u30A9\u30ED\u30A2\u30FC\u5897\u3084\u305D\u3046\u304B\u306A\u30FC\u3001\u3068\u601D\u3046\u4E00\u65B9\u3067\u30C1\u30E9\u30B7\u306E\u88CF\u3060\u304B\u3089\u4ED6\u4EBA\u306B\u898B\u305B\u3066\u3082\u8AB0\u5F97\u611F\u304C\u3042\u308B\u30A2\u30F3\u30D3\u30D0\u30EC\u30F3\u30C8",
  "id" : 59954160400990208,
  "created_at" : "2011-04-18 12:19:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59922180976295936",
  "text" : "\u3084\u3063\u3071\u30D0\u30B9\u3063\u3066\u82E6\u624B\u2026\u9589\u585E\u611F\u3068\u529B\u5B66\u304C\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u305B\u3044\u3067\u9154\u3046\u3002",
  "id" : 59922180976295936,
  "created_at" : "2011-04-18 10:12:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u535A\u9E97\u795E\u4E3B",
      "screen_name" : "korindo",
      "indices" : [ 3, 11 ],
      "id_str" : "20603690",
      "id" : 20603690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59899410758369280",
  "text" : "RT @korindo: \u3048\u3063\uFF1F \u6771\u65B9\u304C\u30AE\u30CD\u30B9\u5165\u308A\u3057\u305F\u306E\uFF1F \u3053\u308C\u3067\u50D5\u3082\u4E16\u754C\u4E00\u306E\u4EF2\u9593\u5165\u308A\u3060\u306D\u3002  http:\/\/www.guinnessworldrecords.com\/Search\/Details\/Mostprolific-fan-made-shooter-series\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/apps.studiohitori.com\/twitrocker\" rel=\"nofollow\"\u003ETwitRocker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59893105398267904",
    "text" : "\u3048\u3063\uFF1F \u6771\u65B9\u304C\u30AE\u30CD\u30B9\u5165\u308A\u3057\u305F\u306E\uFF1F \u3053\u308C\u3067\u50D5\u3082\u4E16\u754C\u4E00\u306E\u4EF2\u9593\u5165\u308A\u3060\u306D\u3002  http:\/\/www.guinnessworldrecords.com\/Search\/Details\/Mostprolific-fan-made-shooter-series\/73841.htm",
    "id" : 59893105398267904,
    "created_at" : "2011-04-18 08:16:43 +0000",
    "user" : {
      "name" : "\u535A\u9E97\u795E\u4E3B",
      "screen_name" : "korindo",
      "protected" : false,
      "id_str" : "20603690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320600350\/IMG_0043bs_normal.jpg",
      "id" : 20603690,
      "verified" : true
    }
  },
  "id" : 59899410758369280,
  "created_at" : "2011-04-18 08:41:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59886176148000768",
  "text" : "\u5E30\u5B85\u2026",
  "id" : 59886176148000768,
  "created_at" : "2011-04-18 07:49:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59877587773702144",
  "text" : "\u75DB\u6068\u306E\u30DF\u30B9\u306B\u6C17\u3065\u3044\u305F",
  "id" : 59877587773702144,
  "created_at" : "2011-04-18 07:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59852404203593729",
  "text" : "\u306A\u3093\u3067\u30B5\u30F3\u30AF\u30B9\u30EA\u30C3\u30C8\u8A9E\u306B\u3064\u3044\u3066\u71B1\u304F\u8A9E\u3063\u3066\u308B\u306E\u3001\u8A33\u304C\u308F\u304B\u3089\u306A\u3044\u3088\uFF1B\uFF1B",
  "id" : 59852404203593729,
  "created_at" : "2011-04-18 05:34:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59852138653822976",
  "text" : "\u5C0F\u96E8\uFF6A\u2026\u3002",
  "id" : 59852138653822976,
  "created_at" : "2011-04-18 05:33:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59827241005232128",
  "text" : "\u6587\u5B66\u90E8\u30E9\u30A6\u30F3\u30B8\u3002\uFF14\u9650\u307E\u3067\u6570\u5B57\u5F04\u308A\u3002\u660E\u3089\u304B\u306A\u7551\u9055\u3044\u3002",
  "id" : 59827241005232128,
  "created_at" : "2011-04-18 03:55:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "\u03BA\u306D\u3053\u305B\u3093",
      "screen_name" : "necocen",
      "indices" : [ 26, 34 ],
      "id_str" : "14087520",
      "id" : 14087520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59818361210667008",
  "text" : "RT @hyuki: \u6570\u5B66\u304C\u3042\u308B\u30AC\u30FC\u30EB\u3068\u304B\u3002 RT @necocen: \u6570\u5B66\u30AC\u30FC\u30EB\u304C\u3042\u308B\u3002\u56DB\u518A\u76EE\u8CB7\u308F\u306A\u3044\u3068",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u03BA\u306D\u3053\u305B\u3093",
        "screen_name" : "necocen",
        "indices" : [ 15, 23 ],
        "id_str" : "14087520",
        "id" : 14087520
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59816454454902784",
    "text" : "\u6570\u5B66\u304C\u3042\u308B\u30AC\u30FC\u30EB\u3068\u304B\u3002 RT @necocen: \u6570\u5B66\u30AC\u30FC\u30EB\u304C\u3042\u308B\u3002\u56DB\u518A\u76EE\u8CB7\u308F\u306A\u3044\u3068",
    "id" : 59816454454902784,
    "created_at" : "2011-04-18 03:12:08 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 59818361210667008,
  "created_at" : "2011-04-18 03:19:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 3, 13 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59807785948430336",
  "text" : "RT @maru_mtod: \u9AD8\u6821\u6570\u5B66\u306F\u7AAE\u5C48\u3067\u72ED\u3044\u4E16\u754C\u3068\u3044\u3046\u611F\u3058\u3060\u3063\u305F\u3051\u3069 \u5927\u5B66\u6570\u5B66\u306F\u5E83\u304C\u308A\u3059\u304E\u3066\u53CE\u62FE\u3064\u304B\u306A\u3044\u611F\u3058",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59802638543360000",
    "text" : "\u9AD8\u6821\u6570\u5B66\u306F\u7AAE\u5C48\u3067\u72ED\u3044\u4E16\u754C\u3068\u3044\u3046\u611F\u3058\u3060\u3063\u305F\u3051\u3069 \u5927\u5B66\u6570\u5B66\u306F\u5E83\u304C\u308A\u3059\u304E\u3066\u53CE\u62FE\u3064\u304B\u306A\u3044\u611F\u3058",
    "id" : 59802638543360000,
    "created_at" : "2011-04-18 02:17:14 +0000",
    "user" : {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "protected" : true,
      "id_str" : "131534834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2637146392\/f145e81f3a6524c5f749f3f38ea7e64d_normal.jpeg",
      "id" : 131534834,
      "verified" : false
    }
  },
  "id" : 59807785948430336,
  "created_at" : "2011-04-18 02:37:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59789758196498435",
  "text" : "@nico_reflexio \u305D\u3093\u306A\u6642\u9593\u3067\u5927\u4E08\u592B\u304B\uFF1F\uFF57\u4EBA\u6765\u308B\u306E\u304B\uFF1F",
  "id" : 59789758196498435,
  "created_at" : "2011-04-18 01:26:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59751390586740736",
  "geo" : { },
  "id_str" : "59751680165687296",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u306F\u3088\u3046\u3002",
  "id" : 59751680165687296,
  "in_reply_to_status_id" : 59751390586740736,
  "created_at" : "2011-04-17 22:54:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59750968912384000",
  "text" : "\uFF34\uFF2C\u4E0Abot\u3057\u304B\u3044\u306A\u3044\u2026",
  "id" : 59750968912384000,
  "created_at" : "2011-04-17 22:51:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59748053149683712",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u5915\u65B9\u96E8\u304B\u2026\u6182\u9B31\u2026\u3002",
  "id" : 59748053149683712,
  "created_at" : "2011-04-17 22:40:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59638632025300992",
  "text" : "\u3055\u3001\u5BDD\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 59638632025300992,
  "created_at" : "2011-04-17 15:25:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59638509501288448",
  "text" : "\u3055\u3063\u304D\u306E\u30C4\u30A4\u30FC\u30C8\u539F\u70B9\u3058\u3083\u306A\u304F\u3068\u3042\u308B\u70B9\u3060\u3063\u305F\u306A\u3041\u3002\u5931\u6557\u3002",
  "id" : 59638509501288448,
  "created_at" : "2011-04-17 15:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59633968429023232",
  "geo" : { },
  "id_str" : "59635028950401024",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5B9F\u306F\u3053\u3063\u3061\u3067\u670D\u8CB7\u3063\u3066\u306A\u3044\u3093\u3060\u304C\u3069\u3053\u3067\u8CB7\u3046\u306E\uFF1F",
  "id" : 59635028950401024,
  "in_reply_to_status_id" : 59633968429023232,
  "created_at" : "2011-04-17 15:11:13 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59632854920998912",
  "text" : "\u3053\u308C\u306F \u5730\u5473\u3060\u3051\u3069 \u304A\u3082\u3057\u308D\u3044\u304B\u3082\u306D  http:\/\/togetter.com\/li\/123872",
  "id" : 59632854920998912,
  "created_at" : "2011-04-17 15:02:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59631344610848768",
  "text" : "\u3053\u306E\u554F\u984C\u89E3\u3044\u3066\u3055\u3048\u3044\u306A\u3044\u3051\u3069\u2026",
  "id" : 59631344610848768,
  "created_at" : "2011-04-17 14:56:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6570\u5B66\u554F\u984Cbot",
      "screen_name" : "mathematics_bot",
      "indices" : [ 56, 72 ],
      "id_str" : "96739891",
      "id" : 96739891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59629647876456448",
  "geo" : { },
  "id_str" : "59631171750985728",
  "in_reply_to_user_id" : 96739891,
  "text" : "\u3082\u3057\u304B\u3057\u3066\uFF4E\u6B21\u5143\u7A7A\u9593\u3067\u306E\u539F\u70B9\u304B\u3089\u306E\u8DDD\u96E2\u304C\u4E00\u5B9A\u306E\u70B9\u306E\u96C6\u5408\uFF08\u4E8C\u6B21\u306A\u3089\u5186\u3001\u4E09\u6B21\u306A\u3089\u7403\uFF09\u306F\uFF4E+\uFF11\u3064\u306E\u70B9\u3067\u5B9A\u307E\u308B\uFF1F QT @mathematics_bot: \u7A7A\u9593\u5185\u306B\u56DB\u9762\u4F53ABCD\u3092\u8003\u3048\u308B\u3002\u3053\u306E\u3068\u304D\u3001\uFF14\u3064\u306E\u9802\u70B9A,B,C,D\u3092\u540C\u6642\u306B\u901A\u308B\u7403\u9762\u304C\u5B58\u5728\u3059\u308B\u3053\u3068\u3092\u793A\u305B\u3002\uFF08\uFF11\uFF11\u4EAC\u5927\u30FB\u7406\uFF09 #math",
  "id" : 59631171750985728,
  "in_reply_to_status_id" : 59629647876456448,
  "created_at" : "2011-04-17 14:55:53 +0000",
  "in_reply_to_screen_name" : "mathematics_bot",
  "in_reply_to_user_id_str" : "96739891",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59628405729136640",
  "text" : "\uFF30\uFF23\u843D\u3068\u3057\u3066\u5BDD\u308B\u614B\u52E2\u306B\u5165\u308D\u3046\u3002\u643A\u5E2F\u304B\u3089\u3064\u3076\u3084\u304F\u3068\u306F\u601D\u3046\u3051\u3069\u3002",
  "id" : 59628405729136640,
  "created_at" : "2011-04-17 14:44:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 20, 29 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59627427470647297",
  "text" : "\u4E00\u6587\u5B57\u3082\u5165\u3063\u3066\u306D\u3047\u3058\u3083\u306D\u3047\u304B\uFF57\uFF57\uFF57RT @nisehorn: \u3068\u3082\u3061\u3063\u3066\u4F55\u6587\u5B57\u304B\u304B\u3048\u305F\u3089\u30E1\u30ED\u30B9\u30AF\u30E9\u30B9\u30BF\u3058\u3083\u3093",
  "id" : 59627427470647297,
  "created_at" : "2011-04-17 14:41:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59627107768213504",
  "text" : "\u6570\u4EBA\u3057\u304B\u898B\u3066\u306A\u3044\u304C\u4E8C\u30A2\u30EA\u30FC\u30A4\u30B3\u30FC\u30EB\u304B\u30D5\u30A9\u30ED\u30A2\uFF1C\u88AB\u30D5\u30A9\u30ED\u30A2\u306A\u3093\u3060\u304C",
  "id" : 59627107768213504,
  "created_at" : "2011-04-17 14:39:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59626844923768833",
  "text" : "\u3042\u308C\uFF1F\u3082\u3057\u304B\u3057\u3066\u30D5\u30A9\u30ED\u30A2\u30FC\uFF1E\uFF1E\u88AB\u30D5\u30A9\u30ED\u30A2\u30FC\u3063\u3066\u4E0D\u81EA\u7136\uFF1F",
  "id" : 59626844923768833,
  "created_at" : "2011-04-17 14:38:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59626249215152129",
  "geo" : { },
  "id_str" : "59626422687383552",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u4EBA\u9593\u3044\u3064\u304B\u306F\u6B7B\u306C\u3093\u3060\u3088\u3002\u899A\u3048\u3066\u304A\u304D\u306A\u3055\u3044\u3002",
  "id" : 59626422687383552,
  "in_reply_to_status_id" : 59626249215152129,
  "created_at" : "2011-04-17 14:37:01 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59626111713296385",
  "text" : "\u7720\u304F\u306A\u3063\u3066\u304D\u305F\u30FC",
  "id" : 59626111713296385,
  "created_at" : "2011-04-17 14:35:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59622292384251905",
  "geo" : { },
  "id_str" : "59622553727139841",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u524D\u304C\u3089\u3057\u304F\u306A\u304B\u3063\u305F\u3089\u4FFA\u306F\u3069\u3046\u306A\u3063\u3066\u3057\u307E\u3046\u306E\uFF1B\uFF1B",
  "id" : 59622553727139841,
  "in_reply_to_status_id" : 59622292384251905,
  "created_at" : "2011-04-17 14:21:39 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3054\u307F\u53CE\u96C6\u8005",
      "screen_name" : "cruz__F",
      "indices" : [ 0, 8 ],
      "id_str" : "2615705894",
      "id" : 2615705894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59617226046709761",
  "geo" : { },
  "id_str" : "59621750266265600",
  "in_reply_to_user_id" : 116143819,
  "text" : "@cruz__F \u7A81\u7136\u3059\u307F\u307E\u305B\u3093\u3002\u4F55\u304B\u3092\u3001\u77E5\u3089\u306A\u3044\u3001\u77E5\u3089\u306A\u3044\u304B\u3089\u89E3\u3051\u306A\u3044\u3001\u9580\u524D\u6255\u3044\u3055\u308C\u308B\u306E\u304C\u5ACC\u3060\u304B\u3089\u52C9\u5F37\u3092\u3059\u308B\u3093\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u306D\u3002\u50D5\u3082\u3086\u3068\u308A\u4E16\u4EE3\u3067\u306F\u3042\u308A\u307E\u3059\u304C\u2026\u3002",
  "id" : 59621750266265600,
  "in_reply_to_status_id" : 59617226046709761,
  "created_at" : "2011-04-17 14:18:27 +0000",
  "in_reply_to_screen_name" : "0scarfe",
  "in_reply_to_user_id_str" : "116143819",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59609599787024384",
  "geo" : { },
  "id_str" : "59612338130665472",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u3053\u3053\u308D\u3061\u3083\u3093\u30D0\u30AB\u306A\u306E\uFF1F",
  "id" : 59612338130665472,
  "in_reply_to_status_id" : 59609599787024384,
  "created_at" : "2011-04-17 13:41:03 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9CF4\u6D77\u2606\u8358\u5409@\uFF75\uFF8C\uFF9F\uFF83\uFF68\uFF8F\uFF7D\u611B\u3057\u3066\u308B",
      "screen_name" : "zeroberiaru",
      "indices" : [ 3, 15 ],
      "id_str" : "200807339",
      "id" : 200807339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59608101308997632",
  "text" : "RT @zeroberiaru: \u660E\u3000\u65E5\u3000\u5B66\u3000\u6821\u3000\u30C0\u3000\u30EB\u3000\u3044\u3000\u4EBA\u3000\u306F\u3000\u6B63\u3000\u76F4\u3000\u306B\u3000\u516C\u3000\u5F0F\u3000R\u3000T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitbeam.jp\/\" rel=\"nofollow\"\u003Etwitbeam[\uFF82\uFF72\uFF6F\uFF84\uFF8B\uFF9E\uFF70\uFF91]\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59587250752720896",
    "text" : "\u660E\u3000\u65E5\u3000\u5B66\u3000\u6821\u3000\u30C0\u3000\u30EB\u3000\u3044\u3000\u4EBA\u3000\u306F\u3000\u6B63\u3000\u76F4\u3000\u306B\u3000\u516C\u3000\u5F0F\u3000R\u3000T",
    "id" : 59587250752720896,
    "created_at" : "2011-04-17 12:01:22 +0000",
    "user" : {
      "name" : "\u9CF4\u6D77\u2606\u8358\u5409@\uFF75\uFF8C\uFF9F\uFF83\uFF68\uFF8F\uFF7D\u611B\u3057\u3066\u308B",
      "screen_name" : "zeroberiaru",
      "protected" : false,
      "id_str" : "200807339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1351923708\/is_normal.jpg",
      "id" : 200807339,
      "verified" : false
    }
  },
  "id" : 59608101308997632,
  "created_at" : "2011-04-17 13:24:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59608078668140545",
  "text" : "\u305A\u3044\u3076\u3093\u524D\u306B\u8CB7\u3063\u305F\u306F\u305A\u306E\u624B\u62ED\u3044\u304C\u884C\u65B9\u4E0D\u660E\u2026\u3042\u308C\u3042\u308C\u3070\u30D6\u30C3\u30AF\u30AB\u30D0\u30FC\u4F5C\u308C\u308B\u306E\u306B\u306A\u30FC\u3002",
  "id" : 59608078668140545,
  "created_at" : "2011-04-17 13:24:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59603620005560320",
  "geo" : { },
  "id_str" : "59604204301451265",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u3048\u3001bot\u3067\u904A\u3076\u306E\u306F\u7570\u5E38\u306A\u3093\u3067\u3059\u304B\uFF1B\uFF1B",
  "id" : 59604204301451265,
  "in_reply_to_status_id" : 59603620005560320,
  "created_at" : "2011-04-17 13:08:44 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59600854549925888",
  "text" : "\u5B8C\u5168\u306B\u5730\u30C7\u30B8\u306B\u79FB\u884C\u3059\u308B\u306E\u3063\u3066\u3044\u3064\u3060\u3063\u3051\uFF1F",
  "id" : 59600854549925888,
  "created_at" : "2011-04-17 12:55:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59581180323971072",
  "geo" : { },
  "id_str" : "59583114514669568",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6253\u3061\u6B62\u3081\u306E\u8868\u60C5\u304C\uFF57\uFF57\uFF57\uFF57",
  "id" : 59583114514669568,
  "in_reply_to_status_id" : 59581180323971072,
  "created_at" : "2011-04-17 11:44:56 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7CD6\u985E\u306E\u4E0A",
      "screen_name" : "tinouye",
      "indices" : [ 3, 11 ],
      "id_str" : "33147484",
      "id" : 33147484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59578431008022528",
  "text" : "RT @tinouye: \u6DBC\u5BAE\u30CF\u30EB\u30D2\u306E\u4E00\u6319\u653E\u9001\u304CWOWOW\u3067\u3042\u308B\u305D\u3046\u3060\u304C\u3001\uFF12\u65E5\u76EE\u306E\u30A8\u30F3\u30C9\u30EC\u30B9\u30A8\u30A4\u30C8\uFF08\u7B2C\uFF11\uFF12\u8A71\u301C\u7B2C\uFF11\uFF19\u8A71\uFF09\u3060\u3051\u3063\u3066\u3001\u62F7\u554F\u3062\u3083\u306D\u3001\u3001\u3001 http:\/\/is.gd\/tGlaQF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59572968048697344",
    "text" : "\u6DBC\u5BAE\u30CF\u30EB\u30D2\u306E\u4E00\u6319\u653E\u9001\u304CWOWOW\u3067\u3042\u308B\u305D\u3046\u3060\u304C\u3001\uFF12\u65E5\u76EE\u306E\u30A8\u30F3\u30C9\u30EC\u30B9\u30A8\u30A4\u30C8\uFF08\u7B2C\uFF11\uFF12\u8A71\u301C\u7B2C\uFF11\uFF19\u8A71\uFF09\u3060\u3051\u3063\u3066\u3001\u62F7\u554F\u3062\u3083\u306D\u3001\u3001\u3001 http:\/\/is.gd\/tGlaQF",
    "id" : 59572968048697344,
    "created_at" : "2011-04-17 11:04:37 +0000",
    "user" : {
      "name" : "\u7CD6\u985E\u306E\u4E0A",
      "screen_name" : "tinouye",
      "protected" : false,
      "id_str" : "33147484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3020031188\/ce1a01d6aeabc26e21ff7d4a130be814_normal.jpeg",
      "id" : 33147484,
      "verified" : false
    }
  },
  "id" : 59578431008022528,
  "created_at" : "2011-04-17 11:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59567268501262336",
  "text" : "@ayu167 \u3044\u3084\u3001\u97F3\u30B2\u30FC\u30B5\u30FC\u30AF\u30EB\u306B\u671F\u5F85\u3001\u3063\u3066\u3053\u3068\u3002\u308F\u304B\u308A\u306B\u304F\u304B\u3063\u305F\u306A\u3002",
  "id" : 59567268501262336,
  "created_at" : "2011-04-17 10:41:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59566554286788608",
  "text" : "@ayu167 \uFF08\u97F3\u30B2\u30FC\u30B5\u30FC\u30AF\u30EB\uFF1F\uFF57\uFF09",
  "id" : 59566554286788608,
  "created_at" : "2011-04-17 10:39:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59559779760218112",
  "geo" : { },
  "id_str" : "59560125882568705",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u541B\u306F\u30D5\u30A3\u30DC\u30CA\u30C3\u30C1\u306B\u53CD\u5FDC\u3059\u308Bbot\u3058\u3083\u306A\u3044\u3067\u3057\u3087\uFF57\uFF57\uFF57\uFF57",
  "id" : 59560125882568705,
  "in_reply_to_status_id" : 59559779760218112,
  "created_at" : "2011-04-17 10:13:35 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59559529091829760",
  "text" : "1,1,2,3",
  "id" : 59559529091829760,
  "created_at" : "2011-04-17 10:11:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59554768997187584",
  "text" : "\u7AEF\u5207\u308C\u8CB7\u3063\u3066\u304D\u3066\u4F5C\u3063\u3066\u3057\u307E\u3046\u3068\u3044\u3046\u306E\u3082\u4E00\u8208\u304B\u306A\u3002",
  "id" : 59554768997187584,
  "created_at" : "2011-04-17 09:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59554677896921088",
  "text" : "\u30A2\u30DE\u30BE\u30F3\u3063\u3066\u4FBF\u5229\u3060\u3051\u3069\u672C\u8CB7\u3063\u3066\u30AB\u30D0\u30FC\u304C\u7121\u3044\u306E\u304C\u306A\u3041\u30FB\u30FB\u30FB\u3002",
  "id" : 59554677896921088,
  "created_at" : "2011-04-17 09:51:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59548041077723136",
  "text" : "\u7406\u7CFB\u306E\u305F\u3081\u306E\u3001\u3068\u304B\u5DE5\u5B66\u90E8\u5B66\u751F\u306E\u305F\u3081\u306E\u3001\u307F\u305F\u3044\u306A\u30C6\u30AD\u30B9\u30C8\u30BF\u30A4\u30C8\u30EB\u306B\u52DD\u624B\u306A\u53CD\u611F\u3092\u899A\u3048\u308B\u3002",
  "id" : 59548041077723136,
  "created_at" : "2011-04-17 09:25:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59546215221706752",
  "text" : "\u3082\u304618\u6642\u904E\u304E\u3066\u3093\u306E\u304B\u3002\u4E00\u65E5\u304C\u65E9\u3044\u3002Time flies like an arrow.",
  "id" : 59546215221706752,
  "created_at" : "2011-04-17 09:18:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59545714585382912",
  "text" : "@koketomi \u4FFA\u3082\u7B4D\u52E2\u3060\u306A\u3001\u3069\u3063\u3061\u3082\u305D\u3093\u306A\u306B\u3057\u3087\u3063\u3061\u3085\u3046\u98DF\u3079\u308B\u308F\u3051\u3058\u3083\u306A\u3044\u3051\u3069\u3002",
  "id" : 59545714585382912,
  "created_at" : "2011-04-17 09:16:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 4, 13 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59542632795344896",
  "text" : "\u306B\u305B\u307B\u30FC@nisehorn",
  "id" : 59542632795344896,
  "created_at" : "2011-04-17 09:04:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 6, 15 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59542575589232640",
  "in_reply_to_user_id" : 96348838,
  "text" : "\u306B\u305B\u307B\u30FC\n @nisehorn",
  "id" : 59542575589232640,
  "created_at" : "2011-04-17 09:03:50 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C7\u30FC\u30D6\u30FB\u30B9\u30DA\u30AF\u30BF\u30FC ",
      "screen_name" : "dave_spector",
      "indices" : [ 3, 16 ],
      "id_str" : "25991694",
      "id" : 25991694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59542036604399616",
  "text" : "RT @dave_spector: \u666E\u6BB5\u306F\u60AA\u3044\u610F\u5473\u306A\u3093\u3060\u3051\u3069\u3001\u3044\u307E\u306F\u3068\u3066\u3082\u5927\u5207\u306A\u3053\u3068\u308F\u3056\u2192\u51B7\u3084\u6C34\u3092\u6D74\u3073\u305B\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59541863891341312",
    "text" : "\u666E\u6BB5\u306F\u60AA\u3044\u610F\u5473\u306A\u3093\u3060\u3051\u3069\u3001\u3044\u307E\u306F\u3068\u3066\u3082\u5927\u5207\u306A\u3053\u3068\u308F\u3056\u2192\u51B7\u3084\u6C34\u3092\u6D74\u3073\u305B\u308B",
    "id" : 59541863891341312,
    "created_at" : "2011-04-17 09:01:01 +0000",
    "user" : {
      "name" : "\u30C7\u30FC\u30D6\u30FB\u30B9\u30DA\u30AF\u30BF\u30FC ",
      "screen_name" : "dave_spector",
      "protected" : false,
      "id_str" : "25991694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1002003570\/________normal.jpg",
      "id" : 25991694,
      "verified" : true
    }
  },
  "id" : 59542036604399616,
  "created_at" : "2011-04-17 09:01:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59520868149231616",
  "text" : "\u3080\u3045\u3002\u3002\u3002\u6628\u65E5\u3068\u540C\u3058\u6D41\u308C\u306B\u306A\u308A\u3064\u3064\u3042\u308B\u3002",
  "id" : 59520868149231616,
  "created_at" : "2011-04-17 07:37:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "indices" : [ 3, 15 ],
      "id_str" : "258721812",
      "id" : 258721812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59470254929215488",
  "text" : "RT @MyMathCloud: To think logically the logically thinkable -- that is the mathematician's aim. C. J. Keyser",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59470125081968640",
    "text" : "To think logically the logically thinkable -- that is the mathematician's aim. C. J. Keyser",
    "id" : 59470125081968640,
    "created_at" : "2011-04-17 04:15:57 +0000",
    "user" : {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "protected" : false,
      "id_str" : "258721812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2965777663\/5bb5d3206072ca9112470f291e368645_normal.png",
      "id" : 258721812,
      "verified" : false
    }
  },
  "id" : 59470254929215488,
  "created_at" : "2011-04-17 04:16:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "indices" : [ 3, 15 ],
      "id_str" : "258721812",
      "id" : 258721812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59465675957211137",
  "text" : "RT @MyMathCloud: The infinite! No other question has ever moved so profoundly the spirit of man.  David Hilbert",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59465514581372928",
    "text" : "The infinite! No other question has ever moved so profoundly the spirit of man.  David Hilbert",
    "id" : 59465514581372928,
    "created_at" : "2011-04-17 03:57:38 +0000",
    "user" : {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "protected" : false,
      "id_str" : "258721812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2965777663\/5bb5d3206072ca9112470f291e368645_normal.png",
      "id" : 258721812,
      "verified" : false
    }
  },
  "id" : 59465675957211137,
  "created_at" : "2011-04-17 03:58:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 3, 14 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59456470982459393",
  "text" : "RT @nisehorrrn: \u30D9\u30AF\u30C8\u30EB\u2192\u4E00\u65B9\u901A\u884C\u2192\u30EC\u30D9\u30EB5\n\u30D9\u30AF\u30EC\u30EB\u2192\u798F\u5CF6\u539F\u767A\u2192\u30EC\u30D9\u30EB7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59456121974427649",
    "text" : "\u30D9\u30AF\u30C8\u30EB\u2192\u4E00\u65B9\u901A\u884C\u2192\u30EC\u30D9\u30EB5\n\u30D9\u30AF\u30EC\u30EB\u2192\u798F\u5CF6\u539F\u767A\u2192\u30EC\u30D9\u30EB7",
    "id" : 59456121974427649,
    "created_at" : "2011-04-17 03:20:18 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "protected" : false,
      "id_str" : "229752118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009819094\/110325_010601a_normal.jpg",
      "id" : 229752118,
      "verified" : false
    }
  },
  "id" : 59456470982459393,
  "created_at" : "2011-04-17 03:21:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59454589447057408",
  "text" : "\u3088\u3057\u3001\u82F1\u8A9E\u7D42\u308F\u3063\u305F\u3057\u3001\u671D\uFF08\u663C\uFF09\u3054\u306F\u3093\u3068\u884C\u3053\u3046\u304B\u3002",
  "id" : 59454589447057408,
  "created_at" : "2011-04-17 03:14:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59441675512184833",
  "text" : "\u6628\u65E5\u4E00\u65E5\u7121\u99C4\u306B\u3057\u305F\u3057\u4ECA\u65E5\u306F\u6709\u610F\u7FA9\u306B\u904E\u3054\u305D\u3046\u3002",
  "id" : 59441675512184833,
  "created_at" : "2011-04-17 02:22:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59440167634747392",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 59440167634747392,
  "created_at" : "2011-04-17 02:16:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59300923989700608",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 59300923989700608,
  "created_at" : "2011-04-16 17:03:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AB (\u975E\u516C\u5F0Fbot)",
      "screen_name" : "miruka_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "118009758",
      "id" : 118009758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59288166464622593",
  "geo" : { },
  "id_str" : "59288330956832768",
  "in_reply_to_user_id" : 118009758,
  "text" : "@miruka_bot 1,1,2,3",
  "id" : 59288330956832768,
  "in_reply_to_status_id" : 59288166464622593,
  "created_at" : "2011-04-16 16:13:34 +0000",
  "in_reply_to_screen_name" : "miruka_bot",
  "in_reply_to_user_id_str" : "118009758",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59287694882250752",
  "text" : "\u3055\u3063\u304D\u306E\u3067\u53CD\u5FDC\u3057\u3066\u308B\u3057\uFF57\uFF57\u3053\u306E\u6642\u9593\u306B\u671D\u306E\u6328\u62F6\u3063\u3066\uFF57\uFF57\uFF57",
  "id" : 59287694882250752,
  "created_at" : "2011-04-16 16:11:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59287088792743937",
  "text" : "\u305A\u3044\u3076\u3093bot\u30D5\u30A9\u30ED\u30FC\u3057\u305F\u3051\u3069\u3002\u3053\u308C\u304A\u306F\u3088\u3046\u3068\u304B\u304A\u3084\u3059\u307F\u3068\u304B\u3059\u3054\u3044\u6CA2\u5C71\u53CD\u5FDC\u3055\u308C\u308B\u3093\u3058\u3083\u306A\u304B\u308D\u3046\u304B\u3002",
  "id" : 59287088792743937,
  "created_at" : "2011-04-16 16:08:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59285847144529920",
  "text" : "\u6642\u3005\u4E00\u6C17\u306B\u8AAD\u307F\u8FBC\u3080\u306A\u30FCsaezuri \u30A2\u30AF\u30BB\u30B9\u3057\u904E\u304E\u304C\u30C0\u30E1\u30C0\u30E1\u306A\u3093\u3060\u308D\u3046\u306A\u30FC\u3002",
  "id" : 59285847144529920,
  "created_at" : "2011-04-16 16:03:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59282499850878977",
  "geo" : { },
  "id_str" : "59285031402745856",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u305D\u3046\u3060\u306D\u3001\u82F1\u6587\u548C\u8A33\u3002",
  "id" : 59285031402745856,
  "in_reply_to_status_id" : 59282499850878977,
  "created_at" : "2011-04-16 16:00:27 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59281206159749120",
  "geo" : { },
  "id_str" : "59281665771573248",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u4ECA\u306F\u8AB2\u984C\u306E\u30B1\u30F3\u30D6\u30EA\u30C3\u30B8\u306E\u8AD6\u6587\u96C6\u306E\uFF08\u3082\u3061\u308D\u3093\u4E00\u90E8\u3001\u5185\u5BB9\u306F\u51B7\u6226\u306B\u3064\u3044\u3066\u3002\uFF09\u306E\u5168\u8A33\u3002\u82F1\u4F5C\u306E\u304C\u597D\u304D\u3060\u304B\u3089\u305D\u3063\u3061\u53D6\u308A\u305F\u304B\u3063\u305F\u3093\u3060\u3051\u3069\u3001\u6642\u9593\u5272\u306E\u90FD\u5408\u3067\u7121\u7406\u3060\u3063\u305F\u3093\u3060\u308F\u3002",
  "id" : 59281665771573248,
  "in_reply_to_status_id" : 59281206159749120,
  "created_at" : "2011-04-16 15:47:05 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 0, 15 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59280164911190016",
  "geo" : { },
  "id_str" : "59280309107163137",
  "in_reply_to_user_id" : 227502200,
  "text" : "@G4_Hirano_chan \u3082\u3046\u5BDD\u308B\u3068\u3053\u308D\u306A\u3093\u3060\u3051\u3069\u306A\u3002\u3002\u3002",
  "id" : 59280309107163137,
  "in_reply_to_status_id" : 59280164911190016,
  "created_at" : "2011-04-16 15:41:41 +0000",
  "in_reply_to_screen_name" : "G4_Hirano_chan",
  "in_reply_to_user_id_str" : "227502200",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59280116123049984",
  "text" : "\u82F1\u8A9E\u3042\u3068\u4E00\u6BB5\u843D\u3060\u304C\u7720\u3044\u2026\u4ECA\u65E5\u8D77\u304D\u305F\u3089\u306B\u3057\u3088\u3046\u3002\u3068\u3044\u3046\u304B\uFF34\uFF4F\u3000\uFF44\uFF4F\u30EA\u30B9\u30C8\u4F5C\u3063\u3066\u3084\u308D\u3046\u3002\u53D7\u9A13\u671F\u307F\u305F\u3044\u306B\u3002",
  "id" : 59280116123049984,
  "created_at" : "2011-04-16 15:40:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59256687663656960",
  "geo" : { },
  "id_str" : "59257041780346880",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 rather\u3067\u3044\u3044\u3068\u306F\u601D\u3046\u3002\u305F\u3060\u6587\u8108\u3067\u300C\u3080\u3057\u308D\u300D\u306E\u610F\u5473\u306F\u51FA\u3066\u308B\u304B\u3089\u7121\u7406\u306B\u8A33\u3055\u306A\u304F\u3066\u3082\u3044\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u3002",
  "id" : 59257041780346880,
  "in_reply_to_status_id" : 59256687663656960,
  "created_at" : "2011-04-16 14:09:14 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59255619366039552",
  "geo" : { },
  "id_str" : "59256072535425024",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u3080\u3057\u308D\u53D7\u9A13\u82F1\u4F5C\u3057\u304B\u3084\u3063\u3066\u306A\u3044\u304B\u3089\u306A\uFF57\u30D1\u30C3\u3068\u898B\u3001\u9055\u548C\u611F\u306F\u306A\u3044\u306A\u3002",
  "id" : 59256072535425024,
  "in_reply_to_status_id" : 59255619366039552,
  "created_at" : "2011-04-16 14:05:23 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59244575130267648",
  "text" : "RT @hyuki: i \u3068\u7D50\u57CE\u3060\u3051\u304C\u53CB\u9054\u3055",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59244249920708608",
    "text" : "i \u3068\u7D50\u57CE\u3060\u3051\u304C\u53CB\u9054\u3055",
    "id" : 59244249920708608,
    "created_at" : "2011-04-16 13:18:24 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 59244575130267648,
  "created_at" : "2011-04-16 13:19:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59239733670322178",
  "geo" : { },
  "id_str" : "59240041288957952",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u306A\u3093\u304B\u8A00\u3046\u3053\u3068\u3042\u3063\u305F\u3089\u3069\u305E\u30FC",
  "id" : 59240041288957952,
  "in_reply_to_status_id" : 59239733670322178,
  "created_at" : "2011-04-16 13:01:41 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59236178733449216",
  "text" : "\u7D04\u4E00\u5E74\u81EA\u708A\u3057\u3066\u3066\u521D\u602A\u6211\u304B\u306A\u30FC\uFF1F\u4ECA\u56DE\u5B66\u3076\u3079\u304D\u6559\u8A13\u304C\u3042\u308B\u3068\u3059\u308C\u3070\u3001\u305D\u308C\u306F\u521D\u5FC3\u5FD8\u308B\u3079\u304B\u3089\u305A\u3068\u3044\u3046\u3053\u3068\u3060\u3002",
  "id" : 59236178733449216,
  "created_at" : "2011-04-16 12:46:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59235754701885440",
  "text" : "\u6CB9\u304C\u306F\u306D\u3066\u5DE6\u624B\u306E\u7532\u3092\u3084\u3051\u3069\u3059\u308B\u30CF\u30D7\u30CB\u30F3\u30B0",
  "id" : 59235754701885440,
  "created_at" : "2011-04-16 12:44:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59234553306419200",
  "text" : "\u9EBB\u5A46\u8C46\u8150\u3046\u307E\u30FC\u3002\u55DA\u547C\u30FC\u9EBB\u5A46\u8C46\u8150\u3001\u9EBB\u5A46\u8C46\u8150\u30FC\u3002",
  "id" : 59234553306419200,
  "created_at" : "2011-04-16 12:39:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59228206665969664",
  "text" : "\u3053\u306E\u6642\u9593\u306B\u3057\u3066\u306F\uFF34\uFF2C\u304C\u304A\u3068\u306A\u3057\u3044\u306A",
  "id" : 59228206665969664,
  "created_at" : "2011-04-16 12:14:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59210751654633473",
  "geo" : { },
  "id_str" : "59211368628367360",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u305D\u3046\u306A\u306E\u304B\u30FC\u3002\u3060\u3063\u305F\u3089should\u3067\u3044\u3044\u306E\u304B\u306A\u3002\u539F\u6587\u306E\u300C\uFF5E\u3059\u308C\u3070\u5927\u4E08\u592B\u300D\u3063\u3066\u306E\u306F\u76F8\u5F53\u5F31\u3044\u304B\u3089\u306A\u3041\u3002\u3002\u3002",
  "id" : 59211368628367360,
  "in_reply_to_status_id" : 59210751654633473,
  "created_at" : "2011-04-16 11:07:45 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 11, 25 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59209686888620033",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126:@ohgakirintaro \n\u30D7\u30E9\u30AF\u30C6\u30A3\u30B9\u306E\u5F8C\u76EE\u7684\u8A9E\u7121\u3044\uFF1F\u500B\u4EBA\u7684\u306B\u306Fshould\u306F\u5F37\u3059\u304E\u308B\u6C17\u304C\u3059\u308B\u304C\u2026\u307E\u3041\u8DA3\u5473\u3060\u306A\u30FC\u3002\u3068\u672C\u4EBA\u3044\u306A\u3044\u306E\u306B\u5999\u306B\u76DB\u308A\u4E0A\u304C\u308B\u3002",
  "id" : 59209686888620033,
  "created_at" : "2011-04-16 11:01:04 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59208593106403328",
  "text" : "\u6700\u8FD1\u82F1\u8A9E\u306B\u95A2\u3057\u3066\u306F\u8AAD\u3080\u3088\u308A\u66F8\u304F\u307B\u3046\u304C\u697D\u306A\u6C17\u304C\u3057\u3066\u3044\u308B\u3002",
  "id" : 59208593106403328,
  "created_at" : "2011-04-16 10:56:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 11, 25 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59205587048726528",
  "geo" : { },
  "id_str" : "59207752043593728",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @ohgakirintaro tell\u3068\u304Bmake\u3068\u304B\u53D7\u3051\u8EAB\u306B\u3059\u308B\u3068\u3084\u3084\u3063\u3053\u3057\u3044\u306E\u306F\u4E3B\u8A9E\u5909\u3048\u308B\u304B\u52D5\u8A5E\u5909\u3048\u305F\u307B\u3046\u304C\u66F8\u304D\u3084\u3059\u3044\u304B\u306A\u30FC\u3002\u53D7\u3051\u8EAB\u306F\u907F\u3051\u305F\u307B\u3046\u304C\uFF08\u4E92\u3044\u306B\u3068\u3063\u3066\uFF09\u308F\u304B\u308A\u3084\u3059\u3044\u3068\u4FFA\u306F\u7FD2\u3063\u305F\u304C\u3002\u3002",
  "id" : 59207752043593728,
  "in_reply_to_status_id" : 59205587048726528,
  "created_at" : "2011-04-16 10:53:22 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 3, 13 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 14, 28 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59207370928168960",
  "text" : "RT @tadash126:@ohgakirintaro \nI am often told (me\u2190\u3044\u308B\uFF1F) that you can speak English fluently. If you want (to)\u3000speak English as good as I am,",
  "id" : 59207370928168960,
  "created_at" : "2011-04-16 10:51:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 11, 25 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59203947423989760",
  "geo" : { },
  "id_str" : "59206985027031040",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @ohgakirintaro  you have to work on it for only 3 months. I don't think that I am good at,  It is not something special ability.",
  "id" : 59206985027031040,
  "in_reply_to_status_id" : 59203947423989760,
  "created_at" : "2011-04-16 10:50:19 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59204887262662656",
  "geo" : { },
  "id_str" : "59205417577889792",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u3053\u3063\u3061\u3082\u66F8\u3044\u3066\u308B\u304B\u3089\u3061\u3087\u3063\u3068\u5F85\u3063\u3066\u306D\uFF57",
  "id" : 59205417577889792,
  "in_reply_to_status_id" : 59204887262662656,
  "created_at" : "2011-04-16 10:44:06 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 11, 25 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59203947423989760",
  "geo" : { },
  "id_str" : "59205324464328704",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @ohgakirintaro Some say to me \"You are good at speaking English\" but if you want to speak as I do, (more)",
  "id" : 59205324464328704,
  "in_reply_to_status_id" : 59203947423989760,
  "created_at" : "2011-04-16 10:43:43 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59203164909469697",
  "geo" : { },
  "id_str" : "59203370942074880",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u65E9\u3044\u306D\u3001\u30EA\u30B5\u3061\u3083\u3093",
  "id" : 59203370942074880,
  "in_reply_to_status_id" : 59203164909469697,
  "created_at" : "2011-04-16 10:35:58 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59203163059789824",
  "text" : "\u660E\u65E5\u306B\u307E\u3068\u3081\u308B\u3068\u9762\u5012\u305D\u3046\u3060\u304B\u3089\u5C11\u3057\u306F\u3084\u308B\u304B\u30FC 1.1.2.3",
  "id" : 59203163059789824,
  "created_at" : "2011-04-16 10:35:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59201273802661888",
  "text" : "\uFF08\u82F1\u8A9E\u3084\u3093\u306A\u304D\u3083\u306A\u30FC\uFF09",
  "id" : 59201273802661888,
  "created_at" : "2011-04-16 10:27:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59201002347302913",
  "text" : "\u3088\u3057\u3001\u30B3\u30F3\u30D1\u30A4\u30E9\u3082\u30A8\u30C7\u30A3\u30BF\u3082\u843D\u3068\u3057\u305F\u3002\u3042\u3068\u306F\u30A2\u30DE\u30BE\u30F3\u3055\u3093\u304C\u4ED5\u4E8B\u3092\u3059\u308B\u306E\u3092\u5F85\u3064\u3060\u3051\u3002",
  "id" : 59201002347302913,
  "created_at" : "2011-04-16 10:26:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59198650424885248",
  "geo" : { },
  "id_str" : "59200274690088960",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u305D\u306E\u767A\u8A00\u3092\u82F1\u8A9E\u3067\u3057\u3066\u305F\u3089\u5B8C\u74A7\u3060\u3063\u305F\u306A\u3002",
  "id" : 59200274690088960,
  "in_reply_to_status_id" : 59198650424885248,
  "created_at" : "2011-04-16 10:23:40 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59196457042976768",
  "text" : "\u518D\u8D77\u52D5\u3057\u305F\u3089\u3042\u3063\u3055\u308A\u5165\u308C\u305F\u3002\u306A\u3093\u3060\u3063\u305F\u3093\u3060\u308D\u3002",
  "id" : 59196457042976768,
  "created_at" : "2011-04-16 10:08:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59195375768182784",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u518D\u8D77\u52D5\u3057\u3066\u307F\u3088\u3046\u3002\u305D\u3057\u3066\u30CE\u30FC\u30C8\u304B\u3089\u30C4\u30A4\u30FC\u30C8\u3002\u5225\uFF30\uFF23\u3067\u591A\u91CD\u8D77\u52D5\u3067\u304D\u306A\u3044\u306E\u304B\u306A\u3002",
  "id" : 59195375768182784,
  "created_at" : "2011-04-16 10:04:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59194875173814272",
  "text" : "\u3080\u3045\u3001\u30C7\u30B9\u30AF\u306Bsaezuri\u5165\u308C\u305F\u3044\u306E\u306B\u8A8D\u8A3C\u3067\u304D\u306A\u3044\u30FB\u30FB\u30FB",
  "id" : 59194875173814272,
  "created_at" : "2011-04-16 10:02:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59169463580364800",
  "geo" : { },
  "id_str" : "59169780338405376",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u9045\u3044\u3088\uFF01",
  "id" : 59169780338405376,
  "in_reply_to_status_id" : 59169463580364800,
  "created_at" : "2011-04-16 08:22:29 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59169402196725761",
  "text" : "@ayu167 \u6C17\u306B\u305B\u305A\u8AAD\u3081\u3070\u304A\uFF4B",
  "id" : 59169402196725761,
  "created_at" : "2011-04-16 08:20:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59168497023987712",
  "text" : "RT @Kaibun_bot: \u7530\u820E\u65B0\u805E\u306F\u3082\u3046\u826F\u3044\u3001\u5185\u5BB9\u3082\u534A\u5206\u3057\u304B\u306A\u3044 \u3000\uFF08\u3044\u306A\u304B\u3057\u3093\u3076\u3093\u306F\u3082\u3046\u3088\u3044\u306A\u3044\u3088\u3046\u3082\u306F\u3093\u3076\u3093\u3057\u304B\u306A\u3044\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 49, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59168161353830401",
    "text" : "\u7530\u820E\u65B0\u805E\u306F\u3082\u3046\u826F\u3044\u3001\u5185\u5BB9\u3082\u534A\u5206\u3057\u304B\u306A\u3044 \u3000\uFF08\u3044\u306A\u304B\u3057\u3093\u3076\u3093\u306F\u3082\u3046\u3088\u3044\u306A\u3044\u3088\u3046\u3082\u306F\u3093\u3076\u3093\u3057\u304B\u306A\u3044\uFF09 #kaibun",
    "id" : 59168161353830401,
    "created_at" : "2011-04-16 08:16:03 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 59168497023987712,
  "created_at" : "2011-04-16 08:17:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59167408425930752",
  "text" : "\u5BB6\u304B\u3089\u51FA\u306A\u3044\u304B\u3089\u826F\u3044\u3051\u3069\uFF08\uFF77\uFF98\uFF6F",
  "id" : 59167408425930752,
  "created_at" : "2011-04-16 08:13:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59167306680512512",
  "text" : "\u9AEA\u3092\u4E7E\u304B\u3055\u306A\u3044\u3067\u5BDD\u305F\u304B\u3089\u82E5\u5E72\u3082\u3057\u3083\u3082\u3057\u3083\u3059\u308B\u3002\u3002\u3002",
  "id" : 59167306680512512,
  "created_at" : "2011-04-16 08:12:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59160422829408256",
  "text" : "RT @NISIOISIN_BOT: \u91D1\u306F\u52FF\u8AD6\u5927\u5207\u3060\u3002\u3060\u3051\u308C\u3069\u5FD8\u308C\u3066\u306F\u306A\u3089\u306A\u3044\u3001\u3082\u3063\u3068\u5927\u5207\u306A\u3082\u306E\u304C\u3042\u308B\u3067\u306F\u306A\u3044\u304B\u2500\u2500\u305D\u306E\u91D1\u3067\u8CFC\u5165\u3059\u308B\u5546\u54C1\u3060",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59159912294518784",
    "text" : "\u91D1\u306F\u52FF\u8AD6\u5927\u5207\u3060\u3002\u3060\u3051\u308C\u3069\u5FD8\u308C\u3066\u306F\u306A\u3089\u306A\u3044\u3001\u3082\u3063\u3068\u5927\u5207\u306A\u3082\u306E\u304C\u3042\u308B\u3067\u306F\u306A\u3044\u304B\u2500\u2500\u305D\u306E\u91D1\u3067\u8CFC\u5165\u3059\u308B\u5546\u54C1\u3060",
    "id" : 59159912294518784,
    "created_at" : "2011-04-16 07:43:16 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 59160422829408256,
  "created_at" : "2011-04-16 07:45:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59155539472547840",
  "text" : "\u90E8\u5C4B\u6383\u9664\u3057\u3066\u82F1\u8A9E\u3084\u308D\u3046\u3002",
  "id" : 59155539472547840,
  "created_at" : "2011-04-16 07:25:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59091810747826176",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u84B2\u56E3\u304C\u3084\u3063\u3068\u96E2\u3057\u3066\u304F\u308C\u305F\u30021,1,2,3",
  "id" : 59091810747826176,
  "created_at" : "2011-04-16 03:12:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59086800257421312",
  "text" : "\u5E03\u56E3\u304C\u96E2\u3057\u3066\u304F\u308C\u306A\u3044\u3002",
  "id" : 59086800257421312,
  "created_at" : "2011-04-16 02:52:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58933003505766400",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 58933003505766400,
  "created_at" : "2011-04-15 16:41:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "indices" : [ 3, 15 ],
      "id_str" : "76905775",
      "id" : 76905775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58916113878237184",
  "text" : "RT @Einstein_ja: \u604B\u306B\u843D\u3061\u308B\u306E\u306F\u611A\u884C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u304C\u3001\u91CD\u529B\u306B\u305D\u306E\u8CAC\u4EFB\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/Einstein_ja\" rel=\"nofollow\"\u003E\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58915921158340608",
    "text" : "\u604B\u306B\u843D\u3061\u308B\u306E\u306F\u611A\u884C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u304C\u3001\u91CD\u529B\u306B\u305D\u306E\u8CAC\u4EFB\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
    "id" : 58915921158340608,
    "created_at" : "2011-04-15 15:33:44 +0000",
    "user" : {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "protected" : false,
      "id_str" : "76905775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433263313\/einstein_normal.jpg",
      "id" : 76905775,
      "verified" : false
    }
  },
  "id" : 58916113878237184,
  "created_at" : "2011-04-15 15:34:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58916066700697601",
  "text" : "\u30A2\u30DE\u30BE\u30F3\u3067\u3044\u308D\u3044\u308D\u983C\u3093\u3060\u304C\u4E00\u756A\u898B\u305F\u3044\u6559\u79D1\u66F8\u3060\u3051\u307E\u3060\u6765\u306A\u3044\u3002",
  "id" : 58916066700697601,
  "created_at" : "2011-04-15 15:34:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58914799135895552",
  "text" : "@koketomi \u3044\u3064\u304B\u3089\u81EA\u5206\u306E\u4EBA\u751F\u3092\u7F8E\u5C11\u5973\u30B2\u30FC\u30E0\u3068\u932F\u899A\u3057\u3066\u3044\u305F\uFF1F",
  "id" : 58914799135895552,
  "created_at" : "2011-04-15 15:29:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58912078462844929",
  "text" : "end313124\u306F\u300E\u7A81\u7136\u96FB\u8A71\u3092\u3057\u3066\u304D\u305F\u306E\u3067\u300C\u4F55\u304B\u3042\u3063\u305F\uFF1F\u300D\u3068\u805E\u3044\u305F\u3068\u3053\u308D\u697D\u3057\u305D\u3046\u306B\u300C\u4ECA\u65E5\u306E\u3042\u306A\u305F\u306F\u221A7\u70B9\u3060\u306D\u300D\u3068\u8A00\u308F\u308C\u308B\u3068\u30AD\u30E5\u30F3\u3068\u3057\u306A\u3044\u3053\u3068\u3082\u306A\u3044\u300F\u3002 http:\/\/shindanmaker.com\/109798  \u7121\u7406\u6570\u304B\u3002\uFF45\u304B\u03C0\u306A\u3089\u7D50\u5A5A\u3059\u308B\u30EC\u30D9\u30EB\u3002\u305F\u3060\u4F4E\u3044\u3088\u306A\u30FC\u3002\u8457\u3057\u304F\u3002",
  "id" : 58912078462844929,
  "created_at" : "2011-04-15 15:18:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58892843401478145",
  "geo" : { },
  "id_str" : "58893134712668161",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u3041\u305D\u3046\u3060\u308D\u3046\u3051\u3069\uFF57",
  "id" : 58893134712668161,
  "in_reply_to_status_id" : 58892843401478145,
  "created_at" : "2011-04-15 14:03:12 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58892462302834688",
  "geo" : { },
  "id_str" : "58892652686483456",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4F55\u3084\u308C\u3070\u3044\u3044\u306E\u304B\u3055\u3063\u3071\u308A\u308F\u304B\u3093\u306A\u3044\u3093\u3060\u304C\u30FB\u30FB\u30FB",
  "id" : 58892652686483456,
  "in_reply_to_status_id" : 58892462302834688,
  "created_at" : "2011-04-15 14:01:17 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 9, 19 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58892471874240512",
  "text" : "\u4ECA\u9031\u3060\u3063\u305F RT @end313124: \u3042\u3042\u3042\u82F1\u8A9E\u306E\u518D\u5C65\u4FEE\u306E\u8AAC\u660E\u4F1A\u5148\u9031\u306E\u706B\u66DC\u3060\u3063\u305Forz",
  "id" : 58892471874240512,
  "created_at" : "2011-04-15 14:00:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58892316588515328",
  "text" : "\u3042\u3042\u3042\u82F1\u8A9E\u306E\u518D\u5C65\u4FEE\u306E\u8AAC\u660E\u4F1A\u5148\u9031\u306E\u706B\u66DC\u3060\u3063\u305Forz",
  "id" : 58892316588515328,
  "created_at" : "2011-04-15 13:59:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58889434967445504",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u4ECA\u65E5\u6388\u696D\u3067\u4EAC\u5927\u3068\u3044\u3048\u3070\uFF1F\u307F\u305F\u3044\u306A\u9023\u60F3\u30B2\u30FC\u30E0\u304C\u3042\u3063\u3066\u3001\u306A\u3093\u3067\u3082\u30DD\u30F3\u30DD\u30F3\u601D\u3044\u3064\u3044\u305F\u306E\u3092\u8A00\u3063\u3066\u884C\u304F\u3093\u3060\u3051\u3069\u300C\u306B\u305B\u307B\u300D\u3063\u3066\u8A00\u304A\u3046\u3068\u3057\u3066\u4F1D\u308F\u3089\u306A\u3044\u3053\u3068\u3092\u6050\u308C\u3066\u8A00\u3048\u306A\u304B\u3063\u305F\u3002",
  "id" : 58889434967445504,
  "created_at" : "2011-04-15 13:48:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58880408145768449",
  "geo" : { },
  "id_str" : "58880886766186496",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa\u3000\u3064 http:\/\/goo.gl\/mquax",
  "id" : 58880886766186496,
  "in_reply_to_status_id" : 58880408145768449,
  "created_at" : "2011-04-15 13:14:32 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58863945213149184",
  "geo" : { },
  "id_str" : "58864055946973185",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308C\u304C\u7B54\u3048\u3060\u308D\u3046\uFF57\uFF57",
  "id" : 58864055946973185,
  "in_reply_to_status_id" : 58863945213149184,
  "created_at" : "2011-04-15 12:07:39 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58849673653403649",
  "text" : "\u3093\u30FC\u56F3\u3089\u305A\u3082\u8A00\u8449\u306E\u30C1\u30E7\u30A4\u30B9\u304C\u60AA\u610F\u3042\u308B\u611F\u3058\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3002",
  "id" : 58849673653403649,
  "created_at" : "2011-04-15 11:10:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58849529205751809",
  "text" : "\u3084\u3063\u3071\u308A\u904A\u3076\u306A\u3089\u751F\u306E\u4EBA\u9593\u306E\u65B9\u304C\u304A\u3082\u3057\u308D\u3044\u3088\u306A\u30FC\u3002",
  "id" : 58849529205751809,
  "created_at" : "2011-04-15 11:09:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58849192109543424",
  "text" : "bot\u3067\u904A\u3076\u306E\u3063\u3066\u9762\u767D\u3044\u3051\u3069\u3001\u3075\u3068\u5207\u306A\u304F\u306A\u308B\u6642\u304C\u30FB\u30FB\u30FB",
  "id" : 58849192109543424,
  "created_at" : "2011-04-15 11:08:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58847757611446272",
  "geo" : { },
  "id_str" : "58848426196078592",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3054\u3081\u3093\u3088\u3001\u30EA\u30B5\u3061\u3083\u3093",
  "id" : 58848426196078592,
  "in_reply_to_status_id" : 58847757611446272,
  "created_at" : "2011-04-15 11:05:32 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58847032143659009",
  "geo" : { },
  "id_str" : "58847755904360448",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3082\u3057\u3083\u3082\u3057\u3083",
  "id" : 58847755904360448,
  "in_reply_to_status_id" : 58847032143659009,
  "created_at" : "2011-04-15 11:02:53 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "\u041F\u0435\u0440\u0435\u0445\u043E\u0434\u043E\u0432a \u041A\u0441\u0435\u043D\u0438\u044F",
      "screen_name" : "kmkmra",
      "indices" : [ 13, 20 ],
      "id_str" : "2825728549",
      "id" : 2825728549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FibonacciHaiku",
      "indices" : [ 78, 93 ]
    }, {
      "text" : "haiku",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "math",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "mathgirl",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58791205814812672",
  "text" : "RT @hyuki: . @kmkmra: \u3042\u3001\u3042\u306E\u3001\u3042\u305F\u3057\u3001\u5148\u8F29\u304C\u3001\u5927\u597D\u304D\u306A\u3093\u3067\u3059\uFF01 http:\/\/togetter.com\/li\/123872  \u3000  #FibonacciHaiku #haiku #math #mathgirl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u041F\u0435\u0440\u0435\u0445\u043E\u0434\u043E\u0432a \u041A\u0441\u0435\u043D\u0438\u044F",
        "screen_name" : "kmkmra",
        "indices" : [ 2, 9 ],
        "id_str" : "2825728549",
        "id" : 2825728549
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FibonacciHaiku",
        "indices" : [ 67, 82 ]
      }, {
        "text" : "haiku",
        "indices" : [ 83, 89 ]
      }, {
        "text" : "math",
        "indices" : [ 90, 95 ]
      }, {
        "text" : "mathgirl",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58790398348378112",
    "text" : ". @kmkmra: \u3042\u3001\u3042\u306E\u3001\u3042\u305F\u3057\u3001\u5148\u8F29\u304C\u3001\u5927\u597D\u304D\u306A\u3093\u3067\u3059\uFF01 http:\/\/togetter.com\/li\/123872  \u3000  #FibonacciHaiku #haiku #math #mathgirl",
    "id" : 58790398348378112,
    "created_at" : "2011-04-15 07:14:57 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 58791205814812672,
  "created_at" : "2011-04-15 07:18:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58778653248589824",
  "text" : "\u6A2A\u6587\u5B57\u306B\u3057\u305F\u3068\u305F\u3093\u306B\u5999\u306B\u4E2D\u4E8C\u75C5\u3063\u307D\u304F\u306A\u308B\u9B54\u6CD5 http:\/\/goo.gl\/JVcUA",
  "id" : 58778653248589824,
  "created_at" : "2011-04-15 06:28:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58776884984557568",
  "text" : "1,1,2,3",
  "id" : 58776884984557568,
  "created_at" : "2011-04-15 06:21:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6570\u5B66\u554F\u984Cbot",
      "screen_name" : "mathematics_bot",
      "indices" : [ 27, 43 ],
      "id_str" : "96739891",
      "id" : 96739891
    }, {
      "name" : "\u3068\u306A\u304B\u3044",
      "screen_name" : "canon_ki",
      "indices" : [ 48, 57 ],
      "id_str" : "88670223",
      "id" : 88670223
    }, {
      "name" : "idiotton",
      "screen_name" : "idiotton",
      "indices" : [ 74, 83 ],
      "id_str" : "42260713",
      "id" : 42260713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58774902928445440",
  "text" : "\u5EA7\u6A19\u306B\u57CB\u3081\u8FBC\u3093\u3067\u6570\u5F0F\u3067\u51E6\u7406\u3063\u3066\u306E\u306F\u3069\u3046\u3067\u3057\u3087\u3046 RT @mathematics_bot: RT @canon_ki: \u6955\u5186\u306E\u6027\u8CEA\u306F\u4F7F\u3048\u306A\u3044\uFF1F RT @idiotton: P\u304C\u771F\u3093\u4E2D\u306E\u6642\u6700\u5927\u3063\u3066\u306E\u306F\u3001\u307B\u307C\u81EA\u660E\u3060\u3051\u3069\u3001\u3069\u3046\u8A3C\u660E\u3059\u308B\u306E\u304C\u3044\u3044\u3093\u3060\u308D\u3002",
  "id" : 58774902928445440,
  "created_at" : "2011-04-15 06:13:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 3, 12 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58759002204545024",
  "text" : "RT @nisehorn: \u30D2\u30E7\u30A8\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58758791243628544",
    "text" : "\u30D2\u30E7\u30A8\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
    "id" : 58758791243628544,
    "created_at" : "2011-04-15 05:09:22 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "protected" : false,
      "id_str" : "96348838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009677836\/06-12-24_23-49m_normal.jpg",
      "id" : 96348838,
      "verified" : false
    }
  },
  "id" : 58759002204545024,
  "created_at" : "2011-04-15 05:10:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58732461005348865",
  "text" : "\u4ECA\u65E5\u306F\u30AA\u30A4\u30E9\u30FC\u306E\u8A95\u751F\u65E5\u306A\u306E\u304B\u30FC\u3002",
  "id" : 58732461005348865,
  "created_at" : "2011-04-15 03:24:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6570\u5B66\u554F\u984Cbot",
      "screen_name" : "mathematics_bot",
      "indices" : [ 10, 26 ],
      "id_str" : "96739891",
      "id" : 96739891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58725113113223168",
  "text" : "\u5E30\u7D0D\u6CD5\u3067\u77AC\u6BBA RT @mathematics_bot: n\u3092\u81EA\u7136\u6570\u3068\u3057\u3001a_n=4^(n\uFF0B1)\uFF0B5^(2n-1)\u3068\u3059\u308B\u3002a_n\u304C21\u3067\u5272\u308A\u5207\u308C\u308B\u3053\u3068\u3092\u793A\u305B\u3002\uFF08\uFF10\uFF19\u9759\u5CA1\u5927\uFF09 #math",
  "id" : 58725113113223168,
  "created_at" : "2011-04-15 02:55:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58723235713400832",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u306A\u3041",
  "id" : 58723235713400832,
  "created_at" : "2011-04-15 02:48:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58721498818551808",
  "geo" : { },
  "id_str" : "58722007382114304",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u6700\u8FD1\u6E1B\u308A\u304C\u65E9\u3044\u304B\u306A\u305C\u5206\u304B\u3063\u305F",
  "id" : 58722007382114304,
  "in_reply_to_status_id" : 58721498818551808,
  "created_at" : "2011-04-15 02:43:12 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58721297441624065",
  "text" : "\u3042\u306820\u5206",
  "id" : 58721297441624065,
  "created_at" : "2011-04-15 02:40:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58720936249147393",
  "text" : "\u5FAE\u5999\u3002end313124\u306E\u4E2D\u8EAB\u306E\u7537\u5973\u6BD4\u7387\u306F\u3010\u7537\uFF1A3\u20107\uFF1A\u5973\u3011\u7CBE\u795E\u5E74\u9F62\u306F\u300A21-25\u6B73\u300B http:\/\/shindanmaker.com\/110050",
  "id" : 58720936249147393,
  "created_at" : "2011-04-15 02:38:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58541573675302912",
  "geo" : { },
  "id_str" : "58541726708678656",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u30BD\u30A6\u30C7\u30B9\u30AB\uFF08\u767D\u76EE",
  "id" : 58541726708678656,
  "in_reply_to_status_id" : 58541573675302912,
  "created_at" : "2011-04-14 14:46:49 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58541086758551552",
  "geo" : { },
  "id_str" : "58541344481746944",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u3061\u3087\u3063\u3068\u4F55\u8A00\u3063\u3066\u308B\u304B\u308F\u304B\u3089\u306A\u3044\u3067\u3059\u306D\u3002",
  "id" : 58541344481746944,
  "in_reply_to_status_id" : 58541086758551552,
  "created_at" : "2011-04-14 14:45:18 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58540929111433216",
  "text" : "\u3056\u308F\u2026\u3056\u308F\u2026",
  "id" : 58540929111433216,
  "created_at" : "2011-04-14 14:43:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58539596585250816",
  "text" : "RT @akeopyaa: \u6BCD\u6821(\u9AD8\u6821)\u306B\u5C0E\u5165\u3055\u308C\u305F\u5730\u9707\u901F\u5831\u306F\u30AB\u30A6\u30F3\u30C8\u30C0\u30A6\u30F3\u3059\u308B\u3089\u3057\u3044\u3002\u300C\u9707\u5EA6\uFF13\u304C\u304D\u307E\u3059\u300230\u79D2\u524D\u300D\u3063\u3066\u611F\u3058",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58538773696348160",
    "text" : "\u6BCD\u6821(\u9AD8\u6821)\u306B\u5C0E\u5165\u3055\u308C\u305F\u5730\u9707\u901F\u5831\u306F\u30AB\u30A6\u30F3\u30C8\u30C0\u30A6\u30F3\u3059\u308B\u3089\u3057\u3044\u3002\u300C\u9707\u5EA6\uFF13\u304C\u304D\u307E\u3059\u300230\u79D2\u524D\u300D\u3063\u3066\u611F\u3058",
    "id" : 58538773696348160,
    "created_at" : "2011-04-14 14:35:05 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 58539596585250816,
  "created_at" : "2011-04-14 14:38:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58535790585724928",
  "text" : "@koketomi \u5C0F\u6C60\u2026\uFF01\u8C6A\u904A\uFF01",
  "id" : 58535790585724928,
  "created_at" : "2011-04-14 14:23:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58369092729577472",
  "text" : "RT @_flyingmoomin: \u543E\u8F29\u306F\u732B\u3067\u3042\u308B. \u89B3\u6E2C\u306F\u307E\u3060\u3055\u308C\u3066\u306A\u3044. \u751F\u304D\u3066\u3044\u308B\u306E\u304B\u6B7B\u3093\u3067\u3044\u308B\u306E\u304B\u3068\u3093\u3068\u898B\u5F53\u304C\u3064\u304B\u306C.\u3000\u306A\u3093\u3067\u3082\u8584\u6697\u3044\u3058\u3081\u3058\u3081\u3057\u305F\u7BB1\u306E\u4E2D\u3067\u5B58\u5728\u306E\u3086\u3089\u3044\u3067\u3044\u305F\u4E8B\u3060\u3051\u306F\u8A18\u61B6\u3057\u3066\u3044\u308B. \u543E\u8F29\u306F\u3053\u3053\u3067\u59CB\u3081\u3066\u4EBA\u9593\u3068\u3044\u3046\u3082\u306E\u3092\u898B\u305F. \u3057\u304B\u3082\u3042\u3068\u3067\u805E\u304F\u3068\u305D\u308C\u306F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54529378540994560",
    "text" : "\u543E\u8F29\u306F\u732B\u3067\u3042\u308B. \u89B3\u6E2C\u306F\u307E\u3060\u3055\u308C\u3066\u306A\u3044. \u751F\u304D\u3066\u3044\u308B\u306E\u304B\u6B7B\u3093\u3067\u3044\u308B\u306E\u304B\u3068\u3093\u3068\u898B\u5F53\u304C\u3064\u304B\u306C.\u3000\u306A\u3093\u3067\u3082\u8584\u6697\u3044\u3058\u3081\u3058\u3081\u3057\u305F\u7BB1\u306E\u4E2D\u3067\u5B58\u5728\u306E\u3086\u3089\u3044\u3067\u3044\u305F\u4E8B\u3060\u3051\u306F\u8A18\u61B6\u3057\u3066\u3044\u308B. \u543E\u8F29\u306F\u3053\u3053\u3067\u59CB\u3081\u3066\u4EBA\u9593\u3068\u3044\u3046\u3082\u306E\u3092\u898B\u305F. \u3057\u304B\u3082\u3042\u3068\u3067\u805E\u304F\u3068\u305D\u308C\u306F\u30B7\u30E5\u30EC\u30C7\u30A3\u30F3\u30AC\u30FC\u3068\u3044\u3046\u7269\u7406\u5B66\u8005\u3067\u3042\u3063\u305F\u305D\u3046\u3060.",
    "id" : 54529378540994560,
    "created_at" : "2011-04-03 13:03:11 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 58369092729577472,
  "created_at" : "2011-04-14 03:20:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58344810918068224",
  "geo" : { },
  "id_str" : "58345429389152256",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u53D7\u3051\u3066\u308B\u3088\uFF1F",
  "id" : 58345429389152256,
  "in_reply_to_status_id" : 58344810918068224,
  "created_at" : "2011-04-14 01:46:49 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58343030037544960",
  "text" : "\u85AC\u98F2\u3093\u3060\u3051\u3069\u307E\u3060\u52B9\u304B\u306A\u3044\u3002\u9F3B\u6C34\u306E\u7C98\u5EA6\u304C\u4F4E\u3044\u304B\u3089\u305D\u308C\u306F\u305D\u308C\u3067\u8F9B\u3044\u3002",
  "id" : 58343030037544960,
  "created_at" : "2011-04-14 01:37:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9762\u767D\u6570\u5B66bot",
      "screen_name" : "funmath_bot",
      "indices" : [ 3, 15 ],
      "id_str" : "245786443",
      "id" : 245786443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58322201874665474",
  "text" : "RT @funmath_bot: \u4E16\u754C\u4E2D\u306E\u5168\u6606\u866B\u306E\u6570\u3088\u308A\u30EB\u30FC\u30D3\u30C3\u30AF\u30AD\u30E5\u30FC\u30D6\u306E\u9762\u306E\u7D44\u307F\u5408\u308F\u305B\u306E\u304C\u591A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58318802521296896",
    "text" : "\u4E16\u754C\u4E2D\u306E\u5168\u6606\u866B\u306E\u6570\u3088\u308A\u30EB\u30FC\u30D3\u30C3\u30AF\u30AD\u30E5\u30FC\u30D6\u306E\u9762\u306E\u7D44\u307F\u5408\u308F\u305B\u306E\u304C\u591A\u3044",
    "id" : 58318802521296896,
    "created_at" : "2011-04-14 00:01:00 +0000",
    "user" : {
      "name" : "\u9762\u767D\u6570\u5B66bot",
      "screen_name" : "funmath_bot",
      "protected" : false,
      "id_str" : "245786443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1231702505\/pipie2_normal.jpg",
      "id" : 245786443,
      "verified" : false
    }
  },
  "id" : 58322201874665474,
  "created_at" : "2011-04-14 00:14:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58321292302102528",
  "text" : "\u8D77\u5E8A\u3001\u30B7\u30E3\u30EF\u30FC\u3082\u6D74\u3073\u3066\u723D\u3084\u304B\u306A\u671D\u3002\u305F\u3060\u6628\u65E5\u85AC\u98F2\u307F\u5FD8\u308C\u3066\u82B1\u7C89\u304Corz",
  "id" : 58321292302102528,
  "created_at" : "2011-04-14 00:10:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58202760063107072",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 58202760063107072,
  "created_at" : "2011-04-13 16:19:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58193128833822720",
  "geo" : { },
  "id_str" : "58193775025061888",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u3044\u3084\u3001\u3053\u3063\u3061\u3053\u305D\u601D\u3063\u305F\u3053\u3068\u3092\u3075\u3068\u8A00\u3063\u3066\u307F\u305F\u3060\u3051\u306A\u3093\u3060\u3002\u3054\u3081\u3093\u3088\u3002",
  "id" : 58193775025061888,
  "in_reply_to_status_id" : 58193128833822720,
  "created_at" : "2011-04-13 15:44:11 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58191454257946624",
  "geo" : { },
  "id_str" : "58192307744288768",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u767D\u3044\u7C89\u3063\u3066\u306E\u304C\u81EA\u660E\u306A\u3089\u306D\u3002\u7802\u7CD6\u3067\u306F\u306A\u304F\u767D\u3044\u7C89\u3063\u3066\u3044\u3046\u3088\u308A\u3042\u304F\u307E\u3067\u300C\u7802\u7CD6\u3068\u306F\u8A00\u3044\u5207\u308C\u306A\u3044\u767D\u3044\u7C89\u300D\u3060\u308D\u3046\u306D\u3002\u3053\u308C\u4EE5\u4E0A\u6398\u308A\u4E0B\u3052\u308B\u3068\u7985\u554F\u7B54\u3060\u3051\u3069\u3002",
  "id" : 58192307744288768,
  "in_reply_to_status_id" : 58191454257946624,
  "created_at" : "2011-04-13 15:38:21 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58190707780894720",
  "geo" : { },
  "id_str" : "58191009770782720",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u8A3C\u660E\u304C\u51FA\u6765\u306A\u3044\u5185\u306F\u4E88\u6E2C\u306B\u3059\u304E\u306A\u3044\u3002",
  "id" : 58191009770782720,
  "in_reply_to_status_id" : 58190707780894720,
  "created_at" : "2011-04-13 15:33:12 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58182639076646912",
  "text" : "@koketomi \u30BD\u30FC\u30C8\u3063\u3066\u5358\u8A9E\u304C\u30CE\u30FC\u30C8\u3063\u3066\u898B\u3048\u3066\u898B\u76F4\u3057\u305F\u3089\u4E00\u77AC\u30CB\u30FC\u30C8\u3063\u3066\u898B\u3048\u3066\u3082\u3046\u4E00\u56DE\u898B\u305F\u3089\u4E00\u77AC\u30CB\u30FC\u30BD\u3063\u3066\u898B\u3048\u3066\u75B2\u308C\u3092\u5B9F\u611F\u3057\u305F\u3002",
  "id" : 58182639076646912,
  "created_at" : "2011-04-13 14:59:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58172997642620928",
  "text" : "\u96FB\u8ECA\u6765\u305F\u306E\u3067\u8AAD\u66F8\u306B\u623B\u308A\u307E\u3059",
  "id" : 58172997642620928,
  "created_at" : "2011-04-13 14:21:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58172900783570944",
  "text" : "\u30B8\u30B0\u30C4\u30A4\u4FBF\u5229\u306D\u30FC\u3002\u96FB\u6C60\u55B0\u3046\u3051\u3069\u3001\u3053\u306E\u30B9\u30DE\u30DB\u3082\u3069\u304D\u306E\u30BF\u30C3\u30C1\u30D1\u30CD\u30EB\u306B\u5BFE\u5FDC\u3057\u305F\u30A2\u30D7\u30EA\u306F\u521D\u3081\u3066\u3002",
  "id" : 58172900783570944,
  "created_at" : "2011-04-13 14:21:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58172444464263168",
  "text" : "\u3053\u306E\u6642\u671F\u306E\u591C\u306E\u808C\u5BD2\u3055\u304C\u597D\u304D\u3002",
  "id" : 58172444464263168,
  "created_at" : "2011-04-13 14:19:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58172137340542976",
  "text" : "\u306B\u3057\u3066\u3082\u6570\u5B66\u30AC\u30FC\u30EB\u3001\u4E71\u629E\u30A2\u30EB\u30B4\u30EA\u30BA\u30E0\u8AAD\u307F\u3084\u3059\u3044\u3002\u30B2\u30FC\u30C7\u30EB\u306B\u6BD4\u3079\u3066\u30B5\u30AF\u30B5\u30AF\u3002\u5FA9\u7FD2\u306B\u3082\u306A\u308B\u3002",
  "id" : 58172137340542976,
  "created_at" : "2011-04-13 14:18:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58171377072619521",
  "geo" : { },
  "id_str" : "58171792338067457",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305D\u308C\u3001\u300C\u6628\u65E5\u300D\u3058\u3083\u304F\u3066\u300C\u4ECA\u65E5\u300D\u3068\u307E\u305C\u8FD4\u3059\u3068\u52B9\u679C\u7684",
  "id" : 58171792338067457,
  "in_reply_to_status_id" : 58171377072619521,
  "created_at" : "2011-04-13 14:16:50 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58171554323894273",
  "text" : "\u666E\u6BB5\u3068\u9055\u3046\u4F4D\u7F6E\u3067\u4E57\u3063\u305F\u304B\u3089\u666F\u8272\u3067\u5224\u65AD\u51FA\u6765\u305A\u306B\u7126\u3063\u305F\u3002\u3053\u306E\u6642\u9593\u3060\u3068\u4EAC\u90FD\u99C5\u304B\u3089\u30BF\u30AF\u30B7\u30FC\u3057\u304B\u629E\u304C\u306A\u3044\u3002\u6B69\u304F\u3068\u3056\u3063\u3068\uFF11\uFF10\uFF10\u5206\u3063\u3066\u3068\u3053\u304B\u306A\u3002",
  "id" : 58171554323894273,
  "created_at" : "2011-04-13 14:15:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58171172172480512",
  "text" : "\u97F3\u697D\u8074\u304D\u306A\u304C\u3089\u6570\u5B66\u30AC\u30FC\u30EB\u8AAD\u3093\u3067\u305F\u3089\u96FB\u8ECA\u3092\u964D\u308A\u305D\u3053\u306A\u3046\u6240\u3060\u3063\u305F\u3002",
  "id" : 58171172172480512,
  "created_at" : "2011-04-13 14:14:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otmg",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58072205547929600",
  "text" : "\u5973\u6027\u5411\u3051\u604B\u611B\u30B2\u30FC\u30E0\u3067\u306Eend313124\u306F\u3001\u7D20\u76F4\u306B\u306A\u308C\u306A\u3044\u56F3\u66F8\u59D4\u54E1\u3002\u5BB6\u5EAD\u79D1\u5BA4\u3067\u3088\u304F\u4F1A\u3044\u307E\u3059\u3002\u5370\u8C61\u7684\u306A\u30BB\u30EA\u30D5\u306F\u300C\u541B\u306B\u306F\u7B11\u3063\u3066\u3066\u307B\u3057\u3044\u304B\u3089\u2026\u2026\u300D\u3067\u3059\u3002 http:\/\/shindanmaker.com\/50881 #otmg",
  "id" : 58072205547929600,
  "created_at" : "2011-04-13 07:41:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58070737839325184",
  "geo" : { },
  "id_str" : "58070950255661057",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u96FB\u6CE2\u60AA\u3044\u3088\u306A\uFF57\u305D\u3053\uFF57",
  "id" : 58070950255661057,
  "in_reply_to_status_id" : 58070737839325184,
  "created_at" : "2011-04-13 07:36:08 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57831811031646208",
  "geo" : { },
  "id_str" : "57832033522688000",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u751F\u5354\u3088\u308A\u5B89\u3044\u3063\u3066\u306E\u304C\u7D42\u308F\u3063\u3066\u308B\u3088\u306A\u3002",
  "id" : 57832033522688000,
  "in_reply_to_status_id" : 57831811031646208,
  "created_at" : "2011-04-12 15:46:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57830757133062145",
  "geo" : { },
  "id_str" : "57831352199950336",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u306E\u624B\u304C\u3042\u3063\u305F\u304B\u3002\u30D7\u30E9\u30A4\u30E0\u3042\u308B\u3057\u307E\u3068\u3081\u3066\u8CB7\u3063\u3066\u3057\u307E\u304A\u3046\u3002",
  "id" : 57831352199950336,
  "in_reply_to_status_id" : 57830757133062145,
  "created_at" : "2011-04-12 15:44:03 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57821693242126336",
  "text" : "\u300C\u6D88\u8017\u54C1\u304C\u305F\u304F\u3055\u3093\u3042\u3063\u3066\u307E\u3060\u307E\u3060\u5C3D\u304D\u306A\u3044\u300D\u3068\u3044\u3046\u72B6\u614B\u306B\u3055\u3055\u3084\u304B\u306A\u5E78\u305B\u3092\u611F\u3058\u308B\u3002",
  "id" : 57821693242126336,
  "created_at" : "2011-04-12 15:05:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57821486257422336",
  "text" : "\u3067\u3082\u30DA\u30EA\u30A8\uFF14\uFF18\u7F36\uFF14\uFF10\uFF10\uFF10\u5186\u5F31\u306F\u5B89\u3044\u3088\u306A\u3041\u3002\uFF12\u7BB1\u8CB7\u3044\u3068\u304B\u8D05\u6CA2\u3002",
  "id" : 57821486257422336,
  "created_at" : "2011-04-12 15:04:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57821267922927616",
  "text" : "\u30CD\u30C3\u30C8\u3067\u901A\u8CA9\u3057\u3066\u3082\u304A\u91D1\u304C\u6E1B\u3089\u306A\u3044\u80FD\u529B\u304C\u6B32\u3057\u3044\u3002",
  "id" : 57821267922927616,
  "created_at" : "2011-04-12 15:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57821153892380672",
  "text" : "RT @NISIOISIN_BOT: \u54C0\u308C\u306A\u3053\u3068\u3060\u3000\u8CB4\u69D8\u3082\u304B\u3064\u3066\u306F\u5929\u4F7F\u306E\u3088\u3046\u306B\u7D14\u6734\u306A\u5C11\u5E74\u3060\u3063\u305F\u306B\u6C7A\u307E\u3063\u3066\u3044\u308B\u3000\u4E0D\u5E78\u306B\u3082\u611B\u60C5\u306B\u6075\u307E\u308C\u306A\u304B\u3063\u305F\u3086\u3048\u306B\u305D\u3093\u306A\u72EC\u5584\u7684\u306A\u4EBA\u9593\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3068\u3057\u304B\u8003\u3048\u3089\u308C\u3093\u3000\u5B89\u5FC3\u3057\u308D\uFF01\u4E8C\u5EA6\u3068\u60AA\u3060\u304F\u307F\u306A\u3069\u3067\u304D\u306A\u3044\u3088\u3046\u3000\u3053\u306E\u79C1\u304C\u5FB9\u5E95\u7684\u306B\u53EF\u611B\u304C\u3063\u3066\u3084\u308B!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57820753978064896",
    "text" : "\u54C0\u308C\u306A\u3053\u3068\u3060\u3000\u8CB4\u69D8\u3082\u304B\u3064\u3066\u306F\u5929\u4F7F\u306E\u3088\u3046\u306B\u7D14\u6734\u306A\u5C11\u5E74\u3060\u3063\u305F\u306B\u6C7A\u307E\u3063\u3066\u3044\u308B\u3000\u4E0D\u5E78\u306B\u3082\u611B\u60C5\u306B\u6075\u307E\u308C\u306A\u304B\u3063\u305F\u3086\u3048\u306B\u305D\u3093\u306A\u72EC\u5584\u7684\u306A\u4EBA\u9593\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3068\u3057\u304B\u8003\u3048\u3089\u308C\u3093\u3000\u5B89\u5FC3\u3057\u308D\uFF01\u4E8C\u5EA6\u3068\u60AA\u3060\u304F\u307F\u306A\u3069\u3067\u304D\u306A\u3044\u3088\u3046\u3000\u3053\u306E\u79C1\u304C\u5FB9\u5E95\u7684\u306B\u53EF\u611B\u304C\u3063\u3066\u3084\u308B!!",
    "id" : 57820753978064896,
    "created_at" : "2011-04-12 15:01:56 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 57821153892380672,
  "created_at" : "2011-04-12 15:03:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57677274555756545",
  "text" : "\u8AAD\u5F8C\u611F\u3001\u6674\u5929\u3001\u304A\u663C\u3054\u98EF\u5F8C\u3002\u3053\u308C\u3089\u306E\u30D5\u30A1\u30AF\u30BF\u30FC\u304B\u3089\u5C0E\u304D\u51FA\u3055\u308C\u308B\u7D50\u8AD6\u306F\u2026\u5727\u5012\u7684\u7720\u6C17\uFF6F\uFF01",
  "id" : 57677274555756545,
  "created_at" : "2011-04-12 05:31:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C60\u7530\u4FE1\u592B",
      "screen_name" : "ikedanob",
      "indices" : [ 3, 12 ],
      "id_str" : "24611873",
      "id" : 24611873
    }, {
      "name" : "\u53F7\u6CE3\u3068\u306F\u5927\u58F0\u3067\u6CE3\u304D\u53EB\u3076\u3053\u3068",
      "screen_name" : "see_voices",
      "indices" : [ 24, 35 ],
      "id_str" : "116739482",
      "id" : 116739482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57626885005385728",
  "text" : "RT @ikedanob: \u305D\u3046\u3044\u3046\u3053\u3068 RT @see_voices: \u798F\u5CF6\u304C\u30EC\u30D9\u30EB\uFF17\u3060\u3068\u3059\u308C\u3070\u30C1\u30A7\u30EB\u30CE\u30D6\u30A4\u30EA\u306F\u30EC\u30D9\u30EB\uFF11\uFF10\u4EE5\u4E0A\u3067\u3082\u3044\u3044\u3050\u3089\u3044\u3060\u304C\u3001\u5B9F\u969B\u306B\u306F\uFF17\u307E\u3067\u3057\u304B\u306A\u3044\u304B\u3089\u4FBF\u5B9C\u7684\u306B\u540C\u3058\u30EC\u30D9\u30EB\u306B\u306A\u3063\u3066\u3044\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u53F7\u6CE3\u3068\u306F\u5927\u58F0\u3067\u6CE3\u304D\u53EB\u3076\u3053\u3068",
        "screen_name" : "see_voices",
        "indices" : [ 10, 21 ],
        "id_str" : "116739482",
        "id" : 116739482
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57614287887286272",
    "text" : "\u305D\u3046\u3044\u3046\u3053\u3068 RT @see_voices: \u798F\u5CF6\u304C\u30EC\u30D9\u30EB\uFF17\u3060\u3068\u3059\u308C\u3070\u30C1\u30A7\u30EB\u30CE\u30D6\u30A4\u30EA\u306F\u30EC\u30D9\u30EB\uFF11\uFF10\u4EE5\u4E0A\u3067\u3082\u3044\u3044\u3050\u3089\u3044\u3060\u304C\u3001\u5B9F\u969B\u306B\u306F\uFF17\u307E\u3067\u3057\u304B\u306A\u3044\u304B\u3089\u4FBF\u5B9C\u7684\u306B\u540C\u3058\u30EC\u30D9\u30EB\u306B\u306A\u3063\u3066\u3044\u308B",
    "id" : 57614287887286272,
    "created_at" : "2011-04-12 01:21:31 +0000",
    "user" : {
      "name" : "\u6C60\u7530\u4FE1\u592B",
      "screen_name" : "ikedanob",
      "protected" : false,
      "id_str" : "24611873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507430619702247424\/4z13JTQv_normal.jpeg",
      "id" : 24611873,
      "verified" : true
    }
  },
  "id" : 57626885005385728,
  "created_at" : "2011-04-12 02:11:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57614730822561792",
  "text" : "\u7A7A\u8179\u306E\u307E\u307E\uFF12\u9650\u3002\u6B63\u5922\uFF1F\u305D\u3052\u3076\uFF6F\uFF01",
  "id" : 57614730822561792,
  "created_at" : "2011-04-12 01:23:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57596308395008000",
  "text" : "@nico_reflexio \u4FFA\u672A\u6765\u304B\u3089\u6765\u305F\u3063\u3066\u8A00\u3063\u305F\u3089\u7B11\u3046\uFF1F\u307E\u3041\u5076\u7136\u3055\u3002",
  "id" : 57596308395008000,
  "created_at" : "2011-04-12 00:10:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57595903179096064",
  "text" : "@nico_reflexio \u304A\u524D\u304C\u671D\u3084\u3063\u3066\u304D\u3066\uFF12\u9650\u306B\u884C\u304B\u305B\u3066\u304F\u308C\u306A\u3044\u5922\u3092\u898B\u305F\u3002",
  "id" : 57595903179096064,
  "created_at" : "2011-04-12 00:08:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57595672198791168",
  "text" : "\uFF12\u9650\u884C\u304D\u640D\u306D\u308B\u5922\u3092\u3053\u306E\uFF13\uFF10\u5206\u3067\uFF14\u3001\uFF15\u30D1\u30BF\u30FC\u30F3\u898B\u305F\u3002\u304A\u306F\u3088\u3046\u3002",
  "id" : 57595672198791168,
  "created_at" : "2011-04-12 00:07:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57452690694873088",
  "text" : "Twilog\u59CB\u3081\u307E\u3057\u305F http:\/\/twilog.org\/end313124",
  "id" : 57452690694873088,
  "created_at" : "2011-04-11 14:39:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57451645327507456",
  "geo" : { },
  "id_str" : "57451940472291328",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30B5\u30F3\u30AD\u30E5",
  "id" : 57451940472291328,
  "in_reply_to_status_id" : 57451645327507456,
  "created_at" : "2011-04-11 14:36:24 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57451138886279169",
  "geo" : { },
  "id_str" : "57451402867384320",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u3046\u3044\u3048\u3070\u4E00\u65E5\u5358\u4F4D\u306E\u30C4\u30A4\u30FC\u30C8\u6570\u3063\u3066\u3069\u3046\u3084\u3063\u3066\u77E5\u3063\u3066\u308B\u306E\uFF1F",
  "id" : 57451402867384320,
  "in_reply_to_status_id" : 57451138886279169,
  "created_at" : "2011-04-11 14:34:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57446693666435074",
  "text" : "\u30AC\u30ED\u30A2\u7FA4\u306F\uFF27\u7FA4\u79D1\u76EE\u3001\u30EA\u30FC\u7FA4\u306F\uFF2C\u7FA4\u79D1\u76EE\u3068\u7406\u89E3\u3057\u3066\u3044\u307E\u3059(\uFF77\uFF98\uFF6F)",
  "id" : 57446693666435074,
  "created_at" : "2011-04-11 14:15:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57446079196696578",
  "text" : "\u8A00\u8A9E\u3067\u3057\u304B\u3082\"\uFF23\"\u306A\u306E\u306B\u306A\u2026\u3002",
  "id" : 57446079196696578,
  "created_at" : "2011-04-11 14:13:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57445977191235584",
  "text" : "\uFF23\u8A00\u8A9E\u5B66\u3076\u306E\u306B\u306A\u3093\u3067\uFF23\u7FA4\u3067\u767B\u9332\u3067\u304D\u306A\u3044\u306E\uFF1F\u3053\u3093\u306A\u306E\u7D76\u5BFE\u304A\u304B\u3057\u3044\u3088\uFF01",
  "id" : 57445977191235584,
  "created_at" : "2011-04-11 14:12:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57444681646211072",
  "geo" : { },
  "id_str" : "57444980154830848",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u308A\u304C\u3068\u514E",
  "id" : 57444980154830848,
  "in_reply_to_status_id" : 57444681646211072,
  "created_at" : "2011-04-11 14:08:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57444628634406912",
  "text" : "5\u9650\u3063\u3066\u4F55\u6642\u306B\u59CB\u307E\u308B\u3063\u3051\uFF1F\u53BB\u5E74\u5F8C\u671F\u5165\u308C\u3066\u306A\u304B\u3063\u305F\u304B\u3089\u308F\u304B\u3093\u306D\u3047\uFF57\uFF57\uFF57",
  "id" : 57444628634406912,
  "created_at" : "2011-04-11 14:07:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57430200761327616",
  "text" : "\u53CD\u7269\u3001\u30DF\u30B7\u30F3\u3001\u5F85\u3061\u91DD\u3001\u30C1\u30E3\u30B3\u30DA\u30F3\u3001\u578B\u7D19\u3001\u306A\u3093\u306B\u3082\u306A\u3044\u3002\u3002\u3002",
  "id" : 57430200761327616,
  "created_at" : "2011-04-11 13:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57430016849489921",
  "text" : "3,4\u4E07\u304B\u3051\u3066\u826F\u3044\u6D74\u8863\u8CB7\u3046\u306E\u3068\u3001\u540C\u3058\uFF08\uFF1F\uFF09\u5024\u6BB5\u3067\u624B\u4F5C\u308A\u3059\u308B\u306E\u3068\u3069\u3063\u3061\u304C\u3044\u3044\u3093\u3060\u308D\u3002",
  "id" : 57430016849489921,
  "created_at" : "2011-04-11 13:09:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57429846778847233",
  "text" : "\u4F55\u3092\u601D\u3063\u305F\u304B\u6D74\u8863\u3092\u4F5C\u308B\u30B5\u30A4\u30C8\u3070\u304B\u308A\u898B\u3066\u3044\u308B\u3002\u9762\u767D\u305D\u3046\u3002",
  "id" : 57429846778847233,
  "created_at" : "2011-04-11 13:08:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57426901903478784",
  "text" : "\u96FB\u52D5\u30DF\u30B7\u30F3\u3063\u3066\u5E7E\u3089\u3059\u308B\u3093\u3060\u308D\u3002\u305D\u306E\u524D\u306B\u30A2\u30A4\u30ED\u30F3\u304B\uFF1F",
  "id" : 57426901903478784,
  "created_at" : "2011-04-11 12:56:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57425520551399424",
  "text" : "\u8A66\u9A13\u4E2D\uFF08\uFF09\u3058\u3083\u306A\u3044\u3093\u3060\u3057\u5225\u306B\u6012\u3089\u308C\u306A\u3044\u3067\u3057\u3087\u3046\u3002\u9AD8\u6821\u306F\u77E5\u3089\u306A\u3044\u304C\u5C11\u306A\u304F\u3068\u3082\u5927\u5B66\u306F\u5225\u306B\u4F55\u3068\u3082\u3002",
  "id" : 57425520551399424,
  "created_at" : "2011-04-11 12:51:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57408343584681985",
  "text" : "\u30D5\u30A9\u30C8\u30B7\u30E7\u30C3\u30D7\u3055\u3093\uFF08\u4F7F\u3044\u3053\u306A\u305B\u305A\u6301\u3066\u4F59\u3057\u3066\u308B\u611F\u306F\u5426\u3081\u306A\u3044\u304C\uFF09\u3055\u3059\u304C\u3067\u3059\u3002",
  "id" : 57408343584681985,
  "created_at" : "2011-04-11 11:43:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57408068820017152",
  "text" : "\u679A\u6570\u5C11\u306A\u3044\u3051\u3069\uFF08\u7121\u99C4\u306B\uFF09\u30DE\u30EB\u30C1\u30AB\u30E9\u30FC",
  "id" : 57408068820017152,
  "created_at" : "2011-04-11 11:42:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57407958308503552",
  "text" : "\u30D3\u30E9\u51FA\u6765\u305F\u3002\u30A2\u30C9\u30EC\u30B9\u9577\u304F\u3066\u30A2\u30EC\u3060\u3063\u305F\u304B\u3089\uFF31\uFF32\u30B3\u30FC\u30C9\u306B\u3057\u3066\u307F\u305F\u3002",
  "id" : 57407958308503552,
  "created_at" : "2011-04-11 11:41:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira O-ko-chi",
      "screen_name" : "Okouchi",
      "indices" : [ 3, 11 ],
      "id_str" : "96684281",
      "id" : 96684281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57334527000969216",
  "text" : "RT @Okouchi: \u7121\u610F\u8B58\u306B\u96F7\u304C\u5149\u3063\u3066\u304B\u3089\u805E\u3053\u3048\u308B\u307E\u3067\u6642\u9593\u3092\u8A08\u3063\u3066\u3057\u307E\u3046\u3002\u7D76\u5BFE\u540C\u985E\u306E\u4EBA\u3044\u308B\u306F\u305A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57333296442523648",
    "text" : "\u7121\u610F\u8B58\u306B\u96F7\u304C\u5149\u3063\u3066\u304B\u3089\u805E\u3053\u3048\u308B\u307E\u3067\u6642\u9593\u3092\u8A08\u3063\u3066\u3057\u307E\u3046\u3002\u7D76\u5BFE\u540C\u985E\u306E\u4EBA\u3044\u308B\u306F\u305A",
    "id" : 57333296442523648,
    "created_at" : "2011-04-11 06:44:57 +0000",
    "user" : {
      "name" : "Akira O-ko-chi",
      "screen_name" : "Okouchi",
      "protected" : true,
      "id_str" : "96684281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583470276\/15682909.v1254812805_normal.jpg",
      "id" : 96684281,
      "verified" : false
    }
  },
  "id" : 57334527000969216,
  "created_at" : "2011-04-11 06:49:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57293270379798529",
  "geo" : { },
  "id_str" : "57297578387181568",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306A\u3093\u306E\u6388\u696D\uFF1F",
  "id" : 57297578387181568,
  "in_reply_to_status_id" : 57293270379798529,
  "created_at" : "2011-04-11 04:23:01 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57231765856714753",
  "geo" : { },
  "id_str" : "57253994548039680",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u5C65\u4FEE\u3057\u3066\u308B\u308F\u3051\u3058\u3083\u306A\u3044\u3051\u3069\u306D\u30FC\u3002\u53BB\u5E74\u7121\u304B\u3063\u305F\u304B\u3089\u5730\u9707\u3092\u53D7\u3051\u3066\u3001\u304B\u3082\u3002",
  "id" : 57253994548039680,
  "in_reply_to_status_id" : 57231765856714753,
  "created_at" : "2011-04-11 01:29:50 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57253333907423232",
  "text" : "\u65E5\u9670\u306F\u7279\u306B\u3002",
  "id" : 57253333907423232,
  "created_at" : "2011-04-11 01:27:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57253255402627072",
  "text" : "\u9577\u8896\u4E8C\u679A\u3058\u3083\u82E5\u5E72\u808C\u5BD2\u3044\u306A\u30FC\u3002",
  "id" : 57253255402627072,
  "created_at" : "2011-04-11 01:26:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57226571592896513",
  "text" : "\u300C\u5730\u9707\uFF65\u96F7\uFF65\u706B\u4E8B\uFF65\u89AA\u7236\u306E\u50BE\u5411\u3068\u5BFE\u7B56\u300D\u3063\u3066\u79D1\u76EE\u304C\u3042\u308B\u4EF6\u306B\u3064\u3044\u3066\uFF57\uFF57\uFF57",
  "id" : 57226571592896513,
  "created_at" : "2011-04-10 23:40:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57212972405227520",
  "text" : "\u76EE\u899A\u307E\u3057\u304B\u3051\u308B\u3068\u9CF4\u308B\u306E\u304C\u6016\u304F\u3066\u65E9\u304F\u8D77\u304D\u308B\u3002\u826F\u304F\u306A\u3044\u3002",
  "id" : 57212972405227520,
  "created_at" : "2011-04-10 22:46:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57210006893891584",
  "text" : "\u8D77\u304D\u305F\u304C\u5BDD\u9055\u3048\u305F\u307F\u305F\u3044\u3002",
  "id" : 57210006893891584,
  "created_at" : "2011-04-10 22:35:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3093\u3061\u3083\u3093",
      "screen_name" : "nori_roll",
      "indices" : [ 3, 13 ],
      "id_str" : "205658906",
      "id" : 205658906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57081998396764161",
  "text" : "RT @nori_roll: \u660E\u65E5\u5B66\u6821\u884C\u304D\u305F\u304F\u306A\u3044\u5B66\u751F\u3001\u516C\u5F0FRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57068234796572672",
    "text" : "\u660E\u65E5\u5B66\u6821\u884C\u304D\u305F\u304F\u306A\u3044\u5B66\u751F\u3001\u516C\u5F0FRT",
    "id" : 57068234796572672,
    "created_at" : "2011-04-10 13:11:42 +0000",
    "user" : {
      "name" : "\u3057\u3093\u3061\u3083\u3093",
      "screen_name" : "nori_roll",
      "protected" : false,
      "id_str" : "205658906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1354437832\/image_normal.png",
      "id" : 205658906,
      "verified" : false
    }
  },
  "id" : 57081998396764161,
  "created_at" : "2011-04-10 14:06:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57075565252976640",
  "geo" : { },
  "id_str" : "57081929924743168",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u307E\u3041\u305D\u3053\u306F\u304B\u3068\u306A\u304F\u7406\u89E3\u3067\u304D\u3066\u3057\u307E\u3046\u304B\u3089\u3042\u308C\u3060\u3051\u3069\u306D\uFF57",
  "id" : 57081929924743168,
  "in_reply_to_status_id" : 57075565252976640,
  "created_at" : "2011-04-10 14:06:07 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57074406844932096",
  "geo" : { },
  "id_str" : "57074786043564032",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u968F\u5206\u6B6A\u3093\u3060\u611B\u3060\u306A\uFF57\uFF57",
  "id" : 57074786043564032,
  "in_reply_to_status_id" : 57074406844932096,
  "created_at" : "2011-04-10 13:37:44 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57074373340823552",
  "text" : "\u660E\u65E5\uFF11\u9650\u304B\u2026",
  "id" : 57074373340823552,
  "created_at" : "2011-04-10 13:36:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56977541851914240",
  "text" : "\u6D3B\u52D5\u306E\u66DC\u65E5\u304C\u6C7A\u307E\u3063\u3066\u3044\u306A\u3044\u306E\u306B\u30D3\u30E9\u4F5C\u308B\u306E\u3063\u3066\u96E3\u3057\u3044\uFF57",
  "id" : 56977541851914240,
  "created_at" : "2011-04-10 07:11:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "indices" : [ 3, 15 ],
      "id_str" : "258721812",
      "id" : 258721812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56976610355724288",
  "text" : "RT @MyMathCloud: A topologist is a person who doesn't know the difference between a coffee cup and a doughnut.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56976167458193409",
    "text" : "A topologist is a person who doesn't know the difference between a coffee cup and a doughnut.",
    "id" : 56976167458193409,
    "created_at" : "2011-04-10 07:05:51 +0000",
    "user" : {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "protected" : false,
      "id_str" : "258721812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2965777663\/5bb5d3206072ca9112470f291e368645_normal.png",
      "id" : 258721812,
      "verified" : false
    }
  },
  "id" : 56976610355724288,
  "created_at" : "2011-04-10 07:07:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56976576503496704",
  "text" : "\u30D3\u30E9\u4F5C\u6210\u306A\u3046\u30FC\u3002\u306A\u305C\u304B\u30D5\u30A9\u30C8\u30B7\u30E7\u30C3\u30D7\u5165\u3063\u3066\u3066\u52A9\u304B\u308B\u3002",
  "id" : 56976576503496704,
  "created_at" : "2011-04-10 07:07:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "indices" : [ 3, 15 ],
      "id_str" : "258721812",
      "id" : 258721812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56919067822538753",
  "text" : "RT @MyMathCloud: I have only to touch mathematics, and I forget everything else on earth.  Sonya Kovalevsky",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56913502203416576",
    "text" : "I have only to touch mathematics, and I forget everything else on earth.  Sonya Kovalevsky",
    "id" : 56913502203416576,
    "created_at" : "2011-04-10 02:56:50 +0000",
    "user" : {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "protected" : false,
      "id_str" : "258721812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2965777663\/5bb5d3206072ca9112470f291e368645_normal.png",
      "id" : 258721812,
      "verified" : false
    }
  },
  "id" : 56919067822538753,
  "created_at" : "2011-04-10 03:18:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56917463580942337",
  "text" : "\uFF13\u5EA6\u5BDD\u3057\u305F\u304B\u3089\u5922\u898B\u304C\u826F\u304B\u3063\u305F\u3002",
  "id" : 56917463580942337,
  "created_at" : "2011-04-10 03:12:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56682622511886336",
  "text" : "@ayu167 \u30AF\u30FC\u30FB\u30AF\u30E9\u30C3\u30AF\u30B9\u30FB\u30AF\u30E9\u30F3",
  "id" : 56682622511886336,
  "created_at" : "2011-04-09 11:39:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "indices" : [ 3, 15 ],
      "id_str" : "258721812",
      "id" : 258721812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56575051226558464",
  "text" : "RT @MyMathCloud: The only angle from which to approach a problem is the TRY-Angle.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56571144060403712",
    "text" : "The only angle from which to approach a problem is the TRY-Angle.",
    "id" : 56571144060403712,
    "created_at" : "2011-04-09 04:16:26 +0000",
    "user" : {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "protected" : false,
      "id_str" : "258721812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2965777663\/5bb5d3206072ca9112470f291e368645_normal.png",
      "id" : 258721812,
      "verified" : false
    }
  },
  "id" : 56575051226558464,
  "created_at" : "2011-04-09 04:31:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56559917066223616",
  "text" : "\u591A\u5206\u8D77\u304D\u305F\u3002\u7A7A\u8179\u3045\u3002",
  "id" : 56559917066223616,
  "created_at" : "2011-04-09 03:31:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56379928286998528",
  "text" : "\u5BDD\u308B\uFF6F\uFF01\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 56379928286998528,
  "created_at" : "2011-04-08 15:36:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56378045380046849",
  "text" : "@koketomi \u30D2\u30BD\u30A6\u30C6\u30F3\u30BD\u30AF\u51FA\u3066\u304B\u3089\u30B1\u30ED\u3061\u3083\u3093\u306E\u682A\u304C\u4E0A\u304C\u3063\u3066\u308B\u3002",
  "id" : 56378045380046849,
  "created_at" : "2011-04-08 15:29:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56367387334811648",
  "text" : "\u304A\u307F\u304F\u3058\uFF1F",
  "id" : 56367387334811648,
  "created_at" : "2011-04-08 14:46:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56366257041190912",
  "text" : "\u660E\u65E5\u306E\u304A\u5915\u98EF\u306F\u6E6F\u8C46\u8150\u306B\u3057\u3088\u3046",
  "id" : 56366257041190912,
  "created_at" : "2011-04-08 14:42:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56365860054503424",
  "text" : "\u306B\u305B\u307B\u306B\u3064\u3044\u3066\u4E00\u901A\u308A\u8AAD\u3093\u3067\u307F\u305F\u3051\u3069\u3001\u53CD\u5FDC\u3055\u308C\u306A\u3044\u306E\u306F\u3044\u3061\u3044\u3061\u30C4\u30A4\u30FC\u30C8\u304C\u9577\u3044\u304B\u3089\u304B\uFF57\u307E\u3041\u3044\u3044\u3051\u3069\u3001\u826F\u304F\u51FA\u6765\u305F\u304A\u3082\u3061\u3083\u3060\u306A\uFF57 http:\/\/goo.gl\/LIFcr",
  "id" : 56365860054503424,
  "created_at" : "2011-04-08 14:40:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56360585713025024",
  "geo" : { },
  "id_str" : "56361267123847168",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u78BA\u304B\u306B\u3001\u56DB\u89D2\u3044\u673A\u3068\u4EBA\u9593\u304C\uFF14\u4EBA\u305D\u308D\u3046\u306A\u3089\u4F1A\u3063\u3066\u3082\u3044\u3044\u304B\u3082\u3002\u3067\u3082\u307E\u3041\u73FE\u72B6\u306B\u6E80\u8DB3\u3002",
  "id" : 56361267123847168,
  "in_reply_to_status_id" : 56360585713025024,
  "created_at" : "2011-04-08 14:22:27 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56357666490028032",
  "geo" : { },
  "id_str" : "56359135029112833",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30D3\u30EA\u30E4\u30FC\u30C9\u53F0\u306A\u3044\u306E\u306B\uFF22\uFF4F\uFF58\u3042\u3063\u3066\u3082\u3057\u3087\u3046\u304C\u306A\u3044\u306E\u3055\uFF57",
  "id" : 56359135029112833,
  "in_reply_to_status_id" : 56357666490028032,
  "created_at" : "2011-04-08 14:13:59 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56356739628544000",
  "geo" : { },
  "id_str" : "56357197625573376",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3057\u304B\u3057\u30DC\u30C3\u30AF\u30B9\u306F\u6301\u3063\u3066\u3044\u308B\u3068\u3044\u3046\u3002",
  "id" : 56357197625573376,
  "in_reply_to_status_id" : 56356739628544000,
  "created_at" : "2011-04-08 14:06:17 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56347275080896512",
  "geo" : { },
  "id_str" : "56347431251619840",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u53D7\u3051\u308B\u306A\u3089\u305C\u3072\u4E00\u7DD2\u306B\uFF57",
  "id" : 56347431251619840,
  "in_reply_to_status_id" : 56347275080896512,
  "created_at" : "2011-04-08 13:27:29 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56345538555162624",
  "text" : "\u4F55\u3067\u306B\u305B\u307B\u304C\u653E\u6D6A\u606F\u5B50\u306E\u8A71\u3057\u3066\u3093\u3060\uFF57\uFF57\uFF57\u7B11\u3063\u3066\u3057\u307E\u3063\u305F\uFF57",
  "id" : 56345538555162624,
  "created_at" : "2011-04-08 13:19:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3053\u306A\u3057@Dies irae\u30A2\u30CB\u30E1\u5316\u5FDC\u63F4",
      "screen_name" : "Coconashi",
      "indices" : [ 3, 13 ],
      "id_str" : "209591322",
      "id" : 209591322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56345328911257600",
  "text" : "RT @Coconashi: \u91CE\u539F\u3072\u308D\u3057\u3063\u3066\u300130\u534A\u3070\u3067\u5927\u624B\u4F01\u696D\u306E\u7BA1\u7406\u8077\u3067\u30DE\u30A4\u30DB\u30FC\u30E0\u6301\u3061\u3067\u3001\u7D66\u6599\u3060\u3063\u3066\u5BB6\u306E\u30ED\u30FC\u30F3\u304C\u3042\u308B\u3051\u3069\u3001\u307F\u3055\u3048\u304C\u3053\u3063\u305D\u308A\u5BB6\u306B\u4FDD\u967A\u5165\u308C\u3089\u308C\u308B\u91D1\u92AD\u7684\u4F59\u88D5\u3082\u3042\u308B\u3001\u3057\u304B\u3082\u59BB\u5B50\u6301\u3061\u3060\u304B\u3089\u3059\u3052\u3048\u52DD\u3061\u7D44\u3060\u3088\u306A\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56336216370581504",
    "text" : "\u91CE\u539F\u3072\u308D\u3057\u3063\u3066\u300130\u534A\u3070\u3067\u5927\u624B\u4F01\u696D\u306E\u7BA1\u7406\u8077\u3067\u30DE\u30A4\u30DB\u30FC\u30E0\u6301\u3061\u3067\u3001\u7D66\u6599\u3060\u3063\u3066\u5BB6\u306E\u30ED\u30FC\u30F3\u304C\u3042\u308B\u3051\u3069\u3001\u307F\u3055\u3048\u304C\u3053\u3063\u305D\u308A\u5BB6\u306B\u4FDD\u967A\u5165\u308C\u3089\u308C\u308B\u91D1\u92AD\u7684\u4F59\u88D5\u3082\u3042\u308B\u3001\u3057\u304B\u3082\u59BB\u5B50\u6301\u3061\u3060\u304B\u3089\u3059\u3052\u3048\u52DD\u3061\u7D44\u3060\u3088\u306A\u3002",
    "id" : 56336216370581504,
    "created_at" : "2011-04-08 12:42:55 +0000",
    "user" : {
      "name" : "\u3053\u3053\u306A\u3057@Dies irae\u30A2\u30CB\u30E1\u5316\u5FDC\u63F4",
      "screen_name" : "Coconashi",
      "protected" : false,
      "id_str" : "209591322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598430457059876864\/_JBUB_im_normal.png",
      "id" : 209591322,
      "verified" : false
    }
  },
  "id" : 56345328911257600,
  "created_at" : "2011-04-08 13:19:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56339459330940928",
  "text" : "\u660E\u65E5\u30D3\u30E9\u3064\u304F\u308D\u3002\u3042\u3068\uFF11\u4EBA\u304B\uFF12\u4EBA\u304F\u308B\u898F\u6A21\u3067\u52E7\u8A98\u6D3B\u52D5\u3063\u3066\u9006\u306B\u96E3\u3057\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u3051\u308C\u3069\u3002",
  "id" : 56339459330940928,
  "created_at" : "2011-04-08 12:55:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56333045334163456",
  "geo" : { },
  "id_str" : "56333981582499841",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u6A2A\u69CD\u3067\u3054\u3081\u3093\u3088\u3002\u305D\u308C\u306F\u3061\u3087\u3063\u3068\u50B7\u3064\u304F\u304B\u3082\u3002\u7121\u8996\u5B89\u5B9A\uFF01",
  "id" : 56333981582499841,
  "in_reply_to_status_id" : 56333045334163456,
  "created_at" : "2011-04-08 12:34:02 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "indices" : [ 3, 14 ],
      "id_str" : "161635350",
      "id" : 161635350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56319214780297216",
  "text" : "RT @kisalantis: \u4ECA\u65E5\u306F\u3069\u3053\u3082\u304B\u3057\u3053\u3082\u98F2\u307F\u4F1A\u306A\u96F0\u56F2\u6C17\u306D\u3002\u3053\u3093\u306A\u306B\u8857\u304C\u6D3B\u6C17\u4ED8\u3044\u305F\u306E\u306F\u4E45\u3057\u3076\u308A\u304B\u3082\u3002\u826F\u3044\u4E8B\u3060\u3068\u601D\u3044\u307E\u3059\u304C\u3001\u79C1\u306F\u308F\u3056\u308F\u3056\u6DF7\u3093\u3067\u308B\u6642\u306B\u98F2\u307F\u306B\u884C\u3063\u305F\u308A\u306F\u3057\u307E\u305B\u3093\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56317939355361280",
    "text" : "\u4ECA\u65E5\u306F\u3069\u3053\u3082\u304B\u3057\u3053\u3082\u98F2\u307F\u4F1A\u306A\u96F0\u56F2\u6C17\u306D\u3002\u3053\u3093\u306A\u306B\u8857\u304C\u6D3B\u6C17\u4ED8\u3044\u305F\u306E\u306F\u4E45\u3057\u3076\u308A\u304B\u3082\u3002\u826F\u3044\u4E8B\u3060\u3068\u601D\u3044\u307E\u3059\u304C\u3001\u79C1\u306F\u308F\u3056\u308F\u3056\u6DF7\u3093\u3067\u308B\u6642\u306B\u98F2\u307F\u306B\u884C\u3063\u305F\u308A\u306F\u3057\u307E\u305B\u3093\u3002",
    "id" : 56317939355361280,
    "created_at" : "2011-04-08 11:30:17 +0000",
    "user" : {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "protected" : false,
      "id_str" : "161635350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451385034910347265\/OhkVStyG_normal.jpeg",
      "id" : 161635350,
      "verified" : false
    }
  },
  "id" : 56319214780297216,
  "created_at" : "2011-04-08 11:35:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "indices" : [ 3, 10 ],
      "id_str" : "15570902",
      "id" : 15570902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56297093643505664",
  "text" : "RT @m_soba: \u3088\u304F\u300C\u5B66\u751F\u306F\u52C9\u5F37\u3059\u308B\u306E\u304C\u4ED5\u4E8B\u300D\u3063\u3066\u8A00\u3046\u3051\u3069\u3001\u3082\u3057\u305D\u308C\u304C\u672C\u5F53\u3060\u3068\u3057\u305F\u3089\u3001\u5E73\u5747\u7684\u306A\u53D7\u9A13\u751F\u306F\u307E\u305A\u9AD8\u6821\u30677\u6642\u9593\u307B\u3069\u52E4\u52D9\u3057\u3001\u305D\u306E\u5F8C\u587E\u3084\u81EA\u5B85\u30673\u6642\u9593\u4EE5\u4E0A\u306E\u6301\u3061\u5E30\u308A\u6B8B\u696D\u3001\u571F\u65E5\u795D\u65E5\u30825\u6642\u9593\u4EE5\u4E0A\u306E\u4F11\u65E5\u52B4\u50CD\u304C\u3042\u308B\u305F\u3081\u5E74\u9593\u52B4\u50CD\u6642\u9593\u306F3000\u6642\u9593\u3092\u512A\u306B\u8D85\u3048\u3001\u3053\u308C\u306F\u904E\u52B4\u6B7B\u8A8D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"erased_102559\" rel=\"nofollow\"\u003Eerased_102559\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55622042279620608",
    "text" : "\u3088\u304F\u300C\u5B66\u751F\u306F\u52C9\u5F37\u3059\u308B\u306E\u304C\u4ED5\u4E8B\u300D\u3063\u3066\u8A00\u3046\u3051\u3069\u3001\u3082\u3057\u305D\u308C\u304C\u672C\u5F53\u3060\u3068\u3057\u305F\u3089\u3001\u5E73\u5747\u7684\u306A\u53D7\u9A13\u751F\u306F\u307E\u305A\u9AD8\u6821\u30677\u6642\u9593\u307B\u3069\u52E4\u52D9\u3057\u3001\u305D\u306E\u5F8C\u587E\u3084\u81EA\u5B85\u30673\u6642\u9593\u4EE5\u4E0A\u306E\u6301\u3061\u5E30\u308A\u6B8B\u696D\u3001\u571F\u65E5\u795D\u65E5\u30825\u6642\u9593\u4EE5\u4E0A\u306E\u4F11\u65E5\u52B4\u50CD\u304C\u3042\u308B\u305F\u3081\u5E74\u9593\u52B4\u50CD\u6642\u9593\u306F3000\u6642\u9593\u3092\u512A\u306B\u8D85\u3048\u3001\u3053\u308C\u306F\u904E\u52B4\u6B7B\u8A8D\u5B9A\u57FA\u6E96\u3092\u5927\u5E45\u306B\u4E0A\u56DE\u308B\u6570\u5B57\u3068\u306A\u308B\u3002",
    "id" : 55622042279620608,
    "created_at" : "2011-04-06 13:25:02 +0000",
    "user" : {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "protected" : false,
      "id_str" : "15570902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484672991460982784\/o-QnjXOh_normal.png",
      "id" : 15570902,
      "verified" : false
    }
  },
  "id" : 56297093643505664,
  "created_at" : "2011-04-08 10:07:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30F3\u30B5\u30A4\u30AF\u30ED\u30DA\u30C7\u30A3\u30A2BOT\u65E5\u672C\u8A9E\u7248",
      "screen_name" : "AnsaiBot",
      "indices" : [ 3, 12 ],
      "id_str" : "72766956",
      "id" : 72766956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56197598045945857",
  "text" : "RT @AnsaiBot: \u30A8\u30F3\u30C9\u30EC\u30B9\u30D5\u30A1\u30C3\u30AF\u30B9 http:\/\/bit.ly\/gGWixT \u30A8\u30F3\u30C9\u30EC\u30B9\u30D5\u30A1\u30C3\u30AF\u30B9\u3068\u306F\u3001\u53D7\u4FE1\u8005\u306B\u5BFE\u3057\u7D42\u308F\u308B\u3053\u3068\u306E\u306A\u3044\u30D5\u30A1\u30C3\u30AF\u30B9\u306E\u9001\u4FE1\u3092\u884C\u3044\u3001\u9AD8\u4FA1\u306A\u30D5\u30A1\u30C3\u30AF\u30B9\u7528\u7D19\u3092\u7121\u99C4\u9063\u3044\u3055\u305B\u308B\u3068\u3044\u3046\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u30B9\u30DD\u30FC\u30C4\u3067\u3042\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/mohayonao\/mohayonao-bot\" rel=\"nofollow\"\u003Emohayonao-bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56197365756989440",
    "text" : "\u30A8\u30F3\u30C9\u30EC\u30B9\u30D5\u30A1\u30C3\u30AF\u30B9 http:\/\/bit.ly\/gGWixT \u30A8\u30F3\u30C9\u30EC\u30B9\u30D5\u30A1\u30C3\u30AF\u30B9\u3068\u306F\u3001\u53D7\u4FE1\u8005\u306B\u5BFE\u3057\u7D42\u308F\u308B\u3053\u3068\u306E\u306A\u3044\u30D5\u30A1\u30C3\u30AF\u30B9\u306E\u9001\u4FE1\u3092\u884C\u3044\u3001\u9AD8\u4FA1\u306A\u30D5\u30A1\u30C3\u30AF\u30B9\u7528\u7D19\u3092\u7121\u99C4\u9063\u3044\u3055\u305B\u308B\u3068\u3044\u3046\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u30B9\u30DD\u30FC\u30C4\u3067\u3042\u308B\u3002",
    "id" : 56197365756989440,
    "created_at" : "2011-04-08 03:31:10 +0000",
    "user" : {
      "name" : "\u30A2\u30F3\u30B5\u30A4\u30AF\u30ED\u30DA\u30C7\u30A3\u30A2BOT\u65E5\u672C\u8A9E\u7248",
      "screen_name" : "AnsaiBot",
      "protected" : false,
      "id_str" : "72766956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2154714127\/AnsaiBot_normal.png",
      "id" : 72766956,
      "verified" : false
    }
  },
  "id" : 56197598045945857,
  "created_at" : "2011-04-08 03:32:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56196731678892032",
  "text" : "\u96E8\u3058\u3083\u306A\u304D\u3083\u5916\u3092\u3075\u3089\u3075\u3089\u3059\u308B\u306E\u304C\u6C17\u6301\u3061\u826F\u3055\u305D\u3046\u306A\u306E\u306B\u306A\u30FC\u3002",
  "id" : 56196731678892032,
  "created_at" : "2011-04-08 03:28:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56164313831981056",
  "text" : "\u96E8\u3060\u304C\u3001\u5E30\u308A\u81EA\u8EE2\u8ECA\u3067\u5927\u4E08\u592B\u304B\uFF1F",
  "id" : 56164313831981056,
  "created_at" : "2011-04-08 01:19:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56161042161610752",
  "text" : "\u6625\u96E8\u304B\u3002\u5FAE\u5999\u306A\u5929\u6C17\u3002",
  "id" : 56161042161610752,
  "created_at" : "2011-04-08 01:06:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56009761698742272",
  "geo" : { },
  "id_str" : "56010619832373249",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4FFA\u3082\u591A\u5206\u975E\u5E38\u52E4\u2026\u306A\u308B\u3088\u3046\u306B\u306A\u308B\u3068\u4FE1\u3058\u3066\u3044\u308B\u3002",
  "id" : 56010619832373249,
  "in_reply_to_status_id" : 56009761698742272,
  "created_at" : "2011-04-07 15:09:07 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56004293307797507",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 15\u664200\u5206\uFF5E16\u664230\u5206\u3089\u3057\u3044\u3088 \u3064 http:\/\/goo.gl\/IWIFe",
  "id" : 56004293307797507,
  "created_at" : "2011-04-07 14:43:58 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56003574517350401",
  "text" : "\uFF54\uFF4B\uFF14\u9650\u3063\u3066\u5065\u5EB7\u8A3A\u65AD\u306E\u6642\u9593\u3068\u304B\u3076\u3063\u3066\u308B\u3045",
  "id" : 56003574517350401,
  "created_at" : "2011-04-07 14:41:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56003173814513665",
  "text" : "\uFF14\u9650\u306E\u7DDA\u5F62\u3082\u4E00\u56DE\u3067\u3066\u307F\u3066\u30A2\u30EC\u306A\u3089\u72EC\u5B66\u306B\u5207\u308A\u66FF\u3048\u3088\u3046\u3002",
  "id" : 56003173814513665,
  "created_at" : "2011-04-07 14:39:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56002731504189440",
  "text" : "\u8981\u77F3\u307F\u305F\u3044\u306A\u90FD\u5408\u306E\u3044\u3044\u30A2\u30A4\u30C6\u30E0\u7121\u3044\u306E\u304B\u306D\u3002",
  "id" : 56002731504189440,
  "created_at" : "2011-04-07 14:37:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56002596661510148",
  "text" : "\u307E\u305F\u5927\u304D\u305D\u3046\u306A\u81EA\u4FE1\u306D\u3002",
  "id" : 56002596661510148,
  "created_at" : "2011-04-07 14:37:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56002497147445249",
  "text" : "\uFF11\uFF10\uFF1A\uFF13\uFF10\uFF5E\u3060\u3063\u3051\uFF1F",
  "id" : 56002497147445249,
  "created_at" : "2011-04-07 14:36:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56002386875002880",
  "text" : "\u307E\u305A\uFF12\u9650\u304C\u4F55\u6642\u304B\u3089\u3060\u3063\u305F\u304B\u8003\u3048\u308B\u306E\u304C\u9762\u5012",
  "id" : 56002386875002880,
  "created_at" : "2011-04-07 14:36:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55997179751436288",
  "text" : "\u6C34\u66DC\u3068\u6728\u66DC\u30AC\u30E9\u30AC\u30E9\u2026\u6587\u5B66\u90E8\u79D1\u76EE\u5165\u308C\u308B\u3060\u308D\u3046\u3051\u3069\u9031\u672B\u306B\u8003\u3048\u3066\u307F\u3088\u3046\u3002",
  "id" : 55997179751436288,
  "created_at" : "2011-04-07 14:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55996407219363840",
  "text" : "\u6559\u80B2\u8003\u3048\u308B\u3068\u5FAE\u7A4D\u53D6\u308C\u306A\u3044\u2026\u3002\u307E\u3041\u3044\u3044\u304B\u3001\u72EC\u5B66\u3067\u3002",
  "id" : 55996407219363840,
  "created_at" : "2011-04-07 14:12:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55977024602386433",
  "text" : "\u660E\u65E5\u304B\u3089\u6388\u696D\u3084\u308B\u306E\u304B\uFF1F\u5065\u5EB7\u8A3A\u65AD\u3063\u3066\u4F55\u6642\u304B\u3089\uFF1F\u308F\u3051\u304C\u308F\u304B\u3089\u306A\u3044\u3088\u3002",
  "id" : 55977024602386433,
  "created_at" : "2011-04-07 12:55:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55954737476009985",
  "text" : "\u7D50\u5C40\u6388\u696D\u3063\u3066\u660E\u65E5\u304B\u3089\u3042\u308B\u306E\u304B\u306A\u30FB\u30FB\u30FB\uFF1F",
  "id" : 55954737476009985,
  "created_at" : "2011-04-07 11:27:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55863786652971008",
  "geo" : { },
  "id_str" : "55863941473120256",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30B5\u30F3\u30AF\u30B9\u300230\u679A\u304F\u3089\u3044\u6492\u3044\u3068\u3053\u3046\u304B\u306A\u3001\u3068\u601D\u3063\u3066\u3002",
  "id" : 55863941473120256,
  "in_reply_to_status_id" : 55863786652971008,
  "created_at" : "2011-04-07 05:26:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55862261113303040",
  "geo" : { },
  "id_str" : "55863230647644160",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306D\u3047\u306D\u3047\u3001\u30D3\u30E9\u306F\u3063\u305F\u308A\u914D\u3063\u305F\u308A\u3059\u308B\u306E\u3063\u3066\u8A31\u53EF\u3068\u66F8\u767B\u9332\u3068\u304B\u3044\u308B\u306E\uFF1F",
  "id" : 55863230647644160,
  "in_reply_to_status_id" : 55862261113303040,
  "created_at" : "2011-04-07 05:23:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55852387251912705",
  "text" : "\u306F\u308B\u3046\u3089\u3089",
  "id" : 55852387251912705,
  "created_at" : "2011-04-07 04:40:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55650761610244097",
  "text" : "\u611A\u8005\u306F\u6559\u3048\u305F\u304C\u308A\u3001\u8CE2\u8005\u306F\u5B66\u3073\u305F\u304C\u308B",
  "id" : 55650761610244097,
  "created_at" : "2011-04-06 15:19:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55645049748328451",
  "geo" : { },
  "id_str" : "55645424429694976",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u96E8\u964D\u308B\u306E\uFF1F",
  "id" : 55645424429694976,
  "in_reply_to_status_id" : 55645049748328451,
  "created_at" : "2011-04-06 14:57:57 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55643062550003712",
  "text" : "\u4E88\u5099\u767B\u9332\u3057\u305F\u79D1\u76EE\u3068\u5C02\u9580\u30D0\u30C3\u30C6\u30A3\u30F3\u30B0\u3057\u3066\u6CE3\u304F\u6CE3\u304F\u4E88\u7D04\u53D6\u308A\u6D88\u3057\u3057\u305F\u3002\u660E\u65E5\u5927\u5B66\u884C\u3063\u3066\u4E88\u5099\u767B\u9332\u3057\u306A\u304A\u3055\u306A\u3070\u30FB\u30FB\u30FB\u3002\n\uFF54\uFF4B\u53D6\u308A\u305F\u3044\u8A9E\u5B66\u306E\u3068\u3053\u308D\u306B\u5C02\u9580\u3042\u308A\u3059\u304E\u3002",
  "id" : 55643062550003712,
  "created_at" : "2011-04-06 14:48:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55634660369248256",
  "text" : "\u5C02\u9580\u79D1\u76EE\u96C6\u4E2D\u8B1B\u7FA9\u3092\u5927\u91CF\u306B\u8A70\u3081\u308B\u3068\u3044\u3046\u4F5C\u6226\u306B\u51FA\u3066\u307F\u3088\u3046\u304B\u306A\u3002\u4F11\u307F\u524A\u3089\u308C\u308B\u3051\u3069\u6642\u9593\u5358\u4F4D\u306E\u52B9\u7387\u306F\u3044\u3044\u306F\u305A\u3002",
  "id" : 55634660369248256,
  "created_at" : "2011-04-06 14:15:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55626468423766017",
  "text" : "\u6C7A\u3057\u3066\u307C\u3063\u3061\u3067\u306F\u306A\u3044\u306B\u3057\u3066\u3082\u3001\u3082\u3046\u5C11\u3057\u53CB\u9054\u4F5C\u3063\u3066\u304A\u3044\u3066\u3082\u3088\u304B\u3063\u305F\u304B\u306A\u3001\u3068\u601D\u3044\u59CB\u3081\u305F\u3002\u5F8C\u3067\u53D6\u6368\u9078\u629E\u3067\u304D\u308B\u3057\u2190",
  "id" : 55626468423766017,
  "created_at" : "2011-04-06 13:42:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55616293906284544",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u30CE\u30FC\u30C8PC\u306E\u58C1\u7D19\u304C\u521D\u671F\u8A2D\u5B9A\u306E\u307E\u307E\u3060\u306A\u3002\u5909\u3048\u3088\u3046\u304B\u306A\u3002",
  "id" : 55616293906284544,
  "created_at" : "2011-04-06 13:02:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55612591241838592",
  "geo" : { },
  "id_str" : "55613375031410688",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u306F\u30DE\u30A4\u30F3\u30B9\u30A4\u30FC\u30D1\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u3069\u306A\u3041\uFF57",
  "id" : 55613375031410688,
  "in_reply_to_status_id" : 55612591241838592,
  "created_at" : "2011-04-06 12:50:36 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55612233253781504",
  "text" : "\u3069\u3046\u305B\u305D\u306E\u3046\u3061\u5FD9\u3057\u304F\u306A\u308B\u306E\u3060\u304B\u3089\u3002",
  "id" : 55612233253781504,
  "created_at" : "2011-04-06 12:46:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55612169303244800",
  "text" : "\u9000\u5C48\u306F\u4EBA\u3092\u6BBA\u3059\u3089\u3057\u3044\u304C\u3001\u9000\u5C48\u306F\u9000\u5C48\u3067\u5ACC\u3044\u3058\u3083\u306A\u3044\u3002",
  "id" : 55612169303244800,
  "created_at" : "2011-04-06 12:45:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55592008726740993",
  "text" : "\u5F8C\u80A9\u30B3\u30EA\u3067\u982D\u75DB\u30FB\u30FB\u30FB",
  "id" : 55592008726740993,
  "created_at" : "2011-04-06 11:25:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55591459264528384",
  "text" : "\u3042\u30FC\u5C65\u4FEE\u8003\u3048\u306A\u304D\u3083\u3044\u304B\u3093\u306E\u306B\u4F55\u306B\u3082\u3084\u308B\u6C17\u3057\u306A\u3044\u3057\u7720\u3044",
  "id" : 55591459264528384,
  "created_at" : "2011-04-06 11:23:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55591205823721472",
  "geo" : { },
  "id_str" : "55591349730295808",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6A5F\u4F1A\u304C\u3042\u3063\u305F\u3089\u8CB8\u3057\u3066\u304F\u308C\uFF57",
  "id" : 55591349730295808,
  "in_reply_to_status_id" : 55591205823721472,
  "created_at" : "2011-04-06 11:23:05 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54876568220217346",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 54876568220217346,
  "created_at" : "2011-04-04 12:02:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54876475987476480",
  "text" : "\u3053\u308C\u3067\u660E\u65E5\u3082\u3055\u3059\u304C\u306B9\u6642\u300110\u6642\u306B\u306F\u81EA\u7136\u306B\u8D77\u304D\u3066\u6D3B\u52D5\u3057\u3066\u3044\u308B\u3053\u3068\u3060\u308D\u3046\u3002",
  "id" : 54876475987476480,
  "created_at" : "2011-04-04 12:02:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54876375085105152",
  "text" : "9\u6642\u3002\u5BDD\u308B\u3002",
  "id" : 54876375085105152,
  "created_at" : "2011-04-04 12:02:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54863693040717824",
  "text" : "\u77BC\u4EE5\u5916\u304C\u8EFD\u3044\u2026",
  "id" : 54863693040717824,
  "created_at" : "2011-04-04 11:11:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54857598981251072",
  "text" : "\u305B\u3081\u30669\u6642\u307E\u3067\u306F\u9811\u5F35\u3063\u3066\u8D77\u304D\u3066\u3044\u3088\u3046\u3068\u601D\u3046\u3002",
  "id" : 54857598981251072,
  "created_at" : "2011-04-04 10:47:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54857394047549441",
  "text" : "\u7761\u9B54\u30FC\u3002\u30B9\u30A4\u30DE\u30FC\u3002",
  "id" : 54857394047549441,
  "created_at" : "2011-04-04 10:46:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54788830741544960",
  "text" : "\u65B0\u5E74\u5EA6\u306E\u4FBF\u89A7\u3063\u3066\u3088\u304F\u8003\u3048\u305F\u3089\u3069\u3053\u3067\u624B\u306B\u5165\u308C\u308B\u306E\uFF1F",
  "id" : 54788830741544960,
  "created_at" : "2011-04-04 06:14:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54754597427888128",
  "text" : "16\u6642\u304B\u3089\u30AC\u30A4\u30C0\u30F3\u30B9\u3063\u3066\u306E\u304C\u4F55\u304B\u3092\u7269\u8A9E\u3063\u3066\u3044\u308B\u3002",
  "id" : 54754597427888128,
  "created_at" : "2011-04-04 03:58:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54731188480393216",
  "geo" : { },
  "id_str" : "54731456399941633",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \uFF08\u7121\u610F\u8B58\u306B\u5B58\u5728\u3057\u305F\u611F\u899A\u3092\u8A00\u8449\u306B\u2026\uFF09",
  "id" : 54731456399941633,
  "in_reply_to_status_id" : 54731188480393216,
  "created_at" : "2011-04-04 02:26:10 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54731319317495808",
  "text" : "\u4E0B\u3089\u3093\u3053\u3068\u8A00\u3063\u3066\u306A\u3044\u3067\u3084\u308D\u3046\u3002",
  "id" : 54731319317495808,
  "created_at" : "2011-04-04 02:25:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54731271217229824",
  "text" : "\u30CE\u30FC\u30C8\u306E\u5B8C\u5099\u306F\u4EBA\u751F\u306E\u7518\u7F8E\u3002",
  "id" : 54731271217229824,
  "created_at" : "2011-04-04 02:25:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54731111053524993",
  "text" : "\u307E\u3041\u3044\u3044\u3001\u6642\u9593\u306F\u305F\u3063\u3077\u308A\u3042\u308B\u3093\u3060\u3001\u5FA9\u7FD2\u3060\u3068\u601D\u3063\u3066\u4FDD\u7BA1\u3057\u3066\u3057\u307E\u304A\u3046\u3002",
  "id" : 54731111053524993,
  "created_at" : "2011-04-04 02:24:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54730970343030784",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E00\u6A4B\u3082\uFF1F\uFF01\u95A2\u897F\u570F\u9650\u5B9A\u611F\u899A\u304B\u3082\u3002",
  "id" : 54730970343030784,
  "created_at" : "2011-04-04 02:24:14 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54730448856817664",
  "text" : "\u3061\u3087\u3063\u3068\u63A2\u3057\u305F\u3051\u3069\u898B\u5F53\u305F\u3089\u306A\u3044\u30FB\u30FB\u30FB\u3080\u3045\u3002\u3069\u3046\u3057\u305F\u3082\u306E\u304B\u30FC\u3002",
  "id" : 54730448856817664,
  "created_at" : "2011-04-04 02:22:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54729511429869568",
  "text" : "\u3068\u601D\u3044\u306A\u304C\u3089\u30CE\u30FC\u30C8\u304C\u629C\u3051\u3066\u3044\u308B\u306E\u306F\u6C17\u6301\u3061\u60AA\u3044\u3002",
  "id" : 54729511429869568,
  "created_at" : "2011-04-04 02:18:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54729437886943232",
  "text" : "\u6570C\u306E\u30EB\u30FC\u30BA\u30EA\u30FC\u30D5\u3001\u201C\u524D\u534A\u201D\u304C\u843D\u4E01\u3057\u3066\u3044\u308B\u2026\u3069\u3046\u305B\u7DDA\u5F62\u4EE3\u6570\u3067\u884C\u5217\u306E\u6F14\u7B97\u306F\u3046\u3093\u3056\u308A\u3059\u308B\u307B\u3069\u3084\u308B\u304B\u3089\u3001\u3084\u308A\u76F4\u3059\u5FC5\u8981\u306A\u3044\u304B\u306A\u30FB\u30FB\u30FB",
  "id" : 54729437886943232,
  "created_at" : "2011-04-04 02:18:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54672471617585152",
  "text" : "TL\u304C\u307B\u3068\u3093\u3069bot\u3002\u307F\u3093\u306A\u5BDD\u3066\u308B\u3088\u306D\u3001\u305D\u308A\u3083\u3042\u3002",
  "id" : 54672471617585152,
  "created_at" : "2011-04-03 22:31:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54670429452902400",
  "text" : "\u65E5\u5DEE\u3057\u3067\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u304F\u76EE\u304C\u899A\u3081\u305F\u3002\u304A\u306F\u3088\u3046\u3002",
  "id" : 54670429452902400,
  "created_at" : "2011-04-03 22:23:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 11, 22 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54590022355128320",
  "geo" : { },
  "id_str" : "54590439117963264",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn @magokoro84 \u304A\u524D\u3089\u9762\u767D\u3044\u306A\uFF57\uFF57\uFF57",
  "id" : 54590439117963264,
  "in_reply_to_status_id" : 54590022355128320,
  "created_at" : "2011-04-03 17:05:49 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54587754058756096",
  "geo" : { },
  "id_str" : "54588007201767424",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4FFA\u3082\u3002\u767A\u72C2\u3059\u308B\u308F\uFF57",
  "id" : 54588007201767424,
  "in_reply_to_status_id" : 54587754058756096,
  "created_at" : "2011-04-03 16:56:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54577670628982784",
  "geo" : { },
  "id_str" : "54579220986347520",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6CB3\u6D25\u3068\u304B\u89AA\u306E\u5730\u5143\u3067\u5439\u3044\u305F\uFF57\uFF57\uFF57",
  "id" : 54579220986347520,
  "in_reply_to_status_id" : 54577670628982784,
  "created_at" : "2011-04-03 16:21:14 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54555731659202560",
  "text" : "\u3053\u3046\u3044\u3046\u81EA\u5DF1\u77DB\u76FE\u7684\u306A\u306E\u5927\u597D\u304D\uFF57",
  "id" : 54555731659202560,
  "created_at" : "2011-04-03 14:47:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54553289907384320",
  "text" : "\u300C\u3058\u3083\u30FC\u3093\u3058\u3083\u3058\u3083\u3058\u3083\u30FC\u3093\u3058\u3083\u3058\u3083\u30FC\u3093\u3001\u3058\u3083\u30FC\u3093\u3058\u3083\u3093\u3058\u3083\u3058\u3083\u3058\u3083\u30FC\u3093\u300D\u3063\u3066",
  "id" : 54553289907384320,
  "created_at" : "2011-04-03 14:38:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54553150199304193",
  "text" : "\u53CB\u9054\u304C\u65B0\u4E16\u754C\u306E\u3053\u308C\u3092Skype\u5F35\u3063\u3066\u304D\u3066\u3001\u308F\u304B\u3063\u305F\u6642\u306F\u6211\u306A\u304C\u3089\u3059\u3054\u3044\u3068\u601D\u3063\u305F\u3002",
  "id" : 54553150199304193,
  "created_at" : "2011-04-03 14:37:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3067\u3081\u304D\u3093",
      "screen_name" : "demekin_0622",
      "indices" : [ 3, 16 ],
      "id_str" : "220672064",
      "id" : 220672064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54552972071407616",
  "text" : "RT @demekin_0622: \u3053\u3000\u306E\u3000\u56DE\u3000\u7B54\u3000\u8005\u3000\u306B\u3000\u30A8\u3000\u30B9\u3000\u30D1\u3000\u30FC\u3000\u3092\u3000\u611F\u3000\u3058\u3000\u305F\u3000\u4EBA\u3000\u306F\u3000\u516C\u3000\u5F0F\u3000R\u3000T\rhttp:\/\/j.mp\/ei7GOS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54540227041173505",
    "text" : "\u3053\u3000\u306E\u3000\u56DE\u3000\u7B54\u3000\u8005\u3000\u306B\u3000\u30A8\u3000\u30B9\u3000\u30D1\u3000\u30FC\u3000\u3092\u3000\u611F\u3000\u3058\u3000\u305F\u3000\u4EBA\u3000\u306F\u3000\u516C\u3000\u5F0F\u3000R\u3000T\rhttp:\/\/j.mp\/ei7GOS",
    "id" : 54540227041173505,
    "created_at" : "2011-04-03 13:46:18 +0000",
    "user" : {
      "name" : "\u3067\u3081\u304D\u3093",
      "screen_name" : "demekin_0622",
      "protected" : false,
      "id_str" : "220672064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1179873777\/viploader2d6261882_normal.jpg",
      "id" : 220672064,
      "verified" : false
    }
  },
  "id" : 54552972071407616,
  "created_at" : "2011-04-03 14:36:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54547802537209856",
  "geo" : { },
  "id_str" : "54548302527594496",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3046\u3080\uFF57\u3042\u3093\u307E\u308A\u30C9\u30E4\u9854\u3067\u8A00\u3046\u3068\u8AA4\u89E3\u3092\u62DB\u304F\u304B\u3089\u304A\u52E7\u3081\u3057\u306A\u3044\u304C\uFF57",
  "id" : 54548302527594496,
  "in_reply_to_status_id" : 54547802537209856,
  "created_at" : "2011-04-03 14:18:23 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54546334602104832",
  "geo" : { },
  "id_str" : "54547105477427200",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E00\u5FDC\u5143\u3005\u306F\u300C\u53CB\u4EBA\u304C\u4E00\u4EBA\u3067\u3082\u3044\u308C\u3070\u30EA\u30A2\u5145\u300D\u3089\u3057\u3044\u3002\u5927\u5B66\u3067\u5168\u304F\u8A71\u3092\u3059\u308B\u76F8\u624B\u304C\u3044\u306A\u3044\u4EBA\u305F\u3061\u3092\u975E\u30EA\u30A2\u5145\u3068\u3044\u3046\u3089\u3057\u3044\u3002\u307E\u3041\u8EE2\u7528\u306B\u6B21\u3050\u8EE2\u7528\u3067\u5E02\u6C11\u6A29\u3092\u5F97\u305F\u3053\u308D\u306B\u306F\u5143\u306E\u610F\u5473\u306F\u640D\u306A\u308F\u308C\u3066\u308B\u3051\u3069\u306D\u3002",
  "id" : 54547105477427200,
  "in_reply_to_status_id" : 54546334602104832,
  "created_at" : "2011-04-03 14:13:38 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54545669205135360",
  "geo" : { },
  "id_str" : "54546081782054912",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3067\u3082\u30EA\u30A2\u5145\u3068\u3044\u3046\u8A00\u8449\u306F\u305D\u3046\u3044\u3046\u4EBA\u305F\u3061\u306B\u751F\u307F\u51FA\u3055\u308C\u305F\u3068\u3044\u3046\u4E0D\u601D\u8B70",
  "id" : 54546081782054912,
  "in_reply_to_status_id" : 54545669205135360,
  "created_at" : "2011-04-03 14:09:33 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54544891639902208",
  "geo" : { },
  "id_str" : "54545574858461184",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u53CB\u9054\u3044\u306A\u3044\u6388\u696D\u591A\u304B\u3063\u305F\u3051\u3069\u306A\u30FC\u3002\u307E\u3041\u304A\u59C9\u3055\u3093\u306A\u3089\u53CB\u9054\u304F\u3089\u3044\u30B5\u30AF\u30C3\u3068\u4F5C\u308C\u308B\u3067\u3057\u3087\u3002",
  "id" : 54545574858461184,
  "in_reply_to_status_id" : 54544891639902208,
  "created_at" : "2011-04-03 14:07:33 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54541976502153216",
  "geo" : { },
  "id_str" : "54542453293850625",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u7121\u9650\u6B21\u5143\u30D9\u30AF\u30C8\u30EB\u7A7A\u9593\u306B\u304A\u3051\u308Bi (\u30AD\u30EA\u30C3",
  "id" : 54542453293850625,
  "in_reply_to_status_id" : 54541976502153216,
  "created_at" : "2011-04-03 13:55:08 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 21, 32 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashtag_mendoi",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54540640322719744",
  "text" : "\u3075\u3068\u601D\u3063\u305F\u304C\u3001\u3053\u308C\u306A\u3089\u6700\u9AD8\u306B\u9762\u767D\u304B\u3063\u305F \u2192@magokoro84 \u6700\u8FD1\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u3092\u4ED8\u3051\u308B\u306E\u304C\u3081\u3093\u3069\u304F\u3055\u304F\u306A\u3063\u305F\u3000#hashtag_mendoi",
  "id" : 54540640322719744,
  "created_at" : "2011-04-03 13:47:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54539710747508736",
  "text" : "1\uFF5E5\u30B1\u30BF\u304F\u3089\u3044\u306E\u6570\u5B57\u3092\u307F\u308B\u3068\u56E0\u6570\u5206\u89E3\u3057\u305F\u304F\u306A\u308B\u3002\u6570\u5B66\u75C5\u3002#math",
  "id" : 54539710747508736,
  "created_at" : "2011-04-03 13:44:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54538602180382721",
  "text" : "\u307E\u3041\u305D\u308C\u3063\u307D\u3044\u30A6\u30BD\u9078\u3093\u3067\u66F8\u3044\u3066\u308B\u3051\u3069\u306D\u30FC\u2606",
  "id" : 54538602180382721,
  "created_at" : "2011-04-03 13:39:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54538510094446592",
  "text" : "\u305D\u3046\u3044\u3048\u30704\u67081\u65E5\u306Bmixi\u3067\u300C\u7406\u5B66\u90E8\u306B\u8EE2\u5B66\u90E8\u3057\u307E\u3057\u305F\u300D\u3063\u3066\u66F8\u3044\u305F\u3089\u4E00\u4EBA\u91E3\u3089\u308C\u3066\u3066\u7B11\u3063\u305F\u3002",
  "id" : 54538510094446592,
  "created_at" : "2011-04-03 13:39:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54537485761527808",
  "geo" : { },
  "id_str" : "54537788552511488",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u96C7\u308F\u308C\uFF08\uFF1F\uFF09\u90E8\u9577\u3060\u3051\u3069\u306A\u30FC\u3002",
  "id" : 54537788552511488,
  "in_reply_to_status_id" : 54537485761527808,
  "created_at" : "2011-04-03 13:36:36 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54537007355011072",
  "geo" : { },
  "id_str" : "54537230160625664",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30D2\u30F3\u30C8\uFF1A\u52D5\u753B\u30B5\u30A4\u30C8",
  "id" : 54537230160625664,
  "in_reply_to_status_id" : 54537007355011072,
  "created_at" : "2011-04-03 13:34:23 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54537152620531712",
  "text" : "\u56E3\u4F53\u884C\u52D5\u5ACC\u3044\u306E\u4FFA\u304C\u30B5\u30FC\u30AF\u30EB\u306E\u90E8\u9577\u3063\u3066\u306E\u3082\u30A2\u30F3\u30D3\u30D0\u30EC\u30F3\u30C8\u3067\u3044\u3044\u3088\u306D",
  "id" : 54537152620531712,
  "created_at" : "2011-04-03 13:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54534295229956096",
  "geo" : { },
  "id_str" : "54536355073638401",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3053\u3063\u3061\u306B\u7D39\u4ECB\u3057\u3066\u307B\u3057\u3044\u306A\uFF57  \u5DE5\u30FB\u7406\u306E\u304A\u306B\u3083\u306E\u3053\u306A\u3089\u3044\u3089\u306A\u3044",
  "id" : 54536355073638401,
  "in_reply_to_status_id" : 54534295229956096,
  "created_at" : "2011-04-03 13:30:54 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54535934946971648",
  "text" : "\u307E\u3041\u305D\u308C\u3089\u3057\u3044\u3053\u3068\u306F\u3084\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3051\u308C\u3069\u30015\u6708\u3068\u304B\u5165\u3063\u3066\u304B\u3089\u3067\u3044\u3044\u304B\u306A\u30FC\u3001\u3063\u3066\u306E\u304C\u672C\u97F3\u3060\u3051\u3069\u3002",
  "id" : 54535934946971648,
  "created_at" : "2011-04-03 13:29:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54535741086244865",
  "text" : "\u3069\u3053\u306E\u30B5\u30FC\u30AF\u30EB\u3082\u65B0\u5165\u751F\u6B53\u8FCE\u306E\u6642\u671F\u306B\u98F2\u307F\u4F1A\u3070\u3063\u304B\u308A\u3084\u308B\u3063\u3066\u601D\u3063\u3066\u3093\u306A\u3089\u3001\u307E\u305A\u306F\u305D\u306E\u3075\u3056\u3051\u305F\u5E7B\u60F3\u3092\u3076\u3061\u58CA\u3059\uFF01",
  "id" : 54535741086244865,
  "created_at" : "2011-04-03 13:28:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54517212836405248",
  "text" : "\u4E00\u6642\u9593\u5F53\u305F\u308A\u306EAIP\u5236\u9650\u306B\u9054\u3057\u305F\u3002\u9762\u5012\u306A\u3002",
  "id" : 54517212836405248,
  "created_at" : "2011-04-03 12:14:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54512530533523458",
  "text" : "\u4F59\u3063\u305F\u5358\u4F4D\u3092\u58F2\u8CB7\u3067\u304D\u308B\u5236\u5EA6\u306A\u3044\u304B\u306A\u30FC\u3002\u5358\u4F4D\u306E\u305F\u3081\u3058\u3083\u306A\u304F\u3066\u81EA\u5206\u306E\u305F\u3081\u306B\u3068\u3063\u305F\u5358\u4F4D\u3068\u304B\u58F2\u308A\u305F\u3044\u3002",
  "id" : 54512530533523458,
  "created_at" : "2011-04-03 11:56:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54512322588323840",
  "text" : "\u307E\u3041\u3069\u3046\u305B\u7406\u5B66\u90E8\u306E\u5358\u4F4D\u3068\u304B\u8A8D\u5B9A\u3055\u308C\u306A\u3044\u3060\u308D\u3046\u3057\u826F\u3044\u3093\u3060\u3051\u3069\u3055\u30FC",
  "id" : 54512322588323840,
  "created_at" : "2011-04-03 11:55:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54511165220462592",
  "text" : "\u4EAC\u5927\u306E\u5B66\u90E8\u9593\u306E\u5358\u4F4D\u4E92\u63DB\u5236\u5EA6\u3063\u3066\u3069\u3093\u306A\u30B7\u30B9\u30C6\u30E0\u306B\u306A\u3063\u3066\u308B\u3093\u3060\u308D\u3046\u3002\u3068\u601D\u3063\u3066\u8ABF\u3079\u305F\u3051\u3069\u3055\u3063\u3071\u308A\u691C\u7D22\u306B\u5F15\u3063\u304B\u304B\u3089\u306A\u3044\u3002\u3069\u3046\u3057\u305F\u3082\u306E\u304B\u3002",
  "id" : 54511165220462592,
  "created_at" : "2011-04-03 11:50:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54478096832798720",
  "text" : "\u3042\u3068\u8EAB\u5206\u306E\u8A3C\u660E\u304C\u514D\u8A31\u8A3C\u4E00\u3064\u3067\u901A\u308B\u306E\u306F\u697D\u2190",
  "id" : 54478096832798720,
  "created_at" : "2011-04-03 09:39:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54477907854241792",
  "text" : "\u5C45\u4F4F\u7533\u8ACB\u3068\u306F\u4FBF\u5229\u306A\u3053\u3068\u3060\u3002\u5F79\u6240\u95A2\u4FC2\u306F\u66F8\u985E\u304C\u591A\u304F\u3066\u3046\u3093\u3056\u308A\u3059\u308B\u3051\u308C\u3069\u306D",
  "id" : 54477907854241792,
  "created_at" : "2011-04-03 09:38:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54477607491747841",
  "text" : "\u30D1\u30B9\u30DD\u30FC\u30C8\u53D7\u3051\u53D6\u3063\u3066\u304D\u305F\u3002\u65E5\u66DC\u306F\u53D7\u3051\u53D6\u308A\u3060\u3051\u3084\u3063\u3066\u305F\u307F\u305F\u3044\u3002",
  "id" : 54477607491747841,
  "created_at" : "2011-04-03 09:37:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54427000437354497",
  "text" : "RT @Kaibun_bot: \u7530\u4E95\u4E2D\u5F8B\u306E\u30A8\u30ED\u7D75\u306E\u91E3\u308A\u304B\u2026\u6CE3\u3044\u305F (\u305F\u3044\u306A\u304B\u308A\u3064\u306E\u3048\u308D\u3048\u306E\u3064\u308A\u304B\u306A\u3044\u305F) #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 37, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54424513579974657",
    "text" : "\u7530\u4E95\u4E2D\u5F8B\u306E\u30A8\u30ED\u7D75\u306E\u91E3\u308A\u304B\u2026\u6CE3\u3044\u305F (\u305F\u3044\u306A\u304B\u308A\u3064\u306E\u3048\u308D\u3048\u306E\u3064\u308A\u304B\u306A\u3044\u305F) #kaibun",
    "id" : 54424513579974657,
    "created_at" : "2011-04-03 06:06:29 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 54427000437354497,
  "created_at" : "2011-04-03 06:16:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54416098745004032",
  "text" : "RT @tameninaru: \u4ED6\u4EBA\u306B\u8D77\u3053\u3063\u3066\u3044\u308B\u9593\u306F\u3059\u3079\u3066\u304C\u304A\u3082\u3057\u308D\u3044\u3002\uFF08\u30A6\u30A3\u30EB\u30FB\u30ED\u30B8\u30E3\u30FC\u30BA\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54407794316677120",
    "text" : "\u4ED6\u4EBA\u306B\u8D77\u3053\u3063\u3066\u3044\u308B\u9593\u306F\u3059\u3079\u3066\u304C\u304A\u3082\u3057\u308D\u3044\u3002\uFF08\u30A6\u30A3\u30EB\u30FB\u30ED\u30B8\u30E3\u30FC\u30BA\uFF09",
    "id" : 54407794316677120,
    "created_at" : "2011-04-03 05:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 54416098745004032,
  "created_at" : "2011-04-03 05:33:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54217650129219584",
  "text" : "\u305D\u308C\u3067\u3082\u5973\u7269\u306E\u30A4\u30E1\u30FC\u30B8\u5F37\u3044\u306A\u3002",
  "id" : 54217650129219584,
  "created_at" : "2011-04-02 16:24:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54217484072517632",
  "text" : "\u305B\u3063\u304B\u304F\u4EAC\u90FD\u3060\u3057\u6D74\u8863\u3084\u3089\u7740\u7269\u3084\u3089\u5B89\u304F\u58F2\u3063\u3066\u308B\u5E97\u3042\u308A\u305D\u3046\u3060\u3088\u306A\u3041",
  "id" : 54217484072517632,
  "created_at" : "2011-04-02 16:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54217134385020928",
  "text" : "\u6D41\u77F3\u306B\u6C17\u9055\u3044\u3058\u307F\u3066\u307E\u3059\u306D",
  "id" : 54217134385020928,
  "created_at" : "2011-04-02 16:22:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54216871209213953",
  "text" : "\u7121\u3044\u304B\u306A\u30FC\u2190",
  "id" : 54216871209213953,
  "created_at" : "2011-04-02 16:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54216804825960448",
  "text" : "\u30D5\u30E9\u30AF\u30BF\u30EB\u56F3\u5F62\u3092\u5370\u5237\u3057\u305F\u6D74\u8863\u3068\u304B\u8907\u7D20\u51FD\u6570\u3092\u8272\u4F7F\u3063\u3066\u30B0\u30E9\u30D5\u306B\u3057\u305F\u6D74\u8863\u3068\u304B",
  "id" : 54216804825960448,
  "created_at" : "2011-04-02 16:21:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54216359990657024",
  "text" : "\u6065\u305A\u304B\u3057\u3044\u304B\u3089\u5BB6\u304B\u3089\u51FA\u306A\u3044\u3051\u3069\u2190",
  "id" : 54216359990657024,
  "created_at" : "2011-04-02 16:19:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54216233888907264",
  "text" : "\u548C\u88C5\u3044\u3044\u3088\u306A\u3041\u3002\u7740\u308B\u306E\u3082\u898B\u308B\u306E\u3082\u597D\u304D\u3067\u3059\u3002\u590F\u7528\u306B\u6D74\u8863\u3068\u304B\u6B32\u3057\u3044\u306A\u3002",
  "id" : 54216233888907264,
  "created_at" : "2011-04-02 16:18:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54213307409760256",
  "geo" : { },
  "id_str" : "54215887204519936",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E00\u5FDC\u884C\u304F\u3088",
  "id" : 54215887204519936,
  "in_reply_to_status_id" : 54213307409760256,
  "created_at" : "2011-04-02 16:17:29 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54151411616858112",
  "geo" : { },
  "id_str" : "54151718430183424",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u5FD9\u3057\u3044\u306A\u3089\u7121\u7406\u3057\u306A\u304F\u3066\u304A\uFF4B\u3067\u3059\u3002\u4E00\u4EBA\u3068\u306F\u53D6\u308C\u307E\u3057\u305F\u3002\u3082\u3046\u4E00\u4EBA\u306F\u4ECA\u304B\u3089\uFF57",
  "id" : 54151718430183424,
  "in_reply_to_status_id" : 54151411616858112,
  "created_at" : "2011-04-02 12:02:30 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54150647108481024",
  "geo" : { },
  "id_str" : "54150831284555776",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u305D\u3093\u306A\u5148\u8F29\u306B\u706B\u66DC\u65E5\u306B\u30B5\u30FC\u30AF\u30EB\u958B\u50AC\u306E\u304A\u77E5\u3089\u305B\u3067\u3059\uFF57",
  "id" : 54150831284555776,
  "in_reply_to_status_id" : 54150647108481024,
  "created_at" : "2011-04-02 11:58:58 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54145867766177792",
  "text" : "\u753B\u50CF\u5909\u3048\u3066\u307F\u305F\u3002",
  "id" : 54145867766177792,
  "created_at" : "2011-04-02 11:39:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54135662110179328",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u30B2\u30FC\u30C6\u30EB\u306E\u4E0D\u5B8C\u5168\u6027\u5B9A\u7406\u8AAD\u307F\u7D42\u308F\u3063\u305F\u3002\u5F8C\u534A\u306E\u7406\u89E3\u304C\u6D45\u3044\u304B\u3089\u3001\u3042\u305D\u3053\u3060\u3051\u7E70\u308A\u8FD4\u3057\u3066\u3086\u3063\u304F\u308A\u8AAD\u3080\u3053\u3068\u306B\u3057\u3088\u3046\u3002",
  "id" : 54135662110179328,
  "created_at" : "2011-04-02 10:58:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54133096022421504",
  "text" : "@koketomi \u4FFA\u306F\u308F\u304B\u308B\u3051\u3069\u306A\u30FC\u3002\u3042\u306E\u7AFF\u304C\u632F\u52D5\u3059\u308B\u30EF\u30AF\u30EF\u30AF\u611F\u3002\u3082\u3061\u308D\u3093\u98DF\u3079\u308C\u305F\u65B9\u304C\u3044\u3044\u3051\u3069\uFF57\uFF57",
  "id" : 54133096022421504,
  "created_at" : "2011-04-02 10:48:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54121046990798848",
  "geo" : { },
  "id_str" : "54121276662497280",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u300C\u81EA\u5206\u3063\u3066\u898B\u3048\u306B\u304F\u3044\u3002\u300D\u3063\u3066\u898B\u3048\u306B\u304F\u3044\u3002",
  "id" : 54121276662497280,
  "in_reply_to_status_id" : 54121046990798848,
  "created_at" : "2011-04-02 10:01:32 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54107014992891904",
  "text" : "\u62CD\u624B\u3092\u304A\u9858\u3044\u3057\u307E\u3059\u3002\u3068\u540C\u3058\u5302\u3044\u3002",
  "id" : 54107014992891904,
  "created_at" : "2011-04-02 09:04:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3088\u306E\u307D\u3093",
      "screen_name" : "ystt",
      "indices" : [ 3, 8 ],
      "id_str" : "5528722",
      "id" : 5528722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54106941227671553",
  "text" : "RT @ystt: \u300C\u81EA\u7C9B\u3092\u6C42\u3081\u308B\u300D\u3068\u3044\u3046\u306E\u304C\u610F\u5473\u308F\u304B\u3093\u306A\u3044\u3002\u305D\u308C\u3058\u3083\u81EA\u7C9B\u3058\u3083\u306A\u304F\u3066\u4ED6\u7C9B\u3067\u3057\u3087\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54098222255325184",
    "text" : "\u300C\u81EA\u7C9B\u3092\u6C42\u3081\u308B\u300D\u3068\u3044\u3046\u306E\u304C\u610F\u5473\u308F\u304B\u3093\u306A\u3044\u3002\u305D\u308C\u3058\u3083\u81EA\u7C9B\u3058\u3083\u306A\u304F\u3066\u4ED6\u7C9B\u3067\u3057\u3087\u3002",
    "id" : 54098222255325184,
    "created_at" : "2011-04-02 08:29:55 +0000",
    "user" : {
      "name" : "\u3072\u3088\u306E\u307D\u3093",
      "screen_name" : "ystt",
      "protected" : false,
      "id_str" : "5528722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601767397322690561\/gvs4fSO1_normal.jpg",
      "id" : 5528722,
      "verified" : false
    }
  },
  "id" : 54106941227671553,
  "created_at" : "2011-04-02 09:04:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54004170528800768",
  "text" : "\u30D1\u30B9\u30DD\u30FC\u30C8\u53D6\u308A\u306B\u884C\u3053\u3046\u3068\u601D\u3063\u305F\u3089\u571F\u65E5\u304A\u4F11\u307F\u3002\u5F79\u4EBA\u4ED5\u4E8B\u3057\u308D\u3088\u2026\u3002",
  "id" : 54004170528800768,
  "created_at" : "2011-04-02 02:16:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53995643756216322",
  "text" : "\u5E03\u56E3\u304C\u79C1\u3092\u96E2\u3055\u306A\u3044\u3002\u5FC3\u5730\u597D\u3044\u3002",
  "id" : 53995643756216322,
  "created_at" : "2011-04-02 01:42:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53832944833413122",
  "geo" : { },
  "id_str" : "53833263487258624",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u82F1\u8A9E\u3067\u66F8\u3044\u3066\u3042\u308B\u6BB5\u968E\u3067\u9078\u3070\u306C\u3063\uFF57\uFF57",
  "id" : 53833263487258624,
  "in_reply_to_status_id" : 53832944833413122,
  "created_at" : "2011-04-01 14:57:04 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53831255728459777",
  "text" : "\u82F1\u8A9E\u306E\u4E88\u5099\u767B\u9332 \u9031\uFF12\u306E\u3084\u3064\u306B\u3057\u3061\u3083\u3063\u305F\u3093\u3060\u304C\u5927\u4E08\u592B\u306A\u306E\u3060\u308D\u3046\u304B",
  "id" : 53831255728459777,
  "created_at" : "2011-04-01 14:49:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53829408686997504",
  "text" : "\u5915\u65B9\u30A6\u30C8\u30A6\u30C8\u3057\u3066\u305F\u3051\u3069\u305D\u308C\u3067\u3082\u3082\u3046\u7720\u3044\u3002\u6625\u7720\u6681\u3092\u899A\u3048\u305A\u3002",
  "id" : 53829408686997504,
  "created_at" : "2011-04-01 14:41:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53696420317900801",
  "text" : "\u7720\u3044\u30FB\u30FB\u30FB",
  "id" : 53696420317900801,
  "created_at" : "2011-04-01 05:53:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53493185548267520",
  "geo" : { },
  "id_str" : "53493996865077248",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u304A\u304B\u3057\u3044\u306A\u3041\u3001\u3055\u3063\u304D\u52A0\u8302\u5DDD\u30C7\u30EB\u30BF\u306B\u30AD\u30E3\u30E1\u30ED\u30F3\u30C7\u30A3\u30A2\u30B9\u304C\u3044\u305F\u3093\u3060\u3051\u3069\u2026\u3002",
  "id" : 53493996865077248,
  "in_reply_to_status_id" : 53493185548267520,
  "created_at" : "2011-03-31 16:28:57 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53487974473662464",
  "geo" : { },
  "id_str" : "53488199082852352",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5148\u8F29\u3068\u77F3\u4E95\u3061\u3083\u3093\u304C\u5B09\u3005\u3068\u3057\u3066\u884C\u3063\u3066\u304A\u308A\u307E\u3059",
  "id" : 53488199082852352,
  "in_reply_to_status_id" : 53487974473662464,
  "created_at" : "2011-03-31 16:05:55 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "April_Fool",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53486712881561600",
  "text" : "\u30A8\u30A4\u30D7\u30EA\u30EB\u30D5\u30FC\u30EB\u3063\u3066\u300C\u5618\u3092\u3064\u3044\u3066\u3082\u3044\u3044\u65E5\u300D\u3060\u3051\u3069\u300C\u5618\u3092\u3064\u304B\u306A\u304F\u3066\u306F\u3044\u3051\u306A\u3044\u65E5\u300D\u3058\u3083\u306A\u3044\u3093\u3060\u305C\uFF57\uFF57 #April_Fool",
  "id" : 53486712881561600,
  "created_at" : "2011-03-31 16:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53484182197903361",
  "geo" : { },
  "id_str" : "53485909508759552",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u304A\u304B\u3057\u306A\u8A71\u3060\u306A\uFF57\uFF57\uFF57\uFF57\u3055\u3063\u304D\u306E\u79C1\u306E\u8A00\u8449\u306F\u4FE1\u3058\u308B\u3068\u8A00\u3046\u306E\u306B\u300C\u5618\u4E59\uFF57\uFF57\u300D\u304C\u5618\u3067\u3042\u308B\u3068\u306F\u8003\u3048\u306A\u3044\u306E\u304B\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 53485909508759552,
  "in_reply_to_status_id" : 53484182197903361,
  "created_at" : "2011-03-31 15:56:49 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gark.",
      "screen_name" : "Gark_mw",
      "indices" : [ 3, 11 ],
      "id_str" : "197358850",
      "id" : 197358850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53479553108164608",
  "text" : "RT @Gark_mw: \u3010\u901F\u5831\u3011Twltter\u904B\u55B6\u300C\u865A\u507D\u6295\u7A3F\u3092\u884C\u3063\u305F\u5834\u5408\u3001\u5224\u660E\u6B21\u7B2C\u30A2\u30AB\u30A6\u30F3\u30C8\u7121\u671F\u9650\u505C\u6B62\u51E6\u5206\u3000\u30C7\u30DE\u9632\u6B62\u306E\u70BA\u300D\u3000http:\/\/bit.ly\/9G10F0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53475491298033665",
    "text" : "\u3010\u901F\u5831\u3011Twltter\u904B\u55B6\u300C\u865A\u507D\u6295\u7A3F\u3092\u884C\u3063\u305F\u5834\u5408\u3001\u5224\u660E\u6B21\u7B2C\u30A2\u30AB\u30A6\u30F3\u30C8\u7121\u671F\u9650\u505C\u6B62\u51E6\u5206\u3000\u30C7\u30DE\u9632\u6B62\u306E\u70BA\u300D\u3000http:\/\/bit.ly\/9G10F0",
    "id" : 53475491298033665,
    "created_at" : "2011-03-31 15:15:25 +0000",
    "user" : {
      "name" : "Gark.",
      "screen_name" : "Gark_mw",
      "protected" : false,
      "id_str" : "197358850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596702012563066880\/qlLfTWdJ_normal.jpg",
      "id" : 197358850,
      "verified" : false
    }
  },
  "id" : 53479553108164608,
  "created_at" : "2011-03-31 15:31:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "April_Fool",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53479238409531393",
  "text" : "\u7AF9\u3084\u3076\u713C\u3051\u305F\uFF01 #April_Fool",
  "id" : 53479238409531393,
  "created_at" : "2011-03-31 15:30:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53476500019757056",
  "text" : "\u3010\u901F\u5831\u3011\u50B7\u7269\u8A9E\u6620\u753B\u5316\u6C7A\u5B9A",
  "id" : 53476500019757056,
  "created_at" : "2011-03-31 15:19:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E1\u30E9\u30F3\u30B3\u30EA\u30C3\u30AF\u304B\u3050\u3084",
      "screen_name" : "konbu711",
      "indices" : [ 3, 12 ],
      "id_str" : "215201100",
      "id" : 215201100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53476366078853120",
  "text" : "RT @konbu711: \u3010\u901F\u5831\u3011\u3042\u3044\u3055\u3064\u306E\u9B54\u6CD5\u304C\u6620\u753B\u5316\u6C7A\u5B9A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53474322035118081",
    "text" : "\u3010\u901F\u5831\u3011\u3042\u3044\u3055\u3064\u306E\u9B54\u6CD5\u304C\u6620\u753B\u5316\u6C7A\u5B9A",
    "id" : 53474322035118081,
    "created_at" : "2011-03-31 15:10:46 +0000",
    "user" : {
      "name" : "\u30E1\u30E9\u30F3\u30B3\u30EA\u30C3\u30AF\u304B\u3050\u3084",
      "screen_name" : "konbu711",
      "protected" : false,
      "id_str" : "215201100",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604959552740532224\/_9_wMYr8_normal.jpg",
      "id" : 215201100,
      "verified" : false
    }
  },
  "id" : 53476366078853120,
  "created_at" : "2011-03-31 15:18:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53476047869579264",
  "geo" : { },
  "id_str" : "53476207295074304",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u5618\u4E59\uFF57\uFF57",
  "id" : 53476207295074304,
  "in_reply_to_status_id" : 53476047869579264,
  "created_at" : "2011-03-31 15:18:16 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53475966089048064",
  "text" : "RT @Kaibun_bot: \u76F8\u8AC7\u3068\u306F\u3001\u3068\u3093\u3060\u5618 (\u305D\u3046\u3060\u3093\u3068\u306F\u3068\u3093\u3060\u3046\u305D) #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 24, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53475001793396736",
    "text" : "\u76F8\u8AC7\u3068\u306F\u3001\u3068\u3093\u3060\u5618 (\u305D\u3046\u3060\u3093\u3068\u306F\u3068\u3093\u3060\u3046\u305D) #kaibun",
    "id" : 53475001793396736,
    "created_at" : "2011-03-31 15:13:28 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 53475966089048064,
  "created_at" : "2011-03-31 15:17:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53475679945228288",
  "text" : "RT @fuuzin000: \u3010\u62E1\u6563\u5E0C\u671B\u3011\u300C\u4ECA\u65E5\u306F\u30A8\u30A4\u30D7\u30EA\u30EB\u30D5\u30FC\u30EB\u300D\u3068\u3044\u3046\u30C7\u30DE\u304C\u5E83\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u6CE8\u610F\u3057\u3066\u4E0B\u3055\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53472698545868800",
    "text" : "\u3010\u62E1\u6563\u5E0C\u671B\u3011\u300C\u4ECA\u65E5\u306F\u30A8\u30A4\u30D7\u30EA\u30EB\u30D5\u30FC\u30EB\u300D\u3068\u3044\u3046\u30C7\u30DE\u304C\u5E83\u304C\u3063\u3066\u3044\u307E\u3059\u3002\u6CE8\u610F\u3057\u3066\u4E0B\u3055\u3044",
    "id" : 53472698545868800,
    "created_at" : "2011-03-31 15:04:19 +0000",
    "user" : {
      "name" : "\u98A8\u5203",
      "screen_name" : "foojin000",
      "protected" : false,
      "id_str" : "110028896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1829658629\/icon_chirno32420934_normal.gif",
      "id" : 110028896,
      "verified" : false
    }
  },
  "id" : 53475679945228288,
  "created_at" : "2011-03-31 15:16:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "April_Fool",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53475591030177792",
  "text" : "\u3053\u308C\u4ED8\u3044\u3066\u308B\u30C4\u30A4\u30FC\u30C8\u3063\u3066\u5168\u90E8\u5618\u3001\u6CE8\u610F!\u2192#April_Fool",
  "id" : 53475591030177792,
  "created_at" : "2011-03-31 15:15:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53473150259834880",
  "text" : "\u3010RT\u63A8\u5968\u3011\u4ECA\u5E74\u306F\u30A8\u30A4\u30D7\u30EA\u30EB\u30D5\u30FC\u30EB\u4E2D\u6B62\u3089\u3057\u3044\u3067\u3059\u3088",
  "id" : 53473150259834880,
  "created_at" : "2011-03-31 15:06:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]