Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318352684384129024",
  "text" : "\u4E0B\u624B\u3057\u305F\u308910\u5E74\u8FD1\u304Flivedoor mail\u4F7F\u3063\u3066\u305F\u306E\u306B\u306A\u3041",
  "id" : 318352684384129024,
  "created_at" : "2013-03-31 13:22:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/SJ6mU4TwL2",
      "expanded_url" : "http:\/\/mail.livedoor.com\/close.html",
      "display_url" : "mail.livedoor.com\/close.html"
    } ]
  },
  "geo" : { },
  "id_str" : "318352555056971776",
  "text" : "\u3053\u308C\u7D50\u69CB\u56F0\u308B\u2026http:\/\/t.co\/SJ6mU4TwL2",
  "id" : 318352555056971776,
  "created_at" : "2013-03-31 13:22:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318349638480588800",
  "geo" : { },
  "id_str" : "318350180279808001",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4E8C\u518A\u540C\u6642\u306B\u4F7F\u3046\u6A5F\u4F1A\u306F\u6050\u3089\u304F\u8A2A\u308C\u306A\u3044\u306E\u3067\u305D\u3046\u3057\u307E\u3057\u3087\u3046",
  "id" : 318350180279808001,
  "in_reply_to_status_id" : 318349638480588800,
  "created_at" : "2013-03-31 13:12:52 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318349463825563648",
  "text" : "\u4F5C\u696D\u304C\u4E00\u6BB5\u843D\u3057\u305F\u304B\u3089\u4ED6\u696D\u306B\u79FB\u308B",
  "id" : 318349463825563648,
  "created_at" : "2013-03-31 13:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318308476164141056",
  "geo" : { },
  "id_str" : "318349256270434307",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3046\u3061\u306B\u4E8C\u518A\u3042\u308B\u306E\u304C\u4E00\u518A\u3057\u304B\u3042\u308A\u307E\u305B\u3093()[\u304D\u3065\u304B\u306A\u304B\u3063\u305F\u3067\u3057]",
  "id" : 318349256270434307,
  "in_reply_to_status_id" : 318308476164141056,
  "created_at" : "2013-03-31 13:09:11 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318331963775787008",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 318331963775787008,
  "created_at" : "2013-03-31 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318258899956412416",
  "geo" : { },
  "id_str" : "318261685871861762",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u3067\u306F\u307E\u305F(\u5358\u8A9E\u5E33\u6025\u3044\u3067\u5FC5\u8981\u3067\u3059\uFF1F)",
  "id" : 318261685871861762,
  "in_reply_to_status_id" : 318258899956412416,
  "created_at" : "2013-03-31 07:21:13 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315761686114078720",
  "geo" : { },
  "id_str" : "318254417482768384",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u306A\u3093\u3068\u3044\u3046\u304B\u65E2\u306B\u5915\u65B9\u306B\u306A\u308A\u304B\u3051\u3066\u307E\u3059\u304C\u5915\u65B9\u6642\u9593\u3042\u308A\u307E\u3059\u3067\u3057\u3087\u3046\u304B[\u3072\u3069\u3044\u5BDD\u574A]",
  "id" : 318254417482768384,
  "in_reply_to_status_id" : 315761686114078720,
  "created_at" : "2013-03-31 06:52:20 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318118086026858496",
  "text" : "\u3054\u3081\u3093\u3001\u305F\u3076\u309314\u6642\u8FD1\u304F\u307E\u3067\u8D77\u304D\u306A\u3044\u2026\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u2026",
  "id" : 318118086026858496,
  "created_at" : "2013-03-30 21:50:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317969530603331584",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 317969530603331584,
  "created_at" : "2013-03-30 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317652000907091969",
  "text" : "\u5F7C\u304C\u30CF\u30F3\u30B3\u3092\u62BC\u3057\u3066\u308B\u6C17\u306F\u3059\u308B\u3051\u3069",
  "id" : 317652000907091969,
  "created_at" : "2013-03-29 14:58:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317651935488520194",
  "text" : "\u5927\u5B66\u3067\u306E\u30A2\u30EB\u30D0\u30A4\u30C8\u306E\u304A\u7D66\u6599\u306E\u632F\u8FBC\u540D\u7FA9\u304C\"\u30AD\u30E8\u30A6\u30C8\u30C0\u30A4\u30AC\u30AF\u30BD\u30A6\u30C1\u30E8\u30A6 \u30DE\u30C4\u30E2\"\u3067\u5207\u308C\u3066\u308B\u3051\u3069\u3053\u308C\u7DCF\u9577\u540D\u7FA9\u306A\u3093\u3067\u3059\u304B\u306D",
  "id" : 317651935488520194,
  "created_at" : "2013-03-29 14:58:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317650962254819328",
  "text" : "iPhone\/iPad\u306E\u5145\u96FB\u30B1\u30FC\u30D6\u30EB\u4E00\u500B\u30C0\u30E1\u306B\u306A\u3063\u305F\u3093\u3060\u3051\u3069\u6295\u3052\u58F2\u3089\u308C\u3066\u308B\u3068\u805E\u3044\u305F\u304C\u3069\u3053\u3067\u8CB7\u3048\u3070\u826F\u3044\u306E\u3060\u308D\u3046\u3001\u96FB\u6C17\u5C4B\u3055\u3093\uFF1F",
  "id" : 317650962254819328,
  "created_at" : "2013-03-29 14:54:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317650528043692033",
  "text" : "\u5B9F\u969BKU\u52E2\u306E\u591A\u304F\u304C\u7D42\u96FB\u3068\u3044\u3046\u6982\u5FF5\u306B\u5BFE\u3059\u308B\u5B9F\u611F\u306A\u3044",
  "id" : 317650528043692033,
  "created_at" : "2013-03-29 14:52:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eno",
      "screen_name" : "eno____zzz",
      "indices" : [ 3, 14 ],
      "id_str" : "446246695",
      "id" : 446246695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317650405230256128",
  "text" : "RT @eno____zzz: \u307E\u305A\u50D5\u306F\u300C\u7D42\u96FB\u300D\u306A\u308B\u6982\u5FF5\u3092\u7406\u89E3\u305B\u306D\u3070\u306A\u3089\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317650288662179843",
    "text" : "\u307E\u305A\u50D5\u306F\u300C\u7D42\u96FB\u300D\u306A\u308B\u6982\u5FF5\u3092\u7406\u89E3\u305B\u306D\u3070\u306A\u3089\u306A\u3044\u3002",
    "id" : 317650288662179843,
    "created_at" : "2013-03-29 14:51:45 +0000",
    "user" : {
      "name" : "eno",
      "screen_name" : "eno____zzz",
      "protected" : false,
      "id_str" : "446246695",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_6_normal.png",
      "id" : 446246695,
      "verified" : false
    }
  },
  "id" : 317650405230256128,
  "created_at" : "2013-03-29 14:52:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317649567824900097",
  "text" : "\u304B\u308F\u3044\u3044\u3082\u306E\u7E1B\u308A\u3067\u3057\u308A\u3068\u308A\u3084\u308B\u3068\u697D\u3057\u3044\u3067\u3059\u3088[\u306A\u3093\u3067\u3082\u304B\u3093\u3067\u3082\u304B\u308F\u3044\u3044\u3063\u3066\u8A00\u3044\u5F35\u308B\u3088\u3046\u306B\u306A\u308B\uFF01]",
  "id" : 317649567824900097,
  "created_at" : "2013-03-29 14:48:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u305A\u3042\u305A",
      "screen_name" : "azuazut",
      "indices" : [ 0, 8 ],
      "id_str" : "294104006",
      "id" : 294104006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317648731870744576",
  "geo" : { },
  "id_str" : "317649107244163072",
  "in_reply_to_user_id" : 294104006,
  "text" : "@azuazut \u898B\u3066\u898B\u305F\u3051\u3069\u7761\u9B54\u3061\u3083\u3093\u306E\u307E\u307E\u306A\u306E\u3067\u5F7C\u304C\u30ED\u30B0\u30A4\u30F3\u3057\u306A\u3044\u3068\u308F\u304B\u3089\u306A\u3044\u3067\u3059[\u3042\u308B\u3044\u306F\u5225\u57A2\u306A\u306E\u304B\u3082\uFF1F]",
  "id" : 317649107244163072,
  "in_reply_to_status_id" : 317648731870744576,
  "created_at" : "2013-03-29 14:47:03 +0000",
  "in_reply_to_screen_name" : "azuazut",
  "in_reply_to_user_id_str" : "294104006",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317648694478516224",
  "text" : "\u3044\u3084\u3001\u5B09\u3057\u3044\u306E\u3067\u3075\u3041\u307C\u306B\u305F\u3044\u3057\u3066\u30EA\u30D7\u30E9\u30A4\u306F\u968F\u6642\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059",
  "id" : 317648694478516224,
  "created_at" : "2013-03-29 14:45:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317648577792966656",
  "text" : "(\u3068\u3044\u3046\u304B\u3075\u3041\u307C\u306B\u5BFE\u3057\u3066\u3059\u3054\u304F\u81EA\u7136\u306B\u30EA\u30D7\u30E9\u30A4\u6765\u305F\u306A\u3053\u308C)",
  "id" : 317648577792966656,
  "created_at" : "2013-03-29 14:44:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317648432514871296",
  "text" : "\u30EC\u30B8\u3067\u3053\u306E\u30D1\u30F3\u3092\u5E97\u54E1\u3055\u3093\u306B\u5DEE\u3057\u51FA\u3059\u3053\u3068\u308A\u3093\u3092\u60F3\u50CF\u3057\u3066\u5FAE\u7B11\u307F\u3092\u7981\u3058\u5F97\u306A\u3044",
  "id" : 317648432514871296,
  "created_at" : "2013-03-29 14:44:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u305A\u3042\u305A",
      "screen_name" : "azuazut",
      "indices" : [ 0, 8 ],
      "id_str" : "294104006",
      "id" : 294104006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317648065173520384",
  "geo" : { },
  "id_str" : "317648319558062080",
  "in_reply_to_user_id" : 294104006,
  "text" : "@azuazut \u306A\u306B\u305D\u308C\u3053\u3068\u308A\u3093\u304B\u308F\u3044\u3044",
  "id" : 317648319558062080,
  "in_reply_to_status_id" : 317648065173520384,
  "created_at" : "2013-03-29 14:43:55 +0000",
  "in_reply_to_screen_name" : "azuazut",
  "in_reply_to_user_id_str" : "294104006",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317645108558319616",
  "text" : "\u8001\u4F53\u306A\u4E0A\u306B\u30D5\u30A1\u30A4\u30EB\u6570\u304C\u591A\u3044\u304B\u3089\u6642\u9593\u304B\u304B\u3063\u3066\u4ED5\u65B9\u306A\u3044\u306A\u2026",
  "id" : 317645108558319616,
  "created_at" : "2013-03-29 14:31:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317645013238546433",
  "text" : "\u8001\u4F53PC\u306B\u97AD\u6253\u3063\u3066\u5909\u63DB\u3057\u305F\u30C7\u30FC\u30BF\u306E\u5F62\u5F0F\u304C\u9055\u3063\u3066\u305F\u305B\u3044\u3067\u3084\u308A\u76F4\u3057( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 317645013238546433,
  "created_at" : "2013-03-29 14:30:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317625927406346241",
  "text" : "\u30DF\u30E4\u30E2\u30C8\u30DE\u30B5\u30B7\u3082\"\u74B0\u5883\u306B\u6587\u53E5\u3092\u8A00\u3046\u5974\u306B\u6674\u308C\u821E\u53F0\u306F\u4E00\u751F\u6765\u306A\u3044\"\u3068\u8A00\u3063\u3066\u308B\u3057\u9811\u5F35\u308D\u3046",
  "id" : 317625927406346241,
  "created_at" : "2013-03-29 13:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317625104546820096",
  "text" : "\u3084\u308B\u4E8B\u3084\u308A\u307E\u3057\u3087\u3046(\u5168\u65B9\u4F4D\u306B\u523A\u3055\u308B\u4E00\u8A00)",
  "id" : 317625104546820096,
  "created_at" : "2013-03-29 13:11:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317625000179933184",
  "text" : "\u6642\u9593\u304C\u8DB3\u308A\u306A\u3044\u306E\u3082\u3042\u308B\u3051\u3069\u5BC6\u5EA6\u304C\u8DB3\u308A\u306A\u3044",
  "id" : 317625000179933184,
  "created_at" : "2013-03-29 13:11:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317602937864069120",
  "text" : "\u30C8\u30CB\u30C3\u30AF\u30A6\u30A9\u30FC\u30BF\u30FC\u98F2\u3093\u3067\u308B",
  "id" : 317602937864069120,
  "created_at" : "2013-03-29 11:43:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317556361854603264",
  "text" : "\u30B9\u30AD\u30FC\u5834\u3067\u3042\u308B\u610F\u5473\u306A",
  "id" : 317556361854603264,
  "created_at" : "2013-03-29 08:38:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317556333241069568",
  "text" : "\u3048\u306E\u3055\u3093\u300C\u30B9\u30AD\u30FC\u884C\u304D\u305F\u3044\u300D\n\u306E\u3046\u3053\u3055\u3093\u300C\u304A\u663C\u306F\u30B9\u30AD\u30FC\u3067\u591C\u306F\u6570\u5B66\u3067\u3059\u304B\u306D\u300D\n\u3048\u3093\u3069\u300C\u663C\u3082\u6570\u5B66\u3067\u3044\u3044\u306E\u3067\u306F\u300D\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30B9\u30AD\u30FC\u5834\u3067\u6570\u5B66\u5408\u5BBF\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y^Y^Y^Y^Y\uFFE3",
  "id" : 317556333241069568,
  "created_at" : "2013-03-29 08:38:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317554704328568832",
  "text" : "\u52D5\u304B\u306A\u3044\u5927\u56F3\u66F8\u9928",
  "id" : 317554704328568832,
  "created_at" : "2013-03-29 08:31:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317481804875575296",
  "text" : "\u304B\u3075\u3093\u3072\u3069\u3044",
  "id" : 317481804875575296,
  "created_at" : "2013-03-29 03:42:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317480923140599808",
  "text" : "\u5916\u306B\u51FA\u305F\u304F\u306A\u3044\u30BF\u30A4\u30D7\u306E\u5BDD\u7656",
  "id" : 317480923140599808,
  "created_at" : "2013-03-29 03:38:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317248195262574593",
  "text" : "\u8A33\u3059\u6642\u306B\u6C17\u4ED8\u3044\u305F\u308A\u3057\u306A\u3044\u306E\u304B\u2026",
  "id" : 317248195262574593,
  "created_at" : "2013-03-28 12:13:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317248058008141824",
  "text" : "\u8AA4\u690D\u2026\u3068\u601D\u3063\u3066\u6D0B\u66F8\u306E\u539F\u8457\u898B\u305F\u3089\u3082\u3068\u304B\u3089\u8AA4\u690D\u3060\u3063\u305F\u307F\u305F\u3044\u3067\u3059",
  "id" : 317248058008141824,
  "created_at" : "2013-03-28 12:13:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317244792566329344",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 317244792566329344,
  "created_at" : "2013-03-28 12:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/QO3Np9zRWS",
      "expanded_url" : "http:\/\/4sq.com\/11QRPWt",
      "display_url" : "4sq.com\/11QRPWt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0254146936, 135.7806462049 ]
  },
  "id_str" : "317220973902450688",
  "text" : "I'm at \u30AB\u30D5\u30A7\u30EC\u30B9\u30C8\u30E9\u30F3 \u30AB\u30F3\u30D5\u30A9\u30FC\u30E9 (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/QO3Np9zRWS",
  "id" : 317220973902450688,
  "created_at" : "2013-03-28 10:25:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317220790879809536",
  "text" : "\u672C\u65E5\u4E8C\u5EA6\u76EE\u306E\u30AB\u30F3\u30D5\u30A9\u30FC\u30E9\u306A\u30FCwwwww",
  "id" : 317220790879809536,
  "created_at" : "2013-03-28 10:25:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304F\u3089\u306B\u3083\u3093\u306B\u3083\u304B",
      "screen_name" : "thulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413212440",
      "id" : 413212440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317215840296640512",
  "in_reply_to_user_id" : 413212440,
  "text" : "@thulud \u3054\u306F\u3093\u3044\u304D\u307E\u3059\uFF1F",
  "id" : 317215840296640512,
  "created_at" : "2013-03-28 10:05:24 +0000",
  "in_reply_to_screen_name" : "thulud",
  "in_reply_to_user_id_str" : "413212440",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317211123961196544",
  "text" : "\u305D\u3057\u3066\u3069\u3053\u306B\u306A\u306B\u3092\u98DF\u3079\u306B\uFF1F",
  "id" : 317211123961196544,
  "created_at" : "2013-03-28 09:46:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317210897720430592",
  "geo" : { },
  "id_str" : "317210979861667840",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u30CA\u30A4\u30B9\u30EC\u30C7\u30A3\u30D1\u30F3\u30B5\u30FC\uFF01",
  "id" : 317210979861667840,
  "in_reply_to_status_id" : 317210897720430592,
  "created_at" : "2013-03-28 09:46:05 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317208413165731841",
  "geo" : { },
  "id_str" : "317210867395616768",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 19\u6642\u4F4D\u3067\u304A\u5915\u98EF\u884C\u304F\u4E88\u5B9A\u3067\u3059\u30FC",
  "id" : 317210867395616768,
  "in_reply_to_status_id" : 317208413165731841,
  "created_at" : "2013-03-28 09:45:38 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317149639168102400",
  "text" : "\u30BC\u30DF\u306A\u306E\u3067\u308A\u3060\u3064",
  "id" : 317149639168102400,
  "created_at" : "2013-03-28 05:42:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317118988213682176",
  "text" : "\u6BD4\u8F03\u5BFE\u8C61\u306E\u30BB\u30F3\u30B9\u826F\u3044",
  "id" : 317118988213682176,
  "created_at" : "2013-03-28 03:40:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "indices" : [ 3, 11 ],
      "id_str" : "16331213",
      "id" : 16331213
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kazoo04\/status\/258819000237170688\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/lLbYDlIq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5eCgmqCIAE2Y6D.png",
      "id_str" : "258819000241364993",
      "id" : 258819000241364993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5eCgmqCIAE2Y6D.png",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lLbYDlIq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317118935608729600",
  "text" : "RT @kazoo04: \u3046\u30FC\u3093\u2026 iPhone5 \u89E6\u3063\u3066\u307F\u305F\u3051\u3069\u3001\u3084\u3063\u3071\u308A\u4ED6\u3068\u6BD4\u3079\u308B\u3068\u898B\u52A3\u308A\u3059\u308B\u3068\u8A00\u308F\u3056\u308B\u3092\u5F97\u306A\u3044\u306A\u30FC\u3002 \u6BD4\u8F03\u3057\u3066\u307E\u3068\u3081\u305F\u304B\u3089 iPhone5 \u691C\u8A0E\u3057\u3066\u3044\u308B\u4EBA\u306F\u53C2\u8003\u306B\u3057\u3066\u307F\u3066\u3002 http:\/\/t.co\/lLbYDlIq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kazoo04\/status\/258819000237170688\/photo\/1",
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/lLbYDlIq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A5eCgmqCIAE2Y6D.png",
        "id_str" : "258819000241364993",
        "id" : 258819000241364993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5eCgmqCIAE2Y6D.png",
        "sizes" : [ {
          "h" : 452,
          "resize" : "fit",
          "w" : 935
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 935
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 164,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lLbYDlIq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258819000237170688",
    "text" : "\u3046\u30FC\u3093\u2026 iPhone5 \u89E6\u3063\u3066\u307F\u305F\u3051\u3069\u3001\u3084\u3063\u3071\u308A\u4ED6\u3068\u6BD4\u3079\u308B\u3068\u898B\u52A3\u308A\u3059\u308B\u3068\u8A00\u308F\u3056\u308B\u3092\u5F97\u306A\u3044\u306A\u30FC\u3002 \u6BD4\u8F03\u3057\u3066\u307E\u3068\u3081\u305F\u304B\u3089 iPhone5 \u691C\u8A0E\u3057\u3066\u3044\u308B\u4EBA\u306F\u53C2\u8003\u306B\u3057\u3066\u307F\u3066\u3002 http:\/\/t.co\/lLbYDlIq",
    "id" : 258819000237170688,
    "created_at" : "2012-10-18 06:37:13 +0000",
    "user" : {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "protected" : false,
      "id_str" : "16331213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583129549694640129\/aPkbezAe_normal.png",
      "id" : 16331213,
      "verified" : false
    }
  },
  "id" : 317118935608729600,
  "created_at" : "2013-03-28 03:40:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/SoFatfZx4o",
      "expanded_url" : "http:\/\/maps.google.com\/maps?q=35.025802,135.780108",
      "display_url" : "maps.google.com\/maps?q=35.0258\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317107316178702336",
  "text" : "\u9023\u7D61\u3053\u306A\u3044\u3057\u304B\u3093\u3075\u3049\u3089\u884C\u304F\u307E\u3059 http:\/\/t.co\/SoFatfZx4o",
  "id" : 317107316178702336,
  "created_at" : "2013-03-28 02:54:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304F\u3089\u306B\u3083\u3093\u306B\u3083\u304B",
      "screen_name" : "thulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413212440",
      "id" : 413212440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317106827588407296",
  "geo" : { },
  "id_str" : "317107166899208192",
  "in_reply_to_user_id" : 413212440,
  "text" : "@thulud \u7AEF\u672B\u6301\u3063\u3066\u3053\u306A\u3051\u308C\u3070\u826F\u3044\u306E\u3067\u306F[\u96FB\u5B50\u66F8\u7C4D\u3060\u3068\u8A70\u307F\u307E\u3059\u304C]",
  "id" : 317107166899208192,
  "in_reply_to_status_id" : 317106827588407296,
  "created_at" : "2013-03-28 02:53:34 +0000",
  "in_reply_to_screen_name" : "thulud",
  "in_reply_to_user_id_str" : "413212440",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317105209560166401",
  "geo" : { },
  "id_str" : "317105436220338177",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p \u4EF0\u3005\u3057\u3044\u306E\u306F\u3042\u308A\u307E\u3059\u3088\u306D\u2026\u30D5\u30A1\u30F3\u3082\u30BF\u30A4\u30D7\u97F3\u3082\u7121\u97F3\u3058\u3083\u306A\u3044\u3067\u3059\u3057\u3001\u9759\u304B\u306A\u3068\u3053\u308D\u3067\u306F\u6C17\u306B\u3055\u308C\u308B\u4EBA\u3082\u3044\u305D\u3046\u3067\u3059\u3002",
  "id" : 317105436220338177,
  "in_reply_to_status_id" : 317105209560166401,
  "created_at" : "2013-03-28 02:46:42 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317104683254689793",
  "text" : "\u307E\u3060\u7D19\u306E\u30CE\u30FC\u30C8\u3068\u30A2\u30A4\u30D1\u30A4\u30E8\u306E\u30DA\u30F3\u3067\u66F8\u304F\u306E\u3067\u306F\u30AE\u30E3\u30C3\u30D7\u304C\u3042\u308B\u3088\u306D",
  "id" : 317104683254689793,
  "created_at" : "2013-03-28 02:43:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317104126930587649",
  "geo" : { },
  "id_str" : "317104554829303808",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p evernote\u3092\u5165\u308C\u3066\u307E\u3059\u304C\u7D50\u5C40\u30CE\u30FC\u30C8PC\u3067tex\u306E\u307B\u3046\u304C\u65E9\u3044\u306E\u3067\u2026\u30E1\u30E2\u306B\u306F\u305F\u307E\u306B\u4F7F\u3044\u307E\u3059\u304C\u3002",
  "id" : 317104554829303808,
  "in_reply_to_status_id" : 317104126930587649,
  "created_at" : "2013-03-28 02:43:12 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304F\u3089\u306B\u3083\u3093\u306B\u3083\u304B",
      "screen_name" : "thulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413212440",
      "id" : 413212440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317103334798532609",
  "geo" : { },
  "id_str" : "317104139706458112",
  "in_reply_to_user_id" : 413212440,
  "text" : "@thulud \u306A\u308B\u307B\u3069\u3067\u3059\u3002\u4ECA\u307E\u3067\u3069\u3061\u3089\u306B\u3082\u308D\u304F\u3059\u3063\u307D\u89E6\u308C\u3066\u306A\u3044\u306E\u3067\u3088\u304F\u308F\u304B\u3089\u3093\u307D\u3093\u3067\u3057\u305F\u3002",
  "id" : 317104139706458112,
  "in_reply_to_status_id" : 317103334798532609,
  "created_at" : "2013-03-28 02:41:33 +0000",
  "in_reply_to_screen_name" : "thulud",
  "in_reply_to_user_id_str" : "413212440",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317103424250462208",
  "geo" : { },
  "id_str" : "317103583713689601",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p \u306A\u308B\u307B\u3069\u3001\u306A\u3093\u304B\u6357\u308B\u65B9\u6CD5\u3042\u3063\u305F\u3089\u5171\u6709\u3057\u307E\u3057\u3087\u3046",
  "id" : 317103583713689601,
  "in_reply_to_status_id" : 317103424250462208,
  "created_at" : "2013-03-28 02:39:20 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317103028689854464",
  "geo" : { },
  "id_str" : "317103148579835904",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p \u3044\u3084\u3001\u4F8B\u3048\u3070\u677F\u66F8\u3068\u304B\u306B\u3064\u3044\u3066\u884C\u3051\u308B\u306E\u304B\u306A\u3001\u3068",
  "id" : 317103148579835904,
  "in_reply_to_status_id" : 317103028689854464,
  "created_at" : "2013-03-28 02:37:36 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317103011778400258",
  "text" : "@i_horse \u3044\u3084\u3001\u3046\u3093\u3001\u8A00\u8449\u9078\u3073\u306F\u9593\u9055\u3048\u305F\u611F\u3042\u308B\u304C\u60AA\u610F\u306F\u306A\u3044\u3093\u3060\u5BDF\u3057\u3066\u304F\u308C",
  "id" : 317103011778400258,
  "created_at" : "2013-03-28 02:37:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317102519287431168",
  "geo" : { },
  "id_str" : "317102734027411456",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p \u901F\u5EA6\u3067\u307E\u3059\uFF1F",
  "id" : 317102734027411456,
  "in_reply_to_status_id" : 317102519287431168,
  "created_at" : "2013-03-28 02:35:57 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317102697960587265",
  "text" : "@i_horse \u30DE\u30B8\u304B\u3001\u52C9\u5F37\u3057\u305F\u3053\u3068\u307E\u3068\u3081\u307F\u305F\u3044\u306A\u3082\u306E\u304B\u306D\u3002",
  "id" : 317102697960587265,
  "created_at" : "2013-03-28 02:35:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317102497170857984",
  "text" : "\u60C5\u5F31\u3060\u304B\u3089\u8ABF\u3079\u308C\u3070\u3044\u3044\u306E\u306B\u3061\u3063\u3066\u3042\u30FC\u3067\u304D\u3044\u3066\u3057\u307E\u3063\u305F",
  "id" : 317102497170857984,
  "created_at" : "2013-03-28 02:35:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317102392581701632",
  "text" : "\u8AB0\u304B\u30B5\u30FC\u30D9\u30A4\u3068\u8AD6\u6587\u306E\u3061\u304C\u3044\u3092\u304A\u305B\u30FC\u3066\u304F\u3060\u3055\u3044",
  "id" : 317102392581701632,
  "created_at" : "2013-03-28 02:34:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317071390924750848",
  "geo" : { },
  "id_str" : "317101692661428224",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u3054\u306F\u3093\u305F\u3079\u306B\u3044\u304D\u307E\u305B\u3093\u304B",
  "id" : 317101692661428224,
  "in_reply_to_status_id" : 317071390924750848,
  "created_at" : "2013-03-28 02:31:49 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317101517469532160",
  "text" : "\u3074\u3042\u306E\u6C0F\u8A8D\u8B58\u3057\u3066\u306A\u3044\u3051\u3069\u3044\u308B\u306A\u3089\u3054\u98EF\u98DF\u3079\u306B\u884C\u304D\u307E\u305B\u3093\u304B",
  "id" : 317101517469532160,
  "created_at" : "2013-03-28 02:31:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317100242338189313",
  "text" : "\u7A7A\u8179\u3068\u306F\u3059\u306A\u308F\u3061\u7A7A\u8179\u3067\u3042\u308B\u3002\u306A\u305C\u306A\u3089\u3070\u3001\u305D\u308C\u306F\u7A7A\u8179\u3060\u304B\u3089\u3060\u3002",
  "id" : 317100242338189313,
  "created_at" : "2013-03-28 02:26:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317098018178494466",
  "text" : "\u3059\u3067\u306B\u7A7A\u8179\u3067\u3042\u3048\u3044\u3067\u3044\u308B",
  "id" : 317098018178494466,
  "created_at" : "2013-03-28 02:17:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304F\u3089\u306B\u3083\u3093\u306B\u3083\u304B",
      "screen_name" : "thulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413212440",
      "id" : 413212440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317089090136834049",
  "geo" : { },
  "id_str" : "317089936832610304",
  "in_reply_to_user_id" : 413212440,
  "text" : "@thulud \u3082\u3046\u306A\u3093\u3068\u3044\u3046\u304B\u53D7\u3051\u53D6\u3063\u3066\u304B\u3089\u304D\u3066\u3082\u3089\u3063\u3066\u3082\u826F\u3044\u3067\u3059\u3088(",
  "id" : 317089936832610304,
  "in_reply_to_status_id" : 317089090136834049,
  "created_at" : "2013-03-28 01:45:06 +0000",
  "in_reply_to_screen_name" : "thulud",
  "in_reply_to_user_id_str" : "413212440",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317086376313094145",
  "text" : "\u307E\u3041\u6B8B\u308A\u306E11\u6642\u9593\u5206\u3060\u3051\u5225\u306E\u65E5\u306B\u3084\u308B\u3068\u304B\u8A00\u3046\u8B0E\u30D5\u30A9\u30ED\u30FC\u3082\u4ECA\u8003\u3048\u3066\u308B",
  "id" : 317086376313094145,
  "created_at" : "2013-03-28 01:30:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304F\u3089\u306B\u3083\u3093\u306B\u3083\u304B",
      "screen_name" : "thulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413212440",
      "id" : 413212440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317086064827310081",
  "geo" : { },
  "id_str" : "317086220670889984",
  "in_reply_to_user_id" : 413212440,
  "text" : "@thulud \u306F\u3044wwwww",
  "id" : 317086220670889984,
  "in_reply_to_status_id" : 317086064827310081,
  "created_at" : "2013-03-28 01:30:20 +0000",
  "in_reply_to_screen_name" : "thulud",
  "in_reply_to_user_id_str" : "413212440",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317086147169894400",
  "text" : "\u3061\u306A\u307F\u306B\u5965\u306E\u30D6\u30FC\u30B9\u306F\"\u81EA\u5B6624\"\u3068\u304B\u8A00\u3046\u3089\u3057\u3044(^^)(^^)(^^)\u3053\u308C\u3082\u521D\u8033(^^)(^^)(^^)",
  "id" : 317086147169894400,
  "created_at" : "2013-03-28 01:30:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317085887857049602",
  "text" : "\u5B66\u7FD2\u5BA424\u306E\u4F1A\u8A71\u3057\u3066\u826F\u3044\u30B9\u30DA\u30FC\u30B9\"\u306A\u3054\u307F\"\u3068\u304B\u8A00\u3046\u540D\u524D\u304C\u3042\u308B\u3089\u3057\u3044\u3002\u521D\u8033\u3002",
  "id" : 317085887857049602,
  "created_at" : "2013-03-28 01:29:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "317083166328385536",
  "text" : "\u60B2\u3057\u307F\u306E\u5185\u5BB9\u5909\u66F4[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992813\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 317083166328385536,
  "created_at" : "2013-03-28 01:18:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u308F\u305F\u3057\u3067\u3059",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317080120236064770",
  "text" : "\u4E3B\u50AC\u8005\u8ABF\u3079\u3068\u3051\u3088\u2026 #\u308F\u305F\u3057\u3067\u3059",
  "id" : 317080120236064770,
  "created_at" : "2013-03-28 01:06:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317080014220845058",
  "text" : "\u3053\u308C12\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5\u3058\u3083\u3093\u3001\u660E\u65E5\u4F11\u9928\u65E5\u3068\u304B\u2026",
  "id" : 317080014220845058,
  "created_at" : "2013-03-28 01:05:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317079843986604034",
  "text" : "[\u901F\u5831]24\u6642\u9593\u81EA\u7FD2\u5BA422\u6642\u3067\u9589\u307E\u308B",
  "id" : 317079843986604034,
  "created_at" : "2013-03-28 01:05:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317071390924750848",
  "geo" : { },
  "id_str" : "317072253474975744",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u3042\u3063\u2026(\u5BDF\u3057)",
  "id" : 317072253474975744,
  "in_reply_to_status_id" : 317071390924750848,
  "created_at" : "2013-03-28 00:34:50 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317064221923880961",
  "text" : "\u5165\u3063\u3066\u53F3\u5965\u306E\u958B\u67B6\u306B\u3044\u307E\u3059",
  "id" : 317064221923880961,
  "created_at" : "2013-03-28 00:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304F\u3089\u306B\u3083\u3093\u306B\u3083\u304B",
      "screen_name" : "thulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413212440",
      "id" : 413212440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317058189944307714",
  "geo" : { },
  "id_str" : "317062486371217409",
  "in_reply_to_user_id" : 413212440,
  "text" : "@thulud \u6848\u306E\u5B9A\u958B\u5E55\u8AB0\u3082\u3044\u306A\u3044(^^)(^^)(^^)",
  "id" : 317062486371217409,
  "in_reply_to_status_id" : 317058189944307714,
  "created_at" : "2013-03-27 23:56:02 +0000",
  "in_reply_to_screen_name" : "thulud",
  "in_reply_to_user_id_str" : "413212440",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316849875398557698",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u304B\u306A\u308A\u7720\u305F\u3044",
  "id" : 316849875398557698,
  "created_at" : "2013-03-27 09:51:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "316844576621092864",
  "text" : "24\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5\u3002\u53C2\u52A0\u8868\u660E\u3057\u3066\u305F\u5404\u4F4D\u306B\u306F\u9069\u5F53\u306B\u9023\u7D61\u3057\u305F\u3051\u308C\u3069\u98DB\u3073\u8FBC\u307F\u3067\u3082\u3069\u3046\u305E http:\/\/t.co\/0cjLXxYqL5",
  "id" : 316844576621092864,
  "created_at" : "2013-03-27 09:30:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "316843385862381570",
  "text" : ". @_lim_infinity @Kyo_Hiiragi  \u4E00\u5FDC\u8208\u5473\u3042\u308A\u306E\u4EBA\u306B\u3082\u9023\u7D61\u3057\u3066\u3044\u307E\u3059\u3002\u660E\u65E5\u306E9\u6642\u306B\u4ED8\u5C5E\u56F3\u66F8\u9928\u524D\u96C6\u5408\u3067\u3059\u3001\u304C\u9593\u306B\u5408\u308F\u306A\u3044\u4EBA\u3084\u9045\u523B\u3059\u308B\u524D\u63D0\u306E\u4EBA\u3084\u3089\u306F\u9069\u5F53\u306B\u6765\u3066\u4E0B\u3055\u3044  http:\/\/t.co\/0cjLXxYqL5",
  "id" : 316843385862381570,
  "created_at" : "2013-03-27 09:25:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316745665013248001",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3081\u30FC\u308B\u3057\u305F",
  "id" : 316745665013248001,
  "created_at" : "2013-03-27 02:57:06 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316716466953154560",
  "text" : "\u52AA\u529B\u3059\u308C\u3070\u512A\u306F\u771F\u3060\u304C\u9006\u306F\u6210\u308A\u7ACB\u305F\u306A\u3044\u6A21\u69D8",
  "id" : 316716466953154560,
  "created_at" : "2013-03-27 01:01:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316715031867838465",
  "text" : "\u4E00\u500B\u697D\u52DD\u306E\u306F\u305A\u306E\u79D1\u76EE\u304C\u306A\u305C\u304B\u4E0D\u53D7\u9A13\u306B\u306A\u3063\u3066\u305F\u3051\u308C\u3069\uFF0C\u6559\u52D9\u306B\u884C\u304F\u306E\u304C\u5ACC\u306A\u306E\u3068\u5168\u304F\u52AA\u529B\u3092\u3057\u3066\u306A\u3044\u306E\u3067\u7121\u8996\u3057\u307E\u3059\u3067\u3059\uFF0E",
  "id" : 316715031867838465,
  "created_at" : "2013-03-27 00:55:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316713694824386560",
  "text" : "\u6625\u30BB\u30DF\u30CA\u30FC4\u9650\u3060\u3051\u6C17\u306B\u306A\u308B\u304B\u3089\u805E\u304D\u306B\u884C\u304F\u306E\u3082\u30A2\u30EA\u3060\u306A\u2026",
  "id" : 316713694824386560,
  "created_at" : "2013-03-27 00:50:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316710984301572097",
  "text" : "\u524D\u5F8C\u671F\u3068\u3082\u306B\u6C34\u66DC\u91D1\u66DC\u3057\u304B\u6388\u696D\u3092\u53D6\u3089\u306A\u3044\u504F\u3063\u305F\u5C65\u4FEE\u8A08\u753B\u3092\u8003\u3048\u3066\u3044\u308B\uFF0E\uFF3B\u3053\u306E\u30B7\u30B9\u30C6\u30E0\u3060\u3068\u30B5\u30DC\u308A\u306F\u8A31\u3055\u308C\u306A\u3044\u5F62\uFF3D",
  "id" : 316710984301572097,
  "created_at" : "2013-03-27 00:39:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u3042\u308B",
      "screen_name" : "fuwafuwa_Fuaru",
      "indices" : [ 3, 18 ],
      "id_str" : "237330800",
      "id" : 237330800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316694754358333440",
  "text" : "RT @fuwafuwa_Fuaru: \u3069\u3093\u306A\u4EBA\u9593\u306B\u3060\u3063\u3066\u96FB\u8ECA\u3092\u6B62\u3081\u308B\u3060\u3051\u306E\u529B\u304C\u3042\u308B\u3093\u3060\uFF01\uFF08\u7DDA\u8DEF\u306B\u98DB\u3073\u8FBC\u307F\u306A\u304C\u3089\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316694721617616896",
    "text" : "\u3069\u3093\u306A\u4EBA\u9593\u306B\u3060\u3063\u3066\u96FB\u8ECA\u3092\u6B62\u3081\u308B\u3060\u3051\u306E\u529B\u304C\u3042\u308B\u3093\u3060\uFF01\uFF08\u7DDA\u8DEF\u306B\u98DB\u3073\u8FBC\u307F\u306A\u304C\u3089\uFF09",
    "id" : 316694721617616896,
    "created_at" : "2013-03-26 23:34:40 +0000",
    "user" : {
      "name" : "\u3075\u3042\u308B",
      "screen_name" : "fuwafuwa_Fuaru",
      "protected" : false,
      "id_str" : "237330800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606238942044647424\/R1YAek2g_normal.png",
      "id" : 237330800,
      "verified" : false
    }
  },
  "id" : 316694754358333440,
  "created_at" : "2013-03-26 23:34:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316694724742356993",
  "text" : "\u5B9F\u969B3\u6642\u9593\u5F31\u3057\u304B\u5BDD\u3066\u306A\u3044\u304B\u3089\u4ECA\u591C\u306F\u65E9\u304F\u5BDD\u308C\u308B\u308C\u308B",
  "id" : 316694724742356993,
  "created_at" : "2013-03-26 23:34:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316694470840184832",
  "text" : "\u4E00\u676F\u306E\u6E29\u304B\u3044\u30BD\u30A4\u30E9\u30C6\u304B\u3089\u59CB\u307E\u308B\u904A\u60F0\u306A\u4E00\u65E5",
  "id" : 316694470840184832,
  "created_at" : "2013-03-26 23:33:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316637324475785216",
  "text" : "\u30DD\u30CB\u30E7\u300C\u30DD\u30CB\u30E7\uFF01\u6D99\u3092\u7981\u3058\u5F97\u306A\u3044\uFF01\u300D",
  "id" : 316637324475785216,
  "created_at" : "2013-03-26 19:46:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316600034877640704",
  "text" : "\u30DD\u30CB\u30E7\u300C\u30DD\u30CB\u30E7\uFF01\u793E\u4F1A\u3092\uFF01\u611F\u3058\u308B\uFF01\u300D",
  "id" : 316600034877640704,
  "created_at" : "2013-03-26 17:18:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316547126089891840",
  "text" : "\u3054\u3081\u3093\u306A\u3055\u3044\u3067\u3057\u305F",
  "id" : 316547126089891840,
  "created_at" : "2013-03-26 13:48:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316547060910407680",
  "text" : "\u8151\u306B\u306F\u843D\u3061\u306A\u3044\u3051\u3069\u624B\u7389\u306F\u843D\u3061\u3061\u3083\u3063\u305F\u3093\u3067\u3059\u306Dwwwww",
  "id" : 316547060910407680,
  "created_at" : "2013-03-26 13:47:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316546304039874560",
  "text" : "\u6700\u5F8C\u306E\u6700\u5F8C\u30673\u30D5\u30A1\u30FC\u30EB\u3068\u304B\u30E4\u30D0\u3059\u304E\u3067\u3057\u305F\u306D",
  "id" : 316546304039874560,
  "created_at" : "2013-03-26 13:44:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316546240131256320",
  "text" : "RT @shigmax: \u5B66\u751F\u6700\u5F8C\u306E\u4EF2\u9593\u5185\u30D3\u30EA\u30E4\u30FC\u30C9\u3067\u307E\u3055\u304B\u306E\u30B9\u30EA\u30FC\u30D5\u30A1\u30FC\u30EB\u3067\u7D42\u308F\u3063\u3066\u3044\u308D\u3044\u308D\u3068\u3053\u3046\u3001\u306A\u3093\u304B\u81EA\u5206\u3089\u3057\u3044\u3084\u3068\u6709\u7D42\u306E\u7F8E\u3092\u98FE\u308C\u3066\u3088\u304B\u3063\u305F\uFF01\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316544962600767488",
    "text" : "\u5B66\u751F\u6700\u5F8C\u306E\u4EF2\u9593\u5185\u30D3\u30EA\u30E4\u30FC\u30C9\u3067\u307E\u3055\u304B\u306E\u30B9\u30EA\u30FC\u30D5\u30A1\u30FC\u30EB\u3067\u7D42\u308F\u3063\u3066\u3044\u308D\u3044\u308D\u3068\u3053\u3046\u3001\u306A\u3093\u304B\u81EA\u5206\u3089\u3057\u3044\u3084\u3068\u6709\u7D42\u306E\u7F8E\u3092\u98FE\u308C\u3066\u3088\u304B\u3063\u305F\uFF01\uFF01\uFF01",
    "id" : 316544962600767488,
    "created_at" : "2013-03-26 13:39:34 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 316546240131256320,
  "created_at" : "2013-03-26 13:44:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316543744268713984",
  "text" : "\u98F2\u307F\u4F1A\u59CB\u307E\u308B\u524D\u304B\u3089\u3059\u3067\u306B\u982D\u75DB\u30DE\u30F3",
  "id" : 316543744268713984,
  "created_at" : "2013-03-26 13:34:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316520024825286658",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 316520024825286658,
  "created_at" : "2013-03-26 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316493006956027904",
  "text" : "\u30E8\u30FC\u30B0\u30EB\u30C8\u306E\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u304C\u3051\u3001\u307F\u305F\u3044\u306A\u30C7\u30B6\u30FC\u30C8\u98DF\u3079\u305F\u3044",
  "id" : 316493006956027904,
  "created_at" : "2013-03-26 10:13:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316492594953719808",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u4ECA\u65E5\u3067\u30B7\u30B0\u30DE\u30C3\u30AF\u30B9\u6C0F\u30E9\u30B9\u30C8\u306A\u306E\u3067\u6765\u307E\u305B\u3093\uFF1F",
  "id" : 316492594953719808,
  "created_at" : "2013-03-26 10:11:29 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316470992681709568",
  "text" : "\u3042\u3075\u308C\u308B\u7720\u6C17\u304C\u3068\u3081\u3069\u306A\u307F",
  "id" : 316470992681709568,
  "created_at" : "2013-03-26 08:45:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316469178750099456",
  "text" : "\u30B5\u30F3\u30C0\u30FC\u30D5\u30A3\u30B9\u30C8\u4ECA\u6708\u4E2D\u306E\u306F\u305A\u3060\u3057\u3044\u308D\u3044\u308D\u697D\u3057\u307F\u3060\u306A",
  "id" : 316469178750099456,
  "created_at" : "2013-03-26 08:38:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316469067877847040",
  "text" : "\u304B\u305A\u30FC\u6C0F\u2026",
  "id" : 316469067877847040,
  "created_at" : "2013-03-26 08:38:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u671F\u9593\u9650\u5B9A\u306F\u3061\u307F\u3064\u5473\u3075\u306B\u3083\u5E3D\u5B50",
      "screen_name" : "soft_HAT",
      "indices" : [ 14, 23 ],
      "id_str" : "336285270",
      "id" : 336285270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/gL2nlxaecy",
      "expanded_url" : "http:\/\/togetter.com\/li\/477803",
      "display_url" : "togetter.com\/li\/477803"
    } ]
  },
  "geo" : { },
  "id_str" : "316468996289466368",
  "text" : "RT @__AEON_: .@soft_HAT \u3055\u3093\u306E\u300C\u304B\u305A\u30FC\u6C0F\u304Cfavstar\u4EE3\u66FF\u30B5\u30FC\u30D3\u30B9\u3092\u4F5C\u308B\u305D\u3046\u3067\u3059\u3002\u300D\u3092\u304A\u6C17\u306B\u5165\u308A\u306B\u3057\u307E\u3057\u305F\u3002 http:\/\/t.co\/gL2nlxaecy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u671F\u9593\u9650\u5B9A\u306F\u3061\u307F\u3064\u5473\u3075\u306B\u3083\u5E3D\u5B50",
        "screen_name" : "soft_HAT",
        "indices" : [ 1, 10 ],
        "id_str" : "336285270",
        "id" : 336285270
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/gL2nlxaecy",
        "expanded_url" : "http:\/\/togetter.com\/li\/477803",
        "display_url" : "togetter.com\/li\/477803"
      } ]
    },
    "geo" : { },
    "id_str" : "316467811360833537",
    "text" : ".@soft_HAT \u3055\u3093\u306E\u300C\u304B\u305A\u30FC\u6C0F\u304Cfavstar\u4EE3\u66FF\u30B5\u30FC\u30D3\u30B9\u3092\u4F5C\u308B\u305D\u3046\u3067\u3059\u3002\u300D\u3092\u304A\u6C17\u306B\u5165\u308A\u306B\u3057\u307E\u3057\u305F\u3002 http:\/\/t.co\/gL2nlxaecy",
    "id" : 316467811360833537,
    "created_at" : "2013-03-26 08:33:00 +0000",
    "user" : {
      "name" : "\u3044\u304A\u3093",
      "screen_name" : "__ion__",
      "protected" : false,
      "id_str" : "569690517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603931155113447424\/lu8Pylbi_normal.png",
      "id" : 569690517,
      "verified" : false
    }
  },
  "id" : 316468996289466368,
  "created_at" : "2013-03-26 08:37:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316464165646659584",
  "text" : "\u30D6\u30E9\u30F3\u30C7\u30FC\u30D9\u30FC\u30B9\u306E\u7D20\u6575\u306A\u6885\u9152\u6B32\u3057\u3044",
  "id" : 316464165646659584,
  "created_at" : "2013-03-26 08:18:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316463696719273984",
  "text" : "\u30D3\u30FC\u30EB\u3068\u304B\u306A\u3044\u3001\u6885\u9152\u306F\u5B89\u3044\u306E\u3057\u304B\u306A\u3044",
  "id" : 316463696719273984,
  "created_at" : "2013-03-26 08:16:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 12, 22 ],
      "id_str" : "230481483",
      "id" : 230481483
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 23, 39 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316462798525845504",
  "geo" : { },
  "id_str" : "316463631007088640",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 @wa_ta_si_ @jelly_in_a_tank @yohjigureito \u30D5\u30EB\u30FC\u30C4\u306E\u30EA\u30AD\u30E5\u30FC\u30EB\u985E\u306F\u3042\u308B\u306E\u3067\u6B32\u3057\u3044\u4EBA\u306F[\u3068\u3044\u3046\u304B\u98F2\u3080\u4EBA\u306F][\u98F2\u307F\u305F\u3044\u3082\u306E\u304C\u3042\u308B\u4EBA\u306F]\u9069\u5F53\u306B\u8CB7\u3063\u3066\u6765\u3066\u304F\u3060\u3055\u3044",
  "id" : 316463631007088640,
  "in_reply_to_status_id" : 316462798525845504,
  "created_at" : "2013-03-26 08:16:23 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316462587170668544",
  "text" : "\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u671D\u306E\u30D5\u30EB\u30FC\u30C4\u30DF\u30C3\u30AF\u30B9\u304C\u7F8E\u5473\u3057\u304F\u3066\u751F\u304D\u308B\u306E\u304C\u8F9B\u3044",
  "id" : 316462587170668544,
  "created_at" : "2013-03-26 08:12:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043B\u0435\u043A\u0441\u0435\u0439 \u041D\u0438\u043A\u0438\u0442\u0438\u043D",
      "screen_name" : "2222_42",
      "indices" : [ 0, 8 ],
      "id_str" : "2338297813",
      "id" : 2338297813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316460916407427073",
  "text" : "@2222_42 \u305D\u308C\u30B9\u30D1\u30A4\u30B7\u30FC\u3067\u7F8E\u5473\u3057\u3044",
  "id" : 316460916407427073,
  "created_at" : "2013-03-26 08:05:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316456715832922112",
  "geo" : { },
  "id_str" : "316460636538298369",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30E9\u30FC\u30CC\u30F3\u53B3\u3057\u3052\u306A\u306E\u306722:30\u304F\u3089\u3044\u306B\u30A6\u30C1\u3092\u30E1\u30C9\u306B\u6765\u3066\u304F\u3060\u3055\u3044[\u6383\u9664\u9593\u306B\u5408\u308F\u306A\u3044\u611F\u3058(^^)(^^)(^^)]",
  "id" : 316460636538298369,
  "in_reply_to_status_id" : 316456715832922112,
  "created_at" : "2013-03-26 08:04:29 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316456255235424256",
  "text" : "\u82B1\u7C89\u306E\u85AC\u98F2\u3093\u3060\u3089\u307C\u30FC\u3063\u3068\u3057\u3061\u3083\u3063\u3066\u8F9B\u3044\u3057\u98F2\u307E\u306A\u3044\u3068\u304F\u3057\u3083\u307F\u3068\u9F3B\u6C34\u3067\u8F9B\u3044\u3057\n\u2582\u2585\u2587\u2588\u2593\u2592\u2591(\u2019\u03C9\u2019)\u2591\u2592\u2593\u2588\u2587\u2585\u2582 \u3046\u308F\u3042\u3042\u3042\u3042",
  "id" : 316456255235424256,
  "created_at" : "2013-03-26 07:47:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316444181679710208",
  "geo" : { },
  "id_str" : "316454801787461633",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u4E09\u6761\u3067\u3057",
  "id" : 316454801787461633,
  "in_reply_to_status_id" : 316444181679710208,
  "created_at" : "2013-03-26 07:41:18 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316439778910429184",
  "text" : "7\u6642\u306B\u3057\u3050\u307E\u3063\u304F\u3059\u3057\u3068\u30D0\u30BA\u3067\u5F85\u3061\u5408\u308F\u305B\u3066\u30019\u6642\u306B\u30E9\u30FC\u30CC\u30F3\u306F\u3069\u3046\u8003\u3048\u3066\u3082\u4E0D\u53EF\u2026",
  "id" : 316439778910429184,
  "created_at" : "2013-03-26 06:41:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316433627103772672",
  "geo" : { },
  "id_str" : "316437094031577090",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u5727\u5012\u7684\u7406\u89E3(^^)(^^)(^^)(^^)(^^)",
  "id" : 316437094031577090,
  "in_reply_to_status_id" : 316433627103772672,
  "created_at" : "2013-03-26 06:30:56 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/RSi54ojl0D",
      "expanded_url" : "http:\/\/4sq.com\/Yw0JeW",
      "display_url" : "4sq.com\/Yw0JeW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "316428925054107648",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/RSi54ojl0D",
  "id" : 316428925054107648,
  "created_at" : "2013-03-26 05:58:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNIpGD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316274092183523330",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNIpGD",
  "id" : 316274092183523330,
  "created_at" : "2013-03-25 19:43:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316199672769310721",
  "geo" : { },
  "id_str" : "316245131089022976",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30A8\u30F3\u30C9\u90B8\u4F7F\u3046\u306A\u3089\u6383\u9664\u306E\u305F\u3081\u306B\u3089\u30FC\u306C\u3093\u306F\u4E0D\u53C2\u52A0\u307E\u3067\u3042\u308B(^^)(^^)(^^)",
  "id" : 316245131089022976,
  "in_reply_to_status_id" : 316199672769310721,
  "created_at" : "2013-03-25 17:48:09 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316244226432184321",
  "text" : "\u307E\u3041\u6700\u60AA\u3001\u56DE\u308A\u9053\u8A3C\u660E\u306B\u4ED8\u304D\u5408\u3063\u3066\u3082\u3089\u3048\u3070\u826F\u3044\u304B(^^)(^^)(^^)",
  "id" : 316244226432184321,
  "created_at" : "2013-03-25 17:44:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316244092889726977",
  "text" : "\u305F\u3076\u3093AC\u6271\u3044\u6163\u308C\u3066\u306A\u3044\u611F\u3042\u308B.\u6DFB\u3048\u5B57\u3068\u304B\u306E\u9078\u3073\u65B9\u805E\u3051\u3070\u308F\u304B\u308B\u304C\u767A\u60F3\u3067\u304D\u306C.",
  "id" : 316244092889726977,
  "created_at" : "2013-03-25 17:44:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316243603666137088",
  "text" : "\u304A\u98A8\u5442\u2026",
  "id" : 316243603666137088,
  "created_at" : "2013-03-25 17:42:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316243175809363969",
  "text" : "\u805E\u304B\u306C\u306F\u4E00\u751F\u306E\u306A\u3093\u3061\u3083\u3089\u3001\u805E\u304F\u306F\u4E00\u6642\u306Ehogehoge",
  "id" : 316243175809363969,
  "created_at" : "2013-03-25 17:40:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316227717458710531",
  "text" : "\u56DE\u308A\u9053\u305B\u305A\u306BAC\u3068\u306E\u540C\u5024\u6027\u304C\u793A\u305B\u306A\u3044\u3043\u3043\u3043\u3043\u3044\u3043\u3043\u3043(\u56DE\u308A\u9053\u3057\u305F\u306E\u306F\u6848\u306E\u5B9A\u58F1\u5927\u6574\u57DF\u306B\u3042\u3063\u305F\u304C)",
  "id" : 316227717458710531,
  "created_at" : "2013-03-25 16:38:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316199672769310721",
  "geo" : { },
  "id_str" : "316210283859288064",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 (\u3072\u3069\u304F\u9060\u3044\u3067\u3059\u304C)\u7247\u4ED8\u3051\u308C\u3070\u4F7F\u3048\u307E\u3059",
  "id" : 316210283859288064,
  "in_reply_to_status_id" : 316199672769310721,
  "created_at" : "2013-03-25 15:29:41 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 12, 28 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 43, 53 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316144538274119681",
  "geo" : { },
  "id_str" : "316198981170503680",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 @Jelly_in_a_tank @yohjigureito @wa_ta_si_ \u884C\u304F\u307E\u3059\uFF01\uFF01",
  "id" : 316198981170503680,
  "in_reply_to_status_id" : 316144538274119681,
  "created_at" : "2013-03-25 14:44:46 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316125469550465024",
  "geo" : { },
  "id_str" : "316125663243403264",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u308F\u304B\u308B",
  "id" : 316125663243403264,
  "in_reply_to_status_id" : 316125469550465024,
  "created_at" : "2013-03-25 09:53:26 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316124468583997440",
  "text" : "\u304A\u5915\u98EF\u3069\u3053\u304B\u884C\u304F\u4EBA\u3044\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u3092\u3001\u304A\u8179\u6E1B\u3063\u305F\u3051\u3069\u98DF\u3079\u305F\u3044\u3082\u306E\u304C\u6D6E\u304B\u3070\u306A\u3044",
  "id" : 316124468583997440,
  "created_at" : "2013-03-25 09:48:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316124039900966912",
  "text" : "#nowplaying \u6587\u5316\u30F2\u98A8\u523A\u30B9\u30EB\u70CF - \u3069\u3076\u30A6\u30B5\u30AE-dBu music-",
  "id" : 316124039900966912,
  "created_at" : "2013-03-25 09:46:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316122821145268224",
  "geo" : { },
  "id_str" : "316123111051374592",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3042\u30FC\u591A\u4EBA\u6570\u540C\u6642\u9032\u884C\u7CFB\u306E\u3084\u3064\u304B\u30FC\u3001\u3044\u3051\u305D\u3046\u306A\u3089\u30EA\u30D7\u30E9\u30A4\u98DB\u3070\u3059\u3051\u3069\u3001\u9045\u308C\u3066\u884C\u304F\u3088\u3046\u306A\u3089\u3084\u3081\u3066\u304A\u304F\u308F\u30FC[\u307E\u3041\u3044\u304B\u306A\u3044\u3068\u601D\u3063\u3066\u304A\u3044\u3066\u30FC]",
  "id" : 316123111051374592,
  "in_reply_to_status_id" : 316122821145268224,
  "created_at" : "2013-03-25 09:43:17 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316121843339784192",
  "geo" : { },
  "id_str" : "316122160240418816",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3080\u30FC\u300116\u6642\u904E\u304E\u304F\u3089\u3044\u306A\u3089\u884C\u304D\u305F\u3044\u3051\u3069\u2026[\u591A\u5C11\uFF1F]",
  "id" : 316122160240418816,
  "in_reply_to_status_id" : 316121843339784192,
  "created_at" : "2013-03-25 09:39:30 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316117089230417921",
  "geo" : { },
  "id_str" : "316121811156860930",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ 15\u6642\u56FA\u5B9A\u3059\u304B",
  "id" : 316121811156860930,
  "in_reply_to_status_id" : 316117089230417921,
  "created_at" : "2013-03-25 09:38:07 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "indices" : [ 3, 11 ],
      "id_str" : "123194093",
      "id" : 123194093
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 13, 23 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316121665358680065",
  "text" : "RT @1738310: @end313124 \u3084\u306F\u308A\u5728\u5EAB\u306F\u30BC\u30ED\u3067\u3057\u305F\u3002\u81EA\u8EAB\u306E\u52C9\u5F37\u306B\u306A\u308A\u307E\u3057\u305F\u3002\u304A\u58F0\u639B\u3051\u3044\u305F\u3060\u304D\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "315495891232509952",
    "geo" : { },
    "id_str" : "316120020717535232",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u3084\u306F\u308A\u5728\u5EAB\u306F\u30BC\u30ED\u3067\u3057\u305F\u3002\u81EA\u8EAB\u306E\u52C9\u5F37\u306B\u306A\u308A\u307E\u3057\u305F\u3002\u304A\u58F0\u639B\u3051\u3044\u305F\u3060\u304D\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
    "id" : 316120020717535232,
    "in_reply_to_status_id" : 315495891232509952,
    "created_at" : "2013-03-25 09:31:00 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "protected" : false,
      "id_str" : "123194093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601183595303079937\/0a0Cxqqk_normal.jpg",
      "id" : 123194093,
      "verified" : false
    }
  },
  "id" : 316121665358680065,
  "created_at" : "2013-03-25 09:37:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316116266945482752",
  "text" : "\u3093\u30FC\u3001\u4F55\u3092\u98DF\u3079\u3088\u3046\u3002\u91CE\u83DC\u3068\u304B\u98DF\u3079\u305F\u3044\u611F\u3058\u3059\u308B\u3002",
  "id" : 316116266945482752,
  "created_at" : "2013-03-25 09:16:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316115408384053248",
  "text" : "\u5927\u5B66\u306B\u3044\u308B\u304C\u304A\u5BB6\u306B\u3054\u98EF\u708A\u3044\u3066\u306A\u3044\u306A\u2026",
  "id" : 316115408384053248,
  "created_at" : "2013-03-25 09:12:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316114144824791040",
  "text" : "#nowplaying \u795E\u5BC2\u3073\u305F\u53E4\u6226\u5834\u3000\uFF5E Suwa Foughten Field - \u3069\u3076\u30A6\u30B5\u30AE",
  "id" : 316114144824791040,
  "created_at" : "2013-03-25 09:07:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316111401754193920",
  "text" : "#nowplaying \u4FE1\u4EF0\u98A8\u5316\u66F2\u3000\uFF5E Native Faith - \u3069\u3076\u30A6\u30B5\u30AE",
  "id" : 316111401754193920,
  "created_at" : "2013-03-25 08:56:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316103986287607808",
  "text" : "\u3082\u304617:30\u3060\uFF1F",
  "id" : 316103986287607808,
  "created_at" : "2013-03-25 08:27:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316103747359092737",
  "text" : "#nowplaying \u82A5\u5DDD\u9F8D\u4E4B\u4ECB\u306E\u8D85\u6CB3\u7AE5 - \u3069\u3076\u30A6\u30B5\u30AE",
  "id" : 316103747359092737,
  "created_at" : "2013-03-25 08:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315894936019009540",
  "text" : "\u661F\u306B\u306D\u304C\u3044\u3092\u3001\u3053\u305F\u3064\u3084\u307F\u304B\u3093\u3001\u9060\u3044\u98DF\u5353",
  "id" : 315894936019009540,
  "created_at" : "2013-03-24 18:36:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315894418475470848",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u8AAD\u3093\u3060\u3089\u3082\u30463:34\u304B\u2026TL\u304C\u9A12\u304C\u3057\u3044",
  "id" : 315894418475470848,
  "created_at" : "2013-03-24 18:34:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315886474564354049",
  "text" : "\u3086\u30DF\u30B5\u3068\u306F\u61D0\u304B\u3057\u3044",
  "id" : 315886474564354049,
  "created_at" : "2013-03-24 18:02:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315886379764707330",
  "text" : "\u3086\uFF1F",
  "id" : 315886379764707330,
  "created_at" : "2013-03-24 18:02:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315882557185069056",
  "text" : "\u30B8\u30E3\u30F3\u30D7\u306F\u306A\u304B\u3063\u305F\u304C\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u306F\u3042\u3063\u305F",
  "id" : 315882557185069056,
  "created_at" : "2013-03-24 17:47:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315873406782427137",
  "text" : "\u3082\u3046\u6708\u66DC\u65E5\u3060\u3051\u308C\u3069\u30B8\u30E3\u30F3\u30D7\u3063\u3066\u7F6E\u3044\u3066\u3042\u3093\u306E\u304B\u306D\uFF0E",
  "id" : 315873406782427137,
  "created_at" : "2013-03-24 17:11:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315873296786808833",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u8CB7\u3044\u306B\u30B3\u30F3\u30D3\u30CB\u884C\u3053\u3046\u304B\uFF0E\uFF0E\uFF0E",
  "id" : 315873296786808833,
  "created_at" : "2013-03-24 17:10:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315861510889017344",
  "text" : "\u7D76\u671B\u304C\u898B\u3048\u308B(^^)(^^)(^^)",
  "id" : 315861510889017344,
  "created_at" : "2013-03-24 16:23:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315861082210172928",
  "text" : "\u3075\u3075\u3075\u3075\u5408\u308F\u305B\u6280\u3068\u306F\u9762\u767D\u3044(\u305F\u304B\u3055\u3093\u3055\u3093\u3055\u3093\u3068\u77E5\u308A\u5408\u3044\u3067\u306A\u304B\u3063\u305F\u3089\u51FA\u6765\u306A\u3044\u82B8\u5F53\u3067\u3042\u308B)",
  "id" : 315861082210172928,
  "created_at" : "2013-03-24 16:22:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 3, 18 ],
      "id_str" : "199550192",
      "id" : 199550192
    }, {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 20, 36 ],
      "id_str" : "230918258",
      "id" : 230918258
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 46, 56 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
      "indices" : [ 100, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315860942271418369",
  "text" : "RT @mircea_morning: @takasan_san_san\u3000\uFF08\u6587\u7684\u6570\u5B66\u5F92\uFF1F\uFF09\u3000@end313124  \uFF08\u7406\u7684\u6587\u5B66\u5F92\uFF1F\uFF09\u3000\u4E8C\u4EBA\u8DB3\u3057\u3066\u5272\u3063\u305F\u3089\u3001\u771F\u9762\u76EE\u306A\u6587\u5B66\u90E8\u751F\u3068\u3001\u771F\u9762\u76EE\u306A\u7406\u5B66\u90E8\u751F\u304C\u3067\u304D\u308B\u3000#RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u9AD8\u4E09 \u548C\u6643",
        "screen_name" : "takasan_san_san",
        "indices" : [ 0, 16 ],
        "id_str" : "230918258",
        "id" : 230918258
      }, {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 26, 36 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
        "indices" : [ 80, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315860279659474945",
    "in_reply_to_user_id" : 230918258,
    "text" : "@takasan_san_san\u3000\uFF08\u6587\u7684\u6570\u5B66\u5F92\uFF1F\uFF09\u3000@end313124  \uFF08\u7406\u7684\u6587\u5B66\u5F92\uFF1F\uFF09\u3000\u4E8C\u4EBA\u8DB3\u3057\u3066\u5272\u3063\u305F\u3089\u3001\u771F\u9762\u76EE\u306A\u6587\u5B66\u90E8\u751F\u3068\u3001\u771F\u9762\u76EE\u306A\u7406\u5B66\u90E8\u751F\u304C\u3067\u304D\u308B\u3000#RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
    "id" : 315860279659474945,
    "created_at" : "2013-03-24 16:18:53 +0000",
    "in_reply_to_screen_name" : "takasan_san_san",
    "in_reply_to_user_id_str" : "230918258",
    "user" : {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "protected" : false,
      "id_str" : "199550192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494419651342774272\/VcykhvGX_normal.jpeg",
      "id" : 199550192,
      "verified" : false
    }
  },
  "id" : 315860942271418369,
  "created_at" : "2013-03-24 16:21:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315860445795872768",
  "geo" : { },
  "id_str" : "315860514318196736",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u305D\u308C\u306Awww",
  "id" : 315860514318196736,
  "in_reply_to_status_id" : 315860445795872768,
  "created_at" : "2013-03-24 16:19:49 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315860380809310208",
  "text" : "\u5408\u308F\u305B\u6280\u3067\u6765\u308B\u3068\u306F\u601D\u308F\u306A\u304F\u3066\u7B11\u3063\u305F",
  "id" : 315860380809310208,
  "created_at" : "2013-03-24 16:19:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315860116631060482",
  "text" : "\u540C\u3058\u3053\u3068\u8A00\u3063\u3066\u308B\u4EBA\u3044\u3066\u30A6\u30B1\u308B",
  "id" : 315860116631060482,
  "created_at" : "2013-03-24 16:18:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315860036163358720",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u3042\u3063\u305F\u3053\u3068\u306A\u3044\u4EBA\u306B\u5370\u8C61\u3068\u304B\u805E\u3044\u3066\u3082\u306D\u3047",
  "id" : 315860036163358720,
  "created_at" : "2013-03-24 16:17:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315859498348707840",
  "geo" : { },
  "id_str" : "315859967892664322",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u666E\u6BB5\u306F\u99B4\u308C\u5408\u3044\u2026(^^)\u3001\u3068\u601D\u3046\u304C\u4F1A\u3063\u305F\u4E8B\u3042\u308B\u3057\u52E2\u3044(^^)",
  "id" : 315859967892664322,
  "in_reply_to_status_id" : 315859498348707840,
  "created_at" : "2013-03-24 16:17:39 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315859416731774976",
  "text" : "\u3053\u306E\u624B\u306E\u4E45\u3005\u306Brt\u3057\u305F\u306A",
  "id" : 315859416731774976,
  "created_at" : "2013-03-24 16:15:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 3, 18 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
      "indices" : [ 20, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315859368434339840",
  "text" : "RT @mircea_morning: #RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
        "indices" : [ 0, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315859226469740544",
    "text" : "#RT\u3057\u305F\u4EBA\u3092\u3082\u306E\u3059\u3054\u304F\u9069\u5F53\u306B\u7D39\u4ECB\u3059\u308B\u304B\u3089\u5F8C\u6094\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044",
    "id" : 315859226469740544,
    "created_at" : "2013-03-24 16:14:42 +0000",
    "user" : {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "protected" : false,
      "id_str" : "199550192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494419651342774272\/VcykhvGX_normal.jpeg",
      "id" : 199550192,
      "verified" : false
    }
  },
  "id" : 315859368434339840,
  "created_at" : "2013-03-24 16:15:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315859318023020545",
  "text" : "\u30DB\u30E2\u30C8\u30D4\u30FC\u98F2\u307F\u3068\u304B\u3044\u3046\u8868\u73FE\u304B\u3089\u306F\u5149\u3067\u306A\u304F\u95C7\u3092\u611F\u3058\u308B\u306E\u3060\u304C\u2026",
  "id" : 315859318023020545,
  "created_at" : "2013-03-24 16:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315858992641503232",
  "text" : "16\u6642\u904E\u304E\u304B\u3089\u304A\u98A8\u5442\u5165\u308D\u3046\u304B\u3068\u601D\u3044\u7D9A\u3051\u3066\u6C17\u3065\u3044\u305F\u30891\u6642\u306A\u3093\u3060",
  "id" : 315858992641503232,
  "created_at" : "2013-03-24 16:13:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315795279787982848",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 315795279787982848,
  "created_at" : "2013-03-24 12:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315786287724498945",
  "text" : "\u81EA\u708A\u3059\u308B\u3068\u5B89\u4E0A\u304C\u308A\u3060\u3057QOL\u4E0A\u304C\u308B\u3063\u3066\u3053\u3068\u306F\u81EA\u708A\u3042\u307E\u308A\u3067\u51FA\u3066\u3044\u306A\u3044\u6642\u671F\u3063\u3066\u304A\u91D1\u6255\u3063\u3066QOL\u4E0B\u3052\u3066\u308B\u7BC0\u3042\u308B",
  "id" : 315786287724498945,
  "created_at" : "2013-03-24 11:24:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315784877377191937",
  "text" : "\u3057\u3089\u3059\u3054\u306F\u3093\u30AA\u30A4\u30B7\u30A4\uFF01\uFF01",
  "id" : 315784877377191937,
  "created_at" : "2013-03-24 11:19:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/315784190404722688\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/hmRYezNzdp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGHkDE8CAAAyXtr.jpg",
      "id_str" : "315784190408916992",
      "id" : 315784190408916992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGHkDE8CAAAyXtr.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/hmRYezNzdp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315784190404722688",
  "text" : "QOL\u30C0\u30C0\u4E0A\u304C\u308A http:\/\/t.co\/hmRYezNzdp",
  "id" : 315784190404722688,
  "created_at" : "2013-03-24 11:16:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315764935693066241",
  "geo" : { },
  "id_str" : "315765120884154368",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u50D5\u3082\u3044\u307E\u3059\u3050\u3068\u306F\u601D\u3063\u3066\u306A\u3044\u3067\u3059(\u4ECA\u3059\u3050\u3067\u3082\u3084\u3076\u3055\u304B\u3067\u306F\u7121\u3044\u304C)",
  "id" : 315765120884154368,
  "in_reply_to_status_id" : 315764935693066241,
  "created_at" : "2013-03-24 10:00:46 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315763867236044800",
  "geo" : { },
  "id_str" : "315764021875838976",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u5927\u4E08\u592B\u3067\u3059[\u307F\u3093\u306A\u305D\u3046\u3044\u3046\u3093\u3060\u3088\u306D]",
  "id" : 315764021875838976,
  "in_reply_to_status_id" : 315763867236044800,
  "created_at" : "2013-03-24 09:56:24 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315763556710772736",
  "geo" : { },
  "id_str" : "315763690047696896",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 14\u679A\u7121\u3044\u3068\u4E0A\u304C\u308C\u307E\u305B\u3093\u306D(\uFF1F)",
  "id" : 315763690047696896,
  "in_reply_to_status_id" : 315763556710772736,
  "created_at" : "2013-03-24 09:55:04 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315762841460293632",
  "text" : "\u30AB\u30EA\u30B9\u30DE\u6027\u306E\u3001\u30B3\u30F3\u30C6\u30F3\u30C4\u6027\u306E\u306A\u3055\u304C\u73FE\u308C\u3066\u3044\u308B",
  "id" : 315762841460293632,
  "created_at" : "2013-03-24 09:51:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "315762718202286080",
  "text" : "\u9EBB\u96C0\u3084\u308A\u305F\u3044\u4EBA\u3044\u308B\u307D\u3044\u306E\u306B\u4EBA\u304C\u3042\u3093\u307E\u308A\u96C6\u307E\u3089\u306A\u3044\u30A1\uFF01[TwiPla] \u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 315762718202286080,
  "created_at" : "2013-03-24 09:51:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315762243365130240",
  "geo" : { },
  "id_str" : "315762298952220672",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u30AC\u30BF\u30C3",
  "id" : 315762298952220672,
  "in_reply_to_status_id" : 315762243365130240,
  "created_at" : "2013-03-24 09:49:33 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315761686114078720",
  "geo" : { },
  "id_str" : "315761923549446144",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u9EBB\u96C0\u30AA\u30D5\u4F01\u753B\u3057\u3061\u3083\u3063\u3066\u308B\u306E\u3067(\u307E\u3060\u4EBA\u6570\u602A\u3057\u3052\u3067\u3059\u306E\u3067\u3084\u308B\u304B\u5FAE\u5999\u3067\u3059\u304C)\u306F\u3084\u3081\u306E\u6642\u9593\u5E2F\u306A\u3089",
  "id" : 315761923549446144,
  "in_reply_to_status_id" : 315761686114078720,
  "created_at" : "2013-03-24 09:48:03 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315761248992116737",
  "geo" : { },
  "id_str" : "315761464692592640",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u3067\u306F\u305D\u3046\u3057\u307E\u3057\u3087\u3046\u3001\u3055\u3063\u304D\u306E\u611F\u3058\u3060\u306829\u307E\u3067\u4EAC\u90FD\u5468\u308A\u306B\u306F\u3044\u306A\u3044\u3067\u3059\uFF1F",
  "id" : 315761464692592640,
  "in_reply_to_status_id" : 315761248992116737,
  "created_at" : "2013-03-24 09:46:14 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315760180337987585",
  "geo" : { },
  "id_str" : "315760418628980736",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CC\u30FC\u3001\u30DE\u30AF\u30C9\u30CA\u30EB\u30C9\u884C\u304B\u306A\u3044\u52E2\u306A\u306E\u3067\u2026[\u30B5\u30D6\u30A6\u30A7\u30A4\u306E\u30B5\u30F3\u30C9\u30A4\u30C3\u30C1\u3068\u304B\u3067\u3082\u5B89\u304F\u3066\u3044\u3044\u304B\u3082]",
  "id" : 315760418628980736,
  "in_reply_to_status_id" : 315760180337987585,
  "created_at" : "2013-03-24 09:42:05 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315759403854868481",
  "geo" : { },
  "id_str" : "315759806164111360",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u3042\u30FC\u3054\u98EF\u304F\u3089\u3044\u3054\u99B3\u8D70\u3057\u3066\u304F\u308C\u308C\u3070\u305D\u308C\u3067\u826F\u3044\u3067\u3059\u30FC(6,700\u5186\u524D\u5F8C\u3067\u9069\u5F53\u306B)",
  "id" : 315759806164111360,
  "in_reply_to_status_id" : 315759403854868481,
  "created_at" : "2013-03-24 09:39:38 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315758573189746688",
  "geo" : { },
  "id_str" : "315759133838172161",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u53D7\u9A13\u306E\u6642\u306B\u3061\u3087\u3063\u3068\u4F7F\u3063\u305F\u3051\u3069\u672C\u68DA\u3067\u80A5\u3048\u3066\u308B\u3002\u66F8\u304D\u8FBC\u307F\u3068\u304B\u30DE\u30FC\u30AB\u30FC\u3068\u304B\u304A\u308A\u76EE\u3068\u304B\u4E00\u5207\u3064\u3051\u306A\u3044\u4E3B\u7FA9\u3060\u3057\u3001\u307E\u3041\u81EA\u7136\u306A\u64E6\u308A\u50B7(\uFF1F)\u307F\u305F\u3044\u306A\u306E\u306F\u306A\u3044\u3067\u306F\u306A\u3044\u3051\u3069",
  "id" : 315759133838172161,
  "in_reply_to_status_id" : 315758573189746688,
  "created_at" : "2013-03-24 09:36:58 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315758349079699456",
  "geo" : { },
  "id_str" : "315758393417670656",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CE",
  "id" : 315758393417670656,
  "in_reply_to_status_id" : 315758349079699456,
  "created_at" : "2013-03-24 09:34:02 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315755793267961856",
  "text" : "\u60B2\u3057\u307F",
  "id" : 315755793267961856,
  "created_at" : "2013-03-24 09:23:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315754488814264320",
  "geo" : { },
  "id_str" : "315754676316422145",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3046\u3061\u306E\u59B9\u304C\u5357\u56FD\u30DB\u30C6\u30EB\u3068\u8A00\u3044\u9593\u9055\u3048\u305F\u306E\u3082\u8A18\u61B6\u306B\u65B0\u3057\u3044",
  "id" : 315754676316422145,
  "in_reply_to_status_id" : 315754488814264320,
  "created_at" : "2013-03-24 09:19:15 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315753666634211330",
  "geo" : { },
  "id_str" : "315753775488958464",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5B9F\u969B\u30AA\u30A4\u30B7\u30A4\uFF01",
  "id" : 315753775488958464,
  "in_reply_to_status_id" : 315753666634211330,
  "created_at" : "2013-03-24 09:15:41 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315737870268772352",
  "text" : "\u30C9\u30EA\u30C3\u30D7\u3059\u308B\u6642\u306B\u4E0B\u306B\u6C37\u3092\u5FCD\u3070\u305B\u308B\u30B9\u30BF\u30A4\u30EB\u304C\u9999\u308A\u304C\u826F\u3044\u6C17\u304C\u3059\u308B",
  "id" : 315737870268772352,
  "created_at" : "2013-03-24 08:12:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315737754690547712",
  "text" : "\u591A\u91CF\u306E\u6C37\u3092\u4F7F\u3063\u305F\u7532\u6590\u3042\u308B",
  "id" : 315737754690547712,
  "created_at" : "2013-03-24 08:12:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315737689116798976",
  "text" : "\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u304C\u6B7B\u306C\u307B\u3069\u7F8E\u5473\u3044",
  "id" : 315737689116798976,
  "created_at" : "2013-03-24 08:11:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315735448985149440",
  "text" : "\u30CD\u30BF\u8981\u7D20\u304C\u591A\u3059\u304E\u3066\u82E5\u5E72\u99AC\u9E7F\u306B\u3057\u3066\u305F\u7BC0\u3042\u3063\u305F\u3051\u3069\u666E\u901A\u306B\u9762\u767D\u3044",
  "id" : 315735448985149440,
  "created_at" : "2013-03-24 08:02:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315735337047556097",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u30CD\u30AA\u30B5\u30A4\u30BF\u30DE\u708E\u4E0A\u8AAD\u307F\u7D42\u3048\u305F\u3051\u3069\u4E8C\u90E8\u3078\u306E\u5F15\u304D\u3082\u826F\u3044\u611F\u3058\u3060\u3057\u3001\u30E9\u30B9\u30C8\u30D0\u30C8\u30EB\u306F\u71B1\u3044\u3057\u3067\u7D50\u69CB\u697D\u3057\u3081\u305F(^^)(^^)(^^)",
  "id" : 315735337047556097,
  "created_at" : "2013-03-24 08:02:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 12, 28 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315674413083279361",
  "geo" : { },
  "id_str" : "315675463316033536",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 @jelly_in_a_tank \u9CE5\u8CB4\u65CF\u304F\u3089\u3044\u3057\u304B\u77E5\u3089\u306A\u3044\u3067\u3059\u3045[\u305D\u308A\u3083\u5B85\u98F2\u307F\u306E\u65B9\u304C\u5B89\u4E0A\u304C\u308A\u3067\u3057\u3087\u3046\u304C]",
  "id" : 315675463316033536,
  "in_reply_to_status_id" : 315674413083279361,
  "created_at" : "2013-03-24 04:04:30 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 17, 28 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315673544287739905",
  "geo" : { },
  "id_str" : "315673794104664064",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank @haguruma20 \u30B8\u30FC",
  "id" : 315673794104664064,
  "in_reply_to_status_id" : 315673544287739905,
  "created_at" : "2013-03-24 03:57:52 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315673483713576960",
  "text" : "\u3044\u308F\u305B\u3093\u306A\u306F\u305A\u304B\u3057\u30FC",
  "id" : 315673483713576960,
  "created_at" : "2013-03-24 03:56:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315673350976458754",
  "text" : "(\u30CE\u30FC\u30BA\u3068\u639B\u304B\u3063\u3066\u308B)",
  "id" : 315673350976458754,
  "created_at" : "2013-03-24 03:56:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315673273708974080",
  "text" : "\u9F3B\u30E0\u30BA\u30E0\u30BA\u306E\u56F3",
  "id" : 315673273708974080,
  "created_at" : "2013-03-24 03:55:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3061\u3088\u304E",
      "screen_name" : "larvitar1031",
      "indices" : [ 0, 13 ],
      "id_str" : "785969384",
      "id" : 785969384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315672581090992130",
  "geo" : { },
  "id_str" : "315672844661035008",
  "in_reply_to_user_id" : 785969384,
  "text" : "@larvitar1031 \u304A\u306F\u3088\u30FC\u3054\u3056\u3044\u307E\u3057\u305F\u30FC",
  "id" : 315672844661035008,
  "in_reply_to_status_id" : 315672581090992130,
  "created_at" : "2013-03-24 03:54:05 +0000",
  "in_reply_to_screen_name" : "larvitar1031",
  "in_reply_to_user_id_str" : "785969384",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315672537927389185",
  "text" : "\u304A\u304D\u305F\u30FC\u30FC\u30FC\u30FC\u30FC\u3088",
  "id" : 315672537927389185,
  "created_at" : "2013-03-24 03:52:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "indices" : [ 0, 8 ],
      "id_str" : "123194093",
      "id" : 123194093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315493913999855617",
  "geo" : { },
  "id_str" : "315495891232509952",
  "in_reply_to_user_id" : 123194093,
  "text" : "@1738310 \u3082\u3057\u304B\u3057\u3066\u672C\u306E\u5728\u5EAB\u628A\u63E1\u3057\u3066\u304A\u3089\u308C\u308B\u306E\u3067\u3059\u304B\uFF1F",
  "id" : 315495891232509952,
  "in_reply_to_status_id" : 315493913999855617,
  "created_at" : "2013-03-23 16:10:56 +0000",
  "in_reply_to_screen_name" : "1738310",
  "in_reply_to_user_id_str" : "123194093",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315493946627342338",
  "geo" : { },
  "id_str" : "315494415353405440",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u4F55\u306B\u3082\u3064\u3051\u306A\u304F\u3066\u3082\u30B5\u30AF\u30B5\u30AF\u7F8E\u5473\u3057\u3044\u306E\u3067\u30AA\u30B9\u30B9\u30E1\u30FC",
  "id" : 315494415353405440,
  "in_reply_to_status_id" : 315493946627342338,
  "created_at" : "2013-03-23 16:05:04 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315493632570437632",
  "geo" : { },
  "id_str" : "315493828830298113",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u88CF\u8868\u3053\u3093\u304C\u308A\u713C\u3044\u305F\u306E\u3092\u30B5\u30AF\u30B5\u30AF\u98DF\u3079\u308B\u306E\u597D\u304D\u306A\u3093\u3067\u3059[\u3082\u3061\u308D\u3093\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u3082\u597D\u304D\u3067\u3059\u304C]",
  "id" : 315493828830298113,
  "in_reply_to_status_id" : 315493632570437632,
  "created_at" : "2013-03-23 16:02:45 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315493631786094592",
  "text" : "\u65B0\u5352\u53D6\u3063\u3066\u308B\u306E\u304B\u306A",
  "id" : 315493631786094592,
  "created_at" : "2013-03-23 16:01:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315493583878770689",
  "text" : "\u5171\u7ACB\u3055\u3093\uFF01\u96C7\u3063\u3066\u304F\u3060\u3055\u3044\uFF01",
  "id" : 315493583878770689,
  "created_at" : "2013-03-23 16:01:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "indices" : [ 3, 11 ],
      "id_str" : "123194093",
      "id" : 123194093
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 13, 23 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315493416639283201",
  "text" : "RT @1738310: @end313124 \u5171\u7ACB\u8B1B\u5EA7 \u73FE\u4EE3\u306E\u6570\u5B66\u306E\u300E\u30DB\u30E2\u30C8\u30D4\u30FC\u8AD6\u300F\u3067\u3059\u306D\u3002\u5B9F\u306F\u3053\u306E\u672C\uFF0C\u30B1\u30FC\u30B9\u306F\u6C5A\u308C\u3066\u3044\u308B\u306E\u3067\u3059\u304C\uFF0C\u3082\u3057\u304B\u3059\u308B\u3068\u307E\u3060\u5728\u5EAB\u304C\u5C11\u3057\u3042\u308B\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u3002\u8CB7\u3046\u8CB7\u308F\u306A\u3044\u306F\u5225\u306B\u3057\u3066\uFF0C\u6708\u66DC\u65E5\u306B\u5728\u5EAB\u72B6\u6CC1\u306E\u5831\u544A\u3092\u4ECA\u4E00\u5EA6\u3055\u305B\u3066\u3044\u305F\u3060\u304D\u307E\u30FC\u3059\u3002\uFF08\u3082\u3046\u7121\u304B\u3063\u305F\u304B\u306A\u3041\u2026\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "315490795824230402",
    "geo" : { },
    "id_str" : "315492486355238912",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u5171\u7ACB\u8B1B\u5EA7 \u73FE\u4EE3\u306E\u6570\u5B66\u306E\u300E\u30DB\u30E2\u30C8\u30D4\u30FC\u8AD6\u300F\u3067\u3059\u306D\u3002\u5B9F\u306F\u3053\u306E\u672C\uFF0C\u30B1\u30FC\u30B9\u306F\u6C5A\u308C\u3066\u3044\u308B\u306E\u3067\u3059\u304C\uFF0C\u3082\u3057\u304B\u3059\u308B\u3068\u307E\u3060\u5728\u5EAB\u304C\u5C11\u3057\u3042\u308B\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u3002\u8CB7\u3046\u8CB7\u308F\u306A\u3044\u306F\u5225\u306B\u3057\u3066\uFF0C\u6708\u66DC\u65E5\u306B\u5728\u5EAB\u72B6\u6CC1\u306E\u5831\u544A\u3092\u4ECA\u4E00\u5EA6\u3055\u305B\u3066\u3044\u305F\u3060\u304D\u307E\u30FC\u3059\u3002\uFF08\u3082\u3046\u7121\u304B\u3063\u305F\u304B\u306A\u3041\u2026\uFF09",
    "id" : 315492486355238912,
    "in_reply_to_status_id" : 315490795824230402,
    "created_at" : "2013-03-23 15:57:24 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "protected" : false,
      "id_str" : "123194093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601183595303079937\/0a0Cxqqk_normal.jpg",
      "id" : 123194093,
      "verified" : false
    }
  },
  "id" : 315493416639283201,
  "created_at" : "2013-03-23 16:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315493286141915138",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 315493286141915138,
  "created_at" : "2013-03-23 16:00:35 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315492827457003520",
  "geo" : { },
  "id_str" : "315493007120023552",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat 10\u679A\u5207\u308A\u3063\u3066\u3082\u306E\u826F\u3044",
  "id" : 315493007120023552,
  "in_reply_to_status_id" : 315492827457003520,
  "created_at" : "2013-03-23 15:59:29 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "indices" : [ 0, 8 ],
      "id_str" : "123194093",
      "id" : 123194093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315492486355238912",
  "geo" : { },
  "id_str" : "315492798730219520",
  "in_reply_to_user_id" : 123194093,
  "text" : "@1738310 \u3044\u3048\u3001\u5B9F\u306F\u65E2\u306B\u6301\u3063\u3066\u308B\u3093\u3067\u3059\u3051\u308C\u3069\u3001\u5FA9\u520A\u3057\u306A\u3044\u306E\u304B\u306A\u30FC\u3068[\u304A\u624B\u6570\u3067\u3059\u306E\u3067\u5728\u5EAB\u78BA\u8A8D\u3057\u306A\u304F\u3066\u826F\u3044\u3067\u3059\u3088\u30FC]",
  "id" : 315492798730219520,
  "in_reply_to_status_id" : 315492486355238912,
  "created_at" : "2013-03-23 15:58:39 +0000",
  "in_reply_to_screen_name" : "1738310",
  "in_reply_to_user_id_str" : "123194093",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315492375906623488",
  "text" : "\u308F\u3078\u3044\u3078\u3044\uFF01",
  "id" : 315492375906623488,
  "created_at" : "2013-03-23 15:56:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315492209170468864",
  "text" : "\u3044\u3084\u3001\u50D5\u306F\u50D5\u306ETL\u3067\u306F\u305D\u3093\u306A\u306B\u767A\u8A00\u591A\u304F\u306A\u3044\u3051\u308C\u3069\u30D5\u30A9\u30ED\u30FC3\u4EBA\u3067\u50D5\u3092\u30D5\u30A9\u30ED\u30FC\u3059\u308B\u306E\u306F\u30E4\u30D0\u30A4\u3068\u601D\u3046",
  "id" : 315492209170468864,
  "created_at" : "2013-03-23 15:56:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315491266978783233",
  "text" : "\u5927\u738B\u304C\u3053\u3046\u8A00\u3063\u3066\u304A\u3089\u308C\u308B\u306E\u3060\u304B\u3089\u5168\u54E1JK\u306A\u306E\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 315491266978783233,
  "created_at" : "2013-03-23 15:52:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315491269231144960",
  "text" : "\uFF1F",
  "id" : 315491269231144960,
  "created_at" : "2013-03-23 15:52:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315490892876226561",
  "text" : "\u6211\u306A\u304C\u3089\u5510\u7A81\u3059\u304E\u305F\u611F\u3058\u3059\u308B",
  "id" : 315490892876226561,
  "created_at" : "2013-03-23 15:51:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "indices" : [ 0, 8 ],
      "id_str" : "123194093",
      "id" : 123194093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315489654398935041",
  "geo" : { },
  "id_str" : "315490795824230402",
  "in_reply_to_user_id" : 123194093,
  "text" : "@1738310 \u5510\u7A81\u3067\u3059\u304C\u30DB\u30E2\u30C8\u30D4\u30FC\u8AD6(\u897F\u7530)\u3068\u304B\u5FA9\u520A\u306E\u4E88\u5B9A\u3068\u304B\u306A\u3044\u3093\u3067\u3059\uFF1F",
  "id" : 315490795824230402,
  "in_reply_to_status_id" : 315489654398935041,
  "created_at" : "2013-03-23 15:50:41 +0000",
  "in_reply_to_screen_name" : "1738310",
  "in_reply_to_user_id_str" : "123194093",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5171\u7ACB\u51FA\u7248\u30B9\u30BF\u30FC\u30C8\u30EC\u30C3\u30AF\u87FB",
      "screen_name" : "1738310",
      "indices" : [ 0, 8 ],
      "id_str" : "123194093",
      "id" : 123194093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315430017897218048",
  "geo" : { },
  "id_str" : "315464165236027393",
  "in_reply_to_user_id" : 123194093,
  "text" : "@1738310 \u671F\u9593\u9650\u5B9A\u5546\u54C1\u306A\u3093\u3067\u3059\u304B\u306D\u3001\u9802\u304D\u7269\u306A\u306E\u3067\u308F\u304B\u3089\u306A\u3044\u306E\u3067\u3059\u304C",
  "id" : 315464165236027393,
  "in_reply_to_status_id" : 315430017897218048,
  "created_at" : "2013-03-23 14:04:52 +0000",
  "in_reply_to_screen_name" : "1738310",
  "in_reply_to_user_id_str" : "123194093",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "315435620178747394",
  "text" : "[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 315435620178747394,
  "created_at" : "2013-03-23 12:11:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "315435622816952320",
  "text" : "[TwiPla] \u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 315435622816952320,
  "created_at" : "2013-03-23 12:11:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315432837341913088",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 315432837341913088,
  "created_at" : "2013-03-23 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315090290929201154",
  "text" : "\u697D\u3057\u3093\u3060\u3082\u306E\u52DD\u3061\u306A\u3068\u3053\u308D\u3042\u308B",
  "id" : 315090290929201154,
  "created_at" : "2013-03-22 13:19:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315090128525729792",
  "geo" : { },
  "id_str" : "315090227846868993",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u305D\u306E\u65B9\u304C\u697D\u3057\u3081\u308B\u306A\u3089\u3042\u308B\u3044\u306F\u826F\u3044\u306E\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u306D\u30FC",
  "id" : 315090227846868993,
  "in_reply_to_status_id" : 315090128525729792,
  "created_at" : "2013-03-22 13:18:59 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315087380195459073",
  "text" : "\u5272\u3068\u539F\u4F5C\u53A8\u306A\u3068\u3053\u308D\u3042\u308B\u304B\u3089\u306A\u2026\u30E1\u30C7\u30A3\u30A2\u30DF\u30C3\u30AF\u30B9\u4F5C\u54C1\u306E\u8A55\u4FA1\u306F\u57FA\u672C\u53B3\u3057\u3081\u306A\u306E\u304B\u3082",
  "id" : 315087380195459073,
  "created_at" : "2013-03-22 13:07:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315086795404607488",
  "geo" : { },
  "id_str" : "315087156051861506",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u3044\u3084\u3001\u539F\u4F5C\u304C\u826F\u3059\u304E\u305F\u3068\u8A00\u3046\u304B\u3001\u539F\u4F5C\u306E\u30A4\u30E1\u30FC\u30B8\u3068\u9055\u3063\u305F\u3068\u3044\u3046\u304B\u2026",
  "id" : 315087156051861506,
  "in_reply_to_status_id" : 315086795404607488,
  "created_at" : "2013-03-22 13:06:46 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315085863052771328",
  "geo" : { },
  "id_str" : "315086305996455937",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u7D20\u76F4\u306A\u611F\u60F3\u3092\u3069\u3046\u305E",
  "id" : 315086305996455937,
  "in_reply_to_status_id" : 315085863052771328,
  "created_at" : "2013-03-22 13:03:24 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315085483615059968",
  "text" : "\u30C0\u30EC\u30F3\u30B7\u30E3\u30F3\u306E\u6F2B\u753B\u3063\u3066\u3044\u3046\u306E\u304C\u2026\u3044\u3084\u3001\u306A\u3093\u3067\u3082\u306A\u3044",
  "id" : 315085483615059968,
  "created_at" : "2013-03-22 13:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315083417287024640",
  "geo" : { },
  "id_str" : "315085309849239553",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u4E86\u89E3\u3057\u307E\u3057\u305F\u300216\u6642\u304F\u3089\u3044\u3067\u629C\u3051\u308B\u3068\u306F\u601D\u3044\u307E\u3059\u304C\u884C\u304D\u307E\u3059\u3002[\u591A\u304F\u3068\u3082\u3067\u306F\uFF1F]",
  "id" : 315085309849239553,
  "in_reply_to_status_id" : 315083417287024640,
  "created_at" : "2013-03-22 12:59:26 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315081771333070848",
  "text" : "6\u6642\u9593\u3082\u524D\u306E\u30EA\u30D7\u30E9\u30A4\u306B\u4ECA\u6C17\u3065\u3044\u305F",
  "id" : 315081771333070848,
  "created_at" : "2013-03-22 12:45:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314984490944581632",
  "geo" : { },
  "id_str" : "315081677309353984",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u4F55\u6642\u307E\u3067\u3092\u4E88\u5B9A\u3057\u3066\u307E\u3059\u304B\uFF1F\u5915\u65B9\u304B\u3089\u30D0\u30A4\u30C8\u306A\u306E\u3067\u3059\u304C\u2026",
  "id" : 315081677309353984,
  "in_reply_to_status_id" : 314984490944581632,
  "created_at" : "2013-03-22 12:45:00 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315065957313814528",
  "text" : "@setsuna030218 \u3064\u3044\u3082\u3046\u4E00\u56DE\u3092\u7E70\u308A\u8FD4\u3057\u3066\u3057\u307E\u3044\u307E\u3059",
  "id" : 315065957313814528,
  "created_at" : "2013-03-22 11:42:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315065847410475008",
  "text" : "@ayuretti \u30DE\u30B8\u304B\u4E09(^o^)\u30CE",
  "id" : 315065847410475008,
  "created_at" : "2013-03-22 11:42:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315065700538515457",
  "text" : "@ayuretti \u3046\u3061\u306E\u5B66\u751F\u8A3C\u901A\u308B\u3089\u3057\u3044\u3067",
  "id" : 315065700538515457,
  "created_at" : "2013-03-22 11:41:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315065444367212544",
  "text" : "\u4E45\u3005\u306B\u30C0\u30D6\u30EB\u30B9\u30DD\u30A4\u30E9\u30FC\u3084\u3063\u305F\u3089\u697D\u3057\u304F\u3066\u6642\u9593\u4F7F\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 315065444367212544,
  "created_at" : "2013-03-22 11:40:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315042309551038464",
  "text" : "\u30D0\u30C3\u30AF\u30B9\u30E9\u30C3\u30B7\u30E5bio\u306B\u66F8\u304D\u63DB\u3048\u305F\uFF0E\u3053\u308C\u74B0\u5883\u3067\u306F\uFFE5\u306B\u306A\u308B\u306E\u304B\u306D\uFF0E",
  "id" : 315042309551038464,
  "created_at" : "2013-03-22 10:08:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "315035002519826432",
  "text" : "\u90E8\u5206\u53C2\u52A0\u3082\u3069\u3046\u305E\uFF01\uFF01[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 315035002519826432,
  "created_at" : "2013-03-22 09:39:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314945072825257984",
  "geo" : { },
  "id_str" : "314945192560050178",
  "in_reply_to_user_id" : 427714784,
  "text" : "@miattermeyer \u2582\u2585\u2587\u2588\u2593\u2592\u2591(\u2019\u03C9\u2019)\u2591\u2592\u2593\u2588\u2587\u2585\u2582 \u3046\u308F\u3042\u3042\u3042\u3042",
  "id" : 314945192560050178,
  "in_reply_to_status_id" : 314945072825257984,
  "created_at" : "2013-03-22 03:42:39 +0000",
  "in_reply_to_screen_name" : "miantomori",
  "in_reply_to_user_id_str" : "427714784",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314944439514718208",
  "text" : "\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u671D\u306E\u30D5\u30EB\u30FC\u30C4\u30DF\u30C3\u30AF\u30B9\u7F8E\u5473\u3057\u3044",
  "id" : 314944439514718208,
  "created_at" : "2013-03-22 03:39:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314944301803126784",
  "text" : "\u5927\u5B66\u306B\u6559\u7FA9\u306E\u6570\u5B66\u5F92\u304C\u96C6\u3063\u3066\u3044\u305F",
  "id" : 314944301803126784,
  "created_at" : "2013-03-22 03:39:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314928006906908672",
  "text" : "\u3082\u30464\u56DE\u306A\u3093\u3060\u304C",
  "id" : 314928006906908672,
  "created_at" : "2013-03-22 02:34:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314927991127932928",
  "text" : "\u3055\u3063\u304D\u300C\u65B0\u5165\u751F\u306E\u65B9\u3067\u3059\u304B\uFF1F\u300D\u3063\u3066\u805E\u304B\u308C\u305F\u304B\u3089\u307E\u3060\u82E5\u304F\u898B\u3048\u3066\u308B\u3089\u3057\u3044(^^)(^^)(^^)",
  "id" : 314927991127932928,
  "created_at" : "2013-03-22 02:34:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314727794586304512",
  "text" : "4\u4E01\u76EE5\u4E01\u76EE\u306B\u4F4F\u3093\u3067\u3044\u308B\u4EBA\u306F\u5927\u5909\u3060",
  "id" : 314727794586304512,
  "created_at" : "2013-03-21 13:18:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314727742899900417",
  "text" : "\u3059\u3052\u3047\u3047\u3047\u3047\uFF01\uFF01\uFF01\uFF3B\u3053\u306E\u6642\u671F\u9154\u3063\u6255\u3044\u304C\u672C\u5F53\u306B\u3046\u308B\u3055\u3044\u3088\u306D\uFF3D",
  "id" : 314727742899900417,
  "created_at" : "2013-03-21 13:18:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "indices" : [ 3, 11 ],
      "id_str" : "20522410",
      "id" : 20522410
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/halhorn\/status\/314727565682151424\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/KqHnHPe0u6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF4jDbHCEAAa269.jpg",
      "id_str" : "314727565686345728",
      "id" : 314727565686345728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF4jDbHCEAAa269.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KqHnHPe0u6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314727623383216128",
  "text" : "RT @halhorn: \u4E95\u306E\u982D\u516C\u5712\u3001\u6C60\u3068\u6A4B\u3068\u685C\u3002\u9577\u6642\u9593\u9732\u5149\u3002 http:\/\/t.co\/KqHnHPe0u6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/halhorn\/status\/314727565682151424\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/KqHnHPe0u6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BF4jDbHCEAAa269.jpg",
        "id_str" : "314727565686345728",
        "id" : 314727565686345728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF4jDbHCEAAa269.jpg",
        "sizes" : [ {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KqHnHPe0u6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314727565682151424",
    "text" : "\u4E95\u306E\u982D\u516C\u5712\u3001\u6C60\u3068\u6A4B\u3068\u685C\u3002\u9577\u6642\u9593\u9732\u5149\u3002 http:\/\/t.co\/KqHnHPe0u6",
    "id" : 314727565682151424,
    "created_at" : "2013-03-21 13:17:53 +0000",
    "user" : {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "protected" : false,
      "id_str" : "20522410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550565137359204353\/hwjKwmzK_normal.jpeg",
      "id" : 20522410,
      "verified" : false
    }
  },
  "id" : 314727623383216128,
  "created_at" : "2013-03-21 13:18:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314723254180925441",
  "text" : "\u8010\u6C34\u30CE\u30FC\u30C8\u304C\u7D50\u69CB\u3042\u308B\u3058\u3083\u306A\u3044\u304B\uFF1F",
  "id" : 314723254180925441,
  "created_at" : "2013-03-21 13:00:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314722163917746178",
  "text" : "\u3057\u304B\u3057\u3042\u3064\u3044\u3042\u3064\u3044",
  "id" : 314722163917746178,
  "created_at" : "2013-03-21 12:56:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314720901906173952",
  "text" : "\u524D\u304A\u3063\u3055\u3093\u304C\uFF08\u53E4\u672C\uFF1F\uFF09\u6587\u5EAB\u672C\u3092\u3057\u308F\u3057\u308F\u306B\u3057\u306A\u304C\u3089\u8AAD\u3093\u3067\u308B\u306E\u898B\u305F\u3053\u3068\u3042\u308B\u304B\u3089\u6570\u5B66\u3084\u308B\u306E\u3082\u305F\u3076\u3093\u30A2\u30EA",
  "id" : 314720901906173952,
  "created_at" : "2013-03-21 12:51:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314720713472884739",
  "text" : "\u9632\u6C34\u30CE\u30FC\u30C8\u3068\u30DA\u30F3\u3060\u3051\u74B0\u5883\u6574\u3048\u308C\u3070\u5B8C\u74A7\u3067\u3042\u308B\uFF0E",
  "id" : 314720713472884739,
  "created_at" : "2013-03-21 12:50:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314720616827727872",
  "text" : "\u30B5\u30A6\u30CA\u3067\u6570\u5B66\uFF0C\u305D\u308C\u3057\u304B\u3084\u308B\u3053\u3068\u306A\u3044\u304B\u3089\u96C6\u4E2D\u3059\u308B\u3057\uFF0C\u5065\u5EB7\u7684\u3060\u3057\u5BDD\u3064\u304D\u3082\u3044\u3044\u3057\uFF0C\u6BCE\u56DE\u30BC\u30DF\u5F8C\u306B\u30B5\u30A6\u30CA\u3067\u5FA9\u7FD2\u306E\u6D41\u308C\u3042\u308B\u306E\u3067\u306F\uFF0E",
  "id" : 314720616827727872,
  "created_at" : "2013-03-21 12:50:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314717976056197120",
  "text" : "\u7D50\u8AD6:\u30B5\u6570\u5B66\u30A6\u30CA\u306F\u697D\u3057\u3044",
  "id" : 314717976056197120,
  "created_at" : "2013-03-21 12:39:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314708080153751552",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 314708080153751552,
  "created_at" : "2013-03-21 12:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314690100464336896",
  "text" : "\uFF77\uFF9E\uFF6E\uFF97\uFF9D",
  "id" : 314690100464336896,
  "created_at" : "2013-03-21 10:49:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoste!",
      "screen_name" : "__4st",
      "indices" : [ 3, 9 ],
      "id_str" : "1003578246",
      "id" : 1003578246
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/__4st\/status\/314690008936226816\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/kyY3n1eYXz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF4A5VVCIAAfugM.jpg",
      "id_str" : "314690008940421120",
      "id" : 314690008940421120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF4A5VVCIAAfugM.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kyY3n1eYXz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314690043589558272",
  "text" : "RT @__4st: \u30ED\u30AF\u30BB\u30F3\u30B9\u30BA\u30E1\u30C0\u30A4\u306E\u5375 http:\/\/t.co\/kyY3n1eYXz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/__4st\/status\/314690008936226816\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/kyY3n1eYXz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BF4A5VVCIAAfugM.jpg",
        "id_str" : "314690008940421120",
        "id" : 314690008940421120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF4A5VVCIAAfugM.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kyY3n1eYXz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314690008936226816",
    "text" : "\u30ED\u30AF\u30BB\u30F3\u30B9\u30BA\u30E1\u30C0\u30A4\u306E\u5375 http:\/\/t.co\/kyY3n1eYXz",
    "id" : 314690008936226816,
    "created_at" : "2013-03-21 10:48:39 +0000",
    "user" : {
      "name" : "Yoste!",
      "screen_name" : "__4st",
      "protected" : false,
      "id_str" : "1003578246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603939106523979777\/HZG7_G8D_normal.jpg",
      "id" : 1003578246,
      "verified" : false
    }
  },
  "id" : 314690043589558272,
  "created_at" : "2013-03-21 10:48:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314689726114312193",
  "geo" : { },
  "id_str" : "314689871547604992",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5996\u602A\u7121\u99C4\u5265\u304E\u3092 \uFF3B\u305D\u306E\u6D41\u308C\u3042\u308B\u3042\u308B\uFF3D",
  "id" : 314689871547604992,
  "in_reply_to_status_id" : 314689726114312193,
  "created_at" : "2013-03-21 10:48:06 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314688993742684160",
  "text" : "\u9B5A\u3068\u8A00\u3046\u30C4\u30A4\u30C3\u30BF\u30E9\u30FC\u3082\u5C45\u305F\u304B\u3089\u3044\u308D\u3044\u308D\u5371\u967A\u306A\u4F1A\u8A71\u3060\u3063\u305F\u306A\uFF1F",
  "id" : 314688993742684160,
  "created_at" : "2013-03-21 10:44:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314688532188901378",
  "geo" : { },
  "id_str" : "314688734387900416",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u3046\u3044\u3048\u3070\u9B5A\u306E\u5375\u3063\u3066\uFF7C\uFF9E\uFF6D\uFF99\uFF7C\uFF9E\uFF6D\uFF99\u3057\u3066\u308B\u3088\u306D",
  "id" : 314688734387900416,
  "in_reply_to_status_id" : 314688532188901378,
  "created_at" : "2013-03-21 10:43:35 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314688542045511680",
  "text" : "\uFF1F",
  "id" : 314688542045511680,
  "created_at" : "2013-03-21 10:42:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314688526530797569",
  "text" : "\u4EAC\u90FD\u3067\u306F\u91CE\u751F\u5316\u3057\u305F\u30D0\u30A4\u30AA\u30AB\u30BA\u30CE\u30B3\u304C\u3059\u3046\u304C\u304F\u5F92\u3092\u8972\u3063\u3066\u3044\u308B\u3068\u805E\u304F\u304B\u3089\u306A...",
  "id" : 314688526530797569,
  "created_at" : "2013-03-21 10:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314688403172126720",
  "text" : "\u30D0\u30A4\u30AA\u30AB\u30BA\u30CE\u30B3\u306B\u9055\u3044\u306A\u3044",
  "id" : 314688403172126720,
  "created_at" : "2013-03-21 10:42:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314688008458752001",
  "geo" : { },
  "id_str" : "314688374772486144",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30CB\u30B7\u30F3\u306E\u5375\u3068\u30BC\u30EA\u30FC\u306E\u5B50\u4F9B\u3063\u3066\u305D\u308C\u5375\u304B\u3089\u7A1A\u9B5A\u304C\u5B75\u308B\u524D\u306B\u89AA\u3063\u3066\u30E4\u30D0\u3044\u306E\u3067\u306F",
  "id" : 314688374772486144,
  "in_reply_to_status_id" : 314688008458752001,
  "created_at" : "2013-03-21 10:42:09 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314687859443503104",
  "geo" : { },
  "id_str" : "314687976519122945",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u8AB0\u306E\u5B50\u3060\u3088\uFF57\uFF57\uFF57",
  "id" : 314687976519122945,
  "in_reply_to_status_id" : 314687859443503104,
  "created_at" : "2013-03-21 10:40:34 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314687467703918592",
  "geo" : { },
  "id_str" : "314687779894341632",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5439\u594F\u697D\u306B\u5408\u308F\u305B\u3066\u697D\u3057\u304F\u30D6\u30E9\u30A6\u30F3\u904B\u52D5\u3057\u3066\u307E\u3057\u305F\u3088\u306D\uFF01\u3042\u308C\u304C\u30BC\u30EA\u30FC\u3055\u3093\u3060\u3063\u305F\u3093\u3067\u3059\u304B\uFF01",
  "id" : 314687779894341632,
  "in_reply_to_status_id" : 314687467703918592,
  "created_at" : "2013-03-21 10:39:48 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314687353174257665",
  "geo" : { },
  "id_str" : "314687414339792898",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30D6\u30E9\u30A6\u30F3\u904B\u52D5\u3057\u3066\u308B\u3084\u3064\u306A\u3089\u3053\u306E\u524D\u898B\u304B\u3051\u305F\uFF0E",
  "id" : 314687414339792898,
  "in_reply_to_status_id" : 314687353174257665,
  "created_at" : "2013-03-21 10:38:20 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314687091730677760",
  "geo" : { },
  "id_str" : "314687247351955456",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30BC\u30EA\u30FC\u304C\u52D5\u3044\u305F\u3089\u305D\u308C\u3082\u3046\u30B9\u30E9\u30A4\u30E0\u3060\u3088\u306D",
  "id" : 314687247351955456,
  "in_reply_to_status_id" : 314687091730677760,
  "created_at" : "2013-03-21 10:37:41 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314687028753231872",
  "text" : "\u6839\u3063\u304B\u3089\u306E\u690D\u7269\u4EBA\u9593\u306A\u3093\u3067\u3059",
  "id" : 314687028753231872,
  "created_at" : "2013-03-21 10:36:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314686802747342850",
  "geo" : { },
  "id_str" : "314686965582790656",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6839\u3063\u3053\u304C\u3042\u308B\u30BC\u30EA\u30FC\u3063\u3066\u305D\u308C\u4F55\u304B\u6A39\u6DB2\u7684\u306A\u3082\u306E\u306A\u306E\u3067\u306F",
  "id" : 314686965582790656,
  "in_reply_to_status_id" : 314686802747342850,
  "created_at" : "2013-03-21 10:36:33 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 17, 24 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314686454100021248",
  "geo" : { },
  "id_str" : "314686586140897280",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank @tenapi \u53E3\u3005\u306B\u99C6\u9010\u3055\u308C\u3066\u3044\u304F\u30CD\u30BF\u306E\u6570\u3005",
  "id" : 314686586140897280,
  "in_reply_to_status_id" : 314686454100021248,
  "created_at" : "2013-03-21 10:35:03 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314686408415662080",
  "text" : "\u53F0\u7121\u3057\uFF0E",
  "id" : 314686408415662080,
  "created_at" : "2013-03-21 10:34:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314686391227383808",
  "text" : "\u5C0F\u8C46\u3042\u3089\u3044\u304C\u5C0F\u8C46\u3092\u6D17\u3044\uFF0C\u5996\u602A\u30AB\u30EF\u30CF\u30AE\u304C\u76AE\u3092\u5265\u304E\uFF0C\u4E39\u7CBE\u8FBC\u3081\u3066\u4F5C\u3063\u305F\u3053\u3057\u3042\u3093\u306B\u7802\u304B\u3051\u3070\u3070\u3042\u304C\u7802\u3092\u304B\u3051\u308B\u30CF\u30FC\u30C8\u30D5\u30EB\u30B9\u30C8\u30FC\u30EA\u30FC",
  "id" : 314686391227383808,
  "created_at" : "2013-03-21 10:34:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306A\u3093\u3060\u3053\u308C",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314685951030988800",
  "text" : "\u5996\u602A\u30AB\u30EF\u30CF\u30AE\u300C\u9762\u5012\u306A\u3058\u3083\u304C\u3044\u3082\u306E\u76AE\u5411\u304D\u3082\u79C1\u306B\u304B\u304B\u308C\u3070...\u3053\u306E\u901A\u308A\uFF01\uFF01\u300D #\u306A\u3093\u3060\u3053\u308C",
  "id" : 314685951030988800,
  "created_at" : "2013-03-21 10:32:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314685803127267328",
  "text" : "\u5996\u602A\u30AB\u30EF\u30CF\u30AE\u610F\u5916\u306B\u7121\u5BB3\u306A\u3044\u3044\u5974\u306A\u306E\u304B\u3082\u3057\u308C\u306A\u3044\uFF0E",
  "id" : 314685803127267328,
  "created_at" : "2013-03-21 10:31:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314685672285933569",
  "text" : "\uFF1F",
  "id" : 314685672285933569,
  "created_at" : "2013-03-21 10:31:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314685664526495745",
  "text" : "\u5C0F\u8C46\u3092\u6D17\u3063\u3066\u76AE\u3092\u5265\u3044\u3067\u4E0A\u8CEA\u306A\u3053\u3057\u3042\u3093\u3092\u4F5C\u308A\u307E\u3059",
  "id" : 314685664526495745,
  "created_at" : "2013-03-21 10:31:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314685554006564865",
  "text" : "\u5996\u602A\u30AB\u30EF\u30CF\u30AE\u3068\u5996\u602A\u3042\u305A\u304D\u3042\u3089\u3044\u304C\u4E26\u3093\u3067\u308B\u69D8\uFF0C\u30B7\u30E5\u30FC\u30EB\u3067\u3044\u3044\u3068\u601D\u3046\uFF0E",
  "id" : 314685554006564865,
  "created_at" : "2013-03-21 10:30:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314685448255578113",
  "text" : "\u9375\u306E\u4EBA\u304B\u3089\u300C\u5996\u602A\u30AB\u30EF\u30CF\u30AE\u300D\u3068\u304B\u8A00\u3046\u6050\u308D\u3057\u3044\u30EF\u30FC\u30C9\u3092\u9802\u6234\u3057\u305F\uFF0E",
  "id" : 314685448255578113,
  "created_at" : "2013-03-21 10:30:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u306E\u4FE1\u5F92\u307E\u3093\u304C\u3093\uFF01",
      "screen_name" : "25manganum",
      "indices" : [ 0, 11 ],
      "id_str" : "400280435",
      "id" : 400280435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314685317447839745",
  "geo" : { },
  "id_str" : "314685386947440640",
  "in_reply_to_user_id" : 400280435,
  "text" : "@25manganum \u306A\u306B\u305D\u308C\u6016\u3044\uFF0E",
  "id" : 314685386947440640,
  "in_reply_to_status_id" : 314685317447839745,
  "created_at" : "2013-03-21 10:30:17 +0000",
  "in_reply_to_screen_name" : "25manganum",
  "in_reply_to_user_id_str" : "400280435",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314685204767834112",
  "text" : "\u3068\u306F\u3044\u3048\u9AA8\u3068\u76AE\u3068\u304C\u5265\u304C\u308C\u308B\u97F3\u3092\u805E\u3044\u305F\u3053\u3068\u3042\u308B\u4EBA\u3044\u306A\u3044\u304B\u3089\u4F55\u3068\u3067\u3082\u8A00\u3048\u308B\u306E\u3067\u306F\uFF0C\u3042\u3093\u304C\u3044\u300C\uFF77\uFF6A\uFF6A\uFF6A\uFF6A\uFF6A\uFF6A\u300D\u3068\u304B\u8A00\u3046\u97F3\u304B\u3082\u3057\u308C\u306A\u3044\uFF0E",
  "id" : 314685204767834112,
  "created_at" : "2013-03-21 10:29:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314684781021503488",
  "text" : "\u97F3\u306E\u30BD\u30E0\u30EA\u30A8\u3068\u304B\u99AC\u306E\u738B\u5B50\u69D8\u307F\u305F\u3044\u306A23\u6642\u306B\u306A\u308B\u76F4\u524D\u4F4D\u306B\u3084\u308B3\u5206\u7A0B\u5EA6\u306E\u756A\u7D44\u7D50\u69CB\u597D\u304D",
  "id" : 314684781021503488,
  "created_at" : "2013-03-21 10:27:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314684341630410752",
  "geo" : { },
  "id_str" : "314684668064714752",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u97F3\u306E\u30BD\u30E0\u30EA\u30A8\u3067\u7D39\u4ECB\u3057\u3066\u307B\u3057\u3044\uFF0E\u5B57\u5E55\u30AA\u30F3\u30EA\u30FC\uFF0C\u7121\u97F3\uFF0C\u89E3\u8AAC\u306A\u3057\u3067\uFF0C\u756A\u7D44\u6642\u9593\u4E2D\u305F\u3060\u305D\u306E\u6587\u5B57\u304C\u6620\u3063\u3066\u308B\u3060\u3051\uFF0E",
  "id" : 314684668064714752,
  "in_reply_to_status_id" : 314684341630410752,
  "created_at" : "2013-03-21 10:27:26 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314684287872020480",
  "text" : "\u30AB\u30EF\u30CF\u30AE\u3068\u306F\u3044\u3048\u666E\u6BB5\u306F\u76AE\u3092\u5265\u304C\u308C\u308B\u5074\u3060\u304B\u3089\u540D\u524D\u8CA0\u3051\u3057\u3066\u308B\u3068\u601D\u3046\uFF0E",
  "id" : 314684287872020480,
  "created_at" : "2013-03-21 10:25:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314684187183566848",
  "text" : "\u300C\u5316\u3051\u306E\u76AE\u304C\u5265\u304C\u308C\u305F\u30AB\u30EF\u30CF\u30AE\u300D\u3068\u3044\u3046\u30EF\u30FC\u30C9\u8003\u3048\u305F\u306E\u3067\u8AB0\u304B\u30DD\u30A8\u30E0\u306B\u3067\u3082\u4F7F\u3063\u3066\u304F\u3060\u3055\u3044",
  "id" : 314684187183566848,
  "created_at" : "2013-03-21 10:25:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314684031226757120",
  "text" : "\u4F1A\u8A71\u304B\u3089\u30DC\u30ED\u3082\u51FA\u3066\u304F\u308B\u3051\u3069\u306D\u2606",
  "id" : 314684031226757120,
  "created_at" : "2013-03-21 10:24:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314683867871211521",
  "geo" : { },
  "id_str" : "314683942697590784",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u306F\u3044",
  "id" : 314683942697590784,
  "in_reply_to_status_id" : 314683867871211521,
  "created_at" : "2013-03-21 10:24:33 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314683682923360256",
  "geo" : { },
  "id_str" : "314683793028034560",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5B8C\u5168\u30AA\u30EA\u30B8\u30CA\u30EB\u3060\u305C\uFF57\uFF57\uFF57\uFF57\uFF57\u4ED6\u4EBA\u306E\u30EA\u30D7\u30E9\u30A4\u3068\u304B\u5168\u304F\u53C2\u8003\u306B\u305B\u305A\u306B\u8003\u3048\u305F\u304B\u3089\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 314683793028034560,
  "in_reply_to_status_id" : 314683682923360256,
  "created_at" : "2013-03-21 10:23:57 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314683694453518336",
  "text" : "\u53E3\u304B\u3089\u306A\u3093\u3067\u3082\u3067\u3053\u3053\u307E\u3067\u8A71\u984C\u304C\u5E83\u304C\u308B\u306E\u5272\u3068\u30B3\u30DF\u30E5\u529B\u3042\u308B\u306E\u3067\u306F",
  "id" : 314683694453518336,
  "created_at" : "2013-03-21 10:23:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314683529663508481",
  "text" : "\u306A\u3093\u3067\u3082\u306A\u3044\u3067\u3059",
  "id" : 314683529663508481,
  "created_at" : "2013-03-21 10:22:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314683520809312256",
  "text" : "\u30DE\u30C8\u30EA\u30E7\u30FC\u56DB\u89D2...",
  "id" : 314683520809312256,
  "created_at" : "2013-03-21 10:22:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314683287593435136",
  "text" : "\u3053\u308C\u306F\u8996\u899A\u306B\u554F\u984C\u304C\u3042\u308A\u307E\u3059\u306D\uFF1F",
  "id" : 314683287593435136,
  "created_at" : "2013-03-21 10:21:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314683150884282368",
  "text" : "\u56DB\u89D2\u306B\u898B\u3048\u3066\u304F\u308B\u3060\u308D\u3046",
  "id" : 314683150884282368,
  "created_at" : "2013-03-21 10:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314682964162256896",
  "geo" : { },
  "id_str" : "314683051223437312",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u53E3 in a \u53E3",
  "id" : 314683051223437312,
  "in_reply_to_status_id" : 314682964162256896,
  "created_at" : "2013-03-21 10:21:00 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314682659848740864",
  "text" : "\u3044\u3048\u30FC\u3044",
  "id" : 314682659848740864,
  "created_at" : "2013-03-21 10:19:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314682422950252545",
  "text" : "\u56DE\u308B\u308F\u3051\u3067\u3059\u306D",
  "id" : 314682422950252545,
  "created_at" : "2013-03-21 10:18:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314682372018814977",
  "text" : "\u53E3\u304B\u3089\u53E3\u304C\u51FA\u3066\u304F\u308B\uFF08\u518D\u5E30\uFF09",
  "id" : 314682372018814977,
  "created_at" : "2013-03-21 10:18:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314682241924079616",
  "text" : "\u308F\u304B\u308B\u30FC\u3046\u3051\u308B\u30FC\u795E\u30FC",
  "id" : 314682241924079616,
  "created_at" : "2013-03-21 10:17:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314682049673965568",
  "text" : "\u30BC\u30EA\u30FC\u3055\u3093\u8D85\u30A6\u30B1\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 314682049673965568,
  "created_at" : "2013-03-21 10:17:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314681625663401984",
  "text" : "22\u6642\u3067\u7DE0\u3081\u51FA\u3055\u308C\u308B\u98DB\u884C\u6A5F\u3067\u6765\u305F\u52E2\u3092\u4E2D\u304B\u3089\u5207\u306A\u3044\u76EE\u3067\u773A\u3081\u308B\u30AA\u30D5\u306B\u306A\u3063\u3061\u3083\u3046",
  "id" : 314681625663401984,
  "created_at" : "2013-03-21 10:15:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314681443152429056",
  "text" : "\u98DB\u884C\u6A5F\u3067\u6765\u3089\u308C\u3066\u308224\u6642\u9593\u81EA\u7FD2\u5BA4\u306F\u5B66\u5185\u751F\u3057\u304B\u5165\u308C\u306A\u3044\uFF57\uFF57\uFF57\uFF57\uFF57\u30A6\u30B1\u308B\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 314681443152429056,
  "created_at" : "2013-03-21 10:14:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314681142903181313",
  "text" : "\u305F\u304B\u3057\uFF57\uFF57\uFF57\uFF57\uFF57\u305F\u304B\u3057\u304CRT\u3057\u3066\u53C2\u52A0\u8005\u5897\u3048\u308B\u306E\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 314681142903181313,
  "created_at" : "2013-03-21 10:13:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314680851285807104",
  "text" : "\u3042\u308C\uFF0C24\u6642\u9593\u30AA\u30D5\u3059\u3063\u3052\u3047RT\u4F38\u3073\u3066\u308B\u306E\u306B\u53C2\u52A0\u8005\u5897\u3048\u3066\u306A\u3044\uFF57\uFF57\uFF57",
  "id" : 314680851285807104,
  "created_at" : "2013-03-21 10:12:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "314631984360091648",
  "text" : "\u72EC\u65AD\u3068\u504F\u898B\u306728\u65E5\u306B\u78BA\u5B9A\u3057\u307E\u3057\u305F\uFF01\uFF01\uFF01\u6765\u308C\u308B\u4EBA\u306F\u305C\u3072\uFF01\uFF01\uFF01[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 314631984360091648,
  "created_at" : "2013-03-21 06:58:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314628594053832706",
  "text" : "\u3068\u3044\u3046\u5177\u5408\u3067\u7720\u3044",
  "id" : 314628594053832706,
  "created_at" : "2013-03-21 06:44:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314628549367697408",
  "text" : "\u304A\u9858\u3044\u3001\u7720\u3089\u306A\u3044\u3067\u57CE\u4E4B\u5185\uFF01\u3042\u3093\u305F\u304C\u4ECA\u3053\u3053\u3067\u7720\u3063\u305F\u3089\u3001\u660E\u65E5\u306E\u5348\u524D\u306E\u30BC\u30DF\u306E\u7D04\u675F\u306F\u3069\u3046\u306A\u3063\u3061\u3083\u3046\u306E\uFF1F \u30AB\u30D5\u30A7\u30A4\u30F3\u306F\u307E\u3060\u6B8B\u3063\u3066\u308B\u3002\u3053\u3053\u3092\u8010\u3048\u308C\u3070\u3001\u5065\u5168\u306A\u751F\u6D3B\u30EA\u30BA\u30E0\u306B\u623B\u308C\u308B\u3093\u3060\u304B\u3089\uFF01\u6B21\u56DE\u300C\u57CE\u4E4B\u5185\u5BDD\u843D\u3061\u3059\uFF01\u300D",
  "id" : 314628549367697408,
  "created_at" : "2013-03-21 06:44:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314520423322755073",
  "text" : "\u30B9\u30B4\u30A4\u30FB\u30CD\u30E0\u30A4\uFF01",
  "id" : 314520423322755073,
  "created_at" : "2013-03-20 23:34:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "river4361",
      "screen_name" : "river4361",
      "indices" : [ 0, 10 ],
      "id_str" : "2526962401",
      "id" : 2526962401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314514727604727810",
  "geo" : { },
  "id_str" : "314518400388984833",
  "in_reply_to_user_id" : 320494295,
  "text" : "@river4361 \u8CFC\u8AAD(\u5F8C\u671F)\u3092\u53D6\u308A\u305D\u3073\u308C\u3066\u3044\u305F\u3082\u306E\u3067\u2026",
  "id" : 314518400388984833,
  "in_reply_to_status_id" : 314514727604727810,
  "created_at" : "2013-03-20 23:26:44 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "314434082643791872",
  "text" : "\u6848\u5916\u96C6\u307E\u3089\u306A\u3044[TwiPla] \u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 314434082643791872,
  "created_at" : "2013-03-20 17:51:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "314433919632154625",
  "text" : "[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 314433919632154625,
  "created_at" : "2013-03-20 17:51:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314408745612496896",
  "text" : "1\u6642\u306B\u306A\u3063\u305F\u3089\u5BDD\u3088\u3046\u3068\u545F\u3053\u3046\u3068\u601D\u3063\u305F\u3089\u3082\u3046\u904E\u304E\u3066\u305F\u3093\u3060\u306A\u3053\u308C\u304C",
  "id" : 314408745612496896,
  "created_at" : "2013-03-20 16:11:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3080",
      "screen_name" : "nemuko_ofuton",
      "indices" : [ 0, 14 ],
      "id_str" : "232433835",
      "id" : 232433835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314408075689857026",
  "geo" : { },
  "id_str" : "314408464229220353",
  "in_reply_to_user_id" : 232433835,
  "text" : "@nemuko_ofuton \u3044\u3048\u3044\u3048\u30FC\uFF0C\u307E\u305F\u4F55\u304B\u306E\u6A5F\u4F1A\u306B\u304A\u4F1A\u3044\u3057\u307E\u3057\u3087\u3046\uFF0E",
  "id" : 314408464229220353,
  "in_reply_to_status_id" : 314408075689857026,
  "created_at" : "2013-03-20 16:09:53 +0000",
  "in_reply_to_screen_name" : "nemuko_ofuton",
  "in_reply_to_user_id_str" : "232433835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314408376287252480",
  "text" : "\u8FD4\u4FE1\u5143\u3092\u307F\u308B\u3068\u7B11\u3063\u3066\u3057\u307E\u3046\uFF57\uFF57\uFF57\u305F\u3076\u3093TL\u306B\u6D6E\u4E0A\u3057\u3066\u3044\u305F\u306E\u3092\u898B\u3064\u3051\u3066\u304F\u3060\u3055\u3063\u4ED6\u306E\u3060\u3068\u601D\u3046\u3051\u308C\u3069\uFF0E",
  "id" : 314408376287252480,
  "created_at" : "2013-03-20 16:09:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3080",
      "screen_name" : "nemuko_ofuton",
      "indices" : [ 3, 17 ],
      "id_str" : "232433835",
      "id" : 232433835
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 19, 29 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314408214739423233",
  "text" : "RT @nemuko_ofuton: @end313124 \u9045\u304F\u306A\u308A\u307E\u3057\u305F\u304C\u3001\u3064\u3069\u3044\u3067\u306F\u8272\u3005\u5FA1\u52A9\u8A00\u9802\u3051\u3066\u3001\u3068\u3066\u3082\u52A9\u304B\u308A\u307E\u3057\u305F\uFF0A\n\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF0A\n\u307E\u305F\u304A\u4F1A\u3044\u3067\u304D\u308B\u306E\u3092\u697D\u3057\u307F\u306B\u3057\u3066\u3044\u307E\u3059\uFF0A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "314407649909284867",
    "geo" : { },
    "id_str" : "314408075689857026",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u9045\u304F\u306A\u308A\u307E\u3057\u305F\u304C\u3001\u3064\u3069\u3044\u3067\u306F\u8272\u3005\u5FA1\u52A9\u8A00\u9802\u3051\u3066\u3001\u3068\u3066\u3082\u52A9\u304B\u308A\u307E\u3057\u305F\uFF0A\n\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF0A\n\u307E\u305F\u304A\u4F1A\u3044\u3067\u304D\u308B\u306E\u3092\u697D\u3057\u307F\u306B\u3057\u3066\u3044\u307E\u3059\uFF0A",
    "id" : 314408075689857026,
    "in_reply_to_status_id" : 314407649909284867,
    "created_at" : "2013-03-20 16:08:21 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u307E\u3080",
      "screen_name" : "nemuko_ofuton",
      "protected" : false,
      "id_str" : "232433835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3488092523\/4d30d148a8112c01a5564a4e28321573_normal.jpeg",
      "id" : 232433835,
      "verified" : false
    }
  },
  "id" : 314408214739423233,
  "created_at" : "2013-03-20 16:08:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314407649909284867",
  "text" : "\u3046\u308F\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u8D77\u304D\u3089\u308C\u306A\u3044\u3044\u3044\u3043\u3043\u3044\u3043\u3043\u3043\u3043\uFF58",
  "id" : 314407649909284867,
  "created_at" : "2013-03-20 16:06:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314407605047021568",
  "text" : "\u5F8C\u671F\u6C34\u66DC\u306B\u4E00\u9650\u304C\u3042\u308B\u3053\u3068\u304C\u78BA\u5B9A",
  "id" : 314407605047021568,
  "created_at" : "2013-03-20 16:06:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314405362868576259",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u826F\u304F\u898B\u305F\u3089\uFF12\uFF17\u307E\u3067\u3060\u3063\u305F\u306E\u3067\u6025\u304C\u306A\u304F\u3066\u304A\u3063\u3051\u30FC\uFF0C\u5225\u306E\u672C\u3068\u52D8\u9055\u3044\u3057\u3066\u3044\u305F\uFF0C",
  "id" : 314405362868576259,
  "created_at" : "2013-03-20 15:57:34 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314404845853503489",
  "text" : "\u3069\u3046\u308264\u95A2\u9023\u306E\u30B2\u30FC\u30E0\u306F\u3084\u305F\u3089\u3081\u3063\u305F\u3089\u8A73\u7D30\u306B\u308F\u305F\u3063\u3066\u899A\u3048\u3066\u3044\u308B\u306A\u3041",
  "id" : 314404845853503489,
  "created_at" : "2013-03-20 15:55:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314339060019765249",
  "text" : "\u548C\u88C5\u63C3\u3048\u308B\u904A\u3073(^^)(^^)(^^)",
  "id" : 314339060019765249,
  "created_at" : "2013-03-20 11:34:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314338265085915136",
  "text" : "\u9662\u9032\u51FA\u6765\u305F\u3089\u304A\u795D\u3044\u306B\u6B32\u3057\u3044\u306A[\u548C\u670D]",
  "id" : 314338265085915136,
  "created_at" : "2013-03-20 11:30:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314337687895171073",
  "geo" : { },
  "id_str" : "314337932041404417",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5727\u5012\u7684\u7406\u89E3[3\u4E07\u30A7\u30A7\u30A7]",
  "id" : 314337932041404417,
  "in_reply_to_status_id" : 314337687895171073,
  "created_at" : "2013-03-20 11:29:37 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314337807772577793",
  "text" : "\u548C\u670D\u7740\u3066\u300C\u7D76\u671B\u3057\u305F\u30C3\uFF01\u300D\u3063\u3066\u8A00\u3044\u305F\u3044[\u305D\u308C\u3060\u3051\u3058\u3083\u306A\u3044\u3051\u3069]",
  "id" : 314337807772577793,
  "created_at" : "2013-03-20 11:29:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314336578346549248",
  "geo" : { },
  "id_str" : "314337191734169600",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5206\u304B\u3063\u305F\u3089\u6559\u3048\u3066\u6B32\u3057\u3044",
  "id" : 314337191734169600,
  "in_reply_to_status_id" : 314336578346549248,
  "created_at" : "2013-03-20 11:26:41 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314226533441089538",
  "geo" : { },
  "id_str" : "314226856817741824",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u5DDD\u304C\u4E8C\u80A1\u306B\u5225\u308C\u305F\u3068\u3053\u308D\u306E\u897F\u5074\u306B\u3044\u307E\u3059\u306D\u30FC",
  "id" : 314226856817741824,
  "in_reply_to_status_id" : 314226533441089538,
  "created_at" : "2013-03-20 04:08:15 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314225541026832384",
  "geo" : { },
  "id_str" : "314226087129407488",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u3061\u306A\u307F\u306B\u5DDD\u306E\u897F\u3068\u6771\u3069\u3063\u3061\u6B69\u3044\u3066\u308B\uFF1F[\u5DDD\u4E0A\u304C\u5317]",
  "id" : 314226087129407488,
  "in_reply_to_status_id" : 314225541026832384,
  "created_at" : "2013-03-20 04:05:11 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314224494187274243",
  "geo" : { },
  "id_str" : "314224662022348800",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u4E8C\u80A1\u306B\u5225\u308C\u308B\u3068\u3053\u308D\u304C\u3042\u308B\u304B\u3089\u305D\u3057\u305F\u3089\u4E0A\u304C\u308B\u3079\u3057",
  "id" : 314224662022348800,
  "in_reply_to_status_id" : 314224494187274243,
  "created_at" : "2013-03-20 03:59:32 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314214193756786688",
  "geo" : { },
  "id_str" : "314224390843805697",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u51FA\u753A\u67F3\u3042\u305F\u308A\u7740\u3044\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u304F\u3060\u3055\u3044\u30FC",
  "id" : 314224390843805697,
  "in_reply_to_status_id" : 314214193756786688,
  "created_at" : "2013-03-20 03:58:27 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314216937095852033",
  "geo" : { },
  "id_str" : "314217948816502785",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3042\u3044\u3066\u308B\u3088\u3046\u3067\u3059",
  "id" : 314217948816502785,
  "in_reply_to_status_id" : 314216937095852033,
  "created_at" : "2013-03-20 03:32:51 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314215875718832129",
  "text" : "13\u6642\u304F\u3089\u3044\u306B\u30E2\u30EB\u30D5\u30A3\u30FC\u541B\u3068\u51FA\u753A\u738B\u5C06\u884C\u304F\u306E\u3067\u6765\u305F\u3044\u4EBA\u3044\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u304F\u3060\u3055\u3044\u306A",
  "id" : 314215875718832129,
  "created_at" : "2013-03-20 03:24:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314214193756786688",
  "geo" : { },
  "id_str" : "314214299553902592",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u304A\u3063\u3051\u30FC",
  "id" : 314214299553902592,
  "in_reply_to_status_id" : 314214193756786688,
  "created_at" : "2013-03-20 03:18:21 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314212746046607361",
  "geo" : { },
  "id_str" : "314213143691808768",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u884C\u304F\u30FC(\u304A\u304D\u305F)",
  "id" : 314213143691808768,
  "in_reply_to_status_id" : 314212746046607361,
  "created_at" : "2013-03-20 03:13:45 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/FHaIiBfNWb",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=f_shuzen",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314194166534000640",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/FHaIiBfNWb",
  "id" : 314194166534000640,
  "created_at" : "2013-03-20 01:58:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314077351443038208",
  "text" : "BGM\u306F\u30A8\u30F3\u30B8\u30F3\u97F3\u3067\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 314077351443038208,
  "created_at" : "2013-03-19 18:14:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314076957681803264",
  "text" : "\u300C\u3053\u306E\u756A\u7D44\u7D42\u4E86\u5F8C20\u5206\u306B\u9650\u308A\uFF0C\u30D0\u30CA\u30C3\u30CF\u30BF\u30EB\u30B9\u30AD\u306E\u5B9A\u7406\u3067\u30AA\u30DA\u30EC\u30FC\u30BF\u30FC\u3092\u5897\u3084\u3057\u3066\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059\uFF01\u300D \uFF3B\u30D0\u30CA\u30C3\u30CF\u30BF\u30EB\u30B9\u30AD\u3042\u3093\u307E\u308AAC\u95A2\u4FC2\u306A\u3044\u3063\u3066\u53F1\u3089\u308C\u305F\uFF08?\uFF09\u3070\u3063\u304B\u308A\uFF3D",
  "id" : 314076957681803264,
  "created_at" : "2013-03-19 18:12:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314076332394954752",
  "geo" : { },
  "id_str" : "314076522078146561",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u300C\u305D\u3093\u306A\u306E\uFF0C\u3053\u306E\u30B5\u30A4\u30C8\u300E\u58F1\u5927\u6574\u57DF\u300F\u3092\u898B\u308C\u3070\u7C21\u5358\u3055\u30C3\uFF01\u300D\u307F\u305F\u3044\u306A",
  "id" : 314076522078146561,
  "in_reply_to_status_id" : 314076332394954752,
  "created_at" : "2013-03-19 18:10:52 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314076305475907585",
  "text" : "\u300C\u9078\u629E\u516C\u7406\u3092\u8A8D\u3081\u307E\u3059\u304B\uFF1F\u300D\u307F\u305F\u3044\u306A\u8857\u982D\u30A2\u30F3\u30B1\u30FC\u30C8\u3068\u304B\u3084\u3063\u3066\u307B\u3057\u3044",
  "id" : 314076305475907585,
  "created_at" : "2013-03-19 18:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314076122977558528",
  "text" : "\u540C\u5024\u306A\u547D\u984C\u7F85\u5217\u3057\u3066\u300C\u306A\u3093\u3068\u3053\u3061\u3089\u3059\u3079\u3066\uFF0C\u9078\u629E\u516C\u7406\u3068\u540C\u5024\u306A\u547D\u984C\u306A\u3093\u3067\u3059\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\u300D\u307F\u305F\u3044\u306A",
  "id" : 314076122977558528,
  "created_at" : "2013-03-19 18:09:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314075911211327488",
  "text" : "\u30A2\u30EB\u30B4\u30C9\u30A5\u30FC\u3055\u3093\u306B\u300C\u6DF1\u591C\u306E\u901A\u8CA9\u756A\u7D44\u307F\u305F\u3044\u306A\u30CE\u30EA\u306E\u9078\u629E\u516C\u7406\u306ECM\u4F5C\u3063\u3066\u304F\u3060\u3055\u3044\u3088\u30FC\u300D\u3063\u3066\u8A00\u3046\u306E\u5FD8\u308C\u3066\u305F\uFF0E",
  "id" : 314075911211327488,
  "created_at" : "2013-03-19 18:08:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314075710039928833",
  "text" : "\u5C31\u8077\u3092\u7406\u7531\u306B\u597D\u304D\u306A\u3053\u3068\u3092\u3084\u3081\u305F\u304F\u306F\u306A\u3044\u3082\u306E\u306D",
  "id" : 314075710039928833,
  "created_at" : "2013-03-19 18:07:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314075654498967552",
  "text" : "\u30A2\u30EB\u30B4\u30C9\u30A5\u30FC\u3055\u3093\u521D\u3081\u793E\u4F1A\u4EBA\u306B\u306A\u3063\u3066\u304B\u3089\u3082\u6570\u5B66\u3084\u3063\u3066\u308B\u4EBA\u306E\u5B58\u5728\u306F\u3068\u3063\u3066\u3082\u3042\u308A\u304C\u305F\u3044",
  "id" : 314075654498967552,
  "created_at" : "2013-03-19 18:07:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u308F\u305A",
      "screen_name" : "kawazu1147",
      "indices" : [ 3, 14 ],
      "id_str" : "111624231",
      "id" : 111624231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314075451654021120",
  "text" : "RT @kawazu1147: \u307E\u3060\u3064\u3069\u3044\u306E\u30A2\u30EC\u66F8\u304D\u7D42\u308F\u3063\u3066\u306A\u3044\u3051\u3069\u3001\u4E00\u756A\u8A00\u3044\u305F\u3044\u3053\u3068\u306F\u30A2\u30EC\u3067\u3059\u3088\u3002\u4FFA\u304C\u30A4\u30B1\u30E1\u30F3\u3068\u304B\u30C1\u30E4\u30DB\u30E4\u3055\u308C\u3066\u826F\u304B\u3063\u305F\u3068\u304B\u3044\u3046\u3069\u3046\u3067\u3082\u3044\u3044\u3053\u3068\u3058\u3083\u306A\u304F\u3066\u3001\u5C11\u3057\u305A\u3064\u3057\u304B\u3067\u304D\u306A\u304F\u3066\u3082\u6570\u5B66\u7D9A\u3051\u3088\u3046\u3068\u601D\u3063\u305F\u3068\u3044\u3046\u3053\u3068\u3067\u3059\u3088\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314075388445872128",
    "text" : "\u307E\u3060\u3064\u3069\u3044\u306E\u30A2\u30EC\u66F8\u304D\u7D42\u308F\u3063\u3066\u306A\u3044\u3051\u3069\u3001\u4E00\u756A\u8A00\u3044\u305F\u3044\u3053\u3068\u306F\u30A2\u30EC\u3067\u3059\u3088\u3002\u4FFA\u304C\u30A4\u30B1\u30E1\u30F3\u3068\u304B\u30C1\u30E4\u30DB\u30E4\u3055\u308C\u3066\u826F\u304B\u3063\u305F\u3068\u304B\u3044\u3046\u3069\u3046\u3067\u3082\u3044\u3044\u3053\u3068\u3058\u3083\u306A\u304F\u3066\u3001\u5C11\u3057\u305A\u3064\u3057\u304B\u3067\u304D\u306A\u304F\u3066\u3082\u6570\u5B66\u7D9A\u3051\u3088\u3046\u3068\u601D\u3063\u305F\u3068\u3044\u3046\u3053\u3068\u3067\u3059\u3088\u3002",
    "id" : 314075388445872128,
    "created_at" : "2013-03-19 18:06:22 +0000",
    "user" : {
      "name" : "\u304B\u308F\u305A",
      "screen_name" : "kawazu1147",
      "protected" : false,
      "id_str" : "111624231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1546733080\/twitterprofile5_normal.jpg",
      "id" : 111624231,
      "verified" : false
    }
  },
  "id" : 314075451654021120,
  "created_at" : "2013-03-19 18:06:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314074283305467905",
  "text" : "\u4E0D\u6442\u751F\u3068\u8A00\u3046\u304B\u30B3\u30F3\u30D3\u30CB\u3068\u304B\u30D5\u30A1\u30B9\u30C8\u30D5\u30FC\u30C9\u3070\u3063\u304B\u308A\u98DF\u3079\u3066\u308B\u3068\u3059\u3050\u306B\u3067\u304D\u3082\u306E\u51FA\u6765\u308B\u304B\u3089\u306A\u3093\u3068\u3044\u3046\u304B\u3068\u3066\u3082\u7D20\u76F4\u306A\u4F53\u3092\u3057\u3066\u3044\u308B\uFF0E",
  "id" : 314074283305467905,
  "created_at" : "2013-03-19 18:01:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314072788715573248",
  "text" : "\u4E45\u3005\u306BTween\u958B\u3044\u305F",
  "id" : 314072788715573248,
  "created_at" : "2013-03-19 17:56:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314070961978744832",
  "text" : "\u30DB\u30C3\u30C8\u30B3\u30B3\u30A2\u98F2\u3093\u3067\u308B\u3002\u30A2\u30EB\u30B3\u30FC\u30EB\u306F\u629C\u3051\u305F\u3002",
  "id" : 314070961978744832,
  "created_at" : "2013-03-19 17:48:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314062417439113216",
  "geo" : { },
  "id_str" : "314067319930380288",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u9023\u65E5\u306E\u3064\u3069\u3044\u3068\u305D\u306E\u5EF6\u9577\u6226\u3067\u91D1\u6B20\u3067\u3059\u305E\u301C",
  "id" : 314067319930380288,
  "in_reply_to_status_id" : 314062417439113216,
  "created_at" : "2013-03-19 17:34:18 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314049657108049920",
  "text" : "\u3044\u3084\u3001\u3069\u3053\u3067\u4F55\u3092\u8A00\u304A\u3046\u3068\u305D\u306E\u4EBA\u306F\u305D\u306E\u4EBA\u306A\u306E\u3067\u3059\u3088",
  "id" : 314049657108049920,
  "created_at" : "2013-03-19 16:24:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314049111903072256",
  "geo" : { },
  "id_str" : "314049442296778753",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u597D\u304D\u306B\u4F7F\u3048\u3070\u826F\u3044\u3093\u3067\u3059\u3088\u30FC",
  "id" : 314049442296778753,
  "in_reply_to_status_id" : 314049111903072256,
  "created_at" : "2013-03-19 16:23:16 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314049103921291266",
  "geo" : { },
  "id_str" : "314049381852663808",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u81EA\u7136\u306B\u8A00\u3044\u307E\u3059\u3088\u306D\u3001\u5727\u5012\u7684\u30B0\u30EC\u30A4\u30C8[\u50D5\u3082\u8A00\u308F\u308C\u305F]",
  "id" : 314049381852663808,
  "in_reply_to_status_id" : 314049103921291266,
  "created_at" : "2013-03-19 16:23:02 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314047612808482818",
  "geo" : { },
  "id_str" : "314048900510134272",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u66F8\u3051\u3070\u3044\u3044\u3068\u601D\u3046\u3088\uFF01",
  "id" : 314048900510134272,
  "in_reply_to_status_id" : 314047612808482818,
  "created_at" : "2013-03-19 16:21:07 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314044343503691776",
  "geo" : { },
  "id_str" : "314048084013375489",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u6642\u9593\u5E2F\u306B\u3088\u3063\u3066\u306F\u884C\u304F\u304B\u3089\u30EA\u30D7\u304F\u3060\u3055\u308C\u301C",
  "id" : 314048084013375489,
  "in_reply_to_status_id" : 314044343503691776,
  "created_at" : "2013-03-19 16:17:52 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 3, 14 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314044173890228226",
  "text" : "RT @noukoknows: \u30A8\u30B4\uFF32\uFF34\u306F\u30C0\u30E1\u307F\u305F\u3044\u306A\u306E\u3001\u8912\u3081\u3089\u308C\u3066\u3082\u300C\u3044\u3048\u3044\u3048\u305D\u3093\u306A\u3053\u3068\u306A\u3044\u3067\u3059\u300D\u3068\u304B\u8A00\u3046\u306E\u3068\u4E00\u7DD2\u3067\u975E\u5E38\u306B\u65E5\u672C\u4EBA\u3063\u307D\u3044\u8003\u3048\u306A\u6C17\u304C\u3059\u308B\u3057\u975E\u5E38\u306B\u3081\u3093\u3069\u304F\u3055\u3044\u3002\u3079\u3064\u306B\u300C\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u300D\u3067\u3044\u3044\u3068\u601D\u3046\u3002\u30A2\u30E1\u30EA\u30AB\u4EBA\u306A\u3089\u8912\u3081\u3089\u308C\u305F\u3089\u5927\u62B5\u306E\u5834\u5408\u304D\u3063\u3068\u5B09\u3057\u305D\u3046\u306B\"T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314043990313951233",
    "text" : "\u30A8\u30B4\uFF32\uFF34\u306F\u30C0\u30E1\u307F\u305F\u3044\u306A\u306E\u3001\u8912\u3081\u3089\u308C\u3066\u3082\u300C\u3044\u3048\u3044\u3048\u305D\u3093\u306A\u3053\u3068\u306A\u3044\u3067\u3059\u300D\u3068\u304B\u8A00\u3046\u306E\u3068\u4E00\u7DD2\u3067\u975E\u5E38\u306B\u65E5\u672C\u4EBA\u3063\u307D\u3044\u8003\u3048\u306A\u6C17\u304C\u3059\u308B\u3057\u975E\u5E38\u306B\u3081\u3093\u3069\u304F\u3055\u3044\u3002\u3079\u3064\u306B\u300C\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u300D\u3067\u3044\u3044\u3068\u601D\u3046\u3002\u30A2\u30E1\u30EA\u30AB\u4EBA\u306A\u3089\u8912\u3081\u3089\u308C\u305F\u3089\u5927\u62B5\u306E\u5834\u5408\u304D\u3063\u3068\u5B09\u3057\u305D\u3046\u306B\"Thanks\"\u3063\u3066\u8A00\u3046\u3002",
    "id" : 314043990313951233,
    "created_at" : "2013-03-19 16:01:36 +0000",
    "user" : {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "protected" : true,
      "id_str" : "348990022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000720729836\/990edaf9c5011972665a60414d8f2569_normal.png",
      "id" : 348990022,
      "verified" : false
    }
  },
  "id" : 314044173890228226,
  "created_at" : "2013-03-19 16:02:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314043960022691841",
  "geo" : { },
  "id_str" : "314044123130781696",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u30A4\u30A8\u30B9\uFF01[\u5165\u9580\u3067\u3059\u3051\u3069]",
  "id" : 314044123130781696,
  "in_reply_to_status_id" : 314043960022691841,
  "created_at" : "2013-03-19 16:02:08 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314043979840770048",
  "text" : "\u51FA\u753A\u738B\u5C06\u306F\u738B\u5C06\u306B\u3057\u3066\u738B\u5C06\u306B\u3042\u3089\u305A",
  "id" : 314043979840770048,
  "created_at" : "2013-03-19 16:01:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314043434233106432",
  "geo" : { },
  "id_str" : "314043790526648320",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u51FA\u753A\u307E\u3067\u6765\u308B\u306A\u3089\u51FA\u753A\u738B\u5C06\u30AA\u30B9\u30B9\u30E1\uFF01\uFF01",
  "id" : 314043790526648320,
  "in_reply_to_status_id" : 314043434233106432,
  "created_at" : "2013-03-19 16:00:48 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u305A\u3042\u305A",
      "screen_name" : "azuazut",
      "indices" : [ 0, 8 ],
      "id_str" : "294104006",
      "id" : 294104006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314040597461741568",
  "geo" : { },
  "id_str" : "314041898560004096",
  "in_reply_to_user_id" : 294104006,
  "text" : "@azuazut \u5927\u624B\u3092\u632F\u3063\u3066\u5973\u5B50\u5927\u3092\u8A2A\u308C\u308B\u6A5F\u4F1A\u306F\u57FA\u672C\u7121\u3044\u306E\u3067(^^)(^^)(^^)",
  "id" : 314041898560004096,
  "in_reply_to_status_id" : 314040597461741568,
  "created_at" : "2013-03-19 15:53:17 +0000",
  "in_reply_to_screen_name" : "azuazut",
  "in_reply_to_user_id_str" : "294104006",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 3, 14 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314040862713729026",
  "text" : "RT @noukoknows: \u819D\u683C\u30F3\u3000\uFF08\u3072\u3056\u304B\u3063\u304F\u3093\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314040817851461633",
    "text" : "\u819D\u683C\u30F3\u3000\uFF08\u3072\u3056\u304B\u3063\u304F\u3093\uFF09",
    "id" : 314040817851461633,
    "created_at" : "2013-03-19 15:49:00 +0000",
    "user" : {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "protected" : true,
      "id_str" : "348990022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000720729836\/990edaf9c5011972665a60414d8f2569_normal.png",
      "id" : 348990022,
      "verified" : false
    }
  },
  "id" : 314040862713729026,
  "created_at" : "2013-03-19 15:49:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314040637517361154",
  "text" : "\u6614\u306F\u79C1\u3082\u304A\u524D\u306E\u3088\u3046\u306A\u30E9\u30C6\u30F3\u8A9E\u5B66\u7FD2\u8005\u3060\u3063\u305F\u306E\u3060\u304C\u3001\u819D\u306B\u683C\u5909\u5316\u306E\u77E2\u3092\u53D7\u3051\u3066\u3057\u307E\u3063\u3066\u306A\u2026",
  "id" : 314040637517361154,
  "created_at" : "2013-03-19 15:48:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314040413201768449",
  "text" : "\u50D5\u306F\u30E9\u30C6\u30F3\u8A9E\u3068\u306F\u306F\u3050\u308C\u3066\u3057\u307E\u3063\u305F\u306E\u3067\u2026",
  "id" : 314040413201768449,
  "created_at" : "2013-03-19 15:47:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u305A\u3042\u305A",
      "screen_name" : "azuazut",
      "indices" : [ 0, 8 ],
      "id_str" : "294104006",
      "id" : 294104006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314039996204077057",
  "geo" : { },
  "id_str" : "314040309740888064",
  "in_reply_to_user_id" : 294104006,
  "text" : "@azuazut \u4EBA\u304C\u96C6\u307E\u308A\u3059\u304E\u308B\u4E88\u611F(^^)(^^)(^^)",
  "id" : 314040309740888064,
  "in_reply_to_status_id" : 314039996204077057,
  "created_at" : "2013-03-19 15:46:59 +0000",
  "in_reply_to_screen_name" : "azuazut",
  "in_reply_to_user_id_str" : "294104006",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30EB\u30D5\u30A3\u30FC",
      "screen_name" : "Morphy_x",
      "indices" : [ 0, 9 ],
      "id_str" : "386896389",
      "id" : 386896389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314039964612579328",
  "geo" : { },
  "id_str" : "314040082434781184",
  "in_reply_to_user_id" : 386896389,
  "text" : "@Morphy_x \u304A\u75B2\u308C\u69D8\uFF01\u4F53\u8ABF\u304A\u5927\u4E8B\u306B\uFF01",
  "id" : 314040082434781184,
  "in_reply_to_status_id" : 314039964612579328,
  "created_at" : "2013-03-19 15:46:04 +0000",
  "in_reply_to_screen_name" : "Morphy_x",
  "in_reply_to_user_id_str" : "386896389",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    }, {
      "name" : "\u306D\u3080\u308ABABEL",
      "screen_name" : "CKPOMHOCTb",
      "indices" : [ 12, 23 ],
      "id_str" : "190136474",
      "id" : 190136474
    }, {
      "name" : "\u306D\u3053",
      "screen_name" : "integmath",
      "indices" : [ 24, 34 ],
      "id_str" : "2299389582",
      "id" : 2299389582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314039672575770624",
  "geo" : { },
  "id_str" : "314039986376830976",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows @CKPOMHOCTb @integmath \u30E9\u30C6\u30F3\u8A9E\u306E\u8F9E\u66F8\u5B8C\u5168\u306B\u672C\u68DA\u306E\u80A5\u3084\u3057\u306B\u306A\u3063\u3066\u308B\u306E\u3067\u8AB0\u304B\u5B89\u304F\u8CB7\u3044\u53D6\u308B\u304B\u4F55\u304B\u6570\u5B66\u66F8\u3068\u4EA4\u63DB\u3057\u3066\u6B32\u3057\u3044\u3067\u3059",
  "id" : 314039986376830976,
  "in_reply_to_status_id" : 314039672575770624,
  "created_at" : "2013-03-19 15:45:41 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u305A\u3042\u305A",
      "screen_name" : "azuazut",
      "indices" : [ 0, 8 ],
      "id_str" : "294104006",
      "id" : 294104006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314038504944447489",
  "geo" : { },
  "id_str" : "314039686656045056",
  "in_reply_to_user_id" : 294104006,
  "text" : "@azuazut \u6211\u3005\u304C\u5948\u826F\u306B\u51FA\u5411\u304F\u306E\u3082\u4E00\u8208\u3067\u3059\u3002",
  "id" : 314039686656045056,
  "in_reply_to_status_id" : 314038504944447489,
  "created_at" : "2013-03-19 15:44:30 +0000",
  "in_reply_to_screen_name" : "azuazut",
  "in_reply_to_user_id_str" : "294104006",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314039454811684864",
  "text" : "\u3068\u3066\u3082\u5FC3\u5730\u3088\u3044\u6DBC\u3057\u3055\u3067\u3042\u308B\u3002\u6563\u6B69\u306B\u306F\u6700\u9AD8\u3002",
  "id" : 314039454811684864,
  "created_at" : "2013-03-19 15:43:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314039349681471488",
  "text" : "\u4E11\u4E09\u3064\u30A2\u30EF\u30FC\u3060\u304C\u3001\u4E0B\u9D28\u795E\u793E\u3092\u6B69\u304F\u904A\u3073",
  "id" : 314039349681471488,
  "created_at" : "2013-03-19 15:43:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314039278021771266",
  "text" : "\u3044\u3084\u306F\u3084\u3001\u3053\u306E\u56DB\u65E5\u9593\u5922\u306E\u3088\u3046\u306B\u697D\u3057\u304B\u3063\u305F\uFF01",
  "id" : 314039278021771266,
  "created_at" : "2013-03-19 15:42:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u305A\u3042\u305A",
      "screen_name" : "azuazut",
      "indices" : [ 0, 8 ],
      "id_str" : "294104006",
      "id" : 294104006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314037773243912193",
  "geo" : { },
  "id_str" : "314037984989151233",
  "in_reply_to_user_id" : 294104006,
  "text" : "@azuazut \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF01\u307E\u305F\u4F55\u304B\u306E\u6A5F\u4F1A\u306B\u3054\u98EF\u3067\u3082\u98DF\u3079\u306B\u884C\u304D\u307E\u3057\u3087\u3046\u3002\u306F\u3044\u3001\u6B21\u304C\u51FA\u753A\u67F3\u3067\u3059\u30FC\u3002",
  "id" : 314037984989151233,
  "in_reply_to_status_id" : 314037773243912193,
  "created_at" : "2013-03-19 15:37:44 +0000",
  "in_reply_to_screen_name" : "azuazut",
  "in_reply_to_user_id_str" : "294104006",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314036999772315648",
  "text" : "\u99D2\u5834\u306E\u795E\u30CA\u30C1\u30E5\u30E9\u30EB\u306B\u3084\u3070\u3044",
  "id" : 314036999772315648,
  "created_at" : "2013-03-19 15:33:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314036955149115392",
  "text" : "RT @the_TQFT: \u67D0\u5F8C\u8F29(\u99D2\u5834\u306E\u795E)\u304C\u80C3\u85AC\u3092\u98F2\u3093\u3067\u3001\u300C\u3046\u3081\u3047\u3001\u6C34\u9178\u5316\u30DE\u30B0\u30CD\u30B7\u30A6\u30E0\u306E\u5473\u304C\u3059\u308B\u300D\u3068\u304B\u8A00\u3063\u3066\u3044\u308B\u306E\u3092\u805E\u3044\u3066\u5439\u304D\u305D\u3046\u306B\u306A\u3063\u305Fwwwwwwwww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314034929598091265",
    "text" : "\u67D0\u5F8C\u8F29(\u99D2\u5834\u306E\u795E)\u304C\u80C3\u85AC\u3092\u98F2\u3093\u3067\u3001\u300C\u3046\u3081\u3047\u3001\u6C34\u9178\u5316\u30DE\u30B0\u30CD\u30B7\u30A6\u30E0\u306E\u5473\u304C\u3059\u308B\u300D\u3068\u304B\u8A00\u3063\u3066\u3044\u308B\u306E\u3092\u805E\u3044\u3066\u5439\u304D\u305D\u3046\u306B\u306A\u3063\u305Fwwwwwwwww",
    "id" : 314034929598091265,
    "created_at" : "2013-03-19 15:25:36 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 314036955149115392,
  "created_at" : "2013-03-19 15:33:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314036800630972416",
  "text" : "\u5225\u308C\u306E\u5B63\u7BC0\u306A\u3093\u3060\u306A\u3041\u2026\u3055\u307F\u3057\u3044\u3084\u3089\u305B\u3064\u306A\u3044\u3084\u3089",
  "id" : 314036800630972416,
  "created_at" : "2013-03-19 15:33:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314006159491219456",
  "geo" : { },
  "id_str" : "314006993352392705",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kiu_uit \u3067\u3082\u697D\u3057\u3044\u306E\u3067\u3084\u308A\u307E\u3057\u3087\u3046\uFF01",
  "id" : 314006993352392705,
  "in_reply_to_status_id" : 314006159491219456,
  "created_at" : "2013-03-19 13:34:35 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314005681239904256",
  "geo" : { },
  "id_str" : "314005886450405376",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kiu_uit \u5177\u4F53\u4F8B\u77E5\u3089\u306A\u3044\u3068\u3057\u3093\u3069\u3044\u3067\u3059\u306D\u3047",
  "id" : 314005886450405376,
  "in_reply_to_status_id" : 314005681239904256,
  "created_at" : "2013-03-19 13:30:11 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313983305483702272",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 313983305483702272,
  "created_at" : "2013-03-19 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313913359034626048",
  "text" : "\u8ECA\u638C\u306F\u5B87\u91CE\u3055\u3093",
  "id" : 313913359034626048,
  "created_at" : "2013-03-19 07:22:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313913111792988160",
  "text" : "\u610F\u5473\u306E\u306A\u3044\u8A00\u8449",
  "id" : 313913111792988160,
  "created_at" : "2013-03-19 07:21:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313912808616116224",
  "text" : "\u8A00\u3063\u3066\u898B\u305F\u3060\u3051\u3067\u3059",
  "id" : 313912808616116224,
  "created_at" : "2013-03-19 07:20:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313912770414403584",
  "text" : "\u672B\u6458\u82B1",
  "id" : 313912770414403584,
  "created_at" : "2013-03-19 07:20:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313896348707586049",
  "text" : "\u3068\u307D\u307D\u301C",
  "id" : 313896348707586049,
  "created_at" : "2013-03-19 06:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313895367773151232",
  "text" : "\u306C\u306C\u306C\u306C\u30FC\u3093",
  "id" : 313895367773151232,
  "created_at" : "2013-03-19 06:11:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313895269806772224",
  "text" : "\u30B3\u30DF\u30CB\u30B1\u30B7\u30E7\u30F3\u3068\u306F\u304B\u304F\u3082\u3046\u307E\u304F\u3044\u304B\u306A\u3044\u3082\u306E\u304B",
  "id" : 313895269806772224,
  "created_at" : "2013-03-19 06:10:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 3, 14 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313895078538137600",
  "text" : "RT @Maleic1618: 3\u6B21\u5143\u306F\u751F\u304D\u308B\u306E\u306B\u4E0D\u4FBF\u904E\u304E\u308B\u3002C^2\u3068\u304B\u304C\u898B\u3048\u308B\u3088\u3046\u306A4\u6B21\u5143\u306B\u751F\u304D\u305F\u304B\u3063\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/shootingstar067.com\/\" rel=\"nofollow\"\u003EShootingStar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313892970803896321",
    "text" : "3\u6B21\u5143\u306F\u751F\u304D\u308B\u306E\u306B\u4E0D\u4FBF\u904E\u304E\u308B\u3002C^2\u3068\u304B\u304C\u898B\u3048\u308B\u3088\u3046\u306A4\u6B21\u5143\u306B\u751F\u304D\u305F\u304B\u3063\u305F\u3002",
    "id" : 313892970803896321,
    "created_at" : "2013-03-19 06:01:30 +0000",
    "user" : {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "protected" : true,
      "id_str" : "520458209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3586149917\/79a30ec1ce8c9452c9e4aecbcd434c16_normal.png",
      "id" : 520458209,
      "verified" : false
    }
  },
  "id" : 313895078538137600,
  "created_at" : "2013-03-19 06:09:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313893121719169024",
  "text" : "\u9045\u523B\u306F\u30B9\u30B4\u30A4\u30FB\u30B7\u30C4\u30EC\u30A4\uFF01",
  "id" : 313893121719169024,
  "created_at" : "2013-03-19 06:02:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313893062260686848",
  "text" : "\u4E00\u6642\u9593\u3067\u884C\u304F\u3063\u3066iPhone\u304C\u8A00\u3046\u304B\u3089\u4E00\u6642\u9593\u3067\u3044\u3051\u308B\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\u3067\u52D5\u3044\u305F\u308990\u5206\u307B\u3069\u639B\u304B\u308B\u6A21\u69D8",
  "id" : 313893062260686848,
  "created_at" : "2013-03-19 06:01:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313726487176040448",
  "text" : "\u3064\u3069\u30443\u301C4\u65E5\u76EE\u697D\u3057\u304B\u3063\u305F\uFF01\u5149\u3092\u6D74\u3073\u305F\uFF01",
  "id" : 313726487176040448,
  "created_at" : "2013-03-18 18:59:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313559026040455168",
  "text" : "\u304A\u3068\u306A\u3057\u304F\u5225\u306E\u52C9\u5F37\u3059\u308B\u307E\u3059",
  "id" : 313559026040455168,
  "created_at" : "2013-03-18 07:54:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313558948106080256",
  "text" : "\u3066\u3075\u3066\u3075\u3057\u3088\u3046\u3068\u601D\u3063\u3066\u304D\u305F\u304C\u30CE\u30FC\u30D1\u30BD\u5145\u96FB\u306A\u304F\u3066\u7D76\u671B",
  "id" : 313558948106080256,
  "created_at" : "2013-03-18 07:54:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313527064726745088",
  "text" : "\u9F3B\u304C\u7D76\u4E0D\u8ABF",
  "id" : 313527064726745088,
  "created_at" : "2013-03-18 05:47:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    }, {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 13, 21 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313373477342154752",
  "geo" : { },
  "id_str" : "313373734243278849",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella @shigmax \u307E\u304B\u305B\u308D\u30FC",
  "id" : 313373734243278849,
  "in_reply_to_status_id" : 313373477342154752,
  "created_at" : "2013-03-17 19:38:15 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313372866261430273",
  "text" : "\u8CE2\u8005\u306B\u81F3\u3063\u3066\u306F\u904B\u52D5\u3059\u308C\u3070\u3059\u308B\u307B\u3069\u5143\u6C17\u306B\u306A\u308B\u7279\u6027\u6301\u3063\u3066\u308B\u306B\u9055\u3044\u306A\u3044\u632F\u308B\u821E\u3044\u3057\u3066\u308B",
  "id" : 313372866261430273,
  "created_at" : "2013-03-17 19:34:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313372553961930753",
  "text" : "\u4F53\u529B\u6709\u9650\u306E\u6211\u3005\u3068\u3057\u3066\u3082\u3060\u306A\u2026.(\u75B2\u308C\u305F)",
  "id" : 313372553961930753,
  "created_at" : "2013-03-17 19:33:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u308F\u305A",
      "screen_name" : "kawazu1147",
      "indices" : [ 3, 14 ],
      "id_str" : "111624231",
      "id" : 111624231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313372468050026496",
  "text" : "RT @kawazu1147: \u5B87\u5B99\u8CE2\u8005\u306F\u5727\u5012\u7684\u5B87\u5B99\u8CE2\u8005\u306B\u9032\u5316\u3057\u3066\u3084\u305F\u3089\u5143\u6C17\u3060\u3057\u30A8\u30B7\u30C7\u30A3\u30B7\u5148\u8F29\u3082\u305F\u3076\u3093\u4F53\u529B\u7121\u9650\u306B\u3042\u308B\u3063\u307D\u3044\u3057\u3084\u3070\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313372410806149120",
    "text" : "\u5B87\u5B99\u8CE2\u8005\u306F\u5727\u5012\u7684\u5B87\u5B99\u8CE2\u8005\u306B\u9032\u5316\u3057\u3066\u3084\u305F\u3089\u5143\u6C17\u3060\u3057\u30A8\u30B7\u30C7\u30A3\u30B7\u5148\u8F29\u3082\u305F\u3076\u3093\u4F53\u529B\u7121\u9650\u306B\u3042\u308B\u3063\u307D\u3044\u3057\u3084\u3070\u3044",
    "id" : 313372410806149120,
    "created_at" : "2013-03-17 19:32:59 +0000",
    "user" : {
      "name" : "\u304B\u308F\u305A",
      "screen_name" : "kawazu1147",
      "protected" : false,
      "id_str" : "111624231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1546733080\/twitterprofile5_normal.jpg",
      "id" : 111624231,
      "verified" : false
    }
  },
  "id" : 313372468050026496,
  "created_at" : "2013-03-17 19:33:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313364889580232704",
  "text" : "\u3084\u3055\u3050\u308C\u5148\u8F29\u3068\u5B87\u5B99\u8CE2\u8005\u3068\u30CF\u30FC\u30E2\u30CB\u30C3\u30AF\u3068\u304B\u308F\u305A\u5927\u5148\u751F\u3068\u5C71\u5143\u3055\u3093(\u5BDD\u3066\u308B)\u3068\u304B\u3053\u306E\u4E0A\u306A\u304F\u6FC3\u3044\u30E1\u30F3\u30D0\u30FC\u3060\u306A\u3041",
  "id" : 313364889580232704,
  "created_at" : "2013-03-17 19:03:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313353852088889344",
  "text" : "\u4F55\u304B\u306E\u6069\u6075\u3092\u6388\u304B\u308C\u308B\u6C17\u304C\u3057\u306A\u3044\u3067\u3082\u306A\u3044",
  "id" : 313353852088889344,
  "created_at" : "2013-03-17 18:19:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313353776083922944",
  "text" : "\u304B\u308F\u305A\u5927\u5148\u751F\u3068\u5B87\u5B99\u8CE2\u8005\u306E\u6B4C\u58F0\u3092\u805E\u304D\u306A\u304C\u3089\u30AB\u30E9\u6570\u5B66\u30AA\u30B1\u306A\u3046\uFF01",
  "id" : 313353776083922944,
  "created_at" : "2013-03-17 18:18:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313330452536623104",
  "geo" : { },
  "id_str" : "313330611936980994",
  "in_reply_to_user_id" : 1230390426,
  "text" : "@mathkin_uit \u73FE\u5730\u3067\u306F\u30AB\u30E9\u30AA\u30B1\u3067\u796D\u308A\u304C\u7D9A\u3044\u3066\u3044\u307E\u3059",
  "id" : 313330611936980994,
  "in_reply_to_status_id" : 313330452536623104,
  "created_at" : "2013-03-17 16:46:53 +0000",
  "in_reply_to_screen_name" : "8_u8",
  "in_reply_to_user_id_str" : "1230390426",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313329046127779840",
  "text" : "\u50D5\u306E\u66F2\u306E\u4E00\u66F2\u524D\u306E\u66F2\u59CB\u307E\u3063\u305F\u3089\u30EA\u30D7\u6B32\u3057\u3044\u3067\u3059(\u3048\u3042\u308A\u3077)",
  "id" : 313329046127779840,
  "created_at" : "2013-03-17 16:40:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313328091026034688",
  "text" : "\u3068\u306F\u3044\u3048\u3042\u3063\u3061\u306E\u90E8\u5C4B\u3069\u3093\u306A\u306E\u304B\u5272\u306B\u6C17\u306B\u306A\u308B\u306A",
  "id" : 313328091026034688,
  "created_at" : "2013-03-17 16:36:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313328032028979201",
  "text" : "\u5BDD\u305F\u304B\u3063\u305F\u3089\u5BDD\u308B\u3079\u304D\u306A\u306E\u3063",
  "id" : 313328032028979201,
  "created_at" : "2013-03-17 16:36:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313258521158369281",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 313258521158369281,
  "created_at" : "2013-03-17 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "indices" : [ 0, 8 ],
      "id_str" : "20522410",
      "id" : 20522410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313153613419642882",
  "geo" : { },
  "id_str" : "313153730503663616",
  "in_reply_to_user_id" : 20522410,
  "text" : "@halhorn \u5727\u5012\u7684\u516C\u5712\u53E3(^^)(^^)(^^)",
  "id" : 313153730503663616,
  "in_reply_to_status_id" : 313153613419642882,
  "created_at" : "2013-03-17 05:04:02 +0000",
  "in_reply_to_screen_name" : "halhorn",
  "in_reply_to_user_id_str" : "20522410",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313146817007190016",
  "text" : "\u8FD1\u3057\u3044\u30E6\u30FC\u30B6\u30FC\u3067\u51FA\u3066\u304D\u305F\u3088\u3046\u3067\u3059\u304C(\u30A2\u30A4\u30B3\u30F3\u3067\u899A\u3048\u3066\u3044\u305F\u305D\u3046\u306A)",
  "id" : 313146817007190016,
  "created_at" : "2013-03-17 04:36:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313146700481052672",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u3055\u3063\u304D\u300Cendomorphism\u306E\u65B9\u3067\u3059\u3088\u306D\uFF1F\u300D\u3066\u8A00\u308F\u308C\u305F\u3051\u3069\u306A\u305C\u30B5\u30D6\u57A2\u304C\u5148\u884C\u3057\u305F\u306E\u304B\u9762\u767D\u3044",
  "id" : 313146700481052672,
  "created_at" : "2013-03-17 04:36:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313145363131400192",
  "text" : "\u5149\u3082\u51FA\u308C\u3070\u30D3\u30FC\u30E0\u3082\u51FA\u308B\u3059\u3046\u304C\u304F\u5F92\u3084\u3070\u3044\u3068\u304A\u3082\u3046 #kansaimath",
  "id" : 313145363131400192,
  "created_at" : "2013-03-17 04:30:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313145226053177346",
  "text" : "\u5C0F\u6CC9\u3055\u3093\u3060\u3051\u3067\u306A\u304F\u306E\u3046\u3053\u3055\u3093\u3082\u5149\u3060\u3057\u305F\u306E\u2026\uFF1F #kansaimath",
  "id" : 313145226053177346,
  "created_at" : "2013-03-17 04:30:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313144613353443328",
  "geo" : { },
  "id_str" : "313144858225278976",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kin_uit \u305C\u3072\u305C\u3072\uFF01",
  "id" : 313144858225278976,
  "in_reply_to_status_id" : 313144613353443328,
  "created_at" : "2013-03-17 04:28:46 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313144412597260288",
  "geo" : { },
  "id_str" : "313144487369117697",
  "in_reply_to_user_id" : 62833617,
  "text" : "@kin_uit \u3044\u3064\u304B\u6765\u307E\u3057\u3087\u3046\uFF01",
  "id" : 313144487369117697,
  "in_reply_to_status_id" : 313144412597260288,
  "created_at" : "2013-03-17 04:27:18 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313138169438687233",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 313138169438687233,
  "created_at" : "2013-03-17 04:02:12 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313105089407623168",
  "text" : "ZF\u306F\u666E\u6BB5\u4F7F\u3063\u3066\u3044\u308BZFC\u304B\u3089C\u629C\u3044\u305F\u3082\u306E\u3067\u3059 #kansaimath110",
  "id" : 313105089407623168,
  "created_at" : "2013-03-17 01:50:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313104895228145665",
  "text" : "keno:\u30BA\u30A3\u30FC\u30A8\u30D5\u3063\u3063\u3066\u306A\u3093\u3067\u3059\u304B\uFF1F\n\u30C9\u30A5\u30FC:\u30C4\u30A7\u30EB\u30E1\u30ED\u30D5\u30EC\u30F3\u30B1\u30EB\u3067\u3059\u3002\nkeno:\u3042\u3041ZF\u3067\u3059\u304B\u3002\n\u30C9\u30A5\u30FC:\u30BC\u30C3\u30C8\u30A8\u30D5\u3068\u8A00\u308F\u306A\u3044\u3068\u4F1D\u308F\u3089\u306A\u3044\u2026 #kansaimath110",
  "id" : 313104895228145665,
  "created_at" : "2013-03-17 01:49:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313103734697783296",
  "text" : "\u7121\u7406\u3057\u3066\u30C4\u30C3\u30B3\u30DF\u3044\u308C\u306A\u304F\u3066\u3082\u3044\u3044\u3093\u3067\u3059\u3088 #kansaimath110",
  "id" : 313103734697783296,
  "created_at" : "2013-03-17 01:45:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 3, 13 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313103309181444096",
  "text" : "RT @end313124: \u30A2\u30EB\u30B4\u30C9\u30A5\u30FC\u3055\u3093\u306A\u3093\u3067\u55A7\u5629\u8170\u306A\u306Ewww #kansaimath110",
  "id" : 313103309181444096,
  "created_at" : "2013-03-17 01:43:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "k",
      "indices" : [ 20, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313103204005060608",
  "text" : "\u30A2\u30EB\u30B4\u30C9\u30A5\u30FC\u3055\u3093\u306A\u3093\u3067\u55A7\u5629\u8170\u306A\u306Ewww #k",
  "id" : 313103204005060608,
  "created_at" : "2013-03-17 01:43:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313102149586399232",
  "text" : "\u7D76\u671B\u3057\u305F\u30C3\uFF01\u8CEA\u554F\u3057\u305F\u3089\u201D\u7A7A\u6C17\u8AAD\u3081\u201D\u3068\u8A00\u3046\u8B1B\u6F14\u306B\u7D76\u671B\u3057\u305F\u30C3\uFF01 #kansaimath110",
  "id" : 313102149586399232,
  "created_at" : "2013-03-17 01:39:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313099281479368705",
  "text" : "\u3042\u3001\u3042\u3076\u306D\u3047\u3053\u308C\u304C\u3082\u3057\u201D\u9078\u629E\u516C\u7406\u3092\u4F7F\u3063\u3066\u306F\u3044\u3051\u306A\u304424\u6642\u201D\u3060\u3063\u305F\u3089\u6B7B\u3093\u3067\u3044\u305F #kansaimath110",
  "id" : 313099281479368705,
  "created_at" : "2013-03-17 01:27:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/313097144095625216\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/s0l2SkBPXW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFhYMZZCUAAMqVK.jpg",
      "id_str" : "313097144099819520",
      "id" : 313097144099819520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFhYMZZCUAAMqVK.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/s0l2SkBPXW"
    } ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 28, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313097144095625216",
  "text" : "\u8CE2\u8005\u306B\u5727\u5012\u7684\u30B5\u30A4\u30C0\u30FC\u3092\u3082\u3089\u3063\u305F(^^)(^^)(^^) #kansaimath110 http:\/\/t.co\/s0l2SkBPXW",
  "id" : 313097144095625216,
  "created_at" : "2013-03-17 01:19:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313095918788435969",
  "text" : "\u4E8C\u65E5\u76EE\u306F\u5927\u4EBA\u3057\u304F\u3059\u308BSyozon",
  "id" : 313095918788435969,
  "created_at" : "2013-03-17 01:14:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313075896733016064",
  "text" : "\u540D\u672D\u4F5C\u308A\u76F4\u3057\u305F\u306E\u306B\u3053\u308C\u5FD8\u308C\u3066\u6765\u305F\u307D\u3044\u306A",
  "id" : 313075896733016064,
  "created_at" : "2013-03-16 23:54:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313073985002823680",
  "text" : "\u5B9F\u969B\u7720\u3044",
  "id" : 313073985002823680,
  "created_at" : "2013-03-16 23:47:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312896108051439616",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 312896108051439616,
  "created_at" : "2013-03-16 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "endmemo",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312844802699956224",
  "text" : "ccc\u3068\u304B\u5F62\u4ED8\u304D\u30E9\u30E0\u30C0\u8A08\u7B97\u3068\u304B\u304C\u54F2\u5B66\u95A2\u9023 #endmemo",
  "id" : 312844802699956224,
  "created_at" : "2013-03-16 08:36:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312844391855316994",
  "text" : "\u30B9\u30AB\u30A4\u30C9\u30E9\u30A4\u30D6iPad\u3060\u3068\u958B\u3051\u306A\u3044\u3067\u3054\u3056\u308B\u30FC",
  "id" : 312844391855316994,
  "created_at" : "2013-03-16 08:34:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312840194111963136",
  "text" : "\u3046\u3060\u3055\u3093\u3059\u3063\u3052\u3047\uFF01\uFF01\uFF01\uFF01 #kansaimath108",
  "id" : 312840194111963136,
  "created_at" : "2013-03-16 08:18:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312840144254291969",
  "text" : "RT @t_uda: \u03C0:S(n+1)\u2192GL(V_\u03BB)\nQ. \u03C0|S(n) \u306E\u65E2\u7D04\u5206\u89E3\u306F\uFF1F\uFF1F\nThm. \u3053\u306E\u554F\u3044\u306F Young \u56F3\u5F62\u3067\u5206\u304B\u308B\u3002\nS(10)\n\u25A1\u25A1\u25A1\u25A0\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A0|S(n)\n\uFF1D\n\u25A1\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\n\uFF0B\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A1\n #kansaimath108",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kansaimath108",
        "indices" : [ 114, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312840109999411200",
    "text" : "\u03C0:S(n+1)\u2192GL(V_\u03BB)\nQ. \u03C0|S(n) \u306E\u65E2\u7D04\u5206\u89E3\u306F\uFF1F\uFF1F\nThm. \u3053\u306E\u554F\u3044\u306F Young \u56F3\u5F62\u3067\u5206\u304B\u308B\u3002\nS(10)\n\u25A1\u25A1\u25A1\u25A0\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A0|S(n)\n\uFF1D\n\u25A1\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\n\uFF0B\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A1\n\u25A1\u25A1\u25A1\n #kansaimath108",
    "id" : 312840109999411200,
    "created_at" : "2013-03-16 08:17:49 +0000",
    "user" : {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "protected" : false,
      "id_str" : "91551881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2672060221\/0f35a7ef7843ca03ed5048770fe5ecc4_normal.png",
      "id" : 91551881,
      "verified" : false
    }
  },
  "id" : 312840144254291969,
  "created_at" : "2013-03-16 08:17:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312840139464380416",
  "text" : "\u767A\u8868\u8005\u304C\u3061\u3087\u3063\u3068\u3060\u3051\u3068\u8A00\u3044\u51FA\u3057\u305F\u3089\u3053\u306E\u6587\u8A00\u304C\u5E30\u7D0D\u7684\u306B\u4F7F\u308F\u308C\u7D9A\u3051\u308B\u53EF\u80FD\u6027\u3092\u8003\u616E\u3057\u306A\u304F\u3066\u306F\u306A\u3089\u306A\u3044 #kansaimath",
  "id" : 312840139464380416,
  "created_at" : "2013-03-16 08:17:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312838431359254528",
  "text" : "\u3046\u3060\u3055\u3093\u304C\u518D\u958B\u3057\u3066\u304F\u308C\u3066\u3044\u3066\u826F\u304B\u3063\u305F",
  "id" : 312838431359254528,
  "created_at" : "2013-03-16 08:11:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312838075078303744",
  "text" : "\u6B8B\u308A\u306E\u677F\u66F8\u306F\u541B\u306E\u76EE\u3067\u78BA\u304B\u3081\u3066\u6B32\u3057\u3044(\u5B8C) #kansaimath108",
  "id" : 312838075078303744,
  "created_at" : "2013-03-16 08:09:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312838000394514432",
  "text" : "\u3064\u3044\u306B\u9ED2\u677F\u8FFD\u3044\u3064\u304B\u308C\u305F\u306E\u3067\u5B9F\u6CC1\u3092\u7D42\u308F\u308A\u307E\u3059orz #kansaimath108",
  "id" : 312838000394514432,
  "created_at" : "2013-03-16 08:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312837561091489792",
  "text" : "hom(V,W)=V^*\u00D7W(\u30C6\u30F3\u30BD\u30EB\u7A4D) #kansaimath108",
  "id" : 312837561091489792,
  "created_at" : "2013-03-16 08:07:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 64, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312837354610102273",
  "text" : "hom(V,W)^G\u306Fintertwiner,V,W:ilred\u306A\u3089\u3070schur\u3088\u308AHom(V,W)^G\u306F1dimor0dim #kansaimath108",
  "id" : 312837354610102273,
  "created_at" : "2013-03-16 08:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312836874060316673",
  "text" : "\u81EA\u660E\u8868\u73FE\u306E\u91CD\u8907\u5EA6=dimV^G=tr(\u03C6)=1\/|G|\u03A3_(g\/in G)\u03C7_V(g) #kansaimath108",
  "id" : 312836874060316673,
  "created_at" : "2013-03-16 08:04:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312836545235271681",
  "text" : "thm:\u03C6:V\u2192V^G\u3078\u306E\u30D7\u30ED\u30B8\u30A7\u30AF\u30B7\u30E7\u30F3 #kansaimath108",
  "id" : 312836545235271681,
  "created_at" : "2013-03-16 08:03:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312836377018515456",
  "text" : "\u03C6(g)=1\/|G|\u03A3_(g\/in G)gv #kansaimath108",
  "id" : 312836377018515456,
  "created_at" : "2013-03-16 08:02:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312836236345749504",
  "text" : "\u6307\u6A19\u306E\u4F7F\u3044\u65B9:V^G:=\uFF5Bv\/in V :\u4EFB\u610F\u306Eg,gv=v\uFF5D #kansaimath108",
  "id" : 312836236345749504,
  "created_at" : "2013-03-16 08:02:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312836010415378432",
  "text" : "\u03C7_\u03C0(h^-1gh)=\u03C7_\u03C0(g) #kansaimath108",
  "id" : 312836010415378432,
  "created_at" : "2013-03-16 08:01:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312835879032999936",
  "text" : "\u5B9A\u7FA9(\u6307\u6A19):\u03C0:G\u2192GL(V):rep\u306E\u6307\u6A19\u3068\u306F \u03C7_\u03C0(g):=tr(\u03C0(g)) #kansaimath108",
  "id" : 312835879032999936,
  "created_at" : "2013-03-16 08:01:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312835444951904257",
  "text" : "\u56FA\u6709\u5024:tr\u3092\u8ABF\u3079\u308B\uFF01\uFF01 #kansaimath108",
  "id" : 312835444951904257,
  "created_at" : "2013-03-16 07:59:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 16, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312835344783511554",
  "text" : "(b)\u4E00\u6B21\u72EC\u7ACB\u306A\u3089v+\u03C3v_i #kansaimath108",
  "id" : 312835344783511554,
  "created_at" : "2013-03-16 07:58:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312835253683224576",
  "text" : "(a)v,\u03C3v_i\u304C\u4E00\u6B21\u5F93\u5C5E\u306A\u3089\u03C9^(a_i)\u2260\u00B11 #kansaimath108",
  "id" : 312835253683224576,
  "created_at" : "2013-03-16 07:58:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312835014771474432",
  "text" : "(2)\u03C9^(a_i)=1 \u306A\u3089\u03C9^(2a_i)=1 #kansaimath108",
  "id" : 312835014771474432,
  "created_at" : "2013-03-16 07:57:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312834788354584576",
  "text" : "V_i:=Span\uFF5Bv_i,\u03C3v_i\uFF5D\/subset W inv\n(1)\u03C9^(a_i)\u22601\u306A\u3089v_i,\u03C3v_i\u306F\u4E00\u6B21\u72EC\u7ACB\u3088\u3063\u3066v_i=V #kansaimath108",
  "id" : 312834788354584576,
  "created_at" : "2013-03-16 07:56:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312834141328637953",
  "text" : "\u3084\u3063\u3079\u8FFD\u3044\u3064\u304B\u306A\u3044",
  "id" : 312834141328637953,
  "created_at" : "2013-03-16 07:54:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312834094776082432",
  "text" : "S(3)\u261EC^3\/supset V:=\uFF5B(v_1,v_2,v_3)^t:v_1+v_2+v_3=0\uFF5D\n\u5B9F\u306FS(3)\u306Eilred\u306FU,U^',V\u306E3\u3064 #kansaimath108",
  "id" : 312834094776082432,
  "created_at" : "2013-03-16 07:53:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312833153528111104",
  "text" : "S(3)\u306E\u7B26\u53F7\u306B\u5199\u3059\u6E96\u540C\u578B #kansaimath108",
  "id" : 312833153528111104,
  "created_at" : "2013-03-16 07:50:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312832978294300672",
  "text" : "\u03C4v_i=\u03C9^(a_i)v_i, \u03C3\u03C4\u03C3=\u03C4^2,\u03C3^2=1\u3088\u308A\u03C4(\u03C3v_i)=\u03C3(\u03C4^2v_i)=\u03C9^(2a_i)v_i #kansaimath108",
  "id" : 312832978294300672,
  "created_at" : "2013-03-16 07:49:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312832427754139648",
  "text" : "V_i:\u03C4\u306E\u56FA\u6709\u5024\u03BB_i\u306E\u56FA\u6709\u30D9\u30AF\u30C8\u30EB\n\u03C4^3=1,\u03BB_i^3=1, \u03BB_i=\u03C9^(\uFF41_i)#kansaimath108",
  "id" : 312832427754139648,
  "created_at" : "2013-03-16 07:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312831893538217984",
  "text" : "\u03C4\/simeq Z_3 W:=S(3)\u306E\u8868\u73FE #kansaimath108",
  "id" : 312831893538217984,
  "created_at" : "2013-03-16 07:45:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312831676336181248",
  "text" : "ex.S(3)=&lt;\u03C4,\u03C3&gt;\u3001\u03C4=&lt;1,2,3&gt;,\u03C3=&lt;1,2&gt;,\u03C3\u03C4\u03C3=\u03C4^2 #kansaimath108",
  "id" : 312831676336181248,
  "created_at" : "2013-03-16 07:44:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 9, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312831299490574336",
  "text" : "\u4E8C\u3064\u76EE\u3082\u304A\u3057\u307E\u3044 #kansaimath108",
  "id" : 312831299490574336,
  "created_at" : "2013-03-16 07:42:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 31, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312831139326877696",
  "text" : "\u03BB\u3068\u3057\u3066\u03C6\u306E\u56FA\u6709\u5024\u3092\u53D6\u308B\u3002\u03C6-\u03BB1\u3082 intertwiner #kansaimath108",
  "id" : 312831139326877696,
  "created_at" : "2013-03-16 07:42:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312830886326448128",
  "text" : "ker\u03C6\u306E\u5834\u5408\u308F\u3051\u3067\u7C21\u5358\u306B\u51FA\u308B\u30011\u756A\u304A\u3057\u307E\u3044 #kansaimath108",
  "id" : 312830886326448128,
  "created_at" : "2013-03-16 07:41:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 28, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312830702246834177",
  "text" : "proof:ker\u03C6,Im\u03C6\u306F\u5171\u306B\u4E0D\u5909(\u78BA\u304B\u3081\u3089\u308C\u3088) #kansaimath108",
  "id" : 312830702246834177,
  "created_at" : "2013-03-16 07:40:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312830526350295040",
  "text" : "LEM(Schur\u306E\u88DC\u984C):V,W(\u65E2\u7D04\u8868\u73FE)\u3068\u3057\u3066\u03C6:V\u2192W:intertwiner\u3068\u3057\u305F\u3089(1) \u03C6=0or\u5168\u5358\u5C04(2)V=W\u306A\u3089\u03C6\u306F\u5B9A\u6570\u500D\u5199\u50CF #kansaimath108",
  "id" : 312830526350295040,
  "created_at" : "2013-03-16 07:39:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312829910538395648",
  "text" : "\u56FA\u6709\u5024\u3092\u898B\u308B\u3053\u3068\u306E\u5F37\u529B\u3055\uFF01 #kansaimath108",
  "id" : 312829910538395648,
  "created_at" : "2013-03-16 07:37:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 28, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312829780980535297",
  "text" : "\u5177\u4F53\u7684\u3067\u3042\u308A\u304C\u305F\u3044(\u300C\u307F\u306A\u3055\u3093\u62BD\u8C61\u8AD6\u304C\u597D\u304D\u3067\u3059\u3051\u3069\u300D) #kansaimath108",
  "id" : 312829780980535297,
  "created_at" : "2013-03-16 07:36:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312829664961888256",
  "text" : "\u884C\u5217\u3067\u66F8\u3044\u305F\u3093\u306A\u3089\u56FA\u6709\u5024\u8ABF\u3079\u3088\u3046\u3088\uFF01\uFF01\uFF01\uFF01 #kansaimath108",
  "id" : 312829664961888256,
  "created_at" : "2013-03-16 07:36:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 11, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312829459919167489",
  "text" : "\u00A7\u8868\u73FE\u3068\u56FA\u6709\u5024\u3001\u6307\u6A19 #kansaimath108",
  "id" : 312829459919167489,
  "created_at" : "2013-03-16 07:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312829352515600384",
  "text" : "V=W+W^\u22A5(\u76F4\u548C) \u3053\u308C\u3092\u7E70\u308A\u8FD4\u305B\u3070\u826F\u3044\u25A1 #kansaimath108",
  "id" : 312829352515600384,
  "created_at" : "2013-03-16 07:35:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312829171552354304",
  "text" : "W\/subset V\u306B\u3064\u3044\u3066W^\u22A5\u3082\u3055\u3076\u305B\u3063\u3068#kansaimath108",
  "id" : 312829171552354304,
  "created_at" : "2013-03-16 07:34:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312828861773660161",
  "text" : "&lt;v,w&gt;=1\/|G|\u03A3_(g \/in G)(gv, gw) \u3053\u308C\u3082\u5185\u7A4D #kansaimath108",
  "id" : 312828861773660161,
  "created_at" : "2013-03-16 07:33:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312828535238696960",
  "text" : "\u4E45\u3005\u306B\u5185\u7A4D\u3061\u3083\u3093\u306E\u9854\u6587\u5B57\u304C(\u30FB,\u30FB) #kansaimath108",
  "id" : 312828535238696960,
  "created_at" : "2013-03-16 07:31:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312828446206210049",
  "text" : "\u2235V\u306B\u4F55\u304B\u5185\u7A4D\u3092\u3044\u308C\u308B(\u30FB,\u30FB) #kansaimath108",
  "id" : 312828446206210049,
  "created_at" : "2013-03-16 07:31:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 16, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312827953216106496",
  "text" : "prop:\u6709\u9650\u7FA4\u306F\u5E38\u306B\u5B8C\u5168\u53EF\u7D04 #kansaimath108",
  "id" : 312827953216106496,
  "created_at" : "2013-03-16 07:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312827617197817856",
  "text" : "\u3082\u3084\u3082\u3084\u304C\u6B62\u307E\u3089\u306A\u3044",
  "id" : 312827617197817856,
  "created_at" : "2013-03-16 07:28:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312827581906952194",
  "text" : "intertwiner\u306E\u548C\u8A33\u95A2\u6771\u3064\u3069\u3044\u3067\u805E\u3044\u305F\u3051\u3069\u601D\u3044\u51FA\u305B\u306C",
  "id" : 312827581906952194,
  "created_at" : "2013-03-16 07:28:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312827454144253952",
  "text" : "\u5B9A\u7FA9:V\u304C\u5B8C\u5168\u53EF\u7D04\u3068\u306F\u3001\u65E2\u7D04\u8868\u73FE\u306E\u76F4\u548C\u3068\u540C\u5024 #kansaimath108",
  "id" : 312827454144253952,
  "created_at" : "2013-03-16 07:27:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312826807831367680",
  "text" : "T\u304C\u5168\u5358\u5C04\u306E\u6642\u3001\u540C\u578B\u3068\u8A00\u3046\u3002\uFF36\uFF0CW\u3068\u306F\u305D\u306E\u9593\u306B\u540C\u578B\u304C\u5B58\u5728\u3059\u308B\u3053\u3068\u3002 #kansaimath108",
  "id" : 312826807831367680,
  "created_at" : "2013-03-16 07:24:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312826494185517056",
  "text" : "\u5B9A\u7FA9(\u8868\u73FE\u306E\u540C\u5024\u6027):T:V\u2192W[lin]\u304Cintertwiner\u3068\u306F \u4EFB\u610F\u306Eg\u306B\u3064\u3044\u3066\u3001gT=Tg #kansaimath108",
  "id" : 312826494185517056,
  "created_at" : "2013-03-16 07:23:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 11, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312825847209922562",
  "text" : "\u4E8C\u3064\u76EE\uFF01\u8868\u73FE\u306E\u5206\u89E3\uFF01 #kansaimath108",
  "id" : 312825847209922562,
  "created_at" : "2013-03-16 07:21:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312825394506125312",
  "text" : "\u5B9A\u7FA9(\u65E2\u7D04\u6027):(\u03C0,V)\u304C\u65E2\u7D04\u3068\u306F\u90E8\u5206\u8868\u73FE\u304C0,V\u306E\u307F\u3067\u3042\u308B\u3082\u306E #kansaimath108",
  "id" : 312825394506125312,
  "created_at" : "2013-03-16 07:19:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 5, 15 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312824862483816448",
  "text" : "\u8A02\u6B63RT @end313124: ex.(4)(\u03C0,V):\u8868\u73FE W \/subset V s.t \u03C0(g)(w)\/subset W \u03C0(g)|_W:W\u2192W(\u90E8\u5206\u8868\u73FE)  \u3053\u308C\u3092\u4E0D\u5909\u7A7A\u9593\u3068\u8A00\u3046#kansaimath108 #kansaimath108",
  "id" : 312824862483816448,
  "created_at" : "2013-03-16 07:17:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312824683324133376",
  "text" : "\u4E00\u3064\u76EE\u3068\u4E8C\u3064\u76EE\u3092\u8003\u3048\u308B\u3002\u307E\u305A\u4E00\u3064\u76EE\u3002 #kansaimath108",
  "id" : 312824683324133376,
  "created_at" : "2013-03-16 07:16:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 37, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312824615791648768",
  "text" : "Borel-Weil\u7406\u8AD6\u304C\u4E09\u3064\u76EE\u306E\u554F\u984C\u306B\u95A2\u308F\u308B\u3001\u52C9\u5F37\u3057\u305F\u3044\u4EBA\u306F\u8ABF\u3079\u308B\u3053\u3068 #kansaimath108",
  "id" : 312824615791648768,
  "created_at" : "2013-03-16 07:16:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312824284198350850",
  "text" : "\u4ECA\u65E5\u306F\u8A71\u305B\u306A\u3044\u304C\u672C\u5F53\u306F\u3082\u3046\u4E00\u3064:(3)\u305D\u306E\u8868\u73FE\u306F\u3069\u3046\u3044\u3046\u5BFE\u79F0\u6027\u3092\u8868\u3057\u3066\u3044\u308B\u306E\u304B\uFF1F #kansaimath108",
  "id" : 312824284198350850,
  "created_at" : "2013-03-16 07:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312824047752863744",
  "text" : "\u3053\u308C\u306F\u8868\u73FE\u8AD6\u3067\u306F\u6700\u3082\u57FA\u672C\u7684\u306A\u554F\u984C #kansaimath108",
  "id" : 312824047752863744,
  "created_at" : "2013-03-16 07:13:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312823975212380160",
  "text" : "\u57FA\u672C\u7684\u306A\u554F\u984C:(1)\u6700\u5C0F\u306E(\u6975\u5C0F\u306E)\u8868\u73FE\u306F\u3069\u308C\uFF1F(2)\u8868\u73FE\u306F\u3069\u3046(1)\u306E\u30D1\u30FC\u30C4\u306B\u5206\u89E3\u51FA\u6765\u308B\u304B\uFF1F #kansaimath108",
  "id" : 312823975212380160,
  "created_at" : "2013-03-16 07:13:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312823427914420224",
  "text" : "\u76F4\u548C\u304C\u51FA\u6765\u308B\u306A\u3089\u9006\u306B\u76F4\u548C\u5206\u89E3\u306F\u51FA\u6765\u306A\u3044\u306E\u304B #kansaimath108",
  "id" : 312823427914420224,
  "created_at" : "2013-03-16 07:11:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312823326106087424",
  "text" : "\u3069\u3093\u3069\u3093\"\u5C0F\u3055\u3044\"\u8868\u73FE\u3092\u3068\u308C\u305D\u3046\u3060\u304C\u3001\u3082\u3063\u3068\u3082\u5C0F\u3055\u3044\u8868\u73FE\u306F\u3069\u3093\u306A\u3082\u306E\u3060\u308D\u3046\uFF1F #kansaimath108",
  "id" : 312823326106087424,
  "created_at" : "2013-03-16 07:11:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312823171537592320",
  "text" : "\u8868\u73FE\u306E\u4E2D\u306B\u8868\u73FE\u304C\u5165\u3063\u3066\u3044\u308B\u3053\u3068\u304C\u3042\u308B #kansaimath108",
  "id" : 312823171537592320,
  "created_at" : "2013-03-16 07:10:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312823087710216192",
  "text" : "ex.(4)(\u03C0,V):\u8868\u73FE W \/subset V s.t \u03C0(g)(w)\/subset W \u03C0(g)|_W:W\u2192W(\u90E8\u5206\u7A7A\u9593) \n\u3053\u308C\u3092\u4E0D\u5909\u7A7A\u9593\u3068\u8A00\u3046#kansaimath108",
  "id" : 312823087710216192,
  "created_at" : "2013-03-16 07:10:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312822301081083904",
  "text" : "V\u306B\u305F\u3044\u3057\u3066v^\uFF0A(\u53CC\u5BFE\u7A7A\u9593)\u3068\u3057\u3066\u03C0(g):V\u2192V \u306B\u305F\u3044\u3057\u3066\u03C0(g)^\uFF0A:V^\uFF0A\u2192V^\uFF0A#kansaimath108",
  "id" : 312822301081083904,
  "created_at" : "2013-03-16 07:07:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 16, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312821717150101504",
  "text" : "\u8868\u73FE\u304B\u3089\u8868\u73FE\u304C\u3069\u3093\u3069\u3093\u51FA\u3066\u304F\u308B #kansaimath108",
  "id" : 312821717150101504,
  "created_at" : "2013-03-16 07:04:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312821680038895616",
  "text" : "ex.(3)V,W\u3092\u8868\u73FE\u3068\u3057\u3066(\u6E96\u540C\u578B\u306F\u7701\u304B\u308C\u3066\u3044\u308B)V+W(\u76F4\u548C)\u3001V\u00D7W(\u30C6\u30F3\u30BD\u30EB\u7A4D)\u3082\u8868\u73FE\u306B\u306A\u308B #kansaimath108",
  "id" : 312821680038895616,
  "created_at" : "2013-03-16 07:04:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312820879530815489",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 312820879530815489,
  "created_at" : "2013-03-16 07:01:24 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312820763935776768",
  "text" : "\u03BB(h)=(\u03A3_(g\/in G)a_g \u03B4_g)=\u03A3_(g\/in G)a_g\u03B4_(hg)  \u3053\u308C\u306F\u5DE6\u6B63\u5247\u8868\u73FE(\u4E00\u5FDC\u53F3\u3082\u3042\u308B) #kansaimath108",
  "id" : 312820763935776768,
  "created_at" : "2013-03-16 07:00:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312820159112957952",
  "text" : "ex.(2) CG:=Span_\uFF23\uFF5B\u03B4g\uFF5D#kansaimath108",
  "id" : 312820159112957952,
  "created_at" : "2013-03-16 06:58:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 31, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312819742102654976",
  "text" : "ex.(1)G\u2192GL(V),g\u21921 \u81EA\u660E\u8868\u73FE(\u3053\u308C\u5927\u4E8B\uFF01\uFF01) #kansaimath108",
  "id" : 312819742102654976,
  "created_at" : "2013-03-16 06:56:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312819168279928832",
  "text" : "\u6700\u521D\u306E\u4E00\u6642\u9593\u306F\u6709\u9650\u6B21\u5143\u306E\u30D9\u30AF\u30C8\u30EB\u7A7A\u9593\u3092\u6271\u3046 #kansaimath108",
  "id" : 312819168279928832,
  "created_at" : "2013-03-16 06:54:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312818825513037824",
  "text" : "\u8A18\u53F7:\u03C0(g)(v)=:gv #kansaimath108",
  "id" : 312818825513037824,
  "created_at" : "2013-03-16 06:53:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312818552832917504",
  "text" : "\u6E96\u540C\u578B\u3068\u30D9\u30AF\u30C8\u30EB\u7A7A\u9593\u306E\u7D44\u3067\u66F8\u3044\u305F\u308A\u3082\u3059\u308B #kansaimath108",
  "id" : 312818552832917504,
  "created_at" : "2013-03-16 06:52:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312818388101640192",
  "text" : "\u4ECA\u306FC\u4E0A\u306E\u3001\u306B\u3057\u3066\u304A\u304F\u3002\u3053\u308C\u306F\u5927\u5207\u3002 #kansaimath108",
  "id" : 312818388101640192,
  "created_at" : "2013-03-16 06:51:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312818329058410496",
  "text" : "\u03C0:G\u2192GL(V):\u6E96\u540C\u578B \u3053\u308C\u3092V\u4E0A\u306E\u8868\u73FE\u3068\u8A00\u3046 #kansaimath108",
  "id" : 312818329058410496,
  "created_at" : "2013-03-16 06:51:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312818056814538752",
  "text" : "\u5B9A\u7FA9(\u7FA4\u306E\u8868\u73FE): G:\u7FA4,V:C\u4E0A\u306E\u30D9\u30AF\u30C8\u30EBSp #kansaimath108",
  "id" : 312818056814538752,
  "created_at" : "2013-03-16 06:50:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312817788068691968",
  "text" : "\u7FA4\u3092\u884C\u5217\u3092\u4F7F\u3063\u3066\u66F8\u304D\u305F\u3044\u3001\u3092\u3082\u3046\u5C11\u3057\u5177\u4F53\u5316 #kansaimath108",
  "id" : 312817788068691968,
  "created_at" : "2013-03-16 06:49:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312817659395862528",
  "text" : "S(\u221E)\u306F\u53EF\u7B97(\u96E2\u6563)\u7FA4\u3068\u3082\u547C\u3070\u308C\u308B #kansaimath108",
  "id" : 312817659395862528,
  "created_at" : "2013-03-16 06:48:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312817539216449537",
  "text" : "GL\u3084O\u306F\u4F4D\u76F8\u7684\u306B\u826F\u3044\u6027\u8CEA\u3092\u5099\u3048\u3066\u3044\u308B. #kansaimath108",
  "id" : 312817539216449537,
  "created_at" : "2013-03-16 06:48:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 38, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312817312866643969",
  "text" : "\u5927\u4E8B\u306A\u3082\u306E\u3068\u3057\u3066S_\u221E:\u81EA\u7136\u6570\u5168\u4F53\u306E\u4E2D\u3067\u306E\u7F6E\u63DB(\u4F46\u3057\u6709\u9650\u500B\u3057\u304B\u52D5\u304B\u3055\u306A\u3044) #kansaimath108",
  "id" : 312817312866643969,
  "created_at" : "2013-03-16 06:47:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312817122650763264",
  "text" : "\u4ED6\u306E\u4F8B\u3068\u3057\u3066\u3001GL(R^n),O(n),U(n) #kansaimath108",
  "id" : 312817122650763264,
  "created_at" : "2013-03-16 06:46:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312816820254044160",
  "text" : "Z\/nZ\u3068\u304B\u81EA\u660E\u306A1\u3068\u304B\u3001S_n\u3068\u304B\u306F\u6709\u9650\u7FA4 #kansaimath108",
  "id" : 312816820254044160,
  "created_at" : "2013-03-16 06:45:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312816670760660992",
  "text" : "\u4ECA\u65E5\u306FG:\u6709\u9650\u7FA4\u3092\u6271\u3046(\u5143\u306E\u500B\u6570\u304C\u6709\u9650\u306A\u3082\u306E) #kansaimath108",
  "id" : 312816670760660992,
  "created_at" : "2013-03-16 06:44:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312816513948213248",
  "text" : "\u7FA4\u306E\u51FA\u81EA\u306F\u3082\u3063\u3068\u5177\u4F53\u7684\u306A\u306F\u305A\u3001\u7FA4\u3092\u884C\u5217\u3092\u4F7F\u3063\u3066\u308F\u304B\u308A\u3084\u3059\u304F\"\u8868\u73FE\"\u3057\u3066\u3042\u3052\u308B\u306E\u304C\u3001\u8868\u73FE\u8AD6 #kansaimath108",
  "id" : 312816513948213248,
  "created_at" : "2013-03-16 06:44:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 18, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312816362768703490",
  "text" : "\u7FA4\u306E\u5B9A\u7FA9\u306F\u62BD\u8C61\u7684\u3067\u3088\u304F\u308F\u304B\u3089\u3093\u307D\u3093 #kansaimath108",
  "id" : 312816362768703490,
  "created_at" : "2013-03-16 06:43:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 12, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312816217624821760",
  "text" : "\u8868\u73FE\u3057\u305F\u3044\u3082\u306E\u306F\u300C\u7FA4\u300D #kansaimath108",
  "id" : 312816217624821760,
  "created_at" : "2013-03-16 06:42:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 9, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312816102793150464",
  "text" : "\u8868\u73FE\u8AD6is \u4F55\uFF1F #kansaimath108",
  "id" : 312816102793150464,
  "created_at" : "2013-03-16 06:42:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312815804569755648",
  "geo" : { },
  "id_str" : "312816030839885824",
  "in_reply_to_user_id" : 819871357,
  "text" : "@kansaimath_3rd \u3042\u3063\u3001\u306F\u3044 #kansaimath108",
  "id" : 312816030839885824,
  "in_reply_to_status_id" : 312815804569755648,
  "created_at" : "2013-03-16 06:42:08 +0000",
  "in_reply_to_screen_name" : "kansaimath",
  "in_reply_to_user_id_str" : "819871357",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 9, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312815962770522113",
  "text" : "\u30C8\u30EC\u30FC\u30B9\u304C\u5F37\u529B\uFF01 #kansaimath108",
  "id" : 312815962770522113,
  "created_at" : "2013-03-16 06:41:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312815746914844673",
  "text" : "@Italiasan \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 312815746914844673,
  "created_at" : "2013-03-16 06:41:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312815603532566528",
  "text" : "\u3046\u3060\u3055\u3093\u3044\u308B\u306A\u3089\u5B9F\u6CC1\u3057\u306A\u304F\u3066\u826F\u3044\u306E\u3067\u306F",
  "id" : 312815603532566528,
  "created_at" : "2013-03-16 06:40:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312814879457296386",
  "text" : "\u6570\u5B66\u5F92\u306E\u300C\u7DDA\u578B\u4EE3\u6570\u300D\u306F\u5F53\u3066\u306B\u306A\u3089\u306A\u3044",
  "id" : 312814879457296386,
  "created_at" : "2013-03-16 06:37:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312814628994437120",
  "text" : "\u3048\u306E\u3055\u3093\u300C\u6700\u521D\u306E\u4E00\u6642\u9593\u306F\u7DDA\u578B\u4EE3\u6570\u3067\u3059\u300D #kansaimath108",
  "id" : 312814628994437120,
  "created_at" : "2013-03-16 06:36:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312814506214576128",
  "text" : "\u3048\u306E\u3055\u3093\u300C\u30C8\u30EC\u30FC\u30B9\u306E\u7D20\u6674\u3089\u3057\u3055\u3092\u5B66\u3076\u8B1B\u7FA9\u300D #kansaimath108",
  "id" : 312814506214576128,
  "created_at" : "2013-03-16 06:36:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 10, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312814103158738944",
  "text" : "\u307E\u3060\u59CB\u307E\u3089\u306A\u3044\u3051\u3069 #kansaimath108",
  "id" : 312814103158738944,
  "created_at" : "2013-03-16 06:34:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath108",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312814063677755393",
  "text" : "\u3048\u306E\u3055\u3093\u306B\u3088\u308B An introduction Representation Theory and Asymptotic Representation Theory  #kansaimath108",
  "id" : 312814063677755393,
  "created_at" : "2013-03-16 06:34:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312791329740582914",
  "text" : "\u7D42\u308F\u3063\u305F\uFF01\uFF01\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF01 #kansaimath110",
  "id" : 312791329740582914,
  "created_at" : "2013-03-16 05:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312791266381426688",
  "text" : "\u4E00\u65B9\u222B_R f_t(x)dx=1\u3060\u304C\u222B_R f_0 \u22600 #kansaimath110",
  "id" : 312791266381426688,
  "created_at" : "2013-03-16 05:03:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 28, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312790925585813504",
  "text" : "\u306A\u3089\u3070f_t(x)\u2192f_0(x)(\u4EFB\u610F\u306Ex)(t\u21930) #kansaimath110",
  "id" : 312790925585813504,
  "created_at" : "2013-03-16 05:02:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312790589848551425",
  "text" : "f_0(x)=\u221E(x=0)or0(\u3042\u3056\u308F\u3044\u305A) #kansaimath110",
  "id" : 312790589848551425,
  "created_at" : "2013-03-16 05:01:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312790386152177665",
  "text" : "\u53CD\u4F8B:f_t(x)=1\/(\/sqrt(2\u03C0x))exp(-x^2\/(2\u03C0)) #kansaimath110",
  "id" : 312790386152177665,
  "created_at" : "2013-03-16 05:00:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312789907879907328",
  "text" : "lim\u222Bf_n=?\u222Blimf_n #kansaimath110",
  "id" : 312789907879907328,
  "created_at" : "2013-03-16 04:58:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312789716346998784",
  "text" : "f_n(x)\u2192f(x)(\u4EFB\u610F\u306Ex)\u306A\u3089\u3070 \u222Bf_n=\u222Bf \u3068\u8A00\u3046\u554F\u984C#kansaimath110",
  "id" : 312789716346998784,
  "created_at" : "2013-03-16 04:57:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312789307930845185",
  "text" : "\u4E94\u3064\u76EE:\u95A2\u6570\u5217\u304C\u5404\u70B9\u53CE\u675F\u3059\u308B\u3068\u304D\u3001\u7A4D\u5206\u306E\u5024\u3082\u53CE\u675F\u3059\u308B\u304B\uFF1F #kansaimath110",
  "id" : 312789307930845185,
  "created_at" : "2013-03-16 04:55:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 55, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312789058025828352",
  "text" : "\u53CD\u4F8B:\u03A9 =Q\u304B\u3064[0,2]\u3068\u3057f:\u03A9\u2192R:f(x)=0or1(\u30EB\u30FC\u30C82\u3088\u308A\u5927\u304D\u3044\u3068\u304D1\u3001\u305D\u308C\u4EE5\u5916\u306E\u3068\u304D0) #kansaimath110",
  "id" : 312789058025828352,
  "created_at" : "2013-03-16 04:54:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312788434659995648",
  "text" : "\u6709\u754C\u304B\u3064\u5B8C\u5099\u3067\u306A\u3044\u7A7A\u9593\u3092\u4F5C\u308B\u2192Q\u306Esubset #kansaimath110",
  "id" : 312788434659995648,
  "created_at" : "2013-03-16 04:52:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312788127586598912",
  "text" : "\u6709\u754C\u9589\u96C6\u5408\u2260\u30B3\u30F3\u30D1\u30AF\u30C8\u306A\u308B\u7A7A\u9593\u306F\u3042\u308B\u304B\uFF1F[\u7121\u9650\u6B21\u5143\u30D0\u30CA\u30C3\u30CF\u3001\u30D2\u30EB\u30D9\u30EB\u30C8Sp\u4EE5\u5916\u3067] #kansaimath110",
  "id" : 312788127586598912,
  "created_at" : "2013-03-16 04:51:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312787949056032770",
  "text" : "\u4E00\u65E6\u03A9\/in R^d \u3068\u3059\u308B\u3068\u4E00\u3064\u76EE\u3068\u4E8C\u3064\u76EE\u304B\u3089f:\u03A9\u2192R\u306F\u4E00\u69D8\u9023\u7D9A\u306B\u306A\u308B#kansaimath110",
  "id" : 312787949056032770,
  "created_at" : "2013-03-16 04:50:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312787618565865473",
  "text" : "\u4E09\u3064\u76EE:X:\u8DDD\u96E2\u7A7A\u9593\u306E\u3068\u304D(1)X\u306F\u30B3\u30F3\u30D1\u30AF\u30C8(2)X\u304C\u5B8C\u5099\u3067\u5168\u6709\u754C #kansaimath110",
  "id" : 312787618565865473,
  "created_at" : "2013-03-16 04:49:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312787344468103169",
  "text" : "\u4E8C\u3064\u76EE:X,Y:\u8DDD\u96E2\u7A7A\u9593,f:X\u2192Y\u304C\u9023\u7D9A\u306E\u3068\u304D\u3001X\u304C\u30B3\u30F3\u30D1\u30AF\u30C8\u306A\u3089\u3070f\u306F\u4E00\u69D8\u9023\u7D9A #kansaimath110",
  "id" : 312787344468103169,
  "created_at" : "2013-03-16 04:48:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 37, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312786997385252864",
  "text" : "\u4E00\u3064\u76EE:\u03A9\u3092R^d\u306E\u3068\u304D\u6B21\u306E\u4E8C\u3064\u304C\u8A00\u3048\u308B(1)\u6709\u754C\u9589\u96C6\u5408\u21C6\u03A9\u306F\u30B3\u30F3\u30D1\u30AF\u30C8 #kansaimath110",
  "id" : 312786997385252864,
  "created_at" : "2013-03-16 04:46:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312786543532179457",
  "text" : "\u80CC\u666F\u306B\u3042\u308B\u5B9A\u7406\u3092\u4E09\u3064\u8FF0\u3079\u308B #kansaimath110",
  "id" : 312786543532179457,
  "created_at" : "2013-03-16 04:44:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312786318419693568",
  "text" : "\u56DB\u3064\u76EE\u306E\u4F8B\u3001\u6709\u754C\u9589\u96C6\u5408\u03A9\u4E0A\u9023\u7D9A\u306A\u95A2\u6570\u306F\u4E00\u69D8\u9023\u7D9A\u306B\u306A\u308B\u304B\uFF1F #kansaimath110",
  "id" : 312786318419693568,
  "created_at" : "2013-03-16 04:44:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312786117978095617",
  "text" : "\u7D71\u8A08\u529B\u5B66\u3068\u304B\u3067\u306F\u76F8\u8EE2\u79FB\u306B\u3064\u3044\u3066\u3053\u306E\u624B\u306E\u3082\u306E\u3092\u4F7F\u3046 #kansaimath110",
  "id" : 312786117978095617,
  "created_at" : "2013-03-16 04:43:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312785956551929856",
  "text" : "\u95A2\u6570\u304B\u3082\u308F\u304B\u3089\u306A\u3044(\u8D85\u95A2\u6570\u306B\u306A\u308B\u3053\u3068\u3082) #kansaimath110",
  "id" : 312785956551929856,
  "created_at" : "2013-03-16 04:42:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312785869725638657",
  "text" : "\u9023\u7D9A\u304B\u3069\u3046\u304B\u3082\u3082\u308F\u304B\u3089\u306A\u3044 #kansaimath110",
  "id" : 312785869725638657,
  "created_at" : "2013-03-16 04:42:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312785800536399872",
  "text" : "\u4E00\u822C\u306B\u6ED1\u3089\u304B\u306A\u95A2\u6570\u306E\u6975\u9650\u304C\u6ED1\u3089\u304B\u3067\u3042\u308B\u3068\u306F\u9650\u3089\u306A\u3044 #kansaimath110",
  "id" : 312785800536399872,
  "created_at" : "2013-03-16 04:42:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312785704285511680",
  "text" : "W_0^N(x)=\u03A3_(k=0)^N b^k cos(\u03C0a^kx) \/in F^\u221E(C^\u03C9)#kansaimath110",
  "id" : 312785704285511680,
  "created_at" : "2013-03-16 04:41:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 3, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312785308863315968",
  "text" : "\u767A\u5C55 #kansaimath110",
  "id" : 312785308863315968,
  "created_at" : "2013-03-16 04:40:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312785191678644224",
  "text" : "\u828B\u3065\u308B\u5F0F\u306Bw_k=\u222B_0^x w_(k-1)(t)dt \u304C\u305D\u306E\u7B54\u3048\u306B\u306A\u308B#kansaimath110",
  "id" : 312785191678644224,
  "created_at" : "2013-03-16 04:39:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312784835766788096",
  "text" : "\u3067\u306Fk\u56DE\u5FAE\u5206\u51FA\u6765\u308B\u304Ck+1\u56DE\u306F\u81F3\u308B\u6240\u3067\u5FAE\u5206\u51FA\u6765\u308B\u3082\u306E\u306F\uFF1F #kansaimath110",
  "id" : 312784835766788096,
  "created_at" : "2013-03-16 04:38:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312784658037350400",
  "text" : "W0(x)=\u03A3_(k=0)^\u7121\u9650 b^k cos(\u03C0a^kx) \u3068\u3059\u308B\u3068\u3053\u308C\u306F\u5FAE\u5206\u51FA\u6765\u306A\u3044#kansaimath110",
  "id" : 312784658037350400,
  "created_at" : "2013-03-16 04:37:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312784149280878592",
  "text" : "a:3\u4EE5\u4E0A\u306E\u5947\u6570\u3001b \/in (0,1) ,ab&gt;1+3\u03C0\/2 #kansaimath110",
  "id" : 312784149280878592,
  "created_at" : "2013-03-16 04:35:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312783724053925890",
  "text" : "\u30EF\u30A4\u30A8\u30EB\u30B7\u30E5\u30C8\u30E9\u30A6\u30B9\u306E\u4F8B #kansaimath110",
  "id" : 312783724053925890,
  "created_at" : "2013-03-16 04:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312783695796920321",
  "text" : "\u9AD8\u6728\u95A2\u6570\u3084\u30D6\u30E9\u30A6\u30F3\u904B\u52D5\u306F\u7701\u7565 #kansaimath110",
  "id" : 312783695796920321,
  "created_at" : "2013-03-16 04:33:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312783482579456000",
  "text" : "\u56DE\u7B54\u4E0D\u80FD\u306A\u3089\u307E\u3060\u826F\u3044\u304C\u9593\u9055\u3044\u307E\u3067\u751F\u3058\u3066\u3057\u307E\u3046 #kansaimath110",
  "id" : 312783482579456000,
  "created_at" : "2013-03-16 04:32:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312783407434330113",
  "text" : "\u554F\u984C\u304C\u66D6\u6627\u3060\u3068\u56DE\u7B54\u3057\u3088\u3046\u304C\u7121\u3044\u3053\u3068\u306E\u6B74\u53F2\u7684\u306A\u4F8B\u306B\u306A\u3063\u3066\u3044\u308B #kansaimath110",
  "id" : 312783407434330113,
  "created_at" : "2013-03-16 04:32:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312783322940059650",
  "text" : "\u4ECA\u306E\u9023\u7D9A\u6027\u306F\u30B3\u30FC\u30B7\u30FC\u306B\u3088\u3063\u3066\u5B9A\u5F0F\u5316\u3055\u308C\u305F\u3082\u306E\u3060\u304C\u3001\u5F53\u6642\u306F\u9023\u7D9A\u6027\u304C\u4ECA\u306E\u3082\u306E\u3068\u306F\u7570\u306A\u3063\u3066\u3044\u305F #kansaimath110",
  "id" : 312783322940059650,
  "created_at" : "2013-03-16 04:32:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312783144640204800",
  "text" : "\u9023\u7D9A\u95A2\u6570\u306A\u3089\u5FAE\u5206\u3067\u304D\u308B\u3001\u3068\u8A00\u3046\u3053\u3068\u304C\u4FE1\u3058\u3089\u308C\u3066\u3044\u305F\u3057\u3001\u8A3C\u660E\u307E\u3067\u3042\u3063\u305F #kansaimath110",
  "id" : 312783144640204800,
  "created_at" : "2013-03-16 04:31:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312783001631203329",
  "text" : "\u6B74\u53F2\u7684\u306B\u6FC0\u3057\u3044\u3053\u3068\u304C\u3042\u3063\u305F\u3002\u75C5\u7684\u306A\u95A2\u6570\u306E\u8A71\u304B\u306A\uFF1F #kansaimath110",
  "id" : 312783001631203329,
  "created_at" : "2013-03-16 04:30:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312782898656845824",
  "text" : "\u3055\u3063\u304D\u306E|x|\u306F\u4E00\u70B9(0)\u3067\u3060\u3051\u5FAE\u5206\u3067\u304D\u306A\u304B\u3063\u305F\u304C\u81F3\u308B\u6240\u3067\u306F\u3069\u3046\u304B #kansaimath110",
  "id" : 312782898656845824,
  "created_at" : "2013-03-16 04:30:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 18, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312782599955288064",
  "text" : "\u9023\u7D9A\u3060\u304C\u81F3\u308B\u6240\u5FAE\u5206\u4E0D\u53EF\u80FD\u306A\u3082\u306E\u306E\u4F8B #kansaimath110",
  "id" : 312782599955288064,
  "created_at" : "2013-03-16 04:29:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312782229996728320",
  "text" : "\u8A00\u308F\u308C\u305F\u3089\u305D\u3046\u3060\u306A\u30FC\u3001\u6587\u8A00\u805E\u304F\u3068\u30E4\u30D0\u305D\u3046\u3060\u3051\u3069 #kansaimath110",
  "id" : 312782229996728320,
  "created_at" : "2013-03-16 04:27:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312782036752551937",
  "text" : "\u30C7\u30A3\u30EA\u30AF\u30EC\u95A2\u6570\u304C\u80CC\u666F\u306B\u3042\u308B #kansaimath110",
  "id" : 312782036752551937,
  "created_at" : "2013-03-16 04:27:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312781927482535936",
  "text" : "f(x)=\u00B11(\u6709\u7406\u6570\u306A\u30891\u3001\u7121\u7406\u6570\u306A\u3089-1)\u3068\u3059\u308C\u3070\u826F\u3044 #kansaimath110",
  "id" : 312781927482535936,
  "created_at" : "2013-03-16 04:26:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 11, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312781585671933952",
  "text" : "\u30DE\u30B8\u304B\u3088\u2026\u3068\u8A00\u3046\u7A7A\u6C17 #kansaimath110",
  "id" : 312781585671933952,
  "created_at" : "2013-03-16 04:25:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312781550318125056",
  "text" : "\u81F3\u308B\u6240\u4E0D\u9023\u7D9A\u306A\u306E\u306B\u7D76\u5BFE\u5024\u3068\u308B\u3068\u89E3\u6790\u7684\u306B\u306A\u308B\u5727\u5012\u7684\u306A\u4F8B\u304C\u3042\u308B #kansaimath110",
  "id" : 312781550318125056,
  "created_at" : "2013-03-16 04:25:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312781413697060864",
  "text" : "h(x)=\u00B1\uFF58^2(x\u306E\u7B26\u53F7\u4F9D\u5B58)\u3068\u3059\u308C\u3070\u826F\u3044\u304C\u3053\u306E\u5834\u5408\u6ED1\u3089\u304B\u3055\u304C\u4E0A\u304C\u308A\u3055\u3048\u3057\u3066\u3044\u308B #kansaimath110",
  "id" : 312781413697060864,
  "created_at" : "2013-03-16 04:24:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312781035878359040",
  "text" : "|x|\u306E\u6642\u306E\u3088\u3046\u306B\u304B\u3063\u304F\u3093\u3068\u306A\u308B\u3068\u30C0\u30E1\u306A\u306E\u3067 #kansaimath110",
  "id" : 312781035878359040,
  "created_at" : "2013-03-16 04:23:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312780691513430016",
  "text" : "\u3067\u306F\u5024\u306E\u7B26\u53F7\u304C\u5909\u308F\u308B\u6642\u306F\u3069\u3046\u3060\u308D\u3046\u304B\uFF1F #kansaimath110",
  "id" : 312780691513430016,
  "created_at" : "2013-03-16 04:21:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312780622441611265",
  "text" : "\u554F\u984C\u306E\u53CD\u4F8B\u3068\u3057\u3066f(x)=x^2 \u304C\u3042\u308B#kansaimath110",
  "id" : 312780622441611265,
  "created_at" : "2013-03-16 04:21:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312780361383944193",
  "text" : "f(x)=|x|\u306F\u4E00\u70B9\u3067\u306F\u5FAE\u5206\u306F\u3067\u304D\u306A\u3044#kansaimath110",
  "id" : 312780361383944193,
  "created_at" : "2013-03-16 04:20:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312780182241034240",
  "text" : "|f|(x)=|f(x)|\u3068\u3057\u3066f(x)=x\u306B\u3064\u3044\u3066\u8003\u3048\u308B\u306E\u306F\u9AD8\u6821\u3067\u3082\u3084\u3063\u305F\u304C\u3053\u308C\u304C\u80CC\u666F\u306B\u3042\u308B #kansaimath110",
  "id" : 312780182241034240,
  "created_at" : "2013-03-16 04:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312779711338147841",
  "text" : "\u4E8C\u3064\u76EE\u3001\u95A2\u6570\u306E\u7D76\u5BFE\u5024\u3092\u3068\u308B\u3068\u6ED1\u3089\u304B\u3055\u304C\u4E0B\u304C\u308B\u304B\uFF1F #kansaimath110",
  "id" : 312779711338147841,
  "created_at" : "2013-03-16 04:17:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312779340821708801",
  "text" : "\u5224\u4F8B\u306F\u3069\u3061\u3089\u3082hoge-hoge =0\u306E\u5F62\u3092\u3057\u3066\u3044\u308B #kansaimath110",
  "id" : 312779340821708801,
  "created_at" : "2013-03-16 04:16:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312778959442042880",
  "text" : "\u307E\u305FF(R)\\F^0(R)\u3082\u74B0\u306B\u306A\u3089\u306A\u3044 #kansaimath110",
  "id" : 312778959442042880,
  "created_at" : "2013-03-16 04:14:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312778687512719362",
  "text" : "\u3055\u3063\u304D\u306E\u53CD\u4F8B\u3068\u3057\u3066R\\Q(\u7121\u7406\u6570)\u306F\u74B0\u306B\u306A\u3089\u306A\u3044 #kansaimath110",
  "id" : 312778687512719362,
  "created_at" : "2013-03-16 04:13:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 70, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312778398323843072",
  "text" : "\u8A18\u53F7Q:\u6709\u7406\u6570\u5168\u4F53,R:\u5B9F\u6570\u5168\u4F53,I:R\u306E\u958B\u533A\u9593,F(I):I\u4E0A\u306E\u95A2\u6570\u304C\u4F5C\u308B\u74B0,f^k(I):k\u56DE\u5FAE\u5206\u53EF\u80FD\u306A\u95A2\u6570\u304C\u4F5C\u308B\u74B0\u3001k=0\u306E\u6642\u306F\u9023\u7D9A #kansaimath110",
  "id" : 312778398323843072,
  "created_at" : "2013-03-16 04:12:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312777625955336192",
  "text" : "i.e \u74B0\u304B\u3089\u90E8\u5206\u74B0\u9664\u3044\u305F\u3089\u74B0\u306B\u306A\u308B\u304B\uFF1F #kansaimath110",
  "id" : 312777625955336192,
  "created_at" : "2013-03-16 04:09:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312777454781612032",
  "text" : "\u80CC\u666F\u306B\u3042\u308B\u7406\u8AD6\u3084\u5B9A\u7406\u306B\u3082\u6C17\u3092\u914D\u3089\u306A\u304F\u3061\u3083\u3044\u3051\u306A\u3044 #kansaimath110",
  "id" : 312777454781612032,
  "created_at" : "2013-03-16 04:08:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 38, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312777388943618049",
  "text" : "\u4E00\u3064\u306E\u4F8B\u304B\u3089\u8907\u6570\u306E\u4F8B\u304C\u51FA\u3066\u6765\u305F\u308A\u3059\u308B\u3001\u4F8B\u306B\u3082\u8272\u3005\u306A\u4F5C\u308A\u65B9\u304C\u3042\u308A\u3001\u5FDC\u7528\u304C\u805E\u304F #kansaimath110",
  "id" : 312777388943618049,
  "created_at" : "2013-03-16 04:08:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312777268957163520",
  "text" : "\u554F\u984C\u3092\u89E3\u3044\u3066\u3068\u554F\u984C\u304C\u307E\u305F\u751F\u3058\u308B\u3053\u3068\u3082\u3042\u308B #kansaimath110",
  "id" : 312777268957163520,
  "created_at" : "2013-03-16 04:08:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776890521886720",
  "text" : "\u3082\u3068\u306B\u306A\u308B\u554F\u984C\u304C\u3042\u308C\u3070\u554F\u984C\u4F5C\u6210\u306F\u66F4\u306B\u697D\u306B\u306A\u308B(\u6761\u4EF6\u3092\u843D\u3068\u3059\u7B49) #kansaimath110",
  "id" : 312776890521886720,
  "created_at" : "2013-03-16 04:06:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776744845320192",
  "text" : "\u5177\u73FE\u5316\u306E\u8A13\u7DF4\u3068\u3057\u3066\u826F\u3044\u306E\u304C\u53CD\u4F8B\u3092\u4F5C\u3063\u305F\u308A\u3059\u308B\u3053\u3068 #kansaimath110",
  "id" : 312776744845320192,
  "created_at" : "2013-03-16 04:06:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776633033560064",
  "text" : "\u66D6\u6627\u306A\u8CEA\u554F\u306B\u306F\u66D6\u6627\u306A\u7B54\u3048\u3057\u304B\u306A\u3044 #kansaimath110",
  "id" : 312776633033560064,
  "created_at" : "2013-03-16 04:05:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776500468391936",
  "text" : "\u554F\u984C\u306E\u6761\u4EF6\u3092\u5177\u4F53\u5316\u3057\u306A\u3044\u3068\u7B54\u3048\u3082\u5177\u4F53\u5316\u3057\u306A\u3044 #kansaimath110",
  "id" : 312776500468391936,
  "created_at" : "2013-03-16 04:05:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776321681993728",
  "text" : "\u554F\u984C\u304C\u66D6\u6627\u3060\u3068\u7B54\u3048\u306B\u304F\u3044 #kansaimath110",
  "id" : 312776321681993728,
  "created_at" : "2013-03-16 04:04:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776237489729537",
  "text" : "\u611F\u899A\u3092\u5177\u4F53\u5316\u3059\u308B\u8A13\u7DF4\u306B\u306A\u308B\uFF01 #kansaimath110",
  "id" : 312776237489729537,
  "created_at" : "2013-03-16 04:04:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776162810142720",
  "text" : "\u554F\u984C\u3092\u4F5C\u308B\u8A13\u7DF4\u3092\u3057\u3088\u3046\uFF01 #kansaimath110",
  "id" : 312776162810142720,
  "created_at" : "2013-03-16 04:03:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776057294057472",
  "text" : "\u81EA\u554F\u81EA\u7B54\u3057\u3066\u53CD\u4F8B\u3092\u4F5C\u308D\u3046 #kansaimath110",
  "id" : 312776057294057472,
  "created_at" : "2013-03-16 04:03:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 10, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312776014667317248",
  "text" : "\u53CD\u4F8B\u3092\u4F5C\u3063\u3066\u904A\u307C\u3046 #kansaimath110",
  "id" : 312776014667317248,
  "created_at" : "2013-03-16 04:03:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath110",
      "indices" : [ 16, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312774859098824704",
  "text" : "\u76F8\u8EE2\u79FBP\u3055\u3093\u306Ehogehoge #kansaimath110",
  "id" : 312774859098824704,
  "created_at" : "2013-03-16 03:58:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312742239455555585",
  "geo" : { },
  "id_str" : "312745453080956928",
  "in_reply_to_user_id" : 91551881,
  "text" : "@t_uda \u3042\u3068\u3067\u3044\u3044\u3093\u3067\u53D7\u4ED8\u3057\u3066\u304F\u3060\u3055\u3044\u301C",
  "id" : 312745453080956928,
  "in_reply_to_status_id" : 312742239455555585,
  "created_at" : "2013-03-16 02:01:41 +0000",
  "in_reply_to_screen_name" : "t_uda",
  "in_reply_to_user_id_str" : "91551881",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312722275336077315",
  "text" : "\u9752\u3044\u8155\u7AE0\u30DE\u30F3\u304C\u904B\u55B6\u3067\u3059 #kansaimath",
  "id" : 312722275336077315,
  "created_at" : "2013-03-16 00:29:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath",
      "indices" : [ 4, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312722078585458688",
  "text" : "\u8A98\u5C0E\u30A1 #kansaimath",
  "id" : 312722078585458688,
  "created_at" : "2013-03-16 00:28:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312700147253534721",
  "text" : "\u3064\u3069\u3044\u306B\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u306E\u5149\u304C\u6E80\u3061\u308B\u6642\u3082\u8FD1\u3044",
  "id" : 312700147253534721,
  "created_at" : "2013-03-15 23:01:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312699998452187137",
  "text" : "RT @koizumi_fifty: \u591A\u5206\u30DE\u30A4\u30AF\u30C6\u30B9\u30C8\u7684\u306A\u5834\u9762\u3067\u300C\u4E16\u754C\u306B\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u306E\u5149\u3092\u30FC\uFF01\u300D\u3068\u3044\u3046\u306E\u3067\u3001\u5FC3\u3042\u308B\u65B9\u306F\u300C\u5149\u3092\u30FC\uFF01\u300D\u3068\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312697866386808832",
    "text" : "\u591A\u5206\u30DE\u30A4\u30AF\u30C6\u30B9\u30C8\u7684\u306A\u5834\u9762\u3067\u300C\u4E16\u754C\u306B\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u306E\u5149\u3092\u30FC\uFF01\u300D\u3068\u3044\u3046\u306E\u3067\u3001\u5FC3\u3042\u308B\u65B9\u306F\u300C\u5149\u3092\u30FC\uFF01\u300D\u3068\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    "id" : 312697866386808832,
    "created_at" : "2013-03-15 22:52:35 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 312699998452187137,
  "created_at" : "2013-03-15 23:01:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312697243968872448",
  "geo" : { },
  "id_str" : "312697363233902593",
  "in_reply_to_user_id" : 819871357,
  "text" : "@kansaimath_3rd \u4E86\u89E3\u3067\u3059",
  "id" : 312697363233902593,
  "in_reply_to_status_id" : 312697243968872448,
  "created_at" : "2013-03-15 22:50:35 +0000",
  "in_reply_to_screen_name" : "kansaimath",
  "in_reply_to_user_id_str" : "819871357",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    }, {
      "name" : "\u79C1\u81EA\u8EAB\u8A00\u308F\u305A\u3082\u304C\u306A\u30D8\u30C3\u30C9\u30F3\u30DB\u30DB",
      "screen_name" : "ysgr_sasakure",
      "indices" : [ 8, 22 ],
      "id_str" : "281368452",
      "id" : 281368452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312696992725864448",
  "geo" : { },
  "id_str" : "312697188285300736",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p @ysgr_sasakure \u300C\u9045\u523B\u3057\u3066\u305F\u3089\u89B3\u5149\u3057\u305F\u300D\u306B\u7A7A\u76EE",
  "id" : 312697188285300736,
  "in_reply_to_status_id" : 312696992725864448,
  "created_at" : "2013-03-15 22:49:53 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312696871426588672",
  "text" : "\u4ECA\u3059\u3050\u5FC5\u8981\u306A\u3089\u30E0\u30C0\u306A\u30EA\u30D7\u3060\u3063\u305F\u306A",
  "id" : 312696871426588672,
  "created_at" : "2013-03-15 22:48:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312696554085552128",
  "geo" : { },
  "id_str" : "312696789503442944",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u3064\u3044\u305F\u3089\u8CB8\u3057\u305F\u3052\u308B\u304B\u3089\u8CB7\u308F\u306A\u304F\u3066\u3088\u3057",
  "id" : 312696789503442944,
  "in_reply_to_status_id" : 312696554085552128,
  "created_at" : "2013-03-15 22:48:18 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312696663401713665",
  "text" : "\u305D\u308A\u3083\u8AB0\u3082\u5C45\u306A\u3044\u3088\u306D",
  "id" : 312696663401713665,
  "created_at" : "2013-03-15 22:47:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312696601774792705",
  "text" : "( ^o^)\uFF1C\u3064\u3069\u3044\u3060\uFF01\n ( \u02D8\u2296\u02D8) \u3002o(\u5F85\u3066\u3088\uFF1F\u306A\u3093\u3067\u8AB0\u3082\u5C45\u306A\u3044\u3093\u3060\uFF1F)\n |Twitter| \u2517(\u260B\uFF40 )\u2513\u4E09 \n( \u25E0\u203F\u25E0 )\u261B \u8AB0\u3088\u308A\u65E9\u3044\u73FE\u5730\u5165\u308A\u2582\u2585\u2587\u2588\u2593\u2592\u2591(\u2019\u03C9\u2019)\u2591\u2592\u2593\u2588\u2587\u2585\u2582 \u3046\u308F\u3042\u3042\u3042\u3042",
  "id" : 312696601774792705,
  "created_at" : "2013-03-15 22:47:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312696069450510337",
  "geo" : { },
  "id_str" : "312696251411988480",
  "in_reply_to_user_id" : 819871357,
  "text" : "@kansaimath_3rd \u3042\u308C\uFF1F\u56DB\u6642\u3055\u3093\u3068\u304B\u306B\u9001\u3063\u3066\u305F\u30EA\u30D7\u30828:45\u3068\u304B8:55\u3068\u304B\u3067\u3057\u305F\u3063\u3051\uFF1F",
  "id" : 312696251411988480,
  "in_reply_to_status_id" : 312696069450510337,
  "created_at" : "2013-03-15 22:46:10 +0000",
  "in_reply_to_screen_name" : "kansaimath",
  "in_reply_to_user_id_str" : "819871357",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312695969491861504",
  "text" : "\u30E1\u30E2\u3063\u3066\u304A\u3051\u3088",
  "id" : 312695969491861504,
  "created_at" : "2013-03-15 22:45:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312695930598084608",
  "text" : "\u3064\u3044\u3067\u306B\u5F85\u3061\u5408\u308F\u305B\u5834\u6240\u3082\u308F\u304B\u3089\u3093\u307D\u3093(^^)(^^)(^^)\u4F53\u305F\u3089\u304F(^^)(^^)(^^)",
  "id" : 312695930598084608,
  "created_at" : "2013-03-15 22:44:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312695800708886529",
  "text" : "\u3053\u3068\u308A\u3055\u3093\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u6D88\u3048\u3066\u308B\u95A2\u4FC2\u3067\u5F85\u3061\u5408\u308F\u305B\u6642\u9593\u304C\u308F\u304B\u3089\u306A\u304F\u306A\u3063\u305F\u304C\u3053\u308C\u3082\u3057\u304B\u3057\u30661\u6642\u9593\u65E9\u3044\u3068\u304B\u305D\u3046\u3044\u3046\u3042\u308C\u304B",
  "id" : 312695800708886529,
  "created_at" : "2013-03-15 22:44:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312688012343513089",
  "text" : "\u3068\u306F\u8A00\u3048\u771F\u9762\u76EE\u306A\u8A71\"\u89E3\u306A\u3057\"\u304C\u8A31\u3055\u308C\u308B\u306E(\u9650\u5B9A\u7684\u3068\u306F\u3044\u3048)\u6570\u5B66\u3060\u3051\u3060\u3057\u3042\u308B\u7A2E\u5F53\u7136\u306E\u7591\u554F\u304B\u3082\uFF1F",
  "id" : 312688012343513089,
  "created_at" : "2013-03-15 22:13:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312687766347603968",
  "text" : "\u3053\u308C\u8A00\u3044\u305F\u304B\u3063\u305F\u3060\u3051\u3067\u3059()",
  "id" : 312687766347603968,
  "created_at" : "2013-03-15 22:12:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312687706553606144",
  "text" : "\u89E3\u306A\u3057\u304C\u53D7\u3051\u5165\u308C\u3089\u308C\u306A\u3044\u306E\u306F\u8003\u3048\u305F\u7532\u6590\u304C\u306A\u3044\u304B\u3089\u3067\u306F\uFF1F\uFF1F",
  "id" : 312687706553606144,
  "created_at" : "2013-03-15 22:12:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u306A\u304B\u304C\u3076\u3088\u3076\u3088",
      "screen_name" : "onaka_buyo",
      "indices" : [ 3, 14 ],
      "id_str" : "145221588",
      "id" : 145221588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/CAs03YMMJa",
      "expanded_url" : "http:\/\/feedly.com\/k\/15Rlgd8",
      "display_url" : "feedly.com\/k\/15Rlgd8"
    } ]
  },
  "geo" : { },
  "id_str" : "312687644209455104",
  "text" : "RT @onaka_buyo: \"\u30BC\u30ED\u3067\u5272\u308B\u3068\u30FB\u30FB\u30FB\uFF1F\" http:\/\/t.co\/CAs03YMMJa  \u307E\u305F\u6016\u3044\u4EBA\u305F\u3061\u304C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.feedly.com\" rel=\"nofollow\"\u003Efeedly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/CAs03YMMJa",
        "expanded_url" : "http:\/\/feedly.com\/k\/15Rlgd8",
        "display_url" : "feedly.com\/k\/15Rlgd8"
      } ]
    },
    "geo" : { },
    "id_str" : "312686566264942592",
    "text" : "\"\u30BC\u30ED\u3067\u5272\u308B\u3068\u30FB\u30FB\u30FB\uFF1F\" http:\/\/t.co\/CAs03YMMJa  \u307E\u305F\u6016\u3044\u4EBA\u305F\u3061\u304C",
    "id" : 312686566264942592,
    "created_at" : "2013-03-15 22:07:41 +0000",
    "user" : {
      "name" : "\u304A\u306A\u304B\u304C\u3076\u3088\u3076\u3088",
      "screen_name" : "onaka_buyo",
      "protected" : false,
      "id_str" : "145221588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1807110627\/buyo-3_normal.png",
      "id" : 145221588,
      "verified" : false
    }
  },
  "id" : 312687644209455104,
  "created_at" : "2013-03-15 22:11:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kansaimath",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312681064596398080",
  "text" : "RT @kansaimath_3rd: \u304A\u306F\u3074\u3088\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01 \u3064\u3069\u3044\u3067\u3059\u306D\uFF01\uFF01\uFF01\uFF01 \u5927\u5909\u5BD2\u3044\u3067\u3059\u304C\u3001\u4ECA\u65E5\uFF11\u65E5\u697D\u3057\u307F\u307E\u3057\u3087\u3046\uFF01\uFF01\uFF01\uFF01\uFF01 (\u3053\u3068\u308A\u3093) #kansaimath",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kansaimath",
        "indices" : [ 56, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312680953543798784",
    "text" : "\u304A\u306F\u3074\u3088\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01 \u3064\u3069\u3044\u3067\u3059\u306D\uFF01\uFF01\uFF01\uFF01 \u5927\u5909\u5BD2\u3044\u3067\u3059\u304C\u3001\u4ECA\u65E5\uFF11\u65E5\u697D\u3057\u307F\u307E\u3057\u3087\u3046\uFF01\uFF01\uFF01\uFF01\uFF01 (\u3053\u3068\u308A\u3093) #kansaimath",
    "id" : 312680953543798784,
    "created_at" : "2013-03-15 21:45:23 +0000",
    "user" : {
      "name" : "\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044",
      "screen_name" : "kansaimath",
      "protected" : false,
      "id_str" : "819871357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558444210320191490\/SC7oiFvZ_normal.jpeg",
      "id" : 819871357,
      "verified" : false
    }
  },
  "id" : 312681064596398080,
  "created_at" : "2013-03-15 21:45:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312677609882390529",
  "text" : "\u306C\u30FC\u3093\u3001\u3082\u305E\u3082\u305E\u3001\u3080\u304F\u308A",
  "id" : 312677609882390529,
  "created_at" : "2013-03-15 21:32:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312521074120200192",
  "text" : "\u30AB\u30D5\u30A7\u30A4\u30F3\u306F\u5348\u524D\u306B\u3057\u304B\u3068\u3063\u3066\u306A\u3044\u3057\u4ECA\u65E5\u3082\u65E9\u5BDD\u3057\u3066\u96C6\u3044\u306B\u5099\u3048\u307E\u3057\u3087\u3046\u304B\u306D\u3002\u5177\u4F53\u7684\u306B\u306F22\u6642\u524D\u306B\u3002",
  "id" : 312521074120200192,
  "created_at" : "2013-03-15 11:10:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312520854288359425",
  "text" : "\u4F1A\u5834\u5165\u308A\u304B\u3089\u306E\u9045\u523B",
  "id" : 312520854288359425,
  "created_at" : "2013-03-15 11:09:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312520709815554048",
  "text" : "\u304A\u6E6F\u3088\u308A\u767D\u6E6F\u306E\u65B9\u304C\u97FF\u304D\u304C\u3044\u3044\u306A",
  "id" : 312520709815554048,
  "created_at" : "2013-03-15 11:08:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312520512595169280",
  "text" : "\u304A\u6E6F\u98F2\u3093\u3067\u308B\u3051\u3069\u7D20\u6734",
  "id" : 312520512595169280,
  "created_at" : "2013-03-15 11:07:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79C1\u81EA\u8EAB\u8A00\u308F\u305A\u3082\u304C\u306A\u30D8\u30C3\u30C9\u30F3\u30DB\u30DB",
      "screen_name" : "ysgr_sasakure",
      "indices" : [ 0, 14 ],
      "id_str" : "281368452",
      "id" : 281368452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312520045521690624",
  "geo" : { },
  "id_str" : "312520152224788480",
  "in_reply_to_user_id" : 281368452,
  "text" : "@ysgr_sasakure \u9045\u523B\u3057\u307E\u305B\u3093\u3088\u3046\u2026",
  "id" : 312520152224788480,
  "in_reply_to_status_id" : 312520045521690624,
  "created_at" : "2013-03-15 11:06:25 +0000",
  "in_reply_to_screen_name" : "ysgr_sasakure",
  "in_reply_to_user_id_str" : "281368452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312496651854036992",
  "text" : "\u7206\u6483\u7528\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8J\u30DC\u30E0",
  "id" : 312496651854036992,
  "created_at" : "2013-03-15 09:33:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312495462940819456",
  "text" : "\u95A2\u897F\u306B\u305E\u304F\u305E\u304F\u3068\u3059\u3046\u304C\u304F\u5F92\u304C\u96C6\u3063\u3066\u884C\u304F\u306E\u3092TL\u3067\u773A\u3081\u3066\u3044\u308B",
  "id" : 312495462940819456,
  "created_at" : "2013-03-15 09:28:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312494987654885376",
  "text" : "\u3067\u3082\u307E\u3041\u30B5\u30F3\u30C0\u30FC\u30D5\u30A3\u30B9\u30C8\u3063\u3066\u30D6\u30E9\u30B9\u30C8\u30C9\u30FC\u30B6\u30FC\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u4EBA\u306B\u306F\u7D76\u5BFE\u4F1D\u308F\u3089\u306C",
  "id" : 312494987654885376,
  "created_at" : "2013-03-15 09:26:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312492793236946944",
  "text" : "\u30B5\u30F3\u30C0\u30FC\u30D5\u30A3\u30B9\u30C8\u671F\u5F85\u3057\u3066\u308B",
  "id" : 312492793236946944,
  "created_at" : "2013-03-15 09:17:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "indices" : [ 3, 11 ],
      "id_str" : "16331213",
      "id" : 16331213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thunderfist",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312492750304063488",
  "text" : "RT @kazoo04: \u545F\u304F\u3068\u304D\u306B\u300C\u304A\u524D\u305D\u308C1\u4E07post\u76EE\u3060\u3051\u3069\u305D\u3093\u306A\u30C4\u30A4\u30FC\u30C8\u3067\u3044\u3044\u306E\uFF1F\u300D\u3063\u3066\u8868\u793A\u3059\u308B\u6A5F\u80FD\u3064\u3051\u3088\u3046 #Thunderfist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thunderfist",
        "indices" : [ 46, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312492667143606272",
    "text" : "\u545F\u304F\u3068\u304D\u306B\u300C\u304A\u524D\u305D\u308C1\u4E07post\u76EE\u3060\u3051\u3069\u305D\u3093\u306A\u30C4\u30A4\u30FC\u30C8\u3067\u3044\u3044\u306E\uFF1F\u300D\u3063\u3066\u8868\u793A\u3059\u308B\u6A5F\u80FD\u3064\u3051\u3088\u3046 #Thunderfist",
    "id" : 312492667143606272,
    "created_at" : "2013-03-15 09:17:12 +0000",
    "user" : {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "protected" : false,
      "id_str" : "16331213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583129549694640129\/aPkbezAe_normal.png",
      "id" : 16331213,
      "verified" : false
    }
  },
  "id" : 312492750304063488,
  "created_at" : "2013-03-15 09:17:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312491828588978176",
  "text" : "\u3084\u306F\u308A\u307F\u308A\u3093\u306F\u6271\u3044\u304C\u96E3\u3057\u3044\u306A",
  "id" : 312491828588978176,
  "created_at" : "2013-03-15 09:13:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312491778303479808",
  "text" : "\u7167\u308A\u713C\u304D\u7F8E\u5473\u3057\u3044\u3051\u3069\u5473\u6FC3\u3044",
  "id" : 312491778303479808,
  "created_at" : "2013-03-15 09:13:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312488727517741056",
  "geo" : { },
  "id_str" : "312488975476596736",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01",
  "id" : 312488975476596736,
  "in_reply_to_status_id" : 312488727517741056,
  "created_at" : "2013-03-15 09:02:32 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312488548936871936",
  "text" : "\u3086\u308B\u30FC\u3044\u30D3\u30EA\u30E4\u30FC\u30C9\u30B5\u30FC\u30AF\u30EB\u3084\u3063\u3066\u307E\u3059\u3051\u3069\u306D",
  "id" : 312488548936871936,
  "created_at" : "2013-03-15 09:00:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312488377570189312",
  "text" : "\u7167\u308A\u713C\u304D\u30C1\u30AD\u30F3\u4F5C\u3063\u3066\u308B",
  "id" : 312488377570189312,
  "created_at" : "2013-03-15 09:00:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u304F\u307B\u304F\u3068",
      "screen_name" : "hokuhokuto",
      "indices" : [ 0, 11 ],
      "id_str" : "176634531",
      "id" : 176634531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312356173611401216",
  "geo" : { },
  "id_str" : "312356216699502592",
  "in_reply_to_user_id" : 176634531,
  "text" : "@hokuhokuto \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 312356216699502592,
  "in_reply_to_status_id" : 312356173611401216,
  "created_at" : "2013-03-15 00:15:00 +0000",
  "in_reply_to_screen_name" : "hokuhokuto",
  "in_reply_to_user_id_str" : "176634531",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312355576631918594",
  "text" : "\u3044\u3064\u304B\u7D50\u57CE\u5148\u751F\u306B\u3082\u3064\u3069\u3044\u6765\u3066\u6B32\u3057\u3044\u306D\u30FC",
  "id" : 312355576631918594,
  "created_at" : "2013-03-15 00:12:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312324592389726208",
  "text" : "\u3086\u308B\u308A\u3068\u5EF6\u9577\u3055\u308C\u305F\u6DF1\u591C\u52E2\u3092\u717D\u3063\u3066\u3044\u304F",
  "id" : 312324592389726208,
  "created_at" : "2013-03-14 22:09:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312324502275125248",
  "text" : "\u65E9\u8D77\u304D\u306F\u5FC3\u5730\u826F\u3044\u306A",
  "id" : 312324502275125248,
  "created_at" : "2013-03-14 22:08:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312324464832573440",
  "text" : "\u6E6F\u821F\u3067\u30B3\u30FC\u30D2\u30FC\u3068\u671D\u306E\u65E5\u5DEE\u3057\u3067QOL\u3060\u3060\u3042\u304C\u308A\u3067\u3042\u308B",
  "id" : 312324464832573440,
  "created_at" : "2013-03-14 22:08:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312308511889575936",
  "text" : "21\u30FC06\u6642\u306E\u795E\u30EA\u30BA\u30E0\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 312308511889575936,
  "created_at" : "2013-03-14 21:05:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312171380428910592",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 312171380428910592,
  "created_at" : "2013-03-14 12:00:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312170776071659520",
  "text" : "\u5BDD\u308B\u3068\u304B\u8A00\u3046\u9078\u629E\u80A2",
  "id" : 312170776071659520,
  "created_at" : "2013-03-14 11:58:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312169858185981952",
  "text" : "\u5589\u4E7E\u3044\u3066\u5589\u4E7E\u3044\u3066\u7720\u305F\u3044",
  "id" : 312169858185981952,
  "created_at" : "2013-03-14 11:54:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u897F",
      "screen_name" : "chinchikurim_ba",
      "indices" : [ 0, 16 ],
      "id_str" : "277901173",
      "id" : 277901173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312073711261990912",
  "geo" : { },
  "id_str" : "312073965017378816",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurim_ba \u5E73\u6C17\u3060\u3068\u601D\u3044\u307E\u3059\u3088\u30FC\u3001\u6C17\u304C\u5411\u3044\u305F\u3089\u53C2\u52A0\u3057\u3066\u4E0B\u3055\u3044\u306A",
  "id" : 312073965017378816,
  "in_reply_to_status_id" : 312073711261990912,
  "created_at" : "2013-03-14 05:33:25 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312073637102497792",
  "text" : "\u8010\u4E45\u30AA\u30D5\u3068\u306F\u540D\u3070\u304B\u308A\u306E\u9014\u4E2D\u53C2\u52A0\u3001\u9014\u4E2D\u9000\u5BA4\u3042\u308A\u306E\u3086\u308B\u3086\u308B\u30AA\u30D5\u4F1A\u3067\u3059\u3057",
  "id" : 312073637102497792,
  "created_at" : "2013-03-14 05:32:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u897F",
      "screen_name" : "chinchikurim_ba",
      "indices" : [ 0, 16 ],
      "id_str" : "277901173",
      "id" : 277901173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312073169936715776",
  "geo" : { },
  "id_str" : "312073471234539520",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurim_ba \u5927\u4E08\u592B\u3060\u3068\u601D\u3044\u307E\u3059\u3088\u30FC\u3001\u958B\u5E55\u3068\u3054\u98EF\u98DF\u3079\u308B\u6642\u4EE5\u5916\u57FA\u672C\u30CE\u30FC\u30BF\u30C3\u30C1\u3067\u3059\u3057",
  "id" : 312073471234539520,
  "in_reply_to_status_id" : 312073169936715776,
  "created_at" : "2013-03-14 05:31:28 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312072531106463745",
  "text" : "\u306C\u306E\u4EBA\u3053\u306E\u524D\u96C0\u8358\u3067\u3070\u3063\u305F\u308A\u4F1A\u3063\u3066\u5727\u5012\u7684\u9A5A\u304D",
  "id" : 312072531106463745,
  "created_at" : "2013-03-14 05:27:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "312072065979133952",
  "text" : "\u30B1\u30F3\u30BC\u30F3\uFF01[TwiPla] \u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 312072065979133952,
  "created_at" : "2013-03-14 05:25:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "312071917995696128",
  "text" : "\u30BB\u30F3\u30C7\u30F3\uFF01[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 312071917995696128,
  "created_at" : "2013-03-14 05:25:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312071331028033536",
  "text" : "\u30CE\u30FC\u30C8\u306B\u307E\u3068\u3081\u305F\u308A\u3059\u308B\u3079\u304D\u306A\u3093\u3060\u308D\u3046\u3051\u3069\u3001\u305D\u306E\u65B9\u6CD5\u3068\u8A00\u3046\u304B\u65B9\u5F0F\u3068\u8A00\u3046\u304B",
  "id" : 312071331028033536,
  "created_at" : "2013-03-14 05:22:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312071225713246210",
  "text" : "\u6570\u7406\u7CFB\u306E\u66F8\u7269\u306E\u8AAD\u307F\u65B9\u306F\u7A4D\u6975\u7684\u306B\u4ED6\u4EBA\u306B\u805E\u3044\u305F\u308A\u3001\u8A66\u884C\u932F\u8AA4\u3057\u3066\u307F\u3066\u306A\u3093\u3068\u306A\u304F\u308F\u304B\u308B\u3051\u3069\u3001\u6C17\u4ED8\u3051\u3070\u4EBA\u6587\u7CFB\u306E\u66F8\u7269\u306E\u8AAD\u307F\u65B9\u3088\u304F\u308F\u304B\u3089\u306A\u3044",
  "id" : 312071225713246210,
  "created_at" : "2013-03-14 05:22:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312070387594842113",
  "text" : "\u306C\u308B\u3044\u70B9\u3092\u9664\u3051\u3070\u7F8E\u5473\u3057\u3044\u30B3\u30FC\u30D2\u30FC\u3067\u3042\u308B",
  "id" : 312070387594842113,
  "created_at" : "2013-03-14 05:19:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312067065982877696",
  "text" : "\u3055\u3063\u304D\u306E\"\u50D5\u306F\u9055\u3046\u3068\u601D\u3046\"\u306F\u9ED9\u6BBA\u3055\u308C\u308B\u306E\u306F\u81EA\u7136\u306A\u306E",
  "id" : 312067065982877696,
  "created_at" : "2013-03-14 05:06:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312065794471235584",
  "text" : "\u3053\u308C\u50D5\u304C\u5909\u306A\u306E\u304B\u306D",
  "id" : 312065794471235584,
  "created_at" : "2013-03-14 05:00:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312065766608486400",
  "text" : "\u3053\u306E\u524D\u5B9F\u5BB6\u3067\u30C9\u30E9\u30DE\u898B\u3066\u305F\u3093\u3060\u3051\u3069\u3001\"\u4E0A\u53F8\u306E\u547D\u4EE4\u7121\u8996\u3057\u3066\u5358\u72EC\u884C\u52D5\u3057\u305F\u4E3B\u4EBA\u516C\u304C\u72AF\u4EBA\u3092\u8FFD\u3044\u8A70\u3081\u308B\u3082\u3001\u72AF\u4EBA\u306F\u6700\u5F8C\u81EA\u7206\u3057\u3066\u3001\u305D\u306E\u74E6\u792B\u306B\u5DFB\u304D\u8FBC\u307E\u308C\u305F\u4E3B\u4EBA\u516C\u304C\u30AE\u30EA\u30AE\u30EA\u3067\u52A9\u304B\u3063\u3066\u826F\u304B\u3063\u305F\u306D\"\u3063\u3066\u30AA\u30C1\u3060\u3063\u305F\u3002\u3053\u308C\u72AF\u4EBA\u6BBA\u3057\u3061\u3083\u3063\u3066\u308B\u3057\u660E\u3089\u304B\u306B\u30D0\u30C3\u30C9\u30A8\u30F3\u30C9\u3058\u3083\u3093\u3063\u3066\u5BB6\u65CF\u306B\u8A00\u3063\u305F\u3089\u602A\u8A1D\u306A\u9854\u3055\u308C\u305F",
  "id" : 312065766608486400,
  "created_at" : "2013-03-14 05:00:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312064785623699456",
  "text" : "\u3053\u308C\u9762\u767D\u304F\u306A\u3044\u306A\u30FC\u3001\u4ECA\u8A00\u3046\u3079\u304D\u3067\u306A\u3044\u306A\u30FC\u3068\u601D\u3044\u306A\u304C\u3089\u53E3\u306B\u3059\u308B\u80FD\u529B\u3060\u3051\u3092\u9AD8\u3081\u306622\u5E74\u9593\u751F\u304D\u3066\u304D\u305F\u7BC0\u3042\u308B",
  "id" : 312064785623699456,
  "created_at" : "2013-03-14 04:56:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312064609764929537",
  "text" : "\u3057\u304B\u3082\u3055\u3057\u3066\u9762\u767D\u304F\u306A\u3044\u3001\u77E5\u3063\u3066\u305F",
  "id" : 312064609764929537,
  "created_at" : "2013-03-14 04:56:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312064425194577920",
  "text" : "\u305A\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082(\u30CD\u30BF\u30DD\u30B9\u30C8\u3092\u75DB\u6068\u306E\u30BF\u30A4\u30D7\u30DF\u30B9\uFF01)",
  "id" : 312064425194577920,
  "created_at" : "2013-03-14 04:55:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312064281774538755",
  "text" : "\u864E\u8996\u7708\u305F\u3093(\u3082)",
  "id" : 312064281774538755,
  "created_at" : "2013-03-14 04:54:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312063438639726593",
  "text" : "\u50D5\u306F\u4E00\u822C\u7684\u3067\u306A\u3044\u3068\u601D\u3044\u307E\u3059\u304C",
  "id" : 312063438639726593,
  "created_at" : "2013-03-14 04:51:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312063374408183808",
  "text" : "\u98EF\u98DF\u3063\u305F\u3089\u570F\u8AD6\u306E\u6D41\u308C\u306F\u4E00\u822C\u7684\u3067\u306F\u306A\u3044\u306E\u304B",
  "id" : 312063374408183808,
  "created_at" : "2013-03-14 04:51:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312037299561050112",
  "text" : "\u4E0D\u601D\u8B70\u3068\u5BD2\u3044",
  "id" : 312037299561050112,
  "created_at" : "2013-03-14 03:07:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311927692314439681",
  "text" : "\u304A\u3084\u3059\u307F\u305B\u304B\u3044",
  "id" : 311927692314439681,
  "created_at" : "2013-03-13 19:52:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311927010257682432",
  "text" : "\u60C5\u5F31\u304C\u3061\u3083\u3093\u3068\u5B9A\u7FA9\u3055\u308C\u3066\u306A\u3044\u304B\u3089\u60C5\u5F31\u3092\u8131\u3059\u308B\u3053\u3068\u304C\u3067\u304D\u306A\u3044\u4E0D\u5177\u5408",
  "id" : 311927010257682432,
  "created_at" : "2013-03-13 19:49:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311926580165361664",
  "text" : "\u30D5\u30A1\u30A4\u30EB\u306E\u6574\u7406\u3068\u304B\u30EA\u30CD\u30FC\u30E0\u3068\u304B\u5F62\u5F0F\u5909\u63DB\u3068\u304B\u3084\u305F\u3089\u3081\u3063\u305F\u3089\u4E0A\u624B\u306B\u306A\u3063\u3066\u6765\u305F",
  "id" : 311926580165361664,
  "created_at" : "2013-03-13 19:47:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311925498672467969",
  "text" : "\u3053\u3053\u6570\u65E5\u5FC3\u3092\u75DB\u3081\u3066\u3044\u305F\u3061\u3087\u3063\u3068\u3057\u305F\u554F\u984C\u304C\u5727\u5012\u7684\u89E3\u6C7A\u3092\u898B\u3066\u7A4F\u3084\u304B\u306B\u7720\u308A\u306B\u3064\u3051\u308B",
  "id" : 311925498672467969,
  "created_at" : "2013-03-13 19:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311925314924208129",
  "text" : "\u3053\u308C1\u5468\u3057\u305F\u3089\u5BDD\u3088\u3046\u3068\u601D\u3063\u3066\u305FBGM\u304C2\u5468\u3057\u304B\u304B\u3063\u3066\u3066\u771F\u9854",
  "id" : 311925314924208129,
  "created_at" : "2013-03-13 19:42:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311914665783480323",
  "text" : "djuv\u5F62\u5F0F\u3092\u77E5\u3089\u306A\u3044\u7A0B\u5EA6\u306B\u306F\u60C5\u5F31\u3060\u3063\u305F\u304B\u3089\u307E\u305F\u4E00\u3064\u8CE2\u304F\u306A\u3063\u305F\u306A\uFF1F",
  "id" : 311914665783480323,
  "created_at" : "2013-03-13 19:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311885362572169216",
  "text" : "\u3046\u3093\u3001facebook\u306E\u65B9\u304C\u95C7\u304C\u6DF1\u3044",
  "id" : 311885362572169216,
  "created_at" : "2013-03-13 17:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311875476345999360",
  "text" : "\u51B7\u3048\u305F\u70AD\u9178\u6C34\u304C\u7F8E\u5473\u3057\u3044",
  "id" : 311875476345999360,
  "created_at" : "2013-03-13 16:24:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311856119326851073",
  "geo" : { },
  "id_str" : "311856466048974850",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 311856466048974850,
  "in_reply_to_status_id" : 311856119326851073,
  "created_at" : "2013-03-13 15:09:10 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311856457626812417",
  "text" : "\u982D\u75DB\u3082\u3055\u3055\u3084\u304B\u306B\u3042\u308B\u3051\u3069\u3001\u3053\u308C\u306F\u80A9\u3053\u308A\u7531\u6765\u3060\u306A",
  "id" : 311856457626812417,
  "created_at" : "2013-03-13 15:09:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311855388913983488",
  "text" : "\u85AC\u98F2\u307F\u305D\u3073\u308C\u308B\u3068\u3084\u306F\u308A\u8F9B\u3044",
  "id" : 311855388913983488,
  "created_at" : "2013-03-13 15:04:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311855288850456577",
  "text" : "\u6628\u65E5\u5F8C\u8F29\u3068\u82B1\u7C89\u30D3\u30B8\u30CD\u30B9\u306E\u5229\u76CA\u3068\u82B1\u7C89\u306B\u3088\u308B\u4F5C\u696D\u52B9\u7387\u306E\u4F4E\u4E0B\u306B\u3088\u308B\u88AB\u5BB3\u3068\u306E\u5929\u79E4\u306E\u8A71\u3057\u305F",
  "id" : 311855288850456577,
  "created_at" : "2013-03-13 15:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311854849790734336",
  "text" : "\u7E70\u308A\u8FD4\u3055\u308C\u308B\u304F\u3057\u3083\u307F\u3067\u9F3B\u3082\u305D\u3046\u3060\u304C\u5589\u3082\u75DB\u3044",
  "id" : 311854849790734336,
  "created_at" : "2013-03-13 15:02:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311852523961065472",
  "text" : "\u89E3\u6C7A\u306E\u5834\u9762\u3068\u304B\u3001\u5834\u6240\u3068\u304B\u304B\u306A\u308A\u9055\u3046",
  "id" : 311852523961065472,
  "created_at" : "2013-03-13 14:53:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311852244574277634",
  "text" : "\u9055\u548C\u611F\u306F\u306A\u3044\u3051\u308C\u3069\u3001\u5316\u7269\u306E\u6642\u70B9\u3067\u732B\u7269\u3063\u3066\u51FA\u7248\u306F\u3055\u308C\u3066\u306A\u3044\u304B\u3089\u5F53\u7136\u30A2\u30CB\u30E1\u5316\u306B\u3064\u3044\u3066\u3082\u8003\u3048\u3089\u308C\u3066\u306A\u304B\u3063\u305F\u306E\u304B\u306D",
  "id" : 311852244574277634,
  "created_at" : "2013-03-13 14:52:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311852062906400769",
  "text" : "\u5316\u7269\u8A9E\u306E\u3064\u3070\u3055\u30AD\u30E3\u30C3\u30C8\u3067\u306E\u56DE\u60F3\u3068\u3057\u3066\u306E\u3064\u3070\u3055\u30D5\u30A1\u30DF\u30EA\u30FC\u306F\u3001\u732B\u7269\u8A9E\u306E\u672C\u7DE8\u3067\u306E\u3064\u3070\u3055\u30D5\u30A1\u30DF\u30EA\u30FC\u3068\u3061\u3087\u3063\u3068\u9055\u3046\u306A\u3041",
  "id" : 311852062906400769,
  "created_at" : "2013-03-13 14:51:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "river4361",
      "screen_name" : "river4361",
      "indices" : [ 0, 10 ],
      "id_str" : "2526962401",
      "id" : 2526962401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311771628918943745",
  "geo" : { },
  "id_str" : "311772404638687233",
  "in_reply_to_user_id" : 320494295,
  "text" : "@river4361 \u672C\u5F53\u3060\u3001\u76F8\u5909\u308F\u3089\u305A\u308F\u304B\u308A\u306B\u304F\u3044\u306A\u3001\u6559\u3048\u3066\u304F\u308C\u3066\u3042\u308A\u304C\u3068\u3046(^^)(^^)(^^)",
  "id" : 311772404638687233,
  "in_reply_to_status_id" : 311771628918943745,
  "created_at" : "2013-03-13 09:35:08 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "river4361",
      "screen_name" : "river4361",
      "indices" : [ 0, 10 ],
      "id_str" : "2526962401",
      "id" : 2526962401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311770504421838848",
  "geo" : { },
  "id_str" : "311771424689909760",
  "in_reply_to_user_id" : 320494295,
  "text" : "@river4361 \u3048\u3063\u3001\u3069\u308C\uFF1F",
  "id" : 311771424689909760,
  "in_reply_to_status_id" : 311770504421838848,
  "created_at" : "2013-03-13 09:31:14 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "311769993354301440",
  "text" : "[TwiPla] \u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 311769993354301440,
  "created_at" : "2013-03-13 09:25:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311769947909025792",
  "text" : "[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 311769947909025792,
  "created_at" : "2013-03-13 09:25:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "311691370408599553",
  "text" : "\u305B\u3093\u3067\u3093[TwiPla] \u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 311691370408599553,
  "created_at" : "2013-03-13 04:13:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311691198567960576",
  "text" : "\u305B\u3093\u3067\u3093[TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 311691198567960576,
  "created_at" : "2013-03-13 04:12:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311689873088188418",
  "text" : "13\u6642\u9593\u3082\u7720\u3063\u3066\u3044\u305F\u2026",
  "id" : 311689873088188418,
  "created_at" : "2013-03-13 04:07:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/en188wOtXy",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=kenkov",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311519935962705920",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/en188wOtXy",
  "id" : 311519935962705920,
  "created_at" : "2013-03-12 16:51:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311488416695070720",
  "text" : "\u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 311488416695070720,
  "created_at" : "2013-03-12 14:46:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311488370348023809",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u6BBA\u3059\u3079\u3057",
  "id" : 311488370348023809,
  "created_at" : "2013-03-12 14:46:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311488126591827968",
  "text" : "base case\u306F\u6C17\u6301\u3061\u3044\u3044\u305C",
  "id" : 311488126591827968,
  "created_at" : "2013-03-12 14:45:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311486823778111488",
  "geo" : { },
  "id_str" : "311487972728008704",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u5408\u683C\u8005\u306B\u306A\u308A\u307E\u3057\u3087\u3046\uFF01\uFF01\u9811\u5F35\u3063\u3066\uFF01\uFF01",
  "id" : 311487972728008704,
  "in_reply_to_status_id" : 311486823778111488,
  "created_at" : "2013-03-12 14:44:54 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "311476999371751424",
  "text" : "\u5BA3\u4F1D\u30A1\uFF01\uFF01[TwiPla] \u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 311476999371751424,
  "created_at" : "2013-03-12 14:01:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311476890059829248",
  "text" : "\u5BA3\u4F1D\u30A1\uFF01 [TwiPla] \u9644\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 311476890059829248,
  "created_at" : "2013-03-12 14:00:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311446591263354880",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 311446591263354880,
  "created_at" : "2013-03-12 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311325390884978690",
  "text" : "@kotorin_z \u4E8C\u4EBA\u3057\u304B\u5C45\u306A\u3044\u3067\u3059",
  "id" : 311325390884978690,
  "created_at" : "2013-03-12 03:58:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311325022289547264",
  "text" : "\u305D\u3082\u305D\u3082\u30EA\u30D7\u3082\u3089\u3063\u305F\u4EBA\u306E\u3046\u3061\u4F55\u4EBA\u304C\u6765\u308B\u306E\u304B\u308F\u304B\u3089\u3093\u307D\u3093",
  "id" : 311325022289547264,
  "created_at" : "2013-03-12 03:57:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311324919025774592",
  "text" : "\u6848\u306E\u5B9A\u96C6\u307E\u308A\u60AA\u904E\u304E\u3067\u3059",
  "id" : 311324919025774592,
  "created_at" : "2013-03-12 03:56:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 3, 15 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311324800134033408",
  "text" : "RT @hymathlogic: \u30A8\u30F3\u30C9\u541B\u3057\u304B\u5C45\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311324553597026305",
    "text" : "\u30A8\u30F3\u30C9\u541B\u3057\u304B\u5C45\u306A\u3044",
    "id" : 311324553597026305,
    "created_at" : "2013-03-12 03:55:32 +0000",
    "user" : {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "protected" : false,
      "id_str" : "295467216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439420014165106688\/B9GEeIe7_normal.jpeg",
      "id" : 295467216,
      "verified" : false
    }
  },
  "id" : 311324800134033408,
  "created_at" : "2013-03-12 03:56:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311318673979764737",
  "text" : "@potezaki \u30CA\u30A4\u30B9\u91D1\u6CA2\uFF01",
  "id" : 311318673979764737,
  "created_at" : "2013-03-12 03:32:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311315873476509696",
  "text" : "\u56DB\u53F7\u9928\u3060\u3063\u305F",
  "id" : 311315873476509696,
  "created_at" : "2013-03-12 03:21:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311315838873526273",
  "text" : "\u56DB\u53F7\u9593\u306E\u88CF\u3067\u65E5\u5411\u307C\u3063\u3053\u3057\u3066\u308B",
  "id" : 311315838873526273,
  "created_at" : "2013-03-12 03:20:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311288212838559744",
  "text" : "3\u6642\u9593\u3060\u3051\u7720\u3063\u305F\u3001\u8D77\u304D\u305F",
  "id" : 311288212838559744,
  "created_at" : "2013-03-12 01:31:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311244039020236800",
  "text" : "\u4E2D\u592E\u306F8\u6642\u304B\u3089\u3001\u5317\u90E8\u306F10\u6642\u304B\u3089\u304B",
  "id" : 311244039020236800,
  "created_at" : "2013-03-11 22:35:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311243609859031041",
  "text" : "\u5317\u90E8\u5F85\u6A5F\u304B\u306A\uFF1F\u98DF\u5802\u4F55\u6642\u304B\u3089\u7A7A\u3044\u3066\u305F\u3063\u3051\u304B",
  "id" : 311243609859031041,
  "created_at" : "2013-03-11 22:33:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311243341834641408",
  "text" : "\u3057\u308C\u3063\u30683\u6642\u9593\u304F\u3089\u3044\u5BDD\u308B\u306E\u304C\u305F\u3076\u3093\u6B63\u89E3\u3060\u304C\u3001\u3069\u3053\u3067\u5BDD\u308B\u304B\u3002",
  "id" : 311243341834641408,
  "created_at" : "2013-03-11 22:32:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311243115057000450",
  "text" : "13\u6642\u306B\u5F85\u3061\u5408\u308F\u305B\u3002\u30B5\u30C4\u30D0\u30C4\uFF01",
  "id" : 311243115057000450,
  "created_at" : "2013-03-11 22:31:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311241603287244801",
  "text" : "I'm at \u304A\u8179\u3078\u3063\u305F",
  "id" : 311241603287244801,
  "created_at" : "2013-03-11 22:25:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311223225839415296",
  "text" : "\u9EBB\u96C0\u30AA\u30D5\u3067\u4E00\u756A\u5927\u5909\u306A\u306E\u306F\u4EBA\u6570\u30924\u306E\u500D\u6570\u306B\u8ABF\u6574\u3059\u308B\u3053\u3068",
  "id" : 311223225839415296,
  "created_at" : "2013-03-11 21:12:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/P6vsSKwZd9",
      "expanded_url" : "http:\/\/twipla.jp\/polls\/44787",
      "display_url" : "twipla.jp\/polls\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311222865527713793",
  "text" : "\u65E5\u4ED8\u306F\u5897\u3084\u3057\u307E\u3057\u305F \u958B\u50AC\u65E5\uFF1F http:\/\/t.co\/P6vsSKwZd9",
  "id" : 311222865527713793,
  "created_at" : "2013-03-11 21:11:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311221926007799808",
  "text" : "\u9EBB\u96C0\u30AA\u30D5\u524D\u56DE\u306E\u30EB\u30FC\u30EB\u8A2D\u5B9A\u304C\u66F8\u3044\u3066\u3042\u3063\u305F\u30DA\u30FC\u30B8\u304C\u306A\u304F\u306A\u3063\u3061\u3083\u3063\u305F\u304B\u3089\u305D\u308C\u3063\u307D\u304F\u3067\u3063\u3061\u4E0A\u3052\u305F\u3002\u4E0D\u5E73\u4E0D\u6E80\u7B49\u3042\u308C\u3070\u3069\u3046\u305E\u3002",
  "id" : 311221926007799808,
  "created_at" : "2013-03-11 21:07:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311216571483844609",
  "geo" : { },
  "id_str" : "311221737633222656",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u3060\u3063\u305F\u30894\u6708\u306F\u3044\u3063\u3066\u304B\u3089\u3067\u3082\u826F\u3044\u304B\u3082\u306A\u30FC",
  "id" : 311221737633222656,
  "in_reply_to_status_id" : 311216571483844609,
  "created_at" : "2013-03-11 21:06:59 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twipla.jp\" rel=\"nofollow\"\u003ETwiPla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/7QXZdiaOeM",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44790",
      "display_url" : "twipla.jp\/events\/44790"
    } ]
  },
  "geo" : { },
  "id_str" : "311221494917238784",
  "text" : "\u7B2C\u4E8C\u56DE\uFF2B\uFF35\u30AF\u30E9\u30B9\u30BF\u5468\u8FBA\u5065\u5168\u9EBB\u96C0\u30AA\u30D5 http:\/\/t.co\/7QXZdiaOeM",
  "id" : 311221494917238784,
  "created_at" : "2013-03-11 21:06:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311215350245097473",
  "geo" : { },
  "id_str" : "311216407037747200",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u306C\u3001\u76F2\u70B9\u3067\u3042\u3063\u305F.4\u6708\u5B66\u6821\u59CB\u307E\u308B\u306E\u3044\u3064\u304B\u3089\u3060\u3063\u3051\u304B.",
  "id" : 311216407037747200,
  "in_reply_to_status_id" : 311215350245097473,
  "created_at" : "2013-03-11 20:45:48 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311215208649617409",
  "text" : "\u9EBB\u96C0\u30AA\u30D5\u3082\u4F01\u753B\u3057\u307E\u305B\u3046",
  "id" : 311215208649617409,
  "created_at" : "2013-03-11 20:41:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 2, 9 ],
      "id_str" : "239486216",
      "id" : 239486216
    }, {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 10, 20 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/P6vsSKwZd9",
      "expanded_url" : "http:\/\/twipla.jp\/polls\/44787",
      "display_url" : "twipla.jp\/polls\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311215127091372032",
  "text" : ". @khulud @piano2683 @Kyo_Hiiragi \u3044\u307E\u3055\u3089\u30A2\u30F3\u30B1\u30FC\u30C8\u4F5C\u3063\u305F\u306E\u3067\u304A\u77E5\u3089\u305B\u3057\u3066\u304A\u304D\u307E\u3059 http:\/\/t.co\/P6vsSKwZd9",
  "id" : 311215127091372032,
  "created_at" : "2013-03-11 20:40:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311214499250184193",
  "text" : "\u4ECA\u66F4\u30A2\u30F3\u30B1\u30FC\u30C8\u3067\u304D\u308B\u4E8B\u306B\u6C17\u4ED8\u3044\u305F\u56F3",
  "id" : 311214499250184193,
  "created_at" : "2013-03-11 20:38:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/P6vsSKwZd9",
      "expanded_url" : "http:\/\/twipla.jp\/polls\/44787",
      "display_url" : "twipla.jp\/polls\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311214397450248194",
  "text" : "\u958B\u50AC\u65E5\uFF1F http:\/\/t.co\/P6vsSKwZd9",
  "id" : 311214397450248194,
  "created_at" : "2013-03-11 20:37:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311214071364059137",
  "text" : "\u65E5\u4ED8\u30D0\u30B7\u30C3\u3068\u6C7A\u3081\u305F\u65B9\u304C\u826F\u3044\u306E\u304B\u3001\u305D\u308C\u3068\u3082\u3042\u308B\u7A0B\u5EA6\u4EBA\u6570\u63C3\u3063\u305F\u3089\u591A\u6570\u6C7A\u3057\u305F\u65B9\u304C\u826F\u3044\u306E\u304B",
  "id" : 311214071364059137,
  "created_at" : "2013-03-11 20:36:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3083\u307E\u3072\u3087\u3046",
      "screen_name" : "hyamaHyo",
      "indices" : [ 0, 9 ],
      "id_str" : "623703365",
      "id" : 623703365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311213712323248131",
  "geo" : { },
  "id_str" : "311213950698156032",
  "in_reply_to_user_id" : 623703365,
  "text" : "@HyamaHyo \u304A\u6687\u3060\u3063\u305F\u3089\u305C\u3072\u30FC",
  "id" : 311213950698156032,
  "in_reply_to_status_id" : 311213712323248131,
  "created_at" : "2013-03-11 20:36:02 +0000",
  "in_reply_to_screen_name" : "hyamaHyo",
  "in_reply_to_user_id_str" : "623703365",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3083\u307E\u3072\u3087\u3046",
      "screen_name" : "hyamaHyo",
      "indices" : [ 0, 9 ],
      "id_str" : "623703365",
      "id" : 623703365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311212284389228544",
  "geo" : { },
  "id_str" : "311213422534590465",
  "in_reply_to_user_id" : 623703365,
  "text" : "@HyamaHyo \u3086\u308B\u3044\u304A\u3075\u3067\u3059\u306E\u3067\u30FC",
  "id" : 311213422534590465,
  "in_reply_to_status_id" : 311212284389228544,
  "created_at" : "2013-03-11 20:33:56 +0000",
  "in_reply_to_screen_name" : "hyamaHyo",
  "in_reply_to_user_id_str" : "623703365",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311209563141599233",
  "text" : "\u8AB0\u3067\u3082\u53C2\u52A0\u3057\u3066\u826F\u3044\u3093\u3060\u3088\uFF01\uFF01\uFF01\uFF01",
  "id" : 311209563141599233,
  "created_at" : "2013-03-11 20:18:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311208986768703488",
  "text" : "@Kyo_Hiiragi \u3044\u3044\u3088\uFF01\uFF01\uFF01\uFF01",
  "id" : 311208986768703488,
  "created_at" : "2013-03-11 20:16:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311198778008948736",
  "text" : "\u663C\u9803\u307E\u305F\u62E1\u6563\u3059\u308B\u304B\u30FC",
  "id" : 311198778008948736,
  "created_at" : "2013-03-11 19:35:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 26, 36 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311198671276494849",
  "text" : "\u30B3\u30E1\u30F3\u30C8\u6B04\u3067\u5E0C\u671B\u65E5\u4ED8\u66F8\u3044\u3066\u304F\u308C\u308B\u3068\u5B09\u3057\u3044\u3067\u3059 RT @end313124: \u4ED8\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 311198671276494849,
  "created_at" : "2013-03-11 19:35:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twipla.jp\" rel=\"nofollow\"\u003ETwiPla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/0cjLXxYqL5",
      "expanded_url" : "http:\/\/twipla.jp\/events\/44787",
      "display_url" : "twipla.jp\/events\/44787"
    } ]
  },
  "geo" : { },
  "id_str" : "311198266492600320",
  "text" : "\u4ED8\u5C5E\u56F3\u66F8\u992824\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5 http:\/\/t.co\/0cjLXxYqL5",
  "id" : 311198266492600320,
  "created_at" : "2013-03-11 19:33:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311197399194419201",
  "text" : "\u304F\u308B\u30FC\u3069\u6C0F\u304C\u4F01\u753B\u3057\u306A\u3044\u306E\u306A\u3089\u307024\u6642\u9593\u8010\u4E45\u52C9\u5F37\u30AA\u30D5\u50D5\u304C\u4F01\u753B\u3057\u3066\u3082\u3088\u3044\u3067\u3059\u304B\u306D\uFF1F",
  "id" : 311197399194419201,
  "created_at" : "2013-03-11 19:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311009942846967808",
  "text" : "\u307E\u3041\u3001\u5185\u7DD2\u306B\u3057\u3068\u3044\u3066\u306D\u30FC\u3001\u3068\u4E8B\u306A\u304D\u3092\u5F97\u305F\u304C",
  "id" : 311009942846967808,
  "created_at" : "2013-03-11 07:05:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311009676970037248",
  "text" : "\u9AD8\u6821\u304B\u3089\u96E2\u308C\u305F\u30B3\u30F3\u30D3\u30CB\u3060\u3063\u305F\u304B\u3089\u5727\u5012\u7684\u9A5A\u304D",
  "id" : 311009676970037248,
  "created_at" : "2013-03-11 07:04:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311009614697201664",
  "text" : "\u30B3\u30F3\u30D3\u30CB\u306E\u30D0\u30A4\u30C8\u3057\u3066\u308B\u6642\u3001\u5BA2\u3068\u3057\u3066\u6765\u305F\u30AF\u30E9\u30B9\u30E1\u30A4\u30C8\u306E\u5973\u306E\u5B50\u306B\u300C\u304A\u7BB8\u304A\u4ED8\u3051\u3057\u307E\u3059\u304B\uFF1F\u300D\u3068\u805E\u3044\u305F\u77AC\u9593\u76EE\u304C\u5408\u3063\u3066\u304A\u4E92\u3044\u9A5A\u304F\u3068\u304B\u8A00\u3046\u5727\u5012\u7684\u601D\u3044\u51FA",
  "id" : 311009614697201664,
  "created_at" : "2013-03-11 07:04:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311008978907824130",
  "geo" : { },
  "id_str" : "311009331313250304",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u5B9F\u969B\u52C9\u5F37\u306B\u306A\u308B\u306E\u3067\u63A8\u5968\u3068\u307E\u3067\u306F\u884C\u304B\u305A\u3068\u3082\u7981\u6B62\u3057\u306A\u304F\u3066\u3082\u826F\u3044\u306E\u306B\u306A\u30FC\u3001\u3068\u601D\u3044\u307E\u3059\u3002[\u9AD8\u6821\u304B\u3089\u304B\u306A\u308A\u30B3\u30F3\u30D3\u30CB\u3067\u3057\u305F\u304C\u30EC\u30B8\u3067\u30AF\u30E9\u30B9\u30E1\u30A4\u30C8\u306E\u5973\u306E\u5B50\u3068\u76EE\u304C\u5408\u3063\u305F\u6642\u306E\u885D\u6483]",
  "id" : 311009331313250304,
  "in_reply_to_status_id" : 311008978907824130,
  "created_at" : "2013-03-11 07:02:57 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311008534840098817",
  "text" : "\u8CA7\u4E4F\u91D1\u306A\u3057",
  "id" : 311008534840098817,
  "created_at" : "2013-03-11 06:59:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311007945959804928",
  "geo" : { },
  "id_str" : "311008266526269440",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u30D0\u30A4\u30C8\u7981\u6B62\u3067\u3082\u3084\u3063\u3066\u3057\u307E\u3048\u3070\u826F\u3044\u306E\u3067\u306F[\u50D5\u306F\u9AD8\u6821\u306E\u6642\u305D\u3093\u306A\u611F\u3058\u3067\u3057\u305F]",
  "id" : 311008266526269440,
  "in_reply_to_status_id" : 311007945959804928,
  "created_at" : "2013-03-11 06:58:43 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310838069462970369",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u30D5\u30FC\u30C8\u30F3\u306B\u79FB\u52D5",
  "id" : 310838069462970369,
  "created_at" : "2013-03-10 19:42:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310837938009280513",
  "text" : "\u305F\u3076\u30936\u6642\u904E\u304E\u307E\u3067\u8D77\u304D\u3066\u308B\u3002\u305D\u3057\u3066\u4ECA\u65E5\u306F\u3082\u3046\u30B3\u30FC\u30D2\u30FC\u306F\u3001\u3068\u3044\u3046\u304B\u30AB\u30D5\u30A7\u30A4\u30F3\u306F\u63A7\u3048\u3088\u3046\u3002",
  "id" : 310837938009280513,
  "created_at" : "2013-03-10 19:41:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310837703346360321",
  "text" : "\u4ECA\u65E5\u306F12\u6642\u3068\u304B\u306B\u8D77\u304D\u3066\u51FA\u639B\u3051\u308B\u304B[12\u6642\u304C\u65E9\u8D77\u304D][\u7D76\u671B\u3057\u305F\uFF0112\u6642\u304C\u65E9\u8D77\u304D\u306A\u751F\u6D3B\u30EA\u30BA\u30E0\u306B\u7D76\u671B\u3057\u305F\uFF01]",
  "id" : 310837703346360321,
  "created_at" : "2013-03-10 19:40:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310837458852012033",
  "text" : "\u6700\u8FD1\u3044\u3064\u8D77\u304D\u308C\u3070\u826F\u3044\u306E\u304B\u5FAE\u5999\u306A\u7761\u7720\u3057\u3066\u308B\u304B\u3089\u826F\u304F\u306A\u3044",
  "id" : 310837458852012033,
  "created_at" : "2013-03-10 19:39:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310816680353878016",
  "text" : "\u624B\u5148\u3068\u6307\u5148\u306E\u5883\u754C\u3068\u304B\u66D6\u6627\u3067\u3082\u3042\u3093\u307E\u308A\u56F0\u3089\u306A\u3044\u306A(^^)(^^)(^^)",
  "id" : 310816680353878016,
  "created_at" : "2013-03-10 18:17:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310816517707165696",
  "text" : "\u6307\u5148\u306F\u6307\u306E\u7B2C\u4E8C\u95A2\u7BC0\u304F\u3089\u3044\u307E\u3067\uFF1F",
  "id" : 310816517707165696,
  "created_at" : "2013-03-10 18:16:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310816392972734464",
  "text" : "\u624B\u5148\u306F\u624B\u306E\u3072\u3089\u3088\u308A\u5148\u3001\u306E\u30A4\u30E1\u30FC\u30B8[\u5177\u4F53\u7684\u306B\u306F\u6307]",
  "id" : 310816392972734464,
  "created_at" : "2013-03-10 18:16:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310816211288092673",
  "text" : "\u30B7\u30E7\u30C3\u30AE\u30E7\u30E0\u30C3\u30B8\u30E7",
  "id" : 310816211288092673,
  "created_at" : "2013-03-10 18:15:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310815629261291521",
  "geo" : { },
  "id_str" : "310816084104187905",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u306B\u308F\u304B\u306B\u30C9\u30DF\u30CB\u30AA\u30F3\u3084\u308A\u305F\u304F\u306A\u3063\u305F\u2026",
  "id" : 310816084104187905,
  "in_reply_to_status_id" : 310815629261291521,
  "created_at" : "2013-03-10 18:15:03 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310815505541918721",
  "text" : "\u75DB\u3044\u306E\u5ACC\u3044\u3060\u3057\u4F8B\u3048\u75C5\u3093\u3067\u3082\u30EA\u30B9\u30C8\u30AB\u30C3\u30C8\u3068\u304B\u7D76\u5BFE\u3084\u3089\u306A\u3044[\u3068\u591A\u5206\u307F\u3093\u306A\u8A00\u3046]",
  "id" : 310815505541918721,
  "created_at" : "2013-03-10 18:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310814893286772737",
  "text" : "\u6307\u5148\u3068\u3044\u3046\u3079\u304D\u3060\u3063\u305F\u306E\u304B\u306A",
  "id" : 310814893286772737,
  "created_at" : "2013-03-10 18:10:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310814851054313473",
  "text" : "@i_horse \u624B\u5148\u3063\u3066\u30EA\u30B9\u30C8\u3082\u542B\u3080\u306E\u304B\u306D\uFF1F",
  "id" : 310814851054313473,
  "created_at" : "2013-03-10 18:10:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310814581394112512",
  "text" : "\u7D19\u3067\u304D\u308B(\u6C17\u4ED8\u304B\u306A\u3044)\u2192\u304A\u98A8\u5442\u5834\u3067\u6C17\u4ED8\u304F\u3001\u306E\u9EC4\u91D1\u30D1\u30BF\u30FC\u30F3",
  "id" : 310814581394112512,
  "created_at" : "2013-03-10 18:09:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310814426729168896",
  "text" : "\u3042\u307E\u308A\u5BB6\u304B\u3089\u51FA\u3066\u306A\u3044\u306E\u306B\u624B\u5148\u304B\u3089\u5207\u308A\u50B7\u304C\u7D76\u3048\u306A\u3044\u2026",
  "id" : 310814426729168896,
  "created_at" : "2013-03-10 18:08:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310811276756545537",
  "text" : "\u5712\u8AD6\u306E\u57FA\u790E \u3068\u306F",
  "id" : 310811276756545537,
  "created_at" : "2013-03-10 17:55:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5929\u56FD\u8D85\u8D8A\u306E\u30DF\u30B5\u30EF",
      "screen_name" : "ccccccccandy",
      "indices" : [ 3, 16 ],
      "id_str" : "161593508",
      "id" : 161593508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310811201615581184",
  "text" : "RT @ccccccccandy: \u516C\u5712\u304C\u516C\u570F\u306B\u898B\u3048\u308B\u3057\u3060\u3081\u304B\u3082\u3057\u308C\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310810800862396417",
    "text" : "\u516C\u5712\u304C\u516C\u570F\u306B\u898B\u3048\u308B\u3057\u3060\u3081\u304B\u3082\u3057\u308C\u306A\u3044\u3002",
    "id" : 310810800862396417,
    "created_at" : "2013-03-10 17:54:04 +0000",
    "user" : {
      "name" : "\u5929\u56FD\u8D85\u8D8A\u306E\u30DF\u30B5\u30EF",
      "screen_name" : "ccccccccandy",
      "protected" : false,
      "id_str" : "161593508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3783939471\/7edff2a3180fc80f7575349b0a416a70_normal.png",
      "id" : 161593508,
      "verified" : false
    }
  },
  "id" : 310811201615581184,
  "created_at" : "2013-03-10 17:55:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310811070463893505",
  "text" : "\u4E00\u4E57\u5BFA\u306B\u516C\u5712\u304C\u3042\u308B\u3089\u3057\u3044",
  "id" : 310811070463893505,
  "created_at" : "2013-03-10 17:55:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310810428500484097",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u516C\u5712\u3068\u304B\u306B\u884C\u304D\u305F\u3044",
  "id" : 310810428500484097,
  "created_at" : "2013-03-10 17:52:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310787386273583105",
  "text" : "\u30D6\u30E9\u30B9\u30C8\u30C9\u30FC\u30B6\u30FC\u7136\u308A\u3001\u30C9\u30F3\u30AD\u30FC64\u7136\u308A\u3001\u30D0\u30F3\u30B8\u30E7\u30FC\u30AB\u30BA\u30FC\u30A4\u7136\u308A",
  "id" : 310787386273583105,
  "created_at" : "2013-03-10 16:21:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310787199618674688",
  "text" : "\u30EC\u30A2\u793E\u306E\u6D88\u5931\u306F\u5927\u304D\u306A\u640D\u5931\u3067\u3042\u308B",
  "id" : 310787199618674688,
  "created_at" : "2013-03-10 16:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310785634941927424",
  "geo" : { },
  "id_str" : "310786964246892544",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \u308F\u304B\u308B",
  "id" : 310786964246892544,
  "in_reply_to_status_id" : 310785634941927424,
  "created_at" : "2013-03-10 16:19:21 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310721826126979072",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 310721826126979072,
  "created_at" : "2013-03-10 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310640528230318080",
  "text" : "\u3054\u306F\u3093\u3001\u3054\u306F\u3093",
  "id" : 310640528230318080,
  "created_at" : "2013-03-10 06:37:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310640156728246272",
  "text" : "\u76EE\u899A\u3081\u305F\u308915:00\u3060\u3063\u305F\u3093\u3060\u304C\uFF1F\uFF01",
  "id" : 310640156728246272,
  "created_at" : "2013-03-10 06:35:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310455159929073665",
  "text" : "\u932F\u4E71\u307C",
  "id" : 310455159929073665,
  "created_at" : "2013-03-09 18:20:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310455090353950721",
  "text" : "\u82B1\u7C89\u306E\u5B58\u5728\u3092\u8A8D\u3081\u306A\u3051\u308C\u3070\u82B1\u7C89\u75C7\u304C\u6CBB\u308B(?)",
  "id" : 310455090353950721,
  "created_at" : "2013-03-09 18:20:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310454894068891648",
  "text" : "\"\u82B1\u7C89\u306E\u5B58\u5728\u3092\u4FE1\u3058\u306A\u3044\"\u3068\u3044\u3046\u65AC\u65B0\u306A\u7ACB\u5834",
  "id" : 310454894068891648,
  "created_at" : "2013-03-09 18:19:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310398759580344320",
  "text" : "\u30B3\u30BF\u30C4\u3067\u98F2\u3080\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\uFF01\u30BC\u30C3\u30D4\u30F3\uFF01",
  "id" : 310398759580344320,
  "created_at" : "2013-03-09 14:36:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310359456921825280",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 310359456921825280,
  "created_at" : "2013-03-09 12:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310075341802713089",
  "text" : "\u73FE\u6BB5\u968E\u306E\u8A8D\u8B58\u6CD5\u3092\u77E5\u3089\u306A\u3044\u304B\u3089\u306A\u304A\u7D20\u4EBA\u307D\u3044",
  "id" : 310075341802713089,
  "created_at" : "2013-03-08 17:11:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310075052773240833",
  "text" : "OCR\u306E\u7CBE\u5BC6\u5316\u3068\u304B\u306B\u4F7F\u3048\u305F\u3089\u2026",
  "id" : 310075052773240833,
  "created_at" : "2013-03-08 17:10:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310074899869884419",
  "text" : "\u8907\u96D1\u306A\u6F22\u5B57\u3068\u304B\uFF1F\u6587\u5B57\u304C\u6F70\u308C\u305F\u3089\u30A2\u30EC\u3060\u3057\u3001\u51E6\u7406\u306B\u6642\u9593\u304C\u304B\u304B\u308A\u3059\u304E\u308B\u3068\u30C0\u30E1\u3060\u3051\u3069",
  "id" : 310074899869884419,
  "created_at" : "2013-03-08 17:09:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310074737512570880",
  "text" : "\u306E\u30FC\u3066\u3043\u3055\u3093\u306Epdf\u898B\u3066\u305F\u3051\u3069\u3053\u308C\u6587\u5B57\u8A8D\u8B58\u3068\u304B\u306B\u5FDC\u7528\u3067\u304D\u305F\u3089\u697D\u3057\u305D\u3046",
  "id" : 310074737512570880,
  "created_at" : "2013-03-08 17:09:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310045028099694593",
  "text" : "\u7518\u3044\u3082\u306Eis\u98DF\u3079\u305F\u3044\u611F\u3058",
  "id" : 310045028099694593,
  "created_at" : "2013-03-08 15:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310033551842234369",
  "text" : "@kotorin_z \u306F\u30FC\u3044\uFF01",
  "id" : 310033551842234369,
  "created_at" : "2013-03-08 14:25:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309977662099697665",
  "text" : "[\u901F\u5831]\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u89E3\u7981",
  "id" : 309977662099697665,
  "created_at" : "2013-03-08 10:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309682957570957312",
  "geo" : { },
  "id_str" : "309923568463007744",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30B4\u30DF\u3068\u5316\u3057\u305F\uFF1F",
  "id" : 309923568463007744,
  "in_reply_to_status_id" : 309682957570957312,
  "created_at" : "2013-03-08 07:08:31 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309923214711222272",
  "text" : "\u3044\u3084\u307E\u3041\u5B9F\u969B\u306E\u3093\u3060\u3051\u3069\u3001\u305D\u3093\u306A\u306B\u3059\u3050\u306F\u52B9\u304B\u306A\u3044\u3088\u306D(\u771F\u9854)",
  "id" : 309923214711222272,
  "created_at" : "2013-03-08 07:07:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u507D\u85AC\u52B9\u679C",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309922954404323328",
  "text" : "\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B\u85AC\u98F2\u3093\u3060\u304B\u3089\u82B1\u7C89\u75C7\u306F\u6CBB\u307E\u308B #\u507D\u85AC\u52B9\u679C",
  "id" : 309922954404323328,
  "created_at" : "2013-03-08 07:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309922480930295809",
  "text" : "\u30BF\u30C3\u30C1\u30D1\u30CD\u30EB\u5238\u58F2\u6A5F\u3067\u7A81\u304D\u6307\u3057\u305F\u3068\u304B\u8A00\u3063\u3066\u305F\u306E\u3082\u3084\u3070\u3044\u3068\u601D\u3063\u305F",
  "id" : 309922480930295809,
  "created_at" : "2013-03-08 07:04:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309922319546060800",
  "text" : "\u753B\u4F2F\u3084\u3070\u3044",
  "id" : 309922319546060800,
  "created_at" : "2013-03-08 07:03:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6797\u3086\u3046_\u516C\u5F0F",
      "screen_name" : "holy_kobayashi",
      "indices" : [ 3, 18 ],
      "id_str" : "901539650",
      "id" : 901539650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309922232854007809",
  "text" : "RT @holy_kobayashi: \u25CE\u5C0F\u6797\u3086\u3046\u3067\u3059\u306A\u3046\u3002\u304D\u3087\u3046\u3082\u304A\u4ED5\u4E8B\u306E\u79FB\u52D5\u4E2D\u306B\u30B0\u30DF\u3092\u8CB7\u308F\u305B\u3066\u3044\u305F\u3060\u3044\u3066\u304A\u308A\u307E\u3059\u3002\u30B0\u30DF\u306F\u98DF\u3079\u308B\u306E\u3082\u3055\u308F\u308B\u306E\u3082\u5927\u597D\u304D\u3067\u3059\u306A\u3046\u3002\u30D1\u30C3\u30B1\u30FC\u30B8\u306E\u3046\u3048\u304B\u3089\u64AB\u3067\u308B\u3068\u512A\u3057\u3044\u6C17\u6301\u3061\u306B\u306A\u308A\u307E\u3059\u3002\u4EE5\u524D\u306F\u30B0\u30DF\u3092\u98DF\u3079\u904E\u304E\u3066\u6B6F\u304C\u6298\u308C\u305F\u3053\u3068\u3082\u3054\u3056\u3044\u307E\u3057\u3066\u3001\u305D\u306E\u304F\u3089 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309547335174729728",
    "text" : "\u25CE\u5C0F\u6797\u3086\u3046\u3067\u3059\u306A\u3046\u3002\u304D\u3087\u3046\u3082\u304A\u4ED5\u4E8B\u306E\u79FB\u52D5\u4E2D\u306B\u30B0\u30DF\u3092\u8CB7\u308F\u305B\u3066\u3044\u305F\u3060\u3044\u3066\u304A\u308A\u307E\u3059\u3002\u30B0\u30DF\u306F\u98DF\u3079\u308B\u306E\u3082\u3055\u308F\u308B\u306E\u3082\u5927\u597D\u304D\u3067\u3059\u306A\u3046\u3002\u30D1\u30C3\u30B1\u30FC\u30B8\u306E\u3046\u3048\u304B\u3089\u64AB\u3067\u308B\u3068\u512A\u3057\u3044\u6C17\u6301\u3061\u306B\u306A\u308A\u307E\u3059\u3002\u4EE5\u524D\u306F\u30B0\u30DF\u3092\u98DF\u3079\u904E\u304E\u3066\u6B6F\u304C\u6298\u308C\u305F\u3053\u3068\u3082\u3054\u3056\u3044\u307E\u3057\u3066\u3001\u305D\u306E\u304F\u3089\u3044\u5927\u597D\u304D\u3067\u3059\u306A\u3046\u3002",
    "id" : 309547335174729728,
    "created_at" : "2013-03-07 06:13:30 +0000",
    "user" : {
      "name" : "\u5C0F\u6797\u3086\u3046_\u516C\u5F0F",
      "screen_name" : "holy_kobayashi",
      "protected" : false,
      "id_str" : "901539650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000702600272\/041fde8861ef7e0ee5b55f429b8d44c5_normal.jpeg",
      "id" : 901539650,
      "verified" : false
    }
  },
  "id" : 309922232854007809,
  "created_at" : "2013-03-08 07:03:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309917304873955328",
  "text" : "\u82B1\u7C89\u75C7\u306A\u306E\u306B\u3053\u306E\u6642\u671F\u5916\u304C\u5FC3\u5730\u3044\u3044\u305B\u3044\u3067\u5916\u306B\u3044\u308B\u304B\u3089\u5E78\u305B\u306B\u306A\u308C\u306A\u3044",
  "id" : 309917304873955328,
  "created_at" : "2013-03-08 06:43:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309917191648735233",
  "text" : "\u507D\u85AC\u52B9\u679C-\u30D7\u30E9\u30B7\u30FC\u30DC\u30FB\u30A8\u30D5\u30A7\u30AF\u30C8-",
  "id" : 309917191648735233,
  "created_at" : "2013-03-08 06:43:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309752193706246145",
  "text" : "\u4E00\u4EBA\u52DD\u3061\u3060\u3063\u305F\u304C\u56FD\u58EB\u30C6\u30F3\u30D1\u30A4\u3059\u308B\u304F\u3089\u3044\u3057\u304B\u76EE\u7ACB\u3063\u305F\u4E8B\u306A\u3057",
  "id" : 309752193706246145,
  "created_at" : "2013-03-07 19:47:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309751968237228032",
  "text" : "\u9EBB\u96C0\u7D42\u308F\u3063\u3066\u5E30\u5B85\uFF01",
  "id" : 309751968237228032,
  "created_at" : "2013-03-07 19:46:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 2, 9 ],
      "id_str" : "141811283",
      "id" : 141811283
    }, {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 10, 18 ],
      "id_str" : "351349087",
      "id" : 351349087
    }, {
      "name" : "\u3079\u306B\u3070\u306A\uFF201\u56DE\u751F",
      "screen_name" : "CcreticusL",
      "indices" : [ 19, 30 ],
      "id_str" : "407066804",
      "id" : 407066804
    }, {
      "name" : "\u3044\u3063\u3069\u30FC",
      "screen_name" : "ido_d",
      "indices" : [ 31, 37 ],
      "id_str" : "335231130",
      "id" : 335231130
    }, {
      "name" : "\u307F\u3084\u30BF\u30B3\u30B9(\u261D \u055E\u0A0A \u055E)\u261D",
      "screen_name" : "miya_tacos",
      "indices" : [ 38, 49 ],
      "id_str" : "747261714",
      "id" : 747261714
    }, {
      "name" : "\u725B\u5CF6",
      "screen_name" : "usijima_uoichi",
      "indices" : [ 50, 65 ],
      "id_str" : "162395025",
      "id" : 162395025
    }, {
      "name" : "Feru",
      "screen_name" : "Feru54604",
      "indices" : [ 66, 76 ],
      "id_str" : "78560756",
      "id" : 78560756
    }, {
      "name" : "Fumi O'Orient",
      "screen_name" : "fumieval",
      "indices" : [ 77, 86 ],
      "id_str" : "75975397",
      "id" : 75975397
    }, {
      "name" : "\u6D85\u69C3",
      "screen_name" : "_ne_ha_n_",
      "indices" : [ 87, 97 ],
      "id_str" : "499591313",
      "id" : 499591313
    }, {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 98, 106 ],
      "id_str" : "145536184",
      "id" : 145536184
    }, {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 107, 117 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309708842755833856",
  "text" : ". @rpdexp @yasuand @CcreticusL @ido_d @miya_tacos @usijima_uoichi @Feru54604 @fumieval @_ne_ha_n_ @chr1233 @typekanon \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 309708842755833856,
  "created_at" : "2013-03-07 16:55:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309634664912535552",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 309634664912535552,
  "created_at" : "2013-03-07 12:00:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309621903428046848",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 309621903428046848,
  "created_at" : "2013-03-07 11:09:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/p7Dv1xgPrn",
      "expanded_url" : "http:\/\/4sq.com\/12wdB6d",
      "display_url" : "4sq.com\/12wdB6d"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "309621773224267777",
  "text" : "\u3055\u3066\u3055\u3066\u30FC\uFF1F (@ \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ) http:\/\/t.co\/p7Dv1xgPrn",
  "id" : 309621773224267777,
  "created_at" : "2013-03-07 11:09:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309536105844330497",
  "text" : "\u6625\u3081\u304D\uFF01",
  "id" : 309536105844330497,
  "created_at" : "2013-03-07 05:28:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309532727164694528",
  "text" : "\u5352\u696D\u3059\u308B\u4EBA\u304C\u5272\u3068\u5B9F\u5BB6\u306E\u8FD1\u304F\u306B\u4F4F\u3080\u3053\u3068\u306B\u306A\u3063\u305F\u4F8B\u304C\u4F55\u4EF6\u304B\u3042\u3063\u3066\u30C6\u30F3\u30BD\u30F3\u3042\u304C\u308B",
  "id" : 309532727164694528,
  "created_at" : "2013-03-07 05:15:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309531312769884160",
  "geo" : { },
  "id_str" : "309531754669146113",
  "in_reply_to_user_id" : 427714784,
  "text" : "@miattermeyer \"\u30D5\u30EB\u5358\u3060\u3063\u305F\u3089\u713C\u8089\u5962\u308B\"\u3001\u307F\u305F\u3044\u306A\u5951\u7D04\u304C\u884C\u308F\u308C\u3066\u3044\u305F\u7D50\u679C\u51FA\u3066\u304D\u305F\u8A00\u8449\u3067\u3057\u305F(^^)(^^)(^^)",
  "id" : 309531754669146113,
  "in_reply_to_status_id" : 309531312769884160,
  "created_at" : "2013-03-07 05:11:35 +0000",
  "in_reply_to_screen_name" : "miantomori",
  "in_reply_to_user_id_str" : "427714784",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309529723720060928",
  "text" : "\"hogehoge\u4EE5\u5916\u30D5\u30EB\u5358\"\u3068\u304B\u8A00\u3046\u5727\u5012\u7684\u767A\u60F3",
  "id" : 309529723720060928,
  "created_at" : "2013-03-07 05:03:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309529233800192000",
  "geo" : { },
  "id_str" : "309529600554328065",
  "in_reply_to_user_id" : 427714784,
  "text" : "@miattermeyer \u50D5\u306E\u53CB\u4EBA\u300C\u5316\u5B66\u4EE5\u5916\u30D5\u30EB\u5358\u300D\u3068\u304B\u3044\u3046\u308F\u3051\u306E\u308F\u304B\u3089\u306A\u3044\u3053\u3068\u8A00\u3063\u3066\u305F\u306E\u3067\u30AA\u30B9\u30B9\u30E1\u3067\u3059",
  "id" : 309529600554328065,
  "in_reply_to_status_id" : 309529233800192000,
  "created_at" : "2013-03-07 05:03:02 +0000",
  "in_reply_to_screen_name" : "miantomori",
  "in_reply_to_user_id_str" : "427714784",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309528728889851904",
  "text" : "\u4ED9\u5DDD\u304C\u7530\u820E\u3068\u304B\u3044\u3046\u51C4\u7D76\u306A\u4E3B\u5F35\u3092\u898B\u305F",
  "id" : 309528728889851904,
  "created_at" : "2013-03-07 04:59:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309528120657063936",
  "text" : "\u3059\u3054\u30FC\u304F\u7406\u4E0D\u5C3D\u306A\u5922\u3092\u898B\u305F\u6C17\u304C\u3059\u308B\u3051\u3069\u5FD8\u308C\u3061\u3083\u3063\u305F",
  "id" : 309528120657063936,
  "created_at" : "2013-03-07 04:57:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309394126393180160",
  "text" : "\u4E45\u3005\u306B\u3053\u306E\u624B\u306E\u30CD\u30BF\u3067\u7B11\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 309394126393180160,
  "created_at" : "2013-03-06 20:04:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u306B\uFF08\u59B9\uFF09",
      "screen_name" : "funiimouto",
      "indices" : [ 3, 14 ],
      "id_str" : "292901585",
      "id" : 292901585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309394048584654849",
  "text" : "RT @funiimouto: \u30AC\u30C3\u30C7\u30E0\uFF01\u3057\u304B\u8A00\u3048\u306A\u3044\u4EBA\u300C\u30AC\u30C3\u30C7\u30E0\uFF01\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309393998731169792",
    "text" : "\u30AC\u30C3\u30C7\u30E0\uFF01\u3057\u304B\u8A00\u3048\u306A\u3044\u4EBA\u300C\u30AC\u30C3\u30C7\u30E0\uFF01\u300D",
    "id" : 309393998731169792,
    "created_at" : "2013-03-06 20:04:12 +0000",
    "user" : {
      "name" : "\u3075\u306B\uFF08\u59B9\uFF09",
      "screen_name" : "funiimouto",
      "protected" : false,
      "id_str" : "292901585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561846964774375424\/sAxenHIN_normal.jpeg",
      "id" : 292901585,
      "verified" : false
    }
  },
  "id" : 309394048584654849,
  "created_at" : "2013-03-06 20:04:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309332121166700544",
  "text" : "\u9F3B\u304B\u3089\u304F\u3057\u3083\u307F\u304C\u3069\u3093\u3069\u3093\u51FA\u3066\u304F\u308B",
  "id" : 309332121166700544,
  "created_at" : "2013-03-06 15:58:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309321972456767489",
  "text" : "\u8272\u3005\u30A8\u30A2\u30EA\u30D7\u3081\u304F\u3051\u308C\u3069\u6CE3\u304D\u8A00\u304C\u3042\u308B\u306A\u3089\u30EA\u30A2\u30EB\u3067\u8A71\u3092\u3002\u8A71\u304F\u3089\u3044\u306A\u3089\u805E\u304D\u307E\u3059\u3057\u3002",
  "id" : 309321972456767489,
  "created_at" : "2013-03-06 15:17:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309321706592415745",
  "text" : "\u308A\u3060\u3064",
  "id" : 309321706592415745,
  "created_at" : "2013-03-06 15:16:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309321370305695746",
  "text" : "Twitter\u3067\u306E\u3064\u3089\u307F\u306E\u767A\u9732\u306F\u5426\u304C\u5FDC\u3067\u3082\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3092\u60F3\u5B9A\u3059\u308B\u3082\u306E\u3060\u304B\u3089\u306A\u2026\u30C0\u30E1\u3060\u2026",
  "id" : 309321370305695746,
  "created_at" : "2013-03-06 15:15:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309319441047498753",
  "text" : "\u3064\u3089\u307F\u3092Twitter\u306B\u5410\u304D\u51FA\u3057\u3066\u3082\u826F\u3044\u3051\u308C\u3069\u30EA\u30D7\u30E9\u30A4\u8CB0\u3063\u3066\u3082\u6328\u62F6\u306B\u56F0\u308B\u306A\u2026",
  "id" : 309319441047498753,
  "created_at" : "2013-03-06 15:07:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309318705924407296",
  "text" : "@i_horse \u971E\u3093\u3067\u3044\u304F\u2026",
  "id" : 309318705924407296,
  "created_at" : "2013-03-06 15:05:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309318591344410625",
  "text" : "\u3072\u3087\u3063\u3053\u308A\u5FA9\u6D3B\u3057\u305F\u308A\u5225\u30A2\u30AB\u3067\u30DD\u30A8\u30E0\u3092\u632F\u308A\u307E\u304D\u305D\u3046\u306A\u6C17\u3082\u3059\u308B",
  "id" : 309318591344410625,
  "created_at" : "2013-03-06 15:04:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309318459752333312",
  "text" : "\u30B3\u30F3\u30C6\u30F3\u30C4\u3068\u3057\u3066\u306E\u5F15\u304D\u969B\uFF1F",
  "id" : 309318459752333312,
  "created_at" : "2013-03-06 15:04:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309317660225699840",
  "text" : "\u6843\u306E\u6A39\u30DD\u30A8\u30E0\u5C71\u6912\u306E\u6A39\u30DD\u30A8\u30E0\u306E\u767B\u5834\u304C\u671B\u307E\u308C\u308B",
  "id" : 309317660225699840,
  "created_at" : "2013-03-06 15:00:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309317193919774721",
  "text" : "\u307E\u3060\u7D42\u308F\u3063\u3066\u306A\u304B\u3063\u305F\u4E8B\u306B\u9A5A\u304D\u6843\u306E\u6728\u5C71\u6912\u306E\u6728\u3060\u3051\u3069\uFF1F",
  "id" : 309317193919774721,
  "created_at" : "2013-03-06 14:59:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309317109983371264",
  "text" : "\u4E16\u754C\u6A39\u306A\u3093\u3061\u3083\u3089\u7D42\u308F\u308B\u306E\uFF1F",
  "id" : 309317109983371264,
  "created_at" : "2013-03-06 14:58:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309238526245998592",
  "text" : "\u767E\u4E07\u904D\u3001\u9EBB\u96C0\u3001\u3061\u3089\u3063\uFF1F",
  "id" : 309238526245998592,
  "created_at" : "2013-03-06 09:46:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309236783181352960",
  "text" : "\u30C8\u30ED\u30D5\u30A3\u30FC\u6B32\u3057\u3044\u306A(\u610F\u5473\u6DF1)",
  "id" : 309236783181352960,
  "created_at" : "2013-03-06 09:39:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309236728303067136",
  "text" : "\u7559\u5E74\u3059\u308B\u3068\u304B\u305A\u30FC\u6C0F\u304B\u3089\u30C8\u30ED\u30D5\u30A3\u30FC\u3082\u3089\u3048\u308B\u304B\u30FC\u3075\u30FC\u3093",
  "id" : 309236728303067136,
  "created_at" : "2013-03-06 09:39:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNIpGD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309226353658580993",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNIpGD",
  "id" : 309226353658580993,
  "created_at" : "2013-03-06 08:58:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309173516698279936",
  "text" : "\u30CA\u30C1\u30E5\u30E9\u30EB\u306B12\u6642\u9593\u307B\u3069\u7720\u3063\u305F",
  "id" : 309173516698279936,
  "created_at" : "2013-03-06 05:28:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308991365977616384",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 308991365977616384,
  "created_at" : "2013-03-05 17:24:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308991332607721473",
  "text" : "\u3073\u3063\u304F\u308A\u3059\u308B\u307B\u3069\u7720\u3044\u306E\u3067\u6B7B\u3093\u3060\u3088\u3046\u306B\u7720\u308B",
  "id" : 308991332607721473,
  "created_at" : "2013-03-05 17:24:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308909870680248320",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 308909870680248320,
  "created_at" : "2013-03-05 12:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308820976089579520",
  "text" : "\u3059\u3079\u3066\u306B\u304A\u3044\u3066\u3076\u308C\u3076\u308C\u3060\u306A\u3041",
  "id" : 308820976089579520,
  "created_at" : "2013-03-05 06:07:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308737435385339904",
  "text" : "\u3042\u3075\u308C\u308B\u7720\u6C17\u304C\u6B62\u307E\u3089\u306A\u3044",
  "id" : 308737435385339904,
  "created_at" : "2013-03-05 00:35:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308603548806033409",
  "geo" : { },
  "id_str" : "308604091410571264",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 d\u3057\u307E\u3057\u305F\u30FC",
  "id" : 308604091410571264,
  "in_reply_to_status_id" : 308603548806033409,
  "created_at" : "2013-03-04 15:45:23 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308603330454753281",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u306F\u3050\u308B\u307E\u90B8\u3067\u304A\u9152\u98F2\u3093\u3067\u307E\u3059\u304C\u6765\u307E\u305B\u3093\u304B(\u5510\u7A81)",
  "id" : 308603330454753281,
  "created_at" : "2013-03-04 15:42:22 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308493702811226112",
  "geo" : { },
  "id_str" : "308494761654902784",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30DE\u30B9\u30EF\u30EA\uFF01",
  "id" : 308494761654902784,
  "in_reply_to_status_id" : 308493702811226112,
  "created_at" : "2013-03-04 08:30:57 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308491784873459712",
  "geo" : { },
  "id_str" : "308493518438035456",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u3044\u3048\u3059\uFF01",
  "id" : 308493518438035456,
  "in_reply_to_status_id" : 308491784873459712,
  "created_at" : "2013-03-04 08:26:00 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308483023505076225",
  "text" : "[\u901F\u5831]\u30DE\u30B9\u30EF\u30EA",
  "id" : 308483023505076225,
  "created_at" : "2013-03-04 07:44:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308465480702771200",
  "text" : "\uFF1F\uFF1F",
  "id" : 308465480702771200,
  "created_at" : "2013-03-04 06:34:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308465308769869824",
  "text" : "\u4E00\u5EA6\u95C7\u3092\u77E5\u3063\u305F\u8005\u306F\u3001\u30B9\u30A4\u30B9\u30A4\u6CF3\u3050",
  "id" : 308465308769869824,
  "created_at" : "2013-03-04 06:33:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308465176162738178",
  "text" : "\uFF1F",
  "id" : 308465176162738178,
  "created_at" : "2013-03-04 06:33:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308465161965019136",
  "text" : "\u5341\u5206\u306B\u767A\u9054\u3057\u305F\u79D1\u5B66\u306F\u3001\u30B9\u30A4\u30B9\u30A4\u6CF3\u3050",
  "id" : 308465161965019136,
  "created_at" : "2013-03-04 06:33:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308464767448797185",
  "text" : "hogehoge\u306F\u30B9\u30A4\u30B9\u30A4\u6CF3\u3050",
  "id" : 308464767448797185,
  "created_at" : "2013-03-04 06:31:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308464695327744000",
  "text" : "RT @tameninaru: \u30DB\u30BF\u30C6\u8C9D\u306F\u30B9\u30A4\u30B9\u30A4\u6CF3\u3050\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308460559119048705",
    "text" : "\u30DB\u30BF\u30C6\u8C9D\u306F\u30B9\u30A4\u30B9\u30A4\u6CF3\u3050\u3002",
    "id" : 308460559119048705,
    "created_at" : "2013-03-04 06:15:02 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 308464695327744000,
  "created_at" : "2013-03-04 06:31:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/h5yp9op7CB",
      "expanded_url" : "http:\/\/4sq.com\/101Z3cQ",
      "display_url" : "4sq.com\/101Z3cQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "308445091855491073",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/h5yp9op7CB",
  "id" : 308445091855491073,
  "created_at" : "2013-03-04 05:13:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308222006174834688",
  "text" : "@kotorin_z \u65E9\u3044\u5206\u306B\u306F(\u8D77\u304D\u3089\u308C\u308C\u3070)\u52D5\u3051\u307E\u3059\u306E\u3067\u301C",
  "id" : 308222006174834688,
  "created_at" : "2013-03-03 14:27:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308221810309206016",
  "text" : "\u300C\u3068\u307D\u307D\u301C\u300D\u306F\u300C\u30AD\u30A7\u30A7\u30A7\u30A7\u300D\u3088\u308A\u30CA\u30C1\u30E5\u30E9\u30EB\u306B\u72C2\u6C17\u3092\u611F\u3058\u308B",
  "id" : 308221810309206016,
  "created_at" : "2013-03-03 14:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308221356787527681",
  "text" : "@kotorin_z \u5915\u65B9\u304F\u3089\u3044\u3067\u629C\u3051\u3066\u826F\u3044\u306A\u3089\u3070\u8CB7\u3044\u51FA\u3057\u3068\u304B\u306F\u304A\u624B\u4F1D\u3044\u3057\u307E\u3059\u30FC\u3001[\u539F\u4ED8\u306E\u6A5F\u52D5\u529Bis\u4FBF\u5229]",
  "id" : 308221356787527681,
  "created_at" : "2013-03-03 14:24:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308220307980832768",
  "text" : "@kotorin_z \u6642\u9593\u5E2F\u306F\u3069\u306E\u304F\u3089\u3044\u3067\u3057\u3087\u3046",
  "id" : 308220307980832768,
  "created_at" : "2013-03-03 14:20:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308185121150877697",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 308185121150877697,
  "created_at" : "2013-03-03 12:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308117099329511425",
  "text" : "\u7279\u306B\u7528\u306F\u306A\u3044\u3093\u3060\u3051\u308C\u3069\u306D\u3001\u3075\u3068",
  "id" : 308117099329511425,
  "created_at" : "2013-03-03 07:30:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308116804058877952",
  "geo" : { },
  "id_str" : "308117062461571073",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u4ECA\u304B\u3089\u4F3A\u3063\u3066\u3082\uFF1F[\u8FF7\u60D1\u3058\u3083\u306A\u3051\u308C\u3070\uFF1F]",
  "id" : 308117062461571073,
  "in_reply_to_status_id" : 308116804058877952,
  "created_at" : "2013-03-03 07:30:06 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308080614777683968",
  "geo" : { },
  "id_str" : "308116519315984384",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u3046\u3075\u3075\u3075\u3075[\u304A\u9AD8\u3044\u3067\u3059\u3057\u306D\u3047]",
  "id" : 308116519315984384,
  "in_reply_to_status_id" : 308080614777683968,
  "created_at" : "2013-03-03 07:27:57 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308115908461744130",
  "text" : "\u3084\u3063\u3071\u308A\u91CF\u306F\u98F2\u3081\u306A\u3044\u3051\u308C\u3069",
  "id" : 308115908461744130,
  "created_at" : "2013-03-03 07:25:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308115855462498307",
  "text" : "\u6885\u9152\u306F\u30D6\u30E9\u30F3\u30C7\u30FC\u30D9\u30FC\u30B9\u304C\u7F8E\u5473\u3057\u3044",
  "id" : 308115855462498307,
  "created_at" : "2013-03-03 07:25:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308115506274127872",
  "text" : "@kotorin_z \u3048\u3063\u3001\u3042\u308C\u3063",
  "id" : 308115506274127872,
  "created_at" : "2013-03-03 07:23:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308115109518139392",
  "text" : "@kotorin_z \u5727\u5012\u7684\u98F2\u307F\u3084\u3059\u3055\u3067\u3059\u3088\u306D\uFF01\uFF01",
  "id" : 308115109518139392,
  "created_at" : "2013-03-03 07:22:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308115004597608448",
  "text" : "[\u3086\u308B\u307C]\u78BA\u7387\u64CD\u4F5C\u306E\u30B9\u30AD\u30EB\u30DB\u30EB\u30C0\u30FC",
  "id" : 308115004597608448,
  "created_at" : "2013-03-03 07:21:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308114606356832256",
  "text" : "\u68EE\u4F0A\u8535\u306E\u62BD\u9078\u653E\u308A\u8FBC\u3093\u3067\u6765\u305F\u3051\u3069\u78BA\u738710%\u5207\u308B\u3089\u3057\u3044\u3067\u3059\u305E\u301C",
  "id" : 308114606356832256,
  "created_at" : "2013-03-03 07:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308113827298414592",
  "text" : "\u30C7\u30D1\u30FC\u30C8\u3068\u304B\u6587\u5177\u5E97\u3068\u304B\u3064\u3044\u7121\u99C4\u9063\u3044\u3057\u3066\u3057\u307E\u3046\u2026",
  "id" : 308113827298414592,
  "created_at" : "2013-03-03 07:17:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308091338933563392",
  "text" : "\u4F55\u304B\u3068\u9813\u632B\u3057\u3059\u304E( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 308091338933563392,
  "created_at" : "2013-03-03 05:47:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308079916342210561",
  "text" : "\u307E\u305F\u6DF1\u3005\u714E\u308A\u304C\u3042\u3063\u305F\u304B\u3089\u306A\u304A\u30CF\u30C3\u30D4\u30FC",
  "id" : 308079916342210561,
  "created_at" : "2013-03-03 05:02:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/LbB16TAOk6",
      "expanded_url" : "http:\/\/4sq.com\/XOKzqV",
      "display_url" : "4sq.com\/XOKzqV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.005932019, 135.7698208094 ]
  },
  "id_str" : "308079794120183808",
  "text" : "\u8C61\u5DE5\u5834\u306E\u30CF\u30C3\u30D4\u30FC\u30A8\u30F3\u30C9 (@ Elephant Factory Coffee) http:\/\/t.co\/LbB16TAOk6",
  "id" : 308079794120183808,
  "created_at" : "2013-03-03 05:02:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307920076370219009",
  "text" : "\u306A\u3093\u304B\u3082\u3046\u8272\u3005\u305F\u3076\u3093\u8D77\u304D\u3089\u308C\u306A\u3044\u306E\u3067\u5BDF\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 307920076370219009,
  "created_at" : "2013-03-02 18:27:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307912796300001280",
  "text" : "\u5B9F\u969B\u30E9\u30C6\u30F3\u8A9E\u3001(\u4F55\u8A9E\u306B\u3060\u304B\u77E5\u3089\u3093\u304C)\u7FFB\u8A33\u30EC\u30D9\u30EB\u307E\u3067\u51FA\u6765\u308C\u3070\u4ED5\u4E8B\u306B\u306F\u56F0\u3089\u306A\u3044\u3089\u3057\u3044\u3051\u3069\u306A\u30FC[\u30E9\u30C6\u30F3\u8A9E\u3067\u3057\u304B\u306A\u3044\u6587\u732E\u304C\u5C71\u306E\u3088\u3046\u306B\u3042\u308B\u3068\u304B\u306A\u3044\u3068\u304B]",
  "id" : 307912796300001280,
  "created_at" : "2013-03-02 17:58:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307912246502244352",
  "text" : "\"\u3061\u3083\u3093\u3068\"\u306B\u8272\u3005\u80CC\u8CA0\u308F\u305B\u3066\u3044\u308B\u3051\u308C\u3069",
  "id" : 307912246502244352,
  "created_at" : "2013-03-02 17:56:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307911902472839169",
  "geo" : { },
  "id_str" : "307912170568577025",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3044\u3084\u307E\u3058\u30E9\u30C6\u30F3\u8A9E\u3061\u3083\u3093\u3068\u51FA\u6765\u308B\u52B4\u529B\u3092\u53AD\u308F\u306A\u3044\u5974\u306F\u4F55\u3067\u3082\u3067\u304D\u305D\u3046\u306A\u611F\u3042\u308B\u3088",
  "id" : 307912170568577025,
  "in_reply_to_status_id" : 307911902472839169,
  "created_at" : "2013-03-02 17:55:56 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307911960127750144",
  "text" : "\u5468\u308A\u306B\u3054\u5B66\u53CB\u3001\u3068\u3044\u3046\u304B\u8A9E\u5B66\u53A8\u304C\u5C45\u308B\u3051\u3069\u5C0A\u656C\u306B\u5024\u3059\u308B",
  "id" : 307911960127750144,
  "created_at" : "2013-03-02 17:55:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307911722100989952",
  "text" : "\u3048\u3093\u3069\u300C\u82F1\u8A9E\u304F\u3089\u3044\u3067\u7518\u3048\u3093\u306A\u3001\u82F1\u8A9E\u3001 \u30C9\u30A4\u30C4\u8A9E\u3001\u30D5\u30E9\u30F3\u30B9\u8A9E\u304F\u3089\u3044\u306F\u3084\u3063\u3066\u308B\u5974\u3060\u3063\u3066\u3044\u308B\u3060\u308D\u300D\n\u3048\u3093\u3069\u300C\u30A6\u30A3\u30C3\u30B9\u300D",
  "id" : 307911722100989952,
  "created_at" : "2013-03-02 17:54:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307911351014158336",
  "text" : "\u5C11\u306A\u304F\u3068\u3082\u4ECA\u8003\u3048\u3066\u3044\u308B\u3069\u306E\u5206\u91CE\u3067\u884C\u304F\u306B\u3057\u3066\u3082\u82F1\u8A9E\u6587\u732E\u306F\u907F\u3051\u3089\u308C\u306C\u3001\u3068\u3044\u3046\u304B\u7B2C\u4E8C\u5916\u56FD\u8A9E\u907F\u3051\u3089\u308C\u308B\u3060\u3051\u826F\u3044\u3068\u601D\u3046\u3079\u3057\u3002",
  "id" : 307911351014158336,
  "created_at" : "2013-03-02 17:52:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307910891104526336",
  "geo" : { },
  "id_str" : "307911112244998144",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u305D\u308C\u306A[\u5352\u8AD6\u4E91\u3005\u3067\u65E9\u6025\u306B\u5FC5\u8981\u3068\u3055\u308C\u305D\u3046\u306A\u30B9\u30AD\u30EB]",
  "id" : 307911112244998144,
  "in_reply_to_status_id" : 307910891104526336,
  "created_at" : "2013-03-02 17:51:44 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307910929461420034",
  "text" : "\u3053\u3053\u4E8C\u65E5\u304F\u3089\u3044\"\u304A\u8179\u304C\u6E1B\u3063\u3066\u3044\u308B\u611F\u3058\u306F\u3042\u308B\u3051\u308C\u3069\u98DF\u6B32\u7121\u3044\"\u611F\u3058\u304C\u7D9A\u3044\u3066\u3044\u308B",
  "id" : 307910929461420034,
  "created_at" : "2013-03-02 17:51:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307899651418382336",
  "text" : "\u3044\u3064\u4FDD\u5B58\u3057\u305F\u304B\u3082\u826F\u304F\u5206\u304B\u3089\u306A\u3044\u3001\u3044\u3064\u8AAD\u3080\u306E\u304B\u3082\u5206\u304B\u3089\u306A\u3044PDF\u3092\u6574\u7406\u3059\u308B",
  "id" : 307899651418382336,
  "created_at" : "2013-03-02 17:06:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307883547270733826",
  "text" : "\u9762\u5012\u306A\u4F5C\u696D\u3092\u307E\u3068\u3081\u3066\u6F70\u3059",
  "id" : 307883547270733826,
  "created_at" : "2013-03-02 16:02:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307882508710731776",
  "text" : "\u30B0\u30EC\u30FC\u30D7\u30D5\u30EB\u30FC\u30C4\u30B8\u30E5\u30FC\u30B9",
  "id" : 307882508710731776,
  "created_at" : "2013-03-02 15:58:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307882378582450176",
  "text" : "\u7720\u3044\u3001\u76EE\u304C\u75DB\u3044\u3001\u5589\u4E7E\u3044\u305F",
  "id" : 307882378582450176,
  "created_at" : "2013-03-02 15:57:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307882017830359041",
  "text" : "3\u6642\u9593\u307B\u3069\u6642\u9593\u304C\u3059\u3063\u98DB\u3093\u3060",
  "id" : 307882017830359041,
  "created_at" : "2013-03-02 15:56:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307822717879590913",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 307822717879590913,
  "created_at" : "2013-03-02 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307798293432393728",
  "text" : "\u60B2\u75DB\u4F1D\u51FA\u3066\u308B\u306E\u304B\u2026",
  "id" : 307798293432393728,
  "created_at" : "2013-03-02 10:23:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 2, 10 ],
      "id_str" : "145536184",
      "id" : 145536184
    }, {
      "name" : "\u305B\u3064\u306A",
      "screen_name" : "seihosetuna",
      "indices" : [ 11, 23 ],
      "id_str" : "141997069",
      "id" : 141997069
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 24, 37 ],
      "id_str" : "295206903",
      "id" : 295206903
    }, {
      "name" : "\u304D\u3061\u3088\u304E",
      "screen_name" : "larvitar1031",
      "indices" : [ 38, 51 ],
      "id_str" : "785969384",
      "id" : 785969384
    }, {
      "name" : "\u6D85\u69C3",
      "screen_name" : "_ne_ha_n_",
      "indices" : [ 52, 62 ],
      "id_str" : "499591313",
      "id" : 499591313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307782248990642177",
  "text" : ". @chr1233 @seihosetuna @nisehorrrrrn @larvitar1031 @_ne_ha_n_ \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 307782248990642177,
  "created_at" : "2013-03-02 09:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307776372544253952",
  "text" : "\u8840\u30E2\u30CA\u30DF\u3060\u3082\u7121\u3044",
  "id" : 307776372544253952,
  "created_at" : "2013-03-02 08:56:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307775184742526976",
  "text" : "\u3068\u3066\u3082\u3088\u304F\u3072\u3048\u3066\u308B",
  "id" : 307775184742526976,
  "created_at" : "2013-03-02 08:51:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307774881410453505",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 307774881410453505,
  "created_at" : "2013-03-02 08:50:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307774852998254592",
  "text" : "\u3055\u3063\u3066\u3055\u3066",
  "id" : 307774852998254592,
  "created_at" : "2013-03-02 08:50:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307774595686100992",
  "text" : "\u307E\u305A\u306F\u30B3\u30BF\u30C4\u304B\u3089\u51FA\u308B\u30DF\u30C3\u30B7\u30E7\u30F3",
  "id" : 307774595686100992,
  "created_at" : "2013-03-02 08:49:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307774398125993984",
  "text" : "\u305D\u3046\u3060\u51B7\u8535\u5EAB\u306B\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3042\u308B\u306E\u3060\u3063\u305F",
  "id" : 307774398125993984,
  "created_at" : "2013-03-02 08:48:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307774243536515073",
  "text" : "\u8840\u3082\u6D99\u3082\u306A\u3044\u5974\u3063\u3066\u3084\u3070\u3044\u306E\u3067\u306F",
  "id" : 307774243536515073,
  "created_at" : "2013-03-02 08:47:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307773833396494336",
  "geo" : { },
  "id_str" : "307774070886387712",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5F7C\u826F\u304F\u6CE3\u3044\u3066\u308B\u304B\u3089",
  "id" : 307774070886387712,
  "in_reply_to_status_id" : 307773833396494336,
  "created_at" : "2013-03-02 08:47:11 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307773588818235392",
  "geo" : { },
  "id_str" : "307773773556350976",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3064\u307E\u308A\u76F8\u8EE2\u79FB\u3055\u3093\u6700\u5F37",
  "id" : 307773773556350976,
  "in_reply_to_status_id" : 307773588818235392,
  "created_at" : "2013-03-02 08:46:00 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307773666291236864",
  "text" : "\u4EBA\u9593\u306E\u69CB\u3063\u3066\u30FC\u69CB\u3063\u3066\u30FC\u306F\u5927\u62B5\u3046\u308F\u3041\u2026\u3063\u3066\u601D\u3046\u3051\u3069\u732B\u306E\u69CB\u3063\u3066\u30FC\u69CB\u3063\u3066\u30FC\u306F\u597D\u304D\u306A\u3042\u305F\u308A\u4EBA\u9593\u3088\u308A\u732B\u306E\u65B9\u304C\u597D\u304D\u306A\u306E\u304B\u81EA\u5206",
  "id" : 307773666291236864,
  "created_at" : "2013-03-02 08:45:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307773238707101698",
  "geo" : { },
  "id_str" : "307773403438395392",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6700\u5F8C\u306E\u4E00\u8A00\u3067\u6D99\u304C\u6B62\u307E\u3089\u306A\u3044",
  "id" : 307773403438395392,
  "in_reply_to_status_id" : 307773238707101698,
  "created_at" : "2013-03-02 08:44:32 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307773144914071552",
  "text" : "\u3067\u3082\u732B\u3063\u3066\u5FD9\u3057\u3044\u6642\u306B\u9650\u3063\u3066\u69CB\u3063\u3066\u6B32\u3057\u304C\u308B\u30A4\u30E1\u30FC\u30B8\u3042\u308B",
  "id" : 307773144914071552,
  "created_at" : "2013-03-02 08:43:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307772847072370689",
  "geo" : { },
  "id_str" : "307772960658292736",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3060\u3088\u306D.",
  "id" : 307772960658292736,
  "in_reply_to_status_id" : 307772847072370689,
  "created_at" : "2013-03-02 08:42:46 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307772502099230720",
  "geo" : { },
  "id_str" : "307772717841661952",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u3053\u306F\u304A\u3068\u306A\u3057\u304F\u5F15\u3044\u3066\u5411\u3053\u3046\u304C\u69CB\u3063\u3066\u30FC\u3063\u3066\u6765\u305F\u3089\u540C\u3058\u4E8B\u3092\u3057\u3066\u3059\u308C\u9055\u3044\u611F\u3092\u697D\u3057\u3080\u306E\u3060\u3088[\uFF1F]",
  "id" : 307772717841661952,
  "in_reply_to_status_id" : 307772502099230720,
  "created_at" : "2013-03-02 08:41:48 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307772259123200002",
  "text" : "@ayuretti \u30CB\u30E5\u30FC\u30E8\u30FC\u30AB\u30FC\u3082\u6C17\u3065\u3044\u3066\u308B",
  "id" : 307772259123200002,
  "created_at" : "2013-03-02 08:39:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307772206312722432",
  "text" : "@kotorin_z \u732B\u304C\u300C\u4ECA\u306F\u6C17\u5206\u3058\u3083\u306A\u3044\u3088\u300D\u3063\u3066\u611F\u3058\u3067\u901A\u308A\u904E\u304E\u308B\u306E\u7D50\u69CB\u597D\u304D\u3067\u3059[\u9006\u3082]",
  "id" : 307772206312722432,
  "created_at" : "2013-03-02 08:39:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307771457814032385",
  "text" : "\u732B\u306B\u69CB\u3063\u3066\u30FC\u69CB\u3063\u3066\u30FC\u3063\u3066\u3057\u305F\u3044[\u3042\u308B\u3044\u306F\u3055\u308C\u305F\u3044]",
  "id" : 307771457814032385,
  "created_at" : "2013-03-02 08:36:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307770710120620032",
  "text" : "\u732B\u304C\u7A81\u7136\u6CCA\u3081\u3066\u304F\u308C\u3063\u3066\u3046\u3061\u306B\u6765\u306A\u3044\u304B\u306A\u3041",
  "id" : 307770710120620032,
  "created_at" : "2013-03-02 08:33:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307770562359472128",
  "text" : "@YohjiGureito \u732B\u98FC\u3063\u3066\u5BB6\u3067\u30B3\u30FC\u30D2\u30FC\u3092\u6DF9\u308C\u308B",
  "id" : 307770562359472128,
  "created_at" : "2013-03-02 08:33:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307770166731735042",
  "text" : "\u6587\u623F\u5177\u3055\u3084\u3093\u3067\u9632\u6C34\u30CE\u30FC\u30C8\u3060\u3051\u8CB7\u3063\u3066\u304D\u3066\u52C9\u5F37\u3057\u305F\u547D\u984C\u3060\u3051\u66F8\u3044\u3066\u30B5\u30A6\u30CA\u3067\u8A3C\u660E\u3092\u5FA9\u7FD2\u3059\u308B\u4F5C\u6226\uFF1F",
  "id" : 307770166731735042,
  "created_at" : "2013-03-02 08:31:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307768905244504064",
  "text" : "\u75DB\u3044\u306E\u5ACC\u3067\u3059",
  "id" : 307768905244504064,
  "created_at" : "2013-03-02 08:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307768826643226624",
  "text" : "\u30EA\u30B9\u30C8\u30AB\u30C3\u30C8\u3068\u304B\u3059\u308B\u4EBA\u3084\u3070\u3044\u3068\u601D\u3046",
  "id" : 307768826643226624,
  "created_at" : "2013-03-02 08:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307768719659122688",
  "text" : "\u6C57\u304C\u6EF2\u307F\u305F\u6642\u306E\u75DB\u307F\u3092\u60F3\u50CF\u3059\u308B\u3060\u3051\u3067\u3084\u3070\u3044",
  "id" : 307768719659122688,
  "created_at" : "2013-03-02 08:25:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307768590898196481",
  "text" : "\u30B5\u30A6\u30CA\u4E8C\u5468\u76EE\u306B\u884C\u3051\u306A\u304B\u3063\u305F\u306E\u304C\u6B8B\u5FF5",
  "id" : 307768590898196481,
  "created_at" : "2013-03-02 08:25:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307768514847047680",
  "text" : "\u3057\u304B\u3082\u92AD\u6E6F\u3067\u4F53\u6D17\u3063\u3066\u308B\u6642\u306B\u6C17\u3065\u3044\u305F\u3082\u306E\u3060\u304B\u3089\u77F3\u9E78\u304C\u6EF2\u307F\u3066\u2582\u2585\u2587\u2588\u2593\u2592\u2591(\u2019\u03C9\u2019)\u2591\u2592\u2593\u2588\u2587\u2585\u2582 \u3046\u308F\u3042\u3042\u3042\u3042\u3063\u3066\u306A\u3063\u305F",
  "id" : 307768514847047680,
  "created_at" : "2013-03-02 08:25:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307768058766843904",
  "text" : "@kotorin_z \u50B7\u304C\u4E8C\u3064\u51FA\u3066\u304D\u3066\u308B\u306E\u30A2\u30EC\u3067\u3059\u306D",
  "id" : 307768058766843904,
  "created_at" : "2013-03-02 08:23:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307766610465259520",
  "text" : "\u5207\u308A\u50B7\u306B\u6C17\u4ED8\u3044\u305F\u77AC\u9593\u304B\u3089\u75DB\u307F\u59CB\u3081\u308B\u73FE\u8C61\u306B\u540D\u524D\u3092\u3064\u3051\u305F\u3044",
  "id" : 307766610465259520,
  "created_at" : "2013-03-02 08:17:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307748771146657793",
  "text" : "\u6C17\u5206\u8EE2\u63DB\u306B\u5916\u306B\u51FA\u305F\u3089\u96EA",
  "id" : 307748771146657793,
  "created_at" : "2013-03-02 07:06:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307725264958418944",
  "text" : "\u4E16\u754C\u6A39\u306A\u3093\u3061\u3083\u3089\u307E\u3060\u30B3\u30F3\u30C6\u30F3\u30C4\u6027\u3092\u4FDD\u3063\u3066\u308B\u306E",
  "id" : 307725264958418944,
  "created_at" : "2013-03-02 05:33:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307671260614242304",
  "text" : "\u767E\u307E\u3059\u5FAE\u5206\u65B9\u7A0B\u5F0F\u306E\u30EA\u30F3\u30AF\u3069\u3063\u304B\u306B\u3068\u3063\u3066\u3042\u308B\u306A",
  "id" : 307671260614242304,
  "created_at" : "2013-03-02 01:58:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3046\u3057\u3046\u3057\u306F\u3059\u3054\u3044",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307670624518696960",
  "text" : "#\u3046\u3057\u3046\u3057\u306F\u3059\u3054\u3044",
  "id" : 307670624518696960,
  "created_at" : "2013-03-02 01:56:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7384\u691B(\u304F\u308D\u3082\u307F\u3058)",
      "screen_name" : "mathematica2357",
      "indices" : [ 14, 30 ],
      "id_str" : "529376719",
      "id" : 529376719
    }, {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 31, 40 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307670477864841216",
  "text" : ". @umichoco11 @mathematica2357 @pankashi \u304A\u306F\u3088\u3054\u3056\u3044\u307E\u305F",
  "id" : 307670477864841216,
  "created_at" : "2013-03-02 01:55:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307670152281993217",
  "text" : "\u9F3B\u304C\u30E0\u30BA\u30E0\u30BA\u3059\u308B\u3042\u305F\u308A\u305D\u308D\u305D\u308D\u82B1\u7C89\u304C",
  "id" : 307670152281993217,
  "created_at" : "2013-03-02 01:54:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307669291589849088",
  "text" : "\u3067\u3082\u5B9F\u969B\u5FC3\u5730\u3088\u304F\u8CA0\u3051\u308B\u306E\u3063\u3066\u7D50\u69CB\u96E3\u3057\u3044\u306E\u3067\u3042\u308B\u3002",
  "id" : 307669291589849088,
  "created_at" : "2013-03-02 01:50:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307668916623261696",
  "text" : "\u8CA0\u3051\u305F\u30C1\u30FC\u30E0\u306E\u4EBA\u306E\u614B\u5EA6\u304C\u6C17\u306B\u98DF\u308F\u306A\u304B\u3063\u305F\u3002\u8CA0\u3051\u305F\u306A\u3089\u6F54\u304F\u7DBA\u9E97\u306B\u8CA0\u3051\u3088\u3046\u3002",
  "id" : 307668916623261696,
  "created_at" : "2013-03-02 01:49:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307668643456614400",
  "text" : "\u5B9F\u969B\u306F\u4E09\u56DE\u306B\u4E00\u56DE\u306F\u4F11\u3080\u3084\u308B\u6C17\u306E\u306A\u3055\u306A\u306E\u3067\u30A2\u30EC\u3067\u3059\u306D",
  "id" : 307668643456614400,
  "created_at" : "2013-03-02 01:48:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307668524908826625",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u4F53\u80B2\u3067\u624B\u3092\u4F7F\u3063\u3066\u826F\u3044\u30B5\u30C3\u30AB\u30FC\u3068\u304B\u3044\u3046\u8B0E\u306E\u7AF6\u6280\u3067\u3068\u3066\u3082\u6D3B\u8E8D\u3059\u308B\u5922\u3092\u898B\u305F\u3002",
  "id" : 307668524908826625,
  "created_at" : "2013-03-02 01:47:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307668157190008833",
  "text" : "\u306C\u308B\u3063\u3068\u76EE\u899A\u3081\u305F",
  "id" : 307668157190008833,
  "created_at" : "2013-03-02 01:46:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nicovideo.jp\" rel=\"nofollow\"\u003Eniconico iOS\u30A2\u30D7\u30EA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sm2801684",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/3oE7pndBVV",
      "expanded_url" : "http:\/\/nico.ms\/sm2801684",
      "display_url" : "nico.ms\/sm2801684"
    } ]
  },
  "geo" : { },
  "id_str" : "307531727214096384",
  "text" : "\u3069\u3046\u3057\u3066\u304B\u8033\u304B\u3089\u96E2\u308C\u306A\u3044 \u3010MAD\u3011\u4FD7\u30FB\u3055\u3088\u306A\u3089\u7D76\u671B\u5148\u751F\u300C\u30C8\u30ED\u30A4\u30E1\u30E9\u30A4\u300D (2:18) #sm2801684 http:\/\/t.co\/3oE7pndBVV",
  "id" : 307531727214096384,
  "created_at" : "2013-03-01 16:44:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307523128106577920",
  "text" : "\u3082\u30461\u6642\u304B\u3001\u7720\u3044\u308F\u3051\u3060\u306A",
  "id" : 307523128106577920,
  "created_at" : "2013-03-01 16:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307372492790591488",
  "text" : "\u3053\u308C\u306F\u30CE\u30FC\u30A8\u30B9\u30B1\u30FC\u30D7",
  "id" : 307372492790591488,
  "created_at" : "2013-03-01 06:11:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307372164116529153",
  "text" : "\u96E8\u3068\u304B\u3044\u3046\u7D76\u671B",
  "id" : 307372164116529153,
  "created_at" : "2013-03-01 06:10:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307358486340173824",
  "text" : "\u7384\u7C73\u8336\u3068\u70CF\u9F8D\u8336\u3092\u3068\u3063\u304B\u3048\u3072\u3063\u304B\u3048\u3057\u3066\u308B",
  "id" : 307358486340173824,
  "created_at" : "2013-03-01 05:15:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307354842278555648",
  "text" : "\u9AD8\u5CF6\u5C4B\u3067\u62BD\u9078\u304B\u2026",
  "id" : 307354842278555648,
  "created_at" : "2013-03-01 05:01:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307354438736150529",
  "text" : "\u3053\u306E\u524D\u89AA\u621A\u306E\u304A\u5BB6\u3067\u9802\u3044\u305F\u306E\u304C\u3068\u3063\u3066\u3082\u7F8E\u5473\u3057\u304B\u3063\u305F",
  "id" : 307354438736150529,
  "created_at" : "2013-03-01 04:59:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307354259349970944",
  "text" : "\u68EE\u4F0A\u8535\u6B32\u3057\u3044\u306A\u3041\u3001\u81EA\u5206\u306E\u30DA\u30FC\u30B9\u306A\u30891.8l\u30672\u5E74\u306F\u4FDD\u3064",
  "id" : 307354259349970944,
  "created_at" : "2013-03-01 04:59:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307324623505199104",
  "text" : "\u5272\u3068\u60AA\u5922\u3060\u3063\u305F\u3001\u6B6F\u304C\u629C\u3051\u308B\u4EE5\u5916\u306B\u3082\u3044\u308D\u3044\u308D",
  "id" : 307324623505199104,
  "created_at" : "2013-03-01 03:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307324462972420097",
  "text" : "\u307E\u305F\u6B6F\u304C\u629C\u3051\u308B\u5922\u3092\u898B\u305F",
  "id" : 307324462972420097,
  "created_at" : "2013-03-01 03:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307322283419119616",
  "text" : "\u4E16\u754C\u6A39\u306A\u3093\u3061\u3083\u3089\u307E\u3060\u3044\u305F\u306E",
  "id" : 307322283419119616,
  "created_at" : "2013-03-01 02:51:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307156954902577152",
  "text" : "\u60C5\u5F31\u3092\u8131\u3057\u3066\u5E7E\u3064\u304B\u9762\u767D\u305D\u3046\u306A\u96FB\u5B50\u30D6\u30C3\u30AF\u3092\u843D\u3068\u3057\u3066\u307F\u305F\uFF0E\u5E03\u56E3\u3067\u8AAD\u307F\u3064\u3064\u7720\u304F\u306A\u308B\u3068\u3057\u3088\u3046\uFF0E",
  "id" : 307156954902577152,
  "created_at" : "2013-02-28 15:54:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3060\u30FC\u3059\u306A",
      "screen_name" : "DarknessCatX",
      "indices" : [ 0, 13 ],
      "id_str" : "258868251",
      "id" : 258868251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307148835061383168",
  "geo" : { },
  "id_str" : "307148867344924673",
  "in_reply_to_user_id" : 258868251,
  "text" : "@DarknessCatX \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 307148867344924673,
  "in_reply_to_status_id" : 307148835061383168,
  "created_at" : "2013-02-28 15:22:51 +0000",
  "in_reply_to_screen_name" : "DarknessCatX",
  "in_reply_to_user_id_str" : "258868251",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307148795131621378",
  "text" : "[\u5185\u5BB9\u304C\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u7121\u3044\uFF57\uFF57\uFF57\uFF57\u3088\u3046\uFF57\uFF57\uFF57\uFF57\uFF57]",
  "id" : 307148795131621378,
  "created_at" : "2013-02-28 15:22:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307148731294289920",
  "text" : "\u4E45\u3005\u306B\u3068\u308A\u3068\u3081\u306E\u306A\u3044\u30EA\u30D7\u30E9\u30A4\u306E\u3084\u308A\u3068\u3057\u3066\u3044\u308B\u611F\u3042\u308B",
  "id" : 307148731294289920,
  "created_at" : "2013-02-28 15:22:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307148623383248897",
  "geo" : { },
  "id_str" : "307148675078029312",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u8A31\u3059\u3063",
  "id" : 307148675078029312,
  "in_reply_to_status_id" : 307148623383248897,
  "created_at" : "2013-02-28 15:22:05 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307148387516547073",
  "geo" : { },
  "id_str" : "307148509218476033",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3057\u3070\u3089\u304F\u8179\u75DB\u304C\u7D9A\u3044\u3066\u3044\u308B\u79C1\u3078\u306E\u3042\u3066\u3064\u3051\u306F\u3084\u3081\u307E\u3057\u3087\u3046",
  "id" : 307148509218476033,
  "in_reply_to_status_id" : 307148387516547073,
  "created_at" : "2013-02-28 15:21:25 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307148124294639616",
  "geo" : { },
  "id_str" : "307148316217581569",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30AF\u30E9\u30A4\u30F3\u306E\u58FA\u306B\u30AB\u30EC\u30FC\u3092\u6D41\u3057\u8FBC\u3093\u3060\u6642\u306EFlow \u3068\u306F",
  "id" : 307148316217581569,
  "in_reply_to_status_id" : 307148124294639616,
  "created_at" : "2013-02-28 15:20:39 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 0, 10 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307148087405719552",
  "geo" : { },
  "id_str" : "307148140098764800",
  "in_reply_to_user_id" : 158645894,
  "text" : "@eclair_15 \u795D\u676F\u306E\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 307148140098764800,
  "in_reply_to_status_id" : 307148087405719552,
  "created_at" : "2013-02-28 15:19:57 +0000",
  "in_reply_to_screen_name" : "eclair_15",
  "in_reply_to_user_id_str" : "158645894",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307148089892950018",
  "text" : "\u96FB\u5B50\u30D6\u30C3\u30AF\u3068\u304B\u30B8\u30E3\u30FC\u30CA\u30EB\u306B\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u306A\u3044\u60C5\u5F31\u3092\u8131\u3059\u308B\u4E88\u5B9A\u3060\u3063\u305F\u306E\u3060\u304C\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u306A\u3044",
  "id" : 307148089892950018,
  "created_at" : "2013-02-28 15:19:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307147861232058369",
  "geo" : { },
  "id_str" : "307147952323981312",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30AF\u30E9\u3061\u3083\u3093\u3068\u30A4\u30F3\u3061\u3083\u3093\u304C\u5FDC\u7B54\u3057\u3066\u304F\u308C\u306A\u3044\u306E\u3067\u3059",
  "id" : 307147952323981312,
  "in_reply_to_status_id" : 307147861232058369,
  "created_at" : "2013-02-28 15:19:13 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307147806039236608",
  "text" : "\u30AF\u30FC\u30E9\u30FC\u30A4\u30FC\u30F3\u30FC\uFF01\uFF01\uFF01",
  "id" : 307147806039236608,
  "created_at" : "2013-02-28 15:18:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307147200943771649",
  "text" : "KULINE\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u306A\u3044\u306E\u50D5\u3060\u3051\uFF1F",
  "id" : 307147200943771649,
  "created_at" : "2013-02-28 15:16:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307144531835486208",
  "text" : "\u30E2\u30C7\u30B9\u30C6\u30E9\u6C0F\u306A\u3093\u3067\u305D\u308CRT\u3057\u307E\u3057\u305F\u3057",
  "id" : 307144531835486208,
  "created_at" : "2013-02-28 15:05:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]