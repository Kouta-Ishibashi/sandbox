Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22486136239",
  "geo" : { },
  "id_str" : "22491503829",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u6BCE\u56DE\u601D\u3046\u304C\u3001\u4F55\u3092\u4EE5\u3063\u3066\u300C\u4F1D\u308F\u3063\u305F\u300D\u306E\u304B\u3092\u5B9A\u7FA9\u3057\u3066\u304F\u308C\u306A\u3044\u3068\u305D\u306E\u30D1\u30FC\u30BB\u30F3\u30C6\u30FC\u30B8\u306F\u4F55\u306E\u8AAC\u5F97\u529B\u3082\u6301\u305F\u306A\u3044\u3088\u3002\u307E\u3041\u305D\u3046\u3044\u3046\u610F\u5473\u3067\u304A\u524D\u306E\u30C4\u30A4\u30FC\u30C8\u306F\u300C\u4F1D\u308F\u3063\u3066\u300D\u3044\u306A\u3044\u3051\u3069\u306A\uFF57",
  "id" : 22491503829,
  "in_reply_to_status_id" : 22486136239,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22496371906",
  "geo" : { },
  "id_str" : "22514357605",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \uFF2B\uFF57\uFF53\uFF4B",
  "id" : 22514357605,
  "in_reply_to_status_id" : 22496371906,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22537476059",
  "text" : "mixi\u3067\u300C\u306E\u3073\u308B\u304B\u3089\u3069\u3046\u305E\uFF01\u300D\u306E\u30B3\u30DF\u30E5\u4F5C\u308A\u307E\u3057\u305F\u3002\u5E83\u3081\u3066\u3063\u3066\u304F\u308C\u308B\u3068\u3046\u308C\u3057\u3044\u3067\u3059\uFF57http:\/\/mixi.jp\/view_community.pl?id=5219298",
  "id" : 22537476059,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22413685731",
  "geo" : { },
  "id_str" : "22420992886",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6642\u4EE3\u306F\u5909\u308F\u3063\u305F\u306A\u3001\u524D\u306F\u671D\u6BD4\u5948\u3060\u306E\u6AFB\u7530\u3060\u306E\u3060\u3063\u305F\u306E\u306B\u2026",
  "id" : 22420992886,
  "in_reply_to_status_id" : 22413685731,
  "created_at" : "2010-08-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22185952432",
  "text" : "\u30E9\u30FC\u30B8\u30E3\u30F3\u306A\u3093\u304B\u751F\u307E\u308C\u3066\u3053\u306A\u3051\u308C\u3070\u3088\u304B\u3063\u305F\u306E\u306B",
  "id" : 22185952432,
  "created_at" : "2010-08-26 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22049847452",
  "geo" : { },
  "id_str" : "22058424352",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3055\u3055\u3084\u304B\u306A\u89AA\u5207\u306E\u6709\u7121\u306F\u4EBA\u3092\u8868\u3059\u3088\u306A",
  "id" : 22058424352,
  "in_reply_to_status_id" : 22049847452,
  "created_at" : "2010-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21806270705",
  "geo" : { },
  "id_str" : "21813835680",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3046\u307E\u305D\u3046\u306A\u30B3\u30FC\u30D2\u30FC\u3060",
  "id" : 21813835680,
  "in_reply_to_status_id" : 21806270705,
  "created_at" : "2010-08-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21746753583",
  "text" : "\u30A8\u30B9\u30AB\u30EC\u30FC\u30BF\u30FC\u306E\u5DE6\u306B\u7ACB\u3064\u3053\u3068\u306B\u6238\u60D1\u3044\u3092\u899A\u3048\u3066\u3057\u307E\u3063\u305F",
  "id" : 21746753583,
  "created_at" : "2010-08-21 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21624555235",
  "text" : "@koketomi \u89AA\u30EA\u30FC\u4E00\u767A\u306F\u56DE\u907F\u3059\u3079\u304D\u3002\u5F79\u6E80\u30EC\u30D9\u30EB\u5F35\u3063\u3066\u308C\u3070\u5225\u3060\u304C\uFF57\u30C9\u30F3\u30DE\u30A4",
  "id" : 21624555235,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21667454916",
  "text" : "@chisa10404 \u3046\u3093\u3000\u6771\u4EAC\u3060\u3088\u30FC\u3001\u3069\u3046\u3057\u305F\uFF1F",
  "id" : 21667454916,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21668548277",
  "text" : "@chisa10404 \u8FD4\u4FE1\u3057\u305F\u306E\u304C\u6D88\u3048\u3066\u308B\u304B\u3089\u3082\u3046\u4E00\u56DE\uFF57\u304B\u3076\u3063\u3066\u305F\u3089\u3059\u307E\u306A\u3044\uFF57\u307E\u3060\u6771\u4EAC\u306B\u3044\u307E\u3059\u3002",
  "id" : 21668548277,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21680335783",
  "text" : "@chisa10404 \u6687\u306A\u65E5\u306E\u307B\u3046\u304C\u591A\u3044\u304B\u3089\u9069\u5F53\u306B\u9023\u7D61\u304F\u308C\u308C\u3070\u3044\u3044\u3068\u601D\u3046\u3088\uFF01\u3044\u307E\u3093\u3068\u3053\uFF12\uFF11\u4E38\u3005\u3068\uFF12\uFF13\u306E\u5915\u65B9\u4EE5\u5916\u6687",
  "id" : 21680335783,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21680625428",
  "text" : "\u5F1F\uFF08\u4FFA\u306B\u5BFE\u3057\u3066\uFF09\u300C\u3042\u3052\u3042\u3057\u53D6\u308B\u306A\u3088\u306A\u300D\u3000\u6B8B\u5FF5\u306A\u59B9\u300C\u201D\u3042\u3052\u3042\u3057\u201D\u3063\u3066\u4F55\uFF1F\u300D\u3000\u2015\u4F1A\u8A71\u7D42\u4E86",
  "id" : 21680625428,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21685542621",
  "text" : "\u3042\u3057\u3001\u304B\u306B\u3001\u3055\u3055\u308C\u305F\u3000\u304B\u306B\u3001\u3042\u3057\u3001\u3055\u3055\u308C\u305F   \u3042\u3057\u304B\u306B\u3001\u3055\u3055\u308C\u305F     \u304B\u306B(\u304C)\u3042\u3057\u3001\u3055\u3055\u308C\u305F \u65E5\u672C\u8A9E\u3084\u3084\u3053\u3057\u3044\u306D\u3047",
  "id" : 21685542621,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21685587468",
  "text" : "\u4E0B\u3089\u3093\u3053\u3066\u3084\u3089\u3093\u3068\u5BDD\u306A\uFF57\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 21685587468,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21575452818",
  "text" : "\u80CC\u4E2D\u304B\u3089\u80A9\u306B\u304B\u3051\u3066\u306E\u307F\u7015\u6B7B",
  "id" : 21575452818,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21448740530",
  "text" : "\u305D\u3057\u3066\u591C\u304C\u660E\u3051\u305F\u2026\uFF01",
  "id" : 21448740530,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21388261215",
  "geo" : { },
  "id_str" : "21388294528",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u306A\u305C\uFF57",
  "id" : 21388294528,
  "in_reply_to_status_id" : 21388261215,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21398742815",
  "text" : "@koketomi \u3053\u306E\u6642\u9593\u306B\u884C\u304F\u306E\u304C\u3055\u3059\u304C\u3060\uFF57",
  "id" : 21398742815,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21424867176",
  "text" : "\u3042\u30FC\u3001\uFF11\uFF10\u6642\u9593\u7761\u7720\u306B\uFF11\u6642\u9593\u306E\u663C\u5BDD\u3058\u3083\u3055\u3059\u304C\u306B\u7720\u308C\u306A\u3044\u308Forz",
  "id" : 21424867176,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21296352298",
  "text" : "@koketomi \u30B9\u30D1\u30ED\u30DC\u307F\u305F\u3044\u306A\u3084\u3064\u3060\u3063\u3051\uFF1F",
  "id" : 21296352298,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21298771049",
  "text" : "\u7FBD\u751F\u306A\u3046",
  "id" : 21298771049,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21198937636",
  "geo" : { },
  "id_str" : "21199576401",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa  \u306A\u306B\u3084\u3063\u3066\u3093\u3059\u304B\uFF57\uFF57\uFF57\uFF57",
  "id" : 21199576401,
  "in_reply_to_status_id" : 21198937636,
  "created_at" : "2010-08-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21060300877",
  "text" : "@koketomi \u5185\u8A33kwsk",
  "id" : 21060300877,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20963420660",
  "text" : "\u539A\u6728\u306A\u3046",
  "id" : 20963420660,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20970835806",
  "text" : "\u5409\u7965\u5BFA\u306A\u3046",
  "id" : 20970835806,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20864743663",
  "text" : "\u5E73\u57CE\u4EAC\u306A\u3046",
  "id" : 20864743663,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20672226899",
  "text" : "\u5D50\u5C71\u306A\u3046",
  "id" : 20672226899,
  "created_at" : "2010-08-09 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20551581948",
  "text" : "\u9D28\u5DDD\u30C7\u30EB\u30BFnow",
  "id" : 20551581948,
  "created_at" : "2010-08-07 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20459158377",
  "geo" : { },
  "id_str" : "20459331725",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3053\u306ECD\u6559\u6750\u3092\u79FB\u52D5\u4E2D\u306B\u3092\u805E\u3044\u3066\u3044\u308B\u3060\u3051\u3067\u3001\u82E6\u624B\u3060\u3063\u305F\u95A2\u897F\u5F01\u304C\u7C21\u5358\u306B\u8A71\u305B\u308B\u3088\u3046\u306B\u306A\u308A\u307E\u3057\u305F(\u7B11)",
  "id" : 20459331725,
  "in_reply_to_status_id" : 20459158377,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20495668985",
  "text" : "\u671D\u4E94\u6642\u306E\u4EAC\u90FD\u306F\u3001\u3042\u308B\u3044\u306F\u7F8E\u3057\u3044\u3002",
  "id" : 20495668985,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20495749534",
  "text" : "\u30FB\u30FB\u30FB\u30FB\u304A\u4F11\u307F\u306A\u3055\u3044\u3002",
  "id" : 20495749534,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20353554355",
  "text" : "\uFF11\uFF15\u4EE5\u964D\u306A\u3089\u53C2\u52A0\u3057\u305F\u3044\u306A\uFF57\uFF18\u65E5\u306F\u7D50\u5C40\u3069\u3046\u3059\u3093\u306E\u3055",
  "id" : 20353554355,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20306506714",
  "text" : "@chisa10404 \u5439\u3044\u305F\uFF57\uFF57\uFF57\u51FA\u8EAB\u9AD8\u6821\u51FA\u3066\u308B\u306E\u304C\u6C17\u306B\u306A\u308B\u3051\u3069\uFF57",
  "id" : 20306506714,
  "created_at" : "2010-08-04 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20190215417",
  "text" : "\u304A\u3044\u3057\u3044\u30D1\u30F3\u5C4B\u3055\u3093\u3092\u898B\u3064\u3051\u305F\u3002\u3055\u3055\u3084\u304B\u306A\u5E78\u305B\u3002\u3042\u3041\u3001\u8A8D\u3081\u3088\u3046\u3058\u3083\u306A\u3044\u304B\u3002\u79C1\u306F\u30D4\u30ED\u30B7\u30AD\u304C\u597D\u304D\u3060\u3002",
  "id" : 20190215417,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20037147917",
  "geo" : { },
  "id_str" : "20114943393",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u6559\u6388\u300E\u6765\u5E74\u304C\u3093\u3070\u3063\u3066\u304F\u308C\u305F\u307E\u3048\u3002\u300F",
  "id" : 20114943393,
  "in_reply_to_status_id" : 20037147917,
  "created_at" : "2010-08-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20176161353",
  "text" : "\u3055\u3041\u3001\u524D\u671F\u6700\u5F8C\u306E\u30C6\u30B9\u30C8\u3060\u3002\u306A\u3093\u3068\u304B\u3057\u3088\u3046\u3058\u3083\u306A\u3044\u304B\uFF01",
  "id" : 20176161353,
  "created_at" : "2010-08-02 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]