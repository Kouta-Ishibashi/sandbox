Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307A\u307A",
      "screen_name" : "tamago_on_gohan",
      "indices" : [ 0, 16 ],
      "id_str" : "1890303169",
      "id" : 1890303169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605014970242170880",
  "geo" : { },
  "id_str" : "605015204951228416",
  "in_reply_to_user_id" : 1890303169,
  "text" : "@tamago_on_gohan \u3058\u3083\u3070\u3059\u304F\u308A\u3077\u3068\uFF1F",
  "id" : 605015204951228416,
  "in_reply_to_status_id" : 605014970242170880,
  "created_at" : "2015-05-31 14:17:20 +0000",
  "in_reply_to_screen_name" : "tamago_on_gohan",
  "in_reply_to_user_id_str" : "1890303169",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605014777161613313",
  "text" : "\u50D5\u306E\u767A\u8A00\u306B\u5BFE\u3057\u3066\u300C\u306A\u3093\u3068\u304B.K\u300D\u3092\u30A8\u30A2\u30EA\u30D7\u3081\u3044\u3066\u8FD4\u3059\u4EBA\u3068\u300C\u306A\u3093\u3068\u304B.js\u300D\u3092\u30A8\u30A2\u30EA\u30D7\u3081\u3044\u3066\u8FD4\u3059bot\u304C\u5B58\u5728\u3057\u3066\u3044\u308B",
  "id" : 605014777161613313,
  "created_at" : "2015-05-31 14:15:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605014446444941312",
  "text" : "\u60C5\u306B\u30B5\u30B9\u30DE\u30BF\u3092\u7A81\u304D\u523A\u305B\u3070\u30E1\u30A4\u30EB\u30B9\u30C8\u30ED\u30FC\u30E0\u306B\u6D41\u3055\u308C\u308B",
  "id" : 605014446444941312,
  "created_at" : "2015-05-31 14:14:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605014233022001152",
  "text" : "\u5E38\u306B\u4EBA\u306B\u89AA\u5207\u306B\u3057\u3088\u3046\u3001\u307F\u305F\u3044\u306A\u5FC3\u6301\u306B\u306F\u3061\u3087\u3063\u3068\u306A\u308C\u306A\u3044\u306E\u3067",
  "id" : 605014233022001152,
  "created_at" : "2015-05-31 14:13:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605014072086523904",
  "text" : "\u6C17\u5206\u304C\u4E57\u308C\u3070\u89AA\u5207\u306B\u3059\u308B\u3057\u3001\u4E57\u3089\u306A\u3051\u308C\u3070\u5225\u306B\u89AA\u5207\u306B\u3057\u306A\u3044\u3002",
  "id" : 605014072086523904,
  "created_at" : "2015-05-31 14:12:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/dDOOv1YizA",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/604875202095280129",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605013955094810624",
  "text" : "\u52D8\u9055\u3044\u3055\u308C\u308B\u3068\u56F0\u308B\u3051\u3069\u5225\u306B\u30AB\u30C3\u30D7\u30EB\u5168\u822C\u306B\u53B3\u3057\u3044\u307B\u3046\u306E\u3048\u3093\u3069\u3055\u3093\u3067\u306F\u306A\u3044 https:\/\/t.co\/dDOOv1YizA",
  "id" : 605013955094810624,
  "created_at" : "2015-05-31 14:12:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604955953763524609",
  "text" : "\u9762\u5012\u3060\u3057\u30A6\u30A4\u30EB\u30B9\u3076\u3063\u3071\u3059\u308B\u304B\u2026",
  "id" : 604955953763524609,
  "created_at" : "2015-05-31 10:21:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604911371445112832",
  "text" : "\u7720\u8D77\u304D\u3057\u305F\u304B\u3089\u65E9\u3044",
  "id" : 604911371445112832,
  "created_at" : "2015-05-31 07:24:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604878258560049153",
  "text" : "\u9762\u63A5\u5B98\u300C\u9762\u63A5\u306F\u4EE5\u4E0A\u306B\u306A\u308A\u307E\u3059\u304C\u3001\u4F55\u304B\u805E\u3044\u3066\u304A\u304D\u305F\u3044\u4E8B\u3068\u304B\u3042\u308A\u307E\u3059\u304B\uFF1F\u300D\n???\u300C\u8CB4\u65B9\u306E\u305F\u3081\u306B\u304A\u7948\u308A\u3055\u305B\u3066\u304F\u3060\u3055\u3044\u300D",
  "id" : 604878258560049153,
  "created_at" : "2015-05-31 05:13:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604878089718394881",
  "text" : "\u4F01\u696D\u306B\u7948\u3089\u308C\u308B\u524D\u306B\u7A4D\u6975\u7684\u306B\u7948\u3063\u3066\u3044\u3051",
  "id" : 604878089718394881,
  "created_at" : "2015-05-31 05:12:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604877821056401408",
  "text" : "\u5FC5\u8981\u306F\u306A\u3044\u3051\u3069\u305A\u308C\u3066\u3042\u3052\u305F\u3089\u89AA\u5207\u306A\u611F\u3058\u306F\u3059\u308B",
  "id" : 604877821056401408,
  "created_at" : "2015-05-31 05:11:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k1y054",
      "screen_name" : "k1y054",
      "indices" : [ 3, 10 ],
      "id_str" : "86968841",
      "id" : 86968841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604877753016446976",
  "text" : "RT @k1y054: \u3078\uFF1F\u306A\u3093\u3067\u3069\u304F\u5FC5\u8981\u304C\u3042\u308B\u306E\uFF1F&gt;RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604876586295238656",
    "text" : "\u3078\uFF1F\u306A\u3093\u3067\u3069\u304F\u5FC5\u8981\u304C\u3042\u308B\u306E\uFF1F&gt;RT",
    "id" : 604876586295238656,
    "created_at" : "2015-05-31 05:06:30 +0000",
    "user" : {
      "name" : "k1y054",
      "screen_name" : "k1y054",
      "protected" : false,
      "id_str" : "86968841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603223104161058817\/tLkp2V8g_normal.jpg",
      "id" : 86968841,
      "verified" : false
    }
  },
  "id" : 604877753016446976,
  "created_at" : "2015-05-31 05:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604877294449008642",
  "text" : "\u524D\u306B\u5EA7\u308B\u89AA\u5B50\u306E\u5B50\u4F9B\u304C\u5438\u8840\u9B3C\u306E\u8A71\u3057\u3057\u3066\u3066\u5FCD\u3061\u3083\u3093\u611F",
  "id" : 604877294449008642,
  "created_at" : "2015-05-31 05:09:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604876633573449728",
  "text" : "\u6A2A\u6D5C\u3001\u7E26\u6D5C\u3001\u659C\u6D5C",
  "id" : 604876633573449728,
  "created_at" : "2015-05-31 05:06:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604875349231464448",
  "text" : "\u30CA\u30AB\u30CE\u30D2\u30C8\u304C\u3044\u308B\uFF1F",
  "id" : 604875349231464448,
  "created_at" : "2015-05-31 05:01:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604875247968329728",
  "text" : "end.K\u306F\u52D5\u304B\u306A\u3044",
  "id" : 604875247968329728,
  "created_at" : "2015-05-31 05:01:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604875202095280129",
  "text" : "\u7A7A\u6C17\u304C\u8AAD\u3081\u308B\u3051\u3069\u8AAD\u307E\u306A\u3044\u306E\u3067\u3001\u96FB\u8ECA\u3067\n\n\u4EBA\u26AA\uFE0E\u79C1\u26AA\uFE0E\u4EBA\n\n\u3063\u3066\u3068\u3053\u308D\u306B\u30AB\u30C3\u30D7\u30EB\u304C\u6765\u305F\u3051\u3069\u52D5\u304B\u306A\u3044",
  "id" : 604875202095280129,
  "created_at" : "2015-05-31 05:01:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604874900755456001",
  "text" : "hoge.js \u7D50\u69CB\u306A\u901F\u3055\uFF1F",
  "id" : 604874900755456001,
  "created_at" : "2015-05-31 04:59:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604874422193823744",
  "text" : "\u3061\u3047\u308A\u3043\u3055\u3093\u3001\u6D77\u5916\u30C9\u30E9\u30DE\u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u307F\u305F\u3044\u306A\u30A4\u30E1\u30C3\u30B8\u3042\u308B",
  "id" : 604874422193823744,
  "created_at" : "2015-05-31 04:57:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604874167108964352",
  "geo" : { },
  "id_str" : "604874336332214273",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u624B\u5E83\u3044\u3067\u3059\u306D\u30FC",
  "id" : 604874336332214273,
  "in_reply_to_status_id" : 604874167108964352,
  "created_at" : "2015-05-31 04:57:34 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604874067485683714",
  "text" : "\u304A\u663C\u306B\u3084\u3063\u3066\u308BCSI\u3068\u304B\u30DB\u30EF\u30A4\u30C8\u30AB\u30E9\u30FC\u3068\u304B\u306F\u6BCD\u89AA\u304C\u898B\u3066\u308B\u304B\u3089\u3064\u3044\u898B\u3061\u3083\u3046",
  "id" : 604874067485683714,
  "created_at" : "2015-05-31 04:56:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604873234148900864",
  "geo" : { },
  "id_str" : "604873663691628544",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u308F\u304B\u308B\u2026\u305D\u3046\u3044\u3046(\u30B9\u30D7\u30E9\u30C3\u30BF?)\u30DB\u30E9\u30FC\u7684\u306A\u30DF\u30B9\u30C6\u30EA\u30FC\u3082\u898B\u3066\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 604873663691628544,
  "in_reply_to_status_id" : 604873234148900864,
  "created_at" : "2015-05-31 04:54:54 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604873010403635200",
  "text" : "\u751F\u9996\u3088\u308A\u8339\u3067\u9996\u306E\u65B9\u304C\u5FC3\u306B\u304D\u305D\u3046\u3060\u3057\u3001\u3055\u3089\u306B\u3044\u3046\u306A\u3089\u713C\u304D\u9996\u306E\u65B9\u304C(ry",
  "id" : 604873010403635200,
  "created_at" : "2015-05-31 04:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604871693190852608",
  "text" : "SAN\u30C1\u30A7\u30C3\u30AF",
  "id" : 604871693190852608,
  "created_at" : "2015-05-31 04:47:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "47NEWS",
      "screen_name" : "47news",
      "indices" : [ 3, 10 ],
      "id_str" : "10462562",
      "id" : 10462562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/3C5uNTo30L",
      "expanded_url" : "http:\/\/bit.ly\/1FUEMcE",
      "display_url" : "bit.ly\/1FUEMcE"
    } ]
  },
  "geo" : { },
  "id_str" : "604871664648613888",
  "text" : "RT @47news: \u6771\u4EAC\u99C5\u30B3\u30A4\u30F3\u30ED\u30C3\u30AB\u30FC\u306B\u907A\u4F53\u304B\u3000\u30B9\u30FC\u30C4\u30B1\u30FC\u30B9\u306E\u4E2D http:\/\/t.co\/3C5uNTo30L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.47news.jp\/\" rel=\"nofollow\"\u003E47NEWS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/3C5uNTo30L",
        "expanded_url" : "http:\/\/bit.ly\/1FUEMcE",
        "display_url" : "bit.ly\/1FUEMcE"
      } ]
    },
    "geo" : { },
    "id_str" : "604858104098922496",
    "text" : "\u6771\u4EAC\u99C5\u30B3\u30A4\u30F3\u30ED\u30C3\u30AB\u30FC\u306B\u907A\u4F53\u304B\u3000\u30B9\u30FC\u30C4\u30B1\u30FC\u30B9\u306E\u4E2D http:\/\/t.co\/3C5uNTo30L",
    "id" : 604858104098922496,
    "created_at" : "2015-05-31 03:53:04 +0000",
    "user" : {
      "name" : "47NEWS",
      "screen_name" : "47news",
      "protected" : false,
      "id_str" : "10462562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51678900\/47newslogo90_normal.jpg",
      "id" : 10462562,
      "verified" : false
    }
  },
  "id" : 604871664648613888,
  "created_at" : "2015-05-31 04:46:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604870272588472321",
  "text" : "\u6771\u6A2A\u7DDA\u306F\u306D\u3001\u6DF1\u304F\u3066\u91CD\u3044\u3093\u3067\u3059",
  "id" : 604870272588472321,
  "created_at" : "2015-05-31 04:41:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604870132301627392",
  "text" : "\u306F\u3041",
  "id" : 604870132301627392,
  "created_at" : "2015-05-31 04:40:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604870119857127424",
  "text" : "\u57FC\u4EAC\u7DDA\u304B\u3089\u6771\u6A2A\u7DDA\u3001\u4E57\u308A\u63DB\u30489\u5206\u3042\u308B\u3057\u4F59\u88D5\u3060\u3068\u304B\u601D\u3063\u305F\u3089\u6700\u5F8C\u8D70\u3089\u306A\u3044\u3068\u9593\u306B\u5408\u308F\u306A\u3044\u904E\u9177\u4E57\u308A\u63DB\u3048\u3060\u3063\u305F",
  "id" : 604870119857127424,
  "created_at" : "2015-05-31 04:40:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yassu",
      "screen_name" : "yassu0320",
      "indices" : [ 0, 10 ],
      "id_str" : "531198661",
      "id" : 531198661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604835219485523968",
  "geo" : { },
  "id_str" : "604857918333198336",
  "in_reply_to_user_id" : 531198661,
  "text" : "@yassu0320 \u3084\u3063\u3059\u541B\u306F\u300C\u30A6\u30EB\u30C8\u30E9\u30DE\u30F3\uFF01\u300D\u3063\u3066\u8A00\u3063\u305F\u5B50\u4F9B\u3092\u30A6\u30EB\u30C8\u30E9\u30DE\u30F3\u3068\u3057\u3066\u8A8D\u8B58\u3059\u308B\u306E\u304B",
  "id" : 604857918333198336,
  "in_reply_to_status_id" : 604835219485523968,
  "created_at" : "2015-05-31 03:52:20 +0000",
  "in_reply_to_screen_name" : "yassu0320",
  "in_reply_to_user_id_str" : "531198661",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 56, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604834369522376704",
  "text" : "\u5C31\u8077\u6D3B\u52D5\u3092\u3057\u3088\u3046\u3068\u696D\u754C\u7814\u7A76\u3092\u59CB\u3081\u305F\u304C\u8AD6\u6587\u304C\u51FA\u6765\u4E0A\u304C\u3063\u3066\u696D\u754C\u5B66\u3068\u3044\u3046\u5206\u91CE\u3092\u6253\u3061\u7ACB\u3066\u3066\u3057\u307E\u3063\u3066\u7D50\u5C40\u7814\u7A76\u8005\u306B\u306A\u3063\u305F\u4EBA #\u4EBA",
  "id" : 604834369522376704,
  "created_at" : "2015-05-31 02:18:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/604833564052422656\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rn8yQAJccv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGTM62PUcAASuue.png",
      "id_str" : "604833561338736640",
      "id" : 604833561338736640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGTM62PUcAASuue.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 503
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 503
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 503
      } ],
      "display_url" : "pic.twitter.com\/Rn8yQAJccv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604833564052422656",
  "text" : "http:\/\/t.co\/Rn8yQAJccv",
  "id" : 604833564052422656,
  "created_at" : "2015-05-31 02:15:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604632561877291008",
  "text" : "\u30B2\u30FC\u30E0\u7D42\u4E86\u6642\u3001\u5E73\u6C11\u304C\u30AA\u30E4\u30B8\u30AE\u30E3\u30B0\u3092\u8A00\u3046\u3068\u3044\u3046\u60AA\u5922\u307F\u305F\u3044\u306A\u30EB\u30FC\u30EB\u304C\u3042\u3063\u3066\u306A",
  "id" : 604632561877291008,
  "created_at" : "2015-05-30 12:56:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308F\u3093\u3069",
      "screen_name" : "wand125",
      "indices" : [ 3, 11 ],
      "id_str" : "15037872",
      "id" : 15037872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Oeowhj9eVg",
      "expanded_url" : "http:\/\/w125.hateblo.jp\/entry\/2015\/05\/28\/010314",
      "display_url" : "w125.hateblo.jp\/entry\/2015\/05\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604632471527768065",
  "text" : "RT @wand125: \u3053\u306A\u3044\u3060\u306E\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u306E\u591C\u306E\u90E8\u3067\u8D77\u3053\u3063\u305F\u60AA\u5922\u306B\u3064\u3044\u3066\u3001\u8A18\u9332\u3068\u3057\u3066\u30EB\u30FC\u30EB\u3060\u3051\u8CBC\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/Oeowhj9eVg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/Oeowhj9eVg",
        "expanded_url" : "http:\/\/w125.hateblo.jp\/entry\/2015\/05\/28\/010314",
        "display_url" : "w125.hateblo.jp\/entry\/2015\/05\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603593352336912384",
    "text" : "\u3053\u306A\u3044\u3060\u306E\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u306E\u591C\u306E\u90E8\u3067\u8D77\u3053\u3063\u305F\u60AA\u5922\u306B\u3064\u3044\u3066\u3001\u8A18\u9332\u3068\u3057\u3066\u30EB\u30FC\u30EB\u3060\u3051\u8CBC\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/Oeowhj9eVg",
    "id" : 603593352336912384,
    "created_at" : "2015-05-27 16:07:24 +0000",
    "user" : {
      "name" : "\u308F\u3093\u3069",
      "screen_name" : "wand125",
      "protected" : false,
      "id_str" : "15037872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606841135525281792\/ESwfFGzw_normal.png",
      "id" : 15037872,
      "verified" : false
    }
  },
  "id" : 604632471527768065,
  "created_at" : "2015-05-30 12:56:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/604618006350565376\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/1Xt3vOafQU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGQIvHjWQAA71Nt.jpg",
      "id_str" : "604617855548669952",
      "id" : 604617855548669952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGQIvHjWQAA71Nt.jpg",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 235
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 235
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 235
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 235
      } ],
      "display_url" : "pic.twitter.com\/1Xt3vOafQU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604618006350565376",
  "text" : "\u53CB\u4EBA\u304C\u8FD4\u4E8B\u3092\u3057\u306A\u304B\u3063\u305F\u3070\u3063\u304B\u308A\u306B\u3001\u4ECA\u9803\u304D\u3063\u3068\u30BB\u30EC\u30D6\u5973\u6027\u306B\u6700\u4F4ERANK\u306E\u30E6\u30FC\u30B6\u30FC\u3068\u3057\u3066\u77E5\u308C\u6E21\u3063\u3066\u308B\u3068\u601D\u3046\u3068\u9762\u767D\u3059\u304E\u3066\u306A http:\/\/t.co\/1Xt3vOafQU",
  "id" : 604618006350565376,
  "created_at" : "2015-05-30 11:59:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604616798294536193",
  "geo" : { },
  "id_str" : "604616988254560256",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u305D\u3046\u306A\u308C\u3070\u30BB\u30EC\u30D6\u306E\u304A\u59C9\u3055\u307E\u65B9\u306B\u6700\u4F4E\u30E9\u30F3\u30AF\u306E\u304A\u5BA2\u69D8\u6271\u3044\u3055\u308C\u3066\u308B\u306E\u3082\u540D\u8A89\u633D\u56DE\u3067\u304D\u308B\u305C\u3001\u3088\u304B\u3063\u305F\u306A",
  "id" : 604616988254560256,
  "in_reply_to_status_id" : 604616798294536193,
  "created_at" : "2015-05-30 11:54:57 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604616234013835265",
  "geo" : { },
  "id_str" : "604616341882961921",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u6A5F\u3092\u307F\u3066\u8AAD\u3093\u3067\u307F\u307E\u3059",
  "id" : 604616341882961921,
  "in_reply_to_status_id" : 604616234013835265,
  "created_at" : "2015-05-30 11:52:23 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604615650317725696",
  "geo" : { },
  "id_str" : "604615754168696832",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u65E5\u672C\u6C88\u6CA1\u3001\u65E5\u672C\u4EE5\u5916\u5168\u90E8\u6C88\u6CA1\u3063\u3066\u4E0D\u601D\u8B70\u6620\u753B\u3092\u601D\u3044\u51FA\u3057\u307E\u3057\u305F\u3002\uFF08\u3069\u3063\u3061\u3082\u307F\u3066\u306A\u3044\uFF09",
  "id" : 604615754168696832,
  "in_reply_to_status_id" : 604615650317725696,
  "created_at" : "2015-05-30 11:50:03 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604615265402249216",
  "geo" : { },
  "id_str" : "604615530222198784",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u6DF1\u304F\u304B\u3089\u8CC7\u6E90\u53D6\u308A\u51FA\u305B\u308B\u3088\u3046\u306B\u306A\u3063\u305F\u3089\u77F3\u6CB9\u738B\u306B\u306A\u308C\u308B",
  "id" : 604615530222198784,
  "in_reply_to_status_id" : 604615265402249216,
  "created_at" : "2015-05-30 11:49:10 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/A4yQuumIFb",
      "expanded_url" : "http:\/\/ask.fm\/a\/c9odm2a9",
      "display_url" : "ask.fm\/a\/c9odm2a9"
    } ]
  },
  "geo" : { },
  "id_str" : "604615424119074816",
  "text" : "\u304A\u6C17\u306B\u5165\u308A\u306E\u30DC\u30FC\u30C9\u30B2\u30FC\u30E0\u306F? \u2014 \u30D1\u30FC\u30C6\u30A3\u30B2\u30FC\u30E0\u3060\u3068\u30C6\u30EC\u30B9\u30C8\u30EC\u30FC\u30B7\u30E7\u30F3\u306A\u3093\u3067\u3059\u304C\u6301\u3063\u3066\u306A\u3044\u3068\u3044\u3046 http:\/\/t.co\/A4yQuumIFb",
  "id" : 604615424119074816,
  "created_at" : "2015-05-30 11:48:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604615172083179521",
  "text" : "\u4F53\u7A4D\u6BD4\u3060\u3068\u5185\u5074\u534A\u5206\u306B\u306F\u3044\u308B\u306E\u304B\u5916\u5074\u534A\u5206\u306B\u5165\u308B\u306E\u304B\u3055\u3063\u3068\u8A08\u7B97\u304C\u51FA\u6765\u306A\u3044",
  "id" : 604615172083179521,
  "created_at" : "2015-05-30 11:47:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/o4CvrpuqBd",
      "expanded_url" : "http:\/\/ask.fm\/end313124\/answer\/108162474629",
      "display_url" : "ask.fm\/end313124\/answ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604614733031874561",
  "text" : "590km\u306E\u5730\u4E0B\u3063\u3066\u3053\u308C\u50D5\u306B\u8CAC\u4EFB\u306A\u3044\u3088\u306D\uFF1F http:\/\/t.co\/o4CvrpuqBd",
  "id" : 604614733031874561,
  "created_at" : "2015-05-30 11:46:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604610989632331777",
  "text" : "\u91CD\u529B\u5B50\u653E\u5C04\u7DDA\u5C04\u51FA\u88C5\u7F6E\u306E\u305B\u3044",
  "id" : 604610989632331777,
  "created_at" : "2015-05-30 11:31:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604610808388001794",
  "text" : "\u8AB0\u3060\u3088\u8CA7\u4E4F\u3086\u3059\u308A\u3057\u305F\u5974",
  "id" : 604610808388001794,
  "created_at" : "2015-05-30 11:30:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604610343843667971",
  "text" : "\u304D\u3082\u3061\u308F\u308B\u3044\u2026",
  "id" : 604610343843667971,
  "created_at" : "2015-05-30 11:28:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604610071255908352",
  "text" : "\u305D\u3057\u3066\u5730\u9707\u9154\u3044",
  "id" : 604610071255908352,
  "created_at" : "2015-05-30 11:27:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604610044764643329",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3068\u3073\u3089\u3042\u3051\u305F",
  "id" : 604610044764643329,
  "created_at" : "2015-05-30 11:27:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604609895116111872",
  "text" : "\u304A\u304A\u304D\u3044\uFF01",
  "id" : 604609895116111872,
  "created_at" : "2015-05-30 11:26:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604609675057709057",
  "text" : "\u306C\u308B\u306C\u308B\u9577\u3044",
  "id" : 604609675057709057,
  "created_at" : "2015-05-30 11:25:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604609548163293184",
  "text" : "\u3086\u308C\u3086\u308C\u3086\u308C",
  "id" : 604609548163293184,
  "created_at" : "2015-05-30 11:25:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604609499219918848",
  "text" : "\u3086\u308C",
  "id" : 604609499219918848,
  "created_at" : "2015-05-30 11:25:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604603271999651841",
  "text" : "\u3042\u3063\u3064\u30FC\u3044",
  "id" : 604603271999651841,
  "created_at" : "2015-05-30 11:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604529051043110912",
  "text" : "\u6E0B\u8C37\u3067\u30EC\u30A4\u30D0\u30F3\u306E\u30B5\u30F3\u30B0\u30E9\u30B9\u58F2\u3063\u3066\u3066\u5909\u306A\u7B11\u3044\u51FA\u305F",
  "id" : 604529051043110912,
  "created_at" : "2015-05-30 06:05:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604318242316767233",
  "geo" : { },
  "id_str" : "604318352278831104",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u3058\u3076\u3093\u3067\u3055\u304C\u305B\u3001\u3042\u307E\u3048\u308B\u306A",
  "id" : 604318352278831104,
  "in_reply_to_status_id" : 604318242316767233,
  "created_at" : "2015-05-29 16:08:17 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604318124133908482",
  "text" : "\u3086\u308C",
  "id" : 604318124133908482,
  "created_at" : "2015-05-29 16:07:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604296036434059264",
  "geo" : { },
  "id_str" : "604296155158065154",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6398\u308B\u304B\u3041\u2026",
  "id" : 604296155158065154,
  "in_reply_to_status_id" : 604296036434059264,
  "created_at" : "2015-05-29 14:40:05 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604295590772518912",
  "geo" : { },
  "id_str" : "604295888442236928",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u88CF\u5C71",
  "id" : 604295888442236928,
  "in_reply_to_status_id" : 604295590772518912,
  "created_at" : "2015-05-29 14:39:01 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon.co.jp (\u30A2\u30DE\u30BE\u30F3)",
      "screen_name" : "AmazonJP",
      "indices" : [ 80, 89 ],
      "id_str" : "161616614",
      "id" : 161616614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/2ABGF81Dq1",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B00FXNCSOK\/ref=cm_sw_r_tw_awdo_cgdAvb0861YA4",
      "display_url" : "amazon.co.jp\/dp\/B00FXNCSOK\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604218165283848192",
  "text" : "SALUS \u30B3\u30E9\u30E0 \u30BD\u30FC\u30C0\u30B9\u30D7\u30FC\u30F3 \u30B7\u30EB\u30D0\u30FC \u4F50\u85E4\u91D1\u5C5E\u8208\u696D#\u30A2\u30DE\u30BE\u30F3\u30DD\u30C1 \u3068\u5165\u308C\u3066@\u8FD4\u4FE1\u3067\u30AB\u30FC\u30C8\u306B\u8FFD\u52A0\u30FB\u5F8C\u3067\u8CB7\u3046 http:\/\/t.co\/2ABGF81Dq1 @amazonJP\u3055\u3093\u304B\u3089\n\u304B\u306A\u3089\u305A\u3057\u3082\u307B\u3057\u304F\u306A\u3044\u3082\u306E\u30EA\u30B9\u30C8\u306B\u8FFD\u52A0\u3057\u307E\u3057\u305F",
  "id" : 604218165283848192,
  "created_at" : "2015-05-29 09:30:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604190514598920192",
  "text" : "\u80CC\u4E2D\u3092\u304A\u306A\u304B\u3068\u4EA4\u63DB\u3059\u308B\u4E8B\u306F\u51FA\u6765\u306A\u3044",
  "id" : 604190514598920192,
  "created_at" : "2015-05-29 07:40:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604143242574057472",
  "text" : "\u3053\u3093\u306A\u5FAE\u5999\u306A\u3068\u3053\u308D\u3067\u5207\u3089\u308C\u308B\u306E\u304B\u2026",
  "id" : 604143242574057472,
  "created_at" : "2015-05-29 04:32:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604136867383017472",
  "text" : "BLAME\u3082\u30B7\u30E7\u30FC\u30C8\u30A2\u30CB\u30E1\u5316\u3059\u308B\u306E\u304B\uFF01",
  "id" : 604136867383017472,
  "created_at" : "2015-05-29 04:07:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TV\u30A2\u30CB\u30E1\u300C\u30B7\u30C9\u30CB\u30A2\u306E\u9A0E\u58EB\u300D",
      "screen_name" : "SIDONIA_anime",
      "indices" : [ 3, 17 ],
      "id_str" : "2359263751",
      "id" : 2359263751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SIDONIA_anime",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/peGYNOtonT",
      "expanded_url" : "http:\/\/youtu.be\/pxKEDXonh10",
      "display_url" : "youtu.be\/pxKEDXonh10"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/GOfD5risO6",
      "expanded_url" : "http:\/\/www.knightsofsidonia.com\/news_tv.php#n20150522_1",
      "display_url" : "knightsofsidonia.com\/news_tv.php#n2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604136811196071936",
  "text" : "RT @SIDONIA_anime: \u300CBLAME!\u300D\u306E\u30B7\u30E7\u30FC\u30C8\u30A2\u30CB\u30E1\u5316\u306B\u3088\u305B\u3066\u5F10\u74F6\u52C9\u5148\u751F&amp;\u702C\u4E0B\u5BDB\u4E4B\u76E3\u7763\u306E\u30B3\u30E1\u30F3\u30C8\u3082\u516C\u958B\u4E2D\uFF01\u30B3\u30E1\u30F3\u30C8\u52D5\u753B\u2026http:\/\/t.co\/peGYNOtonT \uFF0F\u307B\u304B\u8A73\u7D30\u2026http:\/\/t.co\/GOfD5risO6 #SIDONIA_anime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SIDONIA_anime",
        "indices" : [ 106, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/peGYNOtonT",
        "expanded_url" : "http:\/\/youtu.be\/pxKEDXonh10",
        "display_url" : "youtu.be\/pxKEDXonh10"
      }, {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/GOfD5risO6",
        "expanded_url" : "http:\/\/www.knightsofsidonia.com\/news_tv.php#n20150522_1",
        "display_url" : "knightsofsidonia.com\/news_tv.php#n2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "604134642346639360",
    "text" : "\u300CBLAME!\u300D\u306E\u30B7\u30E7\u30FC\u30C8\u30A2\u30CB\u30E1\u5316\u306B\u3088\u305B\u3066\u5F10\u74F6\u52C9\u5148\u751F&amp;\u702C\u4E0B\u5BDB\u4E4B\u76E3\u7763\u306E\u30B3\u30E1\u30F3\u30C8\u3082\u516C\u958B\u4E2D\uFF01\u30B3\u30E1\u30F3\u30C8\u52D5\u753B\u2026http:\/\/t.co\/peGYNOtonT \uFF0F\u307B\u304B\u8A73\u7D30\u2026http:\/\/t.co\/GOfD5risO6 #SIDONIA_anime",
    "id" : 604134642346639360,
    "created_at" : "2015-05-29 03:58:17 +0000",
    "user" : {
      "name" : "TV\u30A2\u30CB\u30E1\u300C\u30B7\u30C9\u30CB\u30A2\u306E\u9A0E\u58EB\u300D",
      "screen_name" : "SIDONIA_anime",
      "protected" : false,
      "id_str" : "2359263751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607485251523248129\/7OK-cacO_normal.jpg",
      "id" : 2359263751,
      "verified" : false
    }
  },
  "id" : 604136811196071936,
  "created_at" : "2015-05-29 04:06:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604130151362764800",
  "text" : "\u30DB\u30EF\u30A4\u30C8\u30AB\u30E9\u30FC",
  "id" : 604130151362764800,
  "created_at" : "2015-05-29 03:40:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604123157964804096",
  "geo" : { },
  "id_str" : "604123239229448192",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u5730\u7403\u306F\u6D77\u306E\u65B9\u304C\u5E83\u3044\u306E\u306B\u306D",
  "id" : 604123239229448192,
  "in_reply_to_status_id" : 604123157964804096,
  "created_at" : "2015-05-29 03:12:58 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u58F0\u306B\u51FA\u3057\u3066\u8AAD\u307F\u305F\u3044\u65E5\u672C\u8A9E",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604122636247932929",
  "text" : "\u30AB\u30C1\u30B0\u30DF\u30AD\u30AE\u30E7\u30A6\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u304B\uFF01 #\u58F0\u306B\u51FA\u3057\u3066\u8AAD\u307F\u305F\u3044\u65E5\u672C\u8A9E",
  "id" : 604122636247932929,
  "created_at" : "2015-05-29 03:10:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604119279504490496",
  "text" : "intelmap\u773A\u3081\u305F\u9650\u308A\u53E3\u6C38\u826F\u90E8\u5CF6\u306B\u306F\u30DD\u30FC\u30BF\u30EB\u306A\u3055\u305D\u3046\u3060\u3063\u305F",
  "id" : 604119279504490496,
  "created_at" : "2015-05-29 02:57:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604117702093877248",
  "text" : "\u3075\u304D\u3093\u3057\u3093\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 604117702093877248,
  "created_at" : "2015-05-29 02:50:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604117670703693825",
  "text" : "\u53E3\u6C38\u826F\u90E8\u5CF6\u306E\u30DD\u30FC\u30BF\u30EB\u3001\u30AC\u30FC\u30C7\u30A3\u30A2\u30F3\u30E1\u30C0\u30EB\u53D6\u308B\u306E\u306B\u3061\u3087\u3046\u3069\u826F\u3055\u305D\u3046",
  "id" : 604117670703693825,
  "created_at" : "2015-05-29 02:50:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603936830157783041",
  "text" : "\u3044\u3084\u3001\u30CA\u30F3\u30B7\u30FC=\u30B5\u30F3\u3068\u3044\u3044\u30B9\u30AC\u30EF\u30E9\u8001\u4EBA\u3068\u3044\u3044\u826F\u3044\u611F\u3058\u3060",
  "id" : 603936830157783041,
  "created_at" : "2015-05-28 14:52:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603932954646093825",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u307F\u3066\u304F\u308B",
  "id" : 603932954646093825,
  "created_at" : "2015-05-28 14:36:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603930456170434560",
  "text" : "\u307E\u3041\u5165\u308C\u308B\u3082\u306E\u306E\u3076\u3063\u3068\u3073\u5EA6\u5408\u3044\u306B\u4F9D\u5B58\u3057\u3066\u304A\u3044\u3057\u304F\u3059\u308B\u305F\u3081\u306E\u8ABF\u6574\u306E\u96E3\u6613\u5EA6\u306F\u4E0A\u304C\u3063\u3066\u3044\u304F\u308F\u3051\u3067\u3059\u304C",
  "id" : 603930456170434560,
  "created_at" : "2015-05-28 14:26:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603930357906329602",
  "text" : "\u30AB\u30EC\u30FC\u306F\u975E\u5E38\u306B\u591A\u304F\u306E\u3082\u306E\u3092\u5165\u308C\u3046\u308B\u30DD\u30C6\u30F3\u30B7\u30E3\u30EB\u3092\u6301\u3063\u3066\u3044\u308B",
  "id" : 603930357906329602,
  "created_at" : "2015-05-28 14:26:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603925990666993666",
  "text" : "\u3054\u5BB6\u5EAD\u306B\u30AC\u30E9\u30E0\u30DE\u30B5\u30E9\u306F\u306A\u3044\u3002",
  "id" : 603925990666993666,
  "created_at" : "2015-05-28 14:09:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603925933397946368",
  "text" : "\u30D0\u30E9\u30F3\u30B9\u306E\u53D6\u308C\u305F\u3082\u306E\u3092\u5927\u91CF\u306B\u751F\u7523\u3057\u305F\u3044\u306A\u3089\u5E02\u8CA9\u306E\u30EB\u30FC\u304C\u666E\u901A\u306B\u5F37\u3044\u3088\u306A\u30FC\u3002\u30EC\u30C8\u30EB\u30C8\u3068\u304B\u306B\u30AC\u30E9\u30E0\u30DE\u30B5\u30E9\u3061\u3087\u3044\u3044\u308C\u308B\u3068\u304A\u3044\u3057\u3044\u3051\u3069\u3002",
  "id" : 603925933397946368,
  "created_at" : "2015-05-28 14:08:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603925652593451008",
  "text" : "\u30AB\u30EC\u30FC\u306B\u304A\u3051\u308B\u30B9\u30D1\u30A4\u30B9\u306E\u5F79\u5272\u3068\u30BF\u30A4\u30DF\u30F3\u30B0\u3001\u306A\u3093\u3068\u306A\u304F\u3057\u304B\u5206\u304B\u3089\u306A\u3044\u3057\u306A\u30FC\u3002\u306A\u3093\u3068\u306A\u304F\u3060\u3051\u3067\u95D8\u3048\u308B\u3002\u305F\u3060\u540C\u3058\u5473\u3092\u518D\u73FE\u3067\u304D\u306A\u3044\u3002",
  "id" : 603925652593451008,
  "created_at" : "2015-05-28 14:07:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603924451651006466",
  "geo" : { },
  "id_str" : "603924641061609472",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30B9\u30D1\u30A4\u30B9\u306E\u7A2E\u985E\u3068\u304B\u76EE\u6307\u3059\u65B9\u5411\u306B\u3088\u3063\u3066\u5165\u308C\u308B\u30BF\u30A4\u30DF\u30F3\u30B0\u3068\u304B\u91CF\u304C\u5909\u308F\u308B\u3068\u601D\u3046\u305E\u3044",
  "id" : 603924641061609472,
  "in_reply_to_status_id" : 603924451651006466,
  "created_at" : "2015-05-28 14:03:49 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/603922344415924225\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/SWxDpJFVlt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGQKq-W0AAFgq7.jpg",
      "id_str" : "603922338053279744",
      "id" : 603922338053279744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGQKq-W0AAFgq7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "fit",
        "w" : 541
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 541
      }, {
        "h" : 94,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 541
      } ],
      "display_url" : "pic.twitter.com\/SWxDpJFVlt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603922344415924225",
  "text" : "\u30B7\u30A7\u30A2\u3059\u308B\u3053\u3068\u3068\u3001\u305F\u304F\u3055\u3093\u306E\u8CEA\u554F\u3092\u3082\u3089\u3046\u3053\u3068\u306E\u9593\u306B\u306F\u5927\u304D\u306A\u30AE\u30E3\u30C3\u30D7\u304C\u3042\u308B http:\/\/t.co\/SWxDpJFVlt",
  "id" : 603922344415924225,
  "created_at" : "2015-05-28 13:54:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603919347367608320",
  "text" : "\u4F55\u304C\u805E\u304D\u305F\u3044\u3093\u3060\u5168\u304F",
  "id" : 603919347367608320,
  "created_at" : "2015-05-28 13:42:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/2CjDBxGS43",
      "expanded_url" : "http:\/\/ask.fm\/a\/c9k0qq11",
      "display_url" : "ask.fm\/a\/c9k0qq11"
    } ]
  },
  "geo" : { },
  "id_str" : "603919098402181120",
  "text" : "\u304A\u91D1\u6301\u3061\u306B\u306A\u308B\u306B\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044? \u2014 \u304A\u91D1\u304C\u7121\u3044\u3068\u304A\u91D1\u3092\u5897\u3084\u3059\u306E\u306F\u96E3\u3057\u3044\u306E\u3067\u3001\u307E\u3068\u307E\u3063\u305F\u304A\u91D1\u3092\u6301\u3064\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u307E\u3057\u3087\u3046 http:\/\/t.co\/2CjDBxGS43",
  "id" : 603919098402181120,
  "created_at" : "2015-05-28 13:41:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/Sp1hVHp2kt",
      "expanded_url" : "http:\/\/ask.fm\/end313124",
      "display_url" : "ask.fm\/end313124"
    } ]
  },
  "geo" : { },
  "id_str" : "603917984004972544",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u4E94\u5104\u5E74\u304F\u3089\u3044\u653E\u7F6E\u3057\u3066\u305F\u3051\u3069\u30A2\u30AB\u30A6\u30F3\u30C8\u751F\u304D\u3066\u305F\u3002 http:\/\/t.co\/Sp1hVHp2kt",
  "id" : 603917984004972544,
  "created_at" : "2015-05-28 13:37:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603917776147775489",
  "text" : "\u3081\u3063\u3061\u3087\u697D\u3057\u307F\u3060",
  "id" : 603917776147775489,
  "created_at" : "2015-05-28 13:36:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603917540977319939",
  "text" : "\u5B9F\u306FPL\u4E8C\u56DE\u76EE\u3068\u304B\u3044\u3046\u30A2\u30EC",
  "id" : 603917540977319939,
  "created_at" : "2015-05-28 13:35:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603917492193398784",
  "text" : "\u30AD\u30E3\u30E9\u30E1\u30A4\u30AF\u201D\u3060\u3051\u201D\u3057\u305F\u305B\u3044\u3067",
  "id" : 603917492193398784,
  "created_at" : "2015-05-28 13:35:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603917427752116226",
  "text" : "\u4E2D\u9014\u534A\u7AEF\u306B\u30AD\u30E3\u30E9\u30E1\u30A4\u30AF\u3057\u305F\u305B\u3044\u3067TRPG\u3084\u308A\u305F\u3055\u304C\u306B\u3087\u304D\u306B\u3087\u304D\u3068",
  "id" : 603917427752116226,
  "created_at" : "2015-05-28 13:35:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u68EE\u7530\u7D18\u5E73",
      "screen_name" : "kouheimorita",
      "indices" : [ 0, 13 ],
      "id_str" : "160230093",
      "id" : 160230093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603907267612704768",
  "geo" : { },
  "id_str" : "603907674384699394",
  "in_reply_to_user_id" : 160230093,
  "text" : "@kouheimorita \u9A19\u3055\u308C\u305F\u3068\u601D\u3063\u3066\u4E00\u5EA6\u3084\u308B\u3068\u826F\u3044\u3067\u3059\u3088",
  "id" : 603907674384699394,
  "in_reply_to_status_id" : 603907267612704768,
  "created_at" : "2015-05-28 12:56:24 +0000",
  "in_reply_to_screen_name" : "kouheimorita",
  "in_reply_to_user_id_str" : "160230093",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 25, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603903513417011202",
  "text" : "\u5F8C\u8F29\u304C\u9B54\u5973\u306E\u5B85\u6025\u4FBF\u306E\u5B9F\u5199\u6620\u753B\u3092\u898B\u3066\u4F53\u8ABF\u3092\u5D29\u3057\u305F\u56DE #\u56DE",
  "id" : 603903513417011202,
  "created_at" : "2015-05-28 12:39:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603901026123423746",
  "geo" : { },
  "id_str" : "603901157971369984",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3080\u3057\u308D\u80C3\u3068\u304B\u306B\u306F\u826F\u304B\u3063\u305F\u3068\u601D\u3046\u3093\u3060\u304C\u2026\u5FC3\u306B\u306F\u826F\u304F\u306A\u304B\u3063\u305F\u3051\u3069",
  "id" : 603901157971369984,
  "in_reply_to_status_id" : 603901026123423746,
  "created_at" : "2015-05-28 12:30:30 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603900791993147392",
  "geo" : { },
  "id_str" : "603900891951796225",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u885D\u6483\u7684\u3067\u306F\u3042\u3063\u305F\u304C\u7834\u58CA\u7684\u3067\u306F\u7121\u304B\u3063\u305F\u3068\u4FE1\u3058\u3066\u3044\u308B",
  "id" : 603900891951796225,
  "in_reply_to_status_id" : 603900791993147392,
  "created_at" : "2015-05-28 12:29:27 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/haguruma20\/status\/603900171110359041\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/VbaIIJeNQL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGF8AVvUgAEYg55.jpg",
      "id_str" : "603900170321821697",
      "id" : 603900170321821697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGF8AVvUgAEYg55.jpg",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/VbaIIJeNQL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603900769746616321",
  "text" : "RT @haguruma20: \u934B\u306B\u3053\u308C\u5168\u90E8\u5165\u308C\u3088\u3046\u306A http:\/\/t.co\/VbaIIJeNQL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.jstwi.com\/kurotwi\/\" rel=\"nofollow\"\u003EKuroTwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/haguruma20\/status\/603900171110359041\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/VbaIIJeNQL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGF8AVvUgAEYg55.jpg",
        "id_str" : "603900170321821697",
        "id" : 603900170321821697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGF8AVvUgAEYg55.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/VbaIIJeNQL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603900171110359041",
    "text" : "\u934B\u306B\u3053\u308C\u5168\u90E8\u5165\u308C\u3088\u3046\u306A http:\/\/t.co\/VbaIIJeNQL",
    "id" : 603900171110359041,
    "created_at" : "2015-05-28 12:26:35 +0000",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 603900769746616321,
  "created_at" : "2015-05-28 12:28:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603900647553957888",
  "text" : "\u5168\u3066\u304C\u934B\u306B\u306A\u308B",
  "id" : 603900647553957888,
  "created_at" : "2015-05-28 12:28:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603900455140270082",
  "geo" : { },
  "id_str" : "603900595339075585",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3060\u308C\u304B\u63D0\u8A00\u3057\u3066\u305F\u6C17\u304C\u3059\u308B\u304C\u3001\u3055\u3059\u304C\u306B\u7834\u58CA\u7684\u3060\u3063\u3066\u3093\u3067\u6B62\u3081\u305F\u3088\u3046\u306A",
  "id" : 603900595339075585,
  "in_reply_to_status_id" : 603900455140270082,
  "created_at" : "2015-05-28 12:28:16 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603900171110359041",
  "geo" : { },
  "id_str" : "603900332368736256",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u5B9F\u969B\u304D\u306A\u7C89\u4EE5\u5916\u5168\u90E8\u3061\u3087\u3063\u3068\u3065\u3064\u5165\u3063\u3066\u305F\u306A",
  "id" : 603900332368736256,
  "in_reply_to_status_id" : 603900171110359041,
  "created_at" : "2015-05-28 12:27:13 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 19, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603900088356765696",
  "text" : "\u30AB\u30EC\u30FC\u30D4\u30E9\u30D5\u3092\u304A\u304B\u305A\u306B\u767D\u98EF\u3092\u98DF\u3079\u305F\u56DE #\u56DE",
  "id" : 603900088356765696,
  "created_at" : "2015-05-28 12:26:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 17, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603899693739806720",
  "text" : "\u30EB\u30CD\u3067\u63DA\u3052\u51FA\u3057\u8C46\u8150\u3092\u4E8C\u3064\u983C\u3093\u3060\u56DE #\u56DE",
  "id" : 603899693739806720,
  "created_at" : "2015-05-28 12:24:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 30, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603899595488264192",
  "text" : "\u5317\u90E8\u98DF\u5802\u3067\u51B7\u3084\u5974\u3068\u3046\u307E\u8F9B\u8C46\u8150\u306E\u4E21\u65B9\u3092\u540C\u6642\u306B\u8CB7\u3063\u3066\u3057\u307E\u3063\u305F\u56DE #\u56DE",
  "id" : 603899595488264192,
  "created_at" : "2015-05-28 12:24:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE",
      "indices" : [ 54, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603899306433609730",
  "text" : "\u30CF\u30A4\u30E9\u30A4\u30C8\u3067\u771F\u590F\u306B\u3048\u3093\u3069\u3055\u3093\u304C\u9903\u5B50\u934B\u5B9A\u98DF\u3092\u983C\u3093\u3060\u3089\u300C\u3048\u3001\u9903\u5B50\u934B\u3067\u3088\u308D\u3057\u3044\u3067\u3059\u304B\uFF1F\uFF01\u300D\u3068\u4E8C\u56DE\u3082\u805E\u304D\u8FD4\u3055\u308C\u305F\u56DE #\u56DE",
  "id" : 603899306433609730,
  "created_at" : "2015-05-28 12:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 17, 26 ],
      "id_str" : "803314422",
      "id" : 803314422
    }, {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 27, 38 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603898578143223808",
  "geo" : { },
  "id_str" : "603898828186497024",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank @acmn13_2 @haguruma20 \u590F\u306B\u934B\u3001\u697D\u3057\u3044\u3088",
  "id" : 603898828186497024,
  "in_reply_to_status_id" : 603898578143223808,
  "created_at" : "2015-05-28 12:21:15 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u725B\u5CF6",
      "screen_name" : "usijima_uoichi",
      "indices" : [ 0, 15 ],
      "id_str" : "162395025",
      "id" : 162395025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603898470571847680",
  "geo" : { },
  "id_str" : "603898718903873536",
  "in_reply_to_user_id" : 162395025,
  "text" : "@usijima_uoichi OK\u3067\u3059\u3002\u3082\u3084\u3057\u3082OK\u3060\u3063\u305F\u306E\u3067\u3059\u304C\u3001\u300C\u3048\u3001\u304A\u524D\u8CB7\u3063\u3066\u3053\u306A\u304B\u3063\u305F\u306E\uFF1F\u300D\u300C\u3048\u3001\u304A\u524D\u304C\u8CB7\u3063\u3066\u304F\u308B\u3068\u3070\u304B\u308A\u2026\u300D\u3063\u3066\u306A\u5177\u5408\u3067\u5B9F\u8CEA\u8C46\u304B\u6CB9\u63DA\u3052\u304B\u306E2\u629E\u3067\u3057\u305F\u3002\u30D4\u30FC\u30CA\u30C3\u30C4\u30D0\u30BF\u30FC\u6301\u3061\u8FBC\u3093\u3067\u308B\u30A2\u30DB\u3082\u3044\u307E\u3057\u305F\u304C\u3002",
  "id" : 603898718903873536,
  "in_reply_to_status_id" : 603898470571847680,
  "created_at" : "2015-05-28 12:20:49 +0000",
  "in_reply_to_screen_name" : "usijima_uoichi",
  "in_reply_to_user_id_str" : "162395025",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603898330117111808",
  "text" : "\u4F55\u3092\u98DF\u3079\u3066\u3082\u62ED\u3048\u306A\u3044\u8C46\u611F\u306B\u5FC3\u3092\u3084\u3089\u308C\u308B",
  "id" : 603898330117111808,
  "created_at" : "2015-05-28 12:19:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603898123312758785",
  "text" : "\u53E3\u306E\u4E2D\u304C\u8C46\u8C46\u3057\u304F\u306A\u3063\u305F\u3068\u304D\u306B\u3001\u30EA\u30D5\u30EC\u30C3\u30B7\u30E5\u7684\u306B\u98F2\u307F\u7269\u3092\u53E3\u306B\u3059\u308B\u3093\u3060\u3051\u3069\u3001\u8C46\u4E73\u3060\u304B\u3089\u3084\u3063\u3071\u308A\u8C46\u8C46\u3057\u3044\u3093\u3060\u3088\u306A",
  "id" : 603898123312758785,
  "created_at" : "2015-05-28 12:18:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603897849617649665",
  "text" : "\u3044\u3084\u3001\u4E94\u5104\u56DE\u4F4D\u8A00\u3063\u3066\u308B\u3051\u3069\u3001\u8C46\u7E1B\u308A\u934B\u306E\u5931\u6557\u306F\u98F2\u307F\u7269\u304C\u8C46\u4E73\u3057\u304B\u306A\u304B\u3063\u305F\u3053\u3068\u306B\u5C3D\u304D\u308B\u3068\u601D\u3046\u3093\u3060",
  "id" : 603897849617649665,
  "created_at" : "2015-05-28 12:17:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603897631627182080",
  "geo" : { },
  "id_str" : "603897712849768448",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5B9F\u306F\u3051\u3063\u3053\u3046\u304A\u3044\u3057\u304F\u98DF\u3079\u308B\u52AA\u529B\u304C\u306A\u3055\u308C\u3066\u3044\u305F\u3093\u3060\u305C",
  "id" : 603897712849768448,
  "in_reply_to_status_id" : 603897631627182080,
  "created_at" : "2015-05-28 12:16:49 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603897338239782912",
  "geo" : { },
  "id_str" : "603897432745713665",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3042\u308C\u3001\u5473\u564C\u3082\u3054\u307E\u3082\u51FA\u6C41\u3082\u3061\u3083\u3093\u3068\u5165\u3063\u3066\u308B\u3093\u3060\u3088",
  "id" : 603897432745713665,
  "in_reply_to_status_id" : 603897338239782912,
  "created_at" : "2015-05-28 12:15:42 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603897168366145536",
  "text" : "\u3053\u306E\u65E9\u3055\u3067\u5F53\u6642\u306E\u753B\u50CF\u304C\u98DB\u3093\u3067\u304F\u308B\u306E\u3001\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u3060",
  "id" : 603897168366145536,
  "created_at" : "2015-05-28 12:14:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 16, 26 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 27, 43 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/haguruma20\/status\/603896975134564352\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/6ZcUkSCywu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGF5F4XU0AAXNlR.jpg",
      "id_str" : "603896966980882432",
      "id" : 603896966980882432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGF5F4XU0AAXNlR.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/6ZcUkSCywu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603897046056083456",
  "text" : "RT @haguruma20: @end313124 @Jelly_in_a_tank \u3093\uFF1F http:\/\/t.co\/6ZcUkSCywu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      }, {
        "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
        "screen_name" : "Jelly_in_a_tank",
        "indices" : [ 11, 27 ],
        "id_str" : "138430452",
        "id" : 138430452
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/haguruma20\/status\/603896975134564352\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/6ZcUkSCywu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGF5F4XU0AAXNlR.jpg",
        "id_str" : "603896966980882432",
        "id" : 603896966980882432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGF5F4XU0AAXNlR.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/6ZcUkSCywu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603896739347574784",
    "geo" : { },
    "id_str" : "603896975134564352",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 @Jelly_in_a_tank \u3093\uFF1F http:\/\/t.co\/6ZcUkSCywu",
    "id" : 603896975134564352,
    "in_reply_to_status_id" : 603896739347574784,
    "created_at" : "2015-05-28 12:13:53 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 603897046056083456,
  "created_at" : "2015-05-28 12:14:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603896956251832320",
  "text" : "\u8C46\u7E1B\u308A\u306E\u934B\u3001\u4ECA\u601D\u3044\u51FA\u3057\u3066\u3082\u9762\u767D\u3044",
  "id" : 603896956251832320,
  "created_at" : "2015-05-28 12:13:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603896392382218240",
  "geo" : { },
  "id_str" : "603896739347574784",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u6E6F\u8C46\u8150\u2026\u4F55\u304B\u5927\u5207\u306A\u3053\u3068\u3092\u5FD8\u308C\u3066\u3044\u308B\u3088\u3046\u306A\u2026",
  "id" : 603896739347574784,
  "in_reply_to_status_id" : 603896392382218240,
  "created_at" : "2015-05-28 12:12:57 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603896643407085569",
  "text" : "\u793E\u4F1A\u4EBA\u4EBA\u9593\u30DE\u30F3\u3068\u304B",
  "id" : 603896643407085569,
  "created_at" : "2015-05-28 12:12:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603896397478264832",
  "geo" : { },
  "id_str" : "603896569125982209",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u306A\u3093\u3068\u72EC\u308A\u8A00\u306B\u306F\u304A\u91D1\u3082\u304B\u304B\u3089\u306A\u3044\uFF01\u3063\u3084\u3063\u305F\u30FC\uFF01",
  "id" : 603896569125982209,
  "in_reply_to_status_id" : 603896397478264832,
  "created_at" : "2015-05-28 12:12:16 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603895895495581696",
  "text" : "\u6B7B\u306C\u307E\u3067\u6BB4\u308C\u3070\u6B7B\u306C\u3057\u3001\u6163\u308C\u308B\u307E\u3067\u540C\u3058\u5BFE\u5FDC\u3057\u7D9A\u3051\u305F\u3089\u6163\u308C\u308B\uFF08\u305F\u3060\u3057\u30A2\u30EC\u30EB\u30AE\u30FC\u306F\u9664\u304F\uFF09",
  "id" : 603895895495581696,
  "created_at" : "2015-05-28 12:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603895722107260928",
  "text" : "\u558B\u3063\u3066\u305F\u3089\u558B\u308C\u308B\u3088\u3046\u306B\u306A\u308B\uFF08\uFF1F\uFF09",
  "id" : 603895722107260928,
  "created_at" : "2015-05-28 12:08:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603895617811709953",
  "text" : "\u3086\u308B\u307C\uFF1A\u30B9\u30D4\u30FC\u30C9\u30E9\u30FC\u30CB\u30F3\u30B0\u306E\u3053\u3063\u3061\u304C\u558B\u308B\u7248\u307F\u305F\u3044\u306A\u306E",
  "id" : 603895617811709953,
  "created_at" : "2015-05-28 12:08:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603895506767511552",
  "text" : "\u4E00\u5207\u306E\u8CAC\u4EFB\u3092\u8CA0\u3044\u307E\u305B\u3093\u3002\u76F8\u624B\u304C\u53B3\u3057\u304F\u306A\u3044\u3068\u601D\u3046\u307E\u3067\u7D9A\u3051\u307E\u3057\u3087\u3046\u3002",
  "id" : 603895506767511552,
  "created_at" : "2015-05-28 12:08:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u30FC",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 3, 19 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603895423762173952",
  "text" : "RT @Jelly_in_a_tank: \u30A8\u30F3\u30C9\u3055\u3093\u306E\u30DC\u30B1\u3001\u5B8C\u5168\u306B\u30DE\u30B8\u30EC\u30B9\u3057\u7D9A\u3051\u3066\u305F\u3089\u7B11\u3063\u3066\u3089\u308C\u308B\u304B\u3089\u305D\u306E\u30AF\u30BB\u304C\u3064\u3044\u3066\u3057\u307E\u3063\u305F\u3063\u307D\u304F\u3066\u3001\u5F8C\u8F29\u306E\u30DC\u30B1\u306B\u30DE\u30B8\u30EC\u30B9\u3057\u307E\u304F\u3063\u3066\u300C\u53B3\u3057\u3044\u3063\u3059\u306D\u301C\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603895343047114752",
    "text" : "\u30A8\u30F3\u30C9\u3055\u3093\u306E\u30DC\u30B1\u3001\u5B8C\u5168\u306B\u30DE\u30B8\u30EC\u30B9\u3057\u7D9A\u3051\u3066\u305F\u3089\u7B11\u3063\u3066\u3089\u308C\u308B\u304B\u3089\u305D\u306E\u30AF\u30BB\u304C\u3064\u3044\u3066\u3057\u307E\u3063\u305F\u3063\u307D\u304F\u3066\u3001\u5F8C\u8F29\u306E\u30DC\u30B1\u306B\u30DE\u30B8\u30EC\u30B9\u3057\u307E\u304F\u3063\u3066\u300C\u53B3\u3057\u3044\u3063\u3059\u306D\u301C\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u3002",
    "id" : 603895343047114752,
    "created_at" : "2015-05-28 12:07:24 +0000",
    "user" : {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "protected" : false,
      "id_str" : "138430452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579169019770486784\/L-3CtsU-_normal.jpg",
      "id" : 138430452,
      "verified" : false
    }
  },
  "id" : 603895423762173952,
  "created_at" : "2015-05-28 12:07:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DA\u30F3\u30D1\u77F3",
      "screen_name" : "PPSPSSSPPP",
      "indices" : [ 0, 11 ],
      "id_str" : "68435106",
      "id" : 68435106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603894894864637952",
  "geo" : { },
  "id_str" : "603894981066039296",
  "in_reply_to_user_id" : 68435106,
  "text" : "@PPSPSSSPPP \u5186\u6ED1\u306B\u304A\u3057\u3083\u3079\u308A\u3067\u304D\u306A\u3044\u3068\u3044\u3051\u306A\u3044\u3067\u3059\u304B\u3089\u306D\u3047\u2026",
  "id" : 603894981066039296,
  "in_reply_to_status_id" : 603894894864637952,
  "created_at" : "2015-05-28 12:05:57 +0000",
  "in_reply_to_screen_name" : "PPSPSSSPPP",
  "in_reply_to_user_id_str" : "68435106",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603894758205890562",
  "geo" : { },
  "id_str" : "603894882067853312",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u30B9\u30D4\u30FC\u30C9\u30E9\u30FC\u30CB\u30F3\u30B0\u306E\u3053\u3063\u3061\u304C\u558B\u308B\u7248\u307F\u305F\u3044\u306A\u306E\u7121\u3044\u3093\u3067\u3059\u304B",
  "id" : 603894882067853312,
  "in_reply_to_status_id" : 603894758205890562,
  "created_at" : "2015-05-28 12:05:34 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603894697409413120",
  "text" : "\u5916\u56FD\u4EBA\u4EBA\u9593\u30DE\u30F3\u2026",
  "id" : 603894697409413120,
  "created_at" : "2015-05-28 12:04:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603894632305459202",
  "text" : "\u305F\u3060\u666E\u6BB5\u306E\u30EC\u30D9\u30EB\u306E\u304F\u3063\u3060\u3089\u306A\u3044\u304A\u3057\u3083\u3079\u308A\u3092\u82F1\u8A9E\u3067\u53D7\u3051\u7B54\u3048\u3057\u3066\u304F\u308C\u308B\u5916\u56FD\u4EBA\u4EBA\u9593\u30DE\u30F3\u304C\u3044\u305F\u3089\u304A\u3057\u3083\u3079\u308A\u3057\u305F\u3044",
  "id" : 603894632305459202,
  "created_at" : "2015-05-28 12:04:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603894515389177856",
  "text" : "\u3068\u306F\u3044\u3048\u5B8C\u5168\u306B\u30EF\u30CA\u30D3\u3060\u306A\u3001\u7279\u306B\u82F1\u4F1A\u8A71\u306E\u52C9\u5F37\u3092\u3057\u305F\u3053\u3068\u304C\u3042\u308B\u308F\u3051\u3067\u3082\u306A\u3044",
  "id" : 603894515389177856,
  "created_at" : "2015-05-28 12:04:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603894164455981056",
  "geo" : { },
  "id_str" : "603894422388879360",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u65E5\u672C\u8A9E\u3068\u540C\u3058\u52E2\u3044\u3067\u558B\u308C\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u307F\u305F\u3044\u306A",
  "id" : 603894422388879360,
  "in_reply_to_status_id" : 603894164455981056,
  "created_at" : "2015-05-28 12:03:44 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603894125562200064",
  "text" : "\u3084\u3063\u3071\u30B0\u30ED\u30FC\u30D0\u30EB\u3063\u3066\u96E3\u3057\u3044\u3093\u3060\u306A\uFF08\uFF1F\uFF09",
  "id" : 603894125562200064,
  "created_at" : "2015-05-28 12:02:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603894059187347456",
  "text" : "\u82F1\u8A9E\u3067\u7D71\u4E00\u3057\u305F\u3089\u30A2\u30E1\u30EA\u30AB\u4EBA\u3068\u304B\u306B\u3081\u3063\u3061\u3087\u6709\u5229\u3060\u3082\u3093\u306A\u2026",
  "id" : 603894059187347456,
  "created_at" : "2015-05-28 12:02:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603893838747336704",
  "text" : "\u3068\u3044\u3046\u304B\u4E16\u754C\u3067\u6226\u3046\u306E\u306B\u307F\u3093\u306A\u6BCD\u56FD\u8A9E\u4F7F\u3063\u305F\u3089\u304A\u3057\u3083\u3079\u308A\u306B\u306A\u3089\u306A\u3044\u306A\uFF1F",
  "id" : 603893838747336704,
  "created_at" : "2015-05-28 12:01:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603893759667916803",
  "text" : "\u30AA\u30EA\u30F3\u30D4\u30C3\u30AF\u3067\u306E\u300C\u304A\u3057\u3083\u3079\u308A\u300D\u3001\u8A55\u4FA1\u57FA\u6E96\u304C\u3055\u3063\u3071\u308A\u308F\u304B\u3089\u306A\u3044\u3057\u3001\u4F55\u3088\u308A\u5B9F\u6CC1\u89E3\u8AAC\u3068\u3081\u3063\u3061\u3087\u88AB\u308B\u3088\u306D",
  "id" : 603893759667916803,
  "created_at" : "2015-05-28 12:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603893341537767426",
  "text" : "\u30AA\u30EA\u30F3\u30D4\u30C3\u30AF\u7AF6\u6280\uFF1A\u304A\u3057\u3083\u3079\u308A",
  "id" : 603893341537767426,
  "created_at" : "2015-05-28 11:59:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603893223325487104",
  "text" : "\u305F\u3060\u982D\u306F\u558B\u3063\u3066\u304B\u3089\u52D5\u304D\u51FA\u3059\u3053\u3068\u304C\u591A\u3044\u306A",
  "id" : 603893223325487104,
  "created_at" : "2015-05-28 11:58:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603893017683075072",
  "geo" : { },
  "id_str" : "603893159949553664",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u308A\u3083\u3042\u307E\u3041\u982D\u3068\u4F53\u3092\u52D5\u304B\u3059\u304B\u3089\u30B9\u30DD\u30FC\u30C4\u307F\u305F\u3044\u306A\u3082\u3093\u3067\u3057\u3087",
  "id" : 603893159949553664,
  "in_reply_to_status_id" : 603893017683075072,
  "created_at" : "2015-05-28 11:58:43 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603892758089203712",
  "geo" : { },
  "id_str" : "603892857829601280",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4E00\u65E5\u935B\u932C\u3092\u6020\u308B\u3068\u53D6\u308A\u623B\u3059\u306E\u306B\u4E09\u65E5\u306F\u304B\u304B\u308B\u304B\u3089\u306A\u3041\uFF08\uFF1F\uFF09",
  "id" : 603892857829601280,
  "in_reply_to_status_id" : 603892758089203712,
  "created_at" : "2015-05-28 11:57:31 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u30FC",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603892323123130368",
  "geo" : { },
  "id_str" : "603892656456867841",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u7FCC\u65E5\u306B\u820C\u304C\u56DE\u3089\u306A\u3044\u306E\u304C\u3064\u3089\u3044\u3088\u306D",
  "id" : 603892656456867841,
  "in_reply_to_status_id" : 603892323123130368,
  "created_at" : "2015-05-28 11:56:43 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603891821190733824",
  "geo" : { },
  "id_str" : "603892002158071808",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3061\u3087\u3063\u3068\u3057\u304B\u558B\u3089\u306A\u3044\u65E5\u306F\u3042\u308B\u3002",
  "id" : 603892002158071808,
  "in_reply_to_status_id" : 603891821190733824,
  "created_at" : "2015-05-28 11:54:07 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603891693046276097",
  "text" : "\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u4E0D\u8DB3\u3063\u3066\u3053\u3046\u3044\u3046\u306E\u3092\u6307\u3055\u306A\u3044\u6C17\u304C\u3059\u308B\u306A\uFF1F",
  "id" : 603891693046276097,
  "created_at" : "2015-05-28 11:52:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603891632782495745",
  "text" : "\u4E00\u65E5\u304A\u5BB6\u306B\u3044\u305F\u3089\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u4E0D\u8DB3\u3063\u307D\u3044",
  "id" : 603891632782495745,
  "created_at" : "2015-05-28 11:52:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603890278613716994",
  "text" : "\u30CE\u30FC\u30C8PC\u306A\u3089\u5341\u5206\u6642\u9593\u6301\u3064\u3057\u5B9F\u969B\u3053\u306E\u30A2\u30A4\u30C7\u30A3\u30A2\u304C\u5B89\u5B9A\u3063\u307D\u3044",
  "id" : 603890278613716994,
  "created_at" : "2015-05-28 11:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/F3rTJ80e1a",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/603112759891374080",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603890169746296832",
  "text" : "\u6C17\u3065\u3044\u305F\u3093\u3060\u3051\u3069\u304A\u5BB6\u306E\u524D\u306B\u505C\u3081\u3066\u3042\u308B\u8ECA\u306E\u4E2D\u306A\u3089\u96FB\u6E90\u306F\u7121\u3044\u3051\u3069\u4EBA\u6A29\u306F\u5C4A\u304F\u306E\u3067\u306F\u306A\u304B\u308D\u3046\u304B https:\/\/t.co\/F3rTJ80e1a",
  "id" : 603890169746296832,
  "created_at" : "2015-05-28 11:46:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603792044905996288",
  "text" : "\u3042\u3001\u304A\u3072\u308B\u306E\u30DB\u30EF\u30A4\u30C8\u30AB\u30E9\u30FC\u898B\u305D\u3073\u308C\u305F",
  "id" : 603792044905996288,
  "created_at" : "2015-05-28 05:16:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603769740838883329",
  "text" : "\u30AD\u30E5\u30C3\u30AD\u30E5\u30C3\u30FC",
  "id" : 603769740838883329,
  "created_at" : "2015-05-28 03:48:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603568276258488321",
  "text" : "\u50D5\u304C\u6B32\u3057\u3044\u4FA1\u683C\u5E2F\u306E\u3001\u30B5\u30A4\u30BA\u306E\u3001\u4ED5\u69D8\u306E\u30C9\u30E9\u30E0\u7F36\u304C\u898B\u3064\u304B\u3089\u306A\u304B\u3063\u305F",
  "id" : 603568276258488321,
  "created_at" : "2015-05-27 14:27:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603568194549252096",
  "text" : "Amazon\u3001\u30C9\u30E9\u30E0\u7F36\u306E\u54C1\u63C3\u3048\u3042\u3093\u307E\u308A\u826F\u304F\u306A\u3044",
  "id" : 603568194549252096,
  "created_at" : "2015-05-27 14:27:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603566667960954880",
  "text" : "\u304A\u306A\u304B\u3044\u3063\u3071\u3044",
  "id" : 603566667960954880,
  "created_at" : "2015-05-27 14:21:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603550721468801026",
  "text" : "\u3053\u306E\u3084\u308A\u3068\u308A\u304C\u50D5\u306E\u624B\u3092\u96E2\u308C\u3066\u201C\u201D\u6587\u5316\u201C\u201D\u304C\u5F62\u6210\u3055\u308C\u305F\u306E\u3092\u8A87\u308A\u306B\u601D\u3046",
  "id" : 603550721468801026,
  "created_at" : "2015-05-27 13:18:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "\u6101\u5BAE\u5F69\u90FD(21)\/S.Uremiya",
      "screen_name" : "ulexite_17",
      "indices" : [ 34, 45 ],
      "id_str" : "232830101",
      "id" : 232830101
    }, {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 47, 56 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603550600354115584",
  "text" : "RT @kagakuma: \u304D\u3001\u304D\u305F\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01RT @ulexite_17: @kagakuma \u5317\u533A\u304B\u3089\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6101\u5BAE\u5F69\u90FD(21)\/S.Uremiya",
        "screen_name" : "ulexite_17",
        "indices" : [ 20, 31 ],
        "id_str" : "232830101",
        "id" : 232830101
      }, {
        "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
        "screen_name" : "kagakuma",
        "indices" : [ 33, 42 ],
        "id_str" : "139989698",
        "id" : 139989698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603550096668561409",
    "text" : "\u304D\u3001\u304D\u305F\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01RT @ulexite_17: @kagakuma \u5317\u533A\u304B\u3089\uFF1F",
    "id" : 603550096668561409,
    "created_at" : "2015-05-27 13:15:31 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 603550600354115584,
  "created_at" : "2015-05-27 13:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "\u304D\u3063\u3057\u3043\u3055\u3093\u306F6\u67087\u65E5\u751F\u307E\u308C",
      "screen_name" : "aitaioddstr",
      "indices" : [ 31, 43 ],
      "id_str" : "1523835464",
      "id" : 1523835464
    }, {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 45, 54 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603550581425180672",
  "text" : "RT @kagakuma: \u304D\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01RT @aitaioddstr: @kagakuma \u3069\u3053\u304B\u3089\u3063\uFF01\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u304D\u3063\u3057\u3043\u3055\u3093\u306F6\u67087\u65E5\u751F\u307E\u308C",
        "screen_name" : "aitaioddstr",
        "indices" : [ 17, 29 ],
        "id_str" : "1523835464",
        "id" : 1523835464
      }, {
        "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
        "screen_name" : "kagakuma",
        "indices" : [ 31, 40 ],
        "id_str" : "139989698",
        "id" : 139989698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603549045349429249",
    "text" : "\u304D\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01RT @aitaioddstr: @kagakuma \u3069\u3053\u304B\u3089\u3063\uFF01\uFF1F",
    "id" : 603549045349429249,
    "created_at" : "2015-05-27 13:11:20 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 603550581425180672,
  "created_at" : "2015-05-27 13:17:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon.co.jp (\u30A2\u30DE\u30BE\u30F3)",
      "screen_name" : "AmazonJP",
      "indices" : [ 73, 82 ],
      "id_str" : "161616614",
      "id" : 161616614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/bPt24mnHFG",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B00BS48YJQ\/ref=cm_sw_r_tw_awdo_jfAzvb0VZAKWN",
      "display_url" : "amazon.co.jp\/dp\/B00BS48YJQ\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603513541346201601",
  "text" : "\u30D6\u30EB\u30DE\u30F3\u7A7A\u6A3DNo.3 \u30E9\u30C3\u30AD\u30FC\u30B3\u30FC\u30D2\u30FC\u30DE\u30B7\u30F3#\u30A2\u30DE\u30BE\u30F3\u30DD\u30C1 \u3068\u5165\u308C\u3066@\u8FD4\u4FE1\u3067\u30AB\u30FC\u30C8\u306B\u8FFD\u52A0\u30FB\u5F8C\u3067\u8CB7\u3046 http:\/\/t.co\/bPt24mnHFG @amazonJP\u3055\u3093\u304B\u3089\n\u304B\u306A\u3089\u305A\u3057\u3082\u307B\u3057\u304F\u306A\u3044\u3082\u306E\u30EA\u30B9\u30C8\u306B\u8FFD\u52A0\u3057\u307E\u3057\u305F",
  "id" : 603513541346201601,
  "created_at" : "2015-05-27 10:50:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603471708318638080",
  "text" : "\u3053\u3053\u3092\u901A\u308B\u305F\u3073\u306B\u6681\u306E\u5947\u5999\u306A\u5171\u95D8\u306E\u52D5\u753B\u3092\u601D\u3044\u51FA\u3059",
  "id" : 603471708318638080,
  "created_at" : "2015-05-27 08:04:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603471529125421056",
  "text" : "\u7B39\u585A\u306A",
  "id" : 603471529125421056,
  "created_at" : "2015-05-27 08:03:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603471508929818624",
  "text" : "\u5947\u5999\u306A\u5171\u95D8\u30D7\u30EC\u30A4\u30B9",
  "id" : 603471508929818624,
  "created_at" : "2015-05-27 08:03:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603467532935110656",
  "text" : "\u50D5\u304C\u5ACC\u3046\u504F\u898B\u306B\u52A9\u3051\u3089\u308C\u3066\u3044\u308B\u6C17\u304C\u3059\u308B\u304B\u3089\u3082\u3084\u308B",
  "id" : 603467532935110656,
  "created_at" : "2015-05-27 07:47:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603215150028468225",
  "text" : "\u3053\u306E\u5909\u5316\u611F\u304C\u5927\u597D\u304D\u306A\u3093\u3060\u3088\u306A",
  "id" : 603215150028468225,
  "created_at" : "2015-05-26 15:04:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 3, 12 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/xTZBsefZhJ",
      "expanded_url" : "http:\/\/w125.hateblo.jp\/entry\/2015\/05\/24\/182250",
      "display_url" : "w125.hateblo.jp\/entry\/2015\/05\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603215103974977536",
  "text" : "RT @hanaoka_: \u308F\u3093\u3069\u3055\u3093\u306E\u304A\u3046\u3061\u3067\u904A\u3093\u3060\u300C\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u300D\u3081\u3061\u3083\u304F\u3061\u3083\u304A\u3082\u3057\u308D\u304B\u3063\u305F\u306E\u3067\u3053\u306E\u307E\u3068\u3081\u3082\u6FC0\u30E4\u30D0\u9B3C\u30DE\u30B9\u30C8\u3067\u3059 \u2192 http:\/\/t.co\/xTZBsefZhJ \u591C\u3082\u3046\u4E00\u56DE\u3084\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/xTZBsefZhJ",
        "expanded_url" : "http:\/\/w125.hateblo.jp\/entry\/2015\/05\/24\/182250",
        "display_url" : "w125.hateblo.jp\/entry\/2015\/05\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602411239197671425",
    "text" : "\u308F\u3093\u3069\u3055\u3093\u306E\u304A\u3046\u3061\u3067\u904A\u3093\u3060\u300C\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u300D\u3081\u3061\u3083\u304F\u3061\u3083\u304A\u3082\u3057\u308D\u304B\u3063\u305F\u306E\u3067\u3053\u306E\u307E\u3068\u3081\u3082\u6FC0\u30E4\u30D0\u9B3C\u30DE\u30B9\u30C8\u3067\u3059 \u2192 http:\/\/t.co\/xTZBsefZhJ \u591C\u3082\u3046\u4E00\u56DE\u3084\u308B",
    "id" : 602411239197671425,
    "created_at" : "2015-05-24 09:50:06 +0000",
    "user" : {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "protected" : false,
      "id_str" : "126927392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540399732707688448\/Iqz4rTVp_normal.jpeg",
      "id" : 126927392,
      "verified" : false
    }
  },
  "id" : 603215103974977536,
  "created_at" : "2015-05-26 15:04:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603209675241353216",
  "text" : "\u671D\u304B\u3089\u3068\u306F\u8A00\u3063\u3066\u3044\u306A\u3044",
  "id" : 603209675241353216,
  "created_at" : "2015-05-26 14:42:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603177475389071361",
  "geo" : { },
  "id_str" : "603178825569193984",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3042\u3001Skype\u306E\u8A8D\u8A3C\u3057\u3068\u3044\u3066\u304F\u3060\u3055\u308C",
  "id" : 603178825569193984,
  "in_reply_to_status_id" : 603177475389071361,
  "created_at" : "2015-05-26 12:40:13 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603177475389071361",
  "geo" : { },
  "id_str" : "603177700711395328",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3060\u3044\u305F\u3044\u308F\u304B\u3063\u305F\u3001\u3058\u3083\u3042\u3042\u3093\u307E\u308A\u6C17\u306B\u3057\u306A\u304F\u3066OK",
  "id" : 603177700711395328,
  "in_reply_to_status_id" : 603177475389071361,
  "created_at" : "2015-05-26 12:35:45 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603176931819917312",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u821E\u53F0\u3063\u3066\u5171\u7523\u570F\u3063\u3066\u7406\u89E3\u3067\u3044\u3044\u306E\u304B\u306A",
  "id" : 603176931819917312,
  "created_at" : "2015-05-26 12:32:41 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603175056441778176",
  "text" : "\uFF20\u5404\u4F4D \u9069\u5F53\u306B\u653E\u308A\u8FBC\u307F\u307E\u3057\u305F\u3002",
  "id" : 603175056441778176,
  "created_at" : "2015-05-26 12:25:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603174306693160960",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u653E\u308A\u6295\u3052\u308B\u3060\u3051\u653E\u308A\u6295\u3052\u305F",
  "id" : 603174306693160960,
  "created_at" : "2015-05-26 12:22:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/c1TeTddxy0",
      "expanded_url" : "http:\/\/charasheet.vampire-blood.net\/311012",
      "display_url" : "charasheet.vampire-blood.net\/311012"
    } ]
  },
  "geo" : { },
  "id_str" : "603171465597444096",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh http:\/\/t.co\/c1TeTddxy0",
  "id" : 603171465597444096,
  "created_at" : "2015-05-26 12:10:58 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 0, 10 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u3044\u308B\u305F\u3093",
      "screen_name" : "t_iru",
      "indices" : [ 11, 17 ],
      "id_str" : "1020292580",
      "id" : 1020292580
    }, {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 18, 28 ],
      "id_str" : "616883839",
      "id" : 616883839
    }, {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 29, 40 ],
      "id_str" : "520458209",
      "id" : 520458209
    }, {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 41, 50 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 52, 60 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603169242364694528",
  "in_reply_to_user_id" : 155546700,
  "text" : "@end313124 @t_iru @ryoOOochh @Maleic1618 @kagakuma (\uFF20bagirom) Skype\u304B\u30B0\u30EB\u30FC\u30D7DM\u304B\u3067\u30AD\u30E3\u30E9\u30B7\u4F5C\u308A\u76F8\u8AC7\u4F1A\u307F\u305F\u3044\u306A\u306E\u3084\u308A\u307E\u305B\u3093\u304B",
  "id" : 603169242364694528,
  "created_at" : "2015-05-26 12:02:08 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603157431686803457",
  "geo" : { },
  "id_str" : "603157556349964288",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u30A2\u30C3\u30CF\u30A4(\u00B4_\u309D\u02CB)\uFF87\uFF70\uFF9D",
  "id" : 603157556349964288,
  "in_reply_to_status_id" : 603157431686803457,
  "created_at" : "2015-05-26 11:15:42 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603157275155369984",
  "geo" : { },
  "id_str" : "603157484832890880",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u597D\u304D\u3063\u3066\u8A00\u3063\u305F\u5974\u306B\u5BFE\u3057\u3066\u3044\u3063\u305F\u307B\u3046\u304C\u30A8\u30D5\u30A7\u30AF\u30C6\u30A3\u30D6",
  "id" : 603157484832890880,
  "in_reply_to_status_id" : 603157275155369984,
  "created_at" : "2015-05-26 11:15:25 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603156726771130368",
  "text" : "\u50D5\u3082\u3054\u98EF\u98DF\u3079\u3066\u3057\u307E\u3063\u305F",
  "id" : 603156726771130368,
  "created_at" : "2015-05-26 11:12:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603156062775160832",
  "text" : "\u3048\uFF1F\u3044\u3048\u3001\u30E1\u30F3\u30C1\u30AB\u30C4\u306B\u6068\u307F\u306F\u306A\u3044\u3067\u3059\u3002\u30E1\u30F3\u30C1\u30AB\u30C4\u306B\u304A\u3084\u3092\u3053\u308D\u3055\u308C\u305F\u308F\u3051\u3067\u3082\u3042\u308A\u307E\u305B\u3093\u3002",
  "id" : 603156062775160832,
  "created_at" : "2015-05-26 11:09:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603155953068834817",
  "text" : "\u305D\u3093\u306A\u306B\u30E1\u30F3\u30C1\u30AB\u30C4\u3070\u3063\u304B\u308A\u98DF\u3079\u3066\u308B\u3068\u30E1\u30F3\u30C1\u30AB\u30C4\u306B\u306A\u3063\u3061\u3083\u3044\u307E\u3059\u3088\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 603155953068834817,
  "created_at" : "2015-05-26 11:09:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603155894679941121",
  "text" : "\u305D\u3093\u306A\u306B\u30E1\u30F3\u30C1\u30AB\u30C4\u304C\u98DF\u3044\u305F\u3051\u308C\u3070\u30E1\u30F3\u30C1\u30AB\u30C4\u5C4B\u3055\u3093\u306B\u884C\u3051\u3070\u3044\u3044\u3067\u3057\u3087\uFF01\uFF01\uFF01",
  "id" : 603155894679941121,
  "created_at" : "2015-05-26 11:09:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603155475295817729",
  "geo" : { },
  "id_str" : "603155714735910915",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u63DA\u3052\u7269\u3068\u304B\u3082\u3042\u3063\u305F\u3088\u305F\u3076\u3093\u3001\u30E1\u30F3\u30C1\u304C\u3042\u308B\u304B\u306F\u77E5\u3089\u306A\u3044\u304C",
  "id" : 603155714735910915,
  "in_reply_to_status_id" : 603155475295817729,
  "created_at" : "2015-05-26 11:08:23 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 15, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603155617490939904",
  "text" : "\u98F2\u98DF\u5E97\u306E\u8A55\u4FA1\u3067\u5E97\u54E1\u3092\u8912\u3081\u308B\u4EBA #\u4EBA",
  "id" : 603155617490939904,
  "created_at" : "2015-05-26 11:07:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603155122600837121",
  "text" : "\u7389\u306D\u304E\u5927\u304D\u3081\u3067\u30BF\u30EB\u30BF\u30EB\u304C\u305F\u308B\u305F\u308B\u3057\u3066\u3066\u3059\u304D",
  "id" : 603155122600837121,
  "created_at" : "2015-05-26 11:06:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603154223061016577",
  "geo" : { },
  "id_str" : "603154971723341824",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u30CF\u30F3\u30D0\u30FC\u30B0\u306A\u3089\u30DF\u30EA\u30AA\u30F3\u306E\u307B\u3046\u304C\u597D\u304D",
  "id" : 603154971723341824,
  "in_reply_to_status_id" : 603154223061016577,
  "created_at" : "2015-05-26 11:05:25 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603151432661868544",
  "text" : "\u518D\u5EA6\u5947\u5999\u306A\u5171\u95D8\u30D7\u30EC\u30A4\u30B9\u3060",
  "id" : 603151432661868544,
  "created_at" : "2015-05-26 10:51:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603150478780674048",
  "text" : "\u3042\u307E\u308A\u306B\u3082\u81EA\u7136\u306B\u30EA\u30AF\u30E9\u30A4\u30CB\u30F3\u30B0\u30C7\u30B9\u30AF\u3063\u3066\u5358\u8A9E\u304C\u53E3\u304B\u3089\u98DB\u3073\u51FA\u305F",
  "id" : 603150478780674048,
  "created_at" : "2015-05-26 10:47:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603148202586415104",
  "text" : "\u30C7\u30B9\u30AF\u306F\u30EA\u30AF\u30E9\u30A4\u30CB\u30F3\u30B0\u3057\u306A\u3044\u3053\u3068\u3092\u304A\u52E7\u3081\u3057\u307E\u3059",
  "id" : 603148202586415104,
  "created_at" : "2015-05-26 10:38:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u58F0\u306B\u51FA\u3057\u3066\u8AAD\u307F\u305F\u3044\u65E5\u672C\u8A9E",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603145868871499777",
  "text" : "\u30B9\u30EA\u30B8\u30E3\u30E4\u30EF\u30EB\u30C0\u30CA\u30D7\u30E9\u30B3\u30C3\u30C6 #\u58F0\u306B\u51FA\u3057\u3066\u8AAD\u307F\u305F\u3044\u65E5\u672C\u8A9E",
  "id" : 603145868871499777,
  "created_at" : "2015-05-26 10:29:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hxpyCN5YdL",
      "expanded_url" : "https:\/\/twitter.com\/bagirom\/status\/603119588646125568",
      "display_url" : "twitter.com\/bagirom\/status\u2026"
    }, {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/NsZCmIW2JX",
      "expanded_url" : "https:\/\/twitter.com\/bagirom\/status\/603120386746617857",
      "display_url" : "twitter.com\/bagirom\/status\u2026"
    }, {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/wO1daC0fO2",
      "expanded_url" : "https:\/\/twitter.com\/bagirom\/status\/603121817939640320",
      "display_url" : "twitter.com\/bagirom\/status\u2026"
    }, {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/oPUDIcbJ7S",
      "expanded_url" : "https:\/\/twitter.com\/bagirom\/status\/603121869152092160",
      "display_url" : "twitter.com\/bagirom\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603127447853211648",
  "text" : "https:\/\/t.co\/hxpyCN5YdL\nhttps:\/\/t.co\/NsZCmIW2JX\nhttps:\/\/t.co\/wO1daC0fO2\nhttps:\/\/t.co\/oPUDIcbJ7S\n\n\u3042\u305F\u308A\u3067\u3059",
  "id" : 603127447853211648,
  "created_at" : "2015-05-26 09:16:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603121202752655361",
  "geo" : { },
  "id_str" : "603121418188955648",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u305D\u3046\u3063\u307D\u3044\u306D",
  "id" : 603121418188955648,
  "in_reply_to_status_id" : 603121202752655361,
  "created_at" : "2015-05-26 08:52:06 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603113687780495360",
  "geo" : { },
  "id_str" : "603117651787816960",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u624B\u914D\u51FA\u6765\u305D\u3046\u306A\u306E\u3067\u3053\u306E\u524D\u306E\u30A6\u30A7\u30D6\u5F62\u5F0F\u306E\u30AD\u30E3\u30E9\u30B7\u306B\u5165\u529B\u3057\u3066\u306A\u6295\u3052\u308B\u5F62\u3067\u3082\u3088\u3044\u3060\u308D\u3046\u304B",
  "id" : 603117651787816960,
  "in_reply_to_status_id" : 603113687780495360,
  "created_at" : "2015-05-26 08:37:08 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603115058634194944",
  "text" : "\u622F\u8A00\u30B7\u30EA\u30FC\u30BA\u306B\u51FA\u3066\u304D\u305F\u30AA\u30D5\u30E9\u30A4\u30F3\u74B0\u5883\u306B\u3042\u308B\u7269\u3092\u76F4\u63A5\u53D6\u308A\u306B\u884C\u304F\u306E\u3001\u8857\u3060\u3063\u3051\u304B\u3001\u3042\u308C\u3092\u601D\u3044\u51FA\u3057\u305F",
  "id" : 603115058634194944,
  "created_at" : "2015-05-26 08:26:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603113163362435072",
  "geo" : { },
  "id_str" : "603113613331599361",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u305F\u3060\u3061\u3087\u3063\u3068\u53EF\u80FD\u306A\u3089\u624B\u914D\u3057\u3066\u307F\u308B\u304B\u3089\u5F85\u305F\u308C\u3088",
  "id" : 603113613331599361,
  "in_reply_to_status_id" : 603113163362435072,
  "created_at" : "2015-05-26 08:21:05 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603113520205471744",
  "text" : "\u30AB\u30DF\u30DF\u30F3\u30B0\u304C\u305F\u307F\u5408\u308F\u306A\u3044",
  "id" : 603113520205471744,
  "created_at" : "2015-05-26 08:20:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603113163362435072",
  "geo" : { },
  "id_str" : "603113474877628417",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u30A2\u30A4\u30A8\u30A8\u30A8\uFF01\u306A\u305C\u672D\u5E4C\u306B\u3044\u308B\u9593\u306B\u8A00\u308F\u306A\u304B\u3063\u305F\u2026\uFF01",
  "id" : 603113474877628417,
  "in_reply_to_status_id" : 603113163362435072,
  "created_at" : "2015-05-26 08:20:32 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603113124716097536",
  "geo" : { },
  "id_str" : "603113328567693312",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u304A\u3063\uFF1F(\u6D41\u77F3\u306B\u3072\u3068\u306E\u5BB6\u62BC\u3057\u304B\u3051\u3066\u305D\u306E\u4EBA\u629C\u304D\u3067\u30AA\u30F3\u30E9\u30A4\u30F3\u30BB\u30C3\u30B7\u30E7\u30F3TRPG\u3084\u308B\u306E\u306F\u610F\u5473\u4E0D\u660E\u3067\u3059\u306D\uFF1F)",
  "id" : 603113328567693312,
  "in_reply_to_status_id" : 603113124716097536,
  "created_at" : "2015-05-26 08:19:57 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603112759891374080",
  "text" : "\u5B9F\u5BB6\u3067\u306A\u304F\u3066\u3082\u4EBA\u6A29\u3068\u96FB\u6E90\u306E\u3042\u308B\u591A\u5C11\u3046\u308B\u3055\u304F\u3057\u3066\u3082(Skype)\u5927\u4E08\u592B\u306A\u7A7A\u9593\u306A\u3089\u3069\u3053\u3067\u3082\u826F\u3044\u3093\u3060\u304C\u306A",
  "id" : 603112759891374080,
  "created_at" : "2015-05-26 08:17:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603112585739677697",
  "text" : "\u4EBA\u6A29\u3068\u96FB\u6E90\u306E\u3042\u308B\u30AF\u30ED\u30FC\u30BA\u30C9\u306A\u7A7A\u9593\u304C\u5B9F\u5BB6\u306B\u306A\u3044\u304B\u3089\u306A\u3041\u2026\u3069\u3046\u3057\u305F\u3082\u306E\u304B",
  "id" : 603112585739677697,
  "created_at" : "2015-05-26 08:17:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603112279954063360",
  "geo" : { },
  "id_str" : "603112409989914625",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3044\u3048\u3059",
  "id" : 603112409989914625,
  "in_reply_to_status_id" : 603112279954063360,
  "created_at" : "2015-05-26 08:16:18 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603111406947475457",
  "geo" : { },
  "id_str" : "603111946628374531",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u5915\u65B9\u306E\u65E9\u3044\u6642\u9593\u304B\u3089\u306F\u3067\u304D\u306A\u3044\u304B\u306A",
  "id" : 603111946628374531,
  "in_reply_to_status_id" : 603111406947475457,
  "created_at" : "2015-05-26 08:14:28 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603110927962087425",
  "geo" : { },
  "id_str" : "603111443777523713",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u307E\u3041\u3001\u305D\u3046\u306A\u308B\u306A",
  "id" : 603111443777523713,
  "in_reply_to_status_id" : 603110927962087425,
  "created_at" : "2015-05-26 08:12:28 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603111201485103104",
  "text" : "\u4E57\u308A\u7D99\u304E\u3046\u307E\u304F\u3044\u3063\u305F\u3068\u306F\u601D\u3046\u304C",
  "id" : 603111201485103104,
  "created_at" : "2015-05-26 08:11:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603111138771902464",
  "text" : "\u30C9\u30A2\u30C8\u30A5\u5F85\u3061\u5408\u308F\u305B\u5834\u6240\u306730\u5206\u5207\u308B\u3068\u306F\u2026",
  "id" : 603111138771902464,
  "created_at" : "2015-05-26 08:11:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603110726161473536",
  "text" : "\u4E00\u6669\u3067\u7D42\u308F\u308B\u30BB\u30C3\u30B7\u30E7\u30F3\u3068\u306F\u601D\u3063\u3066\u306A\u304B\u3063\u305F\u304C",
  "id" : 603110726161473536,
  "created_at" : "2015-05-26 08:09:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603109986412011520",
  "text" : "\u306A\u304A\u6587\u8108\u306F\u628A\u63E1\u3057\u3066\u3044\u306A\u3044\u3068\u9006\u3089\u3046\u306E\u304C\u96E3\u3057\u3044\u306E\u3067\u3061\u3083\u3093\u3068\u628A\u63E1\u3057\u3088\u3046\u306A",
  "id" : 603109986412011520,
  "created_at" : "2015-05-26 08:06:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603109864617807872",
  "text" : "\u6587\u8108\u306B\u306F\u7A4D\u6975\u7684\u306B\u9006\u3089\u3063\u3066\u3044\u3051",
  "id" : 603109864617807872,
  "created_at" : "2015-05-26 08:06:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603109577861693440",
  "geo" : { },
  "id_str" : "603109757298192384",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u30C9\u30F3\u30DE\u30A4\uFF01\uFF01\uFF01\u6C17\u306B\u3059\u3093\u306A\uFF01\uFF01\uFF01",
  "id" : 603109757298192384,
  "in_reply_to_status_id" : 603109577861693440,
  "created_at" : "2015-05-26 08:05:46 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603109381186584576",
  "text" : "\u65E5\u7A0B\u3092\u6295\u3052\u308B\u3057\u304B\u306A\u3044",
  "id" : 603109381186584576,
  "created_at" : "2015-05-26 08:04:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603071935422038016",
  "text" : "\u9811\u5F35\u3063\u3066\u8D77\u304D\u3066\u308C\u3070\u65E9\u5BDD\u65E9\u8D77\u304D\u306E\u30EA\u30BA\u30E0\u306B\u306A\u308B\u306F\u305A\u306A\u3093\u3060\u305F\u3076\u3093",
  "id" : 603071935422038016,
  "created_at" : "2015-05-26 05:35:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603071868334153728",
  "text" : "\u6696\u304B\u3044\u3057\u3061\u3087\u3063\u3068\u5BDD\u4E0D\u8DB3\u3060\u3057\u7720\u3063\u3066\u3057\u307E\u3044\u305D\u3046",
  "id" : 603071868334153728,
  "created_at" : "2015-05-26 05:35:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603056855687024640",
  "text" : "\u7AEF\u7684\u306B\u8A00\u3063\u3066\u4ECA\u65E5\u306F\u6691\u3044",
  "id" : 603056855687024640,
  "created_at" : "2015-05-26 04:35:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603027353011228672",
  "geo" : { },
  "id_str" : "603027416705966080",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u98A8\u8A55\u88AB\u5BB3\u306A",
  "id" : 603027416705966080,
  "in_reply_to_status_id" : 603027353011228672,
  "created_at" : "2015-05-26 02:38:34 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603026995467792384",
  "text" : "gosh\u3068\u304B\u7121\u9650\u306B\u61D0\u304B\u3057\u3044",
  "id" : 603026995467792384,
  "created_at" : "2015-05-26 02:36:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602849269473742849",
  "text" : "\u3044\u3084\u3001\u7D42\u308F\u308A\u305D\u3046\u306A\u30A2\u30C3\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3060\u3068\u306F\u601D\u3063\u3066\u305F\u3051\u3069\u3055",
  "id" : 602849269473742849,
  "created_at" : "2015-05-25 14:50:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u307F\u306A\u3061\u3083\u3093",
      "screen_name" : "rumichang",
      "indices" : [ 0, 10 ],
      "id_str" : "242763253",
      "id" : 242763253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602848635706040320",
  "geo" : { },
  "id_str" : "602848684813000704",
  "in_reply_to_user_id" : 242763253,
  "text" : "@rumichang \u3068\u3053\u308D\u304C\u3069\u3063\u3053\u3044\u672C\u5F53\u3067\u3059",
  "id" : 602848684813000704,
  "in_reply_to_status_id" : 602848635706040320,
  "created_at" : "2015-05-25 14:48:21 +0000",
  "in_reply_to_screen_name" : "rumichang",
  "in_reply_to_user_id_str" : "242763253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602848614155755520",
  "text" : "\u6C38\u9060\u306B\u7D9A\u304F\u3068\u601D\u3063\u3066\u305F\u306E\u306B\u306A",
  "id" : 602848614155755520,
  "created_at" : "2015-05-25 14:48:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602848585730895872",
  "text" : "\u30E9\u30D6\u3084\u3093\u3001\u5B8C\u7D50\u3057\u307E\u3057\u305F",
  "id" : 602848585730895872,
  "created_at" : "2015-05-25 14:47:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602848561114554369",
  "text" : "\u3048\u30FC\u3001\u307F\u306A\u3055\u3093\u306B\u4FE1\u3058\u3089\u308C\u306A\u3044\u304A\u77E5\u3089\u305B\u304C\u3042\u308A\u307E\u3059",
  "id" : 602848561114554369,
  "created_at" : "2015-05-25 14:47:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602828099517063168",
  "text" : "\u305F\u3093\u3058\u3047\u304F\u3093\u306E\u795E\u56DE\u907F\u3001\u672A\u3060\u306B\u304A\u307C\u3048\u3066\u3044\u308B\u30ED\u30FC\u30EB\u306E\u4E00\u3064\u3060",
  "id" : 602828099517063168,
  "created_at" : "2015-05-25 13:26:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602822377433620480",
  "text" : "\u99C4\u5B9F\u5199\u5316\u306F\u898B\u306A\u304B\u3063\u305F\u3053\u3068\u306B\u3059\u308B\u3063\u3066\u30E1\u30BD\u30C3\u30C9\u304C\u3042\u308B\u3067\u3042\u308D\uFF1F",
  "id" : 602822377433620480,
  "created_at" : "2015-05-25 13:03:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602747228776583168",
  "geo" : { },
  "id_str" : "602747474621636608",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u3042\u3089\u3089\u3069\u3093\u307E\u3044",
  "id" : 602747474621636608,
  "in_reply_to_status_id" : 602747228776583168,
  "created_at" : "2015-05-25 08:06:11 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    }, {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 33, 39 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602746459625164801",
  "geo" : { },
  "id_str" : "602746645911105536",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u660E\u65E519\u6642\u3059\u304E\u306B\u65B0\u5BBF\u3067\u3054\u98EF\u3068\u304B\u3069\u3046\u3067\u3059\u304B  \uFF08@k08a_ \uFF09",
  "id" : 602746645911105536,
  "in_reply_to_status_id" : 602746459625164801,
  "created_at" : "2015-05-25 08:02:53 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602746434132279296",
  "text" : "\u3042\u30FC\u3042\u308C\u306A\u3089DM\u3067\u3082",
  "id" : 602746434132279296,
  "created_at" : "2015-05-25 08:02:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602744146634219521",
  "geo" : { },
  "id_str" : "602746392113782784",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u591C\u884C\u3067\u5E30\u308B\u611F\u3058\u3060\u3068\u65B0\u5BBF\u3068\u304B\uFF1F",
  "id" : 602746392113782784,
  "in_reply_to_status_id" : 602744146634219521,
  "created_at" : "2015-05-25 08:01:53 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602742886409502721",
  "geo" : { },
  "id_str" : "602743138059472896",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u3080\u3080\u3080\u3080\u3080\u3001\u660E\u65E5\u306A\u3089\u307C\u304F\u3082\u6642\u9593\u304C\u3042\u308B\u3093\u3060\u3051\u3069\u5FD9\u3057\u304F\u306A\u3044\uFF08\uFF1F\uFF09\u6642\u9593\u5E2F\u3042\u308B\uFF1F",
  "id" : 602743138059472896,
  "in_reply_to_status_id" : 602742886409502721,
  "created_at" : "2015-05-25 07:48:57 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602742550722514945",
  "geo" : { },
  "id_str" : "602742677881417729",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u3044\u3064\u307E\u3067\u3044\u307E\u3059\uFF1F",
  "id" : 602742677881417729,
  "in_reply_to_status_id" : 602742550722514945,
  "created_at" : "2015-05-25 07:47:07 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602736190916325376",
  "text" : "s\/\u6B32\/\u3088\u304F",
  "id" : 602736190916325376,
  "created_at" : "2015-05-25 07:21:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602736163867222016",
  "text" : "\u30DD\u30FC\u30BF\u30EB\u76F4\u4E0B\u3068\u3044\u3046\u3079\u304D\u306A\u306E\u304B\u30DD\u30FC\u30BF\u30EB\u76F4\u4E0A\u3068\u3044\u3046\u3079\u304D\u306A\u306E\u304B\u3044\u307E\u3044\u3061\u6B32\u5206\u304B\u3089\u306A\u3044",
  "id" : 602736163867222016,
  "created_at" : "2015-05-25 07:21:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602731533808439296",
  "text" : "\u58F0\u3092\u304B\u3051\u308B\u304B\u8FF7\u3063\u305F\u30EC\u30D9\u30EB",
  "id" : 602731533808439296,
  "created_at" : "2015-05-25 07:02:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602731465978220544",
  "text" : "\u4ECA\u50D5\u306E\u3053\u3068\u8FFD\u3044\u629C\u304B\u3057\u305F\u81EA\u8EE2\u8ECA\u306E\u3072\u3068\u3001\u305F\u3076\u3093\u30A8\u30FC\u30B8\u30A7\u30F3\u30C8\u3060\u3057\u305F\u3076\u3093\u540D\u524D\u3082\u30A2\u30EC\u3060\u306A\u3063\u3066\u308F\u304B\u308B",
  "id" : 602731465978220544,
  "created_at" : "2015-05-25 07:02:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602724817398140928",
  "text" : "\u6210\u679C\u7269\u3067\u6BB4\u308B\u30A2\u30EC\u6D3B\u304C\u3057\u305F\u304B\u3063\u305F(\u5B8C)",
  "id" : 602724817398140928,
  "created_at" : "2015-05-25 06:36:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602724482982158336",
  "text" : "\u3046\u3093\uFF1F",
  "id" : 602724482982158336,
  "created_at" : "2015-05-25 06:34:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602724465877721088",
  "text" : "\u30A2\u30FC\u30B9\u30AF\u30A8\u30A4\u30AF\u304C\u6765\u305F\u304B\u3089\u305D\u306E\u3046\u3061\u30D2\u30E5\u30FC\u30B8\u30B7\u30E5\u30EA\u30B1\u30F3\u3082\u6765\u308B\u3068\u601D\u3046",
  "id" : 602724465877721088,
  "created_at" : "2015-05-25 06:34:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602721260137656320",
  "text" : "end.K\u306F\u9759\u304B\u306B\u66AE\u3089\u3057\u305F\u3044",
  "id" : 602721260137656320,
  "created_at" : "2015-05-25 06:22:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602721191640469504",
  "text" : "\u30A2\u30EC\u6D3B\u3001\u666E\u6BB5\u306E\u751F\u6D3B\u306B\u6BD4\u3079\u3066\u5FC3\u304C\u63FA\u3055\u3076\u3089\u308C\u308B\u7BC4\u56F2\u304C\u5E83\u3044\u304B\u3089\u75B2\u308C\u308B\u3088\u306D",
  "id" : 602721191640469504,
  "created_at" : "2015-05-25 06:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602705138441027585",
  "text" : "s\/\u8CB7\u3044\/\u306A\u3044",
  "id" : 602705138441027585,
  "created_at" : "2015-05-25 05:17:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602705043452637184",
  "text" : "\u300C\u306A\u308B\u3088\u3046\u306B\u306A\u308B\u300D\u524D\u5411\u304D\u306A\u3088\u3046\u3067\u4F55\u3082\u8A00\u3063\u3066\u8CB7\u3044\u611F\u3058\u304C\u5927\u597D\u304D\u3002",
  "id" : 602705043452637184,
  "created_at" : "2015-05-25 05:17:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602704148417482753",
  "text" : "\u307E\u3063",
  "id" : 602704148417482753,
  "created_at" : "2015-05-25 05:14:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602694136647454720",
  "text" : "\u8D64\u5742\u898B\u3064\u3051\u3001\u8D64\u5742\u5931\u304F\u3057",
  "id" : 602694136647454720,
  "created_at" : "2015-05-25 04:34:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/qu57PiZUZJ",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/602481551515848706",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602481734580600833",
  "text" : "kata\u3063\u3066\u30B3\u30DE\u30F3\u30C9\u3042\u3063\u305F\u304B\u3089\u4F55\u3060\u308D\u3046\u3068\u601D\u3063\u3066\u53E9\u3044\u3066\u51FA\u3066\u304D\u305F\u306E\u304C\u3053\u308C\u3067\u3059\u3088\nhttps:\/\/t.co\/qu57PiZUZJ",
  "id" : 602481734580600833,
  "created_at" : "2015-05-24 14:30:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602481551515848706",
  "text" : "\u578B\u304C\u30AB\u30BF\u30AB\u30BF\u3068\u97F3\u3092\u305F\u3066\u308B\u306E\u3067\u3059\uFF0E",
  "id" : 602481551515848706,
  "created_at" : "2015-05-24 14:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602481423770058752",
  "text" : "\u304F\u3060\u3089\u306A\u3044\u3082\u306E\u3060\u3044\u3059\u304D",
  "id" : 602481423770058752,
  "created_at" : "2015-05-24 14:28:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602481402324594688",
  "text" : "\u904E\u53BB\u306E\u81EA\u5206\u3001\u4E0B\u3089\u306A\u3044\u3082\u306E\u3070\u304B\u308A\u3064\u304F\u3063\u3066\u3044\u308B\u3057\u3001\u73FE\u5728\u306E\u81EA\u5206\u3082\u4E0B\u3089\u306A\u3044\u3082\u306E\u3070\u304B\u308A\u4F5C\u3063\u3066\u308B\u3057\u3001\u5C06\u6765\u306E\u81EA\u5206\u3082\u4E0B\u3089\u306A\u3044\u3082\u306E\u3070\u304B\u308A\u4F5C\u308B\u3060\u308D\u3046",
  "id" : 602481402324594688,
  "created_at" : "2015-05-24 14:28:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602481144794193921",
  "text" : "\u4E3B\u3088\uFF0C\u4EBA\u306E\u98DF\u5F8C\u306E\u7720\u305F\u307F\u3088\uFF0E",
  "id" : 602481144794193921,
  "created_at" : "2015-05-24 14:27:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602481030545678336",
  "text" : "\u5B8C\u5168\u306B\u3042\u30FC\u3063\u3066\u8A00\u3063\u3066\u308B\uFF0E\u3063\u3066\u3044\u3046elisp\u3082\u5206\u3051\u3088\u3046",
  "id" : 602481030545678336,
  "created_at" : "2015-05-24 14:27:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602480959074607105",
  "text" : "\u5B8C\u5168\u306B\u3042\u30FC\u3063\u3066\u8A00\u3063\u3066\u308B\uFF0E",
  "id" : 602480959074607105,
  "created_at" : "2015-05-24 14:27:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602480743139385344",
  "text" : "\u3064\u3044\u306B\u8A2D\u5B9A\u30D5\u30A1\u30A4\u30EB\u304C\u5206\u96E2\u3057\u3066\u3044\u304F\u6642\u304C",
  "id" : 602480743139385344,
  "created_at" : "2015-05-24 14:26:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602480604345737216",
  "text" : "\u30B3\u30DE\u30F3\u30C9\u53E9\u304F\u3068\u300C\u3086\u3086\u5F0F\u300D\u3063\u3066\u3064\u3076\u3084\u3051\u308Belisp\u3069\u3046\u8003\u3048\u3066\u3082\u5206\u96E2\u3057\u305F\u65B9\u304C\u3088\u3044",
  "id" : 602480604345737216,
  "created_at" : "2015-05-24 14:25:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602480313088937986",
  "text" : "\u3086\u3086\u5F0F",
  "id" : 602480313088937986,
  "created_at" : "2015-05-24 14:24:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602477389000495104",
  "text" : "\u3064\u304B\u308C\u305F",
  "id" : 602477389000495104,
  "created_at" : "2015-05-24 14:12:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602474312096964608",
  "text" : "\u304A\u5BFA\u4EBA\u9593\u306F\u4EBA\u306B\u8A71\u3059\u3070\u3063\u304B\u308A\u3067\u4EBA\u306E\u8A71\u3092\u805E\u3051\u306A\u3044\u4EBA\u9593\u304C\u591A\u3044\u3063\u3066\u805E\u3044\u305F\u3051\u3069\u3001\u540C\u696D\u8005\u3068\u3084\u3063\u3066\u3044\u3051\u308B\u6C17\u304C\u3057\u306A\u3044",
  "id" : 602474312096964608,
  "created_at" : "2015-05-24 14:00:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602473823145975808",
  "text" : "\u30AD\u30E7\u30FC\u30C8\u3067\u30DC\u30F3\u30BA\u306B\u306A\u308C\u3070\u3088\u304B\u3063\u305F\u306E\u304B",
  "id" : 602473823145975808,
  "created_at" : "2015-05-24 13:58:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602473753533161473",
  "text" : "RT @haguruma20: \u3048\u3093\u3069\u3055\u3093\u307F\u305F\u3044\u306A\u50E7\u4FB6\u304C\u3044\u305F\u3089\u305D\u306E\u5BFA\u306E\u6A80\u5BB6\u306B\u306A\u3063\u3066\u3082\u826F\u3044\u3068\u601D\u3063\u305F\u3002\u8A71\u4EE3\u3068\u3057\u3066\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601701028031893504",
    "text" : "\u3048\u3093\u3069\u3055\u3093\u307F\u305F\u3044\u306A\u50E7\u4FB6\u304C\u3044\u305F\u3089\u305D\u306E\u5BFA\u306E\u6A80\u5BB6\u306B\u306A\u3063\u3066\u3082\u826F\u3044\u3068\u601D\u3063\u305F\u3002\u8A71\u4EE3\u3068\u3057\u3066\u3002",
    "id" : 601701028031893504,
    "created_at" : "2015-05-22 10:47:58 +0000",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 602473753533161473,
  "created_at" : "2015-05-24 13:58:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602470756438528000",
  "text" : "\u5236\u5EA6\u306E\u629C\u3051\u7A74\u60C5\u5831\u3067\u3059",
  "id" : 602470756438528000,
  "created_at" : "2015-05-24 13:46:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/haguruma20\/status\/602470489739505664\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/86OBUT4Nim",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFxntV7UUAEUNjd.jpg",
      "id_str" : "602470478838517761",
      "id" : 602470478838517761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFxntV7UUAEUNjd.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/86OBUT4Nim"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602470719318937601",
  "text" : "RT @haguruma20: \u5968\u5B66\u91D1\u3001\u672C\u4EBA\u6B7B\u4EA1\u306E\u5834\u5408 http:\/\/t.co\/86OBUT4Nim",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/haguruma20\/status\/602470489739505664\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/86OBUT4Nim",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFxntV7UUAEUNjd.jpg",
        "id_str" : "602470478838517761",
        "id" : 602470478838517761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFxntV7UUAEUNjd.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/86OBUT4Nim"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602470489739505664",
    "text" : "\u5968\u5B66\u91D1\u3001\u672C\u4EBA\u6B7B\u4EA1\u306E\u5834\u5408 http:\/\/t.co\/86OBUT4Nim",
    "id" : 602470489739505664,
    "created_at" : "2015-05-24 13:45:32 +0000",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 602470719318937601,
  "created_at" : "2015-05-24 13:46:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602470386911956992",
  "text" : "\u5371\u967A\u306A\u4E3B\u5F35\u3063\u307D\u3044",
  "id" : 602470386911956992,
  "created_at" : "2015-05-24 13:45:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602470170972397568",
  "geo" : { },
  "id_str" : "602470304808443904",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u571F\u5730\u306B\u672A\u7DF4\u304C\u3042\u308B\u5974\u306F\u4E0D\u52D5\u7523\u5C4B\u3055\u3093\u3068\u304B\u306B\u71B1\u610F\u304C\u4F1D\u308F\u3063\u3066\u5C31\u8077\u51FA\u6765\u308B\u306E\u3067\u81EA\u6BBA\u3057\u305F\u308A\u3057\u306A\u3044",
  "id" : 602470304808443904,
  "in_reply_to_status_id" : 602470170972397568,
  "created_at" : "2015-05-24 13:44:48 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602470164118970368",
  "text" : "\u5968\u5B66\u91D1\u3067\u3053\u306E\u4E16\u306E\u6625\u3092\u8B33\u6B4C\u3057\u305F\u672B\u306B\u81EA\u6BBA\u3063\u3066\u5E78\u305B\u306E\u4E00\u3064\u306E\u5728\u308A\u65B9\u306A\u306E\u3067\u306F",
  "id" : 602470164118970368,
  "created_at" : "2015-05-24 13:44:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602469956815429632",
  "geo" : { },
  "id_str" : "602470041146109952",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u305D\u3046\u306A\u306E\u304B\u3001\u826F\u5FC3\u7684\u306A\u8A2D\u5B9A\u3060",
  "id" : 602470041146109952,
  "in_reply_to_status_id" : 602469956815429632,
  "created_at" : "2015-05-24 13:43:45 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602469961651499009",
  "text" : "\u4ECA\u65E5\u5BC4\u3063\u305F\u30AB\u30E9\u30AA\u30B1\u306E\u30C9\u30EA\u30F3\u30AF\u30D0\u30FC\u3001\u30E1\u30ED\u30F3\u30BD\u30FC\u30C0\u3060\u3051\u58F2\u308A\u5207\u308C\u3066\u305F\u3057\u90A3\u73C2\u3061\u3083\u3093\u306E\u30D5\u30A1\u30F3\u8F9E\u3081\u307E\u3059",
  "id" : 602469961651499009,
  "created_at" : "2015-05-24 13:43:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602469488735334400",
  "geo" : { },
  "id_str" : "602469625054408704",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u5C11\u306A\u304F\u3068\u3082\u5FC3\u6A5F\u4E00\u8EE2\u3057\u3066\u65B0\u3057\u3044\u5834\u3067\u6D3B\u8E8D\u304C\u671F\u5F85\u3067\u304D\u308B",
  "id" : 602469625054408704,
  "in_reply_to_status_id" : 602469488735334400,
  "created_at" : "2015-05-24 13:42:06 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602469412260577280",
  "text" : "\u5968\u5B66\u91D1\u3001\u6B7B\u3093\u3067\u3082\u9023\u5E2F\u4FDD\u8A3C\u4EBA\u3081\u3044\u305F\u5B58\u5728\u306B\u8CA0\u306E\u907A\u7523\u3068\u3057\u3066\u6B8B\u308B\u306E\u3067\u306F",
  "id" : 602469412260577280,
  "created_at" : "2015-05-24 13:41:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u307F\u306A\u3061\u3083\u3093",
      "screen_name" : "rumichang",
      "indices" : [ 0, 10 ],
      "id_str" : "242763253",
      "id" : 242763253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602469147432333313",
  "geo" : { },
  "id_str" : "602469270694440960",
  "in_reply_to_user_id" : 242763253,
  "text" : "@rumichang \u501F\u308A\u3068\u3051\u3070\u3088\u304B\u3063\u305F\u3067\u3059\u304B\u306D(?)",
  "id" : 602469270694440960,
  "in_reply_to_status_id" : 602469147432333313,
  "created_at" : "2015-05-24 13:40:42 +0000",
  "in_reply_to_screen_name" : "rumichang",
  "in_reply_to_user_id_str" : "242763253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@75.9kg",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602469034697695233",
  "geo" : { },
  "id_str" : "602469155560820736",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u6B7B\u4EA1\u52D5\u6A5F\u304C\u3069\u3046\u3042\u308C\u6B7B\u4EA1\u306F\u6B7B\u4EA1\u3067\u3059",
  "id" : 602469155560820736,
  "in_reply_to_status_id" : 602469034697695233,
  "created_at" : "2015-05-24 13:40:14 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602468900488421376",
  "text" : "\u5C31\u6D3B\u306F\u6B7B\u306B\u3088\u3063\u3066\u5373\u5EA7\u306B\u7D42\u3048\u3089\u308C\u308B\u3068\u3044\u3046\u4E8B\u5B9F\u306F\u610F\u5916\u306B\u77E5\u3089\u308C\u3066\u3044\u306A\u3044",
  "id" : 602468900488421376,
  "created_at" : "2015-05-24 13:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602468694581620736",
  "geo" : { },
  "id_str" : "602468773921034240",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u3044\u3064\u3067\u3082\u7D42\u308F\u308C\u308B\u3067\u3042\u308D\uFF1F",
  "id" : 602468773921034240,
  "in_reply_to_status_id" : 602468694581620736,
  "created_at" : "2015-05-24 13:38:43 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602468004132040705",
  "text" : "\u3042\u304A\u3048\u3046\u3044\u3055\u3093\u300Cemacs\u306E\u8A2D\u5B9A\u30D5\u30A1\u30A4\u30EB\u5F04\u308B\u306E\u304C\u597D\u304D\u3063\u3066\u3053\u3068\u306Flisp\u304C\u597D\u304D\u3063\u3066\u3053\u3068\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u904E\u5EA6\u306A\u4E00\u822C\u5316\u3060\u2026\u300D",
  "id" : 602468004132040705,
  "created_at" : "2015-05-24 13:35:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602449984479309826",
  "text" : "\u3053\u3058\u3093\u3067\u3042\u304F\u307E\u306E\u304B\u3093\u305D\u3046\u3067\u3059",
  "id" : 602449984479309826,
  "created_at" : "2015-05-24 12:24:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602413837749329921",
  "text" : "\u3042\u304F\u307E\u3067\u3053\u3058\u3093\u306E\u304B\u3093\u305D\u3046\u3067\u3059",
  "id" : 602413837749329921,
  "created_at" : "2015-05-24 10:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602413805058924544",
  "text" : "DAM\u306E\u6B4C\u3063\u3066\u306A\u3044\u6642\u306E\u6620\u50CF\u306B\u30CA\u30F3\u30B8\u30E7\u30EB\u30CE\u51FA\u3066\u304D\u3066\u5973\u512A\u3055\u3093\u3068\u304A\u558B\u308A\u3057\u3066\u308B\u3093\u3060\u3051\u3069\u3001\u4F4F\u3080\u4E16\u754C\u306E\u9055\u3044\u307F\u305F\u3044\u306A\u3082\u306E\u304C\u6F0F\u308C\u51FA\u3066\u3066\u3061\u3087\u3063\u3068\u9762\u767D\u3044",
  "id" : 602413805058924544,
  "created_at" : "2015-05-24 10:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602358516414685185",
  "text" : "\u9593\u306B\u5408\u308F\u306A\u3044\u9854 of the year",
  "id" : 602358516414685185,
  "created_at" : "2015-05-24 06:20:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602350421517078529",
  "text" : "\u30D7\u30E9\u30E2\u5C4B\u3055\u3093\u773A\u3081\u3066\u305F\u3001(\u5411\u304B\u308F\u306A\u3044\u3068\u9593\u306B\u5408\u308F\u306A\u3044)",
  "id" : 602350421517078529,
  "created_at" : "2015-05-24 05:48:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/602349429299945472\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/BHshk8VXth",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFv5nJWVEAAs3_q.jpg",
      "id_str" : "602349426103881728",
      "id" : 602349426103881728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFv5nJWVEAAs3_q.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/BHshk8VXth"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602349429299945472",
  "text" : "\u3053\u3063\u3061\u306E\u65B9\u304C\u30D4\u30F3\u3068(?)\u304F\u308B http:\/\/t.co\/BHshk8VXth",
  "id" : 602349429299945472,
  "created_at" : "2015-05-24 05:44:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/602348762044833793\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/KVXxYprFBB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFv5AR7UMAIh7xZ.jpg",
      "id_str" : "602348758391599106",
      "id" : 602348758391599106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFv5AR7UMAIh7xZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/KVXxYprFBB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602348762044833793",
  "text" : "\u5909\u306A\u611F\u899A\u3060 http:\/\/t.co\/KVXxYprFBB",
  "id" : 602348762044833793,
  "created_at" : "2015-05-24 05:41:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602318977117753345",
  "text" : "\u3084\u3081\u3066\u304F\u3060\u3055\u30FC\u3044\uFF014\u56DE\u307B\u3069\u898B\u307E\u3057\u305F\u3041\uFF01",
  "id" : 602318977117753345,
  "created_at" : "2015-05-24 03:43:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC \u30D5\u30ED\u30E0\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3",
      "screen_name" : "NJSLYR_anime",
      "indices" : [ 3, 16 ],
      "id_str" : "2993099502",
      "id" : 2993099502
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NJSLYR_anime\/status\/602141919305568257\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Wis1y8tRm7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFs837uUgAAbaR9.jpg",
      "id_str" : "602141906806538240",
      "id" : 602141906806538240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFs837uUgAAbaR9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Wis1y8tRm7"
    } ],
    "hashtags" : [ {
      "text" : "\u5FCD\u6BBA\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HvH2nHHw8v",
      "expanded_url" : "http:\/\/www.nicovideo.jp\/watch\/1432005497",
      "display_url" : "nicovideo.jp\/watch\/14320054\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602318918108065792",
  "text" : "RT @NJSLYR_anime: \u300E\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC \u30D5\u30ED\u30E0\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3\u300F\u7B2C6\u8A71\u3054\u89A7\u306B\u306A\u3089\u308C\u307E\u3057\u305F\u304B(^^)\uFF1F\uFF1F...\u307E\u3060\u3067\u3059\u304B\uFF1F...1\u56DE\u89B3\u305F\uFF1F..1\u56DE\u3057\u304B\u89B3\u3066\u306A\u3044\uFF1F...\u6B21\u306F\u7686\u3055\u3093\u306E\u4E2D\u6307\u3092...http:\/\/t.co\/HvH2nHHw8v #\u5FCD\u6BBA\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NJSLYR_anime\/status\/602141919305568257\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Wis1y8tRm7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFs837uUgAAbaR9.jpg",
        "id_str" : "602141906806538240",
        "id" : 602141906806538240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFs837uUgAAbaR9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Wis1y8tRm7"
      } ],
      "hashtags" : [ {
        "text" : "\u5FCD\u6BBA\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/HvH2nHHw8v",
        "expanded_url" : "http:\/\/www.nicovideo.jp\/watch\/1432005497",
        "display_url" : "nicovideo.jp\/watch\/14320054\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602141919305568257",
    "text" : "\u300E\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC \u30D5\u30ED\u30E0\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3\u300F\u7B2C6\u8A71\u3054\u89A7\u306B\u306A\u3089\u308C\u307E\u3057\u305F\u304B(^^)\uFF1F\uFF1F...\u307E\u3060\u3067\u3059\u304B\uFF1F...1\u56DE\u89B3\u305F\uFF1F..1\u56DE\u3057\u304B\u89B3\u3066\u306A\u3044\uFF1F...\u6B21\u306F\u7686\u3055\u3093\u306E\u4E2D\u6307\u3092...http:\/\/t.co\/HvH2nHHw8v #\u5FCD\u6BBA\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3 http:\/\/t.co\/Wis1y8tRm7",
    "id" : 602141919305568257,
    "created_at" : "2015-05-23 15:59:55 +0000",
    "user" : {
      "name" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC \u30D5\u30ED\u30E0\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3",
      "screen_name" : "NJSLYR_anime",
      "protected" : false,
      "id_str" : "2993099502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573324772756480000\/2DCDbuM4_normal.jpeg",
      "id" : 2993099502,
      "verified" : false
    }
  },
  "id" : 602318918108065792,
  "created_at" : "2015-05-24 03:43:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602262994899206144",
  "text" : "\u53CB\u4EBAA\u300C\u305D\u3053\u8D70\u3063\u3066\u308B\u30D5\u30A7\u30E9\u30FC\u30EA\u4F55cc?\u300D\n\u53CB\u4EBAB\u300C3600\u3058\u3083\u306A\u3044\u304B\u306A\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3058\u3083\u304250cc\u306E\u539F\u4ED8\u3092\u2026\u300D\n\u53CB\u4EBA\u300C\u300C\uFF1F\u300D\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C72\u53F0\u96C6\u3081\u308C\u3070\u4E92\u89D2\u3060\u306A\u3002\u6570\u306E\u66B4\u529B\u3002\u300D",
  "id" : 602262994899206144,
  "created_at" : "2015-05-24 00:01:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601972260161728512",
  "text" : "\u6A5F\u5185\u30E2\u30FC\u30C9\u3001\u8D77\u52D5",
  "id" : 601972260161728512,
  "created_at" : "2015-05-23 04:45:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601969764051783680",
  "text" : "\u274Csystem engineer\n\u2B55\uFE0Fsound effect",
  "id" : 601969764051783680,
  "created_at" : "2015-05-23 04:35:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601969496144805888",
  "text" : "SE",
  "id" : 601969496144805888,
  "created_at" : "2015-05-23 04:34:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601969228564996096",
  "text" : "\u3077\u304D\u3085\u3077\u304D\u3085\u8A00\u3046\u304D\u308A\u3093\u306E\u9774",
  "id" : 601969228564996096,
  "created_at" : "2015-05-23 04:33:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601969177125998592",
  "text" : "\u8089\u30D0\u30C3\u30AF\u306E\u5546\u54C1\u5316\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B",
  "id" : 601969177125998592,
  "created_at" : "2015-05-23 04:33:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TV\u30A2\u30CB\u30E1\u300C\u5E78\u8179\u30B0\u30E9\u30D5\u30A3\u30C6\u30A3\u300D",
      "screen_name" : "koufuku_g",
      "indices" : [ 3, 13 ],
      "id_str" : "2570874193",
      "id" : 2570874193
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/koufuku_g\/status\/601968811332374529\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/NvFBF8SMuY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFnd8jiXIAAX2gY.jpg",
      "id_str" : "601756057631924224",
      "id" : 601756057631924224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFnd8jiXIAAX2gY.jpg",
      "sizes" : [ {
        "h" : 247,
        "resize" : "fit",
        "w" : 362
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 362
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 362
      } ],
      "display_url" : "pic.twitter.com\/NvFBF8SMuY"
    } ],
    "hashtags" : [ {
      "text" : "koufukug",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601969114379227137",
  "text" : "RT @koufuku_g: \u3010\u307D\u304B\u307D\u304B\u796D\u308A\u30B0\u30C3\u30BA5\u3011\u304D\u308A\u3093\u306E\u8089\u30D0\u30C3\u30B0\uFF0F8,800\u5186\uFF08\u7A0E\u8FBC\uFF09\u2605\u672C\u7DE8\u3067\u304D\u308A\u3093\u304C\u6301\u3063\u3066\u3044\u305F\u8089\u30D0\u30C3\u30B0\u3092\u518D\u73FE\uFF01\u7537\u6027\u304C\u6301\u3063\u3066\u3082\u4F7F\u3044\u3084\u3059\u3044\u3001\u5E4550cm\u00D7\u76F4\u5F8426cm\u306E\u30D3\u30C3\u30B0\u30B5\u30A4\u30BA\uFF01\u8377\u7269\u3092\u307E\u3068\u3081\u3066\u5165\u308C\u3089\u308C\u307E\u3059 #koufukug http:\/\/t.co\/NvF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/koufuku_g\/status\/601968811332374529\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/NvFBF8SMuY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFnd8jiXIAAX2gY.jpg",
        "id_str" : "601756057631924224",
        "id" : 601756057631924224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFnd8jiXIAAX2gY.jpg",
        "sizes" : [ {
          "h" : 247,
          "resize" : "fit",
          "w" : 362
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 362
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 362
        } ],
        "display_url" : "pic.twitter.com\/NvFBF8SMuY"
      } ],
      "hashtags" : [ {
        "text" : "koufukug",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601968811332374529",
    "text" : "\u3010\u307D\u304B\u307D\u304B\u796D\u308A\u30B0\u30C3\u30BA5\u3011\u304D\u308A\u3093\u306E\u8089\u30D0\u30C3\u30B0\uFF0F8,800\u5186\uFF08\u7A0E\u8FBC\uFF09\u2605\u672C\u7DE8\u3067\u304D\u308A\u3093\u304C\u6301\u3063\u3066\u3044\u305F\u8089\u30D0\u30C3\u30B0\u3092\u518D\u73FE\uFF01\u7537\u6027\u304C\u6301\u3063\u3066\u3082\u4F7F\u3044\u3084\u3059\u3044\u3001\u5E4550cm\u00D7\u76F4\u5F8426cm\u306E\u30D3\u30C3\u30B0\u30B5\u30A4\u30BA\uFF01\u8377\u7269\u3092\u307E\u3068\u3081\u3066\u5165\u308C\u3089\u308C\u307E\u3059 #koufukug http:\/\/t.co\/NvFBF8SMuY",
    "id" : 601968811332374529,
    "created_at" : "2015-05-23 04:32:03 +0000",
    "user" : {
      "name" : "TV\u30A2\u30CB\u30E1\u300C\u5E78\u8179\u30B0\u30E9\u30D5\u30A3\u30C6\u30A3\u300D",
      "screen_name" : "koufuku_g",
      "protected" : false,
      "id_str" : "2570874193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489062683409281024\/vOhgFElc_normal.jpeg",
      "id" : 2570874193,
      "verified" : false
    }
  },
  "id" : 601969114379227137,
  "created_at" : "2015-05-23 04:33:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601969012445065216",
  "text" : "\u5168\u7136\u95A2\u4FC2\u306A\u3044\u4FBF\u306E\u547C\u3073\u51FA\u3057\u30A2\u30CA\u30A6\u30F3\u30B9\u3060\u3051\u3069\u9060\u85E4\u306A\u3093\u3068\u304B\u69D8\u304C\u547C\u3073\u51FA\u3055\u308C\u3066\u30C9\u30AD\u30C3\u3068\u3059\u308B\u306A\u3069",
  "id" : 601969012445065216,
  "created_at" : "2015-05-23 04:32:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601967419024756736",
  "text" : "hoge\u5B66\u90E8\u3068\u304B\u8981\u3089\u306A\u304F\u306D\uFF1F\u3063\u3066\u3044\u3046\u5974\u3001\u713C\u304D\u305D\u3070\u306F\u30BD\u30FC\u30B9\u5473\u4EE5\u5916\u8981\u3089\u306A\u3044\u3068\u304B\u30E9\u30FC\u30E1\u30F3\u306F\u91A4\u6CB9\u4EE5\u5916\u8981\u3089\u306A\u3044\u3068\u304B\u8A00\u3044\u51FA\u3057\u305D\u3046",
  "id" : 601967419024756736,
  "created_at" : "2015-05-23 04:26:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601955974279077889",
  "text" : "\u305F\u3053\u3084\u304Dmgmg",
  "id" : 601955974279077889,
  "created_at" : "2015-05-23 03:41:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601942595640512512",
  "text" : "\u305D\u308C\u3001\u304C\u629C\u3051\u305F",
  "id" : 601942595640512512,
  "created_at" : "2015-05-23 02:47:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601931659840135168",
  "geo" : { },
  "id_str" : "601942465684242433",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u305F\u3076\u3093\u306F\u671D\u3058\u3083\u306A\u304F\u3066\u6BCD\u3060\u3088\u305D\u308C",
  "id" : 601942465684242433,
  "in_reply_to_status_id" : 601931659840135168,
  "created_at" : "2015-05-23 02:47:22 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u3063\u3077\u3059\uFF1D\u3080\u304E\u3085\u305F\u3093",
      "screen_name" : "Pappus_Mugyutan",
      "indices" : [ 0, 16 ],
      "id_str" : "2423639766",
      "id" : 2423639766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601650690511929344",
  "geo" : { },
  "id_str" : "601650820283637760",
  "in_reply_to_user_id" : 2423639766,
  "text" : "@Pappus_Mugyutan \u304A\u3061\u3064\u3051",
  "id" : 601650820283637760,
  "in_reply_to_status_id" : 601650690511929344,
  "created_at" : "2015-05-22 07:28:28 +0000",
  "in_reply_to_screen_name" : "Pappus_Mugyutan",
  "in_reply_to_user_id_str" : "2423639766",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601649746759942144",
  "text" : "3\u670817\u65E5\u4EE5\u6765\u98F2\u3093\u3067\u306A\u3044\u6A21\u69D8",
  "id" : 601649746759942144,
  "created_at" : "2015-05-22 07:24:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601649522138218497",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 601649522138218497,
  "created_at" : "2015-05-22 07:23:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601649463510183936",
  "text" : "\u4E94\u5104\u5E74\u3076\u308A\u306E\u30FC",
  "id" : 601649463510183936,
  "created_at" : "2015-05-22 07:23:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/eIC8iIBS3v",
      "expanded_url" : "http:\/\/mixi.jp\/view_bbs.pl?comm_id=567831&id=48458768",
      "display_url" : "mixi.jp\/view_bbs.pl?co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601589362074132480",
  "text" : "\u3010\u30B9\u30FC\u30D7\u3011\u6D17\u3046\u524D\u306E\u30AB\u30EC\u30FC\u934B\u3067\u30B9\u30FC\u30D7\u30AB\u30EC\u30FC\u30D1\u30B9\u30BF\uFF01 http:\/\/t.co\/eIC8iIBS3v\n\n\u30DF\u30AF\u30B7\u30A3\u3068\u304B\u3044\u3046\u53E4\u4EE3\u907A\u8DE1\u306B\u523B\u307E\u308C\u305F\u30C9\u30AD\u30E5\u30E1\u30F3\u30C8",
  "id" : 601589362074132480,
  "created_at" : "2015-05-22 03:24:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601589219367063552",
  "text" : "\u30AB\u30EC\u30FC\u30B9\u30FC\u30D7\u30D1\u30B9\u30BF\u306A",
  "id" : 601589219367063552,
  "created_at" : "2015-05-22 03:23:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601423486934876160",
  "text" : "\u4FFA\u306F\u5BDD\u305F\u3044\u3060\u3051\u5BDD\u308B\u305E\u30FC\u30C3\uFF01\u30B8\u30E7\u30B8\u30E7\u30FC\u30A9\uFF01",
  "id" : 601423486934876160,
  "created_at" : "2015-05-21 16:25:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601422793247301633",
  "text" : "\u30C6\u30F3\u30B7\u30E7\u30F3\u4E0A\u304C\u308B\u5973\u306E\u5B50\u306E\u53EF\u611B\u3055",
  "id" : 601422793247301633,
  "created_at" : "2015-05-21 16:22:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601422634350350336",
  "text" : "\u7E88\u3082\u30C6\u30F3\u30B7\u30E7\u30F3\u306E\u4E0A\u304C\u308A\u65B9\u304C\u826F\u3044\u3088\u306A\u3041\u3001\u30D7\u30E9\u30E2\u5C4B\u306E\u30B7\u30FC\u30F3\u306A\u304B\u3063\u305F\u3089\u7E88\u306E\u5370\u8C61\u9055\u3063\u305F\u3088\u306A\u3041",
  "id" : 601422634350350336,
  "created_at" : "2015-05-21 16:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601418931845271553",
  "geo" : { },
  "id_str" : "601419017136418817",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u6B7B\u3093\u3067\u3082\u8FD4\u3055\u306A\u3044\u3068\u7D04\u675F\u3057\u305F\u2026\uFF01",
  "id" : 601419017136418817,
  "in_reply_to_status_id" : 601418931845271553,
  "created_at" : "2015-05-21 16:07:22 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601417660266467328",
  "text" : "\u30AD\u30E5\u30C3\u30AD\u30E5\u30C3",
  "id" : 601417660266467328,
  "created_at" : "2015-05-21 16:01:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601417583103901698",
  "text" : "\u3064\u3080\u304E\u62B1\u304D\u6795\u3001\u6771\u4E9E\u91CD\u5DE5\u3068\u304B\u3067\u4F5C\u3063\u3066\u304F\u308C\u306A\u3044\u304B\u306A\u3002\u6C34\u7B52\u3068\u304B\u3081\u3063\u3061\u3083\u96F0\u56F2\u6C17\u51FA\u3066\u305F\u3082\u3093\u306A\u3041\u3002",
  "id" : 601417583103901698,
  "created_at" : "2015-05-21 16:01:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601417236813754368",
  "text" : "\u305D\u3082\u305D\u3082\u3042\u306E\u4E0D\u52D5\u7523\u5C4B\u3055\u3093\u3061\u3087\u3063\u3068\u3057\u305F\u30B5\u30FC\u30D3\u30B9\u30B7\u30FC\u30F3\u304C\u3042\u308B\u3060\u3051\u306E\u30E2\u30D6\u306A\u306F\u305A\u306A\u306E\u306B\u3081\u3063\u3061\u3083\u826F\u3044\u30DD\u30B8\u30B7\u30E7\u30F3\u3060\u306A",
  "id" : 601417236813754368,
  "created_at" : "2015-05-21 16:00:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601417002738065409",
  "text" : "\u4F55\u76EE\u7DDA\u3060\u3088\u3063\u3066\u611F\u3058\u3060\u3051\u3069\u4E95\u53E3\u3001\u524D\u3088\u308A\u6F14\u6280\u304C\u826F\u304F\u306A\u3063\u305F\u6C17\u304C\u3059\u308B",
  "id" : 601417002738065409,
  "created_at" : "2015-05-21 15:59:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601416040568860672",
  "geo" : { },
  "id_str" : "601416264951599104",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u4E07\u4E00\u671D\u6B7B\u4F53\u3067\u767A\u898B\u3055\u308C\u305F\u3089\u4F8B\u306E\u3082\u306E\u306F\u8FD4\u305B\u306A\u3044\u306A",
  "id" : 601416264951599104,
  "in_reply_to_status_id" : 601416040568860672,
  "created_at" : "2015-05-21 15:56:25 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601414560164093954",
  "text" : "\u53D7\u3051\u306A\u3044",
  "id" : 601414560164093954,
  "created_at" : "2015-05-21 15:49:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601414544750030850",
  "text" : "\u306A\u3093\u3067\u304A\u98A8\u5442\u3067\u8EE2\u3093\u3067\u308B\u3093\u3060\u53D7\u3063\u3051\u308B\u301C",
  "id" : 601414544750030850,
  "created_at" : "2015-05-21 15:49:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601414364759916544",
  "text" : "\u4E45\u3005\u306B\u606F\u304C\u6B62\u307E\u308B\u304F\u3089\u3044\u306B\u306F\u75DB\u304B\u3063\u305F\u304C\u5CE0\u3092\u8D8A\u3048\u305F\u3089\u9006\u306B\u7B11\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 601414364759916544,
  "created_at" : "2015-05-21 15:48:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601414156026130433",
  "text" : "\u304A\u98A8\u5442\u306E\u5165\u308A\u53E3\u306E\u6BB5\u5DEE\u306B\u8DB3\u3092\u5F15\u3063\u639B\u3051\u3066\u819D\u3092\u5E8A\u306B\u3001\u9CE9\u5C3E\u3092\u6D74\u69FD\u306B\u8EFD\u304F\u6253\u3061\u307E\u3057\u305F\u2606",
  "id" : 601414156026130433,
  "created_at" : "2015-05-21 15:48:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601413973871759360",
  "text" : "\u4E94\u5104\u5E74\u3076\u308A\u306B\u201C\u8EE2\u3076\u201C\u3068\u3044\u3046\u30A4\u30D9\u30F3\u30C8\u304C\u767A\u751F\u3057\u305F",
  "id" : 601413973871759360,
  "created_at" : "2015-05-21 15:47:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601409978226774017",
  "geo" : { },
  "id_str" : "601410101933527040",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u3046\u3080\u2026\u305D\u3046\u306A\u3093\u3060\u3088\u306A\u2026",
  "id" : 601410101933527040,
  "in_reply_to_status_id" : 601409978226774017,
  "created_at" : "2015-05-21 15:31:56 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601409512189202434",
  "geo" : { },
  "id_str" : "601409633282985984",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u8AB0\u304B\u306B\u501F\u308A\u3066\u5168\u90E8\u30B3\u30D4\u30FC\u3059\u308C\u3070\u307E\u3041",
  "id" : 601409633282985984,
  "in_reply_to_status_id" : 601409512189202434,
  "created_at" : "2015-05-21 15:30:04 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601409570632638464",
  "text" : "\u3064\u3080\u304E\u62B1\u304D\u307E\u304F\u3089\u3042\u3063\u305F\u3089\u8CB7\u3063\u3066\u3057\u307E\u3044\u305D\u3046\u3060\u3001\u5F62\u72B6\u3082\u305D\u3093\u306A\u611F\u3058\u3060\u3057",
  "id" : 601409570632638464,
  "created_at" : "2015-05-21 15:29:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601409489833631744",
  "text" : "\u3042\u3068\u3064\u3080\u304E\u3068\u306E\u638C\u4F4D\u8A13\u7DF4\u3082\u304B\u3063\u3061\u3087\u826F\u304B\u3063\u305F\u3057\u3046\u3049\u30A9\u30F3\uFF01",
  "id" : 601409489833631744,
  "created_at" : "2015-05-21 15:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601409080943476736",
  "geo" : { },
  "id_str" : "601409347751542784",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u3057\u305F\u3044\u306D",
  "id" : 601409347751542784,
  "in_reply_to_status_id" : 601409080943476736,
  "created_at" : "2015-05-21 15:28:56 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601409306295054336",
  "text" : "\u30B7\u30C9\u30CB\u30A26\u8A71\u3001\u4E0D\u52D5\u7523\u5C4B\u3055\u3093\u306E\u5927\u4EBA\u3057\u3044\u611F\u3058\u304B\u3089\u3058\u308F\u3058\u308F\u30C6\u30F3\u30B7\u30E7\u30F3\u4E0A\u304C\u308B\u611F\u3058\u3081\u3063\u3061\u3087\u53EF\u611B\u304B\u3063\u305F\u3057\u3001\u7E88\u3068\u30D7\u30E9\u30E2\u5C4B\u306E\u300C\u300C\u3053\u306E\u5175\u5668\u306B\u8CAB\u901A\u3067\u304D\u306A\u3044\u3082\u306E\u306F\u306A\u3044\uFF01\u300D\u300D\u3082\u3081\u3063\u3061\u3087\u826F\u304B\u3063\u305F\u3057\u3001\u3064\u3080\u304E\u306E\u300C\u4E00\u7DD2\u306B\u5BDD\u3066\u3082\u826F\u3044\u3067\u3059\u304B\uFF1F\u300D\u3082\u3081\u3063\u3061\u3087\u826F\u304B\u3063\u305F\u3057\u3001\u30A4\u30B6\u30CA\u306E\u9854\u82B8\u3082\u3081\u3063\u3061\u3087\u826F\u304B\u3063\u305F\u3057\u3081\u3063\u3061\u3087\u826F\u304B\u3063\u305F",
  "id" : 601409306295054336,
  "created_at" : "2015-05-21 15:28:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601401968339255297",
  "text" : "\u3068\u3044\u3046\u304BOP\u306E\u6620\u50CF\u306F\u30DC\u30FC\u30F3\u30A4\u30F3\u30D6\u30E9\u30C3\u30AF\u306A\u3093\u3060\u306A",
  "id" : 601401968339255297,
  "created_at" : "2015-05-21 14:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601394588796854272",
  "text" : "\u30B5\u30D7\u30E9\u30A4\u30BA\u30C9\u30C9\u30FC\u30B8\u30E7\u30FC\u3001\u3042\u3041\u826F\u3044\u2026\u9065\u304B\u306B\u826F\u3044\u3067\u3059",
  "id" : 601394588796854272,
  "created_at" : "2015-05-21 14:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601386838729695232",
  "geo" : { },
  "id_str" : "601390598617059328",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u4ECA\u5EA6\u884C\u3063\u3066\u307F\u308B\u308F",
  "id" : 601390598617059328,
  "in_reply_to_status_id" : 601386838729695232,
  "created_at" : "2015-05-21 14:14:26 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601384027182931969",
  "text" : "\u786C\u3044\u30D1\u30F3\u3068\u304B\u30D1\u30A4\u751F\u5730\u7CFB\u306E\u83D3\u5B50\u30D1\u30F3\u3068\u304B\u5F37\u3044\u304A\u5E97\u306A\u3044\u304B\u306A\u30FC",
  "id" : 601384027182931969,
  "created_at" : "2015-05-21 13:48:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601383691672166400",
  "geo" : { },
  "id_str" : "601383934513979392",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u3042\u3001\u3042\u305D\u3053\u306E\u30D1\u30F3\u306F\u7D50\u69CB\u7F8E\u5473\u3057\u3044\u3068\u601D\u3046\u3002\u305F\u3060\u5168\u4F53\u7684\u306B\u67D4\u3089\u304B\u3044\u30A4\u30E1\u30FC\u30B8\u3002",
  "id" : 601383934513979392,
  "in_reply_to_status_id" : 601383691672166400,
  "created_at" : "2015-05-21 13:47:57 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601383626270330880",
  "text" : "\u4EAC\u90FD\u304C\u30D1\u30F3\u7684\u74B0\u5883\u3068\u3057\u3066\u306F\u6700\u9AD8\u3060\u3063\u305F\u3084\u306A\u3063\u3066",
  "id" : 601383626270330880,
  "created_at" : "2015-05-21 13:46:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601383568175009792",
  "text" : "\u672D\u5E4C\u306E\u7F8E\u5473\u3057\u3044\u30D1\u30F3\u5C4B\u3055\u3093\u3001\u672A\u3060\u7D0D\u5F97\u306E\u3044\u304F\u3082\u306E\u304C\u898B\u3064\u304B\u3063\u3066\u306A\u3044",
  "id" : 601383568175009792,
  "created_at" : "2015-05-21 13:46:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601383091500818432",
  "text" : "\u672C\u5F53\u306E\u610F\u5473\u3067\u898B\u305F\u3044\u3082\u306E\u3057\u304B\u898B\u306A\u3044\u4EBA\u3001\u672C\u5F53\u306B\u610F\u5473\u3067\u5384\u4ECB",
  "id" : 601383091500818432,
  "created_at" : "2015-05-21 13:44:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601382675329392643",
  "text" : "\u7406\u60F3\u3068\u73FE\u5B9F\u306E\u30AE\u30E3\u30C3\u30D7\u306B\u82E6\u3057\u3080\u4EBA\u306F\u305F\u3076\u3093\u307E\u3068\u3082\u3067\u3001\u672C\u5F53\u306B\u304A\u304B\u3057\u3044\u4EBA\u306F\u7406\u60F3\u3068\u73FE\u5B9F\u306E\u30AE\u30E3\u30C3\u30D7\u3092\u53D7\u3051\u5165\u308C\u3089\u308C\u306A\u3044\u3093\u3060\u306A\u3063\u3066",
  "id" : 601382675329392643,
  "created_at" : "2015-05-21 13:42:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601371960841351168",
  "geo" : { },
  "id_str" : "601372074733604864",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u3048\u3048\u3093\u3084\u3067",
  "id" : 601372074733604864,
  "in_reply_to_status_id" : 601371960841351168,
  "created_at" : "2015-05-21 13:00:50 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601338282056622081",
  "geo" : { },
  "id_str" : "601338378697715712",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u30AA\u30B9\u30C8\u30FC\u30AF\u306E\u97FF",
  "id" : 601338378697715712,
  "in_reply_to_status_id" : 601338282056622081,
  "created_at" : "2015-05-21 10:46:56 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601338219964276736",
  "text" : "\u30B7\u30FC\u30D5\u30FC\u30FB\u30C9\u30C9\u30EA\u30A2\u3068\u304B\u3082\u6709\u540D\u306A",
  "id" : 601338219964276736,
  "created_at" : "2015-05-21 10:46:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601338023394021377",
  "text" : "\u30B7\u30EB\u30D9\u30FB\u30B9\u30BF\u30B9\u30BF\u30ED\u30FC\u30F3\u307B\u3069\u9762\u767D\u304F\u306F\u306A\u3044",
  "id" : 601338023394021377,
  "created_at" : "2015-05-21 10:45:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/601337801628590080\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/9PnDkfSsJA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFhheh1WAAA9EIX.png",
      "id_str" : "601337727360040960",
      "id" : 601337727360040960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFhheh1WAAA9EIX.png",
      "sizes" : [ {
        "h" : 387,
        "resize" : "fit",
        "w" : 522
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 522
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 522
      } ],
      "display_url" : "pic.twitter.com\/9PnDkfSsJA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601337801628590080",
  "text" : "\u305D\u3046\u3044\u3046\u540D\u524D\u306E\u30AD\u30E3\u30E9\u304C\u3044\u308B\u306E\u304B\u77E5\u3089\u3093\u304C\u4F55\u306F\u3068\u3082\u3042\u308Cr4s\u306A http:\/\/t.co\/9PnDkfSsJA",
  "id" : 601337801628590080,
  "created_at" : "2015-05-21 10:44:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601337304536461312",
  "text" : "\u306A\u305C\u305D\u3046\u601D\u3063\u3066\u3044\u305F\u306E\u304B\u306F\u4E0D\u660E\u3060\u3057\u306C\u304A\u30FC\u3093\u3063",
  "id" : 601337304536461312,
  "created_at" : "2015-05-21 10:42:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601337215722135552",
  "text" : "\u30ED\u30FC\u30EB\u30B9\u30ED\u30A4\u30B9\u3063\u3066\u3001\u30ED\u30FC\u30EB\u30B9\u30FB\u30ED\u30A4\u30B9\u306A\u306E\uFF1F\u30ED\u30FC\u30EB\u30FB\u30B9\u30ED\u30A4\u30B9\u3060\u3068\u3070\u304B\u308A\u601D\u3063\u3066\u3044\u305F",
  "id" : 601337215722135552,
  "created_at" : "2015-05-21 10:42:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601336610379071488",
  "text" : "\u3054\u3081\u3093\u306A\u3055\u3044\u304C\u8A00\u3048\u306A\u3044\u4EBA\u9593\u3063\u3066\u5B58\u5728\u3059\u308B\u304B\u3089\u306A",
  "id" : 601336610379071488,
  "created_at" : "2015-05-21 10:39:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601330599123488768",
  "text" : "\u9AEA\u5207\u3063\u305F",
  "id" : 601330599123488768,
  "created_at" : "2015-05-21 10:16:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601287121576538112",
  "text" : "\u305D\u3093\u306A\u4E00\u65B9\u901A\u884C\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u3092\u3059\u308B\u4EBA\u4E8B\u306E\u3044\u308B\u4F1A\u793E\u306B\u306F\u5165\u308A\u305F\u304F\u306A\u3044\u305E\u3044",
  "id" : 601287121576538112,
  "created_at" : "2015-05-21 07:23:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601287040769118208",
  "text" : "\u9762\u63A5\u30CD\u30BF\u3002\u5F53\u4E8B\u8005\u3060\u304B\u3089\u304B\u77E5\u3089\u3093\u3051\u3069\u307E\u3063\u305F\u304F\u9762\u767D\u3044\u3068\u601D\u3048\u3093\u3002",
  "id" : 601287040769118208,
  "created_at" : "2015-05-21 07:22:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601283410745786368",
  "text" : "\u304B\u307F\u304D\u308B",
  "id" : 601283410745786368,
  "created_at" : "2015-05-21 07:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601055378223140865",
  "text" : "\u3060\u304B\u3089\u57CB\u3081\u7ACB\u3066\u3066\u3057\u307E\u3063\u3066\u30CD\u30AA\u30A2\u30AA\u30E2\u30EA\u306B\u3057\u3066\u3057\u307E\u3048\u3070\u826F\u3044\u306E\u3067\u306F\u306A\u3044\u304B\u3068",
  "id" : 601055378223140865,
  "created_at" : "2015-05-20 16:02:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601055287399817216",
  "text" : "\u5317\u6D77\u9053\u3068\u672C\u5DDE\u306E\u9593\u306B\u3042\u308B\u6D77\u3001\u3053\u308C\u304C\u5927\u304D\u306A\u969C\u5BB3",
  "id" : 601055287399817216,
  "created_at" : "2015-05-20 16:02:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601054960394969088",
  "text" : "\u6642\u9593\u7684\u306A\u30A2\u30EC\u3082\u3042\u308B\u3051\u3069\u3082\u3001\u4EBA\u7684\u74B0\u5883\u306A",
  "id" : 601054960394969088,
  "created_at" : "2015-05-20 16:00:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601054892866711552",
  "text" : "\u6700\u8FD1\u306B\u306A\u3063\u3066\u3088\u3046\u3084\u304F\u30CF\u30FC\u30C9\u306A(?)SF\u3092\u8AAD\u3080\u3088\u3046\u306B\u306A\u3063\u305F\u3051\u3069\u3001\u3069\u3046\u8003\u3048\u3066\u3082\u5B66\u90E8\u306E\u9803\u306B\u3084\u3063\u3066\u304A\u304F\u3079\u304D\u3060\u3063\u305F",
  "id" : 601054892866711552,
  "created_at" : "2015-05-20 16:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tominaga",
      "screen_name" : "masayotominaga",
      "indices" : [ 0, 15 ],
      "id_str" : "1960900880",
      "id" : 1960900880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601051984041410560",
  "geo" : { },
  "id_str" : "601052268276752384",
  "in_reply_to_user_id" : 1960900880,
  "text" : "@masayotominaga \u305D\u306E\u8FBA\u306E\u7D50\u679C\u304C\u5408\u5426\u3067\u3057\u304B\u8FD4\u3063\u3066\u3053\u306A\u3044\u3068\u30D5\u30A3\u30FC\u30C9\u30D0\u30C3\u30AF\u3082\u3057\u306B\u304F\u3044\u3067\u3059\u3082\u3093\u306D\u3047\u2026",
  "id" : 601052268276752384,
  "in_reply_to_status_id" : 601051984041410560,
  "created_at" : "2015-05-20 15:50:02 +0000",
  "in_reply_to_screen_name" : "masayotominaga",
  "in_reply_to_user_id_str" : "1960900880",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601047663652380672",
  "text" : "\u8650\u6BBA\u5668\u5B98",
  "id" : 601047663652380672,
  "created_at" : "2015-05-20 15:31:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u305B\u308A",
      "screen_name" : "zweisleeping",
      "indices" : [ 0, 13 ],
      "id_str" : "181966634",
      "id" : 181966634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601046788489936897",
  "geo" : { },
  "id_str" : "601047125770637312",
  "in_reply_to_user_id" : 181966634,
  "text" : "@zweisleeping \u30D0\u30E9\u30F3\u30B9\u611F\u899A\u3068\u3044\u3046\u304B\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u5FC5\u8981\u306A\u6280\u8853\u3067\u3059\u3088\u306D",
  "id" : 601047125770637312,
  "in_reply_to_status_id" : 601046788489936897,
  "created_at" : "2015-05-20 15:29:36 +0000",
  "in_reply_to_screen_name" : "zweisleeping",
  "in_reply_to_user_id_str" : "181966634",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601046527167963136",
  "text" : "\u4EF2\u826F\u3057\u3053\u3088\u3057\u3060\u3051\u3067\u826F\u3044\u3093\u3067\u3059\u304B\u3075\u30FC\u3093\u3063\u3066",
  "id" : 601046527167963136,
  "created_at" : "2015-05-20 15:27:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601046373803302913",
  "text" : "\u81EA\u5206\u306E\u8CA0\u306E\u611F\u60C5\u3092\u30CB\u30E5\u30A2\u30F3\u30B9\u3092\u8ABF\u6574\u3057\u306A\u304C\u3089\u3001\u8A00\u8449\u3092\u9078\u3073\u306A\u304C\u3089\u4F1D\u3048\u308B\u6280\u8853\u3063\u3066\u3081\u3063\u3061\u3083\u5927\u5207\u3060\u3068\u601D\u3046",
  "id" : 601046373803302913,
  "created_at" : "2015-05-20 15:26:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601045543121354752",
  "text" : "\u4ED6\u4EBA\u3092\u975E\u96E3\u3059\u308B\u53E3\u8ABF\u3068\u304B\u8A9E\u8ABF\u306B\u3053\u305D\u6027\u683C\u304C\u73FE\u308C\u308B\u6C17\u3082\u3059\u308B\u306E\u306B",
  "id" : 601045543121354752,
  "created_at" : "2015-05-20 15:23:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tominaga",
      "screen_name" : "masayotominaga",
      "indices" : [ 0, 15 ],
      "id_str" : "1960900880",
      "id" : 1960900880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601044141292814336",
  "geo" : { },
  "id_str" : "601045098277638144",
  "in_reply_to_user_id" : 1960900880,
  "text" : "@masayotominaga \u540C\u3058\u30A8\u30D4\u30BD\u30FC\u30C9\u8A9E\u308B\u306B\u3082\u8A00\u8449\u9078\u3073\u304C\u5FC5\u8981\u306A\u6C17\u304C\u3057\u307E\u3059\u306D\u2026\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u304C\u4E0A\u624B\u304F\u3044\u304B\u306A\u304F\u3066\u53F1\u3089\u308C\u3066\u3057\u307E\u3063\u305F\u3001\u307F\u305F\u3044\u306B\u67D4\u3089\u304B\u304F\u8A00\u3044\u63DB\u3048\u305F\u308A\u3068\u304B\n\u3067\u3082\u3088\u304F\u308F\u304B\u308A\u307E\u3057\u305F\u3001\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 601045098277638144,
  "in_reply_to_status_id" : 601044141292814336,
  "created_at" : "2015-05-20 15:21:32 +0000",
  "in_reply_to_screen_name" : "masayotominaga",
  "in_reply_to_user_id_str" : "1960900880",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601044404543959040",
  "text" : "\u305D\u306E\u5EA6\u306B\u300C\u30DE\u30B8\u304B\u3088\uFF01\u713C\u8089\u3068\u304B\u98DF\u3079\u306B\u884C\u304F\u304B\uFF01\u300D\u3063\u3066\u7B54\u3048\u3066\u308B\u3048\u3093\u3069\u3055\u3093\u3082\u5927\u6982\u3067\u3042\u308B",
  "id" : 601044404543959040,
  "created_at" : "2015-05-20 15:18:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601044284612038656",
  "text" : "\u53CB\u4EBA\u6C0F\u3001\u8A50\u6B3A\u30E1\u30FC\u30EB\u304C\u6765\u308B\u305F\u3073\u306B\u300C\u306A\u3093\u304B1000\u4E07\u3082\u3089\u3048\u308B\u3089\u3057\u3044\u3093\u3060\u3088\u306D\u300D\u3063\u3066\u9010\u4E00\u5831\u544A\u3057\u3066\u304F\u308B\u306E\u3081\u3063\u3061\u3087\u9762\u767D\u3044",
  "id" : 601044284612038656,
  "created_at" : "2015-05-20 15:18:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601043400779923457",
  "text" : "\u524D\u304B\u3089\u8A00\u3063\u3066\u308B\u3051\u3069\u4E16\u306E\u4E2D\u306B\u306F\u610F\u5473\u4E0D\u660E\u306A\u3082\u306E\u306E\u307B\u3046\u304C\u591A\u3044\u3093\u3060",
  "id" : 601043400779923457,
  "created_at" : "2015-05-20 15:14:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601043163315208192",
  "text" : "\u3059\u3063\u3054\u3044\u53EF\u611B\u30441000\u4E07\u3068\u3081\u3063\u3061\u3083\u30D6\u30B5\u30A4\u30AF\u306A5\u5104\u3067\u3082\u540C\u3058\u3053\u3068\u8A00\u3048\u3093\u306E\uFF1F",
  "id" : 601043163315208192,
  "created_at" : "2015-05-20 15:13:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601041835679580161",
  "text" : "\u30A2\u30EC\u6D3B\u306B\u304A\u3044\u3066\u3001\u201C\u5929\u5730\u958B\u95E2\u201D\u3068\u304B\u201C\u4EBA\u985E\u6EC5\u4EA1\u201D\u3068\u304B\u306E\u30EF\u30FC\u30C9\u306F\u4F7F\u308F\u306A\u3044\u307B\u3046\u304C\u826F\u3044\u3001\u4FFA\u306F\u8A73\u3057\u3044\u3093\u3060",
  "id" : 601041835679580161,
  "created_at" : "2015-05-20 15:08:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601041377061830657",
  "text" : "\u307C\u304F\u3082\u8E0F\u307F\u629C\u304D\u304B\u306D\u306A\u3044",
  "id" : 601041377061830657,
  "created_at" : "2015-05-20 15:06:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tominaga",
      "screen_name" : "masayotominaga",
      "indices" : [ 0, 15 ],
      "id_str" : "1960900880",
      "id" : 1960900880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601040992037314560",
  "geo" : { },
  "id_str" : "601041306572357633",
  "in_reply_to_user_id" : 1960900880,
  "text" : "@masayotominaga \u3057\u3046\u304B\u3064\u306B\u304A\u3051\u308BNG\u30EF\u30FC\u30C9\u3063\u3066\u5177\u4F53\u7684\u306B\u306F\u3069\u3093\u306A\u306E\u3067\u3059\u304B\u2026?",
  "id" : 601041306572357633,
  "in_reply_to_status_id" : 601040992037314560,
  "created_at" : "2015-05-20 15:06:28 +0000",
  "in_reply_to_screen_name" : "masayotominaga",
  "in_reply_to_user_id_str" : "1960900880",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306A\u3089\u306A\u3044",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601041046617722881",
  "text" : "\u305D\u306E\u3046\u3061\u201C\u26AA\uFE0E\u26AA\uFE0E\u3074\u3063\u3074\u6C0F\u201C\u307F\u305F\u3044\u306A\u547C\u79F0\u304C\u51FA\u3066\u304D\u3066\u6700\u7D42\u7684\u306B\u5FA1\u5FA1\u5FA1\u4ED8\u3051\u307F\u305F\u3044\u306A\u3053\u3068\u306B\u306A\u308B #\u306A\u3089\u306A\u3044",
  "id" : 601041046617722881,
  "created_at" : "2015-05-20 15:05:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601039892966051840",
  "text" : "\u304D\u3087\u3046\u306E\u3044\u3044\u306F\u306A\u3057",
  "id" : 601039892966051840,
  "created_at" : "2015-05-20 15:00:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JK\u30A6\u30B1\u624B",
      "screen_name" : "_lqu",
      "indices" : [ 3, 8 ],
      "id_str" : "251637864",
      "id" : 251637864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601039869087911937",
  "text" : "RT @_lqu: \u2190\u5BDD\u3066\u305F\u308F\u3051\u3067\u3082\u306A\u3044\u306E\u306B\u5C71\u624B\u7DDA\u4E57\u308A\u904E\u3054\u3057\u3066\u4ED9\u53F0\u306B\u5E30\u308C\u306A\u304F\u306A\u3063\u305F\u4EBA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.google.co.jp\/\" rel=\"nofollow\"\u003E\uFF98\uFF8A\uFF9F\uFF8C\uFF9E\uFF98\uFF6F\uFF78\u30FB\uFF75\uFF8C\uFF9E\u30FB\uFF9D\uFF93\uFF6E\uFF8C\uFF9F\uFF74\uFF6F\uFF7F\uFF7F\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601039642280890371",
    "text" : "\u2190\u5BDD\u3066\u305F\u308F\u3051\u3067\u3082\u306A\u3044\u306E\u306B\u5C71\u624B\u7DDA\u4E57\u308A\u904E\u3054\u3057\u3066\u4ED9\u53F0\u306B\u5E30\u308C\u306A\u304F\u306A\u3063\u305F\u4EBA",
    "id" : 601039642280890371,
    "created_at" : "2015-05-20 14:59:52 +0000",
    "user" : {
      "name" : "JK\u30A6\u30B1\u624B",
      "screen_name" : "_lqu",
      "protected" : false,
      "id_str" : "251637864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591249953428676609\/zGa5e-AO_normal.png",
      "id" : 251637864,
      "verified" : false
    }
  },
  "id" : 601039869087911937,
  "created_at" : "2015-05-20 15:00:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3093\u307E(88%)",
      "screen_name" : "tononro",
      "indices" : [ 0, 8 ],
      "id_str" : "118676218",
      "id" : 118676218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601039566598901761",
  "in_reply_to_user_id" : 118676218,
  "text" : "@tononro ping",
  "id" : 601039566598901761,
  "created_at" : "2015-05-20 14:59:34 +0000",
  "in_reply_to_screen_name" : "tononro",
  "in_reply_to_user_id_str" : "118676218",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601038290314076160",
  "text" : "\u305F\u3060\u30B9\u30EB\u30FC\u30B9\u30AD\u30EB\u304C\u306A\u3044\u304B\u3089\u62FE\u3048\u308B\u30CD\u30BF\u306F\u5168\u90E8\u62FE\u3046\u3001\u3068\u3044\u3046\u304B\u53CD\u5C04\u3067\u62FE\u3063\u3066\u3057\u307E\u3046",
  "id" : 601038290314076160,
  "created_at" : "2015-05-20 14:54:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601038139742760960",
  "text" : "\u7121\u8336\u632F\u308A\u306E\u4E2D\u306B\u3082\u3044\u308D\u3044\u308D\u3042\u308B\u304B\u3089\u306D",
  "id" : 601038139742760960,
  "created_at" : "2015-05-20 14:53:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601036344211722240",
  "geo" : { },
  "id_str" : "601036655462518784",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u307C\u304F\u304C\u4F59\u8A08\u306A\u3053\u3068\u8A00\u308F\u306A\u3051\u308C\u3070\u6700\u521D\u306F\u4E38\u304F\u53CE\u307E\u3063\u3066\u305F\u306F\u305A\u3060\u3057\u3001\u307C\u304F\u304C\u3081\u3093\u3069\u304F\u3055\u3044\u6551\u4E16\u4E3B\u3063\u3066\u3053\u3068\u304B\u3082\u3057\u3089\u306A\u3044",
  "id" : 601036655462518784,
  "in_reply_to_status_id" : 601036344211722240,
  "created_at" : "2015-05-20 14:48:00 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601036048601190401",
  "text" : "\u98F2\u307F\u4F1A\u3067\u540D\u4E57\u308A\u3092\u4E0A\u3052\u3055\u305B\u308B\u5974\u3082\u305D\u308C\u3067\u540D\u4E57\u308A\u3092\u4E0A\u3052\u3061\u3083\u3046\u5974\u3082\u9762\u767D\u3059\u304E\u308B\u3067\u3057\u3087",
  "id" : 601036048601190401,
  "created_at" : "2015-05-20 14:45:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601035917965426690",
  "text" : "\u5F8C\u8F29A\u300C\u305D\u308Chogehoge\u3089\u3057\u3044\u3088\u300D\n\u5F8C\u8F29B\u300C\u3078\u3047\u30FC\u3001\u3054\u3081\u3093\u4ECA\u66F4\u3060\u3051\u3069\u540D\u4E57\u308A\u3092\u4E0A\u3052\u3066\u304F\u308C\u300D\n\u5F8C\u8F29A\u300C\u3042\u3001\u30B9\u30BA\u30AD\u3067\u3059\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3044\u3084\u3044\u3084\u3001\u201C\u540D\u4E57\u308A\u3092\u4E0A\u3052\u201D\u306A\u3044\u3068\u3067\u3057\u3087\u300D\n\u5F8C\u8F29A\u300C\u300E\u3084\u3041\uFF01\u3084\u3041\uFF01\u6211\u3053\u305D\u306F\uFF01\u300F\u307F\u305F\u3044\u306A\u3084\u3064\u3067\u3059\u304B\u300D",
  "id" : 601035917965426690,
  "created_at" : "2015-05-20 14:45:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601034505713942528",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u5B66\u90E8\u306E\u9803\u306B\u51FA\u6765\u305F\u77E5\u308A\u5408\u3044\u5404\u4F4D\u304C\u6771\u4EAC\u306B\u96C6\u307E\u3063\u3066\u308B\u611F\u304C\u3042\u3063\u3066\u3001\u4E00\u6975\u96C6\u4E2D\u3060",
  "id" : 601034505713942528,
  "created_at" : "2015-05-20 14:39:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601034142017400832",
  "text" : "\u5F7C\u6C0F\u3067\u3082\u5F7C\u5973\u3067\u3082\u597D\u304D\u306A\u547C\u3073\u65B9\u3067\u597D\u304D\u306B\u547C\u3093\u3060\u3089\u826F\u3044\u3055",
  "id" : 601034142017400832,
  "created_at" : "2015-05-20 14:38:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601033918398107648",
  "text" : "s\/\u6C0F\/\u3074\u3063\u3074",
  "id" : 601033918398107648,
  "created_at" : "2015-05-20 14:37:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601033722754830337",
  "text" : "\u3058\u308F\u308B",
  "id" : 601033722754830337,
  "created_at" : "2015-05-20 14:36:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DhiArk",
      "screen_name" : "dhi_ark",
      "indices" : [ 3, 11 ],
      "id_str" : "116467602",
      "id" : 116467602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601033708162785280",
  "text" : "RT @dhi_ark: \u30AB\u30EC\u30D4\u30C3\u30D4\n\u5E73\u30D4\u30C3\u30D4\u30FB\u6E90\u30D4\u30C3\u30D4\n\u30A8\u30CC\u30D4\u30C3\u30D4\n\u5275\u30D4\u30C3\u30D4\u6539\u540D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.suruyatu.com\/\" rel=\"nofollow\"\u003E\u30C4\u30A4\u30C3\u30BF\u30FC\u3059\u308B\u3084\u3064\u03B3\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601033599672918016",
    "text" : "\u30AB\u30EC\u30D4\u30C3\u30D4\n\u5E73\u30D4\u30C3\u30D4\u30FB\u6E90\u30D4\u30C3\u30D4\n\u30A8\u30CC\u30D4\u30C3\u30D4\n\u5275\u30D4\u30C3\u30D4\u6539\u540D",
    "id" : 601033599672918016,
    "created_at" : "2015-05-20 14:35:51 +0000",
    "user" : {
      "name" : "DhiArk",
      "screen_name" : "dhi_ark",
      "protected" : false,
      "id_str" : "116467602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538434634803974144\/ixl40f-T_normal.png",
      "id" : 116467602,
      "verified" : false
    }
  },
  "id" : 601033708162785280,
  "created_at" : "2015-05-20 14:36:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 3, 11 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601033475508940800",
  "text" : "RT @chr1233: \u3060\u304C\u5F85\u3063\u3066\u307B\u3057\u3044\u30AB\u30EC\u30D4\u30C3\u30D4\u306F\u30AB\u30EC\u30D4\u30A3\u306E\u9032\u5316\u5F8C\u3067\u306F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601033433926631424",
    "text" : "\u3060\u304C\u5F85\u3063\u3066\u307B\u3057\u3044\u30AB\u30EC\u30D4\u30C3\u30D4\u306F\u30AB\u30EC\u30D4\u30A3\u306E\u9032\u5316\u5F8C\u3067\u306F",
    "id" : 601033433926631424,
    "created_at" : "2015-05-20 14:35:11 +0000",
    "user" : {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "protected" : false,
      "id_str" : "145536184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604587837543948289\/EBLw8dtv_normal.jpg",
      "id" : 145536184,
      "verified" : false
    }
  },
  "id" : 601033475508940800,
  "created_at" : "2015-05-20 14:35:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601033400741285888",
  "text" : "\u3044\u304B\u3065\u3061\u3058\u3083\u306A\u3044\u308F",
  "id" : 601033400741285888,
  "created_at" : "2015-05-20 14:35:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601033291458740225",
  "text" : "\u3055\u3063\u304D\u306E\u30C4\u30A4\u30FC\u30E8\u306E\u96F7\u3092\u3044\u304B\u3065\u3061\u3068\u8AAD\u3080\u63D0\u7763\u5404\u4F4D",
  "id" : 601033291458740225,
  "created_at" : "2015-05-20 14:34:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601032690184237056",
  "text" : "\u304B\u304C\u304F\u306E\u3061\u304B\u3089\u3060",
  "id" : 601032690184237056,
  "created_at" : "2015-05-20 14:32:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601032649067528192",
  "text" : "\u3064\u307E\u308A\u3042\u308C\u304B\u3001\u7F8E\u5BB9\u9662\u306B\u3042\u308B\u30D1\u30FC\u30DE\u3042\u3066\u308B\u3084\u3064\u3001\u3042\u308C\u306F\u96F7\u3092\u5F53\u3066\u3066\u308B\u306E\u304B",
  "id" : 601032649067528192,
  "created_at" : "2015-05-20 14:32:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601032370251116544",
  "text" : "\u6708\u306E\u77F3\u5F53\u3066\u305F\u3089\u304B\u308C\u3074\u304F\u3057\u30FC\u306B\u306A\u308B\u306E\u304B",
  "id" : 601032370251116544,
  "created_at" : "2015-05-20 14:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/601006498639056898\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WboGpUh1xf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFc0OPPUUAA06ik.jpg",
      "id_str" : "601006494490841088",
      "id" : 601006494490841088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFc0OPPUUAA06ik.jpg",
      "sizes" : [ {
        "h" : 134,
        "resize" : "fit",
        "w" : 179
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 179
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 179
      }, {
        "h" : 134,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 179
      } ],
      "display_url" : "pic.twitter.com\/WboGpUh1xf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601006498639056898",
  "text" : "http:\/\/t.co\/WboGpUh1xf",
  "id" : 601006498639056898,
  "created_at" : "2015-05-20 12:48:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601005394836623360",
  "text" : "\u6F14\u51FA\u904E\u5270\u3068\u3044\u3046\u304B\u3001\u4E3B\u5F35\u904E\u5270\u3067\u4E0B\u54C1\u306A\u5370\u8C61\u3060\u304B\u3089\u304B\u306A",
  "id" : 601005394836623360,
  "created_at" : "2015-05-20 12:43:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601005011544375296",
  "text" : "\u611F\u3058\u308B\u4E0D\u5FEB\u611F\u2192\u899A\u3048\u308B\u4E0D\u5FEB\u611F",
  "id" : 601005011544375296,
  "created_at" : "2015-05-20 12:42:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601004880489123840",
  "text" : "\u3010\uFF0A\u5831\u3011\u307B\u3052\u307B\u3052\u3075\u304C\u3075\u304C\u3074\u3088\u3074\u3088\u3075\u30FC\u3070\u30FC\n\u3010\uFF0A\u5831\u3011\u307B\u3052\u307B\u3052\u3075\u304C\u3075\u304C\u3074\u3088\u3074\u3088\u3075\u30FC\u3070\u30FC\n\u3010\uFF0A\u5831\u3011\u307B\u3052\u307B\u3052\u3075\u304C\u3075\u304C\u3074\u3088\u3074\u3088\u3075\u30FC\u3070\u30FC\n\u3010\uFF0A\u5831\u3011\u307B\u3052\u307B\u3052\u3075\u304C\u3075\u304C\u3074\u3088\u3074\u3088\u3075\u30FC\u3070\u30FC\n(\u753B\u50CF)\n\n\u5F62\u5F0F\u306E\u30C4\u30A4\u30FC\u30C8\u306B\u611F\u3058\u308B\u4E0D\u5FEB\u611F\u306F\u306A\u3093\u306A\u3093\u3060\u308D\u3046\u306A",
  "id" : 601004880489123840,
  "created_at" : "2015-05-20 12:41:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600983644287598592",
  "text" : "\u30C1\u30FC\u30BA\u4E57\u305B",
  "id" : 600983644287598592,
  "created_at" : "2015-05-20 11:17:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600981726656012288",
  "text" : "\u304B\u308C\u30FC\u3089\u3044\u3059",
  "id" : 600981726656012288,
  "created_at" : "2015-05-20 11:09:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600980033574801409",
  "geo" : { },
  "id_str" : "600980166186139649",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3088\u3044\u3088\u3044",
  "id" : 600980166186139649,
  "in_reply_to_status_id" : 600980033574801409,
  "created_at" : "2015-05-20 11:03:31 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600979981854838784",
  "text" : "\u7DCB\u304F\u3089\u3044\u307E\u3067\u306F\u624B\u5143\u306B\u30C7\u30FC\u30BF\u304C\u3042\u308B\u3068\u601D\u3046\u304C",
  "id" : 600979981854838784,
  "created_at" : "2015-05-20 11:02:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600979659606466561",
  "geo" : { },
  "id_str" : "600979801021620226",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u3055\u3046\u3093\u3069\u307B\u308A\u3063\u304F\u306E\u4E00\u6587\u5B57\u30B7\u30EA\u30FC\u30BA\u3059\u304D",
  "id" : 600979801021620226,
  "in_reply_to_status_id" : 600979659606466561,
  "created_at" : "2015-05-20 11:02:04 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600978683986202624",
  "text" : "\u592B\u5A66\u55A7\u5629\u306F\u5AC1\u306B\u98DF\u308F\u305B\u308D",
  "id" : 600978683986202624,
  "created_at" : "2015-05-20 10:57:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600978621633695744",
  "text" : "\u79CB\u8304\u5B50\u306F\u72AC\u306B\u98DF\u308F\u3059\u306A",
  "id" : 600978621633695744,
  "created_at" : "2015-05-20 10:57:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600978531946930176",
  "text" : "\u713C\u304D\u306A\u3059\u306F\u72AC\u3082\u98DF\u308F\u306A\u3044",
  "id" : 600978531946930176,
  "created_at" : "2015-05-20 10:57:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600943216423247872",
  "text" : "\u305F\u306E\u3057\u3044\u304B\u3044\u308F",
  "id" : 600943216423247872,
  "created_at" : "2015-05-20 08:36:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 13, 16 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600942940517609472",
  "geo" : { },
  "id_str" : "600943044041560064",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u306F\u3044 #\u306F\u3044",
  "id" : 600943044041560064,
  "in_reply_to_status_id" : 600942940517609472,
  "created_at" : "2015-05-20 08:36:01 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600942699986956288",
  "text" : "\u3068\u3044\u3046\u304B\u304B\u304C\u304F\u307E\u3055\u3093\u306F\u306A\u3093\u3067\u4F8B\u4F1A\u306E\u767A\u751F\u3092\u9632\u304E\u305F\u3044\u3093\u3060\u2026",
  "id" : 600942699986956288,
  "created_at" : "2015-05-20 08:34:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600942534223908864",
  "text" : "\u98DF\u5802\u306E\u76F4\u4E0A\u306B\u76F4\u5F84\u6570\u767E\u30AD\u30ED\u306B\u53CA\u3076\u9695\u77F3\u3092\u3076\u3064\u3051\u305F\u308A\u3059\u308B\u3068\u30C0\u30E1",
  "id" : 600942534223908864,
  "created_at" : "2015-05-20 08:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600942165485756416",
  "geo" : { },
  "id_str" : "600942336118550528",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u4EBA\u985E\u3092\u5931\u3063\u3066\u3082\u3057\u3070\u3089\u304F\u306E\u9593\u306F\u98DF\u5802\u306E\u4E8C\u968E\u306F\u5B58\u7D9A\u3057\u307E\u3059\u304B\u3089\u306D\u3002\u4EBA\u985E\u3092\u6EC5\u307C\u3059\u65B9\u6CD5\u306B\u3082\u4F9D\u308A\u307E\u3059\u304C\u3002",
  "id" : 600942336118550528,
  "in_reply_to_status_id" : 600942165485756416,
  "created_at" : "2015-05-20 08:33:12 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600941902918090752",
  "geo" : { },
  "id_str" : "600942083399090176",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3048\u30FC\u3001\u4ED6\u306E\u6848\u3060\u3068\u4EBA\u985E\u3092\u6EC5\u307C\u3059\u304F\u3089\u3044\u3057\u304B\u601D\u3044\u3064\u304B\u306A\u3044\u3067\u3059\u306D\u3047",
  "id" : 600942083399090176,
  "in_reply_to_status_id" : 600941902918090752,
  "created_at" : "2015-05-20 08:32:12 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600938405820649472",
  "geo" : { },
  "id_str" : "600940826395602944",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304B\u304C\u304F\u307E\u3055\u3093\u3063\u305F\u3089\u7269\u9A12\u306A\u304B\u3093\u304C\u3048\u304B\u305F\u3092\u3057\u307E\u3059\u306D\uFF5E\u3002\u50D5\u306F\u4F8B\u4F1A\u306E\u767A\u751F\u3092\u9632\u304E\u305F\u3044\u3060\u3051\u3067\u3059\u3088\u3002",
  "id" : 600940826395602944,
  "in_reply_to_status_id" : 600938405820649472,
  "created_at" : "2015-05-20 08:27:12 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600938253416534016",
  "text" : "\u601D\u8003\u505C\u6B62\u4F1A\u8A71",
  "id" : 600938253416534016,
  "created_at" : "2015-05-20 08:16:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600938027809054720",
  "geo" : { },
  "id_str" : "600938080468652032",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3044\u3048\u3001\u7834\u58CA\u3059\u308B\u306E\u306F\u98DF\u5802\u306E\u4E8C\u968E\u3067\u3059",
  "id" : 600938080468652032,
  "in_reply_to_status_id" : 600938027809054720,
  "created_at" : "2015-05-20 08:16:17 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600937698577096704",
  "geo" : { },
  "id_str" : "600937876826804224",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u4ECA\u306E\u3046\u3061\u306B\u98DF\u5802\u306E\u4E8C\u968E\u3092\u7206\u7834\u3057\u3066\u304A\u3051\u3070\u4F8B\u4F1A\u306E\u767A\u751F\u3092\u672A\u7136\u306B\u9632\u3052\u308B\u306E\u3067\u306F",
  "id" : 600937876826804224,
  "in_reply_to_status_id" : 600937698577096704,
  "created_at" : "2015-05-20 08:15:29 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600930859731054592",
  "text" : "\u3093\u3042\u30FC",
  "id" : 600930859731054592,
  "created_at" : "2015-05-20 07:47:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    }, {
      "name" : "\u3044\u308B\u305F\u3093",
      "screen_name" : "t_iru",
      "indices" : [ 9, 15 ],
      "id_str" : "1020292580",
      "id" : 1020292580
    }, {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 16, 27 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600281516426407936",
  "geo" : { },
  "id_str" : "600928596161634304",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom @t_iru @Maleic1618 \u3060\u308C\u3082\u66F8\u3044\u3066\u306A\u304F\u3066\uFF8E\uFF8B\uFF6F\u3063\u3066\u306A\u308A\u307E\u3057\u305F",
  "id" : 600928596161634304,
  "in_reply_to_status_id" : 600281516426407936,
  "created_at" : "2015-05-20 07:38:36 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600927929883873281",
  "text" : "\u3057\u305B\u3044\u304C\u308F\u308B\u3044\u3060\u3051\u306A",
  "id" : 600927929883873281,
  "created_at" : "2015-05-20 07:35:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600927893661843456",
  "text" : "\u80A9\u3068\u304B\u8170\u3001\u660E\u3089\u304B\u306B\u73FE\u4EE3\u306E\u751F\u6D3B\u306B\u5411\u304B\u306A\u3044\u30CF\u30FC\u30C9\u30A6\u30A7\u30A2\u3060\u3057\u30B5\u30A4\u30D0\u30CD\u5316\u3057\u305F\u3044",
  "id" : 600927893661843456,
  "created_at" : "2015-05-20 07:35:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600886574331600896",
  "text" : "\u3042\u3051\u304A\u3074\u3083\u3042\u3001\u305F\u3076\u3093\u6F5C\u6C34\u8266\u306B\u89AA\u3068\u304B\u6BBA\u3055\u308C\u305F\u3093\u3060\u3068\u601D\u3046",
  "id" : 600886574331600896,
  "created_at" : "2015-05-20 04:51:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600886407469473792",
  "geo" : { },
  "id_str" : "600886500012744704",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6F5C\u6C34\u8266\u306B\u305F\u3044\u3057\u3066\u53B3\u3057\u3059\u304E\u308F\u308D\u305F",
  "id" : 600886500012744704,
  "in_reply_to_status_id" : 600886407469473792,
  "created_at" : "2015-05-20 04:51:20 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600865755433869313",
  "geo" : { },
  "id_str" : "600865808525488129",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u50D5\u306F\u60AA\u304F\u306A\u3044",
  "id" : 600865808525488129,
  "in_reply_to_status_id" : 600865755433869313,
  "created_at" : "2015-05-20 03:29:06 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600865262372409345",
  "geo" : { },
  "id_str" : "600865385936719872",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u305D\u308C\u306A",
  "id" : 600865385936719872,
  "in_reply_to_status_id" : 600865262372409345,
  "created_at" : "2015-05-20 03:27:26 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600860499601940480",
  "text" : "\uFF72\uFF72\uFF8A\uFF85\uFF7C\uFF80\uFF9E\uFF85\uFF70",
  "id" : 600860499601940480,
  "created_at" : "2015-05-20 03:08:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600680353846538240",
  "text" : "\u81EA\u5206\u3082\u3060\u3051\u3069\u3001\u53C2\u52A0\u3057\u305D\u3046\u306A\u4EBA\u305F\u3061\u306E\u30A2\u30EC\u6D3B\u7D42\u308F\u3063\u305F\u3089\u5BB4\u30B7\u30CA\u30EA\u30AA\u3092\u3084\u308B\u3068\u5FC3\u306B\u6C7A\u3081\u305F\u3002",
  "id" : 600680353846538240,
  "created_at" : "2015-05-19 15:12:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600649514110693377",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 600649514110693377,
  "created_at" : "2015-05-19 13:09:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600649492208070656",
  "text" : "PM\u300C\u3067\u306F\u4ED5\u69D8\u5909\u66F4\u306E\u7B87\u6240\u30921D100\u3067\u6C7A\u3081\u307E\u3059\u300D",
  "id" : 600649492208070656,
  "created_at" : "2015-05-19 13:09:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600648007864823808",
  "text" : "\u304A\u98A8\u5442\u5165\u308A\u305F\u3044\u2026\u30A2\u30A4\u30B9\u3082\u98DF\u3079\u305F\u3044\u2026\u304A\u98A8\u5442\u3067\u30A2\u30A4\u30B9\u98DF\u3079\u308C\u3070\u3088\u3044\uFF01\uFF01\uFF01",
  "id" : 600648007864823808,
  "created_at" : "2015-05-19 13:03:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600647185412141057",
  "text" : "\u3044\u3068\u3082\u305F\u3084\u3059\u304F\u884C\u308F\u308C\u308B\u3048\u3052\u3064\u306A\u304422\u6642",
  "id" : 600647185412141057,
  "created_at" : "2015-05-19 13:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600584669889994753",
  "text" : "\u6642\u9593\u306E\u6D41\u308C\u304C\u65E9\u3044",
  "id" : 600584669889994753,
  "created_at" : "2015-05-19 08:51:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600551685459685376",
  "text" : "\u307E\u3063\u3001\u307E\u3063",
  "id" : 600551685459685376,
  "created_at" : "2015-05-19 06:40:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/600549013650337792\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/CNK0FaA5bH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFWUJCEWgAAmSW2.jpg",
      "id_str" : "600549008218685440",
      "id" : 600549008218685440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFWUJCEWgAAmSW2.jpg",
      "sizes" : [ {
        "h" : 594,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 594,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CNK0FaA5bH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600549013650337792",
  "text" : "\u306A\u308B\u307B\u3069 http:\/\/t.co\/CNK0FaA5bH",
  "id" : 600549013650337792,
  "created_at" : "2015-05-19 06:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600523231737487361",
  "text" : "\u304B\u306A\u3089\u305A\u3057\u3082\u307B\u3057\u304F\u306A\u3044\u3082\u306E\u30EA\u30B9\u30C8\u3001\u672C\u5F53\u306B\u304B\u306A\u3089\u305A\u3057\u3082\u307B\u3057\u304F\u306A\u3044\u3082\u306E\u304C\u96C6\u3063\u3066\u6765\u3066\u3044\u308B",
  "id" : 600523231737487361,
  "created_at" : "2015-05-19 04:47:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon.co.jp (\u30A2\u30DE\u30BE\u30F3)",
      "screen_name" : "AmazonJP",
      "indices" : [ 72, 81 ],
      "id_str" : "161616614",
      "id" : 161616614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/uBkvOOdQ96",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B00B53L98S\/ref=cm_sw_r_tw_awdo_jaSwvb0BAYBAZ",
      "display_url" : "amazon.co.jp\/dp\/B00B53L98S\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600522837644877824",
  "text" : "\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3 \u306F\u3058\u3081\u3066\u30C7\u30B8\u30AB\u30E12 \u30A2\u30AC\u30C4\u30DE#\u30A2\u30DE\u30BE\u30F3\u30DD\u30C1 \u3068\u5165\u308C\u3066@\u8FD4\u4FE1\u3067\u30AB\u30FC\u30C8\u306B\u8FFD\u52A0\u30FB\u5F8C\u3067\u8CB7\u3046 http:\/\/t.co\/uBkvOOdQ96 @amazonJP\u3055\u3093\u304B\u3089\n\u304B\u306A\u3089\u305A\u3057\u3082\u307B\u3057\u304F\u306A\u3044\u3082\u306E\u30EA\u30B9\u30C8\u306B\u8FFD\u52A0\u3057\u307E\u3057\u305F",
  "id" : 600522837644877824,
  "created_at" : "2015-05-19 04:46:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon.co.jp (\u30A2\u30DE\u30BE\u30F3)",
      "screen_name" : "AmazonJP",
      "indices" : [ 91, 100 ],
      "id_str" : "161616614",
      "id" : 161616614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Sg8iZiZnCN",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B004L8C1HW\/ref=cm_sw_r_tw_awdo_B.Rwvb0M1D8EN",
      "display_url" : "amazon.co.jp\/dp\/B004L8C1HW\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600522744610951168",
  "text" : "\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3 \u672C\u5F53\u306B\u64AE\u308C\u308B!\u3057\u3083\u3079\u308B!\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3 \u306F\u3058\u3081\u3066\u30C7\u30B8\u30AB\u30E1 \u30A2\u30AC\u30C4\u30DE#\u30A2\u30DE\u30BE\u30F3\u30DD\u30C1 \u3068\u5165\u308C\u3066@\u8FD4\u4FE1\u3067\u30AB\u30FC\u30C8\u306B\u8FFD\u52A0\u30FB\u5F8C\u3067\u8CB7\u3046  http:\/\/t.co\/Sg8iZiZnCN @amazonJP\u3055\u3093\u304B\u3089\n\u304B\u306A\u3089\u305A\u3057\u3082\u307B\u3057\u304F\u306A\u3044\u3082\u306E\u30EA\u30B9\u30C8\u306B\u8FFD\u52A0\u3057\u307E\u3057\u305F",
  "id" : 600522744610951168,
  "created_at" : "2015-05-19 04:45:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600306409524359168",
  "text" : "\u304F\u305D\u3063\u307D\u304F\u3066\u304F\u305D\u3058\u3083\u306A\u3044\u3001\u3067\u3082\u3061\u3087\u3063\u3068\u304F\u305D\u306A\u304F\u305D\u308A\u3077",
  "id" : 600306409524359168,
  "created_at" : "2015-05-18 14:26:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600306226396672000",
  "geo" : { },
  "id_str" : "600306293673451520",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u3068\u308A\u3042\u3048\u305A\u5408\u3046",
  "id" : 600306293673451520,
  "in_reply_to_status_id" : 600306226396672000,
  "created_at" : "2015-05-18 14:25:48 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600305921869373441",
  "text" : "\u7F6A\u3068\u7F70",
  "id" : 600305921869373441,
  "created_at" : "2015-05-18 14:24:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600305902873407488",
  "text" : "\u5909\u614B\u738B\u5B50\u3068\u7B11\u308F\u306A\u3044\u732B",
  "id" : 600305902873407488,
  "created_at" : "2015-05-18 14:24:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600305863178477568",
  "text" : "\u30BB\u30FC\u30E9\u30FC\u670D\u3068\u6A5F\u95A2\u9283",
  "id" : 600305863178477568,
  "created_at" : "2015-05-18 14:24:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600305790071808002",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u30BC\u30EA\u30FC\u3068\u70CF\u9F8D\u8336",
  "id" : 600305790071808002,
  "created_at" : "2015-05-18 14:23:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600305438261977088",
  "text" : "\u98DB\u884C\u6A5F\u4E8B\u6545\u3067\u8089\u7247\u304C\u964D\u308A\u6CE8\u3044\u3060\u8A71\u3068\u304B\u96EA\u5C71\u3067\u906D\u96E3\u3057\u3066\u4EBA\u8089\u3092\u98DF\u3079\u3066\u51CC\u3044\u3060\u8A71\u3068\u304B\u805E\u3044\u3061\u3083\u3063\u305F\u304B\u3089SAN\u5024\u304C\u3058\u308F\u3058\u308F\u524A\u3089\u308C\u305F",
  "id" : 600305438261977088,
  "created_at" : "2015-05-18 14:22:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600304205505560576",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u30BC\u30EA\u30FC\u30A4\u30FC\u30BF\u30FC",
  "id" : 600304205505560576,
  "created_at" : "2015-05-18 14:17:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600300377804709888",
  "text" : "\u70CF\u8CB4\u65CF\u3063\u3066\u306A\u3093\u3060\uFF1F",
  "id" : 600300377804709888,
  "created_at" : "2015-05-18 14:02:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600300240390856704",
  "text" : "\u70CF\u8CB4\u65CF\u3067\u70CF\u9F8D\u8336\u3092\u98F2\u3082\u3046",
  "id" : 600300240390856704,
  "created_at" : "2015-05-18 14:01:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u58F0\u306B\u51FA\u3057\u3066\u8AAD\u307F\u305F\u3044\u65E5\u672C\u8A9E",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600291008400596992",
  "text" : "\u30B4\u30A6\u30E9\u30F3\u30AC\u2026\uFF01\u30BD\u30CB\u30C3\u30AF\u30AB\u30E9\u30C6\u5BFE\u7A7A\u30DD\u30E0\u30DD\u30E0\u30D1\u30F3\u30C1\u3060\uFF01\u30DF\u30CB\u30DE\u30EB\u306A\u6728\u4EBA\u62F3\u3081\u3044\u305F\u6700\u5927\u63A5\u8FD1\u8DDD\u96E2\u6253\u6483\u306E\u5FDC\u916C\u3002\u7D76\u3048\u9593\u306A\u304F\u7E70\u308A\u51FA\u3055\u308C\u308B\u653B\u6483\u3068\u9632\u5FA1\u306E\u3001\u69CB\u7BC9\u7F8E\u3081\u3044\u305F\u3001\u5C0F\u5B87\u5B99\u3002 #\u58F0\u306B\u51FA\u3057\u3066\u8AAD\u307F\u305F\u3044\u65E5\u672C\u8A9E",
  "id" : 600291008400596992,
  "created_at" : "2015-05-18 13:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600287308386963457",
  "text" : "\u307C\u304F\u306A\u3093\u304B\u4F1A\u3063\u305F\u4EBA\u306E\u3053\u3068\u3082\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3068\u3044\u3046\u306E\u306B",
  "id" : 600287308386963457,
  "created_at" : "2015-05-18 13:10:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600287240653131776",
  "text" : "\u4E16\u306E\u4E2D\u306E\u4EBA\u306F\u4F1A\u3063\u305F\u3053\u3068\u3082\u306A\u3044\u4EBA\u306B\u5BFE\u3057\u3066\u3044\u308D\u3044\u308D\u77E5\u3063\u305F\u98A8\u306B\u8A00\u3044\u904E\u304E\u308B\u6C17\u304C\u3059\u308B\u3088\u306D",
  "id" : 600287240653131776,
  "created_at" : "2015-05-18 13:10:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600282725493264386",
  "geo" : { },
  "id_str" : "600282856267513856",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u307E\u3041\u50D5\u3082\u5B9F\u5BB6\u306B\u306F\u5C45\u5834\u6240(\u7269\u7406)\u304C\u306A\u3044\u306E\u3067\u3069\u3046\u3057\u3088\u3046\u304B\u8003\u3048\u3066\u308B\u3093\u3067\u3059\u3051\u3069\u306D",
  "id" : 600282856267513856,
  "in_reply_to_status_id" : 600282725493264386,
  "created_at" : "2015-05-18 12:52:40 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600282633977790464",
  "text" : "\u304B\u304C\u304F\u307E\u3055\u3093\u306E\u30DB\u30FC\u30E0\u898B\u306B\u884C\u304F\u3068\u50D5\u4EE5\u5916\u306F\u666E\u901A\u306E\u305F\u3060\u3044\u307E\u304A\u304B\u3048\u308A\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u3057\u3066\u3066\u7B11\u3046",
  "id" : 600282633977790464,
  "created_at" : "2015-05-18 12:51:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600282131680526336",
  "geo" : { },
  "id_str" : "600282287222050816",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u3042\u3070\u3070\u3070\u3070",
  "id" : 600282287222050816,
  "in_reply_to_status_id" : 600282131680526336,
  "created_at" : "2015-05-18 12:50:24 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600282217152032768",
  "text" : "mission complete",
  "id" : 600282217152032768,
  "created_at" : "2015-05-18 12:50:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 31, 41 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 43, 52 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600282059999875072",
  "text" : "RT @kagakuma: \u304D\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01RT @end313124: @kagakuma \u306A\u3093\u3067\u3059\u3063\u3066\uFF1F\uFF01\u5317\u533A\u304B\u3089\u306A\u3093\u3068\uFF1F\uFF01\u306A\u3093\u3068\u8A00\u3044\u307E\u3057\u305F\u304B\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 17, 27 ],
        "id_str" : "155546700",
        "id" : 155546700
      }, {
        "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
        "screen_name" : "kagakuma",
        "indices" : [ 29, 38 ],
        "id_str" : "139989698",
        "id" : 139989698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600282031457579008",
    "text" : "\u304D\u3001\u5317\u533A\u304B\u3089\u304D\u305F\u304F\u307E\u30FC\uFF01\uFF01\uFF01RT @end313124: @kagakuma \u306A\u3093\u3067\u3059\u3063\u3066\uFF1F\uFF01\u5317\u533A\u304B\u3089\u306A\u3093\u3068\uFF1F\uFF01\u306A\u3093\u3068\u8A00\u3044\u307E\u3057\u305F\u304B\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01",
    "id" : 600282031457579008,
    "created_at" : "2015-05-18 12:49:23 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 600282059999875072,
  "created_at" : "2015-05-18 12:49:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u514E",
      "screen_name" : "bagirom",
      "indices" : [ 0, 8 ],
      "id_str" : "203870045",
      "id" : 203870045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600281849869381632",
  "geo" : { },
  "id_str" : "600281980068990976",
  "in_reply_to_user_id" : 203870045,
  "text" : "@bagirom \u65E9\u3081\u306B\u8A00\u3063\u3066\u306A\u30FC",
  "id" : 600281980068990976,
  "in_reply_to_status_id" : 600281849869381632,
  "created_at" : "2015-05-18 12:49:11 +0000",
  "in_reply_to_screen_name" : "bagirom",
  "in_reply_to_user_id_str" : "203870045",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600281947118571521",
  "text" : "\u4E45\u3005\u306B",
  "id" : 600281947118571521,
  "created_at" : "2015-05-18 12:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600281816176562176",
  "geo" : { },
  "id_str" : "600281915640270848",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u306A\u3093\u3067\u3059\u3063\u3066\uFF1F\uFF01\u5317\u533A\u304B\u3089\u306A\u3093\u3068\uFF1F\uFF01\u306A\u3093\u3068\u8A00\u3044\u307E\u3057\u305F\u304B\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01",
  "id" : 600281915640270848,
  "in_reply_to_status_id" : 600281816176562176,
  "created_at" : "2015-05-18 12:48:56 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600281494347612161",
  "geo" : { },
  "id_str" : "600281636526104576",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u5B9F\u5BB6\u304B\u3089\u53C2\u52A0\u3057\u308D\uFF01\uFF01\uFF01\uFF01\u50D5\u306F\u305F\u3076\u3093\u305D\u3046\u306A\u308B\uFF01\uFF01\uFF01",
  "id" : 600281636526104576,
  "in_reply_to_status_id" : 600281494347612161,
  "created_at" : "2015-05-18 12:47:49 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/pBKNGw8qvg",
      "expanded_url" : "http:\/\/www.mod.go.jp\/msdf\/formal\/family\/recipe\/archive\/100423\/print.html",
      "display_url" : "mod.go.jp\/msdf\/formal\/fa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600279878580080641",
  "text" : "\u4ECA\u56DE\u306E\u30AB\u30EC\u30FC\u306F\u3053\u308C http:\/\/t.co\/pBKNGw8qvg \u3092\u30C1\u30AD\u30F3\u306B\u30A2\u30EC\u30F3\u30B8\u3057\u305F\u3084\u3064",
  "id" : 600279878580080641,
  "created_at" : "2015-05-18 12:40:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600278809200369664",
  "text" : "\u300C\u5727\u300D",
  "id" : 600278809200369664,
  "created_at" : "2015-05-18 12:36:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600278762228318209",
  "text" : "\u9EBB\u5A46\u6625\u96E8\u3068\u4E26\u884C\u3057\u3066\u30AB\u30EC\u30FC\u4F5C\u3063\u3066\u308B",
  "id" : 600278762228318209,
  "created_at" : "2015-05-18 12:36:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/uWOuVAm7wD",
      "expanded_url" : "https:\/\/github.com\/KenshoFujisaki\/CreateTwitterLogDB",
      "display_url" : "github.com\/KenshoFujisaki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600232404658343936",
  "text" : "\u3053\u3093\u306A\u7D20\u6575\u306A(?)\u30C4\u30FC\u30EB\u3092\u898B\u3064\u3051\u3066\u3057\u307E\u3063\u3066\u306A\nhttps:\/\/t.co\/uWOuVAm7wD",
  "id" : 600232404658343936,
  "created_at" : "2015-05-18 09:32:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600221117081591808",
  "text" : "\u30AD\u30E3\u30E9\u30AF\u30BF\u30FC\u306E\u516C\u5F0F\u30A2\u30AB\u30A6\u30F3\u30C8\u306B\u30EA\u30D7\u30E9\u30A4\u98DB\u3070\u3059\u4EBA\u3001\u81EA\u52D5\u8CA9\u58F2\u6A5F\u3068\u304B\u3001\u96FB\u8ECA\u306E\u30A2\u30CA\u30A6\u30F3\u30B9\u3068\u304B\u3068\u304A\u558B\u308A\u3057\u305D\u3046",
  "id" : 600221117081591808,
  "created_at" : "2015-05-18 08:47:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600218345720385536",
  "text" : "\u8FF8\u308B\u307B\u3069\u306B\uFF72\uFF72\uFF8A\uFF85\uFF7C\uFF80\uFF9E\uFF85\uFF70",
  "id" : 600218345720385536,
  "created_at" : "2015-05-18 08:36:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600209688618258432",
  "text" : "SlideShare\u3063\u3066\u91CD\u305F\u3044",
  "id" : 600209688618258432,
  "created_at" : "2015-05-18 08:01:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599956465986633728",
  "text" : "\u9577\u98A8\u5442\u306E\u3042\u3068\u306E\u70CF\u9F8D\u8336\u3001\u5E78\u305B",
  "id" : 599956465986633728,
  "created_at" : "2015-05-17 15:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599952660398149632",
  "text" : "\u5973\u5DDD\u99C5\u306E\u30DD\u30FC\u30BF\u30EB\u30AD\u30FC\u3001\u30C9\u30ED\u30C3\u30D7\u3057\u3061\u3083\u3063\u305F\u306E\u5F8C\u6094\u3057\u3066\u308B",
  "id" : 599952660398149632,
  "created_at" : "2015-05-17 15:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599952313071972352",
  "text" : "\u597D\u304D\u306A\u97F3\u697D\u6D41\u3057\u306A\u304C\u3089\u304A\u98A8\u5442\u3067\u30C4\u30A4\u30C3\u30BF\u30FC\u3059\u308B\u306E\u3001\u5E78\u305B\u306E\u4E00\u3064\u306E\u5F62\u3060",
  "id" : 599952313071972352,
  "created_at" : "2015-05-17 14:59:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599951906182565888",
  "text" : "\u5358\u7D14\u306A\u77ED\u3044\u8A00\u8449\u306B\u610F\u5473\u3092\u8FBC\u3081\u3059\u304E\u308B\u306A",
  "id" : 599951906182565888,
  "created_at" : "2015-05-17 14:57:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3093\u307E(88%)",
      "screen_name" : "tononro",
      "indices" : [ 0, 8 ],
      "id_str" : "118676218",
      "id" : 118676218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599951503277707264",
  "geo" : { },
  "id_str" : "599951700896550912",
  "in_reply_to_user_id" : 118676218,
  "text" : "@tononro \u9811\u5F35\u3063\u3066\u8A00\u8A9E\u5316\u3057\u3066\u3044\u304D\u307E\u305B\u3046",
  "id" : 599951700896550912,
  "in_reply_to_status_id" : 599951503277707264,
  "created_at" : "2015-05-17 14:56:46 +0000",
  "in_reply_to_screen_name" : "tononro",
  "in_reply_to_user_id_str" : "118676218",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3093\u307E(88%)",
      "screen_name" : "tononro",
      "indices" : [ 0, 8 ],
      "id_str" : "118676218",
      "id" : 118676218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599951048145403904",
  "geo" : { },
  "id_str" : "599951404967407616",
  "in_reply_to_user_id" : 118676218,
  "text" : "@tononro \u3082\u3057\u304B\u3057\u3066:\u524D\u304B\u3089",
  "id" : 599951404967407616,
  "in_reply_to_status_id" : 599951048145403904,
  "created_at" : "2015-05-17 14:55:36 +0000",
  "in_reply_to_screen_name" : "tononro",
  "in_reply_to_user_id_str" : "118676218",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599945632808218624",
  "text" : "\u3044\u308D\u3093\u306A\u3053\u3068\u304C\u3042\u3063\u3066\u3044\u308D\u3093\u306A\u4EBA\u304C\u3044\u308D\u3093\u306A\u3053\u3068\u3092\u8A00\u3063\u3066\u3044\u3066\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3060",
  "id" : 599945632808218624,
  "created_at" : "2015-05-17 14:32:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599944745712898050",
  "text" : "\u307B\u306E\u30FC\u304B\u30FC\u306A\u30FC\u3072\u30FC\u304B\u308A\u30FC\u304C\u30FC",
  "id" : 599944745712898050,
  "created_at" : "2015-05-17 14:29:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599943272388120576",
  "text" : "\u624B\u66F8\u304DES\u306B\u59BB\u5B50\u3092\u6BBA\u3055\u308C\u305F\u30B7\u30E5\u30FC\u30AB\u30C4\u30BB\u30A4\u304C\u81EA\u3089\u3082\u6BBA\u3055\u308C\u305D\u3046\u306B\u306A\u3063\u305F\u6642\u3001\u81EA\u8EAB\u3082\u624B\u66F8\u304DES\u3068\u306A\u308A\u624B\u66F8\u304DES\u3092\u6BBA\u3059\u5FA9\u8B90\u8005\u3068\u306A\u3063\u3066\u8607\u308B\u8A71",
  "id" : 599943272388120576,
  "created_at" : "2015-05-17 14:23:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599942846930505728",
  "geo" : { },
  "id_str" : "599942966652772352",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u3053\u3053\u4E09\u65E5\u304F\u3089\u3044\u5BD2\u3059\u304E\u308B",
  "id" : 599942966652772352,
  "in_reply_to_status_id" : 599942846930505728,
  "created_at" : "2015-05-17 14:22:04 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599942673663819776",
  "text" : "\u8A31\u3055\u308C\u305F",
  "id" : 599942673663819776,
  "created_at" : "2015-05-17 14:20:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599941952373542913",
  "geo" : { },
  "id_str" : "599942328548077569",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u5F62\u5F0F\u7684\u30AC\u30B9\u629C\u304D",
  "id" : 599942328548077569,
  "in_reply_to_status_id" : 599941952373542913,
  "created_at" : "2015-05-17 14:19:32 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599941964394405888",
  "geo" : { },
  "id_str" : "599942279776710656",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u5BD2\u3044\u304B\u3089\u304A\u5E03\u56E3\u88AB\u308D\u3046\u2192\u304A\u5E03\u56E3\u5165\u308D\u3046\u2192\u663C\u5BDD\u306E\u30B3\u30F3\u30DC\u307E\u3067\u6C7A\u3081\u3066\u3057\u307E\u3063\u305F\u3001\u305F\u307E\u306B\u306F\u8A31\u3055\u308C\u305F\u3044",
  "id" : 599942279776710656,
  "in_reply_to_status_id" : 599941964394405888,
  "created_at" : "2015-05-17 14:19:20 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599941873927487491",
  "text" : "\u7279\u5225\u75B2\u308C\u3066\u305F\u308F\u3051\u3067\u3082\u306A\u3044\u306F\u305A\u306A\u306E\u306B\u306A",
  "id" : 599941873927487491,
  "created_at" : "2015-05-17 14:17:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599941832366129152",
  "text" : "\u4ECA\u65E5\u306F\u5B8C\u5168\u306B\u304A\u5BB6\u306E\u304A\u5E03\u56E3\u3067\u6B7B\u3093\u3060\u3088\u3046\u306B\u751F\u304D\u3066\u305F\u3057\u660E\u65E5\u304B\u3089\u307E\u305F\u3061\u3083\u3093\u3068\u751F\u304D\u3088\u3046",
  "id" : 599941832366129152,
  "created_at" : "2015-05-17 14:17:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599926184193884160",
  "text" : "(\u00B4_\u309D\u02CB)\uFF87\uFF70\uFF9D",
  "id" : 599926184193884160,
  "created_at" : "2015-05-17 13:15:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599602624329977856",
  "text" : "\u3053\u306E\u524DTRPG\u3084\u3063\u305F\u53CB\u4EBA(\u521D\u5FC3\u8005)\u3068\u6050\u6016\u306B\u3064\u3044\u3066\u558B\u3063\u3066\u3066\u3001\u3053\u306E\u524D\u306E\u30BB\u30C3\u30B7\u30E7\u30F3\u6016\u304B\u3063\u305F\u3063\u3066\u8A00\u3063\u3066\u3082\u3089\u3048\u305F\u306E\u3001\u3068\u3066\u3082\u5B09\u3057\u304B\u3063\u305F\u3057KP\u51A5\u5229\u306B\u5C3D\u304D\u308B",
  "id" : 599602624329977856,
  "created_at" : "2015-05-16 15:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599601757346398210",
  "text" : "\u300C\u51FA\u6765\u306A\u3055\u305D\u3046\u306A\u4E8B\u3053\u305D\u3001\u3042\u3048\u3066\u3084\u308A\u305F\u3044\u3093\u3060\u3088\u3002\u79C1\u307F\u305F\u3044\u306A\u5927\u5B66\u9662\u751F\u306F\u3055\u3002\u4EBA\u985E\u3001\u6EC5\u4EA1\u3055\u305B\u3066\u307F\u305F\u308A\u3068\u304B\u3055!\u300D\n\u300C\u3048\u30FC\u3002\u300D\n\u300C\u304A\u30FC\u3002\u300D\n\u300C\u3068\u304D\u3081\u304F\u306A!\u300D",
  "id" : 599601757346398210,
  "created_at" : "2015-05-16 15:46:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599600208805138432",
  "text" : "\u540C\u6642\u306B\u30D1\u30B8\u30E3\u30DE\u3092\u7740\u3066\u5BDD\u308B\u3068\u6B7B\u306C\u30A6\u30A4\u30EB\u30B9\u3082\u6D41\u884C\u3089\u305B\u308C\u3070\u307B\u3089",
  "id" : 599600208805138432,
  "created_at" : "2015-05-16 15:40:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599600024553533440",
  "text" : "\u30D1\u30B8\u30E3\u30DE\u7740\u306A\u3044\u3067\u5BDD\u308B\u3068\u6B7B\u306C\u30A6\u30A4\u30EB\u30B9\u6D41\u884C\u3089\u305B\u308B\u304B",
  "id" : 599600024553533440,
  "created_at" : "2015-05-16 15:39:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599599741924573190",
  "text" : "\u4E94\u5104\u5186\u6B32\u3057\u3044\u3067\u3057\u3087\uFF1F",
  "id" : 599599741924573190,
  "created_at" : "2015-05-16 15:38:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599599324473884673",
  "text" : "\u30E1\u30B8\u30E3\u30FC\u306E\u59CB\u7403\u5F0F\u3068\u304B",
  "id" : 599599324473884673,
  "created_at" : "2015-05-16 15:36:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599599251941773315",
  "text" : "\u51FA\u6765\u306A\u3044\u3053\u3068\u304C\u3084\u308A\u305F\u3044\u3093\u3060\u3088\u3001\u79C1\u307F\u305F\u3044\u306A\u5927\u5B66\u9662\u751F\u306F\u3055",
  "id" : 599599251941773315,
  "created_at" : "2015-05-16 15:36:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599598620824862720",
  "text" : "\u300C\u30AB\u30EC\u30FC\u304C\u98DF\u3079\u305F\u3044\u300D\n\u306B\u5BFE\u3057\u3066\n\u300C\u306A\u3093\u3067\u30AB\u30EC\u30FC\u304C\u98DF\u3079\u305F\u3044\u3093\u3067\u3059\u304B\uFF1F\u300D\n\u3063\u3066\u805E\u304B\u308C\u3066\n\u300C\u8F9B\u3044\u304B\u3089\u3067\u3059\u300D\n\u3063\u3066\u7B54\u3048\u305F\u3089\n\u300C\u30AB\u30EC\u30FC\u4EE5\u5916\u306B\u3082\u8F9B\u3044\u3082\u306E\u306F\u3042\u308A\u307E\u3059\u3088\u300D\n\u3063\u3066\u8A00\u308F\u308C\u3066\u3082\u50D5\u306F\u30AB\u30EC\u30FC\u304C\u98DF\u3079\u305F\u3044\u3093\u3060\u3088\uFF01\uFF01\uFF01\uFF01\u3063\u3066\u306A\u308B\u3067\u3057\u3087",
  "id" : 599598620824862720,
  "created_at" : "2015-05-16 15:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599597906107113475",
  "geo" : { },
  "id_str" : "599598074265088000",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u50D5\u306F\u4EBA\u985E\u3092\u6EC5\u307C\u3057\u305F\u3044\u3093\u3067\u3059\u3088",
  "id" : 599598074265088000,
  "in_reply_to_status_id" : 599597906107113475,
  "created_at" : "2015-05-16 15:31:35 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599597512652001280",
  "geo" : { },
  "id_str" : "599597626166652928",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u8AB0\u3082\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u305F\u3076\u3093",
  "id" : 599597626166652928,
  "in_reply_to_status_id" : 599597512652001280,
  "created_at" : "2015-05-16 15:29:48 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 11, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599597373057171456",
  "text" : "\u4EBA\u985E\u6EC5\u4EA1\u3092\u9054\u6210\u3057\u305F\u4EBA #\u4EBA",
  "id" : 599597373057171456,
  "created_at" : "2015-05-16 15:28:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599597060921294848",
  "geo" : { },
  "id_str" : "599597315762954242",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u4EBA\u985E\u6EC5\u4EA1\u3092\u9054\u6210\u3057\u305F\u4EBA\u306B\u306A\u308A\u305F\u3044",
  "id" : 599597315762954242,
  "in_reply_to_status_id" : 599597060921294848,
  "created_at" : "2015-05-16 15:28:34 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599596814048755712",
  "text" : "\u50D5\u306F\u5730\u7403\u74B0\u5883\u3068\u304B\u3069\u3046\u3067\u3082\u3088\u304F\u3066\u305F\u3060\u3072\u305F\u3059\u3089\u306B\u4EBA\u985E\u3092\u6EC5\u307C\u3057\u305F\u3044\u3060\u3051\u306A\u3093\u3067\u3059\u3088",
  "id" : 599596814048755712,
  "created_at" : "2015-05-16 15:26:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599596558993068033",
  "geo" : { },
  "id_str" : "599596699783274496",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u50D5\u306F\u5730\u7403\u74B0\u5883\u3068\u304B\u3069\u3046\u3067\u3082\u3088\u304F\u3066\u305F\u3060\u3072\u305F\u3059\u3089\u306B\u4EBA\u985E\u3092\u6EC5\u307C\u3057\u305F\u3044\u3060\u3051\u306A\u3093\u3067\u3059\u3088",
  "id" : 599596699783274496,
  "in_reply_to_status_id" : 599596558993068033,
  "created_at" : "2015-05-16 15:26:07 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599595827993051136",
  "geo" : { },
  "id_str" : "599596025444048896",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u305D\u308C\u3060\u3068\u3042\u308A\u305D\u3046\u306A\u3093\u3067\u3059\u3088\u306D\u2026\u3061\u3083\u3093\u3068\u4EBA\u985E\u6EC5\u4EA1\u3092\u63B2\u3052\u3066\u304F\u308C\u306A\u3044\u3068",
  "id" : 599596025444048896,
  "in_reply_to_status_id" : 599595827993051136,
  "created_at" : "2015-05-16 15:23:27 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "22\u6642\u306B\u306F\u5E30\u308A\u305F\u3044\u3058\u3087\u30FC\u304B\u30FC",
      "screen_name" : "p_joker1989",
      "indices" : [ 0, 12 ],
      "id_str" : "103616372",
      "id" : 103616372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599595508613533698",
  "geo" : { },
  "id_str" : "599595654927659008",
  "in_reply_to_user_id" : 103616372,
  "text" : "@p_joker1989 \u4EBA\u985E\u6EC5\u4EA1\u3092\u76EE\u6A19\u3068\u3057\u3066\u63B2\u3052\u3066\u3044\u308B\u4F01\u696D",
  "id" : 599595654927659008,
  "in_reply_to_status_id" : 599595508613533698,
  "created_at" : "2015-05-16 15:21:58 +0000",
  "in_reply_to_screen_name" : "p_joker1989",
  "in_reply_to_user_id_str" : "103616372",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599595222306131968",
  "text" : "\u4F01\u696D\u7406\u5FF5\u300C\u4EBA\u985E\u6EC5\u4EA1\u300D\u307F\u305F\u3044\u306A\u4F01\u696D\u306B\u5165\u3063\u3066\u4EBA\u985E\u6EC5\u4EA1\u306E\u305F\u3081\u306B\u6697\u8E8D\u3057\u3066\u3047",
  "id" : 599595222306131968,
  "created_at" : "2015-05-16 15:20:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599594889446170624",
  "text" : "\u4F01\u696D\u300C\u30B0\u30EB\u30FC\u30D7\u30C7\u30A3\u30B9\u30AB\u30C3\u30B7\u30E7\u30F3\u3059\u308B\u3088\uFF01\u7D50\u8AD6\u3058\u3083\u306A\u304F\u3066\u30D7\u30ED\u30BB\u30B9\u3067\u8A55\u4FA1\u3059\u308B\u3088\uFF01\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u4EBA\u985E\u6EC5\u307C\u3057\u305F\u3089\u89E3\u6C7A\u3059\u308B\u3068\u601D\u3046\u3093\u3067\u3059\u3088\u301C(\u8A00\u3044\u304F\u308B\u3081)\u300D\n\u5468\u308A\u306E\u4EBA\u300C\u300C\u300C\u300C\u306A\u308B\u307B\u3069\u8CE2\u3044\u300D\u300D\u300D\u300D\n\n\u307F\u305F\u3044\u306A\u3053\u3068\u3084\u308A\u305F\u3044",
  "id" : 599594889446170624,
  "created_at" : "2015-05-16 15:18:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599593511088889856",
  "text" : "\u3075\u30FC\u3068\u3061\u3083\u3093",
  "id" : 599593511088889856,
  "created_at" : "2015-05-16 15:13:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599537968823447552",
  "text" : "&gt;&gt;\u524D\u56DE\u306E\u30ED\u30B0\u30A4\u30F3\u304B\u3089\u3044\u308D\u3044\u308D\u306A\u3053\u3068\u304C\u3042\u308A\u307E\u3057\u305F\u3002\u304A\u77E5\u3089\u305B\u3092\u30C1\u30A7\u30C3\u30AF\u3057\u3066\u53CB\u9054\u306E\u6700\u65B0\u60C5\u5831\u3092\u898B\u3066\u307F\u307E\u3057\u3087\u3046\u3002\n\n\u3044\u308D\u3044\u308D\u306A\u3053\u3068\u304C\u3042\u308A\u307E\u3057\u305F\u304B\u3001\u3063\u3066\u611F\u3058\u3060",
  "id" : 599537968823447552,
  "created_at" : "2015-05-16 11:32:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4ECA\u65E5\u306E\u307E\u3068\u3081",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599530882374860801",
  "text" : "\u300C\u30BD\u30FC\u30BB\u30FC\u30B8\u306F\u8089\u8089\u3057\u3044\u3057\u3001\u8089\u3063\u3066\u611F\u3058\u300D #\u4ECA\u65E5\u306E\u307E\u3068\u3081",
  "id" : 599530882374860801,
  "created_at" : "2015-05-16 11:04:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599475939303632896",
  "text" : "\u30A2\u30EC\u6D3B\u3088\u3046\u306B\u524D\u5411\u304D\u306B\u4EBA\u683C\u3092\u8ABF\u6574\u3057\u3066\u3044\u308B\u304B\u3089\u77ED\u6240\u3092\u66F8\u3053\u3046\u3068\u3059\u308B\u3068\u77ED\u6240\u98A8\u9577\u6240\u306B\u306A\u308B\uFF08\u306A\u3089\u306A\u3044\uFF09",
  "id" : 599475939303632896,
  "created_at" : "2015-05-16 07:26:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sukiyanogoto",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/6Du1iJa5Nu",
      "expanded_url" : "http:\/\/shindanmaker.com\/193737",
      "display_url" : "shindanmaker.com\/193737"
    } ]
  },
  "geo" : { },
  "id_str" : "599464217033330688",
  "text" : "\u3059\u304D\u5BB6\u3067\u30AB\u30E9\u30FC\u30DC\u30FC\u30EB\u98DF\u3063\u3066\u305F\u3089\u5F37\u76D7\u304C\u5165\u3063\u3066\u304D\u3066\u725B\u4E3C\u304C\u5E97\u54E1\u6295\u3052\u305F #Sukiyanogoto http:\/\/t.co\/6Du1iJa5Nu",
  "id" : 599464217033330688,
  "created_at" : "2015-05-16 06:39:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5341\u6708\u514E@\u6700\u9AD8\u306E\u590F",
      "screen_name" : "nekaya_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "271979824",
      "id" : 271979824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599440735843135488",
  "geo" : { },
  "id_str" : "599441001367736321",
  "in_reply_to_user_id" : 271979824,
  "text" : "@nekaya_bot \u4F4D\u7F6E\u306F\u628A\u63E1\u3057\u305F\u3002\u4ECA\u5EA6\u884C\u3063\u3066\u307F\u308B\u3002",
  "id" : 599441001367736321,
  "in_reply_to_status_id" : 599440735843135488,
  "created_at" : "2015-05-16 05:07:26 +0000",
  "in_reply_to_screen_name" : "nekaya_bot",
  "in_reply_to_user_id_str" : "271979824",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599437686886170624",
  "text" : "\u30CF\u30E2\u30CB\u30AB\uFF1F",
  "id" : 599437686886170624,
  "created_at" : "2015-05-16 04:54:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5341\u6708\u514E@\u6700\u9AD8\u306E\u590F",
      "screen_name" : "nekaya_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "271979824",
      "id" : 271979824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599437301026922497",
  "geo" : { },
  "id_str" : "599437639553388544",
  "in_reply_to_user_id" : 271979824,
  "text" : "@nekaya_bot \u3069\u3053\u3069\u3053",
  "id" : 599437639553388544,
  "in_reply_to_status_id" : 599437301026922497,
  "created_at" : "2015-05-16 04:54:04 +0000",
  "in_reply_to_screen_name" : "nekaya_bot",
  "in_reply_to_user_id_str" : "271979824",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599205507589545984",
  "text" : "\u4ECA\u65E5\u306E\u5C45\u9152\u5C4B\u3055\u3093\u306F\u725B\u4E73\u304C\u3042\u3063\u305F\u304B\u3089\u725B\u4E73\u3092\u3044\u3063\u3071\u3044\u98F2\u307F\u307E\u3057\u305F",
  "id" : 599205507589545984,
  "created_at" : "2015-05-15 13:31:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599139486279176192",
  "text" : "\u4F55\u3068\u304B\u30B7\u30FC\u30C8\u306B\u66F8\u304D\u3065\u3089\u3044\u3053\u3068\u3053\u306E\u4E0A\u306A\u3057",
  "id" : 599139486279176192,
  "created_at" : "2015-05-15 09:09:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599139439881768960",
  "text" : "\u82E6\u624B\u306A\u3082\u306E\u306B\u3064\u3044\u3066Twilog\u3067\u8ABF\u3079\u305F\u3089\u300C\u4E8C\u56DE\u624B\u3092\u53E9\u3044\u3066\u6E9C\u3081\u653B\u6483\u9632\u5FA1\u306E\u30DD\u30FC\u30BA\u3092\u53D6\u308B\u5974\u300D\u300C\u3075\u3041\u3076\u3075\u3043\u3076\u300D\u300C\u6697\u8A18\u300D\u300C\u30D3\u30FC\u30EB\u300D\u300C\u8912\u3081\u308B\u3053\u3068\u300D\u300C\u8912\u3081\u3089\u308C\u308B\u3053\u3068\u300D\u304C\u30D2\u30C3\u30C8\u3057\u305F",
  "id" : 599139439881768960,
  "created_at" : "2015-05-15 09:09:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599121373387051009",
  "text" : "\u304D\u308B\u3075\u3041\u300C\u304A\u5E97\u306B\u96FB\u8A71\u7E4B\u304C\u3089\u306A\u3044\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u5FC3\u304C\u7DBA\u9E97\u306A\u4EBA\u3058\u3083\u306A\u3044\u3068\u7E4B\u304C\u3089\u306A\u3044\u3093\u3060\u3088\u300D\n\u304D\u308B\u3075\u3041\u300C\u3058\u3083\u3042\u304A\u524D\u304B\u3051\u308D\u3088\u300D\n\u3048\u3093\u3069\u3055\u3093\u300COK\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3064\u306A\u304C\u3089\u306A\u3044\u2026\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u7E4B\u304C\u3063\u305F\u300D\n\u304D\u308B\u3075\u3041\u300C\u300D",
  "id" : 599121373387051009,
  "created_at" : "2015-05-15 07:57:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599084835005562880",
  "text" : "\u6628\u65E5\u304B\u3089\u5BD2\u3059\u304E\u3084\u3057\u307E\u305B\u3093\u304B\u306D",
  "id" : 599084835005562880,
  "created_at" : "2015-05-15 05:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598852886563594240",
  "text" : "\u3044\u3042\uFF01\u3044\u3042\uFF01\u306F\u3059\u305F\u3042\uFF01",
  "id" : 598852886563594240,
  "created_at" : "2015-05-14 14:10:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30AF\u30C8\u30A5\u30EB\u30D510\u9023\u30AC\u30C1\u30E3",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/GG2K5mMZB0",
      "expanded_url" : "http:\/\/shindanmaker.com\/454757",
      "display_url" : "shindanmaker.com\/454757"
    } ]
  },
  "geo" : { },
  "id_str" : "598852814098464768",
  "text" : "SR:\u30CF\u30B9\u30BF\u30FC\nN:\u30DF\uFF1D\u30B4\nHN:\u30CE\u30D5\uFF1D\u30B1\u30FC\nN:\u6DF1\u304D\u3082\u306E\nN:\u30CD\u30BA\u30DF\u602A\u7269\nN:\u30CD\u30BA\u30DF\u602A\u7269\nR:\u30C0\u30B4\u30F3\nN:\u30D8\u30D3\u4EBA\u9593\nR:\u30C0\u30B4\u30F3\nR:\u30A2\u30A4\u30DB\u30FC\u30C8\n#\u30AF\u30C8\u30A5\u30EB\u30D510\u9023\u30AC\u30C1\u30E3\nhttp:\/\/t.co\/GG2K5mMZB0",
  "id" : 598852814098464768,
  "created_at" : "2015-05-14 14:10:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598852297519603712",
  "text" : "\u5FCD\u6BBA\u3001\u30EC\u30A4\u30B8\u30A2\u30B2\u30A4\u30CB\u30B9\u30C8\u30C8\u30FC\u30D5\u306A\u306E\uFF1F\uFF01\u5B8C\u74A7\u306A\u91C7\u914D\u3060\uFF01",
  "id" : 598852297519603712,
  "created_at" : "2015-05-14 14:08:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598851144996106240",
  "text" : "\u97F3\u97FF\u304C",
  "id" : 598851144996106240,
  "created_at" : "2015-05-14 14:03:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598850588105781248",
  "text" : "\u304F\u306A\u3068\u304C\u6249\u306E\u524D\u3067\u6CE3\u304F\u30B7\u30FC\u30F3\u306E\u6B21\u306B\u597D\u304D\u306A\u30B7\u30FC\u30F3\u3060",
  "id" : 598850588105781248,
  "created_at" : "2015-05-14 14:01:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598850458879307776",
  "text" : "\u6765\u9031\u306F\u7E88\u306E\u30D7\u30E9\u30E2\u30C7\u30EB\u5C4B\u3055\u3093\u306E\u30B7\u30FC\u30F3\u304B\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 598850458879307776,
  "created_at" : "2015-05-14 14:00:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598850123053928448",
  "text" : "\u306A\u3093\u3060\u3042\u306E\u751F\u304D\u7269\u53EF\u611B\u3059\u304E\u308B",
  "id" : 598850123053928448,
  "created_at" : "2015-05-14 13:59:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598850014236909569",
  "text" : "\u30B7\u30C9\u30CB\u30A2\u4E94\u8A71\u3001\u3072\u305F\u3059\u3089\u306B\u3064\u3080\u304E\u304C\u304B\u308F\u3044\u3044",
  "id" : 598850014236909569,
  "created_at" : "2015-05-14 13:59:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598774428294459392",
  "text" : "\u3081\u3046\u3081\u3046\u306E\u3053\u3068\u307B\u3068\u3093\u3069\u77E5\u3089\u306A\u3044\u3051\u3069\u30AD\u30E3\u30E9\u3068\u3057\u3066\u306E\u6271\u3044\u306E\u5909\u9077\u3001\u3072\u305F\u3059\u3089\u4E0D\u61AB",
  "id" : 598774428294459392,
  "created_at" : "2015-05-14 08:58:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598756577676374017",
  "text" : "\u304B\u306A\u3089\u305A\u3057\u3082\u8F9B\u3044\u3068\u306F\u9650\u3089\u306A\u3044\u3068\u304D\u306B\u4E0A\u3052\u308B\u672D",
  "id" : 598756577676374017,
  "created_at" : "2015-05-14 07:47:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598753818709401601",
  "text" : "\u9A0E\u58EB\u884C\u9032\u66F2",
  "id" : 598753818709401601,
  "created_at" : "2015-05-14 07:36:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598747929042497536",
  "text" : "\u3086\u3086\u5F0F",
  "id" : 598747929042497536,
  "created_at" : "2015-05-14 07:13:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79E6\u4FCA",
      "screen_name" : "mafmof31",
      "indices" : [ 3, 12 ],
      "id_str" : "255039109",
      "id" : 255039109
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mafmof31\/status\/598678060775256065\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/xIIoRlcxSq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7ugwAVEAAm8H6.jpg",
      "id_str" : "598678046896361472",
      "id" : 598678046896361472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7ugwAVEAAm8H6.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/xIIoRlcxSq"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/mafmof31\/status\/598678060775256065\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/xIIoRlcxSq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7ugwRUMAAkUMt.jpg",
      "id_str" : "598678046967607296",
      "id" : 598678046967607296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7ugwRUMAAkUMt.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/xIIoRlcxSq"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/mafmof31\/status\/598678060775256065\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/xIIoRlcxSq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7ugv3UUAA11r9.jpg",
      "id_str" : "598678046858563584",
      "id" : 598678046858563584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7ugv3UUAA11r9.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/xIIoRlcxSq"
    } ],
    "hashtags" : [ {
      "text" : "yuyushiki",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598747886608723970",
  "text" : "RT @mafmof31: \u3068\u3044\u3046\u308F\u3051\u3067\u30015\/26\u306BLIVE DAM\u3067\u300C\u30C9\u30AD\u30C9\u30AD\u307E\u306B\u307E\u306B\u300D\u300Cfriends\u300D\u300C\u3053\u308C\u306F\u7531\u3005\u3057\u304D\u4E8B\u614B\u3067\u3059\uFF01~\u672C\u5F53\u306F\u672C\u5F53\u306F\u2026\u30CA\u30CE~\u300D\u914D\u4FE1\u307F\u305F\u3044\u3067\u3059\u3002 #yuyushiki http:\/\/t.co\/xIIoRlcxSq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mafmof31\/status\/598678060775256065\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/xIIoRlcxSq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7ugwAVEAAm8H6.jpg",
        "id_str" : "598678046896361472",
        "id" : 598678046896361472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7ugwAVEAAm8H6.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/xIIoRlcxSq"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/mafmof31\/status\/598678060775256065\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/xIIoRlcxSq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7ugwRUMAAkUMt.jpg",
        "id_str" : "598678046967607296",
        "id" : 598678046967607296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7ugwRUMAAkUMt.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/xIIoRlcxSq"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/mafmof31\/status\/598678060775256065\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/xIIoRlcxSq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7ugv3UUAA11r9.jpg",
        "id_str" : "598678046858563584",
        "id" : 598678046858563584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7ugv3UUAA11r9.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/xIIoRlcxSq"
      } ],
      "hashtags" : [ {
        "text" : "yuyushiki",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598678060775256065",
    "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u30015\/26\u306BLIVE DAM\u3067\u300C\u30C9\u30AD\u30C9\u30AD\u307E\u306B\u307E\u306B\u300D\u300Cfriends\u300D\u300C\u3053\u308C\u306F\u7531\u3005\u3057\u304D\u4E8B\u614B\u3067\u3059\uFF01~\u672C\u5F53\u306F\u672C\u5F53\u306F\u2026\u30CA\u30CE~\u300D\u914D\u4FE1\u307F\u305F\u3044\u3067\u3059\u3002 #yuyushiki http:\/\/t.co\/xIIoRlcxSq",
    "id" : 598678060775256065,
    "created_at" : "2015-05-14 02:35:47 +0000",
    "user" : {
      "name" : "\u79E6\u4FCA",
      "screen_name" : "mafmof31",
      "protected" : false,
      "id_str" : "255039109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483971972536102912\/E87wHWfd_normal.jpeg",
      "id" : 255039109,
      "verified" : false
    }
  },
  "id" : 598747886608723970,
  "created_at" : "2015-05-14 07:13:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598745563329220608",
  "text" : "\u30AB\u30E9\u30AA\u30B1\u884C\u304D\u305F\u3044\u9854",
  "id" : 598745563329220608,
  "created_at" : "2015-05-14 07:04:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598745281300070400",
  "text" : "\u30B7\u30C9\u30CB\u30A25\u8A71\u898B\u3088\u3046\u3068\u601D\u3063\u305F\u304C\u304A\u5BB6\u5E30\u3063\u3066\u304B\u3089\u306B\u3057\u3088\u3046",
  "id" : 598745281300070400,
  "created_at" : "2015-05-14 07:02:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598745224748212225",
  "text" : "\u30A4\u30E4\u30D5\u30A9\u30F3\u3092\u5FD8\u308C\u308B\u624B\u75DB\u3044\u30DF\u30B9\u306A",
  "id" : 598745224748212225,
  "created_at" : "2015-05-14 07:02:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598744917230235648",
  "text" : "nyonyonyo",
  "id" : 598744917230235648,
  "created_at" : "2015-05-14 07:01:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/598694077266206722\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/nv5kP0IADc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE79FqAVAAEb27Z.png",
      "id_str" : "598694074103693313",
      "id" : 598694074103693313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE79FqAVAAEb27Z.png",
      "sizes" : [ {
        "h" : 222,
        "resize" : "fit",
        "w" : 471
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 471
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 471
      } ],
      "display_url" : "pic.twitter.com\/nv5kP0IADc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598693846797529089",
  "geo" : { },
  "id_str" : "598694077266206722",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ http:\/\/t.co\/nv5kP0IADc",
  "id" : 598694077266206722,
  "in_reply_to_status_id" : 598693846797529089,
  "created_at" : "2015-05-14 03:39:25 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598693216624345088",
  "geo" : { },
  "id_str" : "598693520182915073",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u4F53\u3092\u5F35\u3063\u305F\u30CD\u30BF",
  "id" : 598693520182915073,
  "in_reply_to_status_id" : 598693216624345088,
  "created_at" : "2015-05-14 03:37:13 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 0, 10 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 11, 20 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598691742662074368",
  "geo" : { },
  "id_str" : "598691989819797504",
  "in_reply_to_user_id" : 155546700,
  "text" : "@end313124 @acmn13_2 \u5B9F\u969B\u30A2\u30EC\u6D3B\u3067\u6771\u4EAC\u3067\u4F1A\u3048\u308B\u30D1\u30BF\u30FC\u30F3\u306F\u3042\u308A\u305D\u3046\u306A",
  "id" : 598691989819797504,
  "in_reply_to_status_id" : 598691742662074368,
  "created_at" : "2015-05-14 03:31:08 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598691645534535680",
  "geo" : { },
  "id_str" : "598691742662074368",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u50D5\u306F\u4EBA\u3060\u304B\u3089\u306D",
  "id" : 598691742662074368,
  "in_reply_to_status_id" : 598691645534535680,
  "created_at" : "2015-05-14 03:30:09 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598691365808013313",
  "geo" : { },
  "id_str" : "598691466819448832",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u50D5\u3082\u3048\u3093\u3069\u3055\u3093\u306B\u3042\u3044\u305F\u3044",
  "id" : 598691466819448832,
  "in_reply_to_status_id" : 598691365808013313,
  "created_at" : "2015-05-14 03:29:03 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598690547193131008",
  "text" : "\u6C17\u9055\u3044\u306E\u4EBA\u3060\u3063\u305F",
  "id" : 598690547193131008,
  "created_at" : "2015-05-14 03:25:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598690494802042883",
  "text" : "\u6C17\u9063\u3044\u306E\u4EBA\u3060\u304B\u3089\u81EA\u5206\u3067\u98DF\u3079\u308B\u304A\u5F01\u5F53\u306E\u5510\u63DA\u3052\u306B\u30EC\u30E2\u30F3\u304B\u3051\u3066\u3044\u3044\u304B\u5468\u308A\u306E\u4EBA\u306B\u3061\u3083\u3093\u3068\u805E\u304F",
  "id" : 598690494802042883,
  "created_at" : "2015-05-14 03:25:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/598687600828764163\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/H49wY8bYA6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE73MqUVEAAQPiK.jpg",
      "id_str" : "598687597376901120",
      "id" : 598687597376901120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE73MqUVEAAQPiK.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/H49wY8bYA6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598687600828764163",
  "text" : "\u305F\u307E\u3054\u4E09\u9283\u58EB\u3092\u9023\u308C\u3066\u304D\u305F\u3088\uFF01 http:\/\/t.co\/H49wY8bYA6",
  "id" : 598687600828764163,
  "created_at" : "2015-05-14 03:13:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598675348012695553",
  "text" : "\u672D\u5E4C\u304B\u3089\u6771\u4EAC\u306E\u30DD\u30FC\u30BF\u30EB\u4FDD\u5B88\u3059\u308B\u306E\u3057\u3093\u3069\u3044\u2026",
  "id" : 598675348012695553,
  "created_at" : "2015-05-14 02:25:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598507625647443968",
  "geo" : { },
  "id_str" : "598508005273903104",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u307B\u3068\u3093\u3069\u8AB0\u306B\u3082\u8A00\u3063\u3066\u306A\u3044\u304B\u3089\u306D\u3001\u4EBA\u985E\u6EC5\u4EA1\u306F\u3001\u4EBA\u985E\u6EC5\u4EA1\u3057\u305F\u3089\u5C31\u6D3B\u3057\u306A\u304F\u3066\u3044\u3044\u306E\u306B\u306A\u30FC\u30EC\u30D9\u30EB\u306E\u8A71\u3060\u304B\u3089",
  "id" : 598508005273903104,
  "in_reply_to_status_id" : 598507625647443968,
  "created_at" : "2015-05-13 15:20:02 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598507251062571008",
  "text" : "\u304D\u3087\u3046\u306F\u306F\u3084\u304A\u304D\u3060",
  "id" : 598507251062571008,
  "created_at" : "2015-05-13 15:17:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598507221866020864",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u307E\u3061",
  "id" : 598507221866020864,
  "created_at" : "2015-05-13 15:16:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598504467231735808",
  "text" : "\u81EA\u5DF1\u5206\u6790\u3057\u3066\u3066\u3055\u3001\u5C06\u6765\u306E\u5922\u3092\u5C0F\u5B66\u6821\u304B\u3089\u9806\u306B\u66F8\u3044\u3066\u3063\u305F\u6642\u306B\u3055\n\u5C0F\u5B66\u6821:\u8A18\u61B6\u306A\u3057\n\u4E2D\u5B66\u6821:\u533B\u8005\n\u9AD8\u6821:\u4F5C\u5BB6\n\u5927\u5B66\u751F:\u5168\u77E5\u5168\u80FD\n\u5927\u5B66\u9662\u751F:\u4EBA\u985E\u6EC5\u4EA1\n\u3063\u3066\u306A\u3063\u3066\u81EA\u5DF1\u5206\u6790\u30AF\u30BD\u3060\u306A\u3063\u3066\u601D\u3063\u305F",
  "id" : 598504467231735808,
  "created_at" : "2015-05-13 15:05:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598503732448374784",
  "text" : "\u5168\u4EBA\u985E\u6EC5\u307C\u305B\u3070\u5168\u3066\u304C\u89E3\u6C7A\u3059\u308B",
  "id" : 598503732448374784,
  "created_at" : "2015-05-13 15:03:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598503494836858880",
  "text" : "\u3081\u3063\uFF01\u3042\u30FC\u3063\u3066\u8A00\u308F\u306A\u3044\u306E\uFF01",
  "id" : 598503494836858880,
  "created_at" : "2015-05-13 15:02:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598503028602241024",
  "text" : "\u65B9\u3005\u306B\u8B0E\u306E\u6587\u5316\u3068\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u69D8\u5F0F\u3092\u4F1D\u64AD\u3057\u3066\u3057\u307E\u3063\u305F\u611F\u3058\u306F\u5426\u3081\u306A\u3044",
  "id" : 598503028602241024,
  "created_at" : "2015-05-13 15:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598502806438313984",
  "text" : "\u79C1\u306F\uFF01\uFF01\u4ED6\u4EBA\u306B\u5F71\u97FF(\u826F\u3044\u5F71\u97FF\u3068\u306F\u8A00\u3063\u3066\u306A\u3044)\u3092\u4E0E\u3048\u3089\u308C\u308B\u4EBA\u9593\u3067\u3059\uFF01\uFF01\uFF01\uFF01\u5185\u5B9A\u304F\u3060\u3055\u3044\uFF01\uFF01\uFF01",
  "id" : 598502806438313984,
  "created_at" : "2015-05-13 14:59:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598502633964380160",
  "text" : "RT @haguruma20: end \u3055\u3093\u3001\u65B9\u3005\u306B\u722A\u75D5\u6B8B\u3057\u904E\u304E\u3067\u306F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598502557292462080",
    "text" : "end \u3055\u3093\u3001\u65B9\u3005\u306B\u722A\u75D5\u6B8B\u3057\u904E\u304E\u3067\u306F",
    "id" : 598502557292462080,
    "created_at" : "2015-05-13 14:58:23 +0000",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 598502633964380160,
  "created_at" : "2015-05-13 14:58:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598502494470164480",
  "text" : "\u8DB3\u63DA\u3052\u3066\u307F\uFF1F\u3063\u3066\u8A98\u5C0E\u3057\u3066\u304B\u3089\u63DA\u3052\u8DB3\u3068\u3063\u305F\u308A\u3059\u308B",
  "id" : 598502494470164480,
  "created_at" : "2015-05-13 14:58:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598502082203619328",
  "geo" : { },
  "id_str" : "598502228895248384",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4EBA\u306E\u8A71\u3092\u805E\u304B\u305A\u306B\u3001\u3042\u3052\u3066\u3082\u3044\u306A\u3044\u8DB3\u3092\u53D6\u308C\u308B\u3088\u3046\u306B\u306A\u308D\u3046\u306A",
  "id" : 598502228895248384,
  "in_reply_to_status_id" : 598502082203619328,
  "created_at" : "2015-05-13 14:57:05 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598501925894533120",
  "text" : "\u52E2\u3044\u3067\u66F8\u304F\u3068\u65E5\u672C\u8A9E\u304C\u4E71\u308C\u308B",
  "id" : 598501925894533120,
  "created_at" : "2015-05-13 14:55:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598501656578297856",
  "text" : "\u6614\u306E\u3001\u7B52\u72B6\u306E\u8D64\u3044\u30DD\u30B9\u30C8",
  "id" : 598501656578297856,
  "created_at" : "2015-05-13 14:54:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598501496783667202",
  "text" : "\u5E2F\u5E83\u306E\u30DB\u30FC\u30E0\u30BB\u30F3\u30BF\u30FC\u3067\u3001\u7B52\u72B6\u306E\u6614\u306E\u8D64\u3044\u30DD\u30B9\u30C8\u306B\u4F3C\u305F\u30C7\u30B6\u30A4\u30F3\u306E\u30DD\u30B9\u30C8\u304C4\u4E07\u304F\u3089\u3044\u3067\u58F2\u3063\u3066\u305F\u3093\u3060\u3088\u306A",
  "id" : 598501496783667202,
  "created_at" : "2015-05-13 14:54:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598500233023098880",
  "text" : "\u304B\u306A\u3089\u305A\u3057\u3082\u307B\u3057\u304F\u306A\u3044",
  "id" : 598500233023098880,
  "created_at" : "2015-05-13 14:49:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/598500044052897793\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/zmK4Vx07zm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE5MneRUUAEstyP.png",
      "id_str" : "598500041511161857",
      "id" : 598500041511161857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE5MneRUUAEstyP.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zmK4Vx07zm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598500044052897793",
  "text" : "\u8A00\u8CEA http:\/\/t.co\/zmK4Vx07zm",
  "id" : 598500044052897793,
  "created_at" : "2015-05-13 14:48:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598499215803744256",
  "geo" : { },
  "id_str" : "598499748140617728",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u30DD\u30B9\u30C8\u307B\u3069\u30D9\u30B9\u30C8\u30DE\u30C3\u30C1\u611F\u304C\u306A\u3044\u3093\u3067\u3059\u3088\u306D\u30FC\u3001\u3067\u3082\u307B\u3057\u3044\u3082\u306E\u30EA\u30B9\u30C8\u306B\u5165\u308C\u307E\u3057\u305F",
  "id" : 598499748140617728,
  "in_reply_to_status_id" : 598499215803744256,
  "created_at" : "2015-05-13 14:47:14 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon.co.jp (\u30A2\u30DE\u30BE\u30F3)",
      "screen_name" : "AmazonJP",
      "indices" : [ 74, 83 ],
      "id_str" : "161616614",
      "id" : 161616614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/kAu7X9AloX",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/4396340419\/ref=cm_sw_r_tw_awdo_To2uvb0XR3EJZ",
      "display_url" : "amazon.co.jp\/dp\/4396340419\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598499596260642817",
  "text" : "\u5185\u5075 \u8B66\u8996\u5E81\u8FF7\u5BAE\u635C\u67FB\u73ED (\u7965\u4F1D\u793E\u6587\u5EAB) \u7965\u4F1D\u793E#\u30A2\u30DE\u30BE\u30F3\u30DD\u30C1 \u3068\u5165\u308C\u3066@\u8FD4\u4FE1\u3067\u30AB\u30FC\u30C8\u306B\u8FFD\u52A0\u30FB\u5F8C\u3067\u8CB7\u3046 http:\/\/t.co\/kAu7X9AloX @amazonJP\u3055\u3093\u304B\u3089\n\u307B\u3057\u3044\u3082\u306E\u30EA\u30B9\u30C8\u306B\u5165\u308C\u307E\u3057\u305F\u3001\u307C\u304F\u306B\u306A\u3044\u3066\u3044\u3092\u9001\u308A\u305F\u3044\u4EBA\u306F\u3069\u3046\u305E",
  "id" : 598499596260642817,
  "created_at" : "2015-05-13 14:46:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598498661975240704",
  "text" : "\u7814\u7A76\u8005\u5FD7\u671B\u306E\u4EBA\u306B\u30DD\u30B9\u30C8\u3092\u9001\u308A\u3064\u3051\u308B\u30CD\u30BF\u3001\u662F\u975E\u3084\u308A\u305F\u3044",
  "id" : 598498661975240704,
  "created_at" : "2015-05-13 14:42:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598497183155924992",
  "text" : "\u3058\u3083\u3042\u8A00\u308F\u305B\u3066\u3082\u3089\u3044\u307E\u3059\u3051\u3069\u3001\u79C1\u306F\u5168\u77E5\u5168\u80FD\u306B\u306A\u308A\u305F\u3044",
  "id" : 598497183155924992,
  "created_at" : "2015-05-13 14:37:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598374427793850369",
  "geo" : { },
  "id_str" : "598374597986156545",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u5728\u5EAB\u30A2\u30EA",
  "id" : 598374597986156545,
  "in_reply_to_status_id" : 598374427793850369,
  "created_at" : "2015-05-13 06:29:56 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598374356759154688",
  "geo" : { },
  "id_str" : "598374398324711424",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u79C1\u3082\u305D\u3093\u306A\u611F\u3058\u3060",
  "id" : 598374398324711424,
  "in_reply_to_status_id" : 598374356759154688,
  "created_at" : "2015-05-13 06:29:08 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598373528782508032",
  "text" : "\u7A7A\u8179\u306A",
  "id" : 598373528782508032,
  "created_at" : "2015-05-13 06:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598361344421728256",
  "geo" : { },
  "id_str" : "598361378995326978",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 598361378995326978,
  "in_reply_to_status_id" : 598361344421728256,
  "created_at" : "2015-05-13 05:37:24 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598356401669341184",
  "text" : "\u624B\u66F8\u304D\u3063\u3066\u66F8\u3044\u3066\u306A\u3044ES\u306F\u624B\u66F8\u304D\u3057\u306D\u30FC\u305E",
  "id" : 598356401669341184,
  "created_at" : "2015-05-13 05:17:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598329844582064128",
  "text" : "\u304A\u3068\u306A\u3057\u304F\u304A\u5BB6\u3067\u4F5C\u696D\u3059\u308B\u304B\u2026",
  "id" : 598329844582064128,
  "created_at" : "2015-05-13 03:32:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598329513198551041",
  "geo" : { },
  "id_str" : "598329776609173504",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u304B\u308F\u3044\u3044\u3093\u3067\u3059\u304C\u3080\u3080\u3080\u3063\u3066\u611F\u3058\u3067\u3059\u306F\u3044",
  "id" : 598329776609173504,
  "in_reply_to_status_id" : 598329513198551041,
  "created_at" : "2015-05-13 03:31:49 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598329332633706496",
  "text" : "\u3058\u3083\u306A\u3044\u65B9\u305F\u3061",
  "id" : 598329332633706496,
  "created_at" : "2015-05-13 03:30:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598329293152722944",
  "text" : "\u7B2C\u516D\u99C6\u9010\u968A\u306F\u96F7\u96FB\u3058\u3083\u306A\u3044\u65B9\u305F\u3061\u306E\u65B9\u304C\u597D\u304D",
  "id" : 598329293152722944,
  "created_at" : "2015-05-13 03:29:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598329025426141184",
  "geo" : { },
  "id_str" : "598329159937470466",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u304B\u308F\u3044\u3044\u3067\u3059\u304C\u5927\u5B66\u884C\u304F\u30E2\u30C1\u30D9\u3060\u3060\u4E0B\u304C\u308A\u306A\u3093\u3067\u3059\u3088\u306D",
  "id" : 598329159937470466,
  "in_reply_to_status_id" : 598329025426141184,
  "created_at" : "2015-05-13 03:29:22 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598328970581413888",
  "text" : "\u3059\u3054\u3044\u304B\u307F\u306A\u308A",
  "id" : 598328970581413888,
  "created_at" : "2015-05-13 03:28:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598328753203204097",
  "text" : "\u96F7",
  "id" : 598328753203204097,
  "created_at" : "2015-05-13 03:27:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598119257407262720",
  "text" : "\u79CB\u8449\u539F\u306E\u30D0\u30FC\u30AB\u30FC\u30AD\u30F3\u30B0\u3067\u81EA\u5206\u304C\u8FFD\u3044\u304B\u3051\u3066\u3044\u308B\u30A2\u30A4\u30C9\u30EB\u30B0\u30EB\u30FC\u30D7\u306E\u5B8C\u5168\u7121\u6B20\u3055\u306B\u3064\u3044\u3066\u71B1\u304F\u8A9E\u308B\u30A2\u30A4\u30C9\u30EB\u30AA\u30BF\u30AF\u3001\u3081\u3063\u3061\u3083\u9762\u767D\u304B\u3063\u305F",
  "id" : 598119257407262720,
  "created_at" : "2015-05-12 13:35:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598118158889660416",
  "text" : "\u79CB\u8449\u539F\u306E\u30DD\u30FC\u30BF\u30EB\u306F\u3084\u3070\u304B\u3063\u305F",
  "id" : 598118158889660416,
  "created_at" : "2015-05-12 13:30:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3080",
      "screen_name" : "tm_akt",
      "indices" : [ 3, 10 ],
      "id_str" : "544131735",
      "id" : 544131735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598118126035734528",
  "text" : "RT @tm_akt: \u30EA\u30A2\u30EB\u30BF\u30A4\u30E0\u3067\u7DD1\u30DD\u30FC\u30BF\u30EB\u304C\u9752\u30DD\u30FC\u30BF\u30EB\u306B\u5909\u308F\u308B\u77AC\u9593\u3092\u898B\u3066\u3057\u307E\u3063\u3066\u8208\u596E\u3057\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/#!\/ABS104a\" rel=\"nofollow\"\u003EBiyon\u2261(\u3000\u03B5:)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598117990597427204",
    "text" : "\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0\u3067\u7DD1\u30DD\u30FC\u30BF\u30EB\u304C\u9752\u30DD\u30FC\u30BF\u30EB\u306B\u5909\u308F\u308B\u77AC\u9593\u3092\u898B\u3066\u3057\u307E\u3063\u3066\u8208\u596E\u3057\u305F",
    "id" : 598117990597427204,
    "created_at" : "2015-05-12 13:30:16 +0000",
    "user" : {
      "name" : "\u3066\u3080",
      "screen_name" : "tm_akt",
      "protected" : false,
      "id_str" : "544131735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550321264816963585\/ocLRyBBZ_normal.jpeg",
      "id" : 544131735,
      "verified" : false
    }
  },
  "id" : 598118126035734528,
  "created_at" : "2015-05-12 13:30:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598117034249965568",
  "text" : "\u3067\u3082\u3053\u306E\u8A3A\u65AD\u305F\u3076\u30933d6\u306E\u51FA\u76EE\u306E\u504F\u308A\u3068\u9055\u3046\u3068\u601D\u308F\u308C",
  "id" : 598117034249965568,
  "created_at" : "2015-05-12 13:26:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598116586931625984",
  "geo" : { },
  "id_str" : "598116770709274624",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u6728\u5076\u306E\u574A",
  "id" : 598116770709274624,
  "in_reply_to_status_id" : 598116586931625984,
  "created_at" : "2015-05-12 13:25:25 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598116559773536256",
  "geo" : { },
  "id_str" : "598116713578672129",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 pow\u304C\u4F4E\u3044\u304B\u3089\u521D\u671FSAN\u304C\u8F9B\u3044\u3001\u4ED6\u306F\u5F37\u3044\u304C",
  "id" : 598116713578672129,
  "in_reply_to_status_id" : 598116559773536256,
  "created_at" : "2015-05-12 13:25:11 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598115939561811968",
  "geo" : { },
  "id_str" : "598116217581281281",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma 2m\u8D85\u3060\u3068\u601D\u308F\u307E\u3059",
  "id" : 598116217581281281,
  "in_reply_to_status_id" : 598115939561811968,
  "created_at" : "2015-05-12 13:23:13 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598115768488710144",
  "geo" : { },
  "id_str" : "598115872561999872",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh dex\u4EE5\u5916\u7533\u3057\u5206\u306A\u3057",
  "id" : 598115872561999872,
  "in_reply_to_status_id" : 598115768488710144,
  "created_at" : "2015-05-12 13:21:51 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598115354003443713",
  "text" : "\u521D\u671FSAN15\u306E\u6FC0\u30E4\u30D0\u30B9\u30C6\u30FC\u30BF\u30B9\u3060",
  "id" : 598115354003443713,
  "created_at" : "2015-05-12 13:19:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/pxiOX6DeTK",
      "expanded_url" : "http:\/\/shindanmaker.com\/389308",
      "display_url" : "shindanmaker.com\/389308"
    } ]
  },
  "geo" : { },
  "id_str" : "598115243999395840",
  "text" : "end313124\u306F\nSTR(\u7B4B\u529B):7\nCON(\u4F53\u529B):7\nSIZ(\u4F53\u683C):13\nDEX(\u654F\u6377):9\nAPP(\u5916\u898B):14\nINT(\u77E5\u6027):11\nPOW(\u7CBE\u795E\u529B):3\nEDU(\u6559\u80B2):8\nhttp:\/\/t.co\/pxiOX6DeTK",
  "id" : 598115243999395840,
  "created_at" : "2015-05-12 13:19:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598115055335440386",
  "text" : "\u7CBE\u795E\u5206\u6790\uFF01",
  "id" : 598115055335440386,
  "created_at" : "2015-05-12 13:18:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598113895425843200",
  "text" : "\u82E6\u624B\u3067\u306F\u306A\u3044\u304CSAN\u306F\u4E0B\u304C\u308B",
  "id" : 598113895425843200,
  "created_at" : "2015-05-12 13:13:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598113840211963904",
  "text" : "SAN\u304C\u4E0B\u304C\u3063\u305F",
  "id" : 598113840211963904,
  "created_at" : "2015-05-12 13:13:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598113806493949952",
  "text" : "RT @haguruma20: \u30B9\u30B1\u30C3\u30C1\u30D6\u30C3\u30AF\u3067\u3059\u3089\u63CF\u304F\u306E\u3092\u8E8A\u8E87\u3063\u305F\u30B3\u30E2\u30EA\u30AC\u30A8\u30EB\u3001\u8ABF\u3079\u3066\u307F\u305F\u3089\u5B8C\u5168\u306B\u84EE\u30B3\u30E9\u3060\u3063\u305F\u3057\u306A\u308B\u307B\u3069\u3060(\u82E6\u624B\u306A\u3089\u8ABF\u3079\u306A\u3044\u307B\u3046\u304C\u826F\u3044\u3067\u3059)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598113619562213377",
    "text" : "\u30B9\u30B1\u30C3\u30C1\u30D6\u30C3\u30AF\u3067\u3059\u3089\u63CF\u304F\u306E\u3092\u8E8A\u8E87\u3063\u305F\u30B3\u30E2\u30EA\u30AC\u30A8\u30EB\u3001\u8ABF\u3079\u3066\u307F\u305F\u3089\u5B8C\u5168\u306B\u84EE\u30B3\u30E9\u3060\u3063\u305F\u3057\u306A\u308B\u307B\u3069\u3060(\u82E6\u624B\u306A\u3089\u8ABF\u3079\u306A\u3044\u307B\u3046\u304C\u826F\u3044\u3067\u3059)",
    "id" : 598113619562213377,
    "created_at" : "2015-05-12 13:12:53 +0000",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 598113806493949952,
  "created_at" : "2015-05-12 13:13:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598113039200583681",
  "geo" : { },
  "id_str" : "598113206867918848",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3042\u3063\u3066\u307E\u3059\u3088\u3001\u3053\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u306F\u305D\u306Ebot\u306E\u30A4\u30E9\u30B9\u30C8\u5316\u3067\u3059\u304B\u3089",
  "id" : 598113206867918848,
  "in_reply_to_status_id" : 598113039200583681,
  "created_at" : "2015-05-12 13:11:15 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/bdyjPox2Yh",
      "expanded_url" : "https:\/\/twitter.com\/Tom_puiiiii\/status\/274466820960960512",
      "display_url" : "twitter.com\/Tom_puiiiii\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598111951256834048",
  "geo" : { },
  "id_str" : "598112861211140097",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u9055\u3046\u3088\u30FC https:\/\/t.co\/bdyjPox2Yh",
  "id" : 598112861211140097,
  "in_reply_to_status_id" : 598111951256834048,
  "created_at" : "2015-05-12 13:09:53 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598105560752357376",
  "geo" : { },
  "id_str" : "598105640838377472",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 (\u4E21\u65B9\u884C\u3051\u3070\u826F\u3044)",
  "id" : 598105640838377472,
  "in_reply_to_status_id" : 598105560752357376,
  "created_at" : "2015-05-12 12:41:11 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 27, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598104941232685056",
  "text" : "\u5BFF\u547D\u304C\u3081\u3061\u3083\u3081\u3061\u3083\u9577\u3044\u3051\u3069\u4ED6\u306B\u53D6\u308A\u7ACB\u3066\u3066\u9577\u6240\u304C\u306A\u3044\u4EBA #\u4EBA",
  "id" : 598104941232685056,
  "created_at" : "2015-05-12 12:38:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/nXrC7EDgzh",
      "expanded_url" : "http:\/\/s.tabelog.com\/tokyo\/A1308\/A130801\/13002291\/",
      "display_url" : "s.tabelog.com\/tokyo\/A1308\/A1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598104181342253056",
  "geo" : { },
  "id_str" : "598104560779988993",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u63A2\u3057\u3066\u307F\u308B\u3002\u3053\u3063\u3061\u3082\u30B5\u30B8\u30A7\u30B9\u30C8\u3060\u3051\u3057\u3066\u304A\u304F\u308F http:\/\/t.co\/nXrC7EDgzh\n\u8D64\u5742\u306A\u30FC\u3001\u4E00\u968E\u4E8C\u968E\u5E97\u8217\u304C\u3042\u308B\u304C\u4E8C\u968E\u306E\u304C\u7F8E\u5473\u3044",
  "id" : 598104560779988993,
  "in_reply_to_status_id" : 598104181342253056,
  "created_at" : "2015-05-12 12:36:54 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598103889284468737",
  "geo" : { },
  "id_str" : "598104155207520256",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u4F01\u696D\u6226\u58EB\u30AC\u30F3\u30BF\u30E0\u306E\u4E16\u754C\u3060\u2026",
  "id" : 598104155207520256,
  "in_reply_to_status_id" : 598103889284468737,
  "created_at" : "2015-05-12 12:35:17 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D1\u30B5\u30FC\u30B8\u30E5@\u6697\u9ED2\u9762",
      "screen_name" : "passage5062",
      "indices" : [ 0, 12 ],
      "id_str" : "208251483",
      "id" : 208251483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598103721575219200",
  "geo" : { },
  "id_str" : "598103798020636672",
  "in_reply_to_user_id" : 208251483,
  "text" : "@passage5062 \u9577\u751F\u304D\u3059\u308B\u4EBA\u6750\u304C\u6B32\u3057\u3044\u3093\u3060\u3088",
  "id" : 598103798020636672,
  "in_reply_to_status_id" : 598103721575219200,
  "created_at" : "2015-05-12 12:33:52 +0000",
  "in_reply_to_screen_name" : "passage5062",
  "in_reply_to_user_id_str" : "208251483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598103420730363905",
  "text" : "\u9577\u3059\u304E\u308B\u9078\u8003\u30D5\u30ED\u30FC",
  "id" : 598103420730363905,
  "created_at" : "2015-05-12 12:32:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598103178555498497",
  "geo" : { },
  "id_str" : "598103302488731648",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u8F9B\u3044\u9EBB\u5A46\u8C46\u8150\u3067\u3082\u98DF\u3079\u306B\u884C\u304D\u305F\u304B\u3063\u305F\u304C\u307E\u305F\u306E\u6A5F\u4F1A\u304B\u306A",
  "id" : 598103302488731648,
  "in_reply_to_status_id" : 598103178555498497,
  "created_at" : "2015-05-12 12:31:54 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598103199749251072",
  "text" : "\u308F\u301C\u7B2C\u56DB\u5104\u4E5D\u5343\u4E5D\u767E\u4E5D\u5341\u4E5D\u6B21\u9078\u8003\u901A\u904E\u3057\u305F\u301C\u3001\u7B2C\u4E94\u5104\u6B21\u9078\u8003\u6765\u9031\u3060\u301C\u3002",
  "id" : 598103199749251072,
  "created_at" : "2015-05-12 12:31:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598102698039218176",
  "geo" : { },
  "id_str" : "598102779471667200",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u308F\u304B\u3063\u305F\u3081\u3046\uFF01\u3059\u3054\u3044\u3081\u3046\uFF01",
  "id" : 598102779471667200,
  "in_reply_to_status_id" : 598102698039218176,
  "created_at" : "2015-05-12 12:29:49 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598102625079308288",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u30DE\u30B8\u3067\u62E0\u70B9\u304C\u3069\u3053\u3060\u304B\u308F\u304B\u3089\u306A\u304F\u306A\u308A\u3064\u3064\u3042\u308B",
  "id" : 598102625079308288,
  "created_at" : "2015-05-12 12:29:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598102364659126272",
  "geo" : { },
  "id_str" : "598102523543625729",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30A2\u30A4\u30A8\u30A8\u30A8\u300123\u7740\u304C\u6FC3\u539A\u306A\u3093\u3060\u3088\u306A\u2026",
  "id" : 598102523543625729,
  "in_reply_to_status_id" : 598102364659126272,
  "created_at" : "2015-05-12 12:28:48 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598100527398813696",
  "geo" : { },
  "id_str" : "598102060333080578",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u4EEE\u306B\u884C\u304F\u306A\u3089\u3044\u3064\u307E\u3067\u3044\u308B\u304B\u306D(\u307C\u304F\u3082\u3044\u304F\u3084\u3067)",
  "id" : 598102060333080578,
  "in_reply_to_status_id" : 598100527398813696,
  "created_at" : "2015-05-12 12:26:58 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598101535604637696",
  "text" : "\u30C6\u30EC\u30D3\u3068\u304A\u558B\u308A\u3059\u308B\u611F\u3058\u3067\u3061\u3087\u3044\u3061\u3087\u3044\u631F\u3093\u3067\u3057\u307E\u3063\u3066\u60AA\u3044\u3053\u3068\u3092\u3057\u305F",
  "id" : 598101535604637696,
  "created_at" : "2015-05-12 12:24:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598101376342753280",
  "text" : "\u9662\u751F\u5BA4\u53CB\u4EBA\u306B\u7740\u96FB\n\u53CB\u4EBA\u300C\u3069\u3046\u3082\u3001\u3042\u30FC\u304A\u4E16\u8A71\u306B\u306A\u3063\u3066\u304A\u308A\u307E\u3059\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u30C9\u30FC\u30E2\u300D\n\u2026\n\u53CB\u4EBA\u300C\u3044\u3084\u30FC\u9762\u63A5\u3068\u304B\u7DCA\u5F35\u3057\u3061\u3083\u3046\u3068\u601D\u3046\u3093\u3067\u3059\u3088\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u4EBA\u9593\u3060\u304B\u3089\u306A\u300D\n\u2026\n\u53CB\u4EBA\u300C\u5931\u793C\u3057\u307E\u3059\u300D\n\u53CB\u4EBA\u300C\u3061\u3087\u3044\u3061\u3087\u3044\u631F\u3093\u3067\u304F\u3093\u306E\u6B62\u3081\u3066\u304F\u308C\u300D",
  "id" : 598101376342753280,
  "created_at" : "2015-05-12 12:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598100015437877248",
  "text" : "\u82E5\u5E72\u67D1\u6A58\u7CFB\u3081\u3044\u305F\u30B5\u30A4\u30C0\u30FC\u304B\u306A\u3001\u8868\u73FE\u3057\u306B\u304F\u3044",
  "id" : 598100015437877248,
  "created_at" : "2015-05-12 12:18:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598099665926500352",
  "text" : "\u30EA\u30DC\u30F3\u30CA\u30DD\u30EA\u30F3\u3068\u304B\u3044\u3046\u98F2\u307F\u7269\u3092\u624B\u306B\u5165\u308C\u305F\u304B\u3089\u306E\u3093\u3067\u307F\u308B",
  "id" : 598099665926500352,
  "created_at" : "2015-05-12 12:17:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598099509663543296",
  "text" : "\u306F\u3041\u30D8\u30A4\u30B0\u30B9\u7C92\u5B50\u7832",
  "id" : 598099509663543296,
  "created_at" : "2015-05-12 12:16:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598098671524122624",
  "text" : "\u307E\u3041\u3001\u305D\u3046\u306A\u308B\u306A",
  "id" : 598098671524122624,
  "created_at" : "2015-05-12 12:13:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TV\u30A2\u30CB\u30E1\u300C\u30B7\u30C9\u30CB\u30A2\u306E\u9A0E\u58EB\u300D",
      "screen_name" : "SIDONIA_anime",
      "indices" : [ 3, 17 ],
      "id_str" : "2359263751",
      "id" : 2359263751
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SIDONIA_anime\/status\/598095230903058433\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mGdSnvCFvv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEzccH-UgAA97Vi.jpg",
      "id_str" : "598095226268319744",
      "id" : 598095226268319744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEzccH-UgAA97Vi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mGdSnvCFvv"
    } ],
    "hashtags" : [ {
      "text" : "\u30C4\u30C8\u30E0\u53D7\u8CDE\u304A\u3081\u3067\u3068\u3046",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598098640842792961",
  "text" : "RT @SIDONIA_anime: \u25C6\u6717\u5831\u203C\uFE0E\u25C6\u5F10\u74F6\u52C9\u5148\u751F\u306E\u300E\u30B7\u30C9\u30CB\u30A2\u306E\u9A0E\u58EB\u300F\u304C\u3001\u7B2C39\u56DE\u8B1B\u8AC7\u793E\u6F2B\u753B\u8CDE\u3010\u4E00\u822C\u90E8\u9580\u3011\u3092\u53D7\u8CDE\u3057\u307E\u3057\u305F\uFF01\uFF01 \u30C4\u30C8\u30E0\u5148\u751F\u3001\u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01 \uFF01\u305D\u3057\u3066\u5FDC\u63F4\u3057\u3066\u304F\u3060\u3055\u3063\u305F\u885B\u4EBA\u968A\u306E\u7686\u69D8\u3001\u6709\u96E3\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01 #\u30C4\u30C8\u30E0\u53D7\u8CDE\u304A\u3081\u3067\u3068\u3046 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SIDONIA_anime\/status\/598095230903058433\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mGdSnvCFvv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEzccH-UgAA97Vi.jpg",
        "id_str" : "598095226268319744",
        "id" : 598095226268319744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEzccH-UgAA97Vi.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mGdSnvCFvv"
      } ],
      "hashtags" : [ {
        "text" : "\u30C4\u30C8\u30E0\u53D7\u8CDE\u304A\u3081\u3067\u3068\u3046",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598095230903058433",
    "text" : "\u25C6\u6717\u5831\u203C\uFE0E\u25C6\u5F10\u74F6\u52C9\u5148\u751F\u306E\u300E\u30B7\u30C9\u30CB\u30A2\u306E\u9A0E\u58EB\u300F\u304C\u3001\u7B2C39\u56DE\u8B1B\u8AC7\u793E\u6F2B\u753B\u8CDE\u3010\u4E00\u822C\u90E8\u9580\u3011\u3092\u53D7\u8CDE\u3057\u307E\u3057\u305F\uFF01\uFF01 \u30C4\u30C8\u30E0\u5148\u751F\u3001\u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01 \uFF01\u305D\u3057\u3066\u5FDC\u63F4\u3057\u3066\u304F\u3060\u3055\u3063\u305F\u885B\u4EBA\u968A\u306E\u7686\u69D8\u3001\u6709\u96E3\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01 #\u30C4\u30C8\u30E0\u53D7\u8CDE\u304A\u3081\u3067\u3068\u3046 http:\/\/t.co\/mGdSnvCFvv",
    "id" : 598095230903058433,
    "created_at" : "2015-05-12 11:59:49 +0000",
    "user" : {
      "name" : "TV\u30A2\u30CB\u30E1\u300C\u30B7\u30C9\u30CB\u30A2\u306E\u9A0E\u58EB\u300D",
      "screen_name" : "SIDONIA_anime",
      "protected" : false,
      "id_str" : "2359263751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607485251523248129\/7OK-cacO_normal.jpg",
      "id" : 2359263751,
      "verified" : false
    }
  },
  "id" : 598098640842792961,
  "created_at" : "2015-05-12 12:13:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598096115225899009",
  "text" : "\u305B\u2026\u30BB\u30AB\u30F3\u30C9\u30E9\u30A4\u30D5",
  "id" : 598096115225899009,
  "created_at" : "2015-05-12 12:03:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598007153991946242",
  "text" : "\u305D\u3082\u305D\u3082\u5F53\u521D\u304B\u3089\u713C\u3054\u3066\u3068\u304B\u5F53\u3066\u3089\u308C\u3066\u305F\u3088\u3046\u306A",
  "id" : 598007153991946242,
  "created_at" : "2015-05-12 06:09:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u59EB\u30B5\u30FC\u306E\u3053\u3051\u6C0F",
      "screen_name" : "peach_knees",
      "indices" : [ 3, 15 ],
      "id_str" : "2182282279",
      "id" : 2182282279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598007098220290049",
  "text" : "RT @peach_knees: \u5065\u6C17\u306B\u30D0\u30F3\u30C9\u3067\u753A\u304A\u3053\u3057\u3092\u9811\u5F35\u3063\u3066\u3044\u308B\u3060\u3051\u306E\u82BD\u514E\u3081\u3046\u304C\u3001\u5143\u30CD\u30BF\u3082\u4F55\u3082\u77E5\u3089\u306A\u3044\u30C4\u30A4\u30C3\u30BF\u30FC\u6C11\u306B\u3001\u8A9E\u5C3E\u306B\u3081\u3046\u3092\u4ED8\u3051\u308B\u4E2D\u5352\u4E26\u307F\u306E\u77E5\u80FD\u3057\u304B\u306A\u3044\u3081\u3046\u3061\u3083\u3093\u3063\u3066\u540D\u524D\u306E\u8B0E\u306E\u793E\u755C\u3068\u3057\u304B\u5468\u77E5\u3055\u308C\u3066\u3044\u306A\u3044\u306E\u3001\u6700\u65E9\u524D\u4E16\u3067\u4F55\u3092\u3057\u305F\u3093\u3060\u3063\u3066\u30EC\u30D9\u30EB\u3067\u4E0D\u9047\u3067\u3057\u3087\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597740614688575488",
    "text" : "\u5065\u6C17\u306B\u30D0\u30F3\u30C9\u3067\u753A\u304A\u3053\u3057\u3092\u9811\u5F35\u3063\u3066\u3044\u308B\u3060\u3051\u306E\u82BD\u514E\u3081\u3046\u304C\u3001\u5143\u30CD\u30BF\u3082\u4F55\u3082\u77E5\u3089\u306A\u3044\u30C4\u30A4\u30C3\u30BF\u30FC\u6C11\u306B\u3001\u8A9E\u5C3E\u306B\u3081\u3046\u3092\u4ED8\u3051\u308B\u4E2D\u5352\u4E26\u307F\u306E\u77E5\u80FD\u3057\u304B\u306A\u3044\u3081\u3046\u3061\u3083\u3093\u3063\u3066\u540D\u524D\u306E\u8B0E\u306E\u793E\u755C\u3068\u3057\u304B\u5468\u77E5\u3055\u308C\u3066\u3044\u306A\u3044\u306E\u3001\u6700\u65E9\u524D\u4E16\u3067\u4F55\u3092\u3057\u305F\u3093\u3060\u3063\u3066\u30EC\u30D9\u30EB\u3067\u4E0D\u9047\u3067\u3057\u3087\u2026",
    "id" : 597740614688575488,
    "created_at" : "2015-05-11 12:30:42 +0000",
    "user" : {
      "name" : "\u59EB\u30B5\u30FC\u306E\u3053\u3051\u6C0F",
      "screen_name" : "peach_knees",
      "protected" : false,
      "id_str" : "2182282279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578948287291502593\/Gjg28KiR_normal.jpeg",
      "id" : 2182282279,
      "verified" : false
    }
  },
  "id" : 598007098220290049,
  "created_at" : "2015-05-12 06:09:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597808607074193408",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 597808607074193408,
  "created_at" : "2015-05-11 17:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/597808254450700289\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/lnf559fzlc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEvXb3aUkAAxYPs.jpg",
      "id_str" : "597808249287512064",
      "id" : 597808249287512064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEvXb3aUkAAxYPs.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/lnf559fzlc"
    } ],
    "hashtags" : [ {
      "text" : "pixiv",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/aecPfQ1nBs",
      "expanded_url" : "http:\/\/www.pixiv.net\/member_illust.php?illust_id=50335259&mode=medium",
      "display_url" : "pixiv.net\/member_illust.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597808254450700289",
  "text" : "\u30A2\u30F3\u30C1\u5099\u4E2D\u936C\u306E\u30A4\u30E9\u30B9\u30C8\u3092\u63CF\u304D\u307E\u3057\u305F\n\n\u30A2\u30F3\u30C1\u5099\u4E2D\u936C | end313124 #pixiv http:\/\/t.co\/aecPfQ1nBs http:\/\/t.co\/lnf559fzlc",
  "id" : 597808254450700289,
  "created_at" : "2015-05-11 16:59:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597798841140707329",
  "text" : "\u30A2\u30F3\u30C1\u5099\u4E2D\u936C\u306A\u306E\u306B\u5099\u4E2D\u936C\u3067\u30AD\u30E3\u30E9\u30AF\u30BF\u30E9\u30A4\u30BA\u3055\u308C\u3066\u308B\u306E\u3058\u308F\u3058\u308F\u60B2\u3057\u3044",
  "id" : 597798841140707329,
  "created_at" : "2015-05-11 16:22:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/597798179975745536\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/pGJwdxANuN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEvORhnVEAA7PUj.png",
      "id_str" : "597798176033148928",
      "id" : 597798176033148928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEvORhnVEAA7PUj.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pGJwdxANuN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597798179975745536",
  "text" : "\u305D\u3057\u3066\u77E5\u3063\u3066\u306E\u901A\u308A\u3053\u308C\u3067\u3059\u3088 http:\/\/t.co\/pGJwdxANuN",
  "id" : 597798179975745536,
  "created_at" : "2015-05-11 16:19:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/597798031644196864\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/WfN9yrc79m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEvOI71UgAEn7pL.png",
      "id_str" : "597798028452331521",
      "id" : 597798028452331521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEvOI71UgAEn7pL.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WfN9yrc79m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597798031644196864",
  "text" : "\u304A\uFF1F\u2026\u304A\uFF1F\uFF01\uFF1F\uFF01 http:\/\/t.co\/WfN9yrc79m",
  "id" : 597798031644196864,
  "created_at" : "2015-05-11 16:18:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597794453445693441",
  "geo" : { },
  "id_str" : "597794571834163200",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u30CF\u30F3\u30C9\u30A2\u30C3\u30AF\u30B9\u66F8\u304F\u3057\u304B\u306D\u3047",
  "id" : 597794571834163200,
  "in_reply_to_status_id" : 597794453445693441,
  "created_at" : "2015-05-11 16:05:07 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597791293364768768",
  "geo" : { },
  "id_str" : "597794171441713152",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u4F55\u3092\u30C7\u30C3\u30B5\u30F3\u3057\u305F\u3089\u826F\u3044\u3067\u3059\u304B\u306D",
  "id" : 597794171441713152,
  "in_reply_to_status_id" : 597791293364768768,
  "created_at" : "2015-05-11 16:03:31 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597786436285280257",
  "text" : "\u79C1\u3068\u3057\u3066\u3082\u30E2\u30A2\u30A4\u50CF\u306E\u524D\u3067\u65A7\u6301\u3063\u3066\u559C\u3093\u3067\u308B\u5973\u306E\u4EBA\u66F8\u3044\u3066\u3066\u3082\u4ED5\u65B9\u306A\u3044\u3063\u3066\u306E\u306F\u306A\u3093\u3068\u306A\u304F\u308F\u304B\u308B\u3093\u3067\u3059\u3088",
  "id" : 597786436285280257,
  "created_at" : "2015-05-11 15:32:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597786315120189440",
  "text" : "\u304A\u7D75\u63CF\u304D\u3067\u3044\u3046\u7D20\u632F\u308A\u307F\u305F\u3044\u306A\u3082\u306E\u3063\u3066\u306A\u3044\u306E\u304B\u306A",
  "id" : 597786315120189440,
  "created_at" : "2015-05-11 15:32:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597778116413562880",
  "text" : "\u5404\u4F5C\u54C1\u306B\u7537\u5973\u554F\u308F\u305A\u597D\u304D\u306A\u30AD\u30E3\u30E9\u3063\u3066\u3044\u308B\u3051\u3069\u3001\u3053\u3046\u3044\u3046\u30BF\u30A4\u30D7\u304C\u597D\u304D\u3063\u3066\u306E\u304C(\u5C5E\u6027\u3068\u304B)\u306A\u3044\u304B\u3089\u81EA\u5206\u3067\u3082\u597D\u307F\u304C\u3055\u3063\u3071\u308A\u308F\u304B\u3089\u3093",
  "id" : 597778116413562880,
  "created_at" : "2015-05-11 14:59:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597776449173520385",
  "geo" : { },
  "id_str" : "597776616001961984",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u307E\u305F\u50D5\u306E\u77E5\u77E5\u308B\u4EAC\u90FD\u304C\u4E00\u3064\u640D\u306A\u308F\u308C\u3066\u3057\u307E\u3063\u305F\u2026",
  "id" : 597776616001961984,
  "in_reply_to_status_id" : 597776449173520385,
  "created_at" : "2015-05-11 14:53:46 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597775936176525312",
  "geo" : { },
  "id_str" : "597776137649917952",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u30A2\u30A4\u30A8\u30A8\u30A8\u2026\u3063\u3066\u53E3\u306B\u51FA\u305F\u2026\u3042\u306E\u8FBA\u3060\u3068\u9280\u6C34\u6E6F\u304C\u307E\u3060\u3042\u308B\u304B\u306A",
  "id" : 597776137649917952,
  "in_reply_to_status_id" : 597775936176525312,
  "created_at" : "2015-05-11 14:51:52 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/597775724519432192\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/lKXuVA8pZr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEu52IqVAAEPIF_.jpg",
      "id_str" : "597775715245817857",
      "id" : 597775715245817857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEu52IqVAAEPIF_.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lKXuVA8pZr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597775724519432192",
  "text" : "\u5B9A\u7FA9\u5982\u6765\u306B\u304A\u9858\u3044\u3059\u308B\u3057\u304B\u306A\u3044(?) http:\/\/t.co\/lKXuVA8pZr",
  "id" : 597775724519432192,
  "created_at" : "2015-05-11 14:50:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597775536421670912",
  "text" : "RT @koizumi_fifty: \u5B9A\u7FA9\u3092\u6B63\u3057\u304F\u884C\u3048\u3070\u305D\u3053\u304B\u3089\u76F4\u3061\u306B\u3042\u3089\u3086\u308B\u3053\u3068\u304C\u308F\u304B\u308B\u3001\u3088\u3044\u6570\u5B66\u3068\u3044\u3046\u306E\u306F\u305D\u3046\u3044\u3046\u3082\u306E\u3060\u3001\u3068\u3044\u3046\u3088\u3046\u306A\u898B\u65B9\u306F\u305D\u308C\u306A\u308A\u306B\u5171\u6709\u3055\u308C\u3066\u3044\u305D\u3046\u306A\u6C17\u304C\u3057\u307E\u3059\u306D\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597775045658685442",
    "text" : "\u5B9A\u7FA9\u3092\u6B63\u3057\u304F\u884C\u3048\u3070\u305D\u3053\u304B\u3089\u76F4\u3061\u306B\u3042\u3089\u3086\u308B\u3053\u3068\u304C\u308F\u304B\u308B\u3001\u3088\u3044\u6570\u5B66\u3068\u3044\u3046\u306E\u306F\u305D\u3046\u3044\u3046\u3082\u306E\u3060\u3001\u3068\u3044\u3046\u3088\u3046\u306A\u898B\u65B9\u306F\u305D\u308C\u306A\u308A\u306B\u5171\u6709\u3055\u308C\u3066\u3044\u305D\u3046\u306A\u6C17\u304C\u3057\u307E\u3059\u306D\u3002",
    "id" : 597775045658685442,
    "created_at" : "2015-05-11 14:47:31 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 597775536421670912,
  "created_at" : "2015-05-11 14:49:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597774574168580096",
  "geo" : { },
  "id_str" : "597774634897965056",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u30DE\u30B8\u3067",
  "id" : 597774634897965056,
  "in_reply_to_status_id" : 597774574168580096,
  "created_at" : "2015-05-11 14:45:53 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597773800055263232",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8",
  "id" : 597773800055263232,
  "created_at" : "2015-05-11 14:42:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597773450590048256",
  "text" : "\u6BBA\u3089\u308C\u308B\u524D\u306B\u6BBA\u308B\u3057\u304B\u306A\u3044",
  "id" : 597773450590048256,
  "created_at" : "2015-05-11 14:41:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597771623987445761",
  "geo" : { },
  "id_str" : "597772138234257408",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u3069\u3063\u3061\u304B\u3068\u3044\u3046\u3068\u30AA\u30D5\u306E\u524D\u5DDD\u3055\u3093\u306E\u65B9\u304C\u826F\u3044",
  "id" : 597772138234257408,
  "in_reply_to_status_id" : 597771623987445761,
  "created_at" : "2015-05-11 14:35:58 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597771852925153282",
  "text" : "\u565B\u307F\u5408\u308F\u306A\u3044\u611F\u3058",
  "id" : 597771852925153282,
  "created_at" : "2015-05-11 14:34:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597771656312926210",
  "text" : "\u9B5A\u82E6\u624B\u306A\u306E\u304B\u3046\u3051\u308B",
  "id" : 597771656312926210,
  "created_at" : "2015-05-11 14:34:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597771317442555904",
  "text" : "\u305D\u306E\u4ED6\u306E\u4F5C\u54C1\u306E\u50D5\u306E\u8DA3\u5473",
  "id" : 597771317442555904,
  "created_at" : "2015-05-11 14:32:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597771008821501953",
  "geo" : { },
  "id_str" : "597771243622772736",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u307F\u304F\u306B\u3083\u3093\u53EF\u611B\u3044\u3093\u3067\u3059\u304C\u50D5\u306E\u305D\u306E\u4ED6\u306E\u4F5C\u54C1\u306E\u8DA3\u5473\u3068\u5408\u308F\u306A\u3055\u3059\u304E\u3066\u81EA\u5206\u3067\u3082\u98F2\u307F\u8FBC\u307F\u3042\u3050\u306D\u3066\u308B\u611F\u3058\u3067\u3059",
  "id" : 597771243622772736,
  "in_reply_to_status_id" : 597771008821501953,
  "created_at" : "2015-05-11 14:32:25 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597770755523280896",
  "geo" : { },
  "id_str" : "597770939271553024",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u3068\u308A\u3042\u3048\u305A\u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u306E\u5B50\u306F\u9811\u5F35\u3063\u3066\u899A\u3048\u307E\u3057\u305F(\u3048\u3089\u3044)",
  "id" : 597770939271553024,
  "in_reply_to_status_id" : 597770755523280896,
  "created_at" : "2015-05-11 14:31:12 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597770816856588289",
  "text" : "\u76EE\u7389\u713C\u304D\u306B\u306F\u4F55\u304B\u3051\u308B\u8AD6\u4E89\u3046\u3051\u308B",
  "id" : 597770816856588289,
  "created_at" : "2015-05-11 14:30:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597770390799142913",
  "geo" : { },
  "id_str" : "597770543358611456",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u30D1\u30F3\u30AF\u3057\u304B\u3051\u306A\u306E\u3067\u540D\u524D\u3092\u5897\u3084\u3055\u306A\u3044\u3067\u304F\u3060\u3055\u3044\uFF01\uFF01",
  "id" : 597770543358611456,
  "in_reply_to_status_id" : 597770390799142913,
  "created_at" : "2015-05-11 14:29:38 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597770451041923072",
  "text" : "11\u8A71\u3001\u4ED5\u4E8B\u30A6\u30FC\u30DE\u30F3\u305F\u3061\u3060",
  "id" : 597770451041923072,
  "created_at" : "2015-05-11 14:29:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597770150088052738",
  "text" : "\u30DE\u30B8\u30EC\u30B9\u30DE\u30F3\u3060\u3063\u305F",
  "id" : 597770150088052738,
  "created_at" : "2015-05-11 14:28:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597770088926707713",
  "text" : "\u8D64\u57CE\u307F\u308A\u3042\u300111\u6B73\u306B\u3057\u3066\u306F\u5E7C\u3059\u304E\u308B\u5370\u8C61\u306A\u2026\u5C0F5\u5973\u5B50\u3063\u3066\u3082\u3063\u3068\u5927\u4EBA\u3057\u3044\u306E\u3067\u306F",
  "id" : 597770088926707713,
  "created_at" : "2015-05-11 14:27:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597769436578217985",
  "text" : "\u79FB\u52D5\u4E2D\u306E\u30E1\u30AC\u30CD\u306A\u308B\u307B\u3069",
  "id" : 597769436578217985,
  "created_at" : "2015-05-11 14:25:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597767994194833408",
  "text" : "11\u8A71\u307F\u304F\u306B\u3083\u3093\u56DE\u304B",
  "id" : 597767994194833408,
  "created_at" : "2015-05-11 14:19:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597754609298313216",
  "text" : "\u30C7\u30EC\u30DE\u30B99\u8A71\u3001\u674F\u3081\u3063\u3061\u3087\u512A\u79C0\u3060",
  "id" : 597754609298313216,
  "created_at" : "2015-05-11 13:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597750349789863936",
  "text" : "\uFF30",
  "id" : 597750349789863936,
  "created_at" : "2015-05-11 13:09:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597733878506266624",
  "geo" : { },
  "id_str" : "597734009985060864",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u306A\u308B\u307B",
  "id" : 597734009985060864,
  "in_reply_to_status_id" : 597733878506266624,
  "created_at" : "2015-05-11 12:04:27 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597732946376720384",
  "geo" : { },
  "id_str" : "597733318394716160",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5F85\u3061\u6642\u9593\u591A\u3044\u30B2\u30FC\u30E0\u3060\u3057\u3080\u3057\u308D\u76F8\u6027\u3044\u3044\u3068\u601D\u3046\u3093\u3060\u304C\u305D\u3093\u306A\u3082\u3093\u304B",
  "id" : 597733318394716160,
  "in_reply_to_status_id" : 597732946376720384,
  "created_at" : "2015-05-11 12:01:43 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597733104183181312",
  "text" : "\u624B\u638C\u3067\u64CD\u308C\u3070\u3001\u901F\u529B\u306F\u4E8C\u500D\u30C3(\u7B11)",
  "id" : 597733104183181312,
  "created_at" : "2015-05-11 12:00:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/597732892697997312\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/n598GoqET2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEuS46uVAAA3VR_.png",
      "id_str" : "597732882090622976",
      "id" : 597732882090622976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEuS46uVAAA3VR_.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n598GoqET2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597732892697997312",
  "text" : "\u3059\u307E\u306C\u2026(r4s) http:\/\/t.co\/n598GoqET2",
  "id" : 597732892697997312,
  "created_at" : "2015-05-11 12:00:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597732264311541761",
  "geo" : { },
  "id_str" : "597732357462884352",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u75B2\u52B4\u629C\u304F\u9593\u306B\u30A2\u30CB\u30E1\u898B\u308C\u3070\u307B\u3089",
  "id" : 597732357462884352,
  "in_reply_to_status_id" : 597732264311541761,
  "created_at" : "2015-05-11 11:57:54 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597732141246492672",
  "text" : "\u7720\u6C17",
  "id" : 597732141246492672,
  "created_at" : "2015-05-11 11:57:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597732122804113408",
  "text" : "NEMU.K",
  "id" : 597732122804113408,
  "created_at" : "2015-05-11 11:56:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597618251133112320",
  "text" : "\u666E\u6BB5\u98F2\u3093\u3067\u308B\u30B3\u30FC\u30D2\u30FC\u304C\u6FC3\u3059\u304E\u308B\u306E\u304B\u3001\u6642\u9593\u3064\u3076\u3057\u306B\u5165\u3063\u305F\u55AB\u8336\u5E97\u306E\u30B3\u30FC\u30D2\u30FC\u304C\u3072\u305F\u3059\u3089\u3046\u3059\u3044",
  "id" : 597618251133112320,
  "created_at" : "2015-05-11 04:24:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597610217602322433",
  "text" : "72h",
  "id" : 597610217602322433,
  "created_at" : "2015-05-11 03:52:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597602934315089920",
  "geo" : { },
  "id_str" : "597603348053762048",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u3088\u3044\u304A\u304B\u3042\u3055\u3093",
  "id" : 597603348053762048,
  "in_reply_to_status_id" : 597602934315089920,
  "created_at" : "2015-05-11 03:25:15 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597598644750061568",
  "text" : "\u89AA\u304C\u3082\u305F\u305B\u3066\u304F\u308C\u305F\u304A\u306B\u304E\u308A\u3001\u5177\u306B\u30AB\u30C4\u304C\u5165\u3063\u3066\u3044\u308B\u3001\u4E0D\u601D\u8B70\u30B9\u30AD\u30EB\u3060",
  "id" : 597598644750061568,
  "created_at" : "2015-05-11 03:06:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597569774080536577",
  "text" : "\u65B0\u5343\u6B73\u3067\u4F1A\u304A\u3046\u3001\u7121\u4E8B\u3092\u7948\u308B",
  "id" : 597569774080536577,
  "created_at" : "2015-05-11 01:11:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597569697513484289",
  "text" : "\u304D \u306A \u3044 \u30E2\u30FC\u30C9",
  "id" : 597569697513484289,
  "created_at" : "2015-05-11 01:11:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597568986897780737",
  "text" : "\u30AB\u30C4\u30B8\u30E5\u30FC\u30EB\u3001\u306A\u3093\u304B\u30AB\u30C4\u3068\u30B8\u30E5\u30FC\u30EB\u306E\u8A9E\u611F\u306E\u305B\u3044\u3067\u3001\u3081\u3063\u3061\u3083\u71B1\u305D\u3046",
  "id" : 597568986897780737,
  "created_at" : "2015-05-11 01:08:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597568862666690560",
  "text" : "\u30AB\u30C4\u30B8\u30E5\u30FC\u30EB\u304C\u30B9\u30B1\u30B9\u30B1\u3060\u2026",
  "id" : 597568862666690560,
  "created_at" : "2015-05-11 01:08:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597568793276059650",
  "text" : "\u672D\u5E4C\u7740\u3044\u3066\u3059\u3050\u30A2\u30EC\u660E\u4F1A\u3060\u3057\u30AB\u30ED\u30A6\u30B7\u306E\u304A\u305D\u308C\u304C\u3042\u308B",
  "id" : 597568793276059650,
  "created_at" : "2015-05-11 01:07:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597568396717264896",
  "text" : "\u304E\u308A\u304E\u308A\u3063\u3077\u308A",
  "id" : 597568396717264896,
  "created_at" : "2015-05-11 01:06:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597568370423169024",
  "text" : "\u642D\u4E57\u624B\u7D9A\u304D\u3082\u642D\u4E57\u3082\u5F85\u3061\u306A\u3057\u306E\u3077\u308A\u3077\u308A\u3063\u304E\u308A",
  "id" : 597568370423169024,
  "created_at" : "2015-05-11 01:06:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597567378919063552",
  "text" : "\u96A8",
  "id" : 597567378919063552,
  "created_at" : "2015-05-11 01:02:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597567353094676480",
  "text" : "\u307E\u306B\u307E\u306B\u30AE\u30EA\u3042\u3063\u305F",
  "id" : 597567353094676480,
  "created_at" : "2015-05-11 01:02:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597551452945428481",
  "text" : "\u9AD8\u901F\u304D\u305F\uFF01\u3053\u308C\u3067\u304B\u3064\u308B\uFF01\u3068\u601D\u3044\u304D\u3084\u9AD8\u901F\u3082\u305D\u3053\u305D\u3053\u6DF7\u3093\u3067\u308B",
  "id" : 597551452945428481,
  "created_at" : "2015-05-10 23:59:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597549162163347456",
  "text" : "\u9053\u304C\u6DF7\u3093\u3067\u308B\u306E\u3060\u304C\u30D2\u30B3\u30FC\u30AD\u30A8\u30A2\u30D7\u30EC\u30FC\u30F3\u9593\u306B\u5408\u3046\u306E\u304B\u3053\u308C",
  "id" : 597549162163347456,
  "created_at" : "2015-05-10 23:49:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597537755858472960",
  "text" : "\u884C\u304F\u305C\u7FBD\u7530\u30A8\u30A2\u30DD\u30FC\u30C8\u3001\u5E30\u308B\u305C\u672D\u5E4C",
  "id" : 597537755858472960,
  "created_at" : "2015-05-10 23:04:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597528192144904193",
  "geo" : { },
  "id_str" : "597537617475870720",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01\uFF01",
  "id" : 597537617475870720,
  "in_reply_to_status_id" : 597528192144904193,
  "created_at" : "2015-05-10 23:04:04 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597527550252843008",
  "text" : "\u7121\u9650\u7720\u3044\u8D77\u5E8A",
  "id" : 597527550252843008,
  "created_at" : "2015-05-10 22:24:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597416884808458241",
  "geo" : { },
  "id_str" : "597417317782331392",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u53EF\u8996\u5316\u3063\u3066\u8A00\u8449\u304C\u3042\u308B\u306E\u306B\u306A\u3093\u3067\u308F\u3056\u308F\u3056\u306D\u3047",
  "id" : 597417317782331392,
  "in_reply_to_status_id" : 597416884808458241,
  "created_at" : "2015-05-10 15:06:02 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597416527051128834",
  "geo" : { },
  "id_str" : "597416663093489666",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u308F\u304B\u308B of \u308F\u304B\u308B",
  "id" : 597416663093489666,
  "in_reply_to_status_id" : 597416527051128834,
  "created_at" : "2015-05-10 15:03:26 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597403290998087680",
  "text" : "\u4ED6\u4EBA\u3068\u8A71\u3055\u306A\u3044\u304B\u3089\u3081\u3063\u3061\u3087\u6642\u4EE3\u9045\u308C\u306A\u8A2D\u5B9A\u30D5\u30A1\u30A4\u30E6\u3060\u3063\u305F",
  "id" : 597403290998087680,
  "created_at" : "2015-05-10 14:10:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597403219413839872",
  "text" : "\u3081\u3063\u3061\u3087\u3079\u3093\u308A\u306AElisp\u7BA1\u7406\u306E\uFF45\uFF4C\uFF49\uFF53\uFF50\u3092\u6559\u308F\u3063\u3066\uFF73\uFF6F\uFF8B\uFF6E\uFF70\u3063\u3066\u306A\u3063\u3066\u308B",
  "id" : 597403219413839872,
  "created_at" : "2015-05-10 14:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597356378630397952",
  "text" : "(\u307E\u3060\uFF12\u3064\u3060\u3051)",
  "id" : 597356378630397952,
  "created_at" : "2015-05-10 11:03:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597356332937646082",
  "text" : "ingress\u306E\u30DD\u30FC\u30BF\u30EB\u30AD\u30FC\u3001\u304B\u3048\u308B\u3042\u3064\u3081\u307F\u305F\u3044\u306B\u306A\u3063\u3066\u304D\u305F",
  "id" : 597356332937646082,
  "created_at" : "2015-05-10 11:03:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597351492744445952",
  "text" : "\u7DCA\u6025\u505C\u8ECA\u306F\u3057\u306A\u3044",
  "id" : 597351492744445952,
  "created_at" : "2015-05-10 10:44:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597351441708134400",
  "text" : "\u65B0\u5BBF\u304B\u3089\u7B39\u585A\u3078\u3001\u5947\u5999\u306A\u5171\u95D8",
  "id" : 597351441708134400,
  "created_at" : "2015-05-10 10:44:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597344333566619650",
  "text" : "\u90FD\u5FC3\u3067\u306E\u3044\u3093\u3050\u308C\u3059",
  "id" : 597344333566619650,
  "created_at" : "2015-05-10 10:16:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597307661495861248",
  "text" : "\u4E88\u5099\u68211\u9031\u9593\u76EE\u3001\u6642\u9593\u3092\u52D8\u9055\u3044\u3057\u3066\u3044\u3066\u304A\u663C\u98DF\u3079\u306B\u6765\u305F\u5927\u6238\u5C4B\u3055\u3093\u306E\u3042\u308B\u30D3\u30EB\u306B\u30A2\u30EC\u6D3B\u3067\u8A2A\u308C\u8B0E\u306E\u4F0F\u7DDA\u56DE\u53CE\u611F\u3092\u5473\u308F\u3063\u3066\u3044\u308B",
  "id" : 597307661495861248,
  "created_at" : "2015-05-10 07:50:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597302887895568384",
  "text" : "\u306B\u3087\u3085\u308F\u30FC\u3093",
  "id" : 597302887895568384,
  "created_at" : "2015-05-10 07:31:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597302805255196672",
  "text" : "\u30B7\u30D6\u30E4\u30B9\u30C6\u30FC\u30B7\u30E7\u30F3\u3067\u80E1\u6563\u81ED\u3044\u5E83\u544A\u304C\u3042\u308B\u306A\u30FC\u3068\u601D\u3063\u305F\u3089hoge\u5DDDhoge\u6CD5\u3060\u3063\u305F",
  "id" : 597302805255196672,
  "created_at" : "2015-05-10 07:31:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597302082706677760",
  "text" : "\u526F\u90FD\u5FC3\u7DDA\u3001\u6DF1\u3044",
  "id" : 597302082706677760,
  "created_at" : "2015-05-10 07:28:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597299995079901184",
  "text" : "\u3074\u3093\u307D\u30FC\u3093",
  "id" : 597299995079901184,
  "created_at" : "2015-05-10 07:19:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597299963354157056",
  "text" : "\u65E5\u9803\u306E\u884C\u3044\u304C\u60AA\u3044\u306E\u304B\u6539\u672D\u3067\u524D\u306E\u4EBA\u304C\u3064\u3063\u304B\u3048\u305F",
  "id" : 597299963354157056,
  "created_at" : "2015-05-10 07:19:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597297724673761281",
  "text" : "hogehoge.K\u69CB\u6587\u306E\u306B\u308F\u304B\u306A\u6D41\u884C",
  "id" : 597297724673761281,
  "created_at" : "2015-05-10 07:10:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597297144890986499",
  "text" : "\u79C1\u3067\u306F\u306A\u3044",
  "id" : 597297144890986499,
  "created_at" : "2015-05-10 07:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597297127912411138",
  "text" : "\u3068\u306A\u308A\u306E\u3068\u306A\u308A\u306E\u304A\u306D\u30FC\u3055\u3093\u3001\u30A8\u30FC\u30B8\u30A7\u30F3\u30C8\u3060\u2026",
  "id" : 597297127912411138,
  "created_at" : "2015-05-10 07:08:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597273783599247360",
  "text" : "\u4ECA\u5EA6\u6771\u4EAC\u6765\u305F\u3089\u5BC4\u751F\u866B\u535A\u7269\u9928\u8A00\u3063\u3066\u307F\u3088\u3046\u304B\u306A",
  "id" : 597273783599247360,
  "created_at" : "2015-05-10 05:35:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597272500352000000",
  "text" : "\u5BC4\u751F\u866B\u535A\u7269\u9928\u3001\u3069\u3053\u306B\u3042\u308B\u3093\u3060\u3063\u3051\u304B",
  "id" : 597272500352000000,
  "created_at" : "2015-05-10 05:30:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597272005629583360",
  "text" : "There exists \u305F\u304B\u3057\u306E\u6BCD",
  "id" : 597272005629583360,
  "created_at" : "2015-05-10 05:28:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597266666129600512",
  "text" : "\u6843\u674E\u3082\u306E\u8A00\u308F\u3056\u308C\u3069\u4E0B\u81EA\u305A\u304B\u3089\u8E4A\u3092\u6210\u3059\u3063\u3066\u3044\u3046\u3067\u3042\u308D",
  "id" : 597266666129600512,
  "created_at" : "2015-05-10 05:07:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597264009163874304",
  "text" : "\u4EBA\u9593\u306F\u305D\u306E\u5834\u305D\u306E\u5834\u3067\u3069\u3093\u306A\u306B\u697D\u3057\u304F\u904E\u3054\u3057\u3066\u300C\u4E00\u751F\u5FD8\u308C\u306A\u3044\u300D\u3068\u304B\u601D\u3063\u3066\u3082\u3042\u3063\u3055\u308A\u5FD8\u308C\u308B",
  "id" : 597264009163874304,
  "created_at" : "2015-05-10 04:56:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597263863625703424",
  "text" : "\u5358\u7D14\u306B\u5199\u771F\u3042\u308B\u3068\u8272\u3005\u601D\u3044\u51FA\u305B\u3066\u826F\u3044\u306A\u30FC\u3068\u306F\u6570\u5C11\u306A\u3044\u5199\u771F\u773A\u3081\u306A\u304C\u3089\u601D\u3063\u305F",
  "id" : 597263863625703424,
  "created_at" : "2015-05-10 04:56:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597263271473840128",
  "text" : "\u5199\u771F\u306F\u7121\u3044\u3051\u3069\u3001\u666E\u901A\u306B\u65C5\u884C\u3068\u304B\u884C\u3063\u3066\u308B\u3057\u697D\u3057\u304F\u307F\u3093\u306A\u3067\u904A\u3079\u308B\u4EBA\u9593\u306A\u3093\u3060\uFF01\uFF01\uFF01\u5199\u771F\u306F\u7121\u3044\u3051\u3069\u4FE1\u3058\u3066\u304F\u308C\uFF01\uFF01\uFF01\u3063\u3066\u611F\u3058",
  "id" : 597263271473840128,
  "created_at" : "2015-05-10 04:53:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597263020620914688",
  "text" : "\u4F01\u696D\u306F\u8981\u6C42\u3057\u3066\u304F\u308B\u304C\u4F7F\u3048\u308B\u5199\u771F\u304C\u306A\u3055\u3059\u304E\u308B",
  "id" : 597263020620914688,
  "created_at" : "2015-05-10 04:52:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597262864479555585",
  "text" : "\u30A2\u30EC\u6D3B\u306E\u305F\u3081\u3063\u3066\u8A00\u3046\u306E\u306F\u3081\u3063\u3061\u3087\u3081\u3063\u3061\u3087\u4E0D\u672C\u610F\u3060\u3051\u3069\u30B5\u30FC\u30AF\u30EB\u3068\u304B\u3067\u65C5\u884C\u3068\u304B\u884C\u3063\u305F\u3089\u5199\u771F\u53D6\u3063\u3066\u304A\u3044\u305F\u65B9\u304C\u3044\u3044\u3067\u3059\u3088",
  "id" : 597262864479555585,
  "created_at" : "2015-05-10 04:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597259658823368704",
  "text" : "\u6709\u9802\u5929\u5909",
  "id" : 597259658823368704,
  "created_at" : "2015-05-10 04:39:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597259403952332802",
  "text" : "\u5929\u5B50\u3001\u30AD\u30E3\u30E9\u30C7\u30B6\u53EF\u611B\u3044\u306E\u306B\u30AD\u30E3\u30E9\u304C\u6B8B\u5FF5\u3063\u3066\u30A4\u30E1\u30FC\u30B8",
  "id" : 597259403952332802,
  "created_at" : "2015-05-10 04:38:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597258874886950912",
  "text" : "\u30B5\u30A4\u30AA\u30FC\u30DB\u30FC\u30B9\u306A\uFF01\u3063\u3066\u58F0\u306B\u51FA\u3057\u3066\u8AAD\u307F\u305F\u3044\u65E5\u672C\u8A9E\u3060",
  "id" : 597258874886950912,
  "created_at" : "2015-05-10 04:36:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597256961109807105",
  "text" : "\u30C9\u30E3\u30FC\u30F3",
  "id" : 597256961109807105,
  "created_at" : "2015-05-10 04:28:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597254650836942848",
  "text" : "\u30B7\u30C9\u30CB\u30A2\u4E8C\u671F\u56DB\u8A71\u3001\u52E2\u5A01\u3055\u3093\u306E\u300C\u30B7\u30C9\u30CB\u30A2\u30FC\u30C3!\u300D\u304C\u4F55\u56DE\u307F\u3066\u3082\u75FA\u308C\u308B",
  "id" : 597254650836942848,
  "created_at" : "2015-05-10 04:19:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597245133839544320",
  "text" : "\u4F8B\u5927\u796D\u304B",
  "id" : 597245133839544320,
  "created_at" : "2015-05-10 03:41:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/AfeIQupBuA",
      "expanded_url" : "http:\/\/shindanmaker.com\/423222",
      "display_url" : "shindanmaker.com\/423222"
    } ]
  },
  "geo" : { },
  "id_str" : "596945277619077121",
  "text" : "end313124\u300C\uFF8A\uFF6F\uFF8A\uFF8A\uFF6B\uFF69wwwwww\uFF8C\uFF67\uFF70\uFF6Fwww\uFF8A\uFF6F\uFF8A\uFF8A\uFF6B\uFF69www\u300D http:\/\/t.co\/AfeIQupBuA",
  "id" : 596945277619077121,
  "created_at" : "2015-05-09 07:50:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596922149643759616",
  "text" : "\u3069\u3046\u3058\u306B\u30EA\u30D5\u30A1\u30AF\u30BF\u30FC\u3082\u51FA\u305F",
  "id" : 596922149643759616,
  "created_at" : "2015-05-09 06:18:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596921687582507008",
  "text" : "4\u56DE\u76EE\u3067\u3088\u3046\u3084\u304F\u51FA\u305F\u2026\u3075\u3046",
  "id" : 596921687582507008,
  "created_at" : "2015-05-09 06:16:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596920570035326977",
  "text" : "3\u56DE\u30B0\u30EA\u30D5\u30CF\u30C3\u30AF\u3057\u3066\u3082\u30DD\u30FC\u30BF\u30EB\u30AD\u30FC\u51FA\u306A\u304F\u3066\u3046\u3049\u30A9\u30F3\u3063\u3066\u306A\u3063\u3066\u308B",
  "id" : 596920570035326977,
  "created_at" : "2015-05-09 06:12:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596903536534921216",
  "text" : "OS\u3060\u306E\u30D6\u30E9\u30A6\u30B6\u3060\u306E\u5927\u624B\uFF13\u3064\u3065\u3064\u304F\u3089\u3044\u306F\u3061\u3083\u3093\u3068\u5BFE\u5FDC\u3057\u3084\u304C\u308C\u7518\u3048\u3093\u306A",
  "id" : 596903536534921216,
  "created_at" : "2015-05-09 05:04:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596903424018481152",
  "text" : "Web\u30C6\u30B9\u30C8\u81EA\u4F53\u306F\u500B\u3005\u4EBA\u3067\u51FA\u6765\u308B\u3057\u52B9\u7387\u7684\u306A\u30B7\u30B9\u30C6\u30E0\u3060\u3068\u601D\u3046\u304CIE\u3092\u6307\u5B9A\u3057\u3066\u304F\u308B\u4F01\u696D\u3001\u304A\u524D\u3060\u3051\u306F\u8A31\u305B\u3093",
  "id" : 596903424018481152,
  "created_at" : "2015-05-09 05:04:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596720767150247936",
  "text" : "\u79C1\u306F\u7720\u308B\u304A\u3084\u3059\u307F",
  "id" : 596720767150247936,
  "created_at" : "2015-05-08 16:58:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596720746136743936",
  "text" : "\u3042\u308B\u7A0B\u5EA6\u306E\u4EBA\u9593\u304C\u901A\u3063\u305F\u9053\u3060\u3057\u4EBA\u9593\u306F\u9593\u9055\u3048\u3066\u899A\u3048\u308B\u751F\u304D\u7269\u3060\u3057\u5F37\u304F\u751F\u304D\u3066\u307B\u3057\u3044",
  "id" : 596720746136743936,
  "created_at" : "2015-05-08 16:58:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596720565018349569",
  "text" : "\u30E1\u30FC\u30EA\u30B9\u306B\u8FD4\u4FE1\u3057\u3061\u3083\u3063\u3066\u5168\u4F53\u306B\u98DB\u3093\u3067\u3044\u3063\u3061\u3083\u3046\u65B0\u5165\u751F\u306E\u56F3\u3001\u3082\u306F\u3084\u69D8\u5F0F\u7F8E\u3068\u8A00\u3046\u304B\u6625\u306E\u98A8\u7269\u8A69\u3060",
  "id" : 596720565018349569,
  "created_at" : "2015-05-08 16:57:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596639202021867520",
  "text" : "\u3081\u30FC\u308A\u3059\u304C\u3080\u3052\u3093\u306B\u964D\u308A\u6CE8\u3050",
  "id" : 596639202021867520,
  "created_at" : "2015-05-08 11:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596590963977367552",
  "geo" : { },
  "id_str" : "596591066528153600",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u306A\u3093\u3060\u304B\u3093\u3060\u4E00\u7DD2\u306B\u3044\u308B\u6642\u9593\u9577\u3044\u3067\u3059\u304B\u3089\u306D\u30FC\u5BB6\u65CF\u306F",
  "id" : 596591066528153600,
  "in_reply_to_status_id" : 596590963977367552,
  "created_at" : "2015-05-08 08:22:49 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596590094829498368",
  "geo" : { },
  "id_str" : "596590648469291008",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u307E\u3041\u8EAB\u8FD1\u3067\u3042\u308B\u3060\u3051\u6C17\u9063\u3044\u3068\u304B\u3057\u306A\u3044\u306E\u3067\u96D1\u306B\u306F\u306A\u308A\u307E\u3059\u3088\u306D\u30FC",
  "id" : 596590648469291008,
  "in_reply_to_status_id" : 596590094829498368,
  "created_at" : "2015-05-08 08:21:09 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596589678448349184",
  "geo" : { },
  "id_str" : "596589912297639936",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u50D5\u304C\u5C5E\u3059\u308B\u6570\u3005\u306E\u30B3\u30DF\u30E5\u30CB\u30C6\u30A3\u306E\u4E2D\u3067\u6700\u3082\u610F\u601D\u758E\u901A\u304C\u96E3\u3057\u3044\u30B3\u30DF\u30E5\u30CB\u30C6\u30A3\u304C\u5BB6\u65CF\u306A\u3093\u3067\u3059\u3088\u306D\u3001\u697D\u3057\u3044\u3067\u3059\u3051\u3069",
  "id" : 596589912297639936,
  "in_reply_to_status_id" : 596589678448349184,
  "created_at" : "2015-05-08 08:18:13 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 0, 7 ],
      "id_str" : "106036912",
      "id" : 106036912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596589113345576960",
  "geo" : { },
  "id_str" : "596589292538859520",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_k_y \u307E\u3041\u4ECA\u56DE\u306F\u666E\u901A\u306E\u304A\u5F01\u5F53\u3060\u3068\u601D\u3063\u3066\u305F\u3068\u5F01\u660E\u3057\u3066\u307E\u3059\u304C\u5BB6\u65CF\u307F\u3093\u306A\u3053\u3093\u306A\u611F\u3058\u306A\u306E\u3067\u305F\u306E\u3057\u3044\u304B\u3044\u308F",
  "id" : 596589292538859520,
  "in_reply_to_status_id" : 596589113345576960,
  "created_at" : "2015-05-08 08:15:46 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    }, {
      "name" : "HamminG",
      "screen_name" : "E8lattice",
      "indices" : [ 9, 19 ],
      "id_str" : "1533610844",
      "id" : 1533610844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596588585689616385",
  "geo" : { },
  "id_str" : "596588926686494720",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar @E8lattice \u3080\u3057\u308D\u3053\u3063\u3061\u5074\u304B\u3089\u7A4D\u6975\u7684\u306B\u98A8\u90AA\u3092\u62BC\u3057\u3066\u3044\u3051(\u304A\u5927\u4E8B\u306B)",
  "id" : 596588926686494720,
  "in_reply_to_status_id" : 596588585689616385,
  "created_at" : "2015-05-08 08:14:18 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596588706678513666",
  "text" : "\u5F7C\u5973\u672C\u5F53\u306B\u8A71\u3092\u805E\u3044\u3066\u306A\u3044",
  "id" : 596588706678513666,
  "created_at" : "2015-05-08 08:13:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596588671056248832",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u300C\u30DA\u30E4\u30F3\u30B0\u305D\u3082\u305D\u3082\u5317\u6D77\u9053\u3067\u58F2\u3063\u3066\u306A\u3044\u3093\u3060\u3088\u300D\n\u6BCD\u89AA\u300C\u3042\u30FC\u306A\u3093\u304B\u5317\u6D77\u9053\u9650\u5B9A\u306E\u3084\u304D\u305D\u3070\u3042\u308B\u3089\u3057\u3044\u306D\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3084\u304D\u305D\u3070\u5F01\u5F53\u306A\u300D\n\u6BCD\u89AA\u300C\u306A\u3093\u304B\u30BF\u30AB\u30C8\u30B7\u304CCM\u3057\u3066\u308B\u3084\u3064\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3084\u304D\u305D\u3070\u5F01\u5F53\u306A\u300D\n\u6BCD\u89AA\u300C\u9650\u5B9A\u306E\u3084\u3064\u3042\u308B\u3063\u3066\u805E\u3044\u305F\u3051\u3069\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u3084\u304D\u305D\u3070\u5F01\u5F53\u306A\uFF01\uFF01\uFF01\u300D",
  "id" : 596588671056248832,
  "created_at" : "2015-05-08 08:13:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596587876885745666",
  "text" : "\u76EE\u7389\u713C\u304D\u306E\u3063\u3051\u305F\u30DA\u30E4\u30F3\u30B0\u3068\u30C9\u30AF\u30BF\u30FC\u30DA\u30C3\u30D1\u30FC\u306E\u304A\u3084\u3064\u3001\u7F8E\u5473\u3057\u3044\u3051\u3069\u4F53\u306B\u60AA\u3044\u5473\u3057\u304B\u3057\u306A\u3044\u3051\u3069\u5317\u6D77\u9053\u3067\u306F\u5B9F\u73FE\u53EF\u80FD\u6027\u3081\u3063\u3061\u3083\u4F4E\u3044\u304B\u3089\u3084\u3063\u3071\u308A\u7F8E\u5473\u3057\u3044",
  "id" : 596587876885745666,
  "created_at" : "2015-05-08 08:10:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596587632118759424",
  "text" : "\u30CF\u30A4\u30E8\u30ED\u30B3\u30F3\u30C7\u30FC\u2026",
  "id" : 596587632118759424,
  "created_at" : "2015-05-08 08:09:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30D5\u30EA\u30AB\u306E\u661F\u9006",
      "screen_name" : "hosisaka",
      "indices" : [ 3, 12 ],
      "id_str" : "167325286",
      "id" : 167325286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596587586132410368",
  "text" : "RT @hosisaka: \u304D\u304E\u3087\u3046\u306E\u3048\u3089\u3044\u3072\u3068\u300C8\u6708\u304B\u3089\u9762\u63A5\u30027\u6708\u306F\u9762\u8AC7\u300D\n\u50D5\u300C\u3048\u3001\u3067\u3082\u305D\u308C\u540Cz\u300D\n\u304D\u304E\u3087\u3046\u306E\u3048\u3089\u3044\u3072\u3068\u300C7\u6708\u306B\u9762\u63A5\u306F\u30A2\u30A6\u30A2\u30A6\u3002\u3067\u3082\u30017\u6708\u306B\u9762\u8AC7\u306F\u30BB\u30D5\u30BB\u30D5\u300D\n\u50D5\u300C\u3067\u3082\u300D\n\u304D\u304E\u3087\u3046\u306E\u3048\u3089\u3044\u3072\u3068\u300C7\u6708\u306F\u9762\u8AC7\u3002\u5B9F\u969B\u5408\u6CD5\u3002\u3044\u3044\u306D\uFF1F\u300D\n\u50D5\u300C\u30A2\u30C3\u30CF\u30A4\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596586394828427264",
    "text" : "\u304D\u304E\u3087\u3046\u306E\u3048\u3089\u3044\u3072\u3068\u300C8\u6708\u304B\u3089\u9762\u63A5\u30027\u6708\u306F\u9762\u8AC7\u300D\n\u50D5\u300C\u3048\u3001\u3067\u3082\u305D\u308C\u540Cz\u300D\n\u304D\u304E\u3087\u3046\u306E\u3048\u3089\u3044\u3072\u3068\u300C7\u6708\u306B\u9762\u63A5\u306F\u30A2\u30A6\u30A2\u30A6\u3002\u3067\u3082\u30017\u6708\u306B\u9762\u8AC7\u306F\u30BB\u30D5\u30BB\u30D5\u300D\n\u50D5\u300C\u3067\u3082\u300D\n\u304D\u304E\u3087\u3046\u306E\u3048\u3089\u3044\u3072\u3068\u300C7\u6708\u306F\u9762\u8AC7\u3002\u5B9F\u969B\u5408\u6CD5\u3002\u3044\u3044\u306D\uFF1F\u300D\n\u50D5\u300C\u30A2\u30C3\u30CF\u30A4\u300D",
    "id" : 596586394828427264,
    "created_at" : "2015-05-08 08:04:15 +0000",
    "user" : {
      "name" : "\u30A2\u30D5\u30EA\u30AB\u306E\u661F\u9006",
      "screen_name" : "hosisaka",
      "protected" : false,
      "id_str" : "167325286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605255479590133762\/vjL-2-Ae_normal.jpg",
      "id" : 167325286,
      "verified" : false
    }
  },
  "id" : 596587586132410368,
  "created_at" : "2015-05-08 08:08:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596582612036026368",
  "text" : "350km\u306B\u6E21\u3063\u3066\u9577\u3044\u65C5\u3092\u3057\u3066\u304D\u305F\u304D\u306C\u3044\u3068\u30DA\u30E4\u30F3\u30B0\u3092\u4ECA\u3053\u3053\u3067\u98DF\u3079\u308B\uFF01",
  "id" : 596582612036026368,
  "created_at" : "2015-05-08 07:49:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596526216825319425",
  "geo" : { },
  "id_str" : "596527245935546369",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u8CE2\u3044",
  "id" : 596527245935546369,
  "in_reply_to_status_id" : 596526216825319425,
  "created_at" : "2015-05-08 04:09:13 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596525627622064128",
  "text" : "\u30A4\u30CE\u30D9\u30FC\u30B7\u30E7\u30F3\u3060",
  "id" : 596525627622064128,
  "created_at" : "2015-05-08 04:02:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596525611562078210",
  "text" : "\u6BD2\u5165\u308A\u306E\u76BF\u3092\u58F2\u308C\u3070\u6BD2\u3068\u76BF\u3092\u540C\u6642\u306B\u6442\u53D6\u3067\u304D\u3066\u52B9\u7387\u304C\u3088\u3044\u306E\u3067\u306F",
  "id" : 596525611562078210,
  "created_at" : "2015-05-08 04:02:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596520804113731584",
  "geo" : { },
  "id_str" : "596521597231464449",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u72EC\u7ACB\u3060\u3068\u3070\u304B\u308A\u601D\u3063\u3066\u3044\u305F\u2026",
  "id" : 596521597231464449,
  "in_reply_to_status_id" : 596520804113731584,
  "created_at" : "2015-05-08 03:46:46 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596519810525081600",
  "geo" : { },
  "id_str" : "596519919870550016",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6BD2\u304C\u5668\u306B\u5165\u3063\u3066\u3044\u308B\u306A\u3093\u3066\u3082\u306E\u306F\u504F\u898B\u306B\u904E\u304E\u306A\u3044",
  "id" : 596519919870550016,
  "in_reply_to_status_id" : 596519810525081600,
  "created_at" : "2015-05-08 03:40:06 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596519850110914561",
  "text" : "\u7D9A\u3044\u3066\u3082\u7D9A\u304B\u306A\u304F\u3066\u3082\u305D\u3093\u306A\u306E\u306F\u3069\u3061\u3089\u3067\u3082\u540C\u3058\u5B50\u3068\u3060",
  "id" : 596519850110914561,
  "created_at" : "2015-05-08 03:39:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596519317635616768",
  "geo" : { },
  "id_str" : "596519546573361152",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u671F\u5F85\u3057\u3059\u304E\u308B\u3068\uFF8A\uFF9F\uFF8B\uFF9F\uFF6F\u3063\u3066\u306A\u308A\u304B\u306D\u306A\u3044\u304B\u3089\u6C17\u3092\u3064\u3051\u306A\u3044\u3068\u306A",
  "id" : 596519546573361152,
  "in_reply_to_status_id" : 596519317635616768,
  "created_at" : "2015-05-08 03:38:37 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596519264326057984",
  "geo" : { },
  "id_str" : "596519354755219456",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6BD2\u3082\u98DF\u3079\u6B8B\u3057\u305F\u3093\u3058\u3083\u306A\u3044\u304B\u3002\u3060\u304B\u3089\u76BF\u3082\u98DF\u3079\u6B8B\u3057\u305F\u3002",
  "id" : 596519354755219456,
  "in_reply_to_status_id" : 596519264326057984,
  "created_at" : "2015-05-08 03:37:51 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596518960427761665",
  "text" : "\uFF8C\uFF68\uFF6F\uFF7C\uFF6D\uFF71\uFF9D\uFF84\uFF9E\uFF81\uFF6F\uFF8C\uFF9F\uFF7D",
  "id" : 596518960427761665,
  "created_at" : "2015-05-08 03:36:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596518704067706880",
  "geo" : { },
  "id_str" : "596518924457381889",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \uFF8C\uFF68\uFF6F\uFF7C\uFF6D\uFF71\uFF9D\uFF84\uFF9E\uFF81\uFF6F\uFF8C\uFF9F\uFF7D\u306A\u30FC\u3002\u305D\u3053\u307E\u3067\u3044\u3051\u308B\u4EBA\u306F\u306A\u304B\u306A\u304B\u3044\u306A\u3044\u3002",
  "id" : 596518924457381889,
  "in_reply_to_status_id" : 596518704067706880,
  "created_at" : "2015-05-08 03:36:09 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596518220430839808",
  "geo" : { },
  "id_str" : "596518395350122497",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \uFF84\uFF9E\uFF69\uFF9D\uFF82\uFF78\u306F\u304B\u306A\u308A\u3044\u308B\u306A\u30FC\u3002\u3061\u3087\u3063\u3068\u76EE\u969C\u308A\u3002\u305D\u3053\u307E\u3067\u3044\u304F\u306A\u3089\uFF77\uFF9E\uFF86\uFF6C\uFF86\uFF6D\u304F\u3089\u3044\u307E\u3067\u3044\u3051\u3070\u3044\u3044\u306E\u306B\u4E2D\u9014\u534A\u7AEF\u306A\u611F\u3058\u3059\u308B\u3088\u306D\u3002",
  "id" : 596518395350122497,
  "in_reply_to_status_id" : 596518220430839808,
  "created_at" : "2015-05-08 03:34:02 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596517672923213825",
  "geo" : { },
  "id_str" : "596517890393706496",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3055\u3059\u304C\u306B\uFF8A\uFF9F\uFF8B\uFF9F\uFF6F\u306B\u306A\u308B\u3053\u3068\u306F\u306A\u3044\u3067\u3057\u3087\uFF5E\u30024\u30F6\u6708\u5F8C\u306A\u3089\u3068\u3082\u304B\u304F\u4ECA\u306E\u6BB5\u968E\u3067\uFF8A\uFF9F\uFF8B\uFF9F\uFF6F\u3063\u3066\u306A\u3063\u3066\u308B\u4EBA\u898B\u305F\u3053\u3068\u7121\u3044\u3057\u3002",
  "id" : 596517890393706496,
  "in_reply_to_status_id" : 596517672923213825,
  "created_at" : "2015-05-08 03:32:02 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596517323818729472",
  "geo" : { },
  "id_str" : "596517440168730624",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u306B\u3087\u308F\u30FC\u3093\u3063\u3066\u611F\u3058\u3067\u3059\u306D",
  "id" : 596517440168730624,
  "in_reply_to_status_id" : 596517323818729472,
  "created_at" : "2015-05-08 03:30:15 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596517054284308480",
  "text" : "\u306F\u3041\uFF5E\u3044\u3044\u305F\u3044\u3053\u3068\u3082\u3044\u3048\u306A\u3044\u3053\u3093\u306A\u3088\u306E\u306A\u304B\u3060\u308F\uFF5E",
  "id" : 596517054284308480,
  "created_at" : "2015-05-08 03:28:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596516630143729664",
  "text" : "\u30DC\u30B1\u308B\u3068\u304D\u306B\u306F\u660E\u793A\u7684\u306B\u3084\u3089\u306A\u3044\u3068\u304B\u306A\u3057\u3044\u3053\u3068\u306B\u306A\u308B\u3068\u304D\u304C\u306A",
  "id" : 596516630143729664,
  "created_at" : "2015-05-08 03:27:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596515991951028224",
  "text" : "95\u5272",
  "id" : 596515991951028224,
  "created_at" : "2015-05-08 03:24:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596508301333962752",
  "geo" : { },
  "id_str" : "596508437636255746",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6BD2\u98DF\u3079\u305F\u306E\u3067\u306F",
  "id" : 596508437636255746,
  "in_reply_to_status_id" : 596508301333962752,
  "created_at" : "2015-05-08 02:54:28 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/596353308224159745\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CW1khNvkCo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEasK-qWoAEUHqY.jpg",
      "id_str" : "596353305292480513",
      "id" : 596353305292480513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEasK-qWoAEUHqY.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 398
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 398
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 398
      } ],
      "display_url" : "pic.twitter.com\/CW1khNvkCo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596353308224159745",
  "text" : "http:\/\/t.co\/CW1khNvkCo",
  "id" : 596353308224159745,
  "created_at" : "2015-05-07 16:38:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596352983211769856",
  "text" : "\u3042\u30FC\u6642\u9593is\u3042\u3093\u307E\u308A\u306A\u3044\u3042\u30FC",
  "id" : 596352983211769856,
  "created_at" : "2015-05-07 16:36:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "so26078149",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "nicoch",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/688vFyXrRx",
      "expanded_url" : "http:\/\/nico.ms\/1429604399",
      "display_url" : "nico.ms\/1429604399"
    } ]
  },
  "geo" : { },
  "id_str" : "596345433179299840",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC \u30D5\u30ED\u30E0\u30A2\u30CB\u30E1\u30A4\u30B7\u30E8\u30F3\u3000\u7B2C4\u8A71 (14:22) http:\/\/t.co\/688vFyXrRx #so26078149 #nicoch \u30A2\u30FC\u826F\u3044\u2026\u9065\u304B\u306B\u826F\u3044\u3067\u3059\u2026",
  "id" : 596345433179299840,
  "created_at" : "2015-05-07 16:06:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596341517469356033",
  "text" : "\u300C\u6BBA\u3059\u300D\u3068\u304B\u8A00\u3046\u5358\u8A9E\u3001\u610F\u5473\u7684\u306B\u3082\u9762\u767D\u3055\u7684\u306B\u3082\u5F37\u3059\u304E\u308B\u304B\u3089\u4F7F\u7528\u3092\u63A7\u3048\u3066\u3044\u308B\u304C\u601D\u3044\u3064\u3044\u3066\u3057\u307E\u3063\u305F\u304B\u3089\u4ED5\u65B9\u306A\u3044\u3002",
  "id" : 596341517469356033,
  "created_at" : "2015-05-07 15:51:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596341366675800064",
  "text" : "\u8033\u304B\u3089\u30BF\u30B3\u304C\u51FA\u308B\u3002\u305D\u3057\u3066\u304A\u524D\u3092\u6BBA\u3059\u3002",
  "id" : 596341366675800064,
  "created_at" : "2015-05-07 15:50:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596313362432069632",
  "text" : "\u3048\u3089\u3044",
  "id" : 596313362432069632,
  "created_at" : "2015-05-07 13:59:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596313346648842240",
  "text" : "\u3048\u3089\u3044\u304B\u3089\u9332\u97F3\u3057\u305F\u30A2\u30EC\u6D3B\u8AAC\u660E\u4F1A\u306E\u4E2D\u8EAB\u3092\u3057\u3063\u304B\u308A\u805E\u304D\u306A\u304A\u3057\u3066\u3044\u308B",
  "id" : 596313346648842240,
  "created_at" : "2015-05-07 13:59:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30EB\u30D5\u30A1\u30CB\u30AA\u30F3\u30D5\u30A1\u30DF\u30EA\u30FC",
      "screen_name" : "killfar",
      "indices" : [ 0, 8 ],
      "id_str" : "300742004",
      "id" : 300742004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596311852834951169",
  "geo" : { },
  "id_str" : "596312160025739264",
  "in_reply_to_user_id" : 300742004,
  "text" : "@killfar \u3081\u3057\u3042\u304C\u308C",
  "id" : 596312160025739264,
  "in_reply_to_status_id" : 596311852834951169,
  "created_at" : "2015-05-07 13:54:32 +0000",
  "in_reply_to_screen_name" : "killfar",
  "in_reply_to_user_id_str" : "300742004",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7720\u308A\u514E@\u65E5\u713C\u3051\u3057\u305F",
      "screen_name" : "sleeping_keyR",
      "indices" : [ 0, 14 ],
      "id_str" : "1027496239",
      "id" : 1027496239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596309021235150848",
  "geo" : { },
  "id_str" : "596309630256480257",
  "in_reply_to_user_id" : 1027496239,
  "text" : "@sleeping_keyR \u3044\u3061\u304A\u3046\u52E4\u52D9\u5730\u306F\u6771\u4EAC\u3067\u8003\u3048\u3066\u308B\u306E\u3067\u305D\u306E\u6642\u306F\u305C\u3072",
  "id" : 596309630256480257,
  "in_reply_to_status_id" : 596309021235150848,
  "created_at" : "2015-05-07 13:44:29 +0000",
  "in_reply_to_screen_name" : "sleeping_keyR",
  "in_reply_to_user_id_str" : "1027496239",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596308708142940160",
  "text" : "\u25EF\u25EF\u3084 \u3042\u309D\u25EF\u25EF\u3084 \u25EF\u25EF\u3084\u69CB\u6587\u3060",
  "id" : 596308708142940160,
  "created_at" : "2015-05-07 13:40:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596308644385263618",
  "text" : "\u671B\u6708\u3084 \u3042\u309D\u671B\u6708\u3084 \u671B\u6708\u3084",
  "id" : 596308644385263618,
  "created_at" : "2015-05-07 13:40:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7720\u308A\u514E@\u65E5\u713C\u3051\u3057\u305F",
      "screen_name" : "sleeping_keyR",
      "indices" : [ 0, 14 ],
      "id_str" : "1027496239",
      "id" : 1027496239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596308246211604483",
  "geo" : { },
  "id_str" : "596308372686639104",
  "in_reply_to_user_id" : 1027496239,
  "text" : "@sleeping_keyR \u305D\u3046\u3067\u3059\u3088\u3002\u6771\u4EAC\u51FA\u8EAB\u3067\u3059\u3088\u30FC\u3002\u3076\u3063\u3061\u3083\u3051TU\u306E\u65B9\u304C\u3088\u3063\u307D\u3069\u8FD1\u3044\u4F4D\u7F6E\u306B\u4F4F\u3093\u3067\u307E\u3059\u3002",
  "id" : 596308372686639104,
  "in_reply_to_status_id" : 596308246211604483,
  "created_at" : "2015-05-07 13:39:29 +0000",
  "in_reply_to_screen_name" : "sleeping_keyR",
  "in_reply_to_user_id_str" : "1027496239",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596308063910432768",
  "text" : "\u3057\u304B\u3057\u307E\u3041\u5F7C\u3089\u306E\u5B9F\u5BB6\u306B\u9695\u77F3\u304C\u6FC0\u7A81\u3059\u308C\u3070\u3044\u305A\u308C\u4E0B\u5BBF\u5148\u306B\u3082\u5C45\u3089\u308C\u306A\u304F\u306A\u308B\u304B\u3089\u7D50\u679C\u30AA\u30FC\u30E9\u30A4\u304B\uFF08\uFF1F\uFF09",
  "id" : 596308063910432768,
  "created_at" : "2015-05-07 13:38:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5409\u7530\u5584\u54C9",
      "screen_name" : "yoshinari_yo",
      "indices" : [ 3, 16 ],
      "id_str" : "1186140702",
      "id" : 1186140702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596307922432299008",
  "text" : "RT @yoshinari_yo: \u305D\u3053\u306F\u4E0B\u5BBF\u5148\u306B\u3057\u3068\u304F\u3079\u304D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596307868300673024",
    "text" : "\u305D\u3053\u306F\u4E0B\u5BBF\u5148\u306B\u3057\u3068\u304F\u3079\u304D",
    "id" : 596307868300673024,
    "created_at" : "2015-05-07 13:37:29 +0000",
    "user" : {
      "name" : "\u5409\u7530\u5584\u54C9",
      "screen_name" : "yoshinari_yo",
      "protected" : false,
      "id_str" : "1186140702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579145456107704320\/QdWdN7lG_normal.jpg",
      "id" : 1186140702,
      "verified" : false
    }
  },
  "id" : 596307922432299008,
  "created_at" : "2015-05-07 13:37:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596307812977782785",
  "text" : "\u3054\u3082\u3063\u3068\u3082\u3060",
  "id" : 596307812977782785,
  "created_at" : "2015-05-07 13:37:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5409\u7530\u5584\u54C9",
      "screen_name" : "yoshinari_yo",
      "indices" : [ 3, 16 ],
      "id_str" : "1186140702",
      "id" : 1186140702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596307758288244737",
  "text" : "RT @yoshinari_yo: \u5B9F\u5BB6\u306B\u7F6A\u306F\u306A\u3044\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596305887435689984",
    "text" : "\u5B9F\u5BB6\u306B\u7F6A\u306F\u306A\u3044\u2026",
    "id" : 596305887435689984,
    "created_at" : "2015-05-07 13:29:37 +0000",
    "user" : {
      "name" : "\u5409\u7530\u5584\u54C9",
      "screen_name" : "yoshinari_yo",
      "protected" : false,
      "id_str" : "1186140702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579145456107704320\/QdWdN7lG_normal.jpg",
      "id" : 1186140702,
      "verified" : false
    }
  },
  "id" : 596307758288244737,
  "created_at" : "2015-05-07 13:37:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596306818445381633",
  "text" : "\u3064\u307E\u308A\u8AB0\u304C\u8A00\u3063\u3066\u3082\uFF71\uFF9A\u306A\u306E\u3067\u8A9E\u3063\u3066\u306F\u3044\u3051\u306A\u3044\u3084\u3064\u3060",
  "id" : 596306818445381633,
  "created_at" : "2015-05-07 13:33:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596306510465998849",
  "geo" : { },
  "id_str" : "596306729740029952",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u6731\u306B\u4EA4\u308F\u308C\u3069\u3082\u6731\u304F\u306A\u308B\u3068\u306F\u9650\u3089\u306A\u3044",
  "id" : 596306729740029952,
  "in_reply_to_status_id" : 596306510465998849,
  "created_at" : "2015-05-07 13:32:57 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596306596239544320",
  "text" : "\u3067\u3082\u300C\u7D50\u5A5A\u306F\u30B3\u30B9\u30D1\u60AA\u3044\u300D\u30A2\u30C3\u30D4\u30EB\u306F\u7D50\u5A5A\u3057\u305F\u4EBA\u9593\u304C\u3084\u308B\u3068\u5ACC\u5473\u3063\u307D\u3044\u3057\u3001\u7D50\u5A5A\u3057\u3066\u306A\u3044\u4EBA\u9593\u304C\u3084\u308B\u3068\u305F\u3060\u306E\u8CA0\u3051\u60DC\u3057\u307F\u3063\u307D\u3044\u3057\u3001\u300C\u5B66\u6B74\u306A\u3093\u3066\u95A2\u4FC2\u306A\u3044\u3088\u300D\u767A\u8A00\u3068\u4F3C\u3066\u3044\u308B",
  "id" : 596306596239544320,
  "created_at" : "2015-05-07 13:32:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596306115547107331",
  "text" : "\u30B3\u30B9\u30D1\u306F\u60AA\u3044\u3051\u3069\u305D\u308C\u306F\u305D\u308C",
  "id" : 596306115547107331,
  "created_at" : "2015-05-07 13:30:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596305933292056576",
  "geo" : { },
  "id_str" : "596306065127448577",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u3042\u3002\u5206\u304B\u3063\u3066\u308B\u3068\u306F\u601D\u3046\u3051\u3069\u5225\u306B\u50D5\u306F\u7D50\u5A5A\u53CD\u5BFE\u6D3E\u3068\u304B\u305D\u3046\u3044\u3046\u308F\u3051\u3067\u306F\u306A\u3044\u3088\u3002",
  "id" : 596306065127448577,
  "in_reply_to_status_id" : 596305933292056576,
  "created_at" : "2015-05-07 13:30:19 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596304953422925824",
  "text" : "\u7D50\u5A5A\u306F\u30B3\u30B9\u30D1\u60AA\u3044\u3068\u304B\u5929\u5730\u958B\u95E2\u4EE5\u6765\u8A00\u308F\u308C\u7D9A\u3051\u3066\u308B\u3067\u3057\u3087",
  "id" : 596304953422925824,
  "created_at" : "2015-05-07 13:25:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7720\u308A\u514E@\u65E5\u713C\u3051\u3057\u305F",
      "screen_name" : "sleeping_keyR",
      "indices" : [ 0, 14 ],
      "id_str" : "1027496239",
      "id" : 1027496239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596303621353967617",
  "geo" : { },
  "id_str" : "596304712988626944",
  "in_reply_to_user_id" : 1027496239,
  "text" : "@sleeping_keyR \u3044\u3048\u3001\u5B9F\u5BB6\u304C\u6771\u4EAC\u306A\u306E\u3067\u6771\u4EAC\u3067\u3084\u3063\u3066\u307E\u3059\u306D\u3002\u5317\u6D77\u9053\u3067\u3084\u3063\u3066\u304F\u308C\u308B\u4F01\u696D\u3082\u3042\u308B\u306E\u3067\u305D\u306E\u9650\u308A\u3067\u306F\u306A\u3044\u3067\u3059\u3051\u308C\u3069\u3002",
  "id" : 596304712988626944,
  "in_reply_to_status_id" : 596303621353967617,
  "created_at" : "2015-05-07 13:24:57 +0000",
  "in_reply_to_screen_name" : "sleeping_keyR",
  "in_reply_to_user_id_str" : "1027496239",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7720\u308A\u514E@\u65E5\u713C\u3051\u3057\u305F",
      "screen_name" : "sleeping_keyR",
      "indices" : [ 0, 14 ],
      "id_str" : "1027496239",
      "id" : 1027496239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596302828915720192",
  "geo" : { },
  "id_str" : "596303223469658112",
  "in_reply_to_user_id" : 1027496239,
  "text" : "@sleeping_keyR \u5358\u7D14\u306B\u904B\u304C\u60AA\u304B\u3063\u305F\u3093\u3067\u3059\u306D\u3002\u305F\u3076\u3093",
  "id" : 596303223469658112,
  "in_reply_to_status_id" : 596302828915720192,
  "created_at" : "2015-05-07 13:19:01 +0000",
  "in_reply_to_screen_name" : "sleeping_keyR",
  "in_reply_to_user_id_str" : "1027496239",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7720\u308A\u514E@\u65E5\u713C\u3051\u3057\u305F",
      "screen_name" : "sleeping_keyR",
      "indices" : [ 0, 14 ],
      "id_str" : "1027496239",
      "id" : 1027496239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596302312752041985",
  "geo" : { },
  "id_str" : "596302474052415488",
  "in_reply_to_user_id" : 1027496239,
  "text" : "@sleeping_keyR \u305D\u306E\u5F8C\u306E\u30A8\u30F3\u30C8\u30EA\u30FC\u306B\u5FC5\u9808\u306A\u30A4\u30D9\u30F3\u30C8\u3060\u3063\u305F\u306E\u3067\u4ED5\u65B9\u306A\u3044\u304B\u3082\u3067\u3059\u304C\u2026\u306D\u3047",
  "id" : 596302474052415488,
  "in_reply_to_status_id" : 596302312752041985,
  "created_at" : "2015-05-07 13:16:03 +0000",
  "in_reply_to_screen_name" : "sleeping_keyR",
  "in_reply_to_user_id_str" : "1027496239",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596302218942222336",
  "text" : "\u30A4\u30B7\u30AD\u30BF\u30AB\u30A4\u4EBA\u3082\u5384\u4ECB\u3060\u3051\u3069\u30A4\u30B7\u30AD\u30D2\u30AF\u30A4\u3092\u5168\u9762\u306B\u51FA\u3059\u4EBA\u9593\u3082\u5384\u4ECB\u306A\u3093\u3084\u3067",
  "id" : 596302218942222336,
  "created_at" : "2015-05-07 13:15:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596302069830520833",
  "text" : "\u3044\u3084\u307B\u3093\u3068\u3001\u3084\u308B\u6C17\u7121\u3044\u306A\u3089\u6765\u308B\u306A\u3088\u3063\u3066",
  "id" : 596302069830520833,
  "created_at" : "2015-05-07 13:14:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596302013484257280",
  "text" : "\u5C02\u653B\u306E\u8A55\u4FA1\u306B\u95A2\u308F\u3089\u306A\u3044\u304B\u3089\u4F55\u3082\u8A00\u308F\u306A\u304B\u3063\u305F\uFF08\u3048\u3089\u3044",
  "id" : 596302013484257280,
  "created_at" : "2015-05-07 13:14:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596301682729824259",
  "text" : "\u30A2\u30EC\u6D3B\u30A4\u30D9\u30F3\u30C8\u3001\u8AAC\u660E\u4F1A\u306E\u5EF6\u9577\u306E\u3050\u308B\u30FC\u3077\u308F\u30FC\u304F\u3067\u4E00\u7DD2\u306B\u306A\u3063\u305F\u4EBA\u9593\u304C\u300C\u7720\u3044\u300D\u300C\u304A\u8179\u6E1B\u3063\u305F\u300D\u300C\u30BF\u30D0\u30B3\u5438\u3044\u305F\u3044\u300D\u300C\u5B66\u6821\u306B\u7740\u3066\u305F\u30EA\u30AF\u30EB\u30FC\u30BF\u306E\u5973\u6027\u304C\u53EF\u611B\u304B\u3063\u305F\u304B\u3089\u6765\u305F\u300D\u300C\u5358\u4F4D\u3084\u3079\u3047\u300D\u3092\u5782\u308C\u6D41\u3059\u5927\u30CF\u30BA\u30EC\u3060\u3063\u305F\u306E\u3067\u63A7\u3048\u3081\u306B\u8A00\u3063\u3066\u3053\u3044\u3064\u3089\u306E\u5B9F\u5BB6\u306B\u9695\u77F3\u843D\u3061\u3066\u3053\u3044\u3063\u3066\u601D\u3063\u305F",
  "id" : 596301682729824259,
  "created_at" : "2015-05-07 13:12:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596009264243605505",
  "text" : "\u304A\u3084\u3059\u307F\u304A\u3084\u3059\u307F",
  "id" : 596009264243605505,
  "created_at" : "2015-05-06 17:50:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596009237374898176",
  "text" : "\u5BDD\u306A\u3044\u3068\u5BDD\u306A\u3044\u3068",
  "id" : 596009237374898176,
  "created_at" : "2015-05-06 17:50:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596008946889928704",
  "text" : "\u7761\u7720\u3068\u304B\u3044\u3046\u306E\u4ED5\u4E8B\u7387100%\u3060\u3057\u52B9\u7387\u826F\u3044",
  "id" : 596008946889928704,
  "created_at" : "2015-05-06 17:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596008038454038528",
  "text" : "\u5C55\u958B\u77E5\u3063\u3066\u3066\u3082\u624B\u306B\u6C57\u63E1\u308B\u3082\u3093\u306A\u3041",
  "id" : 596008038454038528,
  "created_at" : "2015-05-06 17:46:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/BtmUHceHXU",
      "expanded_url" : "http:\/\/nico.ms\/1430190505",
      "display_url" : "nico.ms\/1430190505"
    } ]
  },
  "geo" : { },
  "id_str" : "596007973148758016",
  "text" : "\u9CE5\u808C\u304C\u6B62\u307E\u3089\u306A\u3044\u2026\u795E\u56DE\u3060\n\u30B7\u30C9\u30CB\u30A2\u306E\u9A0E\u58EB \u7B2C\u4E5D\u60D1\u661F\u6226\u5F79\u3000\u7B2C4\u8A71\u300C\u6FC0\u6602\u300D \nhttp:\/\/t.co\/BtmUHceHXU",
  "id" : 596007973148758016,
  "created_at" : "2015-05-06 17:45:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595944094112747520",
  "text" : "\u4EC4\u30B7\u30EA\u30FC\u30BA\u7DCF\u9078\u6319\u3046\u3051\u308B",
  "id" : 595944094112747520,
  "created_at" : "2015-05-06 13:31:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595943898913976321",
  "text" : "\u3088\u305B\u306A\u3079 \u305F\u307E\u3054\u3084\u304D \u304A\u3080\u3089\u3044\u3059 \u305F\u3051\u306E\u3053\u3054\u306F\u3093",
  "id" : 595943898913976321,
  "created_at" : "2015-05-06 13:31:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595919527927541760",
  "text" : "\u306C\u30FC\u30FC\u30FC\u3093",
  "id" : 595919527927541760,
  "created_at" : "2015-05-06 11:54:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595919501591506945",
  "text" : "\u611A\u59B9\u306E\u53CB\u4EBA\u3089\u304C\u5916\u3067\u9A12\u3044\u3067\u3044\u3066\u306C\u30FC\u3093",
  "id" : 595919501591506945,
  "created_at" : "2015-05-06 11:54:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595917499188785152",
  "text" : "\u306B\u3087\u308F\u306B\u3087\u308F",
  "id" : 595917499188785152,
  "created_at" : "2015-05-06 11:46:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595484095578284032",
  "text" : "\u65E9\u304F\u3064\u3044\u305F\u3089ingress\u3067\u3082\u3057\u3066\u308C\u3070\u826F\u3044\u3067\u305D",
  "id" : 595484095578284032,
  "created_at" : "2015-05-05 07:04:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EBA",
      "indices" : [ 63, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595484055119998977",
  "text" : "19\uFF1A20\u306E\u5F85\u3061\u5408\u308F\u305B\u306E\u524D\u306Bingress\u3059\u308B\u305F\u3081\u306B17\uFF1A00\u306B\u5F85\u3061\u5408\u308F\u305B\u3059\u308B\u3051\u3069\u300116\uFF1A30\u306B\u306F\u3064\u304D\u305D\u3046\u306A\u6642\u9593\u3067\u51FA\u304B\u3051\u308B\u4EBA #\u4EBA",
  "id" : 595484055119998977,
  "created_at" : "2015-05-05 07:03:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595482407433838593",
  "text" : "\u306A\u3093\u3084\u306A\u3093\u3084\u306E\u30B3\u30D4\u30DA\u304A\u3082\u3044\u3060\u3057\u305F",
  "id" : 595482407433838593,
  "created_at" : "2015-05-05 06:57:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EMoeoXHW56",
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/593379317968572416",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    }, {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/H5ULVvhnWa",
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/593379467738775552",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    }, {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/7Ha8veOX20",
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/593380109664399363",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595482055410069504",
  "text" : "http:\/\/t.co\/EMoeoXHW56\nhttp:\/\/t.co\/H5ULVvhnWa\nhttp:\/\/t.co\/7Ha8veOX20\n\u3053\u306E\u6642\u3068\u304A\u3093\u306A\u3058\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u306E\uFF71\uFF76\uFF95\uFF9D\uFF96\u3060",
  "id" : 595482055410069504,
  "created_at" : "2015-05-05 06:56:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595481586021343232\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/WcJffY3iih",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEOTVVkUsAErVx_.png",
      "id_str" : "595481570519068673",
      "id" : 595481570519068673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEOTVVkUsAErVx_.png",
      "sizes" : [ {
        "h" : 377,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/WcJffY3iih"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595481586021343232",
  "text" : "r4s\u306A http:\/\/t.co\/WcJffY3iih",
  "id" : 595481586021343232,
  "created_at" : "2015-05-05 06:54:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595251693534609408",
  "text" : "\u3081\u3063\uFF01\u5B8C\u5168\u306B\u3042\u30FC\u3063\u3066\u8A00\u308F\u306A\u3044\u306E\uFF01",
  "id" : 595251693534609408,
  "created_at" : "2015-05-04 15:40:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9752\u6C5F \u6182 @\u304C\u3093\u3070\u3089\u306D\u3070",
      "screen_name" : "aoeui666",
      "indices" : [ 0, 9 ],
      "id_str" : "821299302",
      "id" : 821299302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595211202684293120",
  "geo" : { },
  "id_str" : "595211944379875328",
  "in_reply_to_user_id" : 821299302,
  "text" : "@aoeui666 23\u6642\u306B\u306F\u884C\u3051\u308B\u3068\u601D\u3044\u307E\u3059\u3002\u9045\u308C\u3066\u3059\u307F\u307E\u305B\u3093\u3002",
  "id" : 595211944379875328,
  "in_reply_to_status_id" : 595211202684293120,
  "created_at" : "2015-05-04 13:02:40 +0000",
  "in_reply_to_screen_name" : "aoeui666",
  "in_reply_to_user_id_str" : "821299302",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9752\u6C5F \u6182 @\u304C\u3093\u3070\u3089\u306D\u3070",
      "screen_name" : "aoeui666",
      "indices" : [ 0, 9 ],
      "id_str" : "821299302",
      "id" : 821299302
    }, {
      "name" : "\u308C\u3093\u307E(88%)",
      "screen_name" : "tononro",
      "indices" : [ 10, 18 ],
      "id_str" : "118676218",
      "id" : 118676218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594848135156924417",
  "geo" : { },
  "id_str" : "595210990393790464",
  "in_reply_to_user_id" : 821299302,
  "text" : "@aoeui666 @tononro \u9593\u306B\u5408\u308F\u306A\u3044\u3063\u307D\u3044\u3067\u3059\u304Cslack\u3060\u3051\u306A\u3089\u3044\u3051\u307E\u3059",
  "id" : 595210990393790464,
  "in_reply_to_status_id" : 594848135156924417,
  "created_at" : "2015-05-04 12:58:53 +0000",
  "in_reply_to_screen_name" : "aoeui666",
  "in_reply_to_user_id_str" : "821299302",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3048\u308C\u3082\u3002",
      "screen_name" : "eremoremo",
      "indices" : [ 0, 10 ],
      "id_str" : "87585638",
      "id" : 87585638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595104303829819392",
  "geo" : { },
  "id_str" : "595115929425448960",
  "in_reply_to_user_id" : 87585638,
  "text" : "@eremoremo \u798F\u52A9\u3068\u3044\u3046\u304A\u5E97\u3092\u85A6\u3081\u3089\u308C\u3066\u884C\u3063\u3066\u304D\u307E\u3057\u305F\u3002\u725B\u30BF\u30F3\u3082\u4E09\u89D2\u63DA\u3052\u3082\u304A\u306B\u304E\u308A\u3082\u7F8E\u5473\u3057\u3085\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "id" : 595115929425448960,
  "in_reply_to_status_id" : 595104303829819392,
  "created_at" : "2015-05-04 06:41:08 +0000",
  "in_reply_to_screen_name" : "eremoremo",
  "in_reply_to_user_id_str" : "87585638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595115721891287040\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/zPIZhz4Vl7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEJGluPVIAArtb9.jpg",
      "id_str" : "595115714647760896",
      "id" : 595115714647760896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEJGluPVIAArtb9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/zPIZhz4Vl7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595115721891287040",
  "text" : "\u90A3\u73C2\u5DDD http:\/\/t.co\/zPIZhz4Vl7",
  "id" : 595115721891287040,
  "created_at" : "2015-05-04 06:40:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595064739329224704",
  "geo" : { },
  "id_str" : "595073451825635328",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3093\u3042\u30FC\u3001\u624B\u75DB\u3044\u304C\u4FDD\u6301\u3067\u983C\u3080\u2026",
  "id" : 595073451825635328,
  "in_reply_to_status_id" : 595064739329224704,
  "created_at" : "2015-05-04 03:52:21 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595056492459397120",
  "geo" : { },
  "id_str" : "595056916193103872",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u79C1\u3060\u304C\u9069\u5F53\u306B\u6D17\u6FEF\u3057\u3066\u4F7F\u3046\u306A\u308A\u96D1\u5DFE\u306B\u3059\u308B\u306A\u308A\u3057\u3066\u304F\u308C\u3002\u3059\u307E\u306A\u3044\u3002\u305F\u3076\u3093\u98A8\u5442\u5834\u306B\u3082\u30CF\u30F3\u30C9\u30BF\u30AA\u30EB\u7F6E\u3044\u3066\u308B\u304C\u540C\u69D8\u306E\u5BFE\u5FDC\u3067\u983C\u3080\u3002",
  "id" : 595056916193103872,
  "in_reply_to_status_id" : 595056492459397120,
  "created_at" : "2015-05-04 02:46:39 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595039637439033344",
  "text" : "\u307E\u308C\u3044\u3093\u304C\u53CC\u5BFE\u6027\u3060\u3063\u3066\u8A00\u3044\u305D\u3046",
  "id" : 595039637439033344,
  "created_at" : "2015-05-04 01:37:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595039480089694208\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/c5IBJu91qY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEIBL9hUIAE20Zq.jpg",
      "id_str" : "595039405770809345",
      "id" : 595039405770809345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEIBL9hUIAE20Zq.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/c5IBJu91qY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595039480089694208",
  "text" : "\u5B9A\u7FA9\u305D\u3070\u3001\u5B9A\u7FA9\u3046\u3069\u3093 http:\/\/t.co\/c5IBJu91qY",
  "id" : 595039480089694208,
  "created_at" : "2015-05-04 01:37:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 0, 9 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595029687119814656",
  "geo" : { },
  "id_str" : "595029861552431105",
  "in_reply_to_user_id" : 2306283966,
  "text" : "@tenapyon \u6CB9\u63DA\u3052\u7F8E\u5473\u3057\u304B\u3063\u305F\u3067\u3059\uFF01\u30CB\u30F3\u30CB\u30AF\u5165\u308A\u306E\u4E03\u5473\u3068\u91A4\u6CB9\u3067",
  "id" : 595029861552431105,
  "in_reply_to_status_id" : 595029687119814656,
  "created_at" : "2015-05-04 00:59:08 +0000",
  "in_reply_to_screen_name" : "tenapyon",
  "in_reply_to_user_id_str" : "2306283966",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595028176469790720",
  "text" : "\u5B9A\u7FA9\u5982\u6765\u3001\u5E30\u4F9D\u3059\u308B\u3068\u826F\u3044\u5B9A\u7FA9\u304C\u51FA\u6765\u305D\u3046",
  "id" : 595028176469790720,
  "created_at" : "2015-05-04 00:52:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u81EA\u7531\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B\u3068\u675F\u7E1B\u30BC\u30EB\u30D7\u30B9\u30C8\u6BBF\u4E0B",
      "screen_name" : "tenapyon",
      "indices" : [ 0, 9 ],
      "id_str" : "2306283966",
      "id" : 2306283966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595027632800030720",
  "geo" : { },
  "id_str" : "595028034677121024",
  "in_reply_to_user_id" : 2306283966,
  "text" : "@tenapyon \u5B9A\u7FA9\u306E\u4F55\u305F\u308B\u304B\u3092\u77E5\u308B\u65C5\u3067\u3059(?)",
  "id" : 595028034677121024,
  "in_reply_to_status_id" : 595027632800030720,
  "created_at" : "2015-05-04 00:51:53 +0000",
  "in_reply_to_screen_name" : "tenapyon",
  "in_reply_to_user_id_str" : "2306283966",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595027934903054336\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/Ul8zOQxWzb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEH2v83UUAAQEyt.jpg",
      "id_str" : "595027929442045952",
      "id" : 595027929442045952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEH2v83UUAAQEyt.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Ul8zOQxWzb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595027934903054336",
  "text" : "\u5B9A\u7FA9\u5982\u6765 http:\/\/t.co\/Ul8zOQxWzb",
  "id" : 595027934903054336,
  "created_at" : "2015-05-04 00:51:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595027454730768384\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/rDxc4vTLsN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEH2UJaUkAAwVEW.jpg",
      "id_str" : "595027451773751296",
      "id" : 595027451773751296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEH2UJaUkAAwVEW.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/rDxc4vTLsN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595027454730768384",
  "text" : "\u5B9A\u7FA9\u3053\u3051\u3057 http:\/\/t.co\/rDxc4vTLsN",
  "id" : 595027454730768384,
  "created_at" : "2015-05-04 00:49:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595026573570379776\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/XM8uqFRKd2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEH1g34VAAEGwev.png",
      "id_str" : "595026570894442497",
      "id" : 595026570894442497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEH1g34VAAEGwev.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XM8uqFRKd2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595026573570379776",
  "text" : "\u5B9A\u7FA9\u306B\u3066 http:\/\/t.co\/XM8uqFRKd2",
  "id" : 595026573570379776,
  "created_at" : "2015-05-04 00:46:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595025929321127936",
  "text" : "\u964D\u308B\u3068\u5B9A\u7FA9\u304C\u51FA\u3066\u304D\u305D\u3046",
  "id" : 595025929321127936,
  "created_at" : "2015-05-04 00:43:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595025908936773633\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/7RaJUH9B9v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEH06LQVAAA28G3.jpg",
      "id_str" : "595025906080481280",
      "id" : 595025906080481280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEH06LQVAAA28G3.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/7RaJUH9B9v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595025908936773633",
  "text" : "\u5B9A\u7FA9\u306E\u5C0F\u69CC http:\/\/t.co\/7RaJUH9B9v",
  "id" : 595025908936773633,
  "created_at" : "2015-05-04 00:43:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595024953423986688\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/NegAGUVkBG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEH0CjPUEAA_cVO.jpg",
      "id_str" : "595024950446002176",
      "id" : 595024950446002176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEH0CjPUEAA_cVO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/NegAGUVkBG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595024953423986688",
  "text" : "\u5B9A\u7FA9\u540D\u7269 http:\/\/t.co\/NegAGUVkBG",
  "id" : 595024953423986688,
  "created_at" : "2015-05-04 00:39:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595024751027826688\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/5EA67KcZlS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEHz2wkVAAIjlPk.jpg",
      "id_str" : "595024747865374722",
      "id" : 595024747865374722,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEHz2wkVAAIjlPk.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/5EA67KcZlS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595024751027826688",
  "text" : "\u9053\u884C\u304F\u3082\u306E\u306E\u3044\u308D\u3044\u308D\u306B\u5B9A\u7FA9\u3063\u3066\u66F8\u3044\u3066\u3042\u3063\u3066\u3058\u308F\u308B http:\/\/t.co\/5EA67KcZlS",
  "id" : 595024751027826688,
  "created_at" : "2015-05-04 00:38:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/595020706728939520\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/BQcLA5oz7k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEHwKvXUMAEATPJ.jpg",
      "id_str" : "595020693093232641",
      "id" : 595020693093232641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEHwKvXUMAEATPJ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/BQcLA5oz7k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595020706728939520",
  "text" : "\u5B9A\u7FA9\u3067\u3059 http:\/\/t.co\/BQcLA5oz7k",
  "id" : 595020706728939520,
  "created_at" : "2015-05-04 00:22:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9752\u6C5F \u6182 @\u304C\u3093\u3070\u3089\u306D\u3070",
      "screen_name" : "aoeui666",
      "indices" : [ 0, 9 ],
      "id_str" : "821299302",
      "id" : 821299302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594848135156924417",
  "geo" : { },
  "id_str" : "594850792667942912",
  "in_reply_to_user_id" : 821299302,
  "text" : "@aoeui666 \u51FA\u5148\u3067\u3059\u304C\u30EA\u30E2\u30FC\u30C8\u3067\u78BA\u8A8D\u3057\u307E\u3057\u305F\u3002(\u50D5\u3082\u5931\u5FF5\u3057\u3066\u3044\u307E\u3057\u305F)",
  "id" : 594850792667942912,
  "in_reply_to_status_id" : 594848135156924417,
  "created_at" : "2015-05-03 13:07:35 +0000",
  "in_reply_to_screen_name" : "aoeui666",
  "in_reply_to_user_id_str" : "821299302",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9752\u6C5F \u6182 @\u304C\u3093\u3070\u3089\u306D\u3070",
      "screen_name" : "aoeui666",
      "indices" : [ 0, 9 ],
      "id_str" : "821299302",
      "id" : 821299302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594810748544516096",
  "geo" : { },
  "id_str" : "594810980330180608",
  "in_reply_to_user_id" : 821299302,
  "text" : "@aoeui666 ok\u3067\u3059.",
  "id" : 594810980330180608,
  "in_reply_to_status_id" : 594810748544516096,
  "created_at" : "2015-05-03 10:29:23 +0000",
  "in_reply_to_screen_name" : "aoeui666",
  "in_reply_to_user_id_str" : "821299302",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9752\u6C5F \u6182 @\u304C\u3093\u3070\u3089\u306D\u3070",
      "screen_name" : "aoeui666",
      "indices" : [ 0, 9 ],
      "id_str" : "821299302",
      "id" : 821299302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594809966311055360",
  "geo" : { },
  "id_str" : "594810110544777216",
  "in_reply_to_user_id" : 821299302,
  "text" : "@aoeui666 \u660E\u65E5\u306E\u591C\u6BD4\u8F03\u7684\u9045\u3044\u6642\u9593\u306A\u3089\u305F\u3076\u3093\u3044\u3051\u307E\u3059",
  "id" : 594810110544777216,
  "in_reply_to_status_id" : 594809966311055360,
  "created_at" : "2015-05-03 10:25:56 +0000",
  "in_reply_to_screen_name" : "aoeui666",
  "in_reply_to_user_id_str" : "821299302",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9752\u6C5F \u6182 @\u304C\u3093\u3070\u3089\u306D\u3070",
      "screen_name" : "aoeui666",
      "indices" : [ 0, 9 ],
      "id_str" : "821299302",
      "id" : 821299302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594785505742495744",
  "geo" : { },
  "id_str" : "594809625968410624",
  "in_reply_to_user_id" : 821299302,
  "text" : "@aoeui666 \u898B\u3048\u3066\u306A\u3044\u3067\u3059",
  "id" : 594809625968410624,
  "in_reply_to_status_id" : 594785505742495744,
  "created_at" : "2015-05-03 10:24:00 +0000",
  "in_reply_to_screen_name" : "aoeui666",
  "in_reply_to_user_id_str" : "821299302",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594705181792600064",
  "text" : "\u591A\u69D8\u4F53\u3067\u306F\u306A\u3044",
  "id" : 594705181792600064,
  "created_at" : "2015-05-03 03:28:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594705104487362560",
  "text" : "\u677E\u5CF6\u3084 \u3042\u309D\u677E\u5CF6\u3084 \u677E\u5CF6\u3084",
  "id" : 594705104487362560,
  "created_at" : "2015-05-03 03:28:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594423385813192704",
  "geo" : { },
  "id_str" : "594423649089622016",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u53CB\u4EBA\u3089\u3068\u76F8\u8AC7\u3057\u3066\u307F\u308B\u308F\u3002\u3042\u308A\u304C\u3068\u3046\u3002",
  "id" : 594423649089622016,
  "in_reply_to_status_id" : 594423385813192704,
  "created_at" : "2015-05-02 08:50:16 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594422259898404864",
  "geo" : { },
  "id_str" : "594423227700482049",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u3042\u308A\u304C\u3068\u3046\uFF01\u8ABF\u3079\u3066\u307F\u307E\u3057\u305F\uFF01",
  "id" : 594423227700482049,
  "in_reply_to_status_id" : 594422259898404864,
  "created_at" : "2015-05-02 08:48:35 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307A\u307A",
      "screen_name" : "tamago_on_gohan",
      "indices" : [ 0, 16 ],
      "id_str" : "1890303169",
      "id" : 1890303169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594420821080158208",
  "geo" : { },
  "id_str" : "594420999652675584",
  "in_reply_to_user_id" : 1890303169,
  "text" : "@tamago_on_gohan \u3044\u3048\u3044\u3048\u3001\u6559\u3048\u3066\u3044\u305F\u3060\u3044\u3066\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\u308F\u304C\u307E\u307E\u8A00\u3063\u3066\u3059\u307F\u307E\u305B\u3093\u3002",
  "id" : 594420999652675584,
  "in_reply_to_status_id" : 594420821080158208,
  "created_at" : "2015-05-02 08:39:44 +0000",
  "in_reply_to_screen_name" : "tamago_on_gohan",
  "in_reply_to_user_id_str" : "1890303169",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594420731334627328",
  "text" : "\u79C1\u306F\u7F8E\u5473\u3057\u3051\u308C\u3070\u307E\u3041\u826F\u3044\u3093\u3060\u3051\u3069\u306A",
  "id" : 594420731334627328,
  "created_at" : "2015-05-02 08:38:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307A\u307A",
      "screen_name" : "tamago_on_gohan",
      "indices" : [ 0, 16 ],
      "id_str" : "1890303169",
      "id" : 1890303169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594420398441172993",
  "geo" : { },
  "id_str" : "594420628016345088",
  "in_reply_to_user_id" : 1890303169,
  "text" : "@tamago_on_gohan \u305B\u3063\u304B\u304F\u6765\u3066\u308B\u306E\u3067\u53EF\u80FD\u306A\u3089\u305D\u306E\u65B9\u304C\u826F\u3044\u3067\u3059\u306D",
  "id" : 594420628016345088,
  "in_reply_to_status_id" : 594420398441172993,
  "created_at" : "2015-05-02 08:38:16 +0000",
  "in_reply_to_screen_name" : "tamago_on_gohan",
  "in_reply_to_user_id_str" : "1890303169",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307A\u307A",
      "screen_name" : "tamago_on_gohan",
      "indices" : [ 0, 16 ],
      "id_str" : "1890303169",
      "id" : 1890303169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594420070698221568",
  "geo" : { },
  "id_str" : "594420301288476672",
  "in_reply_to_user_id" : 1890303169,
  "text" : "@tamago_on_gohan \u5019\u88DC\u306B\u306F\u4E0A\u304C\u3063\u3066\u308B\u3093\u3067\u3059\u304C\u3001\u6771\u4EAC\u306B\u3042\u308B\u3089\u3057\u3044\u3093\u3067\u3059\u3088\u306D",
  "id" : 594420301288476672,
  "in_reply_to_status_id" : 594420070698221568,
  "created_at" : "2015-05-02 08:36:58 +0000",
  "in_reply_to_screen_name" : "tamago_on_gohan",
  "in_reply_to_user_id_str" : "1890303169",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594419857388503040",
  "text" : "@\u4ED9\u53F0\u306E\u4EBA  \u4ED9\u53F0\u3067\u725B\u30BF\u30F3\u306E\u30AA\u30B9\u30B9\u30E1\u306E\u304A\u5E97\u30B5\u30B8\u30A7\u30B9\u30C8\u3057\u3066\u3082\u3089\u3048\u307E\u305B\u3093\u304B\uFF01",
  "id" : 594419857388503040,
  "created_at" : "2015-05-02 08:35:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 12, 21 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594419689511485440",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 @acmn13_2  \u4ED9\u53F0\u3067\u725B\u30BF\u30F3\u306E\u30AA\u30B9\u30B9\u30E1\u306E\u304A\u5E97\u30B5\u30B8\u30A7\u30B9\u30C8\u3057\u3066\u3082\u3089\u3048\u307E\u305B\u3093\u304B\uFF01",
  "id" : 594419689511485440,
  "created_at" : "2015-05-02 08:34:32 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594307039611858945",
  "text" : "\u3082\u3046\u3061\u3087\u3044\u3067\u30EA\u30C1\u30E3\u30FC\u30B8\u306E\u30E1\u30C0\u30EB\u304C\u305F\u3076\u3093\u91D1\u306B\u306A\u308B\u3002",
  "id" : 594307039611858945,
  "created_at" : "2015-05-02 01:06:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594303081191329792",
  "text" : "\u3042\u306820\u4E07AP",
  "id" : 594303081191329792,
  "created_at" : "2015-05-02 00:51:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594159063501385729",
  "text" : "(\u52DD\u624B\u306B\u30C7\u30A4\u30EA\u30FC\u3092\u6D88\u5316\u3057\u3066\u306F\u3044\u3051\u306A\u3044\u3068\u306F\u8A00\u308F\u308C\u3066\u306A\u3044)",
  "id" : 594159063501385729,
  "created_at" : "2015-05-01 15:18:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594158513414230016",
  "text" : "\u8266\u3053\u308C\u898B\u3066\u308B\u3084\u3067\u3063\u3066\u8A00\u3063\u305F\u3089\u89E3\u4F53\u3059\u308B\u306A\u3063\u3066\u8A00\u308F\u308C\u305F\u304C\u305D\u3093\u306A\u4FE1\u7528\u5EA6\u304B\u3088\u30A6\u30B1\u308B",
  "id" : 594158513414230016,
  "created_at" : "2015-05-01 15:16:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594154498706145281",
  "text" : "\u9752\u8449\u5C71\u30C8\u30F3\u30CD\u30EB\uFF1F\u3092\u901A\u904E\u3057\u305F",
  "id" : 594154498706145281,
  "created_at" : "2015-05-01 15:00:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594154227666063360",
  "text" : "\u5BAE\u57CE\u4ED9\u53F0\u30A4\u30F3\u30BF\u30FC",
  "id" : 594154227666063360,
  "created_at" : "2015-05-01 14:59:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594118620327727104",
  "text" : "\u307E\u308C\u3044\u3093\uFF01\u5927\u5BCC\u8C6A\u4EBA\u72FC\u306E\u8ABF\u6574\u306F\u541B\u306B\u4EFB\u305B\u305F\uFF01\uFF01\uFF01\uFF01",
  "id" : 594118620327727104,
  "created_at" : "2015-05-01 12:38:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594055255391744001",
  "text" : "\u30A6\u30D2\u30E7\u30FC",
  "id" : 594055255391744001,
  "created_at" : "2015-05-01 08:26:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594055217315872768",
  "text" : "\u6771\u4EAC\u99C5\u304B\u3089\u5468\u308A\u300130\u5206\u307B\u3069\u30B0\u30EA\u30D5\u30CF\u30C3\u30AF\u3057\u306A\u304C\u3089\u9069\u5F53\u306B\u30EC\u30BE\u30CD\u523A\u3057\u306A\u304C\u3089\u6B69\u3044\u3066\u9069\u5F53\u306Bxmp\u3076\u3063\u3071\u3057\u3066\u305F\u3060\u3051\u3067\u7D4C\u9A13\u5024\u304C\u30A6\u30D2\u30E7\u30FC",
  "id" : 594055217315872768,
  "created_at" : "2015-05-01 08:26:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594025487883612160",
  "text" : "\u771F\u590F\u306E\u934B\u306F\u697D\u3057\u3044",
  "id" : 594025487883612160,
  "created_at" : "2015-05-01 06:28:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593926024808693761",
  "text" : "ingress\u7D4C\u9A13\u50241.5\u500D\u826F\u3044\u2026\u30A2\u30FC\u3001\u9065\u304B\u306B\u826F\u3044\u3067\u3059",
  "id" : 593926024808693761,
  "created_at" : "2015-04-30 23:52:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593793414870618112",
  "text" : "\u3042\u305F\u307E\u3044\u305F\u3044",
  "id" : 593793414870618112,
  "created_at" : "2015-04-30 15:05:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593793232724590592",
  "text" : "\u80A9\u3053\u308A\u3042\u30FC\u3001\u80A9\u3053\u308A\u3042\u30FC\u3063\u3066\u8A00\u3063\u3066\u305F\u30891\u65E5\u304C\u904E\u304E\u305F",
  "id" : 593793232724590592,
  "created_at" : "2015-04-30 15:05:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]