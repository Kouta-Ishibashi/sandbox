Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19970361327",
  "text" : "\u3069\u3046\u3057\u3066\u30DE\u30F3\u30AC\u3063\u3066\u3084\u3064\u306F\"\u7D9A\u304D\u304C\u6C17\u306B\u306A\u308B\u3088\u3046\u306B\"\u69CB\u6210\u3055\u308C\u3066\u3044\u308B\u3093\u3060\u3002\u3053\u308C\u304B\u3089\u306F\u5B8C\u7D50\u3057\u305F\u8A71\u3057\u304B\u307E\u3068\u3081\u8CB7\u3044\u3057\u306A\u3044\u3053\u3068\u306B\u3057\u3088\u3046\u304B\u306A\u3041\u3002\u3067\u3082\u305D\u308C\u3060\u3068\u304A\u91D1\u304C\u306A\u3041",
  "id" : 19970361327,
  "created_at" : "2010-07-31 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19975441500",
  "text" : "@chisa10404 \u79C1\uFF1F\u663C\u5BDD\u306E\u524D\u306B\u304A\u3084\u3064\u306B\u8C46\u5927\u798F\u98DF\u3079\u307E\u3057\u305F\u301C\u2190",
  "id" : 19975441500,
  "created_at" : "2010-07-31 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19991428991",
  "text" : "\u300C\uFF5E\u300D\u2190\u3053\u308C\u30C1\u30EB\u30C0\u3063\u3066\u8AAD\u3080\u3093\u3060\u305C\uFF57\u3000\u3088\u3063\u3066\u300C\u30DE\uFF5E\u3055\u3093\u300D\uFF1D\u30DE\u30C1\u30EB\u30C0\u3055\u3093",
  "id" : 19991428991,
  "created_at" : "2010-07-31 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19891213940",
  "text" : "\u3042\u308C\uFF1F\u3055\u3063\u304D\u8D77\u304D\u305F\u306E\u306B\uFF47\uFF44\uFF47\uFF44\u3057\u3066\u305F\u3089\u3082\u30464\u6642\u3058\u3083\u306A\u3044\u304B\u2026\u2026\u305D\u3046\u304B\u3001\u3053\u308C\u304C\u300C\u590F\u4F11\u307F\u300D\u304B\u2026\u3002",
  "id" : 19891213940,
  "created_at" : "2010-07-30 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19940272186",
  "text" : "\u7D50\u5C40\u5BDD\u308C\u306A\u3044\u30D1\u30BF\u30FC\u30F3\u307F\u305F\u3044\u3067\u3059\u3002",
  "id" : 19940272186,
  "created_at" : "2010-07-30 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19789683619",
  "text" : "@koketomi \u5358\uFF11\u3060\u3063\u3066\u3042\u3093\u307E\u308A\u306A\u3044\u3068\u601D\u3046\u3051\u3069\uFF57\uFF57\uFF57",
  "id" : 19789683619,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19806906373",
  "text" : "\u3068\u3042\u308B\u53E4\u5178\u306E\u6587\u66F8\u76EE\u9332(\u30A4\u30F3\u30C7\u30C3\u30AF\u30B9)\u30C6\u30B9\u30C8\u7BC4\u56F2\u306E\u30E9\u30C6\u30F3\u6587\u306E\u30A4\u30F3\u30C7\u30C3\u30AF\u30B9\u3092\u3001\u30A8\u30AF\u30BB\u30EB\u3067\u8F9E\u66F8\u9806\u306B\u3057\u3066\u6301\u3061\u8FBC\u307F\u3002\u5F53\u7136\u512A\uFF01",
  "id" : 19806906373,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19821529064",
  "geo" : { },
  "id_str" : "19826853792",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u306E\u8A00\u8449\u306F\u3044\u308D\u3093\u306A\u610F\u5473\u3067\u5049\u5927\u3059\u304E\u3066\u3084\u3070\u3044\uFF57",
  "id" : 19826853792,
  "in_reply_to_status_id" : 19821529064,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19699457221",
  "geo" : { },
  "id_str" : "19704957017",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305F\u3076\u3093\u524D\u7F6E\u8A5E\u53E5\u6B62\u307E\u308A\u306E\u539F\u984C\u3060\u304B\u3089\u300C\u306B\u300D\u304C\u5165\u308B\u304B\u306F\u7FFB\u8A33\u8005\u3055\u3093\u6B21\u7B2C\u4F55\u3058\u3083\u306A\u3044\u304B\u306A\u30FC\u3001\u4ED8\u304B\u306A\u3044\u307B\u3046\u304C\u4E00\u822C\u7684\u306A\u6C17\u304C\u3059\u308B\u3051\u3069",
  "id" : 19704957017,
  "in_reply_to_status_id" : 19699457221,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19707197339",
  "text" : "\u55DA\u547C\u3001\u6628\u65E5\u5FC5\u6B7B\u3067\u4ED5\u4E0A\u3052\u305F\u30EC\u30DD\u30FC\u30C8\u5FD8\u308C\u3066\u304D\u305F\u3002\u3006\u6642\u9593\u306B\u306F\u4F59\u88D5\u3060\u304C\u3001\u3053\u306E\u708E\u5929\u4E0B\u3001\u81EA\u8EE2\u8ECA\u3067\u5927\u5B66\u3068\u5BB6\u3092\u5F80\u5FA9\u3059\u308B\u306E\u306F\u6182\u9B31\u3060\u2026\u3002",
  "id" : 19707197339,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19710406742",
  "text" : "\uFF12\u9023\u30AB\u30F3\u304B\u3089\u30EA\u30FC\u30C1\u3001\u4E00\u767A\u3001\u767D\u3001\u30DB\u30F3\u30A4\u30C4\u3001\u30C8\u30A4\u30C8\u30A4\u3001\u4E09\u6697\u523B\u3001\u30C9\u30E9\uFF15\uFF01\u4E00\u77AC\u30EA\u30F3\u30B7\u30E3\u30F3\u56DB\u6697\u523B\u3092\u671F\u5F85\u3057\u305F\u3051\u3069\u6F2B\u753B\u306E\u8AAD\u307F\u3059\u304E\u3067\u3057\u305F\u3002\u307E\u3041\u643A\u5E2F\u3060\u3051\u3069\u306D\u3002",
  "id" : 19710406742,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19710495286",
  "text" : "\u3067\u3082\u6570\u3048\u5F79\u6E80\u3060\u304B\u3089\u7D50\u679C\u30AA\u30FC\u30E9\u30A4\uFF57\uFF57\uFF57",
  "id" : 19710495286,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19736733377",
  "geo" : { },
  "id_str" : "19737018909",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308A\u3083\u3001\u9055\u3046\u3060\u308D\u3046\u3001\u50BE\u5411\u3082\u3001\u307B\u3057\u304C\u3063\u3066\u308B\u5B66\u751F\u3082\uFF57\uFF57\uFF57",
  "id" : 19737018909,
  "in_reply_to_status_id" : 19736733377,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19658619768",
  "text" : "\u7D42\u308F\u3063\u305F\uFF01\u7D50\u5C403\u6642\u9593\u304F\u3089\u3044\u304B\uFF57\u3055\u3066\u3001\u660E\u65E5\u306E\u843D\u3068\u3059\u3064\u3082\u308A\u306E\u5358\u4F4D\u306E\u904E\u53BB\u554F\u3067\u3082\u62FE\u3063\u3066\u3053\u3088\u3046\u304B\u306A\u3002",
  "id" : 19658619768,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19661967531",
  "text" : "\u3084\u3063\u3068\u898B\u3064\u3051\u305F\uFF57\u3055\u3066\u89E3\u7B54\u4F5C\u3063\u3066\u4E38\u6697\u8A18\u3059\u308B\u304B\uFF57\n\u5927\u5B66\u751F\u305F\u308B\u3082\u306E\u3001\u6700\u5C0F\u9650\u306E\u52AA\u529B\u3067\u5358\u4F4D\u3092\u53D6\u3089\u306A\u304F\u3066\u3069\u3046\u3057\u307E\u3059\uFF57",
  "id" : 19661967531,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19662501511",
  "text" : "\u3068\u601D\u3063\u305F\u3051\u3069\u89E3\u7B54\u4F5C\u308C\u306D\u3047\uFF57\uFF57\uFF57\uFF57\u6388\u696D\u9014\u4E2D\u304B\u3089\u8AE6\u3081\u3066\u305F\u304B\u3089\u306A\u3041\uFF57\u3082\u3046\u3044\u3044\u3084\uFF57\n\u5927\u5B66\u751F\u305F\u308B\u3082\u306E\u3001\u843D\u3068\u3059\u79D1\u76EE\u306E\u305F\u3081\u306B\u52C9\u5F37\u3057\u3066\u3069\u3046\u3057\u307E\u3059\u2190",
  "id" : 19662501511,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19663215249",
  "text" : "Phillips\u306E\u5B9F\u9A13\u3067\u7121\u610F\u5473\u306A\u30C1\u30A7\u30C3\u30AB\u30FC\u30D1\u30BF\u30F3\u3092\u7528\u3044\u305F\u76EE\u7684\u3068\u306F\u4F55\u304B\uFF1F\n\n\u7121\u610F\u5473\u306A\u3093\u3060\u304B\u3089\u7121\u610F\u5473\u306A\u3093\u3060\u3088\uFF57\uFF57\uFF57\uFF57\u30D0\u30AB\u30E4\u30ED\u30A6\u3002\u65E5\u672C\u8A9E\u3067\u66F8\u304D\u305F\u307E\u3048\u3002",
  "id" : 19663215249,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19663528644",
  "geo" : { },
  "id_str" : "19663632545",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30D8\u30C3\u30BB\uFF1F",
  "id" : 19663632545,
  "in_reply_to_status_id" : 19663528644,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19646188525",
  "text" : "\u3055\u3066\u3001\u660E\u65E5\u63D0\u51FA\u306E\u30EC\u30DD\u30FC\u30C8\u3092\u30BF\u30A4\u30E0\u30A2\u30BF\u30C3\u30AF\u3068\u884C\u3053\u3046\u304B\u3002",
  "id" : 19646188525,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19653434229",
  "text" : "A4\u4E21\u9762\uFF08\u30EA\u30E3\u30F3\u30E1\u30F3\uFF09\u3044\u3063\u3071\u3044\u306B\u66F8\u304F\u306E\u3063\u3066\u601D\u3063\u305F\u3088\u308A\u5927\u5909\u3060\u306A\uFF57\u30EC\u30DD\u30FC\u30C8\u3042\u3093\u307E\u308A\u66F8\u3044\u305F\u3053\u3068\u306A\u3044\u306E\u3088\u306D\uFF57",
  "id" : 19653434229,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19535278996",
  "geo" : { },
  "id_str" : "19539692952",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u30AA\u30FC\u30EB\u512A\u3068\u304B\uFF57\uFF57\uFF57\u982D\u60AA\u3044\u306E\u4EE3\u540D\u8A5E\u3060\u308D\uFF57\uFF57\u30AA\u30FC\u30EB\uFF16\uFF10\u70B9\u3067\u30AA\u30FC\u30EB\u304E\u308A\u304E\u308A\u53EF\u306A\u306E\u304C\u5B66\u751F\u306E\u771F\u9AC4\u3060\u308D",
  "id" : 19539692952,
  "in_reply_to_status_id" : 19535278996,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19558704095",
  "geo" : { },
  "id_str" : "19563012216",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u305D\u3046\u3084\u3063\u3066\u304A\u524D\u306F\u5C06\u6765\u306E\u305F\u3081\u306B\u4ECA\u3092\u72A0\u7272\u306B\u3057\u7D9A\u3051\u308B\u306E\u304B\u3002",
  "id" : 19563012216,
  "in_reply_to_status_id" : 19558704095,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19565604537",
  "geo" : { },
  "id_str" : "19567141456",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3068\u3082\u3059\u308C\u3070\u300C\u53B3\u3057\u3044\u8A00\u8449\u3067\u590F\u4E2D\u6DBC\u3057\u3044\u300D\u306F\u305A\u306A\u3093\u3060\u304C\u3002",
  "id" : 19567141456,
  "in_reply_to_status_id" : 19565604537,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19567807102",
  "geo" : { },
  "id_str" : "19570382627",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u7269\u7406\u7684\u306B\u8003\u3048\u308B\u306A\u3089\u4EBA\u304C\u4F55\u304B\u3057\u3083\u3079\u3063\u305F\u304F\u3089\u3044\u3067\u8D77\u304D\u308B\u7A7A\u6C17\u306E\u71B1\u91CF\u306E\u5909\u4F4D\u306F\u4F53\u611F\u6E29\u5EA6\u3067\u306F\u7121\u8996\u3067\u304D\u308B\u30EC\u30D9\u30EB\u3060\u3002\u3063\u3066\u7B54\u3048\u3066\u308B\u306A\uFF57\uFF57\u4FFA\u306F\u8AD6\u7406\u7684\u306B\u8FF0\u3079\u305F\u307E\u3067\u3060\u3002",
  "id" : 19570382627,
  "in_reply_to_status_id" : 19567807102,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19571244311",
  "geo" : { },
  "id_str" : "19571583893",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u9DB4\u5C4B\u306A\u3093\u3068\u304B\u3060\u3063\u305F\u306F\u305A\u3002",
  "id" : 19571583893,
  "in_reply_to_status_id" : 19571244311,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19573215057",
  "geo" : { },
  "id_str" : "19573756372",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u9AD8\u6821\u3067\u5B66\u3093\u3060\u3053\u3068\uFF1A\u624B\u306E\u306C\u304D\u65B9\u3002",
  "id" : 19573756372,
  "in_reply_to_status_id" : 19573215057,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19575391877",
  "text" : "\u554F\uFF14\u300C\u30D5\u30E9\u30F3\u30AF\u30B8\u30E3\u30AF\u30BD\u30F3\u304C\u3001\u308F\u308C\u308F\u308C\u306E\u77E5\u8B58\u304C\u7269\u7406\u7684\u306A\u3082\u306E\u306B\u9650\u3089\u306A\u3044\u3053\u3068\u3092\u793A\u305D\u3046\u3068\u3057\u3066\u7528\u3044\u305F\u8B70\u8AD6\u3092\u306A\u3093\u3068\u3044\u3046\u304B\u300D\nend\u306E\u7B54\u300C\uFF08\u9577\u7D30\u3044\u25A1\u3092\u66F8\u304F\uFF09\u2190\u79C1\u306F\u3053\u306E\u67A0\u5185\u306B\u3001\u89E3\u7B54\u3092\u7269\u7406\u7684\u306A\u3082\u306E\u306B\u9650\u3089\u306A\u3044\u65B9\u6CD5\u3067\u793A\u3057\u305F\u3002\u300D",
  "id" : 19575391877,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19575409934",
  "text" : "\u54F2\u5B66\u57FA\u790E\u8AD6\u3002\u6982\u3057\u3066\u3053\u3093\u306A\u611F\u3058\u3002\u3060\u3063\u3066\u771F\u9762\u76EE\u306B\u66F8\u3044\u3066\uFF13\u5272\u4F4D\u3060\u3068\u609F\u3063\u305F\u304B\u3089\u3002\u6559\u6388\u306E\u30E6\u30FC\u30E2\u30A2\u306B\u671F\u5F85\u3002\u5358\u4F4D\u964D\u3063\u3066\u3053\u306A\u3044\u304B\u306A\u3041\u3002",
  "id" : 19575409934,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19470365606",
  "text" : "\u30A2\u30F3\u30AD\u30E2\u306E\u6697\u8A18\u7269",
  "id" : 19470365606,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19480948475",
  "text" : "\u3042\u306840\u5206\u3067\u8377\u7269\u6765\u306A\u3044\u3068\u9762\u5012\u3060\u306A\u30FC\u3001\u4EE3\u5F15\u304D\u3060\u3057\u306A\u30FC\u3002\u70AD\u9178\u6C34\u306E\u7BB1\u8CB7\u3044\u306F\u79C1\u306E\u3055\u3055\u3084\u304B\u306A\u305C\u3044\u305F\u304F\u306E\u4E00\u3064\u306A\u306E\u3067\u3059\u3002",
  "id" : 19480948475,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19481752077",
  "geo" : { },
  "id_str" : "19481856027",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u30DA\u30EA\u30A8\u3067\u3059\uFF57",
  "id" : 19481856027,
  "in_reply_to_status_id" : 19481752077,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19483364309",
  "text" : "\u5730\u56F3\u3092\u6301\u3063\u305F\u4EBA\u304C\u591A\u3044\u3068\u601D\u3048\u3070\u3001\u305D\u3046\u304B\u3001\u4E16\u9593\u306F\u6240\u8B02\u590F\u4F11\u307F\u304B\u3002",
  "id" : 19483364309,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19490109324",
  "text" : "\u4EAC\u5927\u751F\u305F\u308B\u3082\u306E\u3001\u307B\u308D\u9154\u3044\u3067\u9D28\u5DDD\u6CBF\u3044\u3092\u6B69\u304B\u306A\u304F\u3066\u3069\u3046\u3057\u307E\u3059\u3002",
  "id" : 19490109324,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19491478161",
  "text" : "\u901A\u308A\u639B\u304B\u3063\u305F\u4E0B\u9D28\u795E\u793E\u3067\u307F\u305F\u3089\u3057\u796D\u3084\u3063\u3066\u308B\u3002\u6797\u6A8E\u98F4\u3067\u3082\u98DF\u3079\u305F\u3044\u6C17\u5206",
  "id" : 19491478161,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19401354610",
  "text" : "\uFF21\uFF4D\uFF41\uFF4E\uFF54\uFF45\uFF53 amentes-\u604B\u3059\u308B\u8005\u306F\u6B63\u6C17\u3067\u306F\u306A\u3044-\u3000\u30ED\u30FC\u30DE\u4EBA\u3082\u306A\u304B\u306A\u304B\u4E0A\u624B\u3044\u3053\u3068\u3092\u8A00\u3046\u3002",
  "id" : 19401354610,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19401368378",
  "text" : "\u3055\u3063\u304D\u306E100\u30C4\u30A4\u30FC\u30C8\u76EE\u3060\u3063\u305F\u308A\uFF57\uFF57",
  "id" : 19401368378,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19402180116",
  "text" : "@chisa10404 \u3044\u3084\u3001\u300C\u65B0\u30E9\u30C6\u30F3\u6587\u6CD5\u300D\u3063\u3066\u3084\u3064\u3002\u3067\u3082\u3053\u306E\u5206\u306F\u5148\u751F\u304C\u677F\u66F8\u3057\u305F\u3082\u306E\u3067\u6559\u79D1\u66F8\u306E\u6587\u3058\u3083\u306A\u3044\u3088\u30FC\uFF57",
  "id" : 19402180116,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19406924403",
  "text" : "\u96F7\u9CF4\u3001\u96E8\u97F3\u3002\u30B2\u30EA\u30E9\u8C6A\u96E8\u6765\u305F\u308B\u3002",
  "id" : 19406924403,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19410971139",
  "geo" : { },
  "id_str" : "19413246712",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u30B4\u30EA\u30E9\u306E\u5B66\u540D\u306F\u30B4\u30EA\u30E9\u30B4\u30EA\u30E9\u3000\u3064\u307E\u308A\u3001\u30B4\u30EA\u30E9\uFF1D\u30B4\u30EA\u30E9\u30B4\u30EA\u30E9\uFF1D2\u30B4\u30EA\u30E9\u3000\u4E21\u8FBA\u3092\u30B4\u30EA\u30E9\u3067\u5272\u3063\u3066\uFF11\uFF1D\uFF12\u3000\u3088\u3063\u30661=2\u3000\uFF31 \uFF25 \uFF24.",
  "id" : 19413246712,
  "in_reply_to_status_id" : 19410971139,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19413814802",
  "text" : "\u6C37\u306E\u5165\u3063\u305F\u6C41\u3067\u3001\u6885\u3001\u7D0D\u8C46\u306A\u3093\u304B\u3092\u4ED8\u3051\u5408\u308F\u305B\u306B\u3057\u3066\u51B7\u305F\u3044\u305D\u3046\u3081\u3093\u3092\u555C\u308B\u3002\u3053\u308C\u3053\u305D\u590F\u3060\u306A\u3041\u3001\u3068\u601D\u3046\u305D\u3093\u306A\u30C6\u30B9\u30C8\u524D\u306E\u5348\u5F8C8\u6642",
  "id" : 19413814802,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19417778833",
  "geo" : { },
  "id_str" : "19424142300",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3053\u3063\u3061\u3082\u5915\u7ACB\u3068\u96F7\u306F\u3082\u306E\u3059\u3054\u304B\u3063\u305F\u3093\u3060\u3088\u306D\u3001\u3063\u3066\u30DF\u30B5\u30AB\u306F\u30DF\u30B5\u30AB\u306F\u5831\u544A\u3057\u3066\u307F\u305F\u308A\u3002",
  "id" : 19424142300,
  "in_reply_to_status_id" : 19417778833,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19424176493",
  "text" : "@koketomi \u305D\u306E\u30A2\u30A4\u30B9\u306E\u30B4\u30DF\u304C\u307E\u305F\u6563\u3089\u304B\u308B\u3093\u3067\u3059\u306D\u3001\u308F\u304B\u308A\u307E\u3059\uFF57",
  "id" : 19424176493,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19419676497",
  "geo" : { },
  "id_str" : "19424257942",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro 3\u5206\u9593\u304C\u3093\u3070\u3063\u3066\u3084\u308B\uFF01\u2026\uFF08\u4E09\u5206\uFF09\u2026\u6642\u9593\u3060\u30A1\uFF01\u7B54\u3048\u3092\u805E\u3053\u3046\u304B\uFF01",
  "id" : 19424257942,
  "in_reply_to_status_id" : 19419676497,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19216530984",
  "geo" : { },
  "id_str" : "19221661378",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u304B\u3076\u308C\u3066\u3057\u307E\u3048",
  "id" : 19221661378,
  "in_reply_to_status_id" : 19216530984,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19233436509",
  "geo" : { },
  "id_str" : "19241618853",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u62CD\u624B\uFF57\uFF57\u305D\u308C\u6CB3\u5408\u75C5\u3084\u308D\uFF57\uFF57\uFF57",
  "id" : 19241618853,
  "in_reply_to_status_id" : 19233436509,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19250406530",
  "text" : "\u3053\u306E\u7720\u6C17\u306F\u3069\u3053\u304B\u3089\u6765\u308B\u3093\u3060\u3002\u3002\u3002\u660E\u65E5\u306E\u30C6\u30B9\u30C8\u306F\u306A\u3093\u3068\u304B\u306A\u308A\u305D\u3046\u3060\u304C\u3002",
  "id" : 19250406530,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19315835265",
  "text" : "\u3055\u3066\u3001\u8CA0\u3051\u6226\u3068\u884C\u3053\u3046\u304B\u3002\u57FA\u790E\u751F\u7269\u5B66\u30A7",
  "id" : 19315835265,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19322546406",
  "geo" : { },
  "id_str" : "19323619095",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u3051\u3057\u304B\u3089\u3093\u3001\u3082\u3063\u3068\u3084\u308C\uFF01",
  "id" : 19323619095,
  "in_reply_to_status_id" : 19322546406,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19325813380",
  "text" : "\u30C8\u30FC\u30B9\u30C8\u3057\u305F\u98DF\u30D1\u30F3\u306E\u4E0A\u306B\u30D0\u30CB\u30E9\u30A2\u30A4\u30B9\u3001\u30C1\u30E7\u30B3\u30EC\u30FC\u30C8\u30BD\u30FC\u30B9\u3001\u30B7\u30CA\u30E2\u30F3\u30D1\u30A6\u30C0\u30FC\u3002\u305D\u3057\u3066\u30B3\u30FC\u30D2\u30FC\u3002\u30AB\u30ED\u30EA\u30FC\u304C\u6C17\u306B\u306A\u308B\u304C\u3053\u308C\u4EE5\u4E0A\u306E\u7D44\u307F\u5408\u308F\u305B\u306F\u3042\u308B\u307E\u3044\uFF57\u6E29\u3068\u51B7\u306F\u5171\u5B58\u3057\u3046\u308B\uFF01",
  "id" : 19325813380,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19325906843",
  "geo" : { },
  "id_str" : "19326001081",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4F8B\u3048\u6DF7\u305C\u3066\u3082\u30B2\u30C6\u30E2\u30CE\u306B\u3057\u306A\u3044\u81EA\u4FE1\u306F\u3042\u308B\u3001\u3067\u3082\u305D\u3046\u3044\u3046\u8A71\u3058\u3083\u306A\u3044\u306A\uFF57\uFF57\u30B3\u30FC\u30D2\u30FC\u304A\u3044\u3057\u3044\u3067\u3059\uFF57",
  "id" : 19326001081,
  "in_reply_to_status_id" : 19325906843,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19327127765",
  "text" : "\u30C6\u30B9\u30C8\u524D\u306E\u90E8\u5C4B\u306E\u6383\u9664\u3063\u3066\u30C7\u30D5\u30A9\u3067\u3059\u3088\u306D\uFF1F\uFF57",
  "id" : 19327127765,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19329472878",
  "text" : "@koketomi \u4FFA\u306F\u3042\u3048\u3066\u5206\u3051\u3066\u305F\u308A\u3002\u3053\u3063\u3061\u306E\u304C\u81EA\u5DF1\u6E80\u8DB3\u81ED\u304C\u5F37\u3044\uFF57\uFF57",
  "id" : 19329472878,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19332755139",
  "geo" : { },
  "id_str" : "19333965805",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u300C\u5E78\u798F\u306E\u79D8\u8A23\u306F\u3001\u4ED6\u4EBA\u306E\u8A00\u3046\u3053\u3068\u3092\u805E\u304B\u306A\u3044\u3053\u3068\u3060\u3002\u300D",
  "id" : 19333965805,
  "in_reply_to_status_id" : 19332755139,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19044139050",
  "text" : "\u5BDD\u574A\u3057\u3066\u82F1\u8A9E\u306E\u8A66\u9A13\u53D7\u3051\u640D\u306A\u3063\u305Forz\u7D20\u76F4\u306B\u6700\u5C65\u4FEE\u304B\u306A\u30FC\u3002",
  "id" : 19044139050,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19072812823",
  "text" : "@chisa10404 \u4F55\u306E\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\uFF1F\u6C17\u306B\u306A\u308A\u307E\u3059\uFF57",
  "id" : 19072812823,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19073708375",
  "text" : "@chisa10404 \u3084\u3063\u3071\u308A\u304B\u305F\u3044\u30D1\u30F3\u306E\u307B\u3046\u304C\u3044\u3044\u3088\u306D\u3002\u9AD8\u305D\u3046\u3060\u3051\u3069\u771F\u4F3C\u3067\u304D\u305D\u3046\uFF57",
  "id" : 19073708375,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18956577992",
  "geo" : { },
  "id_str" : "18957382586",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30CE\u30FC\u30C8\u307F\u308B\u3068\uFF1F\u3063\u3066\u306A\u3063\u305F\u8A18\u61B6\u304C\u591A\u3005\u3002\u81EA\u5206\u3067\u691C\u7B97\u3059\u3079\u3057\u3002",
  "id" : 18957382586,
  "in_reply_to_status_id" : 18956577992,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18993894573",
  "geo" : { },
  "id_str" : "18994286933",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u591C\u306B\u3057\u304B\u6210\u9577\u3057\u306A\u3044\u304B\u3089\u3060\u3088\u3002",
  "id" : 18994286933,
  "in_reply_to_status_id" : 18993894573,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18895123024",
  "text" : "\u8A66\u9A13\u524D\u306B\u9650\u3063\u3066\u307E\u3063\u305F\u304F\u8A66\u9A13\u306B\u95A2\u4FC2\u306E\u306A\u3044\u52C9\u5F37\u3092\u3057\u305F\u304F\u306A\u308B\u306E\u306F\u306A\u305C\u3060\u308D\u3046\u3002\u7269\u7406\u3084\u308A\u305F\u3044\u2026\u3002",
  "id" : 18895123024,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18906303320",
  "text" : "\u30EC\u30D0\u30CB\u30E9\u7F8E\u5473\u3044\uFF42",
  "id" : 18906303320,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18947321858",
  "geo" : { },
  "id_str" : "18947867037",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u4ECA\u65E5\u306F\u5348\u524D\u306B\u597D\u304D\u306A\u3053\u3068\u3057\u3066\u5348\u5F8C\u304B\u3089\u597D\u304D\u306A\u3053\u3068\u3092\u3059\u308B\u3068\u3044\u3044\u3002",
  "id" : 18947867037,
  "in_reply_to_status_id" : 18947321858,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18948849157",
  "text" : "\u6885\u96E8\u306F\u6182\u9B31\u3060\u3063\u305F\u304C\u3001\u671D\u306E\u3053\u306E\u6642\u9593\u3067\u6C17\u6E29\u304C\uFF13\uFF10\u5EA6\u3060\u3063\u305F\u308A\u6700\u9AD8\u6C17\u6E29\u304C\uFF13\uFF14\u5EA6\u3060\u3063\u305F\u308A\u3059\u308B\u3068\u306A\u304A\u6182\u9B31\u3060\u3002",
  "id" : 18948849157,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18812231838",
  "geo" : { },
  "id_str" : "18815176811",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3069\u3046\u3057\u3066\u305D\u3046\u306A\u3063\u305F\uFF57\uFF57\uFF57",
  "id" : 18815176811,
  "in_reply_to_status_id" : 18812231838,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18750969235",
  "text" : "SW\u4E8C\u671F\u4E8C\u8A71\u306A\u304B\u306A\u304B\u304A\u3082\u3057\u308D\u304B\u3063\u305F\u306A\u3002\u6700\u7D42\u56DE\u306E\u5302\u3044\u304C\u3059\u308B\u3051\u3069\uFF57\uFF57\uFF57",
  "id" : 18750969235,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18776808619",
  "text" : "\u5148\u8F29\u5BB6\u3067\u9EBB\u96C0\u306A\u3046\u3002\uFF12\u5C40\u306E\u89AA\u3067\u56FD\u58EB\u7121\u53CC\u30C4\u30E2\u3063\u305F\uFF57\uFF57\uFF57\uFF57",
  "id" : 18776808619,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18787847669",
  "text" : "\u5E30\u5B85\u306A\u3046\u3002\u6700\u60AA\u306E\u751F\u6D3B\u30EA\u30BA\u30E0\u3060\u3002\u4ECA\u304B\u3089\u5BDD\u308B\u306E\u304B\u3041",
  "id" : 18787847669,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18667481123",
  "text" : "\u66B4\u96E8\u3001\u66B4\u98A8\u3001\u96F7\u3002\u304A\u663C\u307E\u3067\u306F\u7DBA\u9E97\u306B\u6674\u308C\u3066\u305F\u306E\u306B\u306A\u3002",
  "id" : 18667481123,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18675510707",
  "geo" : { },
  "id_str" : "18708627550",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa  \u30D2\u30F3\u30C8:\u4E94\u5341\u6B69\u767E\u6B69",
  "id" : 18708627550,
  "in_reply_to_status_id" : 18675510707,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18594957458",
  "geo" : { },
  "id_str" : "18600299500",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308C\u3063\u3066\u5272\u3068\u56F0\u308B\u3088\u306D",
  "id" : 18600299500,
  "in_reply_to_status_id" : 18594957458,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18515881090",
  "text" : "\u660E\u65E54\u9650\u304B\u3089\u3001\u660E\u5F8C\u65E53\u9650\u306E\u307F\u3068\u304B\uFF57\u30C6\u30B9\u30C8\u524D\u3060\u3051\u3069\u3044\u308D\u3044\u308D\u304A\u304B\u3057\u3044\uFF57\uFF57",
  "id" : 18515881090,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18517593282",
  "text" : "\u30B2\u30EA\u30E9\u8C6A\u96E8\u304C\u7D9A\u3044\u3066\u3044\u308B\u3068\u304D\u3063\u3066\u3082\u3046\u305D\u308C\u306F\u30B2\u30EA\u30E9\u3067\u306A\u3044\u6C17\u304C\u3059\u308B\u3002",
  "id" : 18517593282,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mixi",
      "screen_name" : "mixi",
      "indices" : [ 11, 16 ],
      "id_str" : "1515640344",
      "id" : 1515640344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18518756545",
  "text" : "\u4E45\u3005\u306B\u65E5\u8A18\u3092\u66F8\u3044\u3066\u307F\u305F\uFF20mixi",
  "id" : 18518756545,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18398210916",
  "text" : "\u7761\u9B54\u304C\u6709\u9802\u5929",
  "id" : 18398210916,
  "created_at" : "2010-07-13 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18409054761",
  "text" : "\u30EA\u30FC\u30C1\u3001\u30C4\u30E2\u3001\u30BF\u30F3\u30E4\u30AA\u3001\u30D4\u30F3\u30D5\u3001\u30EA\u30E3\u30F3\u30DA\u30FC\u30B3\u30FC\u3001\u30C9\u30E9\uFF11\u3002\u500D\u6E80\uFF01\u30EA\u30E3\u30F3\u30DA\u30FC\u30B3\u30FC\u3068\u304B\u521D\u3081\u3066\u3060\u3002",
  "id" : 18409054761,
  "created_at" : "2010-07-13 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18469736326",
  "text" : "\u5BB6\u304B\u3089\u51FA\u3089\u308C\u306A\u3044\u7A0B\u5EA6\u306E\u8C6A\u96E8\u3002\u3057\u304B\u3057\u4E00\u9650\u30C6\u30B9\u30C8orz",
  "id" : 18469736326,
  "created_at" : "2010-07-13 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18344746104",
  "text" : "\u4ECA\u65E5\u306E\u304A\u5915\u98EF\u306F\u3001\u9D8F\u8089\u306E\u30D1\u30F3\u7C89\u30BD\u30C6\u30FC\u3001\u30BF\u30FC\u30E1\u30EA\u30C3\u30AF\u98A8\u3001\u81EA\u5206\u3067\u8A00\u3046\u3051\u3069\u7F8E\u5473\u3059\u304E\u308B\uFF01\uFF57\uFF57\uFF57",
  "id" : 18344746104,
  "created_at" : "2010-07-12 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18254347006",
  "text" : "\u3084\u306F\u308A\u7D20\u76F4\u306B\u8C46\u3092\u64C2\u3063\u3066\u6DF9\u308C\u305F\u30B3\u30FC\u30D2\u30FC\u306E\u307B\u3046\u304C\u304A\u3044\u3057\u3044\u3002\u3057\u304B\u3082\u5B89\u3044\u3002",
  "id" : 18254347006,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18255597995",
  "geo" : { },
  "id_str" : "18256941151",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \uFF12\u9031\u9593\u524D\u304B\u3089\u9CF4\u3044\u3066\u3044\u305F\u305E",
  "id" : 18256941151,
  "in_reply_to_status_id" : 18255597995,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18270541827",
  "text" : "\u4FFA\u304C\u632F\u308A\u8FBC\u3093\u3060\u8A33\u3058\u3083\u306A\u3044\u304C\u56FD\u58EB\u7121\u53CC\u3063\u3066\u30EA\u30FC\u30C1\u3059\u308B\u3082\u306E\u306A\u306E\uFF1F",
  "id" : 18270541827,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18270700322",
  "geo" : { },
  "id_str" : "18270790657",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa 13\u9762\u3068\u304B\uFF57\uFF57\uFF57\u4FFA\u306F\u77F3\u4E95\u3058\u3083\u306A\u3044\u304B\u3089\uFF57\uFF57",
  "id" : 18270790657,
  "in_reply_to_status_id" : 18270700322,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18307389302",
  "text" : "\u96E8\u2026",
  "id" : 18307389302,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18310501756",
  "text" : "\u6E7F\u5EA6\uFF19\uFF10\uFF05\u3063\u3066\u306A\u306B\uFF1F\u96E8\u304C\u3084\u308B\u6C17\u3092\u6D41\u3057\u3066\u3044\u304F\u671D\uFF18\u6642",
  "id" : 18310501756,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18191006734",
  "geo" : { },
  "id_str" : "18191040440",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5FB9\u591C\u306F\u304A\u52E7\u3081\u3057\u306A\u3044\u304C\u3001\u304C\u3093\u3070\u308C\uFF57",
  "id" : 18191040440,
  "in_reply_to_status_id" : 18191006734,
  "created_at" : "2010-07-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18136659293",
  "text" : "\u30CF\u30C4\u3001\u30C9\u30E9\u30C9\u30E9\u3001\u30C8\u30A4\u30C8\u30A4\u3001\u5DBA\u4E0A\u958B\u82B1(\u5730\u7344\u5358\u9A0E)\u3001\u8DF3\u6E80\uFF01",
  "id" : 18136659293,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17990392812",
  "geo" : { },
  "id_str" : "18009977580",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3048\uFF1F\u5973\u307F\u305F\u3044\u306A\u30DE\u30C4\u30B3\u30C7\u30E9\u30C3\u30AF\u30B9\uFF1F\u3046\uFF50\uFF01",
  "id" : 18009977580,
  "in_reply_to_status_id" : 17990392812,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18017650618",
  "text" : "\u30C1\u30F3\u30A4\u30C4\u30C9\u30E9\uFF14\u3001\u500D\u6E80\uFF01",
  "id" : 18017650618,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18034782435",
  "geo" : { },
  "id_str" : "18036269617",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro 11\u6642\u3068\u304B\uFF57\uFF5723\u6642\u3058\u3083\u306A\u304F\u3066\uFF1F\uFF57\uFF57\uFF57",
  "id" : 18036269617,
  "in_reply_to_status_id" : 18034782435,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17866362583",
  "text" : "2\u65E5\u3082\u653E\u7F6E\u3057\u3066\u3057\u307E\u3063\u305F\u3002\u3064\u3076\u3084\u304F\u3053\u3068\u306A\u3057\u2190",
  "id" : 17866362583,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17876128082",
  "text" : "1\u6642\u9593\u3067\u8AB2\u984C1\/6\u30026\u6642\u9593\u3082\u304B\u3051\u3066\u3089\u3093\u306D\u3047\u3002\u660E\u65E5\u5348\u524D\u4E2D\u306F\u4F11\u8B1B\u3067\u3088\u304B\u3063\u305F\u3002\uFF08\u534A\u5206\u81EA\u4E3B\uFF09",
  "id" : 17876128082,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17703059984",
  "text" : "\u5316\u7269\u8A9E\u89B3\u4E86",
  "id" : 17703059984,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17708572088",
  "text" : "\u30CF\u30AC\u30EC\u30F3\u3082\u7D42\u308F\u308A\u304B\u3041\u2026\u2026\u3002",
  "id" : 17708572088,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17614315758",
  "text" : "\u9D28\u5DDD\u304C\u6885\u96E8\u6FC1\u306A\u4EF6\u306B\u3064\u3044\u3066",
  "id" : 17614315758,
  "created_at" : "2010-07-03 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17618813820",
  "text" : "\u643A\u5E2F\u3060\u304C\u56DB\u6697\u523B\u5358\u9A0E\u5F85\u30AD\u30BF\u30FC",
  "id" : 17618813820,
  "created_at" : "2010-07-03 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]