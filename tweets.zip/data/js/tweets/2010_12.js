Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20696832870973440",
  "text" : "\u30EA\u30FC\u30C5\u30E2\u30CF\u30A4\u30C6\u30A4\u30C1\u30FC\u30C8\u30A4\u6DF7\u8001\u982D\u30C9\u30E9\u30C9\u30E9\u3001\u500D\u6E80\uFF01\u30C1\u30FC\u30C8\u30A4\u6DF7\u8001\u982D\u306F\u521D\u304B\u306A\u3002",
  "id" : 20696832870973440,
  "created_at" : "2010-12-31 04:24:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19748199476494336",
  "text" : "\u305F\u3060\u3001\u4ED6\u306E\u8B66\u9418\u306B\u6C17\u304C\u3064\u304B\u306A\u304B\u3063\u305F\u3060\u3051\u3067\uFF57",
  "id" : 19748199476494336,
  "created_at" : "2010-12-28 13:35:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19748084212830208",
  "text" : "mixi\u30CB\u30E5\u30FC\u30B9\u306E\u4ECA\u5E74\u4E00\u756A\u826F\u304B\u3063\u305F\u30A2\u30CB\u30E1\u7684\u306A\u30CB\u30E5\u30FC\u30B9\u3067\u30DF\u30EB\u30AD\u30FC\u30DB\u30FC\u30E0\u30BA\u304C\u4E00\u5207\u51FA\u3066\u304D\u3066\u3044\u306A\u3044\u4EF6\u306B\u3064\u3044\u3066\u3002\u4ECA\u65E5\u306E\u304B\u308F\u3044\u3044\u30AD\u30E3\u30E9\u3060\u3057\u3068\u3051\u3070\u304A\uFF4B\u8DEF\u7DDA\u306B\u8B66\u9418\u3092\u9CF4\u3089\u3057\u3066\u305F\u306E\u306B\u306A\u30FC\u3002",
  "id" : 19748084212830208,
  "created_at" : "2010-12-28 13:34:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19619329762926592",
  "text" : "\u30D5\u30E9\u30A4\u30F3\u30B0\u306A\u304C\u3089\u3001\u3046\u3069\u3093\u306A\u3046#menjolno",
  "id" : 19619329762926592,
  "created_at" : "2010-12-28 05:03:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19424761541038082",
  "text" : "\u306B\u3057\u3066\u3082\u5FCD\u91CE\u30E1\u30E1\u306F\u3044\u3044\u30AD\u30E3\u30E9\u3057\u3066\u308B\u3088\u306A\u30FC",
  "id" : 19424761541038082,
  "created_at" : "2010-12-27 16:09:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19424610818727936",
  "text" : "\u50BE\u7269\u8A9E\u8AAD\u4E86 \u3084\u3063\u3071\u308A\u3064\u3070\u3055\u30BF\u30A4\u30AC\u30FC\u3068\u306F\u5225\u6642\u7CFB\u5217\u304B\u30FC\u3002\u3082\u3057\u304B\u3057\u305F\u3089\u4ECA\u5F8C\u306E\u4F5C\u54C1\u3001\u5168\u90E8\u4E00\u7DD2\u306E\u6642\u8EF8\u304B\u3068\u601D\u3063\u305F\u306E\u306B\u306A\u30FC\u3002\u3057\u306E\u3076\u30BF\u30A4\u30E0\u306F\u3082\u3057\u304B\u3057\u3066\uFF1F",
  "id" : 19424610818727936,
  "created_at" : "2010-12-27 16:09:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19303375778615296",
  "geo" : { },
  "id_str" : "19305933414862848",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5341\u5206\u30EA\u30A2\u30EB\u304C\u5145\u5B9F\u3057\u3066\u308B\u3058\u3083\u306A\u3044\u304B\uFF57\u307E\u3041\u4FFA\u306F\u4EBA\u591A\u3044\u306E\u3082\u3001\uFF28\u5DDD\u307F\u305F\u3044\u306A\u9152\u306E\u98F2\u307F\u65B9\u3082\u597D\u304D\u3058\u3083\u306A\u3044\u304B\u3089\u306A\u30FC",
  "id" : 19305933414862848,
  "in_reply_to_status_id" : 19303375778615296,
  "created_at" : "2010-12-27 08:17:47 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19298137713680384",
  "geo" : { },
  "id_str" : "19302332831371264",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u65B0\u5E79\u7DDA\u306E\u5B89\u3044\u30C1\u30B1\u30C3\u30C8\u304C\u5E74\u672B\u306F\uFF12\uFF17\u307E\u3067\u3057\u304B\u4F7F\u3048\u306A\u304B\u3063\u305F\u306E\u3055\u3002\u7533\u3057\u8A33\u306A\u3044\u304C\u3002",
  "id" : 19302332831371264,
  "in_reply_to_status_id" : 19298137713680384,
  "created_at" : "2010-12-27 08:03:29 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19294695586795521",
  "text" : "\u65B0\u6A2A\u6D5C\u306A\u3046\u3002\u6A39\u6D77\u306F\u3069\u3053\uFF1F\u3063\u3066\u306A\u3093\u3067\u3067\u3059\u304B\u301C",
  "id" : 19294695586795521,
  "created_at" : "2010-12-27 07:33:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19288093685194752",
  "text" : "\u3082\u3061\u308D\u3093\u898B\u308B\u89D2\u5EA6\u306B\u4F9D\u308B\u306E\u3060\u308D\u3046\u3051\u308C\u3069\u5BCC\u58EB\u5C71\u3068\u7A7A\u306E\u5883\u754C\u304C\u306A\u3059\u66F2\u7DDA\u306F\u3001\u6570\u7406\u7684\u306B\u7F8E\u3057\u3044\u306A\u3041\u3002\u6307\u6570\u51FD\u6570\uFF1F",
  "id" : 19288093685194752,
  "created_at" : "2010-12-27 07:06:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19287179641495552",
  "text" : "\u65B0\u5E79\u7DDA\u306A\u3046",
  "id" : 19287179641495552,
  "created_at" : "2010-12-27 07:03:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19286966407266304",
  "text" : "\u30D5\u30B8\u30E4\u30DE\u30A6\u30C4\u30AF\u30B7",
  "id" : 19286966407266304,
  "created_at" : "2010-12-27 07:02:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18334196661493761",
  "geo" : { },
  "id_str" : "18334975518576642",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u8352\u308C\u3066\u308B\u306D\u3047\uFF57\u304A\u75B2\u308C\u69D8\u3067\u3059\u3002",
  "id" : 18334975518576642,
  "in_reply_to_status_id" : 18334196661493761,
  "created_at" : "2010-12-24 15:59:33 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18318077942829056",
  "geo" : { },
  "id_str" : "18318843189399552",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4E00\u4EBA\u66AE\u3089\u3057\u306B\u306F\u3046\u3089\u3084\u307E\u3057\u3044\u305C\u3002\u3068\u3044\u3046\u304B\u3046\u3061\u3067\u306F\u3053\u306E\u30EC\u30D9\u30EB\u306E\u30AE\u30E3\u30B0\u3067\u3055\u3048\u7406\u89E3\u3057\u3066\u3082\u3089\u3048\u306A\u3044\u3053\u3068\u304C\u3042\u308B\u3093\u3060\u305C\uFF57",
  "id" : 18318843189399552,
  "in_reply_to_status_id" : 18318077942829056,
  "created_at" : "2010-12-24 14:55:27 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18317005639655425",
  "geo" : { },
  "id_str" : "18317409790205952",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3080\u3063\u3061\u3083\u3044\u3044\u5BB6\u5EAD\u3060\u306A\uFF57",
  "id" : 18317409790205952,
  "in_reply_to_status_id" : 18317005639655425,
  "created_at" : "2010-12-24 14:49:45 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18317368170119168",
  "text" : "RT @akeopyaa: \u6BCD\u300C\u30EC\u30D0\u30FC\u7121\u3044\u3084\u300D\u3000\u4FFA\u300C\u30EC\u30D0\u30FC\u304C\u3042\u30EC\u30D0\u306A\u3041\u30FC\u300D\u3000\u4FFA\u300C\u3064\u307E\u3089\u306A\u3044\u30AE\u30E3\u30B0\u8A00\u3063\u3066\u3061\u3083\u3044\u304B\u3093\u305E\u3046(\u809D\u81D3)\u300D\u3000\u59B9\u300C\u982D\u67D4\u3089\u304B\u3044\u306C\u30FC\uFF01\u300D\u3000\u4FFA\u300C\u8912\u3081\u3089\u308C\u305F\uFF57\u3066\u3063\u304D\u308A\u300E\u30AD\u30E2\u30C3(\u809D)\u300F\u3063\u3066\u8A00\u308F\u308C\u308B\u3068\u601D\u3063\u305F\uFF57\uFF57\u300D\u3000\u3053\u3093\u306A\u98DF\u5353\u3002\u4E3B\u4EBA\u516C\u306F\u4FFA\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "18317005639655425",
    "text" : "\u6BCD\u300C\u30EC\u30D0\u30FC\u7121\u3044\u3084\u300D\u3000\u4FFA\u300C\u30EC\u30D0\u30FC\u304C\u3042\u30EC\u30D0\u306A\u3041\u30FC\u300D\u3000\u4FFA\u300C\u3064\u307E\u3089\u306A\u3044\u30AE\u30E3\u30B0\u8A00\u3063\u3066\u3061\u3083\u3044\u304B\u3093\u305E\u3046(\u809D\u81D3)\u300D\u3000\u59B9\u300C\u982D\u67D4\u3089\u304B\u3044\u306C\u30FC\uFF01\u300D\u3000\u4FFA\u300C\u8912\u3081\u3089\u308C\u305F\uFF57\u3066\u3063\u304D\u308A\u300E\u30AD\u30E2\u30C3(\u809D)\u300F\u3063\u3066\u8A00\u308F\u308C\u308B\u3068\u601D\u3063\u305F\uFF57\uFF57\u300D\u3000\u3053\u3093\u306A\u98DF\u5353\u3002\u4E3B\u4EBA\u516C\u306F\u4FFA\u3002",
    "id" : 18317005639655425,
    "created_at" : "2010-12-24 14:48:09 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 18317368170119168,
  "created_at" : "2010-12-24 14:49:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u5C71\u4E00\u4EC1@momonga5589",
      "screen_name" : "momonga5589",
      "indices" : [ 3, 15 ],
      "id_str" : "133814035",
      "id" : 133814035
    }, {
      "name" : "\u5927\u91CE\u3000\u5143\u6BC5",
      "screen_name" : "guitarmoto",
      "indices" : [ 26, 37 ],
      "id_str" : "106918240",
      "id" : 106918240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18316067910721536",
  "text" : "RT @momonga5589: \u3053\u308C\u306F\u3044\u3044 RT @guitarmoto: \u6A2A\u6D5C\u7DDA\u306E\u30A2\u30CA\u30A6\u30F3\u30B9\uFF62\u307E\u3082\u306A\u304F\u7D42\u70B9\u3001\u6A4B\u672C\u3067\u3059\u3002\u5404\u5BB6\u5EAD\u306E\u30B5\u30F3\u30BF\u3055\u3093\u306F\u3001\u793E\u5185\u306B\u30D7\u30EC\u30BC\u30F3\u30C8\u3092\u304A\u5FD8\u308C\u306B\u306A\u3089\u306A\u3044\u3088\u3046\u304A\u6C17\u3092\u3064\u3051\u304F\u3060\u3055\u3044\u3002\uFF63\u30FB\u30FB\u30FBJR\u304C\u3061\u3087\u3063\u3068\u597D\u304D\u306B\u306A\u3063\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5927\u91CE\u3000\u5143\u6BC5",
        "screen_name" : "guitarmoto",
        "indices" : [ 9, 20 ],
        "id_str" : "106918240",
        "id" : 106918240
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "18314528471121920",
    "text" : "\u3053\u308C\u306F\u3044\u3044 RT @guitarmoto: \u6A2A\u6D5C\u7DDA\u306E\u30A2\u30CA\u30A6\u30F3\u30B9\uFF62\u307E\u3082\u306A\u304F\u7D42\u70B9\u3001\u6A4B\u672C\u3067\u3059\u3002\u5404\u5BB6\u5EAD\u306E\u30B5\u30F3\u30BF\u3055\u3093\u306F\u3001\u793E\u5185\u306B\u30D7\u30EC\u30BC\u30F3\u30C8\u3092\u304A\u5FD8\u308C\u306B\u306A\u3089\u306A\u3044\u3088\u3046\u304A\u6C17\u3092\u3064\u3051\u304F\u3060\u3055\u3044\u3002\uFF63\u30FB\u30FB\u30FBJR\u304C\u3061\u3087\u3063\u3068\u597D\u304D\u306B\u306A\u3063\u305F\u3002",
    "id" : 18314528471121920,
    "created_at" : "2010-12-24 14:38:18 +0000",
    "user" : {
      "name" : "\u9AD8\u5C71\u4E00\u4EC1@momonga5589",
      "screen_name" : "momonga5589",
      "protected" : false,
      "id_str" : "133814035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487669723719405569\/-HKOy6oQ_normal.jpeg",
      "id" : 133814035,
      "verified" : false
    }
  },
  "id" : 18316067910721536,
  "created_at" : "2010-12-24 14:44:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18312705454645248",
  "geo" : { },
  "id_str" : "18313889414389761",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3093\u306A\u3082\u3093\u3069\u3046\u3084\u3063\u3066\u5BA2\u89B3\u6570\u5024\u5316\u3059\u308B\u3093\u3060\u3088",
  "id" : 18313889414389761,
  "in_reply_to_status_id" : 18312705454645248,
  "created_at" : "2010-12-24 14:35:46 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18291423442903040",
  "geo" : { },
  "id_str" : "18295189793673217",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3069\u3046\u3057\u3066\u305D\u3046\u306A\u3063\u305F\u3002\u304A\u5927\u4E8B\u306B\u3002",
  "id" : 18295189793673217,
  "in_reply_to_status_id" : 18291423442903040,
  "created_at" : "2010-12-24 13:21:27 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18267485681745920",
  "text" : "\u4ECA\u591C\u306E\u3054\u98EF\u306F\u9EBB\u5A46\u8C46\u8150\u306A\u306E\u3055\u30FC\u3002\u3068\u3063\u3066\u3082\u8F9B\u3044\u5974\u3002\u5473\u898B\u3057\u305F\u3089\u564E\u305B\u308B\u30EC\u30D9\u30EB\u3002",
  "id" : 18267485681745920,
  "created_at" : "2010-12-24 11:31:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18218905935814656",
  "text" : "\u663C\u904E\u304E\u304B\u3089\u59CB\u3081\u305F\u5927\u6383\u9664\u304C\u3088\u3046\u3084\u304F\u7D42\u308F\u308A\u3092\u8FCE\u3048\u305F\u3002\u6383\u9664\u306E\u3006\u306B\u633D\u304D\u305F\u3066\u306E\u30B3\u30FC\u30D2\u30FC\u3092\u98F2\u3080\u306E\u306F\u5B9F\u5BB6\u304B\u3089\u306E\u7FD2\u6163\u3067\u3042\u308B\u3002",
  "id" : 18218905935814656,
  "created_at" : "2010-12-24 08:18:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18037300789256192",
  "text" : "\u7720\u308C\u306A\u3044orz",
  "id" : 18037300789256192,
  "created_at" : "2010-12-23 20:16:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17957318150852609",
  "text" : "10\u6642\u9593\u8FD1\u304F\u5BDD\u3066\u3001\u3042\u307E\u3064\u3055\u3048\u663C\u5BDD\uFF08\u5915\u5BDD\uFF1F\uFF09\u3055\u3048\u3057\u3066\u3057\u307E\u3063\u305F\u79C1\u306F\u4F55\u6642\u7720\u304F\u306A\u308B\u306E\u304B\u3002",
  "id" : 17957318150852609,
  "created_at" : "2010-12-23 14:58:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17060725360959488",
  "text" : "\u3054\u98EF\u5F8C\u306E\u3053\u306E\u6642\u9593\u306F\u4F55\u3068\u3082\u7720\u3044\u3002\u6388\u696D\u307E\u3067\u30B7\u30A8\u30B9\u30BF\u3057\u3088\u3046\u3002",
  "id" : 17060725360959488,
  "created_at" : "2010-12-21 03:36:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16495658269679616",
  "geo" : { },
  "id_str" : "16495995135201280",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3053\u306E\u30C4\u30A4\u30FC\u30C8\u304C\u3059\u3067\u306B\u96D1\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 16495995135201280,
  "in_reply_to_status_id" : 16495658269679616,
  "created_at" : "2010-12-19 14:12:06 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16455793922547712",
  "text" : "@koketomi \u5927\u304D\u3044\u751F\u8089\u5148\u306B\u72E9\u3063\u305F\u3089\u884C\u3051\u305F\uFF57",
  "id" : 16455793922547712,
  "created_at" : "2010-12-19 11:32:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16343944858173440",
  "text" : "\u30A2\u30B8\u30AB\u30F3\u3001\u591C\u306F\u77ED\u3057\u6B69\u3051\u3088\u4E59\u5973\u306A\u3093\u304B\u306E\u8868\u7D19\u3001\u30B8\u30E3\u30B1\u30C3\u30C8\u306E\u4E2D\u6751\u3055\u3093\u306E\u30B5\u30A4\u30F3\u4F1A\u6642\u9593\u5F85\u3061\u306A\u3046\u3002",
  "id" : 16343944858173440,
  "created_at" : "2010-12-19 04:07:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16017374566154240",
  "geo" : { },
  "id_str" : "16150511803695105",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\uFF4B",
  "id" : 16150511803695105,
  "in_reply_to_status_id" : 16017374566154240,
  "created_at" : "2010-12-18 15:19:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16071922592784384",
  "text" : "\u4E45\u3005\u306B\u7B11\u3063\u305Fhttp:\/\/www.nicovideo.jp\/watch\/sm7588593",
  "id" : 16071922592784384,
  "created_at" : "2010-12-18 10:06:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16060790243069952",
  "text" : "@koketomi \u751F\u306E\u9B5A\u306F\u4E45\u3057\u304F\u98DF\u3079\u3066\u306A\u3044\u306A\u3041\u3001\u3046\u3089\u3084\u307E\u3057\u3044\uFF57",
  "id" : 16060790243069952,
  "created_at" : "2010-12-18 09:22:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16023825309237248",
  "text" : "tk\u79C1\u306E\u8A69\u96C6\u3068\u304B\u30CD\u30BF\u304C\u30B3\u30A2\u3059\u304E\u308B\u3060\u308D\uFF57\uFF57\u65B0\u5BBF\u99C5\uFF57\uFF57#milkyholmes",
  "id" : 16023825309237248,
  "created_at" : "2010-12-18 06:55:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16023625949782016",
  "text" : "\u3084\u3063\u3068\u3053\u3055\u304A\u8A71\u306B\u306A\u3063\u3066\u304D\u305F\u306A\u3041#milkyholmes",
  "id" : 16023625949782016,
  "created_at" : "2010-12-18 06:55:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15763317565947908",
  "geo" : { },
  "id_str" : "15763880139554816",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u305F\u307E\u305F\u307E\u4E8C\u6B21\u66F2\u7DDA\u306E\u554F\u984C\u5F04\u3063\u3066\u3066\u624B\u5143\u306B\u8A08\u7B97\u7528\u7D19\u304C\u3042\u3063\u305F\u3093\u3067\u3001\u30BF\u30A4\u30DF\u30F3\u30B0\u304C\u7D76\u5999\u3067\u3057\u305F\uFF57",
  "id" : 15763880139554816,
  "in_reply_to_status_id" : 15763317565947908,
  "created_at" : "2010-12-17 13:42:56 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15763280345702400",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3000\uFF38\uFF1D\uFF58\uFF0D\uFF15\u3067\u7F6E\u304D\u63DB\u3048\u305F\u3093\u3067\u3057\u305F\u3002\u91CD\u306D\u3066\u8A02\u6B63\u3057\u307E\u3059\uFF57\u3000",
  "id" : 15763280345702400,
  "created_at" : "2010-12-17 13:40:33 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15762922194079744",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3000\u5931\u793C\u3002\uFF38\uFF1D\uFF58\uFF0B\uFF15\u306E\u307E\u307E\u3060\u3063\u305F\u306E\u3067\uFF58\uFF0B\uFF59\uFF1D-1993",
  "id" : 15762922194079744,
  "created_at" : "2010-12-17 13:39:08 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15756592339226626",
  "geo" : { },
  "id_str" : "15761711977996288",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u03C0\u306E\u6761\u4EF6\u660E\u3089\u304B\u306B\u8981\u3089\u306A\u3044\u3067\u3059\u304C\uFF58\uFF0B\uFF59\uFF1D-1998",
  "id" : 15761711977996288,
  "in_reply_to_status_id" : 15756592339226626,
  "created_at" : "2010-12-17 13:34:19 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15752457925697538",
  "geo" : { },
  "id_str" : "15754680290246657",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4EAC\u90FD\u30BF\u30EF\u30FC\u306A\u3093\u3066\u306A\u304B\u3063\u305F\u3002",
  "id" : 15754680290246657,
  "in_reply_to_status_id" : 15752457925697538,
  "created_at" : "2010-12-17 13:06:23 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15442585719934976",
  "text" : "\u534A\u8358\u4E8C\u56DE\u3067\u4E8C\u56DE\u3068\u3082\uFF15\u4E07\u70B9\u4EE5\u4E0A\u6301\u3063\u3066\u7D42\u5C40\u3068\u3044\u3046\u9B3C\u30C5\u30E2\u3002\u3044\u3064\u3082\u3053\u306E\u304F\u3089\u3044\u3060\u3068\u3044\u3044\u3051\u3069\uFF57",
  "id" : 15442585719934976,
  "created_at" : "2010-12-16 16:26:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15442317477416960",
  "text" : "\u53CB\u4EBA\u3068\u934B\u2192\u9EBB\u96C0\u3002\u6628\u65E5\u304B\u3089\u4ECA\u65E5\u306B\u639B\u3051\u3066\u5178\u578B\u7684\u306A\u30EA\u30A2\u5145\u3067\u3057\u305F\uFF57",
  "id" : 15442317477416960,
  "created_at" : "2010-12-16 16:25:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15073557235109888",
  "text" : "\u4ECA\u3042\u308A\u306E\u307E\u307E\u306B\u8D77\u3053\u3063\u305F\u3053\u3068\u3092\u8A71\u3059\u305C\u2026\uFF01\u4FFA\u306F\u30EA\u30AA\u30EC\u30A4\u30A2\u306E\u5C3B\u5C3E\u3092\u5207\u3063\u305F\u3093\u3060\u3001\u3059\u308B\u3068\u6B21\u306E\u77AC\u9593\u5C3B\u5C3E\u304C\u5FA9\u6D3B\u3057\u3066\u3044\u305F\u3093\u3060\u3002\u4F55\u3092\u8A00\u3063\u3066\u308B\u306E\u304B\u308F\u304B\u3089\u306D\u3047\u3068\u601D\u3046\u304C\u3001\u7E2B\u5408\u624B\u8853\u3060\u3068\u304B\u8D85\u901F\u518D\u751F\u3060\u3068\u304B\u305D\u3093\u306A\u3061\u3083\u3061\u306A\u3082\u3093\u3058\u3083\u65AD\u3058\u3066\u306D\u3047\u3001\u3082\u3063\u3068\u6050\u308D\u3057\u3044\u3082\u306E\u306E\u9006\u9C57\u3092\u5473\u308F\u3063\u305F\u305C\u2026",
  "id" : 15073557235109888,
  "created_at" : "2010-12-15 15:59:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15041556285231104",
  "text" : "RT @NHK_PR: \u5148\u307B\u3069\u306E\u30C4\u30A4\u30FC\u30C8\u3067\u3001\u3055\u304B\u306A\u30AF\u30F3\u3055\u3093\u3092\u3001\u3055\u304B\u306A\u30AF\u30F3\u3068\u304A\u547C\u3073\u3057\u3066\u3057\u307E\u3044\u307E\u3057\u305F\u3002\u305F\u3044\u3078\u3093\u306A\u5931\u793C\u3092\u3044\u305F\u3057\u307E\u3057\u305F\u3002\u7533\u3057\u308F\u3051\u3042\u308A\u307E\u305B\u3093\u3002\u304A\u8A6B\u3073\u3057\u3066\u8A02\u6B63\u3044\u305F\u3057\u307E\u3059\u3002\u4F55\u5352\u3054\u5BB9\u8D66\u304F\u3060\u3055\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15033076312711169",
    "text" : "\u5148\u307B\u3069\u306E\u30C4\u30A4\u30FC\u30C8\u3067\u3001\u3055\u304B\u306A\u30AF\u30F3\u3055\u3093\u3092\u3001\u3055\u304B\u306A\u30AF\u30F3\u3068\u304A\u547C\u3073\u3057\u3066\u3057\u307E\u3044\u307E\u3057\u305F\u3002\u305F\u3044\u3078\u3093\u306A\u5931\u793C\u3092\u3044\u305F\u3057\u307E\u3057\u305F\u3002\u7533\u3057\u308F\u3051\u3042\u308A\u307E\u305B\u3093\u3002\u304A\u8A6B\u3073\u3057\u3066\u8A02\u6B63\u3044\u305F\u3057\u307E\u3059\u3002\u4F55\u5352\u3054\u5BB9\u8D66\u304F\u3060\u3055\u3044\u3002",
    "id" : 15033076312711169,
    "created_at" : "2010-12-15 13:18:59 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 15041556285231104,
  "created_at" : "2010-12-15 13:52:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15012560835182592",
  "geo" : { },
  "id_str" : "15026874904219648",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5E7E\u4F55\u306F\u3061\u3083\u3093\u3068\u89E3\u8AAC\"\u304D\u304B\u2033\u306A\u3044\u3068\uFF01",
  "id" : 15026874904219648,
  "in_reply_to_status_id" : 15012560835182592,
  "created_at" : "2010-12-15 12:54:20 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14854965113655296",
  "text" : "\u304E\u308A\u304E\u308A\u4E00\u9650\u9593\u306B\u5408\u3063\u305F\u304C\u80C3\u306E\u4E2D\u304C\u7A7A\u3063\u307D\u3002\u304A\u8179\u6E1B\u3063\u305F\u306A\u3041\u3002\u3067\u3082\u4E8C\u9650\u3002",
  "id" : 14854965113655296,
  "created_at" : "2010-12-15 01:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14534237600358400",
  "text" : "\u305D\u3057\u3066\u6559\u6388\u306F\u73FE\u308C\u305A\u3002\u5168\u304F\u69CB\u308F\u306A\u3044\u3051\u3069\u2190",
  "id" : 14534237600358400,
  "created_at" : "2010-12-14 04:16:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14533899505901569",
  "text" : "\u663C\u4F11\u307F\u4E38\u3005\u5BDD\u3066\u305F\u3089\u8D77\u304D\u4E0A\u304C\u308B\u3068\u304D\u91D1\u7E1B\u308A\u306B\u3042\u3063\u305F\u3002\u7A81\u3063\u4F0F\u3057\u3066\u3066\u3082\u306A\u308B\u3082\u306E\u306A\u306E\u306D\u3047\u3002",
  "id" : 14533899505901569,
  "created_at" : "2010-12-14 04:15:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14508699489931264",
  "text" : "@koketomi \u68A8\u3058\u3083\u306D\uFF1F",
  "id" : 14508699489931264,
  "created_at" : "2010-12-14 02:35:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13612378914553856",
  "geo" : { },
  "id_str" : "13612715717173249",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u304A\u5F01\u5F53\u306E\u51B7\u3081\u305F\u3054\u98EF\u306F\u5ACC\u3044\u3058\u3083\u306A\u3044\u3051\u3069\u3001\u305D\u308C\u306A\u3089\u5510\u63DA\u3052\u3082\u51B7\u3081\u3066\u3066\u3044\u3044\u3084\uFF57",
  "id" : 13612715717173249,
  "in_reply_to_status_id" : 13612378914553856,
  "created_at" : "2010-12-11 15:14:58 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12674507063955456",
  "geo" : { },
  "id_str" : "12707298719834113",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u7D42\u308F\u3063\u305F\u3089\u904A\u3073\u306B\u98F2\u307F\u306B\u8272\u3005\u884C\u3053\u3046\u306A\uFF57\u307E\u3041\u540C\u7A93\u4F1A\uFF08\u7B11\uFF09\u306E\u8A71\u306F\u9152\u306E\u80B4\u306B\u306F\u306A\u308B\u3060\u308D\u3046\u3088",
  "id" : 12707298719834113,
  "in_reply_to_status_id" : 12674507063955456,
  "created_at" : "2010-12-09 03:17:10 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12533138169270272",
  "geo" : { },
  "id_str" : "12533669818269696",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30FB\u30FB\u30FB\u5BDF\u3057\u3066\u3084\u308C\uFF57",
  "id" : 12533669818269696,
  "in_reply_to_status_id" : 12533138169270272,
  "created_at" : "2010-12-08 15:47:14 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12419733815042048",
  "geo" : { },
  "id_str" : "12420047850967040",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4ECA\u56DE\u3082\u3053\u3053\u308D\u3061\u3083\u3093\u306E\uFF29\uFF31\u306E\u6841\u304C\u5897\u3048\u3066\u307E\u3057\u305F\u306D\uFF57",
  "id" : 12420047850967040,
  "in_reply_to_status_id" : 12419733815042048,
  "created_at" : "2010-12-08 08:15:44 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12380919134429184",
  "text" : "\u4E00\u5BFE\u4E00\u3067\u5FAE\u7A4D\u3001\u7DDA\u5F62\u4EE3\u6570\u3001\u5FAE\u5206\u65B9\u7A0B\u5F0F\u3001\u8907\u7D20\u95A2\u6570\u3001\u7D71\u8A08\u2026\u307F\u305F\u3044\u306A",
  "id" : 12380919134429184,
  "created_at" : "2010-12-08 05:40:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12380793372418048",
  "text" : "\u6771\u4EAC\u51FA\u7248\u3055\u3093\u3001\u5927\u5B66\u3067\u306E\u6570\u5B66\u307F\u305F\u3044\u306E\u51FA\u3057\u3066\u304F\u3093\u306A\u3044\u304B\u306A\u30FC\u3002",
  "id" : 12380793372418048,
  "created_at" : "2010-12-08 05:39:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12339989014642688",
  "text" : "\u5927\u5B66\u751F\u5354\u306E\u30EA\u30AF\u30A8\u30B9\u30C8\u7528\u7D19\u306B\u300C\u4E00\u756A\u3044\u3044\u306E\u3092\u983C\u3080\u300D\u3068\u3060\u3051\u66F8\u3044\u3066\u3042\u3063\u3066\u5439\u3044\u305F\uFF57\uFF57\u751F\u5354\u8077\u54E1\u306E\u771F\u9762\u76EE\u306A\u8FD4\u7B54\u306B\u3082\u5439\u3044\u305F\uFF57",
  "id" : 12339989014642688,
  "created_at" : "2010-12-08 02:57:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12160959351099392",
  "geo" : { },
  "id_str" : "12161321730572288",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u3042\u308C\u539F\u4F5C\u3082\u8AAD\u3093\u3060\u3051\u3069\u3044\u3044\u3088\u306D\u3002\u3059\u3054\u304F\u5207\u306A\u3044\u3002\u3042\u3068\u30C9\u30FC\u30CA\u30C4\u30D3\u30B9\u30B1\u30C3\u30C8\u98DF\u3079\u305F\u304F\u306A\u308B\uFF57",
  "id" : 12161321730572288,
  "in_reply_to_status_id" : 12160959351099392,
  "created_at" : "2010-12-07 15:07:39 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12157497225773056",
  "text" : "\u3054\u98EF\u304C\u306A\u3044\u306A\u3089\u30D1\u30F3\u3092\u304B\u3058\u308C\u3070\u3044\u3044\u3058\u3083\u306A\u3044\u3002\u5FA1\u5915\u98EF\u306A\u3046\u3002",
  "id" : 12157497225773056,
  "created_at" : "2010-12-07 14:52:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12149527880400896",
  "text" : "\u30D0\u30A4\u30C8\u306E\u5E30\u308A\u306B\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u304F\u306A\u308B\u306E\u306F\u4F55\u6545\u3060\u308D\u3046",
  "id" : 12149527880400896,
  "created_at" : "2010-12-07 14:20:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12149235331891201",
  "text" : "@koketomi \u713C\u304D\u305D\u3070\u2026\u590F\u306E\u6642\u671F\u306E\u51B7\u3081\u305F\u306E\u306F\u5ACC\u3044\u3058\u3083\u306A\u3044\u304C\u3053\u306E\u6642\u671F\u306E\u306F\u51B7\u3081\u305F\u3001\u3068\u8A00\u3046\u3088\u308A\u51B7\u3048\u305F\u3001\u3060\u3082\u3093\u306A\uFF57",
  "id" : 12149235331891201,
  "created_at" : "2010-12-07 14:19:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12059095221673984",
  "geo" : { },
  "id_str" : "12059610013769728",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3063\u3066\u3001\u306A\u3093\u3067\u3067\u3059\u304B\u301C",
  "id" : 12059610013769728,
  "in_reply_to_status_id" : 12059095221673984,
  "created_at" : "2010-12-07 08:23:29 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milkyhomes",
      "indices" : [ 9, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11708183600963584",
  "text" : "\u3063\u3066\u306A\u3093\u3067\u3067\u3059\u304B\uFF5E#milkyhomes",
  "id" : 11708183600963584,
  "created_at" : "2010-12-06 09:07:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11453069019578368",
  "text" : "\u7D50\u5C40\u65E5\u4ED8\u306F\u5909\u308F\u3063\u3066\u3057\u307E\u3044\u307E\u3057\u305F\u3068\u3055\u3002\u30D5\u30E9\u30B0\u56DE\u53CE\u30C3",
  "id" : 11453069019578368,
  "created_at" : "2010-12-05 16:13:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11452958268981248",
  "text" : "\u7D42\u308F\u3063\u305F\u30FC\n\u4E00\u500B\u4E2D\u9014\u534A\u7AEF\u3060\u3051\u3069\u306A\u3093\u3068\u304B\u306A\u308B\u3060\u308D\u3046\uFF57",
  "id" : 11452958268981248,
  "created_at" : "2010-12-05 16:12:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11415730482319360",
  "text" : "\u3042\u3068\u4E8C\u3064\u3002\u4ECA\u65E5\u4E2D\u306B\u306F\u7D42\u308F\u308B\u3068\u3044\u3044\u3093\u3060\u3051\u3069\u306A\u30FC",
  "id" : 11415730482319360,
  "created_at" : "2010-12-05 13:44:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11407837972406272",
  "text" : "\u4E00\u6BB5\u843D!\u3060\u304C\u307E\u30603\u6BB5\u843D\u307B\u3069\u3042\u308B\u306E\u3055orz",
  "id" : 11407837972406272,
  "created_at" : "2010-12-05 13:13:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11364365362003968",
  "text" : "\u30E2\u30F3\u30CF\u30F3\u3084\u308A\u3066\u3047\u2026\u2026\u3067\u3082\u8AB2\u984C\u30A7\u2026\uFF01\u3068\u308A\u3042\u3048\u305A\u76EE\u6A19\u306F\u65E5\u4ED8\u5909\u308F\u308B\u524D\u306B\u8AB2\u984C\u3092\u7D42\u3048\u308B\u3053\u3068\u2190\u6B7B\u4EA1\u30D5\u30E9\u30B0\u3058\u3083\u306A\u3044\u3088\u2190\uFF08\uFF52\uFF59",
  "id" : 11364365362003968,
  "created_at" : "2010-12-05 10:20:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11317043437502465",
  "geo" : { },
  "id_str" : "11323133759848448",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30A4\u30F3\u30B9\u30BF\u30F3\u30C8\u30B3\u30FC\u30D2\u30FC\u3092\u7D04\u4E8C\u500D\u306E\u6FC3\u3055\u3067\u98F2\u3093\u3067\u3044\u3066\u3057\u3070\u3089\u304F\u6C17\u304C\u3064\u304B\u306A\u304B\u3063\u305F\u4FFA\u304C\u901A\u308A\u307E\u3059\u3088\u3063\u3068\u3002",
  "id" : 11323133759848448,
  "in_reply_to_status_id" : 11317043437502465,
  "created_at" : "2010-12-05 07:37:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10261681284321280",
  "text" : "\u30B4\u30FC\u30EB\u30C7\u30F3\u30B9\u30E9\u30F3\u30D0\u30FC\u6587\u5EAB\u5316\u3057\u3066\u308B\u3058\u3083\u306A\u3044\u304B\u30FC\u3002\u51FA\u7248\u793E\u3068\u306E\u6211\u6162\u6BD4\u3079\u306B\u3064\u3044\u306B\u8CB7\u3063\u305F\u308F\u2190",
  "id" : 10261681284321280,
  "created_at" : "2010-12-02 09:19:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10261396570771456",
  "text" : "\u643A\u5E2F\u3060\u304C\u5C0F\u56DB\u559C\u548C\u4E86\u3002\u6700\u671F\u30B7\u30E3\u30DC\u5F85\u3061\u3060\u3063\u305F\u3051\u3069\u30D5\u30EA\u30C6\u30F3\u3067\u6700\u671F\u306E\u5317\u3092\u30E9\u30B9\u30C8\uFF12\u9806\u3067\u5F15\u304F\u52C7\u6C17\u306F\u3042\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
  "id" : 10261396570771456,
  "created_at" : "2010-12-02 09:18:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10258352332349440",
  "geo" : { },
  "id_str" : "10259011794374656",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u304A\u524D\u5E79\u4E8B\u3084\u308B\u3068gdgd\u3059\u308B\u304B\u3089\u30AA\u30B9\u30B9\u30E1\u3057\u306A\u3044\u3051\u3069\u306A\u30FC",
  "id" : 10259011794374656,
  "in_reply_to_status_id" : 10258352332349440,
  "created_at" : "2010-12-02 09:08:33 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10235388010430464",
  "geo" : { },
  "id_str" : "10235694165270528",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u306F\u8A18\u8FF0\u30B9\u30AD\u30FC\u3060\u3063\u305F\u3002\u3069\u3063\u3061\u304C\u826F\u304B\u3063\u305F\u3063\u3066\u8A00\u3046\u304B\u51FA\u6765\u308B\u5974\u306F\u4E21\u65B9\u51FA\u6765\u308B\u3088\u306A\u30FC\u3002",
  "id" : 10235694165270528,
  "in_reply_to_status_id" : 10235388010430464,
  "created_at" : "2010-12-02 07:35:54 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10235312605237249",
  "text" : "\u6388\u696D\u304C\u53F3\u304B\u3089\u5165\u3063\u3066\u5DE6\u306B\u629C\u3051\u308B\u304B\u3068\u601D\u3044\u304D\u3084\u3001\u53F3\u3082\u5165\u3063\u3066\u3082\u3044\u306A\u304B\u3063\u305F\u2190\u305F\u3060\u3001\u7A7A\u6C17\u304C\u9707\u3048\u305F\u3060\u3051\u3002",
  "id" : 10235312605237249,
  "created_at" : "2010-12-02 07:34:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10143653112578048",
  "text" : "\u300C\u96C6\u4F1A\u306B\u96C6\u307E\u308D\u3046\u300D\u3063\u3066\u91CD\u8907\u306E\u81ED\u3044\u304C\u3059\u308B\u3088\u306A\u3002\u67D0\u30D3\u30E9\u306E\u5927\u898B\u51FA\u3057\u3060\u3063\u305F\u304C\uFF57\uFF57",
  "id" : 10143653112578048,
  "created_at" : "2010-12-02 01:30:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9988379370332161",
  "geo" : { },
  "id_str" : "9998588075573248",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4E00\u5FDC\u7A81\u3063\u8FBC\u3093\u3067\u304A\u304D\u307E\u3059\u304C\u30CE\u30AD\u30B5\u30AB\u3058\u3083\u306A\u304F\u3066\u30CE\u30AE\u30B5\u30AB\u3055\u3093\u3067\u3059\uFF57\u3042\u3068\u30E8\u30B9\u30AC\u30CE\u30BD\u30E9\u3088\u308A\u30DF\u30EB\u30AD\u30FC\u306E\uFF12\uFF10\u5358\u9A0E\u306E\u307B\u3046\u304C\u516C\u5171\u96FB\u6CE2\u7684\u306B\u30A2\u30A6\u30C8\u3060\u3068\u601D\u3044\u307E\u3059\u2190",
  "id" : 9998588075573248,
  "in_reply_to_status_id" : 9988379370332161,
  "created_at" : "2010-12-01 15:53:43 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9897427435786240",
  "geo" : { },
  "id_str" : "9931787996233729",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u666E\u901A\u306B\u30ED\u30FC\u30BD\u30F3\u3067\u4E88\u7D04\u3067\u3057\u305F\u3002\uFF30\uFF33\uFF30\u3068\u68B1\u5305\u306E\u30D1\u30C3\u30AF\u3082\u3042\u308B\u3089\u3057\u3044\u306E\u3067\u305C\u3072\u305C\u3072\uFF01",
  "id" : 9931787996233729,
  "in_reply_to_status_id" : 9897427435786240,
  "created_at" : "2010-12-01 11:28:17 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9896991874093056",
  "text" : "\u30E2\u30F3\u30CF\u30F3\u306A\u3046\u30FC\u3002\u3088\u304F\u3088\u304F\u8003\u3048\u308C\u3070\uFF30\uFF33\uFF30\u306E\u30B2\u30FC\u30E0\u3067\u65B0\u54C1\u3067\u3001\u3057\u304B\u3082\u767A\u58F2\u65E5\u306B\u8CB7\u3063\u305F\u306E\u3063\u3066\u521D\u3081\u3066\u3060\uFF57",
  "id" : 9896991874093056,
  "created_at" : "2010-12-01 09:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9804002992586752",
  "text" : "\u65E5\u306A\u305F\u306A\u3089\u6696\u304B\u3044\u3002\u6696\u623F(\uFF1F)\u304C\u3064\u3044\u3066\u308B\u65E5\u9670\u306E\u6559\u5BA4\u3088\u308A\u6696\u304B\u3044\u3063\u3066\u3069\u3046\u306A\u306E\uFF1F",
  "id" : 9804002992586752,
  "created_at" : "2010-12-01 03:00:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]