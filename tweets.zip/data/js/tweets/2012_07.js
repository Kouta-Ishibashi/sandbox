Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230308754028113920",
  "text" : "TL\u306B\u5730\u5143\u306E\u77E5\u3063\u3066\u308B\u5358\u8A9E\u304C\u51FA\u3066\u304F\u308B\u3068\u5B09\u3057\u304F\u306A\u3063\u3066\u3057\u307E\u3046",
  "id" : 230308754028113920,
  "created_at" : "2012-07-31 14:27:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3057\u3083\u3053",
      "screen_name" : "nashacom",
      "indices" : [ 0, 9 ],
      "id_str" : "90918872",
      "id" : 90918872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230308263940472832",
  "geo" : { },
  "id_str" : "230308617151193088",
  "in_reply_to_user_id" : 90918872,
  "text" : "@nashacom \u304D\u3089\u661F\u3068\u306F\u61D0\u304B\u3057\u3044\uFF01\u3042\u308C\u3082\u7D50\u69CB\u3053\u3063\u3066\u308A\u3067\u3059\u3088\u306D\uFF0E",
  "id" : 230308617151193088,
  "in_reply_to_status_id" : 230308263940472832,
  "created_at" : "2012-07-31 14:27:07 +0000",
  "in_reply_to_screen_name" : "nashacom",
  "in_reply_to_user_id_str" : "90918872",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230301010722168832",
  "text" : "\u30AF\u30FC\u30E9\u30FC\u306E\u305B\u3044\u3067\u5589\u3044\u305F\u3044\u3057\u884C\u3063\u305F\u3093\u5207\u308B\u304B",
  "id" : 230301010722168832,
  "created_at" : "2012-07-31 13:56:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230300905004748801",
  "text" : "\u78BA\u7387\u306E\u30EC\u30DD\u30FC\u30C8\u4ED5\u4E0A\u304C\u3063\u305F\u30A1\uFF01",
  "id" : 230300905004748801,
  "created_at" : "2012-07-31 13:56:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230281641967382528",
  "text" : "\u6C17\u5408\u3067\u3084\u308C\u3070\u7D20\u6575\u306A\u7D50\u679C\u304C\u5F85\u3063\u3066\u3044\u308B\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 230281641967382528,
  "created_at" : "2012-07-31 12:39:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230271741329555458",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 230271741329555458,
  "created_at" : "2012-07-31 12:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8A66\u9A13\u524D\u3060\u304B\u3089",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229912680809521152",
  "text" : "\u6848\u5916\u4EBA\u6355\u307E\u3089\u306A\u3044\u306A\u2026 #\u8A66\u9A13\u524D\u3060\u304B\u3089",
  "id" : 229912680809521152,
  "created_at" : "2012-07-30 12:13:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229903961740681216",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u304A\u3072\u307E\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u306D(",
  "id" : 229903961740681216,
  "created_at" : "2012-07-30 11:39:10 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229901114638733313",
  "text" : "\u6687\u306A\u4EBA\u3044\u306A\u3044\u306E\u304B\u306A(\u305D\u3082\u305D\u3082\u81EA\u5206\u306F\u6687\u306A\u306E\u304B)",
  "id" : 229901114638733313,
  "created_at" : "2012-07-30 11:27:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229896424572203009",
  "text" : "\u4E00\u4EBA\u6B20\u3051\u306E\u9EBB\u96C0\u5353\u304B\u3041(\u30C1\u30E9\u30C3",
  "id" : 229896424572203009,
  "created_at" : "2012-07-30 11:09:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229765579605696513",
  "text" : "\u5727\u5012\u7684\u306D\u3080\u305F\u307F",
  "id" : 229765579605696513,
  "created_at" : "2012-07-30 02:29:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u604B\u3059\u308B\u307D\u304B\u305F\u3093\u5148\u8F29",
      "screen_name" : "Bzxc2",
      "indices" : [ 12, 18 ],
      "id_str" : "232626869",
      "id" : 232626869
    }, {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 19, 32 ],
      "id_str" : "264005011",
      "id" : 264005011
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 33, 46 ],
      "id_str" : "295206903",
      "id" : 295206903
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 47, 62 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 63, 77 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 78, 94 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229762488487522304",
  "text" : ". @ispamgis @Bzxc2 @carotene4035 @nisehorrrrrn @G4_Hirano_chan @riveriver4361 @Jelly_in_a_tank @setsuna3021181 \u304A\u306F\u3042\u308A\u3067\u3057\u305F\u30FC",
  "id" : 229762488487522304,
  "created_at" : "2012-07-30 02:17:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229712388851658752",
  "text" : "\u8D77\u304D\u305F",
  "id" : 229712388851658752,
  "created_at" : "2012-07-29 22:57:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twipla.jp\" rel=\"nofollow\"\u003ETwiPla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3064\u3069\u3044\u7CFB\u30A4\u30D9\u30F3\u30C8\u7D39\u4ECBbot",
      "screen_name" : "sugakuto_osaka",
      "indices" : [ 0, 15 ],
      "id_str" : "481590089",
      "id" : 481590089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/5m53I5mk",
      "expanded_url" : "http:\/\/twipla.jp\/events\/25496",
      "display_url" : "twipla.jp\/events\/25496"
    } ]
  },
  "geo" : { },
  "id_str" : "229613142202781696",
  "in_reply_to_user_id" : 481590089,
  "text" : "@sugakuto_osaka \u53C2\u52A0\u3057\u307E\u3059\uFF01 http:\/\/t.co\/5m53I5mk",
  "id" : 229613142202781696,
  "created_at" : "2012-07-29 16:23:33 +0000",
  "in_reply_to_screen_name" : "sugakuto_osaka",
  "in_reply_to_user_id_str" : "481590089",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229606391323713536",
  "text" : "\u306A\u3093\u3067\u30EC\u30DD\u30FC\u30C8\u306B\u304F\u305D\u307E\u3058\u3081\u306B\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\u306E\u3084\u308A\u65B9\u66F8\u3044\u3066\u308B\u3093\u3060\u308D\u3046\u2026\u4FFA\u2026",
  "id" : 229606391323713536,
  "created_at" : "2012-07-29 15:56:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229606250508341249",
  "text" : "\uFF11\uFF0E\u8AB0\u304B\u304C\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u3092\u98F2\u3080\u969B\u306B\u306F\u300C\u30ED\u30C3\u30AF\u30B9\n\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01\u300D\u3068\u3064\u3076\u3084\u304F\uFF0E\n\uFF12\uFF0E\u6B21\u306B\u305D\u306E\u3064\u3076\u3084\u304D\u3092\u898B\u305F\u4EBA\u306F\u305D\u306E\u4EBA\u306B\u30EA\u30D7\u30E9\u30A4\uFF08\u8FD4\u4FE1\uFF09\u3067\u300C\u30CA\u30A4\u30B9\n\u30ED\u30C3\u30AF\uFF01\u300D\u3068\u9001\u308B\uFF0E\n\uFF13\uFF0E\u6700\u521D\u306B\u98F2\u3093\u3060\u4EBA\u304C\u30EA\u30D7\u30E9\u30A4\u3092\u98DB\u3070\u3057\u3066\u304D\u305F\u4EBA\u305F\u3061\u306B\u300C\u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\n\u30ED\u30C3\u30AF\uFF01\u300D\u3068\u8FD4\u4E8B\u3092\u3059\u308B\uFF0E",
  "id" : 229606250508341249,
  "created_at" : "2012-07-29 15:56:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229542192908226562",
  "geo" : { },
  "id_str" : "229570332762177536",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u4E00\u9650\u8A66\u9A13\u3060\u304B\u3089\u7D42\u308F\u3063\u305F\u3089\u884C\u304F",
  "id" : 229570332762177536,
  "in_reply_to_status_id" : 229542192908226562,
  "created_at" : "2012-07-29 13:33:27 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229562132956577792",
  "geo" : { },
  "id_str" : "229570274775941121",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3084\u3063\u3071\u308A\u2026",
  "id" : 229570274775941121,
  "in_reply_to_status_id" : 229562132956577792,
  "created_at" : "2012-07-29 13:33:13 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229546933633576963",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 229546933633576963,
  "created_at" : "2012-07-29 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229534192789241856",
  "text" : "\u3068\u8A00\u3046\u304B\u3001\u30EC\u30DD\u30FC\u30C8\u306E\u53C2\u8003\u8CC7\u6599\u306B\u30C8\u30A5\u30B2\u30C3\u30BF\u30FC\u306Eurl\u66F8\u304F\u3057\u304B\u306A\u3044\u3051\u3069\u826F\u3044\u306E\u304B\u306A\u3053\u308C",
  "id" : 229534192789241856,
  "created_at" : "2012-07-29 11:09:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229526155588403200",
  "geo" : { },
  "id_str" : "229529301924605952",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u300C\u4E21\u66FF\u3067\u304D\u306A\u3044\u3093\u3067\u6B21\u56DE\u6255\u3063\u3066\u304F\u3060\u3055\u3044\u306D\uFF08\u4E0D\u6A5F\u5ACC\u305D\u3046\u306B\uFF09\u300D\u3067\u4E0B\u3055\u308C\u308B\uFF0C\uFF08\u5C11\u306A\u304F\u3068\u3082\u81EA\u5206\u306E\u6642\u306F\uFF09\u30D1\u30BF\u30FC\u30F3\u3067\u3059\u306D\uFF0E",
  "id" : 229529301924605952,
  "in_reply_to_status_id" : 229526155588403200,
  "created_at" : "2012-07-29 10:50:24 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229523563873452032",
  "text" : "KU\u30AF\u30E9\u30B9\u30BF\uFF0C\u30C4\u30A4\u30C3\u30BF\u30FC\u3068\u8A00\u3048\u3070\uFF0C\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3068\u307B\u304B\u306B\u4F55\u306E\u8A71\u3059\u308C\u3070\u3044\u3044\u3093\u3067\u3059\u304B\u306D",
  "id" : 229523563873452032,
  "created_at" : "2012-07-29 10:27:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229522789525245952",
  "text" : "\u304C\uFF0C\u3058\u3083\u306A\u304F\u3066\uFF0C\u3084\uFF0C\u3067\u3059\u306D",
  "id" : 229522789525245952,
  "created_at" : "2012-07-29 10:24:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229522698223632384",
  "text" : "\u304A\u6C17\u306B\u5165\u308A\uFF08\u4EE5\u4E0B\u3075\u3041\u307C\u3068\u3059\u308B\uFF09\u304C\u30EA\u30C4\u30A4\u30FC\u30C8\uFF08\u4EE5\u4E0BRT\u3068\u3059\u308B\uFF09 \u30EC\u30DD\u30FC\u30C8\u306E\u4E00\u90E8\u304C\u3053\u308C\u3067\u3042\u308B",
  "id" : 229522698223632384,
  "created_at" : "2012-07-29 10:24:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3080\u308ABABEL",
      "screen_name" : "CKPOMHOCTb",
      "indices" : [ 0, 11 ],
      "id_str" : "190136474",
      "id" : 190136474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229519641620410368",
  "geo" : { },
  "id_str" : "229519749862789120",
  "in_reply_to_user_id" : 190136474,
  "text" : "@CKPOMHOCTb \u89E3\u308A\u306B\u304F\u8868\u73FE\u3067\u3057\u305F\u306D\u30FC\u52E2\u3044\u3067\u66F8\u304F\u3068\u826F\u304F\u306A\u3044\u3067\u3059\uFF0E\u3067\u3082\u30EC\u30DD\u30FC\u30C8\u306F\u52E2\u3044\u3067\u66F8\u304D\u307E\u3059\uFF0E",
  "id" : 229519749862789120,
  "in_reply_to_status_id" : 229519641620410368,
  "created_at" : "2012-07-29 10:12:27 +0000",
  "in_reply_to_screen_name" : "CKPOMHOCTb",
  "in_reply_to_user_id_str" : "190136474",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229519386183098368",
  "text" : "\u96C6\u5408\u4F4D\u76F8\u306E\u52C9\u5F37\u3082\u3057\u305F\u30D5\u30EA\u3057\u306A\u304D\u3083\u304B\uFF0E",
  "id" : 229519386183098368,
  "created_at" : "2012-07-29 10:11:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229519323964788737",
  "text" : "\u307E\u3041\u9811\u5F35\u3063\u3066\u66F8\u3044\u3066\u307F\u308B\u304B\uFF0E\u4ECA\u65E5\u306E\u76EE\u6A19\u306F\u3042\u3068\u4E8C\u3064\u306E\u30EC\u30DD\u30FC\u30C8\u3042\u3052\u308B\u3053\u3068\uFF0E",
  "id" : 229519323964788737,
  "created_at" : "2012-07-29 10:10:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229518900948267008",
  "text" : "\u521D\u97F3\u30DF\u30AF\u3084\u3089MMD\u3042\u305F\u308A\u3067\u3082\u66F8\u304D\u3084\u3059\u3044\u3060\u308D\u3046\u306A\u30FC\u81EA\u5206\u306F\u7D20\u990A\u304C\u306A\u3044\u304C\uFF0E",
  "id" : 229518900948267008,
  "created_at" : "2012-07-29 10:09:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229518781087637505",
  "text" : "@setsuna3021181 \u5727\u5012\u7684\u66F8\u304D\u3084\u3059\u3055\uFF0E\u666E\u901A\u306B\u30CB\u30B3\u52D5\uFF0C\u6771\u65B9\u306A\u3093\u304B\u3067\u66F8\u3044\u3066\u3044\u308B\u4EBA\u904E\u53BB\u306B\u3044\u305F\u3063\u307D\u3044\u3057\u5168\u7136\u3044\u3051\u307E\u3059\u306D\uFF0E",
  "id" : 229518781087637505,
  "created_at" : "2012-07-29 10:08:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229518401045942272",
  "text" : "\u3053\u308C\u304B\u3044\u305F\u3089\u7279\u5B9A\u3055\u308C\u3046\u308B\u3058\u3083\u3093\u6559\u6388\u306B\uFF0E\u6D88\u3057\u3066\u304A\u304F\u304B\u30FC\uFF0E",
  "id" : 229518401045942272,
  "created_at" : "2012-07-29 10:07:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3080\u308ABABEL",
      "screen_name" : "CKPOMHOCTb",
      "indices" : [ 0, 11 ],
      "id_str" : "190136474",
      "id" : 190136474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229513995718111232",
  "geo" : { },
  "id_str" : "229518169956573184",
  "in_reply_to_user_id" : 190136474,
  "text" : "@CKPOMHOCTb \u3042\uFF0C\u305D\u3046\u3058\u3083\u306A\u304F\u3066\u4E8C\u756A\u76EE\u306B\u7DE0\u3081\u5207\u308A\u306B\u8FD1\u3044\u30EC\u30DD\u30FC\u30C8\u5148\u306B\u3084\u3063\u3061\u3083\u3063\u305F\u3063\u3066\u8A71\u3067\u3059\uFF57",
  "id" : 229518169956573184,
  "in_reply_to_status_id" : 229513995718111232,
  "created_at" : "2012-07-29 10:06:10 +0000",
  "in_reply_to_screen_name" : "CKPOMHOCTb",
  "in_reply_to_user_id_str" : "190136474",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229513720970244096",
  "text" : "\u4E00\u756A\u7DE0\u3081\u5207\u308A\u8FD1\u3044\u30EC\u30DD\u30FC\u30C8\u4ED5\u4E0A\u3052\u305F\u3089\u4E8C\u756A\u76EE\u3060\u3063\u305F\u6642\u306E\u9854\u3057\u3066\u308B",
  "id" : 229513720970244096,
  "created_at" : "2012-07-29 09:48:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229420843992743936",
  "text" : "\u3053\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u80A9\u3053\u308A\u982D\u75DB\u306E\u30B3\u30F3\u30DC\u2026",
  "id" : 229420843992743936,
  "created_at" : "2012-07-29 03:39:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229416296410931201",
  "text" : "#nowplaying Gonna Getta Way ! - SWING HOLIC",
  "id" : 229416296410931201,
  "created_at" : "2012-07-29 03:21:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u771F\u663C\u306E\u6383\u9664",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229414203872665600",
  "text" : "\u90E8\u5C4B\u6383\u9664\u3059\u308B\u304B #\u771F\u663C\u306E\u6383\u9664",
  "id" : 229414203872665600,
  "created_at" : "2012-07-29 03:13:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229241737913180160",
  "text" : "\u3050\u308B\u3050\u308B",
  "id" : 229241737913180160,
  "created_at" : "2012-07-28 15:47:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229226316401102851",
  "text" : "\u3072\u3083\u304F\u307E\u3093\u3079\u3093\u3067\u3042\u305F\u307E\u306E\u308F\u308B\u3044\u304C\u304F\u305B\u3044\u304C\u3088\u3063\u3066\u3055\u308F\u3044\u3067\u3044\u308B\u3088",
  "id" : 229226316401102851,
  "created_at" : "2012-07-28 14:46:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229223779044306944",
  "text" : "\u3053\u3068\u308A\u3093\u2026",
  "id" : 229223779044306944,
  "created_at" : "2012-07-28 14:36:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229223265577607168",
  "text" : "\u3086\u308B\u307C \u3053\u306E\u6642\u9593\u3042\u3044\u3066\u308B\u30E9\u30FC\u30E1\u30F3",
  "id" : 229223265577607168,
  "created_at" : "2012-07-28 14:34:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229184535106056192",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 229184535106056192,
  "created_at" : "2012-07-28 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229064840348581890",
  "text" : "\u4E45\u3005\u306B\u30CA\u30DD\u30EA\u30BF\u30F3\u98DF\u3079\u305F\u3089\u7F8E\u5473\u3057\u304B\u3063\u305F",
  "id" : 229064840348581890,
  "created_at" : "2012-07-28 04:04:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228781544658051073",
  "geo" : { },
  "id_str" : "228782071773011968",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ 7\u6642\u306B\u305D\u3053\u3067\uFF01",
  "id" : 228782071773011968,
  "in_reply_to_status_id" : 228781544658051073,
  "created_at" : "2012-07-27 09:21:11 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228781249517465600",
  "geo" : { },
  "id_str" : "228781415561564162",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3048\u30FC\u3068\u6771\u5927\u8DEF\u306E\u6D88\u9632\u7F72\u308F\u304B\u308B\uFF1F",
  "id" : 228781415561564162,
  "in_reply_to_status_id" : 228781249517465600,
  "created_at" : "2012-07-27 09:18:34 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228780974866038785",
  "geo" : { },
  "id_str" : "228781116486717440",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u6771\u5927\u8DEF\u306E\u3058\u3083\u3093\u3068\u3074\u3042\u3054\u5B58\u77E5\uFF1F",
  "id" : 228781116486717440,
  "in_reply_to_status_id" : 228780974866038785,
  "created_at" : "2012-07-27 09:17:23 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228780671714340864",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u5915\u65B9\u3072\u307E\u306A\u3044\uFF1F\u4E00\u6B20\u3051\u306E\u9EBB\u96C0\u3042\u308B\u306E\u3067\u3059\u304C\u30FC",
  "id" : 228780671714340864,
  "created_at" : "2012-07-27 09:15:37 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228715536874340353",
  "geo" : { },
  "id_str" : "228724837332418561",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u65AD\u9762\u3068\u8003\u3048\u4E09\u6B21\u5143\u306B\u62E1\u5F35\u3059\u308B\u306E\u306F\u541B\u3060\uFF01\uFF01\uFF01",
  "id" : 228724837332418561,
  "in_reply_to_status_id" : 228715536874340353,
  "created_at" : "2012-07-27 05:33:45 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228724384179814401",
  "geo" : { },
  "id_str" : "228724732814573568",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3075\u305F\u3078\u3084\uFF1F",
  "id" : 228724732814573568,
  "in_reply_to_status_id" : 228724384179814401,
  "created_at" : "2012-07-27 05:33:20 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228720039044464640",
  "text" : "@setsuna3021181 \u9C3B\u3092\u4E09\u679A\u306B\u4E0B\u308D\u3059\u306E\u3063\u3066\u7D50\u69CB\u5927\u5909\u306A\u3093\u3067\u3059\u3088\u306D\u3002\u982D\u306B\u91D8\u3092\u6253\u3061\u4ED8\u3051\u308B\u306E\u3067\u3059\u3002",
  "id" : 228720039044464640,
  "created_at" : "2012-07-27 05:14:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228711558597971969",
  "text" : "\u5317\u90E8\u3067\u3054\u98EF\u98DF\u3079\u308B\u304B",
  "id" : 228711558597971969,
  "created_at" : "2012-07-27 04:40:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228711178610802688",
  "geo" : { },
  "id_str" : "228711244268445700",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u304A\u3064\u304B\u308C\u3055\u307E\u3042\u3042\u3042\u3042\u3042\u3042\u3042\uFF01\uFF01",
  "id" : 228711244268445700,
  "in_reply_to_status_id" : 228711178610802688,
  "created_at" : "2012-07-27 04:39:44 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228711141533155328",
  "text" : "\u3046\u306A\u304E\u9AD8\u3044\u306A\u3089\u3046\u3064\u307C\u306E\u84B2\u713C\u306B\u3059\u308C\u3070\u3044\u3044\u3093\u3058\u3083",
  "id" : 228711141533155328,
  "created_at" : "2012-07-27 04:39:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228708899807707136",
  "geo" : { },
  "id_str" : "228709303081652224",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5225\u306B\u304B\u307E\u308F\u306A\u3044\u305C\u30FC\u3067\u3082\u898F\u6A21\u3068\u5834\u6240\u3060\u3051\u5927\u4F53\u3067\u3044\u3044\u3057\u6559\u3048\u3066\u30FC",
  "id" : 228709303081652224,
  "in_reply_to_status_id" : 228708899807707136,
  "created_at" : "2012-07-27 04:32:01 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 30 ],
      "url" : "https:\/\/t.co\/3ovXadcQ",
      "expanded_url" : "https:\/\/twitter.com\/xe_no\/status\/163534795178123264",
      "display_url" : "twitter.com\/xe_no\/status\/1\u2026"
    }, {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/WHdxF7QK",
      "expanded_url" : "http:\/\/attrip.jp\/35323",
      "display_url" : "attrip.jp\/35323"
    } ]
  },
  "in_reply_to_status_id_str" : "228706341085118464",
  "geo" : { },
  "id_str" : "228708929977335809",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax https:\/\/t.co\/3ovXadcQ http:\/\/t.co\/WHdxF7QK \u3053\u306E\u8FBA\u898B\u3066\u307F\u308C\u3070\u3088\u3044\u304B\u3068\u3002",
  "id" : 228708929977335809,
  "in_reply_to_status_id" : 228706341085118464,
  "created_at" : "2012-07-27 04:30:32 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228703543706652675",
  "geo" : { },
  "id_str" : "228707918625796096",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3044\u3044\u306D\u30FC\u884C\u304D\u305F\u3044\u3068\u601D\u3063\u3066\u3044\u305F\u3068\u3053\u308D\u3060\u305C",
  "id" : 228707918625796096,
  "in_reply_to_status_id" : 228703543706652675,
  "created_at" : "2012-07-27 04:26:31 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228697933971853312",
  "geo" : { },
  "id_str" : "228703600786935810",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u3042\u3068\u3067\u8ABF\u3079\u3066\u30EA\u30D7\u30E9\u30A4\u3067\u9001\u308A\u307E\u3059",
  "id" : 228703600786935810,
  "in_reply_to_status_id" : 228697933971853312,
  "created_at" : "2012-07-27 04:09:22 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228703199715000320",
  "geo" : { },
  "id_str" : "228703460592332800",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30EC\u30DD\u30FC\u30C8\u7D42\u308F\u3063\u3066\u3055\u3048\u3044\u308C\u3070",
  "id" : 228703460592332800,
  "in_reply_to_status_id" : 228703199715000320,
  "created_at" : "2012-07-27 04:08:48 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228696157923196929",
  "geo" : { },
  "id_str" : "228700276478074880",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u53CB\u4EBA\u306E\u30EC\u30DD\u30FC\u30C8\u8ACB\u3051\u8CA0\u3063\u3066\u308B\u306E\u3067\u3042\u307E\u308A\u9AD8\u5EA6\u306B\u3057\u305F\u3089\u307E\u305A\u3044(^^)(^^)(^^)\u3067\u3082\u3042\u308A\u304C\u3068\u3046(^^)(^^)(^^)",
  "id" : 228700276478074880,
  "in_reply_to_status_id" : 228696157923196929,
  "created_at" : "2012-07-27 03:56:09 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228679367969099776",
  "geo" : { },
  "id_str" : "228691042214486016",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3055\u3093\u304D\u3085\u30FC",
  "id" : 228691042214486016,
  "in_reply_to_status_id" : 228679367969099776,
  "created_at" : "2012-07-27 03:19:27 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228676011317927937",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30E9\u30F3\u30B0\u30EC\u30FC\u306E\u4F8B\u306E\u554F\u984C\u306B\u3064\u3044\u3066\u66F8\u3044\u3066\u3042\u308B\u672C\u306A\u3093\u304B\u3042\u308A\u307E\u3059\u304B\u306D\u30FC\uFF1F",
  "id" : 228676011317927937,
  "created_at" : "2012-07-27 02:19:44 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 39, 54 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228672414651920384",
  "text" : ". @ispamgis @setsuna3021181 @coxff2006 @G4_Hirano_chan \u304A\u306F\u3042\u308A\u3067\u3057\u3066\uFF0E",
  "id" : 228672414651920384,
  "created_at" : "2012-07-27 02:05:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228668415521484800",
  "text" : "\u3042\u3001\u7121\u5730\u3067\u3059\u3002",
  "id" : 228668415521484800,
  "created_at" : "2012-07-27 01:49:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228668318863732736",
  "text" : "\u3053\u306E\u6642\u671F\u306F\u62B1\u304D\u6795\u304C\u6691\u82E6\u3057\u3044",
  "id" : 228668318863732736,
  "created_at" : "2012-07-27 01:49:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228667536835756032",
  "text" : "@setsuna3021181 \u3067\u3059\u3088\u306D\u3047",
  "id" : 228667536835756032,
  "created_at" : "2012-07-27 01:46:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228667340924018689",
  "text" : "\u4ECA\u306E\u306F\u30D5\u30EA\u3060\u3063\u305F",
  "id" : 228667340924018689,
  "created_at" : "2012-07-27 01:45:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228666866418212864",
  "geo" : { },
  "id_str" : "228667035587051520",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u304A\u3001\u304A\u3084\u3059\u307F\u3067\u3057\u305F\uFF01",
  "id" : 228667035587051520,
  "in_reply_to_status_id" : 228666866418212864,
  "created_at" : "2012-07-27 01:44:04 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228492461536845824",
  "geo" : { },
  "id_str" : "228666791814119424",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u4E80\u30EA\u30D7\u3067\u3059\u304C\u30D5\u30A9\u30ED\u30EF\u30FC\u306B\u4F5C\u3063\u305F\u4EBA\u304C\u3044\u307E\u3057\u305F\u3088\u3002\u3061\u3087\u3063\u3068\u307E\u3048\u306B\u3002",
  "id" : 228666791814119424,
  "in_reply_to_status_id" : 228492461536845824,
  "created_at" : "2012-07-27 01:43:06 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228666029230940160",
  "text" : "\u8D77\u304D\u305F",
  "id" : 228666029230940160,
  "created_at" : "2012-07-27 01:40:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228509343774040064",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u8AAD\u3093\u3067\u308B\u4EBA\u3044\u306A\u3044\u3093\u3067\u3059\u304B\u306D(\uFF81\uFF97\uFF6F\uFF81\uFF97\uFF6F",
  "id" : 228509343774040064,
  "created_at" : "2012-07-26 15:17:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228509232473968640",
  "text" : "\u300C\u307E\u3058\u3081\u306A\u6642\u9593\u300D\u306B\u3064\u3044\u3066\u8A71\u305B\u308B\u4EBA\u304C\u5468\u308A\u306B\u5C45\u306A\u304F\u3066\u8F9B\u3044\uFF0E",
  "id" : 228509232473968640,
  "created_at" : "2012-07-26 15:17:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228509047677153282",
  "text" : "\u306A\u3093\u304B\u5FD9\u3057\u3044\u3051\u308C\u3069\u512A\u5148\u9806\u4F4D\u304C\u5358\u4F4D\u306B\u306A\u3044\u305E\uFF08\u3044\u3064\u3082\u306E\u3053\u3068\uFF09",
  "id" : 228509047677153282,
  "created_at" : "2012-07-26 15:16:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228459736113229824",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 228459736113229824,
  "created_at" : "2012-07-26 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sm6362977",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/CgewM6yO",
      "expanded_url" : "http:\/\/nico.ms\/sm6362977",
      "display_url" : "nico.ms\/sm6362977"
    } ]
  },
  "geo" : { },
  "id_str" : "228441547539111936",
  "text" : "\u3053\u308C\u3092BGM\u306B\u30EC\u30DD\u30FC\u30C8\u3084\u308B\uFF01\u30D6\u30E9\u30B9\u30C8\u30C9\u30FC\u30B6\u30FC BGM\u96C6 (62:53) #sm6362977 http:\/\/t.co\/CgewM6yO",
  "id" : 228441547539111936,
  "created_at" : "2012-07-26 10:48:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/hrYtddDp",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/161?prefill=tane_yoshi",
      "display_url" : "gohantabeyo.com\/nani\/161?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228438540906803201",
  "text" : "\u5510\u63DA\u3052\u30D1\u30FC\u30C6\u30A3\u30FC\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/hrYtddDp",
  "id" : 228438540906803201,
  "created_at" : "2012-07-26 10:36:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228348357318410240",
  "text" : "\u81D3\u5668\u6797\u3063\u3066\u8A00\u3046\u3068\u731F\u5947\u7684\u3063\u307D\u3044\u306A",
  "id" : 228348357318410240,
  "created_at" : "2012-07-26 04:37:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228326133526040577",
  "text" : "\u3093\u30FC\u3001\u3053\u306E\u307E\u307E\u3067\u3082\u826F\u3044\u306E\u3060\u304C\u3082\u3046\u3061\u3087\u3063\u3068\u826F\u304F\u306A\u308B\u6C17\u304C\u3057\u3066\u306A\u3089\u306A\u3044",
  "id" : 228326133526040577,
  "created_at" : "2012-07-26 03:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228323866911571970",
  "text" : "\u7269\u7406\u5B66\u5F92\u305F\u3061\u306F\u3069\u3046\u3057\u3066\u3044\u308B\u3093\u3060\u308D\u3046\uFF0E|a&gt;\u306E\u8868\u8A18\u2026",
  "id" : 228323866911571970,
  "created_at" : "2012-07-26 03:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228321773907746816",
  "text" : "tex\u3067|a&gt;\u306E\u5F62\u306E\u30D9\u30AF\u30C8\u30EB\u8868\u8A18\u3092\u7DBA\u9E97\u306B\u51FA\u3059\u65B9\u6CD5\u77E5\u3063\u3066\u308B\u4EBA\u5C45\u305F\u3089\u6559\u3048\u3066\u6B32\u3057\u3044\u306E\u3067\u3059\u304C\u30FC",
  "id" : 228321773907746816,
  "created_at" : "2012-07-26 02:52:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228283373733425152",
  "text" : "\u7D50\u5C409\u6642\u3059\u304E\u306B\u7740\u3044\u305F\u304B\u3089\u3042\u308C",
  "id" : 228283373733425152,
  "created_at" : "2012-07-26 00:19:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228271249879597056",
  "text" : "\u3042\u3001\u9045\u523B\u307D\u3044\u306A\u3053\u308C",
  "id" : 228271249879597056,
  "created_at" : "2012-07-25 23:31:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u306C\u305F\u306C\uFF1E\u03C9\uFF1C",
      "screen_name" : "FireRacoon",
      "indices" : [ 0, 11 ],
      "id_str" : "225002271",
      "id" : 225002271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228270193049210881",
  "geo" : { },
  "id_str" : "228270253895995393",
  "in_reply_to_user_id" : 225002271,
  "text" : "@FireRacoon \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 228270253895995393,
  "in_reply_to_status_id" : 228270193049210881,
  "created_at" : "2012-07-25 23:27:24 +0000",
  "in_reply_to_screen_name" : "FireRacoon",
  "in_reply_to_user_id_str" : "225002271",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228270122459090946",
  "text" : "\u3060\u3044\u305F\u30448\u6642\u306B\u76EE\u899A\u307E\u3057\u306F\u9045\u3044",
  "id" : 228270122459090946,
  "created_at" : "2012-07-25 23:26:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228270045174853632",
  "text" : "\u3042\u30685\u5206\u3067\u51FA\u306A\u3044\u3068\u307E\u305A\u3044\u3068\u304B\u5618\u3060",
  "id" : 228270045174853632,
  "created_at" : "2012-07-25 23:26:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228136967647408128",
  "text" : "\u307E\u305F\u306D",
  "id" : 228136967647408128,
  "created_at" : "2012-07-25 14:37:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228135940965683200",
  "text" : "\u8FD1\u3044\u3046\u3061\u30A8\u30EC\u30AD\u30C6\u5CF6\u8F09\u308B\u3089\u3057\u3044\u3051\u308C\u3069\u5168\u7136\u4FE1\u7528\u3057\u3066\u306A\u3044\uFF0E",
  "id" : 228135940965683200,
  "created_at" : "2012-07-25 14:33:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228135599259910146",
  "text" : "\u30B2\u30FC\u30B8\u5834\u306E\u3086\u7406\u8AD6\u3063\u3066...",
  "id" : 228135599259910146,
  "created_at" : "2012-07-25 14:32:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228135080135102464",
  "text" : "\u3061\u308A\u3068\u3066\u3061\u3093\u3063\u3066\u3059\u3054\u3044\u97FF\u304D\u304C\u3044\u3044\u3051\u308C\u3069\u65E5\u5E38\u4F1A\u8A71\u3067\u5727\u5012\u7684\u306B\u4F7F\u3046\u6A5F\u4F1A\u304C\u306A\u3044\uFF0E",
  "id" : 228135080135102464,
  "created_at" : "2012-07-25 14:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228134784407326720",
  "text" : "\u3061\u308A\u3068\u3066\u3061\u3093\u7684\u8A00\u8449\u904A\u3073",
  "id" : 228134784407326720,
  "created_at" : "2012-07-25 14:29:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228134601179164672",
  "text" : "\u3053\u308C\u81EA\u5206\u304C\u3061\u3083\u3093\u3068\u30C6 \u30F3\u30BD\u30EB\u7406\u89E3\u3057\u306A\u3044\u3067\u3084\u3063\u3066\u308B\u304B\u3089\u975E\u5E38\u306B\u3088\u304F\u306A\u3044\uFF0E",
  "id" : 228134601179164672,
  "created_at" : "2012-07-25 14:28:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228134096562434049",
  "text" : "\u30C6\u30F3\u30BD\u30EB\u54B3\u306F\u6614\u306F\u6B7B\u306B\u81F3\u308B\u75C5\u3060\u3063\u305F\uFF0E",
  "id" : 228134096562434049,
  "created_at" : "2012-07-25 14:26:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228133958116847616",
  "text" : "\u30C6\u30F3\u30BD\u30EB\u5E2D\u3092\u3054\u5E0C\u671B\u306E\u304A\u5BA2\u69D8\u306F\u30B9\u30BF\u30C3\u30D5\u307E\u3067\u304A\u58F0\u304B\u3051\u304F\u3060\u3055\u3044\uFF0E",
  "id" : 228133958116847616,
  "created_at" : "2012-07-25 14:25:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D5\u30E9\u30B0\u3058\u3083\u306A\u3044\u3063\u3066\u3070",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228133595338903552",
  "text" : "\u5BDD\u3063\u3053\u308D\u304C\u3063\u3066\u4F5C\u696D\u3059\u308B\u304B\u30FC\uFF08\u30D5\u30E9\u30B0\u3058\u3083\u306A\u3044 #\u30D5\u30E9\u30B0\u3058\u3083\u306A\u3044\u3063\u3066\u3070",
  "id" : 228133595338903552,
  "created_at" : "2012-07-25 14:24:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228133154794377216",
  "text" : "\u8A00\u8449\u306E\u5370\u8C61\u3060\u3051\u3067\u9593\u9055\u3063\u305F\u3053\u3068\u3092\u8A00\u3046\u306E\u3063\u3066\u697D\u3057\u3044",
  "id" : 228133154794377216,
  "created_at" : "2012-07-25 14:22:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228132851265200129",
  "text" : "\u30C6\u30F3\u30BD\u30EB\u3063\u3066\u4E0A\u54C1\u306A\u30D1\u30F3\u5C4B\u3055\u3093\u3068\u304B\u306B\u58F2\u3063\u3066\u305D\u3046\u3060\u3088\u306D\uFF0E\u30DE\u30ED\u30F3\u30C6\u30F3\u30BD\u30EB\u3068\u304B\uFF0C\u30AF\u30E9\u30F3\u30D9\u30EA\u30FC\u30C6\u30F3\u30BD\u30EB\u3068\u304B\uFF0E",
  "id" : 228132851265200129,
  "created_at" : "2012-07-25 14:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228132443893424128",
  "text" : "\u6559\u6388\u304C\u8EFD\u304F\u8AAC\u660E\u3057\u3066\u304F\u308C\u305F\u3051\u308C\u3069\u7D50\u5C40\u826F\u304F\u89E3\u3063\u3066\u7121",
  "id" : 228132443893424128,
  "created_at" : "2012-07-25 14:19:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228132267900407808",
  "text" : "\u7269\u7406\u306E\u4EBA\u306F\u5883\u754C\u6761\u4EF6\uFF0C\u6570\u5B66\u306E\u4EBA\u306F\u521D\u671F\u6761\u4EF6\u3063\u3066\u8A00\u3063\u3066\u308B\u5370\u8C61\u3060\u3063\u305F\u3093\u3060\u304C\uFF0E",
  "id" : 228132267900407808,
  "created_at" : "2012-07-25 14:19:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228132150371811328",
  "text" : "\u3048\u3063\uFF0C\u5883\u754C\u6761\u4EF6\u3068\u521D\u671F\u6761\u4EF6\u3063\u3066\u79D1\u5B66\u54F2\u5B66\u7684\u306A\u6587\u8108\u3060\u3068\u9055\u3046\u3082\u306E...\uFF4D\uFF4A\uFF44...",
  "id" : 228132150371811328,
  "created_at" : "2012-07-25 14:18:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228130924557127681",
  "text" : "\u3048\u3093\u3069\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0",
  "id" : 228130924557127681,
  "created_at" : "2012-07-25 14:13:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 3, 9 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30A8\u30F3\u30C9\u30E2\u30EB\u30D5\u30A3\u30C9\u30A5\u30FC\u30E0",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228130810522390528",
  "text" : "RT @alg_d: #\u30A8\u30F3\u30C9\u30E2\u30EB\u30D5\u30A3\u30C9\u30A5\u30FC\u30E0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u30A8\u30F3\u30C9\u30E2\u30EB\u30D5\u30A3\u30C9\u30A5\u30FC\u30E0",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228130488450170880",
    "text" : "#\u30A8\u30F3\u30C9\u30E2\u30EB\u30D5\u30A3\u30C9\u30A5\u30FC\u30E0",
    "id" : 228130488450170880,
    "created_at" : "2012-07-25 14:12:01 +0000",
    "user" : {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "protected" : false,
      "id_str" : "127940910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579632693668773888\/0Susg2n0_normal.jpg",
      "id" : 127940910,
      "verified" : false
    }
  },
  "id" : 228130810522390528,
  "created_at" : "2012-07-25 14:13:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228130416563982339",
  "text" : "\u72D0\u3055\u3093\u3082\u5F15\u304D\u7D9A\u304D\u5727\u5012\u7684\u3060\u3063\u305F\uFF0E\u4EBA\u985E\u6700\u60AA\uFF0E",
  "id" : 228130416563982339,
  "created_at" : "2012-07-25 14:11:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228130324230578176",
  "text" : "\u4EBA\u8B58\u306E\u300C\u306A\u3041\u2026\u6B20\u9665\u88FD\u54C1\u2026\u300D\u3063\u3066\u304B\u3063\u3053\u3044\u3044\uFF01\u5727\u5012\u7684\uFF01",
  "id" : 228130324230578176,
  "created_at" : "2012-07-25 14:11:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228130027722665984",
  "text" : "\u4EBA\u9593\u8A66\u9A13\u3082\u3044\u3044\u611F\u3058\u3060\u3063\u305F\u3051\u308C\u3069\uFF0C\u307E\u3058\u3081\u306A\u6642\u9593\u304C\u9CE5\u808C\u3060\u3063\u305F\uFF0E\u6765\u6708\u6700\u7D42\u8A71\uFF0E",
  "id" : 228130027722665984,
  "created_at" : "2012-07-25 14:10:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228129891198066688",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u8AAD\u307F\u7D42\u3048\u305F\uFF0E",
  "id" : 228129891198066688,
  "created_at" : "2012-07-25 14:09:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227924534278377472",
  "text" : "\u3053\u306E\u6691\u3044\u306E\u306B\u304A\u8336\u6F2C\u3051\u3064\u304F\u308B\u3088",
  "id" : 227924534278377472,
  "created_at" : "2012-07-25 00:33:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227924487578976260",
  "text" : "\u4E00\u9650\u884C\u3063\u305F\u3089\u4F55\u304B\u66F8\u3051\u3063\u3066\u8A00\u308F\u308C\u305F\u304B\u3089\u4F55\u304B\u66F8\u3044\u3066\u5E30\u3063\u3066\u304D\u305F",
  "id" : 227924487578976260,
  "created_at" : "2012-07-25 00:33:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227902734471405569",
  "text" : "\u6691\u3044\uFF01\u8D77\u304D\u305F\uFF01",
  "id" : 227902734471405569,
  "created_at" : "2012-07-24 23:07:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227786626837909504",
  "text" : "\u4ECA\u65E5\u306E\u4E00\u9650\u3067todo\u30EA\u30B9\u30C8\u4F5C\u308B\u304B\u30FC",
  "id" : 227786626837909504,
  "created_at" : "2012-07-24 15:25:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227734975150186496",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 227734975150186496,
  "created_at" : "2012-07-24 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227712179594473472",
  "text" : "\u30E1\u30AC\u30CD\u306E\u306F\u306A\u3042\u3066\u76F4\u3057\u305F\u3002\u4EAC\u90FD\u30D0\u30EB\u306F\u307E\u305F\u4ECA\u5EA6\u3002",
  "id" : 227712179594473472,
  "created_at" : "2012-07-24 10:29:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227636789718966273",
  "geo" : { },
  "id_str" : "227637037187080192",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u30DA\u30D6\u30B7\u3092\u304A\u304B\u305A\u306B\u30B3\u30AB\u30B3\u30FC\u30E9\u2026\u3063\u3066\u306A\u3093\u3067\u3067\u3059\u304B\u301C",
  "id" : 227637037187080192,
  "in_reply_to_status_id" : 227636789718966273,
  "created_at" : "2012-07-24 05:31:13 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227636710975082496",
  "text" : "\u30B3\u30FC\u30E9\u3068\u304B\u30B5\u30A4\u30C0\u30FC\u306F\u5358\u9A0E\u306E\u30A4\u30E1\u30FC\u30B8\u304C\u5F37\u3044",
  "id" : 227636710975082496,
  "created_at" : "2012-07-24 05:29:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227636439565889536",
  "geo" : { },
  "id_str" : "227636624828268544",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u3044\u3064\u3082\u7591\u554F\u306A\u3093\u3060\u304C\u30B3\u30FC\u30E9\u3068\u304B\u30B5\u30A4\u30C0\u30FC\u306B\u5408\u3046\u304A\u304B\u3057\u3068\u306F",
  "id" : 227636624828268544,
  "in_reply_to_status_id" : 227636439565889536,
  "created_at" : "2012-07-24 05:29:35 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227635486590631936",
  "text" : "@i_horse \u306A\u306B\u305D\u308C\u3079\u3093\u308A",
  "id" : 227635486590631936,
  "created_at" : "2012-07-24 05:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227634991767625729",
  "text" : "\u3055\u3066\u3001\u7DCF\u4EBA\u68DF\u304B\u30894\u5171\u307E\u3067\u52D5\u304F\u306E\u304B\u30FC",
  "id" : 227634991767625729,
  "created_at" : "2012-07-24 05:23:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227634456331177984",
  "text" : "\u3042\u30FC\u3042\u30FC\u5098\u306A\u3044\u3002\u30EC\u30A4\u30F3\u30B3\u30FC\u30C8\u3082\u539F\u4ED8\u306E\u4E2D\u3060\u3002",
  "id" : 227634456331177984,
  "created_at" : "2012-07-24 05:20:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/yrz50IE6",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/kyoto.html",
      "display_url" : "sx9.jp\/weather\/kyoto.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "227633983431786496",
  "geo" : { },
  "id_str" : "227634149190676480",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 http:\/\/t.co\/yrz50IE6 \u76F4\u5F8C\u3060\u3051\u306A\u3089\u304B\u306A\u308A\u7684\u78BA\u306A\u306E\u3067\u3069\u3046\u305E",
  "id" : 227634149190676480,
  "in_reply_to_status_id" : 227633983431786496,
  "created_at" : "2012-07-24 05:19:45 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227633964318326784",
  "text" : "\u6D17\u6FEF\u7269\u3092\u90E8\u5C4B\u5E72\u3057\u3067\u304D\u308B\u30B9\u30DA\u30FC\u30B9\u304C\u306A\u3051\u308C\u3070\u3084\u3089\u308C\u3066\u3044\u305F\u306A\u2026",
  "id" : 227633964318326784,
  "created_at" : "2012-07-24 05:19:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/cwMX4x2S",
      "expanded_url" : "http:\/\/j.mp\/P7ILHu",
      "display_url" : "j.mp\/P7ILHu"
    } ]
  },
  "geo" : { },
  "id_str" : "227633262795841537",
  "text" : "\u306A\u3044\u3093\u305F\u3093\u4EAC\u90FD  http:\/\/t.co\/cwMX4x2S",
  "id" : 227633262795841537,
  "created_at" : "2012-07-24 05:16:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227632934516056064",
  "geo" : { },
  "id_str" : "227633115915505665",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u305C\u3063\u305F\u3044\u3084\u307E\u306A\u3044\u3067\u3059\u306D\u2026",
  "id" : 227633115915505665,
  "in_reply_to_status_id" : 227632934516056064,
  "created_at" : "2012-07-24 05:15:38 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227632665799565312",
  "text" : "\u306A\u3044\u3093\u305F\u3093\u306E\u30B0\u30E9\u30D5\u304C\u4E0D\u7A4F\u3068\u306F\u3053\u306E\u3053\u3068\u304B",
  "id" : 227632665799565312,
  "created_at" : "2012-07-24 05:13:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227632456977752064",
  "text" : "\u5730\u4E0B\u306E\u6559\u5BA4\u306A\u306E\u306B\u6FC0\u3057\u3044\u96E8\u97F3\u304C",
  "id" : 227632456977752064,
  "created_at" : "2012-07-24 05:13:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227617979045650433",
  "text" : "\u306E\u3069\u304B\u308F\u3044\u305F",
  "id" : 227617979045650433,
  "created_at" : "2012-07-24 04:15:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227617698597707779",
  "text" : "@setsuna3021181 \u307E\u3041\u3044\u305A\u308C\u3069\u3053\u304B\u3067\u3042\u3046\u3053\u3068\u3082\u3042\u308A\u307E\u3057\u3087\u3046",
  "id" : 227617698597707779,
  "created_at" : "2012-07-24 04:14:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227617059381575680",
  "text" : "@setsuna3021181 3\u3067\u3059.\u6700\u8FD1\u306F\u8A66\u9A13\u524D\u306A\u306E\u3067\u3042\u308C\u3067\u3059\u304C\u7406\u5B66\u90E8\u306E\u6388\u696D\u306F\u8997\u304D\u306B\u884C\u3063\u3066\u307E\u3059\u3088\u30FC\u3002",
  "id" : 227617059381575680,
  "created_at" : "2012-07-24 04:11:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227616569382019072",
  "text" : "@setsuna3021181 \u307E\u3041\u3084\u3084\u3053\u3057\u3044\u66F8\u304D\u65B9\u3057\u3066\u307E\u3059\u304C\u305D\u3046\u3044\u3046\u3053\u3068\u3067\u3059",
  "id" : 227616569382019072,
  "created_at" : "2012-07-24 04:09:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227615283198697472",
  "text" : "@setsuna3021181 \u307E\u305F\u4E00\u4EBA\u9A19\u3055\u308C\u307E\u3057\u305F\u306D\u3047\u3002bio\u3092\u3088\u304F\u898B\u307E\u3057\u3087\u3046\u3002",
  "id" : 227615283198697472,
  "created_at" : "2012-07-24 04:04:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227614728460058624",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 227614728460058624,
  "created_at" : "2012-07-24 04:02:34 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227614607269830658",
  "text" : "@setsuna3021181 \u306F\u3044",
  "id" : 227614607269830658,
  "created_at" : "2012-07-24 04:02:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227605963832713216",
  "text" : "\u30AF\u30ED\u30CD\u30C3\u30AB\u30FC\u306E\u30C7\u30EB\u30BF\u306E\u30EA\u30BA\u30E0\u3067",
  "id" : 227605963832713216,
  "created_at" : "2012-07-24 03:27:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227605905406062593",
  "text" : "\u3072\u308B\u306D\u3063\u304B\u30FC\u3089\u3055\u3081\u305F",
  "id" : 227605905406062593,
  "created_at" : "2012-07-24 03:27:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227605779232997376",
  "text" : "@setsuna3021181 \u897F\u6D0B\u53F2\u5B66",
  "id" : 227605779232997376,
  "created_at" : "2012-07-24 03:27:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227565860204724224",
  "text" : "\u3042\u308B\u3053\u3068\u306A\u3044\u3053\u3068\u66F8\u3044\u3066\u5E30\u3063\u3066\u304D\u305F",
  "id" : 227565860204724224,
  "created_at" : "2012-07-24 00:48:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227556948273397760",
  "text" : "\u4E00\u5FDC\u30CB\u30B3\u30CB\u30B3\u805E\u3044\u3066\u308B\u3051\u308C\u3069\u672C\u5F53\u306B\u805E\u3044\u3066\u308B\u3060\u3051\u3067\u3059",
  "id" : 227556948273397760,
  "created_at" : "2012-07-24 00:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227556703737110528",
  "text" : "\u91CE\u7403\u5168\u7136\u308F\u304B\u3089\u306A\u3044\u3057\u3001\u307E\u3041\u305D\u308C\u306F\u3042\u3093\u307E\u308A\u81EA\u6162\u3059\u308B\u3053\u3068\u3067\u3082\u306A\u3044\u3093\u3060\u3051\u3069\u3001\u305D\u3093\u306A\u50D5\u306B\u5BFE\u3057\u3066\u91CE\u7403\u306E\u8A71\u3092\u4E00\u65B9\u7684\u306B\u307E\u304F\u3057\u305F\u3066\u308B\u306E\u306F\u2026",
  "id" : 227556703737110528,
  "created_at" : "2012-07-24 00:12:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306E\u3063\u3061\uFF20\u95A2\u6771\u306E\u4EBA",
      "screen_name" : "Notchi_KT",
      "indices" : [ 0, 10 ],
      "id_str" : "121298858",
      "id" : 121298858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227556044774191104",
  "geo" : { },
  "id_str" : "227556187682508800",
  "in_reply_to_user_id" : 121298858,
  "text" : "@Notchi_KT \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 227556187682508800,
  "in_reply_to_status_id" : 227556044774191104,
  "created_at" : "2012-07-24 00:09:57 +0000",
  "in_reply_to_screen_name" : "Notchi_KT",
  "in_reply_to_user_id_str" : "121298858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227554499940720641",
  "text" : "\u3067\u3082\u7A7A\u304D\u3063\u8179\u306B\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3068\u304B\u52B9\u304F\u3051\u3069\u7D76\u5BFE\u304B\u3089\u3060\u306B\u60AA\u3044",
  "id" : 227554499940720641,
  "created_at" : "2012-07-24 00:03:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227554289114025984",
  "geo" : { },
  "id_str" : "227554397943635969",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 227554397943635969,
  "in_reply_to_status_id" : 227554289114025984,
  "created_at" : "2012-07-24 00:02:50 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227554274706599936",
  "text" : "\u3057\u304B\u3057\u4ECA\u65E5\u306F\u6765\u306A\u304B\u3063\u305F\u3089\u307E\u305A\u3044\u30BF\u30A4\u30D7\u306E\u65E5\u3060\u3063\u305F\u3093\u3060\u306A\u30FC",
  "id" : 227554274706599936,
  "created_at" : "2012-07-24 00:02:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227553204529922048",
  "text" : "\u307E\u3055\u306B\u3001\u60F3\u50CF\u4E3B\u3067\u3042\u308B",
  "id" : 227553204529922048,
  "created_at" : "2012-07-23 23:58:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227553121138790400",
  "text" : "\u7121(\u51FA\u3066\u306A\u3044\u8B1B\u7FA9)\u304B\u3089\u6709(\u611F\u60F3)\u3092\u5275\u308A\u51FA\u3059",
  "id" : 227553121138790400,
  "created_at" : "2012-07-23 23:57:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227552644506468352",
  "text" : "\u307E\u3041\u611F\u60F3\u306A\u3089\u3067\u3063\u3061\u4E0A\u3052\u3067\u8010\u3048\u308B\u306F\u305A(",
  "id" : 227552644506468352,
  "created_at" : "2012-07-23 23:55:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227552131278856192",
  "text" : "\u904B\u30B2\u30FC\u59CB\u307E\u3063\u305F\uFF01\uFF01\uFF01\uFF01",
  "id" : 227552131278856192,
  "created_at" : "2012-07-23 23:53:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227552013708308482",
  "text" : "\u4F5C\u6587\u3057\u3066\u3082\u3089\u3046\uFF1F\uFF01\uFF1F\uFF01\uFF1F\uFF01",
  "id" : 227552013708308482,
  "created_at" : "2012-07-23 23:53:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227551409619496960",
  "text" : "\u3057\u3001\u8A66\u9A13\u3060\u3063\u305F\u3089\u5148\u751F\u3053\u3093\u306A\u306B\u9045\u308C\u3066\u6765\u306A\u3044\u3088\u306D\uFF1F\uFF1F\uFF1F",
  "id" : 227551409619496960,
  "created_at" : "2012-07-23 23:50:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227550840410492928",
  "text" : "\u305D\u3082\u305D\u3082\u6559\u5BA4\u3069\u3053\u3060\u304B\u5931\u5FF5\u3057\u3066\u305F",
  "id" : 227550840410492928,
  "created_at" : "2012-07-23 23:48:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227550526571687938",
  "text" : "\u8A66\u9A13\u3058\u3083\u306A\u3044\u3068\u3044\u3044\u306A\u30FC\u8A66\u9A13\u3058\u3083\u306A\u3044\u3068\u3044\u3044\u306A\u30FC\u8A66\u9A13\u3060\u3068\u307E\u305A\u3044\u306A\u30FC(^^)(^^(^^)(^^)(^^))",
  "id" : 227550526571687938,
  "created_at" : "2012-07-23 23:47:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227550190180106241",
  "text" : "\u4ECA\u65E5\u8A66\u9A13\u3060\u3063\u305F\u3089\u6B7B\u306C\u306E\u306F\u8A00\u3046\u307E\u3067\u3082\u306A\u3044",
  "id" : 227550190180106241,
  "created_at" : "2012-07-23 23:46:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227550026992328704",
  "text" : "@setsuna3021181 \u5C02\u9580\u3067\u3059\u3088\u30FC",
  "id" : 227550026992328704,
  "created_at" : "2012-07-23 23:45:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227549819302969344",
  "text" : "\u5468\u308A\u306E\u4F1A\u8A71\u304C\u8A66\u9A13\u307D\u304F\u3066\u6226\u6144\u3057\u3066\u308B",
  "id" : 227549819302969344,
  "created_at" : "2012-07-23 23:44:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227531476542050305",
  "text" : "\u4E00\u9650\u51FA\u305F\u3089\u5E30\u3063\u3066\u6765\u3066\u5BDD\u308B\u306E\u3082\u8996\u91CE",
  "id" : 227531476542050305,
  "created_at" : "2012-07-23 22:31:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227530954913230848",
  "text" : "@setsuna3021181 \u305C\u3093\u305C\u3093\u9055\u3044\u307E\u3059\u3088\uFF57",
  "id" : 227530954913230848,
  "created_at" : "2012-07-23 22:29:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227529651105435648",
  "text" : "@setsuna3021181 \u4E45\u3005\u306B\u4E00\u9650\u306B\u884C\u304B\u306A\u3044\u3068\u306A\u306E\u3067\u5BDD\u305F\u3089\u30A2\u30EC\u3067\u3059",
  "id" : 227529651105435648,
  "created_at" : "2012-07-23 22:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227529483706564609",
  "text" : "\u4ECA\u3046\u3061\u306B\u98DF\u30D1\u30F3\u3042\u308B\u306E\u304B\u306A(\u305D\u3082\u305D\u3082)",
  "id" : 227529483706564609,
  "created_at" : "2012-07-23 22:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227529111625674752",
  "text" : "\u306A\u306B\u3088\u308A\u30B3\u30FC\u30D2\u30FC\u306E\u30B9\u30C8\u30C3\u30AF\u3092\u5207\u3089\u3057\u3066\u3044\u308B\u306E\u304C\u554F\u984C\u3067\u3001\u3057\u3087\u304F\u3071\u3093\u304B\u3044\u306B\u3044\u3053\u3046\u304B\u306A",
  "id" : 227529111625674752,
  "created_at" : "2012-07-23 22:22:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227528026538266624",
  "text" : "\u306D\u3080\u305F\u307F\u30FC\u30FC\u30FC",
  "id" : 227528026538266624,
  "created_at" : "2012-07-23 22:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227440942813151232",
  "text" : "@i_horse MS\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 227440942813151232,
  "created_at" : "2012-07-23 16:32:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227392249821007872",
  "geo" : { },
  "id_str" : "227397704068784128",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u304A\u3063\u3051\u30FC",
  "id" : 227397704068784128,
  "in_reply_to_status_id" : 227392249821007872,
  "created_at" : "2012-07-23 13:40:12 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/kjNDKRfe",
      "expanded_url" : "http:\/\/twitpic.com\/aasu14",
      "display_url" : "twitpic.com\/aasu14"
    } ]
  },
  "geo" : { },
  "id_str" : "227331569902292992",
  "text" : "\u3069\u3046\u3057\u3066\u3053\u3046\u306A\u3063\u305F http:\/\/t.co\/kjNDKRfe",
  "id" : 227331569902292992,
  "created_at" : "2012-07-23 09:17:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227320722811396096",
  "geo" : { },
  "id_str" : "227321879629803521",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u306D\u30FC",
  "id" : 227321879629803521,
  "in_reply_to_status_id" : 227320722811396096,
  "created_at" : "2012-07-23 08:38:54 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227291647715704832",
  "text" : "\u306F\u3041\u2026",
  "id" : 227291647715704832,
  "created_at" : "2012-07-23 06:38:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227291396418179072",
  "text" : "\u304B\u307F\u306E\u305D\u3093\u3056\u3044\u3057\u3087\u3046\u3081\u3044\u2026",
  "id" : 227291396418179072,
  "created_at" : "2012-07-23 06:37:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227290186487308288",
  "text" : "RT @t_uda: \u5E30\u3063\u3066\u30AF\u30FC\u30E9\u30FC\u306E\u30EA\u30E2\u30B3\u30F3\u898B\u305F\u3089\u6E29\u5EA6\u8868\u793A\u304C 35 \u3068\u304B\u3067\u306A\u304F\u3066\u30AA\u30FC\u30D0\u30FC\u30D5\u30ED\u30FC (??) \u3057\u305F\u306E\u304B\u305F\u3060\u4E00\u6587\u5B57 H \u3068\u8868\u793A\u3055\u308C\u3066\u3044\u305F\u306E\u3067\u3059\u304C\u3001\u6E29\u5EA6\u304C\u3059\u3054\u3044 Haskell \u3063\u3066\u3069\u3046\u3044\u3046\u610F\u5473\u3067\u3059\u304B&gt;&lt; \u7A7A\u8ABF\u306B\u526F\u4F5C\u7528\u304C\u51FA\u3066\u3044\u306A\u3044\u304B\u3082\u6C17\u306B\u306A\u308A\u307E\u3059&g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for Android org\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227289858262056960",
    "text" : "\u5E30\u3063\u3066\u30AF\u30FC\u30E9\u30FC\u306E\u30EA\u30E2\u30B3\u30F3\u898B\u305F\u3089\u6E29\u5EA6\u8868\u793A\u304C 35 \u3068\u304B\u3067\u306A\u304F\u3066\u30AA\u30FC\u30D0\u30FC\u30D5\u30ED\u30FC (??) \u3057\u305F\u306E\u304B\u305F\u3060\u4E00\u6587\u5B57 H \u3068\u8868\u793A\u3055\u308C\u3066\u3044\u305F\u306E\u3067\u3059\u304C\u3001\u6E29\u5EA6\u304C\u3059\u3054\u3044 Haskell \u3063\u3066\u3069\u3046\u3044\u3046\u610F\u5473\u3067\u3059\u304B&gt;&lt; \u7A7A\u8ABF\u306B\u526F\u4F5C\u7528\u304C\u51FA\u3066\u3044\u306A\u3044\u304B\u3082\u6C17\u306B\u306A\u308A\u307E\u3059&gt;&lt;",
    "id" : 227289858262056960,
    "created_at" : "2012-07-23 06:31:39 +0000",
    "user" : {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "protected" : false,
      "id_str" : "91551881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2672060221\/0f35a7ef7843ca03ed5048770fe5ecc4_normal.png",
      "id" : 91551881,
      "verified" : false
    }
  },
  "id" : 227290186487308288,
  "created_at" : "2012-07-23 06:32:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227278940287410176",
  "text" : "\u3068\u306F\u8A00\u3048\u3057\u3093\u3060\u3057\u3093\u3060\u3067\u6C17\u304C\u697D\u306B\u306A\u308B\u3068\u3044\u3046\u8AAC",
  "id" : 227278940287410176,
  "created_at" : "2012-07-23 05:48:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227278386253402112",
  "text" : "\u4ECA\u65E5\u8A66\u9A13\u3060\u3063\u305F\u3089\u2026\u6B7B\u306C",
  "id" : 227278386253402112,
  "created_at" : "2012-07-23 05:46:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3064\u3069\u3044\u7CFB\u30A4\u30D9\u30F3\u30C8\u7D39\u4ECBbot",
      "screen_name" : "sugakuto_osaka",
      "indices" : [ 3, 18 ],
      "id_str" : "481590089",
      "id" : 481590089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227056349907939330",
  "text" : "RT @sugakuto_osaka: \u3010\u8FFD\u8A18\u3011\u5148\u307B\u3069\u306E\u9023\u7D61\u30D5\u30A9\u30FC\u30E0\u306E\u6C0F\u540D\u306F\u672C\u540D\u3058\u3083\u306A\u304F\u3066\u30CF\u30F3\u30C9\u30EB\u30CD\u30FC\u30E0\u3067\u7D50\u69CB\u3067\u3059\u3002\u3042\u3068\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306FPC\u306E\u3082\u306E\u3067\u304A\u306D\u304C\u3044\u3057\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227056258258173952",
    "text" : "\u3010\u8FFD\u8A18\u3011\u5148\u307B\u3069\u306E\u9023\u7D61\u30D5\u30A9\u30FC\u30E0\u306E\u6C0F\u540D\u306F\u672C\u540D\u3058\u3083\u306A\u304F\u3066\u30CF\u30F3\u30C9\u30EB\u30CD\u30FC\u30E0\u3067\u7D50\u69CB\u3067\u3059\u3002\u3042\u3068\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306FPC\u306E\u3082\u306E\u3067\u304A\u306D\u304C\u3044\u3057\u307E\u3059\u3002",
    "id" : 227056258258173952,
    "created_at" : "2012-07-22 15:03:25 +0000",
    "user" : {
      "name" : "\u3064\u3069\u3044\u7CFB\u30A4\u30D9\u30F3\u30C8\u7D39\u4ECBbot",
      "screen_name" : "sugakuto_osaka",
      "protected" : false,
      "id_str" : "481590089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3194680581\/8cb7d07e676372cdcbae86769516bb49_normal.png",
      "id" : 481590089,
      "verified" : false
    }
  },
  "id" : 227056349907939330,
  "created_at" : "2012-07-22 15:03:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227056090548948992",
  "text" : "\u60C5\u5F31\u30A5\uFF01\u60C5\u5F31\u3045\uFF01",
  "id" : 227056090548948992,
  "created_at" : "2012-07-22 15:02:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227055146918617089",
  "text" : "\u00D7\u30CE\u30FC\u52C9\uFF08\uFF84\uFF9E\uFF94\uFF67\n\u25CB\u30CE\u30FC\u52C9\uFF08\u9854\u9762\u84BC\u767D",
  "id" : 227055146918617089,
  "created_at" : "2012-07-22 14:59:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227053690987626496",
  "text" : "\u78BA\u304B\u306B\u3061\u3087\u3063\u3068\u52B9\u7387\u308F\u308B\u3044",
  "id" : 227053690987626496,
  "created_at" : "2012-07-22 14:53:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227010223079055360",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 227010223079055360,
  "created_at" : "2012-07-22 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226994714262528000",
  "text" : "\u3055\u304B\u306A\u98DF\u3079\u305F\u3044\u306A\u30FC\u3068\u601D\u3063\u3066\u305F\u3089\u89AA\u304C\u9B5A\u8D08\u3063\u3066\u304F\u308C\u305F\u304B\u3089\u89AA\u3059\u3054\u3044",
  "id" : 226994714262528000,
  "created_at" : "2012-07-22 10:58:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226993890346020866",
  "text" : "\u7518\u9BAD\u3046\u3081\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048",
  "id" : 226993890346020866,
  "created_at" : "2012-07-22 10:55:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226991770628661248",
  "text" : "\u3054\u98EF\u306F\u7D04\u708A\u3051\u306A\u3044\u304B\u306A\u30FC",
  "id" : 226991770628661248,
  "created_at" : "2012-07-22 10:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226984538432221184",
  "text" : "\u5E30\u5B85\u3057\u305F\u3057",
  "id" : 226984538432221184,
  "created_at" : "2012-07-22 10:18:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226984517460717568",
  "text" : "\u3064\u3069\u3044\u306E\u4F1A\u8B70\u307E\u3067\u306B\u3054\u98EF\u4F5C\u308B\u305E\u30FC",
  "id" : 226984517460717568,
  "created_at" : "2012-07-22 10:18:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226957694710460417",
  "geo" : { },
  "id_str" : "226984461416427520",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u307F\u305F\u3044\u3067\u3059\u306D\uFF0E\u3067\u3082\u3084\u3081\u3066\u304A\u304D\u307E\u3059\uFF57",
  "id" : 226984461416427520,
  "in_reply_to_status_id" : 226957694710460417,
  "created_at" : "2012-07-22 10:18:07 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226953814111043584",
  "geo" : { },
  "id_str" : "226954321298878464",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz iPad\u3067\u304D\u306A\u304B\u3063\u305F(\uFF70\uFF70;)",
  "id" : 226954321298878464,
  "in_reply_to_status_id" : 226953814111043584,
  "created_at" : "2012-07-22 08:18:21 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226953675220852736",
  "geo" : { },
  "id_str" : "226953781118660608",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u51FA\u5148\u3060\u3051\u3069\u3044\u3044\u304B\u306A",
  "id" : 226953781118660608,
  "in_reply_to_status_id" : 226953675220852736,
  "created_at" : "2012-07-22 08:16:12 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226953002085412864",
  "geo" : { },
  "id_str" : "226953136814817280",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u304E\u3083\u304F\u306B\u304B\u3093\u304C\u3048\u308B\u3093\u3060\u3001\u307E\u30605\u6642\u306A\u306E\u3060\u3068",
  "id" : 226953136814817280,
  "in_reply_to_status_id" : 226953002085412864,
  "created_at" : "2012-07-22 08:13:39 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226952916127342593",
  "text" : "\u5727\u5012\u7684\u548C\u98DF",
  "id" : 226952916127342593,
  "created_at" : "2012-07-22 08:12:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226952818177748992",
  "text" : "\u306A\u3093\u304B\u304A\u5473\u564C\u6C41\u3092\u4F5C\u308D\u3046\u3001\u3042\u3068\u7D0D\u8C46",
  "id" : 226952818177748992,
  "created_at" : "2012-07-22 08:12:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226952755976220672",
  "text" : "\u304A\u3086\u306F\u3093\u306F\u3001\u9BAD\u3092\u713C\u3044\u3066\u30FC\u3054\u98EF\u708A\u3044\u3066\u30FC\u3001\u5375\u713C\u304D\u4F5C\u3063\u3066\u30FC\u305D\u308C\u304B\u3089\u305D\u308C\u304B\u3089",
  "id" : 226952755976220672,
  "created_at" : "2012-07-22 08:12:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 0, 9 ],
      "id_str" : "134141604",
      "id" : 134141604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226950702663098368",
  "geo" : { },
  "id_str" : "226950952031244290",
  "in_reply_to_user_id" : 134141604,
  "text" : "@nf_spitz \u307E\u3041\u305D\u3093\u306A\u306B\u98F2\u3081\u306A\u3044\u306E\u3067\u3044\u3044\u53E3\u5B9F\u3068\u3044\u3048\u3070\u3044\u3044\u53E3\u5B9F\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u3047",
  "id" : 226950952031244290,
  "in_reply_to_status_id" : 226950702663098368,
  "created_at" : "2012-07-22 08:04:58 +0000",
  "in_reply_to_screen_name" : "nf_spitz",
  "in_reply_to_user_id_str" : "134141604",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226950105377406977",
  "text" : "\u6700\u8FD1\u306F\u539F\u4ED8\u3067\u52D5\u304F\u305B\u3044\u3067\u51FA\u5148\u3067\u304A\u9152\u3092\u9060\u616E\u3057\u7D9A\u3051\u3066\u3044\u308B",
  "id" : 226950105377406977,
  "created_at" : "2012-07-22 08:01:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226949275421122561",
  "text" : "\u70AD\u9178\u629C\u3051\u308B\u3057\u6599\u7406\u51B7\u3081\u308B\u3057\u51FA\u3066\u304D\u305F\u3089\u3081\u3044\u3081\u3044\u98DF\u3079\u308C\u3070\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u306E\u3068\u304B\u601D\u3063\u3061\u3083\u3046\u304B\u3089\u305D\u3082\u305D\u3082\u5927\u4EBA\u6570\u306E\u98F2\u307F\u4F1A\u306B\u5411\u3044\u3066\u3044\u306A\u3044\u6027\u683C\u3092\u3057\u3066\u3044\u308B",
  "id" : 226949275421122561,
  "created_at" : "2012-07-22 07:58:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226948849397293056",
  "text" : "@YohjiGreat \u30D3\u30FC\u30EB\u82E6\u624B\u306A\u306E\u3067\u305D\u3046\u3044\u3046\u306E\u52A9\u304B\u308A\u307E\u3059",
  "id" : 226948849397293056,
  "created_at" : "2012-07-22 07:56:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226948216187404288",
  "text" : "@YohjiGreat \u306A\u306B\u305D\u308C\u7D20\u6575",
  "id" : 226948216187404288,
  "created_at" : "2012-07-22 07:54:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226947990001156096",
  "text" : "\u5927\u62B5\u30D3\u30FC\u30EB\u304B\u30A6\u30FC\u30ED\u30F3\u8336\u306E\u4E8C\u629E\u3092\u8FEB\u3089\u308C\u308B",
  "id" : 226947990001156096,
  "created_at" : "2012-07-22 07:53:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226947630616428544",
  "text" : "\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u306B\u3042\u3063\u305F\u306A\u30FC\u300C\u4EBA\u751F\u306B\u306F\u5ACC\u3044\u306A\u3082\u306E\u3092\u9ED9\u3063\u3066\u98DF\u3079\u306A\u304F\u3061\u3083\u3044\u3051\u306A\u3044\u5834\u9762\u304C\u3042\u308B\u3051\u308C\u3069\u3001\u4EBA\u306E\u5ACC\u3044\u306A\u3082\u306E\u3092\u7121\u7406\u3084\u308A\u98DF\u3079\u3055\u305B\u308B\u6A29\u5229\u306F\u8AB0\u306B\u3082\u306A\u3044\u300D\u307F\u305F\u3044\u306A\u30BB\u30EA\u30D5",
  "id" : 226947630616428544,
  "created_at" : "2012-07-22 07:51:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226944641503744000",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u30D3\u30FC\u30EB\u3067\u3044\u3044\u3088\u306D\uFF1F\n\u5426\u3001\u30AB\u30B7\u30B9\u30BD\u30FC\u30C0\u3067\uFF01",
  "id" : 226944641503744000,
  "created_at" : "2012-07-22 07:39:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 0, 7 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226943557641064449",
  "geo" : { },
  "id_str" : "226944316604567552",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_key \u50D5\u306F\u7A7A\u6C17\u3092\u8AAD\u307E\u305A\u306B\u3079\u3064\u306E\u3082\u306E\u3092\u305F\u306E\u3093\u3060\u308A\u3001\u98F2\u3081\u306A\u3044\u3075\u308A\u3092\u3057\u3066\u30A6\u30FC\u30ED\u30F3\u8336\u306B\u3057\u307E\u3059\u306D\u3002\u30D3\u30FC\u30EB\u82E6\u624B\u306A\u306E\u3067\u3002",
  "id" : 226944316604567552,
  "in_reply_to_status_id" : 226943557641064449,
  "created_at" : "2012-07-22 07:38:36 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226942412315041792",
  "text" : "\u30BD\u30D3\u30A8\u30C8\u30ED\u30B7\u30A2TL\u2026",
  "id" : 226942412315041792,
  "created_at" : "2012-07-22 07:31:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226934716119515136",
  "text" : "\u5589\u4E7E\u3044\u3066\u4ED5\u65B9\u306A\u3044\u306E\u306F\u6628\u65E5\u306E\u304A\u5915\u98EF\u304B\u306A\u30FC\u5929\u6D25\u98EF\u306E\u5869\u3060\u308C\u3061\u3087\u3063\u3068\u3057\u3087\u3063\u3071\u304B\u3063\u305F",
  "id" : 226934716119515136,
  "created_at" : "2012-07-22 07:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226934023467962368",
  "geo" : { },
  "id_str" : "226934713409994753",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u305D\u308C\u30E4\u30D0\u30A4\u3067\u3059\u306D(\u3057\u308D\u3081",
  "id" : 226934713409994753,
  "in_reply_to_status_id" : 226934023467962368,
  "created_at" : "2012-07-22 07:00:26 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3053\u3084\u3067",
      "screen_name" : "nekoyade",
      "indices" : [ 0, 9 ],
      "id_str" : "553253012",
      "id" : 553253012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226933358519808001",
  "geo" : { },
  "id_str" : "226933489814077440",
  "in_reply_to_user_id" : 553253012,
  "text" : "@nekoyade \u62E1\u5927\u3057\u3066\u898B\u3066\u898B\u305F\u3089\u306A\u306B\u3053\u308C\u304B\u308F\u3044\u3044",
  "id" : 226933489814077440,
  "in_reply_to_status_id" : 226933358519808001,
  "created_at" : "2012-07-22 06:55:34 +0000",
  "in_reply_to_screen_name" : "nekoyade",
  "in_reply_to_user_id_str" : "553253012",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226933154894737409",
  "text" : "\u3088\u304F\u307F\u305F\u3089\u306D\u3053\u3084\u3067\u306E\u30A2\u30A4\u30B3\u30F3\u304C\u304B\u308F\u3044\u3044",
  "id" : 226933154894737409,
  "created_at" : "2012-07-22 06:54:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3053\u3084\u3067",
      "screen_name" : "nekoyade",
      "indices" : [ 0, 9 ],
      "id_str" : "553253012",
      "id" : 553253012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226932242646171648",
  "geo" : { },
  "id_str" : "226932415409582080",
  "in_reply_to_user_id" : 553253012,
  "text" : "@nekoyade \u3044\u3084\u3001\u96FB\u8ECA\u306E\u4E2D\u3067\uFF15\uFF15\uFF11\u306E\u8089\u307E\u3093\u3092\u98DF\u3079\u3066\u81ED\u3044\u304C\u2026\u3068\u3044\u3046\u8A71\u304C\u3042\u308B\u306E\u3067\u3059\u3088",
  "id" : 226932415409582080,
  "in_reply_to_status_id" : 226932242646171648,
  "created_at" : "2012-07-22 06:51:18 +0000",
  "in_reply_to_screen_name" : "nekoyade",
  "in_reply_to_user_id_str" : "553253012",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3053\u3084\u3067",
      "screen_name" : "nekoyade",
      "indices" : [ 0, 9 ],
      "id_str" : "553253012",
      "id" : 553253012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226930559065153536",
  "geo" : { },
  "id_str" : "226931701543223296",
  "in_reply_to_user_id" : 553253012,
  "text" : "@nekoyade YouTube\u3067\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u3067\u691C\u7D22\uFF01",
  "id" : 226931701543223296,
  "in_reply_to_status_id" : 226930559065153536,
  "created_at" : "2012-07-22 06:48:28 +0000",
  "in_reply_to_screen_name" : "nekoyade",
  "in_reply_to_user_id_str" : "553253012",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226930947600314369",
  "text" : "\u3088\u304F\u8003\u3048\u305F\u3089\u4E2D\u7D1A\u306E\u904E\u53BB\u554F\u304A\u3044\u3066\u308B\u30B5\u30A4\u30C8\u898B\u305F\u3053\u3068\u306A\u3044\u304B\u3082",
  "id" : 226930947600314369,
  "created_at" : "2012-07-22 06:45:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226923440794378240",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u904E\u53BB\u554F\u304C\u5B58\u5728\u3059\u308B\u304B\u8ABF\u3079\u3088\u3046\u3063\u3068",
  "id" : 226923440794378240,
  "created_at" : "2012-07-22 06:15:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226922785736384513",
  "geo" : { },
  "id_str" : "226922972496146432",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3067\u3059\u3088\u306D\u3047\u2026",
  "id" : 226922972496146432,
  "in_reply_to_status_id" : 226922785736384513,
  "created_at" : "2012-07-22 06:13:47 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226921741971238912",
  "text" : "\u5C40\u6240\u7684\u8A9E\u5B66\u30AC\u30C1\u52E2\u306B",
  "id" : 226921741971238912,
  "created_at" : "2012-07-22 06:08:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226920316084027392",
  "geo" : { },
  "id_str" : "226921588283539456",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u3048\u3063\n\n\u3048\u3063\n\u5927\u5C71\u304C\u3084\u308A\u305F\u3044\u3089\u3057\u3044\u306E\u3067\u8A98\u3063\u3066\u3042\u3052\u3066\u304F\u3060\u3055\u3044",
  "id" : 226921588283539456,
  "in_reply_to_status_id" : 226920316084027392,
  "created_at" : "2012-07-22 06:08:17 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226919488522711040",
  "text" : "\u30BF\u30F3\u30D6\u30E9\u30FC\u306B\u30B3\u30FC\u30D2\u30FC\u7528\u610F\u3057\u305F\u306E\u306B\u53F0\u6240\u306B\u5FD8\u308C\u3066\u6765\u305F\u6642\u306E\u9854\u3057\u3063\u3071\u306A\u3057",
  "id" : 226919488522711040,
  "created_at" : "2012-07-22 05:59:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6D99\u3092\u98F2\u3093\u3067\u65AD\u3063\u305F",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226917782678286336",
  "text" : "\u306A\u305C\uFF01\uFF01\uFF01\u3046\u3061\u306E\u30B5\u30FC\u30AF\u30EB\u306E\u4EBA\u9593\u306F\uFF01\uFF01\uFF01\u50D5\u3092\uFF01\uFF01\uFF01\u9EBB\u96C0\u306B\u8A98\u3046\u306E\uFF01\uFF01\uFF01\u3053\u306E\u6642\u671F\u306B\uFF01\uFF01\uFF01\u3042\u308A\u304C\u3068\u3046\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01 \uFF03\u6D99\u3092\u98F2\u3093\u3067\u65AD\u3063\u305F",
  "id" : 226917782678286336,
  "created_at" : "2012-07-22 05:53:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/6jIi7jN3",
      "expanded_url" : "http:\/\/4sq.com\/QcgPFS",
      "display_url" : "4sq.com\/QcgPFS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "226887060680744960",
  "text" : "\u5C11\u3057\u65E9\u3044\u3051\u3069\u958B\u3051\u305F\u3088\uFF01 (@ \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ) http:\/\/t.co\/6jIi7jN3",
  "id" : 226887060680744960,
  "created_at" : "2012-07-22 03:51:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226886524338315264",
  "text" : "\u3042\u306E\u3084\u308A\u53D6\u308A\u306F\u5727\u5012\u7684\u3060\u3063\u305F",
  "id" : 226886524338315264,
  "created_at" : "2012-07-22 03:48:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226886256355860480",
  "text" : "\uFF21\u300C\u58CA\u308C\u304B\u3051\u306E\u30EC\u30C7\u30A3\u30AA\u300D\n\u3055\u3089\u3075\u300C\u58CA\u308C\u304B\u3051\u306E\u30CD\u30A4\u30C6\u30A3\u30AA\uFF1F\u300D\n\u3048\u3093\u3069\u300C\u30C8\u30A5\u30FC\u30C8\u30A5\u30FC\uFF57\uFF57\uFF57\u300D\nA\u300C\u300D",
  "id" : 226886256355860480,
  "created_at" : "2012-07-22 03:47:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226884413236072449",
  "text" : "\u7518\u5869\u306E\u9BAD\u304C\u5C4A\u3044\u305F\u3002\u708A\u304D\u305F\u3066\u3054\u98EF\u3068\u306E\u5171\u6F14\u306F \u907F\u3051 \u3089\u308C\u306A\u3044\u306D\u3002",
  "id" : 226884413236072449,
  "created_at" : "2012-07-22 03:40:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226883055363694592",
  "text" : "\u3050\u308B\u3050\u308B\u2026",
  "id" : 226883055363694592,
  "created_at" : "2012-07-22 03:35:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226882677184278528",
  "text" : "\u9ED2\u8C46\u5165\u308A\u306E\u30C9\u30FC\u30CA\u30C4\u304C\u7F8E\u5473\u3044\uFF01\u65E8\u3059\u304E\u308B\uFF01",
  "id" : 226882677184278528,
  "created_at" : "2012-07-22 03:33:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5727\u5012\u7684\u3072\u3089\u3081\u304D",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226882266809397249",
  "text" : "\u3074\u3088\u3074\u3088\u3068\u304B\u30B8\u30E5\u30EB\u30B8\u30E5\u30EB\u307F\u305F\u3044\u306B\u3050\u308B\u3050\u308B\u3067\u304A\u3057\u3066\u3044\u304F\u304B \uFF03\u5727\u5012\u7684\u3072\u3089\u3081\u304D",
  "id" : 226882266809397249,
  "created_at" : "2012-07-22 03:32:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u304A\u524D\u3089\u305F\u307E\u306B\u306F\u30A2\u30A4\u30B3\u30F3\u3089\u3057\u3044\u30C4\u30A4\u30FC\u30C8\u3057\u308D\u3088",
      "indices" : [ 17, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226881597713035265",
  "text" : "\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B #\u304A\u524D\u3089\u305F\u307E\u306B\u306F\u30A2\u30A4\u30B3\u30F3\u3089\u3057\u3044\u30C4\u30A4\u30FC\u30C8\u3057\u308D\u3088",
  "id" : 226881597713035265,
  "created_at" : "2012-07-22 03:29:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226880857120575488",
  "text" : "\u30D6\u30EA\u30A2\u30F3\u30C6\u30A3\u30FC\u30BA\u306F\u4F55\u98DF\u3079\u3066\u3082\u5927\u62B5\u7F8E\u5473\u3057\u3044",
  "id" : 226880857120575488,
  "created_at" : "2012-07-22 03:26:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226880046588100608",
  "text" : "\u3057\u3057\u3068\u3046\u30D5\u30E9\u30F3\u30B9\u30D1\u30F3\u7F8E\u5473\u3057\u3044",
  "id" : 226880046588100608,
  "created_at" : "2012-07-22 03:23:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 10, 18 ],
      "id_str" : "57847957",
      "id" : 57847957
    }, {
      "name" : "\u8336\u67F1\u3055\u3093(\u304A\u4F11\u307F\u4E2D\u3067\u3059)",
      "screen_name" : "chabashirasan",
      "indices" : [ 19, 33 ],
      "id_str" : "472125109",
      "id" : 472125109
    }, {
      "name" : "\u30DF\u30EB\u30AB (\u975E\u516C\u5F0Fbot)",
      "screen_name" : "miruka_bot",
      "indices" : [ 34, 45 ],
      "id_str" : "118009758",
      "id" : 118009758
    }, {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 46, 56 ],
      "id_str" : "157989076",
      "id" : 157989076
    }, {
      "name" : "\u30E6\u30FC\u30EA_\u975E\u516C\u5F0Fbot@ver 1.2",
      "screen_name" : "yuri_mathgirl",
      "indices" : [ 57, 71 ],
      "id_str" : "585531917",
      "id" : 585531917
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u308B\u3093 [\u6700\u7D42\u898F\u5236\u30A2\u30AB]",
      "screen_name" : "nisehorrrrrrrn",
      "indices" : [ 72, 87 ],
      "id_str" : "295218654",
      "id" : 295218654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226867033738997760",
  "text" : "@ispamgis @ninetan @chabashirasan @miruka_bot @typekanon @yuri_mathgirl @nisehorrrrrrrn \u304A\u306F\u3042\u308A\u3067\u3057\u305F\u30FC",
  "id" : 226867033738997760,
  "created_at" : "2012-07-22 02:31:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226865814433853440",
  "text" : "\u6700\u8FD1\u76EE\u899A\u307E\u3057\u304C\u306A\u308B\u6570\u5206\u524D\u306B\u8D77\u304D\u308B\u8B0E\u30B7\u30B9\u30C6\u30E0\u304C\u4F53\u306B\u642D\u8F09\u3055\u308C\u305F\u6A21\u69D8",
  "id" : 226865814433853440,
  "created_at" : "2012-07-22 02:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feru",
      "screen_name" : "Feru54604",
      "indices" : [ 0, 10 ],
      "id_str" : "78560756",
      "id" : 78560756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226864129317687296",
  "geo" : { },
  "id_str" : "226864351984906241",
  "in_reply_to_user_id" : 78560756,
  "text" : "@Feru54604 \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 226864351984906241,
  "in_reply_to_status_id" : 226864129317687296,
  "created_at" : "2012-07-22 02:20:51 +0000",
  "in_reply_to_screen_name" : "Feru54604",
  "in_reply_to_user_id_str" : "78560756",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226863625460129792",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 226863625460129792,
  "created_at" : "2012-07-22 02:17:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226647764304535554",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 226647764304535554,
  "created_at" : "2012-07-21 12:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/Pxg7V2uj",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "226416318180638720",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/Pxg7V2uj",
  "id" : 226416318180638720,
  "created_at" : "2012-07-20 20:40:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226407035854540800",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u304A\u9B5A\u98DF\u3079\u305F\u3044\u3002\u3067\u304D\u308C\u3070\u751F\u3067\u3002",
  "id" : 226407035854540800,
  "created_at" : "2012-07-20 20:03:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226406517883146240",
  "text" : "\u3048\u3093\u3069\u304F\u3093\u306F150\u5186\u306E\u304A\u8336\u98F2\u3093\u3067\u3001\u306A\u3093\u3084\u304B\u3093\u3084\u30671500\u5186\u3082\u3089\u3063\u3066\u30011100\u5186\u652F\u6255\u3063\u3066\u3001125\u5186\u306E\u30A6\u30FC\u30ED\u30F3\u8336\u3092\u8CB7\u3063\u3066\u5E30\u308A\u307E\u3057\u305F\u3002\u3055\u3066\u3001\u751F\u6D3B\u30EA\u30BA\u30E0\u306F\u3069\u3046\u306A\u3063\u3066\u3057\u307E\u3046\u306E\u3067\u3057\u3087\u3046\u304B\u3002",
  "id" : 226406517883146240,
  "created_at" : "2012-07-20 20:01:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226327117577736192",
  "text" : "\u89E3\u3051\u305F\uFF01\u30D3\u30D3\u3063\u3066\u6765\u305F\uFF01",
  "id" : 226327117577736192,
  "created_at" : "2012-07-20 14:46:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226305054477516800",
  "text" : "\u30E1\u30AC\u30CD\u521D\u3081\u3066\u304B\u3051\u305F\u6642\u3082\u4E16\u754C\u304C\u5909\u308F\u3063\u305F\u8A18\u61B6\u304C\u3042\u308B\u306A\u30FC",
  "id" : 226305054477516800,
  "created_at" : "2012-07-20 13:18:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226203288381566976",
  "text" : "\u8A00\u3063\u3066\u898B\u305F\u3060\u3051",
  "id" : 226203288381566976,
  "created_at" : "2012-07-20 06:34:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226203177551282176",
  "text" : "\u3088\u3063\u3057\u3083\u76EE\u899A\u3081\u305F\u3002\u76EE\u899A\u3081\u308B\u30D1\u30EF\u30FC\u3002",
  "id" : 226203177551282176,
  "created_at" : "2012-07-20 06:33:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226201787244347393",
  "text" : "30\u5206\u306E\u307E\u3069\u308D\u307F\u3082\u8A08\u7B97\u306E\u3046\u3061",
  "id" : 226201787244347393,
  "created_at" : "2012-07-20 06:28:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226201665303351296",
  "text" : "\u30DE\u30B9\u30AB\u30C3\u30C8\u30AA\u30D6\u30A2\u30EC\u30AD\u30B5\u30F3\u30C9\u30EA\u30A2\u306F\u308F\u304B\u3063\u305F",
  "id" : 226201665303351296,
  "created_at" : "2012-07-20 06:27:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226177165232840704",
  "text" : "15\u6642\u306B\u8D77\u304D\u308B\u3002\u96E8\u30A7\u3002",
  "id" : 226177165232840704,
  "created_at" : "2012-07-20 04:50:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226177064368234497",
  "text" : "1\u6642\u9593\u307B\u3069\u4EEE\u7720\u3059\u308B",
  "id" : 226177064368234497,
  "created_at" : "2012-07-20 04:49:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226175439910105090",
  "text" : "\u725B\u4E73\u3055\u3048\u8CB7\u3044\u306B\u51FA\u308C\u306A\u3044(\u51FA\u306A\u3044)",
  "id" : 226175439910105090,
  "created_at" : "2012-07-20 04:43:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226172242621505536",
  "geo" : { },
  "id_str" : "226175304656363520",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u305D\u308C\u306A\u30FC",
  "id" : 226175304656363520,
  "in_reply_to_status_id" : 226172242621505536,
  "created_at" : "2012-07-20 04:42:49 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226171959598276608",
  "text" : "\u304B\u307F\u306A\u308A",
  "id" : 226171959598276608,
  "created_at" : "2012-07-20 04:29:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226171894636875776",
  "text" : "16\u6642\u4EE5\u964D\u6B62\u3080\u3068\u3082\u9650\u3089\u306C",
  "id" : 226171894636875776,
  "created_at" : "2012-07-20 04:29:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 0, 9 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226171648775159809",
  "geo" : { },
  "id_str" : "226171833500696576",
  "in_reply_to_user_id" : 407863488,
  "text" : "@phyzyuya \u306A\u3044\u3093\u305F\u3093\u307F\u305F\u3051\u306916\u6642\u4F4D\u307E\u3067\u306F\u964D\u308A\u3063\u3071\u306A\u3057\u307F\u305F\u3044\u2026",
  "id" : 226171833500696576,
  "in_reply_to_status_id" : 226171648775159809,
  "created_at" : "2012-07-20 04:29:01 +0000",
  "in_reply_to_screen_name" : "phyzyuya",
  "in_reply_to_user_id_str" : "407863488",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226167678002405376",
  "text" : "\u5727\u5012\u7684\u51B7\u9759",
  "id" : 226167678002405376,
  "created_at" : "2012-07-20 04:12:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226167615930904578",
  "text" : "RT @shigmax: \u96F7\u3060\u3000\u3053\u3053\u306F\u51B7\u9759\u306B\u304A\u3078\u305D\u3092\u96A0\u305D\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226167500184891392",
    "text" : "\u96F7\u3060\u3000\u3053\u3053\u306F\u51B7\u9759\u306B\u304A\u3078\u305D\u3092\u96A0\u305D\u3046",
    "id" : 226167500184891392,
    "created_at" : "2012-07-20 04:11:48 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 226167615930904578,
  "created_at" : "2012-07-20 04:12:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226167317200003072",
  "text" : "\u304B\u307F\u306A\u308A\u3043",
  "id" : 226167317200003072,
  "created_at" : "2012-07-20 04:11:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226163358531981312",
  "text" : "\u305D\u3057\u3066\u3072\u3069\u3044\u96E8",
  "id" : 226163358531981312,
  "created_at" : "2012-07-20 03:55:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226163327989084162",
  "text" : "\u30A6\u30AA\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u3068\u3051\u305F\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC",
  "id" : 226163327989084162,
  "created_at" : "2012-07-20 03:55:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226156371345825792",
  "text" : "\u590F\u306F\u6C57\u3068\u51B7\u623F\u3067\u3001\u51AC\u306F\u4E7E\u71E5\u3067\u9AEA\u306E\u6BDB\u304C",
  "id" : 226156371345825792,
  "created_at" : "2012-07-20 03:27:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226156020274184192",
  "text" : "\u5FAE\u7B11",
  "id" : 226156020274184192,
  "created_at" : "2012-07-20 03:26:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226155787637116930",
  "text" : "\u9AEA\u304C\u4F38\u3073\u305F\u306A\u3041",
  "id" : 226155787637116930,
  "created_at" : "2012-07-20 03:25:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226155277404233729",
  "text" : "\u30DF\u30C3\u30B7\u30E7\u30F3",
  "id" : 226155277404233729,
  "created_at" : "2012-07-20 03:23:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226155250753626112",
  "text" : "\u6C37\u3068\u725B\u4E73\u3092\u8CB7\u3044\u306B\u884C\u304F\u307F\u3063\u3061\u3083\u3093",
  "id" : 226155250753626112,
  "created_at" : "2012-07-20 03:23:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226155055454236673",
  "text" : "\u308F\u3057\u3083\u308F\u3057\u3083\u3057\u3083\u308F\u30FC",
  "id" : 226155055454236673,
  "created_at" : "2012-07-20 03:22:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226155013645418496",
  "text" : "\u3057\u3083\u308F\u3063\u305F",
  "id" : 226155013645418496,
  "created_at" : "2012-07-20 03:22:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226140851313709056",
  "text" : "4.1\u7BC0\u7D42\u308F\u3063\u305F\u3089\u663C\u5BDD4.1\u7BC0\u7D42\u308F\u3063\u305F\u3089\u663C\u5BDD4.1\u7BC0\u7D42\u308F\u3063\u305F\u3089\u663C\u5BDD4.1\u7BC0\u7D42\u308F\u3063\u305F\u3089\u663C\u5BDD",
  "id" : 226140851313709056,
  "created_at" : "2012-07-20 02:25:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226140095021981696",
  "text" : "\u9CE5\u3068\u3044\u3046\u5B57\u306F",
  "id" : 226140095021981696,
  "created_at" : "2012-07-20 02:22:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305E\u308B",
      "screen_name" : "zollkause",
      "indices" : [ 0, 10 ],
      "id_str" : "203859363",
      "id" : 203859363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226139232278831104",
  "geo" : { },
  "id_str" : "226139802561568769",
  "in_reply_to_user_id" : 203859363,
  "text" : "@zollkause \u516D\u6CD5\u5168\u66F8\u3068\u304B\u306A\u3089\u305D\u3046\u304B\u3082",
  "id" : 226139802561568769,
  "in_reply_to_status_id" : 226139232278831104,
  "created_at" : "2012-07-20 02:21:45 +0000",
  "in_reply_to_screen_name" : "zollkause",
  "in_reply_to_user_id_str" : "203859363",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226139701071990784",
  "text" : "\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\u7D19\u306E\u8F9E\u66F8\u4F7F\u3044\u306F\u7D50\u69CB\u306A\u78BA\u7387\u3067\u4E00\u767A\u30C4\u30E2\u3059\u308B\u3068\u601D\u3046\u3093\u3060\u3051\u308C\u3069",
  "id" : 226139701071990784,
  "created_at" : "2012-07-20 02:21:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305E\u308B",
      "screen_name" : "zollkause",
      "indices" : [ 0, 10 ],
      "id_str" : "203859363",
      "id" : 203859363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226131273230462976",
  "geo" : { },
  "id_str" : "226139104553881600",
  "in_reply_to_user_id" : 203859363,
  "text" : "@zollkause \u5929\u9CF3\u3060\u3068\u3067\u306A\u3055\u904E\u304E\u308B\u5370\u8C61",
  "id" : 226139104553881600,
  "in_reply_to_status_id" : 226131273230462976,
  "created_at" : "2012-07-20 02:18:58 +0000",
  "in_reply_to_screen_name" : "zollkause",
  "in_reply_to_user_id_str" : "203859363",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226130967985811456",
  "text" : "\u8F9E\u66F8\u3068\u304B\u6559\u79D1\u66F8\u3067\u76EE\u7684\u306E\u30DA\u30FC\u30B8\u3092\u30D1\u30C3\u3068\u958B\u3051\u308B\u3053\u3068\u3092\u300E\u4E00\u767A\u30C4\u30E2\u300F\u3068\u547C\u3076\u3053\u3068\u3092\u63D0\u5531\u3057\u305F\u3044\uFF0E",
  "id" : 226130967985811456,
  "created_at" : "2012-07-20 01:46:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226106004373372928",
  "text" : "\u3057\u307F\u3058\u307F",
  "id" : 226106004373372928,
  "created_at" : "2012-07-20 00:07:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226105992935530496",
  "text" : "\u305D\u3046\u304B\u3001\u8272\u3005\u6700\u901F\u306A\u9AD8\u6821\u306E\u540C\u671F\u306F\u3082\u3046\u5B66\u751F\u6700\u5F8C\u306E\u590F\u306A\u306E\u304B",
  "id" : 226105992935530496,
  "created_at" : "2012-07-20 00:07:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226102888613699584",
  "text" : "\u820C\u706B\u50B7\u3057\u305F\uFF0E",
  "id" : 226102888613699584,
  "created_at" : "2012-07-19 23:55:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226089580502327296",
  "text" : "\u671D\u304B\u3089\u30B9\u30FC\u30D7\u30D1\u30B9\u30BF\u3068\u3044\u3046\u5727\u5012\u7684\u767A\u60F3",
  "id" : 226089580502327296,
  "created_at" : "2012-07-19 23:02:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225923079346462720",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 225923079346462720,
  "created_at" : "2012-07-19 12:00:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225886269606084608",
  "text" : "\u3053\u308C\u306F\u3072\u3069\u3044",
  "id" : 225886269606084608,
  "created_at" : "2012-07-19 09:34:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/56Ke9Bzq",
      "expanded_url" : "http:\/\/twitpic.com\/a99nz2",
      "display_url" : "twitpic.com\/a99nz2"
    } ]
  },
  "geo" : { },
  "id_str" : "225884137918169088",
  "text" : "\u5DE6\u534A\u58CA\u533A\u9593 http:\/\/t.co\/56Ke9Bzq",
  "id" : 225884137918169088,
  "created_at" : "2012-07-19 09:25:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225766147897823232",
  "text" : "\u3069\u3063\u3061\u3082\u3069\u3063\u3061\u306A\u3093\u3060\u305C",
  "id" : 225766147897823232,
  "created_at" : "2012-07-19 01:36:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225766016473526272",
  "text" : "\u95A2\u897F\u306B\u5BFE\u3059\u308B\u95A2\u6771\u306E\u504F\u898B\u304C\u5F37\u3044\u306E\u3068\u540C\u69D8\u306B\u95A2\u6771\u306B\u5BFE\u3059\u308B\u95A2\u897F\u306E\u504F\u898B\u3082\u307E\u305F\u7D50\u69CB\u5F37\u3044",
  "id" : 225766016473526272,
  "created_at" : "2012-07-19 01:36:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225611298250047489",
  "text" : "\u591A\u69D8\u4F53\u64CD\u306E\u30DD\u30FC\u30BA\u306F\u9593\u9055\u3044\u306A\u304F\u5E7E\u4F55\u306E\u30DD\u30FC\u30BA",
  "id" : 225611298250047489,
  "created_at" : "2012-07-18 15:21:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225611195552505856",
  "text" : "\u4F1D\u7D71\u7684\u306A\u7A7A\u624B\u8E0A\u308A\u306E\u30B9\u30BF\u30A4\u30EB\u306F\u89E3\u6790\u7684\u306A\u306E\u304B\u306A\uFF08\u3057\u308D\u3081",
  "id" : 225611195552505856,
  "created_at" : "2012-07-18 15:21:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225610641497534464",
  "text" : "\u3053\u308C\u8A98\u3063\u3066\u9802\u3044\u305F\u3051\u308C\u3069\u3069\u308C\u3082\u8A66\u9A13\u53D7\u3051\u306A\u3044\uFF57\uFF57\uFF57\uFF57\uFF57\u53D7\u3051\u308B\uFF57\uFF57\uFF57\uFF57\uFF57\u53D7\u3051\u306A\u3044\u306E\u306B\u53D7\u3051\u308B\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 225610641497534464,
  "created_at" : "2012-07-18 15:19:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225602501808885760",
  "text" : "\u3042\uFF0C\u78BA\u8A8D\u306E\u30E1\u30FC\u30EB\u4E8C\u3064\u6765\u305F\u304B\u3089\u5927\u4E08\u592B\u306A\u3093\u3060\u308D\u3046\u591A\u5206",
  "id" : 225602501808885760,
  "created_at" : "2012-07-18 14:46:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225602373467373568",
  "text" : "\u3084\u307E\u3060\u3061\u3083\u3093\u306E\u30E1\u30FC\u30EB\u30D5\u30A9\u30FC\u30E0\u304B\u3089\u9001\u4FE1\u3063\u3066\u62BC\u3057\u305F\u3089\u6587\u5B57\u5316\u3051\u3057\u305F\u3093\u3060\u3051\u308C\u3069\u3053\u308C\u3060\u3044\u3058\u3087\u3046\u3076\u306A\u306E\u304B\u3057\u3089\u3093",
  "id" : 225602373467373568,
  "created_at" : "2012-07-18 14:46:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "indices" : [ 3, 16 ],
      "id_str" : "310067164",
      "id" : 310067164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2g4IpTqn",
      "expanded_url" : "http:\/\/bit.ly\/xXUzRE",
      "display_url" : "bit.ly\/xXUzRE"
    } ]
  },
  "geo" : { },
  "id_str" : "225598152714096640",
  "text" : "RT @_yamadachan_: \u300C\u98DF\u30D1\u30F3\u30C0\u30C3\u30B7\u30E5\u300D\u9001\u6599\u7121\u6599\u30AD\u30E3\u30F3\u30DA\u30FC\u30F3\uFF01 \u30D5\u30EA\u30FC\u30DA\u30FC\u30D1\u30FC\u3092\u30B2\u30C3\u30C8\u3067\u304D\u306A\u3044\u541B\u306B\uFF01\u90F5\u9001\u30B5\u30FC\u30D3\u30B9\u306E\u304A\u77E5\u3089\u305B\u2606\u3000\u90F5\u4FBF\u756A\u53F7\u3001\u4F4F\u6240\u3001\u304A\u540D\u524D\u3001\u5E0C\u671B\u306E\u30D5\u30EA\u30FC\u30DA\u30FC\u30D1\u30FC\u30CA\u30F3\u30D0\u30FC\u3068\u90E8\u6570\u3001twitterID\u3092\u30E1\u30FC\u30EB\u30D5\u30A9\u30FC\u30E0\u304B\u3089\u9001\u3063\u3066\u306D\u301C\uFF087\/5~7\/20\u307E\u3067\uFF09 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/2g4IpTqn",
        "expanded_url" : "http:\/\/bit.ly\/xXUzRE",
        "display_url" : "bit.ly\/xXUzRE"
      } ]
    },
    "geo" : { },
    "id_str" : "225597824077795328",
    "text" : "\u300C\u98DF\u30D1\u30F3\u30C0\u30C3\u30B7\u30E5\u300D\u9001\u6599\u7121\u6599\u30AD\u30E3\u30F3\u30DA\u30FC\u30F3\uFF01 \u30D5\u30EA\u30FC\u30DA\u30FC\u30D1\u30FC\u3092\u30B2\u30C3\u30C8\u3067\u304D\u306A\u3044\u541B\u306B\uFF01\u90F5\u9001\u30B5\u30FC\u30D3\u30B9\u306E\u304A\u77E5\u3089\u305B\u2606\u3000\u90F5\u4FBF\u756A\u53F7\u3001\u4F4F\u6240\u3001\u304A\u540D\u524D\u3001\u5E0C\u671B\u306E\u30D5\u30EA\u30FC\u30DA\u30FC\u30D1\u30FC\u30CA\u30F3\u30D0\u30FC\u3068\u90E8\u6570\u3001twitterID\u3092\u30E1\u30FC\u30EB\u30D5\u30A9\u30FC\u30E0\u304B\u3089\u9001\u3063\u3066\u306D\u301C\uFF087\/5~7\/20\u307E\u3067\uFF09\u3000http:\/\/t.co\/2g4IpTqn",
    "id" : 225597824077795328,
    "created_at" : "2012-07-18 14:28:07 +0000",
    "user" : {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "protected" : false,
      "id_str" : "310067164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585053686205775873\/EygeOjja_normal.jpg",
      "id" : 310067164,
      "verified" : false
    }
  },
  "id" : 225598152714096640,
  "created_at" : "2012-07-18 14:29:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30B3\u30FC\u30D2\u30FC\u30DF\u30EB\u30AF",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225597880352772096",
  "text" : "\u305D\u3082\u305D\u3082\u690D\u7269\u6027\u306F\u7518\u3048 #\u30B3\u30FC\u30D2\u30FC\u30DF\u30EB\u30AF",
  "id" : 225597880352772096,
  "created_at" : "2012-07-18 14:28:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7384\u691B(\u304F\u308D\u3082\u307F\u3058)",
      "screen_name" : "mathematica2357",
      "indices" : [ 0, 16 ],
      "id_str" : "529376719",
      "id" : 529376719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225596864010006528",
  "geo" : { },
  "id_str" : "225597008071770114",
  "in_reply_to_user_id" : 529376719,
  "text" : "@mathematica2357 \u308F\u3041\u3044\u30A6\u30FC\u30ED\u30F3\u8336 \u3048\u3093\u3069\u30A6\u30FC\u30ED\u30F3\u8336\u3060\u3044\u3059\u304D \uFF08\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u304C\u3044\u3044\u306E",
  "id" : 225597008071770114,
  "in_reply_to_status_id" : 225596864010006528,
  "created_at" : "2012-07-18 14:24:52 +0000",
  "in_reply_to_screen_name" : "mathematica2357",
  "in_reply_to_user_id_str" : "529376719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225596257551388672",
  "text" : "\uFF15\u7AE0\u3067\u3059\u304B\u3089\u2026\u5F8C\u751F\u3067\u3059\u304B\u3089\u2026",
  "id" : 225596257551388672,
  "created_at" : "2012-07-18 14:21:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225596016353746945",
  "text" : "\u5727\u5012\u7684\u7BB4\u8A00\u3060\u3063\u305F\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 225596016353746945,
  "created_at" : "2012-07-18 14:20:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 3, 12 ],
      "id_str" : "134141604",
      "id" : 134141604
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 20, 30 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225595961962020866",
  "text" : "RT @nf_spitz: \u73FE\u5B9F\u9003\u907F \u201C@end313124: \u8A66\u9A13\u524D\u306B\u8A66\u9A13\u3068\u95A2\u4FC2\u306E\u306A\u3044\u52C9\u5F37\u3057\u305F\u304F\u306A\u308B\u73FE\u8C61\u306B\u540D\u524D\u3092\uFF01\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 6, 16 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225595870417129473",
    "text" : "\u73FE\u5B9F\u9003\u907F \u201C@end313124: \u8A66\u9A13\u524D\u306B\u8A66\u9A13\u3068\u95A2\u4FC2\u306E\u306A\u3044\u52C9\u5F37\u3057\u305F\u304F\u306A\u308B\u73FE\u8C61\u306B\u540D\u524D\u3092\uFF01\u201D",
    "id" : 225595870417129473,
    "created_at" : "2012-07-18 14:20:21 +0000",
    "user" : {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "protected" : false,
      "id_str" : "134141604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606146106632724480\/bT0kQSWB_normal.jpg",
      "id" : 134141604,
      "verified" : false
    }
  },
  "id" : 225595961962020866,
  "created_at" : "2012-07-18 14:20:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305E\u308B",
      "screen_name" : "zollkause",
      "indices" : [ 0, 10 ],
      "id_str" : "203859363",
      "id" : 203859363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225595768126451715",
  "geo" : { },
  "id_str" : "225595939723821057",
  "in_reply_to_user_id" : 203859363,
  "text" : "@zollkause \uFF4D\uFF4A\uFF4B \u307E\u3041\uFF16\u7AE0\u306F\u5165\u3089\u306A\u3044\u3060\u308D\u3046\u2026",
  "id" : 225595939723821057,
  "in_reply_to_status_id" : 225595768126451715,
  "created_at" : "2012-07-18 14:20:38 +0000",
  "in_reply_to_screen_name" : "zollkause",
  "in_reply_to_user_id_str" : "203859363",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305E\u308B",
      "screen_name" : "zollkause",
      "indices" : [ 0, 10 ],
      "id_str" : "203859363",
      "id" : 203859363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225595536303067136",
  "in_reply_to_user_id" : 203859363,
  "text" : "@zollkause \u304B\u304F\u308A\u3064\u306E\u8A66\u9A13\u7BC4\u56F2\u3063\u3066\u3069\u3053\u307E\u3067\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 225595536303067136,
  "created_at" : "2012-07-18 14:19:01 +0000",
  "in_reply_to_screen_name" : "zollkause",
  "in_reply_to_user_id_str" : "203859363",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225595291083096065",
  "text" : "\u8A66\u9A13\u524D\u306B\u8A66\u9A13\u3068\u95A2\u4FC2\u306E\u306A\u3044\u52C9\u5F37\u3057\u305F\u304F\u306A\u308B\u73FE\u8C61\u306B\u540D\u524D\u3092\uFF01",
  "id" : 225595291083096065,
  "created_at" : "2012-07-18 14:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225594708112580608",
  "text" : "\u30A6\u30FC\u30ED\u30F3\u8336\u2026\u30A6\u30FC\u30ED\u30F3\u8336\u98F2\u307F\u305F\u3044\u2026",
  "id" : 225594708112580608,
  "created_at" : "2012-07-18 14:15:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225587861179744258",
  "text" : "\u30DE\u30DF\u30FC\u306E\u8CDE\u5473\u671F\u9650\u304C\u4ECA\u65E5\u4E2D\u3060\u3063\u305F\uFF0E\u6C17\u4ED8\u3044\u3066\u3088\u304B\u3063\u305F\uFF0E",
  "id" : 225587861179744258,
  "created_at" : "2012-07-18 13:48:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225587604169560065",
  "text" : "\u5589\u304C\u6E07\u3044\u3066\u4ED5\u65B9\u306A\u3044",
  "id" : 225587604169560065,
  "created_at" : "2012-07-18 13:47:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225586971953725441",
  "geo" : { },
  "id_str" : "225587110982320128",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 225587110982320128,
  "in_reply_to_status_id" : 225586971953725441,
  "created_at" : "2012-07-18 13:45:33 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225586663643033600",
  "text" : "\u672C\u6C17\u51FA\u3059 \u3067\u7D42\u308F\u308B\u6587\u306F\u305F\u3044\u3066\u3044\u622F\u8A00",
  "id" : 225586663643033600,
  "created_at" : "2012-07-18 13:43:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u622F\u8A00",
      "indices" : [ 26, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225586588124585984",
  "text" : "\u4ECA\u671F\u3042\u3093\u307E\u308A\u666E\u901A\u306B\u3057\u3066\u306A\u3044\u304B\u3089\u8A66\u9A13\u671F\u9593\u3060\u3051\u672C\u6C17\u51FA\u3059 #\u622F\u8A00",
  "id" : 225586588124585984,
  "created_at" : "2012-07-18 13:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225586058186850305",
  "geo" : { },
  "id_str" : "225586152361570305",
  "in_reply_to_user_id" : 547547290,
  "text" : "@oPAKILIFEo \u53D6\u308C\u306A\u304B\u3063\u305F\u79D1\u76EE\u306F\u898B\u3066\u307E\u305B\u3093\uFF01\uFF08\uFF77\uFF98\uFF6F",
  "id" : 225586152361570305,
  "in_reply_to_status_id" : 225586058186850305,
  "created_at" : "2012-07-18 13:41:44 +0000",
  "in_reply_to_screen_name" : "kussy_tessy",
  "in_reply_to_user_id_str" : "547547290",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225585597832630273",
  "geo" : { },
  "id_str" : "225585822219505664",
  "in_reply_to_user_id" : 547547290,
  "text" : "@oPAKILIFEo \u305D\u308C\u3067\u3082\u53D6\u308C\u305F\u4E00\u756A\u53F3\u306E\u6570\u5B57\u304C\u5C11\u306A\u3044\u3068\u3061\u3087\u3063\u3068\u3046\u308C\u3057\u304F\u306A\u308A\u307E\u3059\u3051\u3069\u306D\uFF57",
  "id" : 225585822219505664,
  "in_reply_to_status_id" : 225585597832630273,
  "created_at" : "2012-07-18 13:40:25 +0000",
  "in_reply_to_screen_name" : "kussy_tessy",
  "in_reply_to_user_id_str" : "547547290",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225585233976754177",
  "geo" : { },
  "id_str" : "225585437966745600",
  "in_reply_to_user_id" : 547547290,
  "text" : "@oPAKILIFEo \u305B\u3081\u3066\u30EC\u30DD\u30FC\u30C8\u51FA\u3057\u305F\u308A\u8A66\u9A13\u53D7\u3051\u305F\u4EBA\u306E\u30C7\u30FC\u30BF\u3082\u6B32\u3057\u3044\u3067\u3059\u3088\u306D",
  "id" : 225585437966745600,
  "in_reply_to_status_id" : 225585233976754177,
  "created_at" : "2012-07-18 13:38:54 +0000",
  "in_reply_to_screen_name" : "kussy_tessy",
  "in_reply_to_user_id_str" : "547547290",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225584840798507008",
  "geo" : { },
  "id_str" : "225584967785267200",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u9806\u5F53\u306A\u7D50\u679C\u3060\u3051\u308C\u3069\u7B11\u3063\u305F\uFF57\uFF57\uFF57",
  "id" : 225584967785267200,
  "in_reply_to_status_id" : 225584840798507008,
  "created_at" : "2012-07-18 13:37:02 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 3, 14 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 16, 26 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225584896192692224",
  "text" : "RT @akiyohmori: @end313124 \u30B9\u30AF\u6C34\u306E\u5F7C\u3001\u7325\u893B\u7F6A\u304B\u4F55\u304B\u3067\u6355\u307E\u3063\u305F\u3089\u3057\u3044\u3002\u3042\u304F\u307E\u3067\u3082\u5642\u3060\u3051\u3069w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "225505928240312320",
    "geo" : { },
    "id_str" : "225584840798507008",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u30B9\u30AF\u6C34\u306E\u5F7C\u3001\u7325\u893B\u7F6A\u304B\u4F55\u304B\u3067\u6355\u307E\u3063\u305F\u3089\u3057\u3044\u3002\u3042\u304F\u307E\u3067\u3082\u5642\u3060\u3051\u3069w",
    "id" : 225584840798507008,
    "in_reply_to_status_id" : 225505928240312320,
    "created_at" : "2012-07-18 13:36:31 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "protected" : true,
      "id_str" : "171457320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555339308161196032\/YYPpPK6s_normal.jpeg",
      "id" : 171457320,
      "verified" : false
    }
  },
  "id" : 225584896192692224,
  "created_at" : "2012-07-18 13:36:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u501F\u308A\u65C5\u884C\u306E\u30C8\u30DE\u30B8\u30A6\u30B9",
      "screen_name" : "kagyu_phis",
      "indices" : [ 0, 11 ],
      "id_str" : "129850436",
      "id" : 129850436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225583425317376000",
  "geo" : { },
  "id_str" : "225583582972870656",
  "in_reply_to_user_id" : 129850436,
  "text" : "@kagyu_phis \u30B3\u30A2\u30B3\u30FC\u30B9\u306F\u5148\u751F\u66F0\u304F\u300C\u4EE3\u6570\u5E7E\u4F55\u306E\u201D\u512A\u79C0\u306A\u201D\u5B66\u751F\u3092\u80B2\u3066\u308B\u306E\u304C\u76EE\u6A19\u300D\u3067\u3059\u304B\u3089\u76F8\u5F53\u3067\u3057\u3087\u3046\u306D\u2026",
  "id" : 225583582972870656,
  "in_reply_to_status_id" : 225583425317376000,
  "created_at" : "2012-07-18 13:31:31 +0000",
  "in_reply_to_screen_name" : "kagyu_phis",
  "in_reply_to_user_id_str" : "129850436",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225583363929550850",
  "text" : "\u3053\u306E\u30EA\u30B9\u30C8\u9762\u767D\u3044\u306A\u30FC\uFF0E\u3053\u308C\u898B\u308B\u3060\u3051\u3067\u53CB\u4EBA\u3042\u306E\u5358\u4F4D\u53D6\u308C\u305F\u306E\u304B\u30FC\u3068\u304B\u89E3\u308B\uFF0E",
  "id" : 225583363929550850,
  "created_at" : "2012-07-18 13:30:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u501F\u308A\u65C5\u884C\u306E\u30C8\u30DE\u30B8\u30A6\u30B9",
      "screen_name" : "kagyu_phis",
      "indices" : [ 0, 11 ],
      "id_str" : "129850436",
      "id" : 129850436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225582862190133250",
  "geo" : { },
  "id_str" : "225583197415669762",
  "in_reply_to_user_id" : 129850436,
  "text" : "@kagyu_phis 218\u4EBA\u4E2D61\u4EBA\u53D6\u5F97\u3067\u3059\u304B\u3089\u7D50\u69CB\u53B3\u3057\u3044\u3067\u3059\u306D\uFF0E\u8A66\u9A13\u53D7\u3051\u3066\u3082\u3044\u306A\u3044\u4EBA\u3082\u3044\u308B\u3067\u3057\u3087\u3046\u304C",
  "id" : 225583197415669762,
  "in_reply_to_status_id" : 225582862190133250,
  "created_at" : "2012-07-18 13:30:00 +0000",
  "in_reply_to_screen_name" : "kagyu_phis",
  "in_reply_to_user_id_str" : "129850436",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4ECA\u5E74\u3082\u767B\u9332\u3059\u308B",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225582784184455168",
  "text" : "\u4EE3\u6570\u5B66\u5165\u9580\u306F\u767B\u9332\u3057\u3066\u305F\u3057\u8A66\u9A13\u53D7\u3051\u3066\u3082\u4E0D\u53EF\u3060\u3063\u305F\u3051\u3069\u306D\uFF01\uFF01\uFF01\uFF01\uFF01 #\u4ECA\u5E74\u3082\u767B\u9332\u3059\u308B",
  "id" : 225582784184455168,
  "created_at" : "2012-07-18 13:28:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225582568685314048",
  "text" : "@setsuna0321118 \u3042\u30FC\u4E00\u822C\u6559\u990A\u306E\u5E7E \u4F55\u5B66\u5165\u9580\u306A\u3089\u521D\u7B49\u5E7E\u4F55\u3092\u60F3\u5B9A\u3057\u3066\u767B\u9332\u3057\u305F\u4E00\u56DE\u751F\u3068\u304B\u304C\u3057\u308D\u3081\u306B\u306A\u3063\u3066\u5207\u3063\u3066\u308B\u53EF\u80FD\u6027\u304C\u7D50\u69CB\u3042\u308A\u305D\u3046\u306A",
  "id" : 225582568685314048,
  "created_at" : "2012-07-18 13:27:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3067\u3082\u52C9\u5F37\u3059\u308B\u6C17\u306F\u3042\u3093\u307E\u308A\u306A\u3044",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225582344218755072",
  "text" : "\u9006\u306B\u4ECA\u671F\u53D6\u3063\u3066\u3066\u3042\u3093\u307E\u308A\u6388\u696D\u884C\u3063\u3066\u306A\u3044\u79D1\u76EE\u304C3\u5272\u5F31\u4F4D\u306E\u53D6\u5F97\u7387\u3067\u6226\u6144\u3057\u3066\u3044\u308B\uFF0E #\u3067\u3082\u52C9\u5F37\u3059\u308B\u6C17\u306F\u3042\u3093\u307E\u308A\u306A\u3044",
  "id" : 225582344218755072,
  "created_at" : "2012-07-18 13:26:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225582189486682112",
  "text" : "\u3042\u308C\u307F\u3093\u306A\u306B\u5358\u4F4D\u6492\u3044\u3066\u305F\u308F\u3051\u3058\u3083\u306A\u3044\u306E\u306D\u2026\u3068\u3057\u307F\u3058\u307F\u3057\u3066\u3044\u308B\u79D1\u76EE\u304C\u3044\u304F\u3064\u3082\uFF0E",
  "id" : 225582189486682112,
  "created_at" : "2012-07-18 13:25:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225580718183550976",
  "text" : "\u307E\u3041\u53EF\u3060\u3063\u305F\u3093\u3067\u5049\u305D\u3046\u306B\u8A00\u3048\u307E\u305B\u3093\u3051\u308C\u3069\uFF08\u3057\u308D\u3081",
  "id" : 225580718183550976,
  "created_at" : "2012-07-18 13:20:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225580291408920576",
  "text" : "\u50D5\u3060\uFF0E",
  "id" : 225580291408920576,
  "created_at" : "2012-07-18 13:18:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225579865150205952",
  "text" : "\u3053\u308C\u5E7E\u4F55\u5B66\u5165\u9580\u306E\u9AD8\u7B49\u6559\u80B2\u7814\u7A76\u958B\u767A\u6A5F\u69CB\u304C\u4E00\u822C\u6559\u990A\u3063\u3066\u610F\u5473\u306A\u3089\u5C65\u4FEE\u8005\uFF16\u306E\u5358\u4F4D\u53D6\u5F97\u8005\uFF11\u3063\u3066\u2026",
  "id" : 225579865150205952,
  "created_at" : "2012-07-18 13:16:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u3086\u03C9\u30FC)\u3327@\u6843",
      "screen_name" : "yuton",
      "indices" : [ 3, 9 ],
      "id_str" : "15597112",
      "id" : 15597112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/3QeLETT3",
      "expanded_url" : "http:\/\/htn.to\/wpXXB1",
      "display_url" : "htn.to\/wpXXB1"
    } ]
  },
  "geo" : { },
  "id_str" : "225579711856771074",
  "text" : "RT @yuton: \u201C\u5404\u6388\u696D\u306E\u5E73\u5747\u5B66\u751F\u5728\u7C4D\u6570\u201D http:\/\/t.co\/3QeLETT3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hatena.ne.jp\/guide\/twitter\" rel=\"nofollow\"\u003EHatena\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http:\/\/t.co\/3QeLETT3",
        "expanded_url" : "http:\/\/htn.to\/wpXXB1",
        "display_url" : "htn.to\/wpXXB1"
      } ]
    },
    "geo" : { },
    "id_str" : "225579194971725824",
    "text" : "\u201C\u5404\u6388\u696D\u306E\u5E73\u5747\u5B66\u751F\u5728\u7C4D\u6570\u201D http:\/\/t.co\/3QeLETT3",
    "id" : 225579194971725824,
    "created_at" : "2012-07-18 13:14:05 +0000",
    "user" : {
      "name" : "(\u3086\u03C9\u30FC)\u3327@\u6843",
      "screen_name" : "yuton",
      "protected" : true,
      "id_str" : "15597112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2528372726\/shimizu-l00_normal.jpg",
      "id" : 15597112,
      "verified" : false
    }
  },
  "id" : 225579711856771074,
  "created_at" : "2012-07-18 13:16:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u63D0\u7763\u306F\u3057\u3051\u3093*\u30D0\u30B1\u30C4\u5099\u84C4",
      "screen_name" : "hashiken716",
      "indices" : [ 18, 30 ],
      "id_str" : "100018219",
      "id" : 100018219
    }, {
      "name" : "\u306A\u3063\u3064\u304D\u306E\u307F",
      "screen_name" : "downy_821",
      "indices" : [ 31, 41 ],
      "id_str" : "287541933",
      "id" : 287541933
    }, {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 42, 52 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225579180652380161",
  "text" : ". @setsuna0321118 @hashiken716 @downy_821 @eclair_15 \u304A\u304B\u3042\u308A\u3067\u3057\u305F\u30FC",
  "id" : 225579180652380161,
  "created_at" : "2012-07-18 13:14:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225578770336190465",
  "text" : "\u304D\u3063\u305F\u304F\u3045\u30FC\uFF3E\uFF3E",
  "id" : 225578770336190465,
  "created_at" : "2012-07-18 13:12:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225524391461654528",
  "text" : "\u540C\u6642\u9032\u884C\u3067\u4F5C\u308B\u306E\u306B10\u5206\u5207\u308B\u304B\u3089\u52B9\u7387\u3088\u3055\u3052\u3067\u3044\u3044\u611F\u3058",
  "id" : 225524391461654528,
  "created_at" : "2012-07-18 09:36:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225524287115759616",
  "text" : "\u3086\u3067\u5375\u3068\u30D4\u30B6\u30C8\u30FC\u30B9\u30C8\u7F8E\u5473\u3057\u304B\u3063\u305F",
  "id" : 225524287115759616,
  "created_at" : "2012-07-18 09:35:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225512789719007232",
  "text" : "4\u00D74\u00D74\u306E\u30EB\u30FC\u30D3\u30C3\u30AF\u30AD\u30E5\u30FC\u30D6\u306A\u30893\u00D73\u30925\u9762\u63C3\u3048\u3089\u308C\u308B\u304B\u306A",
  "id" : 225512789719007232,
  "created_at" : "2012-07-18 08:50:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225512681845698561",
  "text" : "\u305D\u306E\u767A\u60F3\u306F\u306A\u304B\u3063\u305F\u3002\u504F\u898B\u3060\u3063\u305F\u3002",
  "id" : 225512681845698561,
  "created_at" : "2012-07-18 08:49:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3061\u3087\u3046",
      "screen_name" : "ichyo",
      "indices" : [ 3, 9 ],
      "id_str" : "64091783",
      "id" : 64091783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225512419374538752",
  "text" : "RT @ichyo: \u30EB\u30FC\u30D3\u30C3\u30AF\u30AD\u30E5\u30FC\u30D6\u306E\u9762\u304C6\u8272\u3057\u304B\u306A\u3044\u3068\u3044\u3046\u56FA\u5B9A\u89B3\u5FF5\u3092\u6368\u3066\u308B\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225512292685586432",
    "text" : "\u30EB\u30FC\u30D3\u30C3\u30AF\u30AD\u30E5\u30FC\u30D6\u306E\u9762\u304C6\u8272\u3057\u304B\u306A\u3044\u3068\u3044\u3046\u56FA\u5B9A\u89B3\u5FF5\u3092\u6368\u3066\u308B\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u308B",
    "id" : 225512292685586432,
    "created_at" : "2012-07-18 08:48:15 +0000",
    "user" : {
      "name" : "\u3044\u3061\u3087\u3046",
      "screen_name" : "ichyo",
      "protected" : false,
      "id_str" : "64091783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2257450221\/Donut_120x120_normal.gif",
      "id" : 64091783,
      "verified" : false
    }
  },
  "id" : 225512419374538752,
  "created_at" : "2012-07-18 08:48:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3057\u30FC",
      "screen_name" : "oPAKILAo",
      "indices" : [ 0, 9 ],
      "id_str" : "547544213",
      "id" : 547544213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225511954268160000",
  "geo" : { },
  "id_str" : "225512183126175744",
  "in_reply_to_user_id" : 547544213,
  "text" : "@oPAKILAo \u306A\u3093\u3067\u3082\u30B5\u30A4\u30BA\u304C\u5927\u304D\u3044\u3082\u306E\u306F\u5927\u5473\u306B\u306A\u308A\u3084\u3059\u3044\u3068\u304B",
  "id" : 225512183126175744,
  "in_reply_to_status_id" : 225511954268160000,
  "created_at" : "2012-07-18 08:47:48 +0000",
  "in_reply_to_screen_name" : "oPAKILAo",
  "in_reply_to_user_id_str" : "547544213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3057\u30FC",
      "screen_name" : "oPAKILAo",
      "indices" : [ 0, 9 ],
      "id_str" : "547544213",
      "id" : 547544213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225511590160633856",
  "geo" : { },
  "id_str" : "225511737292632064",
  "in_reply_to_user_id" : 547544213,
  "text" : "@oPAKILAo \u5927\u304D\u3044\u3082\u306E\u3060\u3068\u304A\u5473\u564C\u6C41\u306B\u3044\u308C\u305F\u308A\u3057\u307E\u3059\u306D\u30FC",
  "id" : 225511737292632064,
  "in_reply_to_status_id" : 225511590160633856,
  "created_at" : "2012-07-18 08:46:02 +0000",
  "in_reply_to_screen_name" : "oPAKILAo",
  "in_reply_to_user_id_str" : "547544213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225510884078923776",
  "text" : "\u30EB\u30FC\u30D3\u30C3\u30AF\u30AD\u30E5\u30FC\u30D65\u9762\u3060\u3051\u63C3\u3048\u308B\u3063\u3066\u60AA\u9B54\u306E\u6240\u696D",
  "id" : 225510884078923776,
  "created_at" : "2012-07-18 08:42:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225509391472918528",
  "geo" : { },
  "id_str" : "225509592803704833",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u306B\u307B\u3093\u3054\u3067",
  "id" : 225509592803704833,
  "in_reply_to_status_id" : 225509391472918528,
  "created_at" : "2012-07-18 08:37:31 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225508805130194944",
  "text" : "\u306A\u308B\u307B\u3069\u30FC",
  "id" : 225508805130194944,
  "created_at" : "2012-07-18 08:34:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225507695128608768",
  "text" : "\u30DC\u30B1\u306B\u5BFE\u3059\u308B\u30C4\u30C3\u30B3\u30DF\u306A\u3093\u304B\u306F\u304B\u306A\u308A\u6709\u7528\u306A\u306E\u304B\u306A\u3002\u305D\u308C\u3067\u30822\u56DE\u4F4D\u3067\u843D\u3068\u305B\u3088\u3068\u601D\u3046\u3051\u308C\u3069\u3002",
  "id" : 225507695128608768,
  "created_at" : "2012-07-18 08:29:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225506726210834432",
  "text" : "\u50D5\u500B\u4EBA\u306F\u6C17\u306B\u306A\u308B\u4F1A\u8A71\u306F\u5272\u3068\u9762\u5012\u304C\u304C\u3089\u305A\u306B\u8FD4\u4FE1\u5143\u8FFD\u3046\u3051\u3069\u2026",
  "id" : 225506726210834432,
  "created_at" : "2012-07-18 08:26:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225505928240312320",
  "text" : "\u4E0A\u667A\u304C\u6848\u5916\u30A2\u30EC",
  "id" : 225505928240312320,
  "created_at" : "2012-07-18 08:22:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E16\u754C\u306E\u3086\u3046\u304D\u307F\u305A\u305F\u306B",
      "screen_name" : "ho_nancho_yuki",
      "indices" : [ 3, 18 ],
      "id_str" : "156918588",
      "id" : 156918588
    }, {
      "name" : "\u3079\u30FC\u3055\u3093",
      "screen_name" : "allabeeee",
      "indices" : [ 35, 45 ],
      "id_str" : "244864921",
      "id" : 244864921
    }, {
      "name" : "takahiro sugita",
      "screen_name" : "gisutagisu",
      "indices" : [ 48, 59 ],
      "id_str" : "202216750",
      "id" : 202216750
    }, {
      "name" : "\u3079\u30FC\u3055\u3093",
      "screen_name" : "allabeeee",
      "indices" : [ 61, 71 ],
      "id_str" : "244864921",
      "id" : 244864921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/f7xoNeIS",
      "expanded_url" : "http:\/\/twitter.com\/gisutagisu\/status\/225494973179629569\/photo\/1",
      "display_url" : "pic.twitter.com\/f7xoNeIS"
    } ]
  },
  "geo" : { },
  "id_str" : "225505831515459584",
  "text" : "RT @ho_nancho_yuki: \u4E0A\u667A\u3067\u4E00\u4F53\u306A\u306B\u304C\u8D77\u304D\u3066\u308B\u3093\u3060\u7B11@allabeeee: \u201C@gisutagisu: @allabeeee\u4FFA\u3082\u898B\u305F\u305E\u305D\u3044\u3064(\u7B11) http:\/\/t.co\/f7xoNeIS\u201D\u304F\u305D\u304A\u3082\u308D\u3044\u7B11\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3079\u30FC\u3055\u3093",
        "screen_name" : "allabeeee",
        "indices" : [ 15, 25 ],
        "id_str" : "244864921",
        "id" : 244864921
      }, {
        "name" : "takahiro sugita",
        "screen_name" : "gisutagisu",
        "indices" : [ 28, 39 ],
        "id_str" : "202216750",
        "id" : 202216750
      }, {
        "name" : "\u3079\u30FC\u3055\u3093",
        "screen_name" : "allabeeee",
        "indices" : [ 41, 51 ],
        "id_str" : "244864921",
        "id" : 244864921
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/f7xoNeIS",
        "expanded_url" : "http:\/\/twitter.com\/gisutagisu\/status\/225494973179629569\/photo\/1",
        "display_url" : "pic.twitter.com\/f7xoNeIS"
      } ]
    },
    "geo" : { },
    "id_str" : "225499801175855104",
    "text" : "\u4E0A\u667A\u3067\u4E00\u4F53\u306A\u306B\u304C\u8D77\u304D\u3066\u308B\u3093\u3060\u7B11@allabeeee: \u201C@gisutagisu: @allabeeee\u4FFA\u3082\u898B\u305F\u305E\u305D\u3044\u3064(\u7B11) http:\/\/t.co\/f7xoNeIS\u201D\u304F\u305D\u304A\u3082\u308D\u3044\u7B11\u201D",
    "id" : 225499801175855104,
    "created_at" : "2012-07-18 07:58:36 +0000",
    "user" : {
      "name" : "\u4E16\u754C\u306E\u3086\u3046\u304D\u307F\u305A\u305F\u306B",
      "screen_name" : "ho_nancho_yuki",
      "protected" : false,
      "id_str" : "156918588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1253549666\/profile_normal.jpg",
      "id" : 156918588,
      "verified" : false
    }
  },
  "id" : 225505831515459584,
  "created_at" : "2012-07-18 08:22:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3093\u3071\u3093",
      "screen_name" : "anpanmg",
      "indices" : [ 3, 11 ],
      "id_str" : "192015527",
      "id" : 192015527
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/anpanmg\/status\/225492454713991168\/photo\/1",
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/ZM7YWwZl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyEcMV8CIAAvzpB.jpg",
      "id_str" : "225492454718185472",
      "id" : 225492454718185472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyEcMV8CIAAvzpB.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZM7YWwZl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225505807490490371",
  "text" : "RT @anpanmg: \u6355\u307E\u3063\u305F\u30FCw http:\/\/t.co\/ZM7YWwZl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/anpanmg\/status\/225492454713991168\/photo\/1",
        "indices" : [ 7, 27 ],
        "url" : "http:\/\/t.co\/ZM7YWwZl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AyEcMV8CIAAvzpB.jpg",
        "id_str" : "225492454718185472",
        "id" : 225492454718185472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyEcMV8CIAAvzpB.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZM7YWwZl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225492454713991168",
    "text" : "\u6355\u307E\u3063\u305F\u30FCw http:\/\/t.co\/ZM7YWwZl",
    "id" : 225492454713991168,
    "created_at" : "2012-07-18 07:29:26 +0000",
    "user" : {
      "name" : "\u3042\u3093\u3071\u3093",
      "screen_name" : "anpanmg",
      "protected" : false,
      "id_str" : "192015527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492568002336788480\/U0X4SFWP_normal.jpeg",
      "id" : 192015527,
      "verified" : false
    }
  },
  "id" : 225505807490490371,
  "created_at" : "2012-07-18 08:22:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3093\u3071\u3093",
      "screen_name" : "anpanmg",
      "indices" : [ 3, 11 ],
      "id_str" : "192015527",
      "id" : 192015527
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/anpanmg\/status\/225492335906136064\/photo\/1",
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/2et3XzoC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyEcFbWCIAEbgO9.jpg",
      "id_str" : "225492335910330369",
      "id" : 225492335910330369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyEcFbWCIAEbgO9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2et3XzoC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225505799999463424",
  "text" : "RT @anpanmg: \u30BD\u30D5\u30A3\u30A2\u30F3\u306E\u65E5\u5E38...\u7B11 http:\/\/t.co\/2et3XzoC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/anpanmg\/status\/225492335906136064\/photo\/1",
        "indices" : [ 13, 33 ],
        "url" : "http:\/\/t.co\/2et3XzoC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AyEcFbWCIAEbgO9.jpg",
        "id_str" : "225492335910330369",
        "id" : 225492335910330369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyEcFbWCIAEbgO9.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2et3XzoC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225492335906136064",
    "text" : "\u30BD\u30D5\u30A3\u30A2\u30F3\u306E\u65E5\u5E38...\u7B11 http:\/\/t.co\/2et3XzoC",
    "id" : 225492335906136064,
    "created_at" : "2012-07-18 07:28:57 +0000",
    "user" : {
      "name" : "\u3042\u3093\u3071\u3093",
      "screen_name" : "anpanmg",
      "protected" : false,
      "id_str" : "192015527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492568002336788480\/U0X4SFWP_normal.jpeg",
      "id" : 192015527,
      "verified" : false
    }
  },
  "id" : 225505799999463424,
  "created_at" : "2012-07-18 08:22:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225505442057560064",
  "text" : "\u307E\u3041\u307F\u3093\u306A\u306B\u898B\u3066\u3082\u3089\u3044\u305F\u3044\u3068\u3044\u3046\u6C17\u6301\u3061\u306F\u308F\u304B\u308B\u3051\u308C\u3069",
  "id" : 225505442057560064,
  "created_at" : "2012-07-18 08:21:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3057\u30FC",
      "screen_name" : "oPAKILAo",
      "indices" : [ 0, 9 ],
      "id_str" : "547544213",
      "id" : 547544213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225504436703870976",
  "geo" : { },
  "id_str" : "225505197328306177",
  "in_reply_to_user_id" : 547544213,
  "text" : "@oPAKILAo \u30EA\u30D7\u30E9\u30A4\u3058\u3083\u30C0\u30E1\u306A\u3093\u3067\u3059\u304B\u306D\u3047\u3002\u3044\u3084\u3001\u3082\u3061\u308D\u3093\u975E\u516C\u5F0FRT\u3067\u3042\u308B\u3053\u3068\u304C\u5FC5\u8981\u306A\u5834\u5408\u3082\u591A\u3005\u3042\u308A\u307E\u3059\u304C\u3002",
  "id" : 225505197328306177,
  "in_reply_to_status_id" : 225504436703870976,
  "created_at" : "2012-07-18 08:20:03 +0000",
  "in_reply_to_screen_name" : "oPAKILAo",
  "in_reply_to_user_id_str" : "547544213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225504266331226112",
  "text" : "\u4E8C\u91CD\u4EE5\u4E0A\u306E\u975E\u516C\u5F0FRT\u306F\u2026\u2026",
  "id" : 225504266331226112,
  "created_at" : "2012-07-18 08:16:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u308B\u3093 [\u6700\u7D42\u898F\u5236\u30A2\u30AB]",
      "screen_name" : "nisehorrrrrrrn",
      "indices" : [ 0, 15 ],
      "id_str" : "295218654",
      "id" : 295218654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225501955995348992",
  "geo" : { },
  "id_str" : "225502149197578240",
  "in_reply_to_user_id" : 295218654,
  "text" : "@nisehorrrrrrrn \u6D88\u3048\u306A\u3044",
  "id" : 225502149197578240,
  "in_reply_to_status_id" : 225501955995348992,
  "created_at" : "2012-07-18 08:07:56 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrrrn",
  "in_reply_to_user_id_str" : "295218654",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225501292305453057",
  "text" : "\u306B\u305B\u307B\u30FC\u3058\u3083\u306A\u3044\u3093\u3058\u3083\u306A\u3044\uFF1F",
  "id" : 225501292305453057,
  "created_at" : "2012-07-18 08:04:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225501167701082113",
  "text" : "\u7A7A\u8179\u30FC",
  "id" : 225501167701082113,
  "created_at" : "2012-07-18 08:04:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225501168716103682",
  "text" : "\u7121\u70BA",
  "id" : 225501168716103682,
  "created_at" : "2012-07-18 08:04:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225500739244539906",
  "text" : "\u30D6\u30ED\u30C3\u30AF\u6307\u6570\u9AD8\u307E\u3063\u305F\u306E\u3067\u30D6\u30ED\u30C3\u30AF",
  "id" : 225500739244539906,
  "created_at" : "2012-07-18 08:02:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225500392153292803",
  "text" : "\u6EC5\u591A\u306B\u30D6\u30ED\u30C3\u30AF\u3057\u306A\u3044\u3051\u3069",
  "id" : 225500392153292803,
  "created_at" : "2012-07-18 08:00:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225500181506953216",
  "text" : "\u5B89\u5B9A\u3068\u4FE1\u983C\u306E\u30D6\u30ED\u30C3\u30AF",
  "id" : 225500181506953216,
  "created_at" : "2012-07-18 08:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225495447115014145",
  "text" : "@KyoHiiragi \u5916\u56FD\u8A9E\u306F\u60AA\u3044\u4E8B\u3044\u308F\u306A\u3044\u304B\u3089\u51FA\u3066\u304A\u3044\u305F\u65B9\u304C\u3044\u3044\u305C\u2026A\u7FA4\u306F\u3068\u3082\u304B\u304F",
  "id" : 225495447115014145,
  "created_at" : "2012-07-18 07:41:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225494687295881216",
  "text" : "\u50D5\u304C\u8208\u5473\u3042\u308B\u306E\u306F\u3053\u306E\u6388\u696D\u306E\u4E2D\u8EAB\u3058\u3083\u306A\u3044\u3002\u3053\u306E\u6388\u696D\u306E\u5358\u4F4D\u3060\u3002",
  "id" : 225494687295881216,
  "created_at" : "2012-07-18 07:38:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225494006468050944",
  "text" : "@KyoHiiragi \u8208\u5473\u306A\u304F\u3066\u51FA\u5E2D\u53D6\u3089\u306A\u3044\u79D1\u76EE\u306F\u8DB3\u304C\u9060\u306E\u304F\u3088\u306D",
  "id" : 225494006468050944,
  "created_at" : "2012-07-18 07:35:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225493632919154689",
  "text" : "\u4E8C\u30F6\u6708\u3076\u308A\u306B\u6765\u305F\u3089\u3053\u306E\u69D8\u3060\u3088\uFF01",
  "id" : 225493632919154689,
  "created_at" : "2012-07-18 07:34:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225493587410956288",
  "text" : "\u3046\u304A\u30FC\u3001\u30C6\u30B9\u30C8\u304B\u3088\u3046\u304A\u30FC",
  "id" : 225493587410956288,
  "created_at" : "2012-07-18 07:33:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225493369252618240",
  "text" : "\u3048\u3001\u3053\u306E\u6388\u696D\u30C6\u30B9\u30C8\u306A\u3093\u3067\u3059\u304B.",
  "id" : 225493369252618240,
  "created_at" : "2012-07-18 07:33:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225249588066521089",
  "geo" : { },
  "id_str" : "225249886130548737",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u3046\u3044\u3084\u732B\u306E\u6069\u8FD4\u3057\u306B\u6C34\u69FD\u307D\u3044\u3082\u306E\u306B\u5165\u3063\u305F\u30DE\u30BF\u30BF\u30D3\u30BC\u30EA\u30FC\u304C\u51FA\u3066\u304D\u305F\u306E\u3092\u601D\u3044\u51FA\u3057\u305F\u304B\u3089\u898B\u3066\u307F\u308B\u3068\u3044\u3044\u3088",
  "id" : 225249886130548737,
  "in_reply_to_status_id" : 225249588066521089,
  "created_at" : "2012-07-17 15:25:32 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225249071621873668",
  "text" : "\u8A66\u9A13\u671F\u9593\u3092\u306A\u304B\u3063\u305F\u3053\u3068\u306B\u3057\u3066\u5358\u4F4D\u3092\u3042\u3063\u305F\u4E8B\u306B\u3059\u308B\u9B54\u6CD5\u306A\u3044\u306E",
  "id" : 225249071621873668,
  "created_at" : "2012-07-17 15:22:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225247580509048833",
  "text" : "\u3055\u3066\u3001\u30B3\u30FC\u30D2\u30FC\u98F2\u3093\u3067\u30012\u664230\u5206\u307E\u3067\u7720\u308C\u306A\u304B\u3063\u305F\u3089\u304A\u9152\u306E\u3093\u3067\u7121\u7406\u3084\u308A\u5BDD\u308B\u304B",
  "id" : 225247580509048833,
  "created_at" : "2012-07-17 15:16:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 0, 9 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225246286608207874",
  "geo" : { },
  "id_str" : "225246553051377664",
  "in_reply_to_user_id" : 126927392,
  "text" : "@hanaoka_ \u9762\u767D\u3044\u304A\u8A71\u671F\u5F85\u3057\u3066\u307E\u3059\u306D(^^)(^^)(^^)",
  "id" : 225246553051377664,
  "in_reply_to_status_id" : 225246286608207874,
  "created_at" : "2012-07-17 15:12:17 +0000",
  "in_reply_to_screen_name" : "hanaoka_",
  "in_reply_to_user_id_str" : "126927392",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225246211848937472",
  "text" : "\u82B1\u5CA1\u3055\u3093\u4F55\u3084\u3063\u305F\u306E(\u306B\u3084\u306B\u3084",
  "id" : 225246211848937472,
  "created_at" : "2012-07-17 15:10:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225245524046000128",
  "text" : "\u305D\u3046\u3044\u3084\u89AA\u3088\u308A\u4E0A\u306E\u4E16\u4EE3\u306B\u306F\u30C4\u30F3\u30C7\u30EC\u3063\u3066\u8A00\u8449\u306F\u901A\u3058\u306A\u3044\u3093\u3060\u306A\u3041 \u307F\u3064\u3092",
  "id" : 225245524046000128,
  "created_at" : "2012-07-17 15:08:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225244558118756354",
  "text" : "\u3053\u306E\u6642\u9593\u306B\u2026\u8D77\u304D\u3066\u304B\u3089\u521D\u306E\u30B3\u30FC\u30D2\u30FC\u2026\u3060\u3068\u2026",
  "id" : 225244558118756354,
  "created_at" : "2012-07-17 15:04:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225198260225179650",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 225198260225179650,
  "created_at" : "2012-07-17 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225170168119164928",
  "text" : "\u30B5\u30FC\u30AF\u30EB\u3067\u307C\u3063\u3061\u3063\u3066\u3053\u308C\u3082\u3046\u30B5\u30FC\u30AF\u30EB\u3063\u3058\u3083\u306A\u301C\u3044\u3002\u7DF4\u7FD2\u306B\u306A\u308B\u304B\u3089\u3044\u3044\u3051\u3069\u3002",
  "id" : 225170168119164928,
  "created_at" : "2012-07-17 10:08:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225126027075137536",
  "geo" : { },
  "id_str" : "225132665781747712",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u5727\u5012\u7684\u4E86\u89E3\u3067\u3059",
  "id" : 225132665781747712,
  "in_reply_to_status_id" : 225126027075137536,
  "created_at" : "2012-07-17 07:39:44 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225130719167516672",
  "text" : "\u8AB0\u304B\u6765\u306A\u3044\u304B\u306A\u30FC\u8A66\u9A13\u524D\u3060\u304B\u3089\u602A\u3057\u3044\u304B\u306A(^^)(^^)(^^)",
  "id" : 225130719167516672,
  "created_at" : "2012-07-17 07:32:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/nWNH5JKy",
      "expanded_url" : "http:\/\/4sq.com\/SEib9K",
      "display_url" : "4sq.com\/SEib9K"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "225124809363824641",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/nWNH5JKy",
  "id" : 225124809363824641,
  "created_at" : "2012-07-17 07:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225124711976275968",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u4ECA\u65E5\u6765\u307E\u305B\u3093\uFF1F\u306A\u306B\u3084\u3089\u304A\u8CA1\u5E03\u5FD8\u308C\u305F\u6642\u306E\u7CBE\u7B97\u304C\u3046\u3093\u306C\u3093",
  "id" : 225124711976275968,
  "created_at" : "2012-07-17 07:08:08 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225101880592830464",
  "text" : "\u307E\u305F\u4F1A\u3048\u308B\u306D\u30D1\u30D5\u30A7\u306A\u30FC",
  "id" : 225101880592830464,
  "created_at" : "2012-07-17 05:37:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225094509598474241",
  "text" : "\u3046\u306A\u304E\u305F\u3079\u305F\u3044",
  "id" : 225094509598474241,
  "created_at" : "2012-07-17 05:08:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225046164368654336",
  "text" : "@i_horse \u3069\u3046\u305B\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u308B",
  "id" : 225046164368654336,
  "created_at" : "2012-07-17 01:56:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225045739213033472",
  "text" : "\u3053\u306E\u6691\u3044\u306E\u306B\u30E9\u30FC\u30E1\u30F3\u4F5C\u308B\u304B",
  "id" : 225045739213033472,
  "created_at" : "2012-07-17 01:54:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224888870007865345",
  "text" : "\u6570\u5B66\u7684\u306A\u6982\u5FF5\u3092\u63CF\u3044\u305F\u3082\u306E\u306F\u82B8\u8853\u305F\u308A\u5F97\u308B\u304B",
  "id" : 224888870007865345,
  "created_at" : "2012-07-16 15:30:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224867533851860993",
  "text" : "\u3044\u3093\u3067\u3043\u307A\u3093\u3067\u3093\u3068\u3042\u3093\u3069\u3042\u3044\u3067\u3093\u3066\u3043\u304B\u308A\u30FC\u3067\u3043\u3059\u3068\u308A\u3073\u3085\u30FC\u3066\u3063\u3069\u306A\u3093\u3060\u3051\u3069\u306D",
  "id" : 224867533851860993,
  "created_at" : "2012-07-16 14:06:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224867347100483584",
  "text" : "iid\u304B\u3089\u6EA2\u308C\u51FA\u308B\u5F10\u5BFA\u611F",
  "id" : 224867347100483584,
  "created_at" : "2012-07-16 14:05:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306A\u3089\u306A\u3044",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224866667740672001",
  "text" : "\u3042\u3068\u304C\u304D\u306B\u30AA\u30C1\u3092\u3064\u3051\u308B\u2026\u30EC\u30DD\u30FC\u30C8\u3084\u308B\u306E\u304C\u697D\u3057\u304F #\u306A\u3089\u306A\u3044",
  "id" : 224866667740672001,
  "created_at" : "2012-07-16 14:02:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224866527810301953",
  "text" : "\u304A\u5F8C\u304C\u3088\u308D\u3057\u3044\u3088\u3046\u3067\u3002\u3063\u3066\u30EC\u30DD\u30FC\u30C8\u306E\u6700\u5F8C\u306B\u66F8\u304D\u305F\u3044\u3002",
  "id" : 224866527810301953,
  "created_at" : "2012-07-16 14:02:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224866146497736705",
  "text" : "\u8A00\u3044\u305F\u3044",
  "id" : 224866146497736705,
  "created_at" : "2012-07-16 14:00:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "indices" : [ 3, 12 ],
      "id_str" : "407863488",
      "id" : 407863488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224866124297285632",
  "text" : "RT @phyzyuya: \u30EC\u30DD\u30FC\u30C8\u306B\u300C\u3064\u307E\u3093\u306D\u30FC\u3053\u3068\u805E\u304F\u306A\u3088\u300D\u3063\u3066\u8A00\u3044\u305F\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224865813717450752",
    "text" : "\u30EC\u30DD\u30FC\u30C8\u306B\u300C\u3064\u307E\u3093\u306D\u30FC\u3053\u3068\u805E\u304F\u306A\u3088\u300D\u3063\u3066\u8A00\u3044\u305F\u3044\u3002",
    "id" : 224865813717450752,
    "created_at" : "2012-07-16 13:59:22 +0000",
    "user" : {
      "name" : "\u67CA\u30B7\u30CE\u30A2\u3061\u3083\u3093\u306B\u8E0F\u307E\u308C\u968A",
      "screen_name" : "phyzyuya",
      "protected" : false,
      "id_str" : "407863488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595297314069065728\/6-fnYpsa_normal.jpg",
      "id" : 407863488,
      "verified" : false
    }
  },
  "id" : 224866124297285632,
  "created_at" : "2012-07-16 14:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224857109517447168",
  "geo" : { },
  "id_str" : "224857265591685120",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u306A\u306B\u305D\u308C\u304D\u307E\u305A\u3044",
  "id" : 224857265591685120,
  "in_reply_to_status_id" : 224857109517447168,
  "created_at" : "2012-07-16 13:25:24 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224855912635039744",
  "text" : "\u307E\u3041\u3084\u308B\u3057\u304B\u306A\u3044",
  "id" : 224855912635039744,
  "created_at" : "2012-07-16 13:20:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224855559562731521",
  "text" : "\u6570\u5B66\u3067\u304D\u306A\u3044\u72B6\u614B\u304B\u3089\u8131\u3057\u305F\u3044\u2026",
  "id" : 224855559562731521,
  "created_at" : "2012-07-16 13:18:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224854017191313409",
  "geo" : { },
  "id_str" : "224855241303142400",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u79C1\u60C5\u3092\u631F\u3080\u306A\u6B69\u3051\u6B69\u3051",
  "id" : 224855241303142400,
  "in_reply_to_status_id" : 224854017191313409,
  "created_at" : "2012-07-16 13:17:21 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224851955648958465",
  "text" : "@setsuna0321118 \u304A\u306F\u3042\u308A\u3067\u3057\u305F\u30FC\uFF01",
  "id" : 224851955648958465,
  "created_at" : "2012-07-16 13:04:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224842519136047104",
  "text" : "@KyoHiiragi \u3042\u30FC\uFF0C\u3054\u3081\u3093\u306D\uFF0C\u5225\u306B\u6012\u3063\u3066\u308B\u308F\u3051\u3058\u3083\u306A\u3044\u3093\u3060\u3088\uFF0E\u306A\u3093\u304B\u304B\u307F\u5408\u308F\u306A\u3044\u306A\u30FC\u3068\u601D\u3063\u305F\u3060\u3051\u3067\uFF0E",
  "id" : 224842519136047104,
  "created_at" : "2012-07-16 12:26:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224839721849864192",
  "text" : "\u3093\u30FC\uFF0C\u3069\u3046\u3082\u4F1A\u8A71\u304C\u304B\u307F\u5408\u308F\u306A\u3044\u306A...",
  "id" : 224839721849864192,
  "created_at" : "2012-07-16 12:15:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224839035468787713",
  "text" : "@KyoHiiragi \u3048...?",
  "id" : 224839035468787713,
  "created_at" : "2012-07-16 12:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224837513917890561",
  "text" : "@KyoHiiragi \u300C2012\u5E747\u670816\u65E5\u306E19\u664230\u5206\u306B\uFF0C\u76EE\u899A\u307E\u3057\u306E\u30D9\u30EB\u304C\u9CF4\u308B\u3088\u3046\u306B\u3057\u3066\u304A\u3044\u305F\u3093\u3060\u3051\u308C\u3069\uFF0C\u7D50\u5C40\u8D77\u304D\u305F\u306E\u306F\uFF0C2012\u5E747\u670816\u65E5\u306E21\u6642\u5C11\u3057\u524D\u3060\u3063\u305F\u306A\u30FC\uFF0C\u300D\u3068\u3044\u3063\u305F\u5185\u5BB9\u306E\u30DD\u30B9\u30C8\u3067\u3057\u305F\uFF0E",
  "id" : 224837513917890561,
  "created_at" : "2012-07-16 12:06:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224836746846810113",
  "text" : "19:30\u306B\u76EE\u899A\u307E\u3057\u639B\u3051\u305F\u3093\u3060\u304C\uFF5E\uFF1F",
  "id" : 224836746846810113,
  "created_at" : "2012-07-16 12:03:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224836489735979008",
  "text" : "\u4EEE\u7720\u3059\u308B\u3064\u3082\u308A\u304C\u672C\u7720\u306B\u306A\u308B\u3068\u3053\u308D\u3060\u3063\u305F\uFF0E",
  "id" : 224836489735979008,
  "created_at" : "2012-07-16 12:02:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224779667318652929",
  "text" : "\u3068\u3044\u3046\u304B\u5FD8\u308C\u3066\u3066\u8CB7\u3063\u3066\u304D\u3061\u3083\u3063\u305F\u306E\u306F\u81EA\u5206\u3060\u3063\u305F\uFF0E",
  "id" : 224779667318652929,
  "created_at" : "2012-07-16 08:17:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224779560942698496",
  "text" : "\u4E09\u30C4\u77E2\u30B5\u30A4\u30C0\u30FC1.5L\u3068\u30B9\u30D7\u30E9\u30A4\u30C81.5L\u304C\u540C\u5C45\u3057\u3066\u308B\u3046\u3061\u306E\u51B7\u8535\u5EAB\u306F\u982D\u60AA\u3044\uFF0E",
  "id" : 224779560942698496,
  "created_at" : "2012-07-16 08:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224779323524128768",
  "text" : "\u3068\u3044\u3046\u304B\u51B7\u8535\u5EAB\u306B\u307B\u3068\u3093\u3069\u307E\u3068\u3082\u306A\u98DF\u6750\u304C\u306A\u304B\u3063\u305F\u304B\u3089\u8CB7\u3044\u306B\u884C\u304B\u306A\u304D\u3083\u2026",
  "id" : 224779323524128768,
  "created_at" : "2012-07-16 08:15:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224779074306981888",
  "text" : "\u982D\u786C\u304B\u3063\u305F\uFF0E\u5805\u304B\u3063\u305F\uFF0E",
  "id" : 224779074306981888,
  "created_at" : "2012-07-16 08:14:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224779003939131392",
  "text" : "\u982D\u304C\u3046\u3089\u3084\u307E\u3057\u3044\u4EBA\u306F\u67D4\u3089\u304B\u3044\n\u3063\u3066\u3068\u3053\u308D\u307E\u3067\u8003\u3048\u305F\u3051\u308C\u3069\u5727\u5012\u7684\u610F\u5473\u4E0D\u660E",
  "id" : 224779003939131392,
  "created_at" : "2012-07-16 08:14:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryc",
      "screen_name" : "ryc_db",
      "indices" : [ 3, 10 ],
      "id_str" : "532782737",
      "id" : 532782737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224778887501058048",
  "text" : "RT @ryc_db: \u982D\u304C\u67D4\u3089\u304B\u3044\u4EBA\u306F\u7FA8\u307E\u3057\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224778809935794176",
    "text" : "\u982D\u304C\u67D4\u3089\u304B\u3044\u4EBA\u306F\u7FA8\u307E\u3057\u3044",
    "id" : 224778809935794176,
    "created_at" : "2012-07-16 08:13:39 +0000",
    "user" : {
      "name" : "ryc",
      "screen_name" : "ryc_db",
      "protected" : false,
      "id_str" : "532782737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549218031469985793\/P3HXIaO8_normal.jpeg",
      "id" : 532782737,
      "verified" : false
    }
  },
  "id" : 224778887501058048,
  "created_at" : "2012-07-16 08:13:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224778452954386433",
  "text" : "\u79D8\u8853\u300C\u8FD4\u3057\u306B\u304F\u3044\u30EA\u30D7\u30E9\u30A4\u3092\u3075\u3041\u307C\u308B\u3053\u3068\u3067\u304A\u8336\u3092\u6FC1\u3059\u300D",
  "id" : 224778452954386433,
  "created_at" : "2012-07-16 08:12:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224777828787437568",
  "text" : "\u9006\u3060\u3063\u305F\u3051\u3069\u3053\u308C\u5B9F\u969B\u8A00\u3063\u3066\u898B\u308B\u3068\u304A\u306A\u304B\u3078\u3063\u305F\u96F0\u56F2\u6C17\u3092\u3060\u3057\u306A\u304C\u3089\u30C1\u30E9\u30C3\u30C1\u30E9\u30C3\u3063\u3066\u8A00\u3046\u306E\u3059\u3054\u304F\u982D\u60AA\u3044",
  "id" : 224777828787437568,
  "created_at" : "2012-07-16 08:09:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224777662219038720",
  "text" : "\u300C\uFF81\uFF97\uFF6F!!!\uFF81\uFF97\uFF6F!!!\uFF08\uFF75\uFF85\uFF76\uFF8D\uFF6F\uFF80\u300D",
  "id" : 224777662219038720,
  "created_at" : "2012-07-16 08:09:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224777543830618112",
  "text" : "\uFF8B\uFF9E\uFF78\uFF6F\u3063\u3066\u306A\u3063\u305F\u5206\u306E\u30A8\u30CD\u30EB\u30AE\u30FC\u8FD4\u3057\u3066\u307B\u3057\u3044\uFF0E\u5177\u4F53\u7684\u306B\u306F\u304A\u8179\u6E1B\u3063\u305F\uFF0E",
  "id" : 224777543830618112,
  "created_at" : "2012-07-16 08:08:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224777395482267648",
  "text" : "\u866B\u306E\u306F\u3070\u305F\u304F\u97F3\u304C\u3057\u305F\u6C17\u304C\u3057\u3066\u30C9\u30AD\u30C3\u3068\u3057\u305F\u304C\u5916\u3067\u304A\u3063\u3055\u3093\u304C\u6B4C\u3063\u3066\u308B\u3060\u3051\u3060\u3063\u305F\uFF08\u3057\u308D\u3081",
  "id" : 224777395482267648,
  "created_at" : "2012-07-16 08:08:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224776412014456832",
  "text" : "\u8D85\u5149\u901F\u6669\u5FA1\u98EF",
  "id" : 224776412014456832,
  "created_at" : "2012-07-16 08:04:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224776358243467265",
  "text" : "\u3067\u30825\u6642\u306B\u304A\u5915\u98EF\u306F\u5149\u3088\u308A\u306F\u3084\u3044\u3088\u306A\u30FC",
  "id" : 224776358243467265,
  "created_at" : "2012-07-16 08:03:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224776096355319808",
  "text" : "\u306A\u3093\u304B\u3053\u3046(^^)\u304A\u8179\u306B\u9055\u548C\u611F\u304C\u3042\u308B\u306A\u30FC(^^)\u3068\u601D\u3063\u305F\u3089\u304A\u663C(^^)\u3054\u98EF\u98DF\u3079\u3066\u306A\u304B\u3063\u305F(^^)(^^)(^^)(^^)(^^)",
  "id" : 224776096355319808,
  "created_at" : "2012-07-16 08:02:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224774760960233472",
  "text" : "\u3053\u3061\u3068\u3089\u30AF\u30E9\u30B7\u30B9\u898B\u308B\u697D\u3057\u307F\u3068\u8A00\u3063\u305F\u3089\u4F11\u8B1B\u304F\u3089\u3044\u306A\u3093\u3060\u304B\u3089\u3055",
  "id" : 224774760960233472,
  "created_at" : "2012-07-16 07:57:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224774551089856512",
  "text" : "\u4F55\u3067\u4F11\u8B1B\u3067\u3066\u306A\u3044\u306E\uFF1F\uFF01\u30D7\u30E9\u30C1\u30CA\u3080\u304B\u3064\u304F",
  "id" : 224774551089856512,
  "created_at" : "2012-07-16 07:56:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224769780094218241",
  "text" : "\u3066\u8A00\u3046\u304B\u3053\u308C\u56DE\u907F\u3067\u304D\u3066\u306A\u3044",
  "id" : 224769780094218241,
  "created_at" : "2012-07-16 07:37:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224769726478434304",
  "text" : "\u3067\u3082\u30B4\u30DF\u304C\u3080\u3063\u3061\u3083\u51FA\u305F\u304B\u3089\u30C6\u30B9\u30C8\u524D\u6052\u4F8B\u306E\u6383\u9664\u3057\u305F\u304F\u306A\u308B\u73FE\u8C61\u3092\u56DE\u907F\u3059\u308B\u305F\u3081\u306B\u4ECA\u304B\u3089\u6383\u9664\u3059\u308B\uFF0E",
  "id" : 224769726478434304,
  "created_at" : "2012-07-16 07:37:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224769607569903616",
  "text" : "\u30E9\u30A4\u30C8\u3068\u6247\u98A8\u6A5F\u3068\u5C4A\u3044\u3066\u3044\u308D\u3044\u308D\u6357\u308A\u305D\u3046",
  "id" : 224769607569903616,
  "created_at" : "2012-07-16 07:37:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224749440819412992",
  "text" : "\u9006\u5E7B\u60F3",
  "id" : 224749440819412992,
  "created_at" : "2012-07-16 06:16:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224747447509983233",
  "text" : "\u3080\u3046\u3002Amazon\u304B\u3089\u8377\u7269\u5C4A\u3044\u305F\u3089\u663C\u5BDD\u3057\u305F\u3044\u3093\u3060\u304C\u307E\u3060\u5C4A\u304B\u306A\u3044\u3002",
  "id" : 224747447509983233,
  "created_at" : "2012-07-16 06:09:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224746888308600832",
  "text" : "\u03C0\u2260\u221A10",
  "id" : 224746888308600832,
  "created_at" : "2012-07-16 06:06:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224718691944763392",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u306F\u5348\u524D\u4E2D\u3060\u3051\u3068\u8A00\u3063\u305F\u306A\u3001\u3042\u308C\u306F\u5618\u3060\u3002",
  "id" : 224718691944763392,
  "created_at" : "2012-07-16 04:14:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224708595600736256",
  "text" : "\u308F\u304B\u3089\u3093\u307D\u3049\u3049\u304A\u3093",
  "id" : 224708595600736256,
  "created_at" : "2012-07-16 03:34:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224706664115347457",
  "text" : "\u53C2\u3063\u305F\u306A\u30FC",
  "id" : 224706664115347457,
  "created_at" : "2012-07-16 03:26:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224695675349254146",
  "text" : "\u8D85\u3001\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B",
  "id" : 224695675349254146,
  "created_at" : "2012-07-16 02:43:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224695543954276354",
  "text" : "\u305D\u3046\u3044\u3084\u6628\u65E5\u3001\u8D85\u70AD\u9178\u6C34100\u5186\u3063\u3066\u306E\u304C\u3042\u3063\u305F\u304B\u3089\u8CB7\u3063\u3066\u307F\u305F\u3093\u3060\u3051\u308C\u3069\u3001\u4F55\u306E\u4E8B\u306F\u306A\u3044\u53EA\u306E\u70AD\u9178\u6C34\u3060\u3063\u305F",
  "id" : 224695543954276354,
  "created_at" : "2012-07-16 02:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224667232997883904",
  "text" : "\u677F\u30C1\u30E7\u30B3\u306F\u51CD\u3089\u305B\u308B\u3068\u30D1\u30AD\u30C3\u3066\u306A\u3063\u3066\u5FC3\u5730\u3088\u3044",
  "id" : 224667232997883904,
  "created_at" : "2012-07-16 00:50:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224666989770190849",
  "text" : "\u81BF\u306E\u65E5\u3063\u3066\u3044\u3046\u3068\u30D3\u30E7\u30A6\u30AD\u30E1\u30A4\u30C6\u30EB",
  "id" : 224666989770190849,
  "created_at" : "2012-07-16 00:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224666852767432705",
  "text" : "\u30C1\u30E7\u30B3\u98DF\u3079\u305F\u304B\u3063\u305F\u3089\u677F\u30C1\u30E7\u30B3\u8CB7\u3048\u3088\u3002\u8AD6\u70B9\u304C\u305A\u308C\u3066\u3044\u308B\u3002",
  "id" : 224666852767432705,
  "created_at" : "2012-07-16 00:48:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TATA.@10th\uFF1E\u53D7\u9A13",
      "screen_name" : "TATT679",
      "indices" : [ 3, 11 ],
      "id_str" : "500490691",
      "id" : 500490691
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TATT679\/status\/216498803937783808\/photo\/1",
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/rq9OcRp8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwEog98CMAIWRSt.jpg",
      "id_str" : "216498803937783810",
      "id" : 216498803937783810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwEog98CMAIWRSt.jpg",
      "sizes" : [ {
        "h" : 309,
        "resize" : "fit",
        "w" : 549
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 549
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 549
      } ],
      "display_url" : "pic.twitter.com\/rq9OcRp8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224666756348776448",
  "text" : "RT @TATT679: \u3060\u308C\u3082\u77E5\u3089\u306A\u304B\u3063\u305F\u4E8B\u5B9F\u2026 http:\/\/t.co\/rq9OcRp8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TATT679\/status\/216498803937783808\/photo\/1",
        "indices" : [ 13, 33 ],
        "url" : "http:\/\/t.co\/rq9OcRp8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AwEog98CMAIWRSt.jpg",
        "id_str" : "216498803937783810",
        "id" : 216498803937783810,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwEog98CMAIWRSt.jpg",
        "sizes" : [ {
          "h" : 309,
          "resize" : "fit",
          "w" : 549
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 549
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 549
        } ],
        "display_url" : "pic.twitter.com\/rq9OcRp8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216498803937783808",
    "text" : "\u3060\u308C\u3082\u77E5\u3089\u306A\u304B\u3063\u305F\u4E8B\u5B9F\u2026 http:\/\/t.co\/rq9OcRp8",
    "id" : 216498803937783808,
    "created_at" : "2012-06-23 11:51:52 +0000",
    "user" : {
      "name" : "TATA.@10th\uFF1E\u53D7\u9A13",
      "screen_name" : "TATT679",
      "protected" : false,
      "id_str" : "500490691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482835519168983040\/RZjROtsS_normal.jpeg",
      "id" : 500490691,
      "verified" : false
    }
  },
  "id" : 224666756348776448,
  "created_at" : "2012-07-16 00:48:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224666653068234754",
  "text" : "\u722A\u5C06\u68CB\u3063\u3066\u3044\u3046\u3068\u30AA\u30AB\u30EB\u30C8\u30E1\u30A4\u30C6\u30EB",
  "id" : 224666653068234754,
  "created_at" : "2012-07-16 00:47:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224666070689120256",
  "text" : "\u722A\u5207\u308B",
  "id" : 224666070689120256,
  "created_at" : "2012-07-16 00:45:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224640146681774081",
  "text" : "\u307E\u30608\u6642\uFF0E\u65E9\u8D77\u304D\u306F\u4E00\u65E5\u304C\u9577\u304F\u3066\u30A4\u30A4\u30CD\u30FC\uFF0E\u307E\u3041\u305F\u3076\u3093\u663C\u5BDD\u3059\u308B\u3051\u308C\u3069\uFF0E",
  "id" : 224640146681774081,
  "created_at" : "2012-07-15 23:02:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224639692652556288",
  "text" : "\u6708\u706B\u3061\u3083\u3093\u306E\u30CD\u30BF\u3060\u3063\u305F\u304B\u306A",
  "id" : 224639692652556288,
  "created_at" : "2012-07-15 23:00:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224639634444005376",
  "text" : "\u7D20\u6575\uFF0E\u7D20\u3067\u6575\uFF0E",
  "id" : 224639634444005376,
  "created_at" : "2012-07-15 23:00:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224639525165608961",
  "text" : "\u6247\u98A8\u6A5F\u306F\u3088\u5C4A\u3051",
  "id" : 224639525165608961,
  "created_at" : "2012-07-15 23:00:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224639461680627712",
  "text" : "\u590F\u306A\u306E\u306B\u3075\u3086\u304B\u3044",
  "id" : 224639461680627712,
  "created_at" : "2012-07-15 22:59:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224639393355415552",
  "text" : "\u6674\u308C\u6674\u308C\u4E0D\u6109\u5FEB",
  "id" : 224639393355415552,
  "created_at" : "2012-07-15 22:59:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224632339412692994",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u304B\u3089\u8D77\u304D\u3066\u3044\u308B",
  "id" : 224632339412692994,
  "created_at" : "2012-07-15 22:31:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224632031873740800",
  "text" : "\u6D74\u3073\u308B\u3088\u3046\u306B\u98F2\u3093\u3067\u308B\u3002\u5348\u524D\u4E2D\u3060\u3051\u3057\u3088\u3046\u3002",
  "id" : 224632031873740800,
  "created_at" : "2012-07-15 22:30:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224631928769347587",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u304C\u8DB3\u308A\u306A\u3044\uFF01\uFF01\uFF01",
  "id" : 224631928769347587,
  "created_at" : "2012-07-15 22:29:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/hgelmxTx",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/14?prefill=r_sixess",
      "display_url" : "gohantabeyo.com\/nani\/14?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224600479122984960",
  "text" : "\u3042\u3044\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/hgelmxTx",
  "id" : 224600479122984960,
  "created_at" : "2012-07-15 20:25:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224596187804745728",
  "text" : "\u8D77\u304D\u305F\u3002\u60AA\u304F\u306A\u3044\u3002",
  "id" : 224596187804745728,
  "created_at" : "2012-07-15 20:07:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224503646208016384",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 224503646208016384,
  "created_at" : "2012-07-15 14:00:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224483575590952961",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3063\u3058\u3083\u306A~\u3044",
  "id" : 224483575590952961,
  "created_at" : "2012-07-15 12:40:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224483489280557056",
  "text" : "5\u6642\u307E\u3067\u5BDD\u307E\u3059\u3063\uFF01\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uFF01",
  "id" : 224483489280557056,
  "created_at" : "2012-07-15 12:40:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224483410222125057",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u30FC\uFF1F",
  "id" : 224483410222125057,
  "created_at" : "2012-07-15 12:39:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224483373391949824",
  "text" : "\u7947\u5712\u796D\u306B\u51FA\u304B\u3051\u305F\u306E\u306F\u3084\u3063\u3071\u5931\u6557\u3060\u3063\u305F\u306A\uFF0E\u75B2\u308C\u3066\u7720\u3044\uFF0E",
  "id" : 224483373391949824,
  "created_at" : "2012-07-15 12:39:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224389880598364160",
  "text" : "\u30A2\u30AB\u30A6\u30F3\u30C8\u4E57\u3063\u53D6\u308A\u3068\u304B\u60AA\u8CEA\u3045",
  "id" : 224389880598364160,
  "created_at" : "2012-07-15 06:28:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224385980940029952",
  "text" : "\u3044\u307E\u3055\u304B\u306A\u306E\u306A\u304B\u306B\u3044\u308B\u306E\u306F\u307E\u3063\u304F\u308D\u304F\u308D\u3059\u3051\u3089\u3057\u3044",
  "id" : 224385980940029952,
  "created_at" : "2012-07-15 06:12:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224385392986701825",
  "text" : "\u6247\u98A8\u6A5F\u3001\u5353\u4E0A\u30E9\u30A4\u30C8\u3068\u307E\u3068\u3081\u3066\u6CE8\u6587\u3059\u308B\u304B\u30FC\u304A\u91D1\u304C\u304C\u304C\u304C",
  "id" : 224385392986701825,
  "created_at" : "2012-07-15 06:10:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224382964077821952",
  "text" : "\u4F55\u3060\u3053\u308C\u5FD9\u3057\u3044\u306E\u304B\u6687\u306A\u306E\u304B",
  "id" : 224382964077821952,
  "created_at" : "2012-07-15 06:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224376994991837184",
  "text" : "\u6551\u6025\u8ECA\u5E97\u306E\u76EE\u306E\u524D\u3067\u6B62\u307E\u3063\u305F\u304C",
  "id" : 224376994991837184,
  "created_at" : "2012-07-15 05:36:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224375839213633536",
  "text" : "\u304D\u3087\u3046\u306F\u3075\u3041\u307C\u304C\u306F\u304B\u3069\u308B\u306A\u30FC(^^)(^^)(^^)",
  "id" : 224375839213633536,
  "created_at" : "2012-07-15 05:32:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 3, 12 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224375173585977346",
  "text" : "RT @hanaoka_: \uFF88\uFF78\uFF7D\uFF84\uFF7A\uFF85\uFF9D\uFF7D\uFF9E\uFF8B\uFF70\uFF9D\uFF84!!!!!\u300C\u3086\u30D0\u30C3\u30B8\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224374732580061186",
    "text" : "\uFF88\uFF78\uFF7D\uFF84\uFF7A\uFF85\uFF9D\uFF7D\uFF9E\uFF8B\uFF70\uFF9D\uFF84!!!!!\u300C\u3086\u30D0\u30C3\u30B8\u300D",
    "id" : 224374732580061186,
    "created_at" : "2012-07-15 05:27:59 +0000",
    "user" : {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "protected" : false,
      "id_str" : "126927392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540399732707688448\/Iqz4rTVp_normal.jpeg",
      "id" : 126927392,
      "verified" : false
    }
  },
  "id" : 224375173585977346,
  "created_at" : "2012-07-15 05:29:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224373488067158016",
  "text" : "\u3069\u30FC\u308A\u3067\u308D\u3050\u3044\u3093\u3067\u304D\u306A\u3044\u308F\u3051\u3067\u3059\u306D",
  "id" : 224373488067158016,
  "created_at" : "2012-07-15 05:23:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3087\u3093",
      "screen_name" : "myuon_myon",
      "indices" : [ 3, 14 ],
      "id_str" : "580746240",
      "id" : 580746240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224373420475940864",
  "text" : "RT @myuon_myon: \u203BKU\u95A2\u4FC2\u8005\u306E\u65B9 \u6628\u6669\u306E\u5927\u96E8\u3067\u5409\u7530\u5357\u306E\u5730\u4E0B\u96FB\u7B97\u6A5F\u5BA4\u304C\u6F0F\u6C34\u3057\u305F\u305F\u3081\u5168\u5B66\u751F\u5171\u901A\u30DD\u30FC\u30BF\u30EB\u53CA\u3073\u6559\u80B2\u30B7\u30B9\u30C6\u30E0\u304C\u843D\u3061\u3066\u3044\u307E\u3059 \u5FA9\u65E7\u306F\u3044\u3064\u306B\u306A\u308B\u304B\u5206\u304B\u3089\u306A\u3044\u3068\u306E\u3053\u3068\u3067\u3059",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224372926663753729",
    "text" : "\u203BKU\u95A2\u4FC2\u8005\u306E\u65B9 \u6628\u6669\u306E\u5927\u96E8\u3067\u5409\u7530\u5357\u306E\u5730\u4E0B\u96FB\u7B97\u6A5F\u5BA4\u304C\u6F0F\u6C34\u3057\u305F\u305F\u3081\u5168\u5B66\u751F\u5171\u901A\u30DD\u30FC\u30BF\u30EB\u53CA\u3073\u6559\u80B2\u30B7\u30B9\u30C6\u30E0\u304C\u843D\u3061\u3066\u3044\u307E\u3059 \u5FA9\u65E7\u306F\u3044\u3064\u306B\u306A\u308B\u304B\u5206\u304B\u3089\u306A\u3044\u3068\u306E\u3053\u3068\u3067\u3059",
    "id" : 224372926663753729,
    "created_at" : "2012-07-15 05:20:49 +0000",
    "user" : {
      "name" : "\u307F\u3087\u3093",
      "screen_name" : "myuon_myon",
      "protected" : false,
      "id_str" : "580746240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512083963779612672\/U_YivD9X_normal.png",
      "id" : 580746240,
      "verified" : false
    }
  },
  "id" : 224373420475940864,
  "created_at" : "2012-07-15 05:22:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224371398762704897",
  "text" : "\u3075\u3075\u3075",
  "id" : 224371398762704897,
  "created_at" : "2012-07-15 05:14:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/lh1ZDUVq",
      "expanded_url" : "http:\/\/4sq.com\/OG8nIv",
      "display_url" : "4sq.com\/OG8nIv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "224350548382597120",
  "text" : "\u3042\u3051\u305F (@ \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ) http:\/\/t.co\/lh1ZDUVq",
  "id" : 224350548382597120,
  "created_at" : "2012-07-15 03:51:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224323897997266944",
  "text" : "\u30AF\u30E9\u30B7\u30B9\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u306A\u3044\uFF1F",
  "id" : 224323897997266944,
  "created_at" : "2012-07-15 02:05:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224317055057399808",
  "text" : "\u4E8C\u3064\u8FD4\u4E8B\u3067\u7947\u5712\u796D\u306B\u884C\u304F\u3053\u3068\u306B\u306A\u3063\u305F\u3051\u3069\u305F\u3076\u3093\u5F8C\u6094\u3057\u304B\u3057\u306A\u3044\u3093\u3060\u308D\u3046\u306A\u3041",
  "id" : 224317055057399808,
  "created_at" : "2012-07-15 01:38:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224162732583292929",
  "text" : "\u4ECA\u5EA6\u3053\u305D\u672C\u5F53\u306B\u96E2\u8131\uFF0E\u307E\u305F\u306D\uFF0E",
  "id" : 224162732583292929,
  "created_at" : "2012-07-14 15:25:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224162222232961024",
  "text" : "\u306A\u3093\u3060\u304B\u3093\u3060\u3067\u306E\u3046\u3053\u3055\u3093\u306F\u4EBA\u61D0\u3053\u3044\u3088\u306D\u3047",
  "id" : 224162222232961024,
  "created_at" : "2012-07-14 15:23:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224161465593106434",
  "text" : "\uFF08\u7FCC\u671D\u8D77\u304D\u3066\u3053\u306A\u3044\u30D1\u30BF\u30FC\u30F3\uFF09",
  "id" : 224161465593106434,
  "created_at" : "2012-07-14 15:20:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224161419359301632",
  "text" : "\u304F\u305D\u3063\uFF01\u3053\u3093\u306A\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306B\u5C45\u3089\u308C\u308B\u304B\uFF01\u4FFA\u306F\u52C9\u5F37\u306B\u623B\u308B\uFF01",
  "id" : 224161419359301632,
  "created_at" : "2012-07-14 15:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224160778817781762",
  "geo" : { },
  "id_str" : "224160930450255873",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u9D28\u5DDD\u3067\u30D7\u30EA\u30F3\u3092\u4F5C\u308B\uFF4E\u6B21\u4F1A\u304C\u3042\u3063\u305F\u3089\u547C\u3093\u3067\u304F\u3060\u3055\u3044",
  "id" : 224160930450255873,
  "in_reply_to_status_id" : 224160778817781762,
  "created_at" : "2012-07-14 15:18:25 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224160522768101376",
  "text" : "\uFF08\u3057\u304B\u3057\u3066\u53F1\u3089\u308C\u305F\u672C\u4EBA\u304C\u5168\u7136\u53CD\u7701\u3067\u304D\u3066\u3044\u306A\u3044\u306E\u56F3\uFF09",
  "id" : 224160522768101376,
  "created_at" : "2012-07-14 15:16:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224160179971821568",
  "text" : "\u300C\u6BB4\u308B\u3068\u304B\u6016\u3044\u5B57\u9762\u3092\u4E26\u3079\u3064\u3064\u3057\u3063\u304B\u308A\u3075\u3041\u307C\u3063\u3066\u304F\u308B\u3042\u305F\u308A\u306E\u3046\u3053\u3055\u3093\u306E\u30C4\u30F3\u30C7\u30EC\u3063\u3077\u308A\u304C\u4F3A\u3048\u308B\uFF0E\u300D\u3068\u304B\u8A00\u308F\u306A\u3044\u65B9\u304C\u3044\u3044\u3093\u3060\u308D\u3046\u306A\u3041\u2026\u306F\u3063\uFF01",
  "id" : 224160179971821568,
  "created_at" : "2012-07-14 15:15:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224159570707222528",
  "text" : "\u306A\u306B\u304C\u3044\u3051\u306A\u304B\u3063\u305F\u3093\u3060\u308D\u3046\uFF08\u3057\u308D\u3081",
  "id" : 224159570707222528,
  "created_at" : "2012-07-14 15:13:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 12, 23 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224159488263987201",
  "text" : "@9110alice  @noukoknows \u3048\u3063\uFF0C\u3042\u3063\uFF0C\u306F\u3044\uFF0C\u3054\u2026\u3054\u3081\u3093\u306A\u3055\u3044\uFF0E",
  "id" : 224159488263987201,
  "created_at" : "2012-07-14 15:12:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224159047660740608",
  "text" : "\u8A00\u8449\u904A\u3073\u306F\u81EA\u91CD\u3057\u306A\u3044\uFF0E\u81EA\u5632\u306F\u3059\u308B\u3051\u3069\uFF0E",
  "id" : 224159047660740608,
  "created_at" : "2012-07-14 15:10:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224158601961418752",
  "geo" : { },
  "id_str" : "224158709570473984",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u306A\u306B\u3053\u308C\u308A\u3075\u3058\u3093",
  "id" : 224158709570473984,
  "in_reply_to_status_id" : 224158601961418752,
  "created_at" : "2012-07-14 15:09:35 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224158411154137091",
  "text" : "\u6C34\u6238\u9EC4\u9580\u300C\u52A9\u3055\u3093\uFF0C\u62E1\u6563\uFF01\u77E5\u3089\u3057\u3081\u3066\u3084\u308A\u306A\u3055\u3044\uFF01\u300D",
  "id" : 224158411154137091,
  "created_at" : "2012-07-14 15:08:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224158239439323136",
  "text" : "@KyoHiiragi \u307E\u3041\u60B2\u60E8\u3068\u308F\u304B\u3063\u3066\u3084\u308B\u3060\u3051\u7FA8\u307E\u3057\u3044\uFF0E\u3053\u3061\u3068\u3089\u4F55\u306B\u3082\u8003\u3048\u305A\u51CD\u308B\u524D\u306E\u7F8E\u5473\u3057\u3044\u849F\u84BB\u3092\u305D\u3046\u3066\u3044\u3057\u3066\u9F67\u3063\u305F\u3082\u3093\u3060\u304B\u3089\u30C6\u30F3\u30B7\u30E7\u30F3\u306E\u4E0B\u304C\u308A\u5177\u5408\u304C\u30E4\u30D0\u304B\u3063\u305F\uFF0E",
  "id" : 224158239439323136,
  "created_at" : "2012-07-14 15:07:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 11, 22 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224157987382640641",
  "text" : "@9110alice @noukoknows \u97AD\u6253\u3064\u3053\u3068\u306B\u5922\u4E2D\u306E\u306E\u3046\u3053\u3055\u3093",
  "id" : 224157987382640641,
  "created_at" : "2012-07-14 15:06:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224157743030861826",
  "geo" : { },
  "id_str" : "224157794528538624",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u5727\u5012\u7684\u30DE\u30B8\u30EC\u30B9\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 224157794528538624,
  "in_reply_to_status_id" : 224157743030861826,
  "created_at" : "2012-07-14 15:05:57 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224157623212183552",
  "text" : "@KyoHiiragi \u3053\u306E\u6642\u671F\u30B3\u30F3\u30D3\u30CB\u306B\u304A\u3067\u3093\u3063\u3066\u304A\u3044\u3066\u308B\uFF1F\u5E97\u8217\u306B\u4F9D\u308B\u306E\u304B\u77E5\u3089\u3093",
  "id" : 224157623212183552,
  "created_at" : "2012-07-14 15:05:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224157206411620353",
  "text" : "\u307E\u3041\u81EA\u5206\u304C\u4F55\u3092\u3069\u3046\u98DF\u3079\u3088\u3046\u3068\u50D5\u306E\u52DD\u624B\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u30FC\uFF08\uFF8E\uFF9E\uFF7F\uFF6F",
  "id" : 224157206411620353,
  "created_at" : "2012-07-14 15:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224156988823715840",
  "text" : "\u5225 \u306B \u65E5 \u672C \u8A9E \u304C \u8ABF \u5B50 \u304C \u3044 \u3044 \u3068 \u306F \u8A00 \u3063 \u3066 \u3044 \u306A \u3044",
  "id" : 224156988823715840,
  "created_at" : "2012-07-14 15:02:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 9, 17 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224156613785829377",
  "text" : "\u6B64\u51E630\u3075\u3093\u304F\u3089\u3044@shigmax\u3055\u3093\u306E\u30C4\u30A4\u30FC\u30C8\u304C\u30C4\u30DC\u3067\u30C4\u30DC\u3067",
  "id" : 224156613785829377,
  "created_at" : "2012-07-14 15:01:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224156475130511360",
  "text" : "RT @shigmax: \u6182\u3055\u6674\u3089\u3057\u306B\u796D\u3067\u901A\u884C\u4EBA\u306B\u300C\u30C9\u30E9\u30B4\u30F3\u30DC\u30FC\u30EB\u3057\u3088\u3046\u305C\uFF01\uFF01\uFF01\u300D\u3067\u4E00\u767A\u76EE\u306B\u30D3\u30FC\u30E0\u51FA\u3057\u3066\u5343\u5DFB\u6295\u3052\u3064\u3051\u308B\u5ACC\u304C\u3089\u305B\u3092\u601D\u3044\u3064\u3044\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224156419052666881",
    "text" : "\u6182\u3055\u6674\u3089\u3057\u306B\u796D\u3067\u901A\u884C\u4EBA\u306B\u300C\u30C9\u30E9\u30B4\u30F3\u30DC\u30FC\u30EB\u3057\u3088\u3046\u305C\uFF01\uFF01\uFF01\u300D\u3067\u4E00\u767A\u76EE\u306B\u30D3\u30FC\u30E0\u51FA\u3057\u3066\u5343\u5DFB\u6295\u3052\u3064\u3051\u308B\u5ACC\u304C\u3089\u305B\u3092\u601D\u3044\u3064\u3044\u305F",
    "id" : 224156419052666881,
    "created_at" : "2012-07-14 15:00:29 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 224156475130511360,
  "created_at" : "2012-07-14 15:00:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224155758927953922",
  "text" : "\u3042\u308C\u3092\u307E\u305F\u3084\u308C\u308B\u307B\u3069\u50D5\u3089\u306F\u3082\u3046\u82E5\u304F\u306A\u3044\u3093\u3060\u306A\u3041",
  "id" : 224155758927953922,
  "created_at" : "2012-07-14 14:57:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224155670264549377",
  "text" : "RT @shigmax: \u30ED\u30FC\u30AB\u30EB\u30EB\u30FC\u30EB\u3044\u308D\u3044\u308D\u3042\u3063\u305F\u3051\u3069\u3000\u3046\u3061\u306F\u5341\u56DE\u8CAF\u3081\u305F\u3089\u7834\u58CA\u5149\u7DDA\u3067\u76F8\u624B\u3092\u4E00\u6483\u5FC5\u6BBA\u3067\u304D\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224154132276195328",
    "text" : "\u30ED\u30FC\u30AB\u30EB\u30EB\u30FC\u30EB\u3044\u308D\u3044\u308D\u3042\u3063\u305F\u3051\u3069\u3000\u3046\u3061\u306F\u5341\u56DE\u8CAF\u3081\u305F\u3089\u7834\u58CA\u5149\u7DDA\u3067\u76F8\u624B\u3092\u4E00\u6483\u5FC5\u6BBA\u3067\u304D\u305F",
    "id" : 224154132276195328,
    "created_at" : "2012-07-14 14:51:24 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 224155670264549377,
  "created_at" : "2012-07-14 14:57:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224155637033086976",
  "text" : "RT @shigmax: \u306A\u3093\u304B\u6614\u3042\u3063\u305F\u3088\u306D\u3000\u8CAF\u3081\u305F\u308A\u30D3\u30FC\u30E0\u51FA\u3057\u305F\u308A\u30D0\u30EA\u30E4\u3057\u305F\u308A\u3059\u308B\u3000\u3058\u3083\u3093\u3051\u3093\u307F\u305F\u3044\u306A\u30B2\u30FC\u30E0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224153840272941056",
    "text" : "\u306A\u3093\u304B\u6614\u3042\u3063\u305F\u3088\u306D\u3000\u8CAF\u3081\u305F\u308A\u30D3\u30FC\u30E0\u51FA\u3057\u305F\u308A\u30D0\u30EA\u30E4\u3057\u305F\u308A\u3059\u308B\u3000\u3058\u3083\u3093\u3051\u3093\u307F\u305F\u3044\u306A\u30B2\u30FC\u30E0",
    "id" : 224153840272941056,
    "created_at" : "2012-07-14 14:50:14 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 224155637033086976,
  "created_at" : "2012-07-14 14:57:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224155546394165249",
  "text" : "@KyoHiiragi \u4E00\u5EA6\u30B3\u30F3\u30D3\u30CB\u3067\u304A\u3067\u3093\u306E\u849F\u84BB\u8CB7\u3063\u3066\u6765\u3066\u51CD\u3089\u305B\u3066\u304B\u3089\u7FCC\u65E5\u30EC\u30F3\u30B8\u3067\u30C1\u30F3\u3057\u3066\u304B\u3089\u98DF\u3079\u3066\u307F\u308B\u3068\u3044\u3044\u3088\uFF01",
  "id" : 224155546394165249,
  "created_at" : "2012-07-14 14:57:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224154651036102657",
  "geo" : { },
  "id_str" : "224155105610571776",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30EA\u30D5\u30EC\u30AF\u30BF\u30FC\u6F70\u3057\u307F\u305F\u3044\u306E\u3082\u3042\u3063\u3066\u5727\u5012\u7684\u3044\u305F\u3061\u3054\u3063\u3053",
  "id" : 224155105610571776,
  "in_reply_to_status_id" : 224154651036102657,
  "created_at" : "2012-07-14 14:55:16 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224154685517471745",
  "geo" : { },
  "id_str" : "224154784951844864",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3060\u3088\u306D\u30FC\u2606\u4F55\u306B\u3082\u8003\u3048\u305A\u306B\u51B7\u51CD\u5EAB\u306B\u76F4\u884C\u3060\u3063\u305F\u308F\uFF0E",
  "id" : 224154784951844864,
  "in_reply_to_status_id" : 224154685517471745,
  "created_at" : "2012-07-14 14:53:59 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224154423264411649",
  "geo" : { },
  "id_str" : "224154524548481025",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u51CD\u3089\u305B\u3066\u6EB6\u304B\u3057\u305F\u306E\u304C\uFF1F",
  "id" : 224154524548481025,
  "in_reply_to_status_id" : 224154423264411649,
  "created_at" : "2012-07-14 14:52:57 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224154132276195328",
  "geo" : { },
  "id_str" : "224154340548550659",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u30AB\u30A6\u30F3\u30BF\u30FC\u30D0\u30EA\u30E4\u30FC\u3068\u304B\u3042\u3063\u305F\u6C17\u304C\uFF57\uFF57\uFF57\u307F\u3093\u306A\u305F\u3081\u305F\u56DE\u6570\u304C\u89E3\u3089\u306A\u304F\u306A\u3063\u3066\u5727\u5012\u7684\u3054\u307E\u304B\u3057\u304C\u59CB\u307E\u308B",
  "id" : 224154340548550659,
  "in_reply_to_status_id" : 224154132276195328,
  "created_at" : "2012-07-14 14:52:14 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224154154019463170",
  "text" : "@KyoHiiragi \u3042\u308C\u3053\u306E\u4E16\u306E\u4E2D\u3067\u304B\u306A\u308A\u60B2\u60E8\u306A\u90E8\u985E\u306E\u98DF\u3079\u7269\u3060\u3088\uFF0E\u306A\u3093\u3068\u3044\u3046\u304B\uFF0C\u52A3\u5316\u3057\u305F\u30B4\u30E0\u3068\u30B9\u30DD\u30F3\u30B8\u3092\u5408\u308F\u305B\u305F\u3088\u3046\u306A\u6B6F\u89E6\u308A\uFF0E",
  "id" : 224154154019463170,
  "created_at" : "2012-07-14 14:51:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224153783737909248",
  "text" : "\u3068\u3044\u3046\u304B\u9078\u629E\u516C\u7406\u30AA\u30D5\u884C\u304D\u305F\u304B\u3063\u305F\u306A\u3041\u2026",
  "id" : 224153783737909248,
  "created_at" : "2012-07-14 14:50:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224153481894821888",
  "text" : "@KyoHiiragi \u51CD\u3063\u305F\u849F\u84BB\u3092\u6EB6\u304B\u3057\u305F\u3082\u306E\u3092\u98DF\u3079\u305F\u3053\u3068\u3042\u308B\uFF1F",
  "id" : 224153481894821888,
  "created_at" : "2012-07-14 14:48:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224153130521202688",
  "text" : "@KyoHiiragi \u305F\u3076\u3093\u3082\u3046\u51CD\u3063\u3061\u3083\u3063\u305F\u3093\u3060\u3051\u308C\u3069\u50D5\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3093\u3067\u3059\u304B\uFF0E",
  "id" : 224153130521202688,
  "created_at" : "2012-07-14 14:47:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224152821858181120",
  "text" : "RT @shigmax: \u3044\u3064\u51FA\u3059\u306E\uFF1F\u3000\u3000\u4ECA\u3067\u3057\u3087\u3046\uFF01\uFF01\uFF01\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224152730904707072",
    "text" : "\u3044\u3064\u51FA\u3059\u306E\uFF1F\u3000\u3000\u4ECA\u3067\u3057\u3087\u3046\uFF01\uFF01\uFF01\uFF01\uFF01",
    "id" : 224152730904707072,
    "created_at" : "2012-07-14 14:45:50 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 224152821858181120,
  "created_at" : "2012-07-14 14:46:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224152783077646337",
  "text" : "RT @shigmax: \u30D3\u30FC\u30E0\u51FA\u305D\u3046\u304B\u306A\u301C\u301C\u301C\u301C\u301C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224152635794661376",
    "text" : "\u30D3\u30FC\u30E0\u51FA\u305D\u3046\u304B\u306A\u301C\u301C\u301C\u301C\u301C",
    "id" : 224152635794661376,
    "created_at" : "2012-07-14 14:45:27 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 224152783077646337,
  "created_at" : "2012-07-14 14:46:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224152591729307649",
  "text" : "\u3093\u30FC\uFF0C\u6614\u65E5\u672C\u53F2\u306E\u53C2\u8003\u66F8\u306B\u300C\u3053\u3053\u304B\u3089\u306F\u8907\u96D1\u306A\u306E\u3067\uFF0C\u3082\u3057\u7720\u3044\u4EBA\u304C\u3044\u305F\u3089\u5BDD\u3066\u304F\u3060\u3055\u3044\u300D\u3063\u3066\u66F8\u3044\u3066\u3042\u3063\u3066\uFF0C\u7D20\u76F4\u306B\u6BCE\u56DE\u5BDD\u3066\u305F\u3089\u30C6\u30B9\u30C8\u3067\u9177\u3044\u70B9\u3092\u53D6\u3063\u3061\u3083\u3063\u305F\u3093\u3060\u3088\u306D\uFF0E\n\u3060\u304B\u3089\u849F\u84BB\u30BC\u30EA\u30FC\u306F\u51CD\u308B\u3093\u3060\u3088\uFF0E",
  "id" : 224152591729307649,
  "created_at" : "2012-07-14 14:45:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224152378511851520",
  "text" : "@KyoHiiragi \u3048\u3063",
  "id" : 224152378511851520,
  "created_at" : "2012-07-14 14:44:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224152203437424642",
  "text" : "\u50D5\u306ETL\u306B\u306F\u30D3\u30FC\u30E0\u51FA\u305B\u308B\u4EBA\u304C\u8907\u6570\u540D\u3044\u308B\u304B\u3089\u3061\u3087\u3063\u3068\u81EA\u5206\u304C\u30D3\u30FC\u30E0\u51FA\u305B\u306A\u3044\u3053\u3068\u306B\u5371\u6A5F\u611F\u3092\u899A\u3048\u59CB\u3081\u305F\uFF0E",
  "id" : 224152203437424642,
  "created_at" : "2012-07-14 14:43:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 13, 23 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224152098789527552",
  "text" : "RT @shigmax: @end313124 \u3042\u304B\u3093wwwww\u30D3\u30FC\u30E0\u51FA\u305D\u3046(^^)(^^)(^^)(^^)(^^)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "224151290614251522",
    "geo" : { },
    "id_str" : "224151681724719105",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u3042\u304B\u3093wwwww\u30D3\u30FC\u30E0\u51FA\u305D\u3046(^^)(^^)(^^)(^^)(^^)",
    "id" : 224151681724719105,
    "in_reply_to_status_id" : 224151290614251522,
    "created_at" : "2012-07-14 14:41:40 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 224152098789527552,
  "created_at" : "2012-07-14 14:43:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224151942400720898",
  "text" : "@KyoHiiragi \u3093\u30FC\uFF0C\u6614\u65E5\u672C\u53F2\u306E\u53C2\u8003\u66F8\u306B\u300C\u3053\u3053\u304B\u3089\u306F\u8907\u96D1\u306A\u306E\u3067\uFF0C\u3082\u3057\u7720\u3044\u4EBA\u304C\u3044\u305F\u3089\u5BDD\u3066\u304F\u3060\u3055\u3044\u300D\u3063\u3066\u66F8\u3044\u3066\u3042\u3063\u3066\uFF0C\u7D20\u76F4\u306B\u6BCE\u56DE\u5BDD\u3066\u305F\u3089\u30C6\u30B9\u30C8\u3067\u9177\u3044\u70B9\u3092\u53D6\u3063\u3061\u3083\u3063\u305F\u3093\u3060\u3088\u306D\uFF0E",
  "id" : 224151942400720898,
  "created_at" : "2012-07-14 14:42:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 16, 24 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224151290614251522",
  "text" : "\u30D3\u30FC\u30E0\u51FA\u305B\u308B\u3093\u3067\u3059\u304B\uFF1F\uFF01 RT @shigmax: \u4F55\u3067\u3082\u8ABF\u5B50\u306B\u6CE2\u304C\u51FA\u308B\u306E\u306F\u8AB0\u3067\u3082\u3057\u3087\u3046\u304C\u306A\u3044\u3068\u306F\u601D\u3046\u3093\u3060",
  "id" : 224151290614251522,
  "created_at" : "2012-07-14 14:40:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 24, 40 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 65, 75 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224151084992692226",
  "text" : "\u51CD\u3089\u305B\u305F\u3089\uFF7C\uFF9E\uFF6D\uFF99\uFF7C\uFF9E\uFF6D\uFF99\u8A00\u308F\u306A\u3044\u3093\u3058\u3083\u2026RT @Jelly_in_a_tank: \u3058\u3085\u308B\u3058\u3085\u308B RT @KyoHiiragi: @end313124 \u849F\u84BB\u30BC\u30EA\u30FC\u51CD\u3089\u305B\u305F\u3089\u30C0\u30E1\u3067\u3059\u3088!!",
  "id" : 224151084992692226,
  "created_at" : "2012-07-14 14:39:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224150993682694147",
  "text" : "@KyoHiiragi \u306A\u305C\uFF1F",
  "id" : 224150993682694147,
  "created_at" : "2012-07-14 14:38:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224150472003567616",
  "text" : "\u3042\uFF0C\u5E30\u5B85\u3057\u307E\u3057\u305F\u3057",
  "id" : 224150472003567616,
  "created_at" : "2012-07-14 14:36:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224150442718932992",
  "text" : "\u5BB6\u306B\u3082\u51CD\u3063\u305F\u849F\u84BB\u30BC\u30EA\u30FC\u304C\u3042\u308B\u3093\u3060\u306A\u3053\u308C\u304C",
  "id" : 224150442718932992,
  "created_at" : "2012-07-14 14:36:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224137184280715265",
  "text" : "\u53CB\u4EBA\u306B\u5510\u7A81\u306B\u4E8C\u5E74\u3076\u308A\u304F\u3089\u3044\u306B\u96FB\u8A71\u3092\u304B\u3051\u308B\u904A\u3073\u304C\u697D\u3057\u3044",
  "id" : 224137184280715265,
  "created_at" : "2012-07-14 13:44:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224134328039383042",
  "text" : "\u7740\u308B\u3082\u306E\u304C\u7F8E\u3057\u3044\u306E\u304B\u7740\u3089\u308C\u308B\u3082\u306E\u304C\u7F8E\u3057\u3044\u306E\u304B\u3044\u3064\u3082\u308F\u304B\u3089\u306A\u3044",
  "id" : 224134328039383042,
  "created_at" : "2012-07-14 13:32:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u30FC\u306B\u3083\u3093\uFF20R-univ.Math",
      "screen_name" : "ilovegalois",
      "indices" : [ 3, 15 ],
      "id_str" : "258362326",
      "id" : 258362326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224134188213878784",
  "text" : "RT @ilovegalois: \u4ECA\u65E5\u306F\u7957\u5712\u796D\u3060\u304B\u3089\u304B\u96FB\u8ECA\u5185\u306B\u7740\u7269\u7F8E\u4EBA\u304C\u591A\u3044\u306A\u3041",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224134037067935745",
    "text" : "\u4ECA\u65E5\u306F\u7957\u5712\u796D\u3060\u304B\u3089\u304B\u96FB\u8ECA\u5185\u306B\u7740\u7269\u7F8E\u4EBA\u304C\u591A\u3044\u306A\u3041",
    "id" : 224134037067935745,
    "created_at" : "2012-07-14 13:31:33 +0000",
    "user" : {
      "name" : "\u304D\u30FC\u306B\u3083\u3093\uFF20R-univ.Math",
      "screen_name" : "ilovegalois",
      "protected" : false,
      "id_str" : "258362326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510819268590436352\/7RZnoc1Q_normal.jpeg",
      "id" : 258362326,
      "verified" : false
    }
  },
  "id" : 224134188213878784,
  "created_at" : "2012-07-14 13:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224111083785420800",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 224111083785420800,
  "created_at" : "2012-07-14 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224026954028953602",
  "text" : "\u53CB\u4EBA\u306B\u300Cend\u304F\u3093\u306E\u30C4\u30A4\u30FC\u30C8\u306F\u7406\u89E3\u306E\u7BC4\u7587\u3092\u8D85\u3048\u308B\u8B0E\u30C4\u30A4\u30FC\u30C8\u304C\u591A\u3044\u300D\u3068\u3044\u3046\u5727\u5012\u7684\u304A\u8A00\u8449\u3092\u3044\u305F\u3060\u3044\u305F\u306E\u3067\u3061\u3087\u3063\u3068\u8AAD\u307F\u8FD4\u3057\u3066\u307F\u305F\u304C\uFF0C\u3046\u3093\uFF0E\u4ECA\u65E5\u3082\u6691\u3044\u306D\uFF0E",
  "id" : 224026954028953602,
  "created_at" : "2012-07-14 06:26:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224023805469786113",
  "text" : "\u767D\u3044\u30B7\u30E3\u30C4\u304C\u4E7E\u3044\u3066\u3044\u306A\u3044\u304B\u3089\u4ED5\u65B9\u306A\u3044\uFF0E",
  "id" : 224023805469786113,
  "created_at" : "2012-07-14 06:13:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224023101015474177",
  "text" : "\u30EA\u30FC\u30DE\u30F3\u7A4D\u5206\u306E\u69CB\u3048\uFF57\uFF57\uFF57\uFF57\uFF57\u30EB\u30D9\u30FC\u30B0\u7A4D\u5206\u306E\u69CB\u3048\uFF57\uFF57\uFF57\uFF57\uFF57\u5727\u5012\u7684\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 224023101015474177,
  "created_at" : "2012-07-14 06:10:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224022829635612674",
  "text" : "\u79C1\u3082\u6614\u306F\u4E00\u65E5\u306B100\u30DD\u30B9\u30C8\u8FD1\u304F\u3057\u3066\u3044\u305F\u3093\u3060\u304C\uFF0C\u819D\u306B\u77E2\u3092\u53D7\u3051\u3066\u3057\u307E\u3063\u3066\u306A\uFF0E\uFF0E\uFF0E",
  "id" : 224022829635612674,
  "created_at" : "2012-07-14 06:09:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223983742153277440",
  "text" : "\u3042\u305A\u304D\u30D0\u30FC\u306A\u3046",
  "id" : 223983742153277440,
  "created_at" : "2012-07-14 03:34:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223833822096138242",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3001\u304B\u306A",
  "id" : 223833822096138242,
  "created_at" : "2012-07-13 17:38:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223833541442666498",
  "text" : "\u3064\u307E\u3093\u306D\u30FC\u4E8B\u805E\u304F\u306A\u3088\u3063\uFF01",
  "id" : 223833541442666498,
  "created_at" : "2012-07-13 17:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223827781333692416",
  "text" : "@koketomi \u907F\u3051\u308D\uFF01\u3063\u3066\u8A00\u3063\u305F\u3089\u30DF\u30CB\u56DB\u99C6\u3060\u3063\u3066\u907F\u3051\u308B\u3093\u3060\u304B\u3089\u304A\u524D\u3082\u907F\u3051\u308D\uFF01",
  "id" : 223827781333692416,
  "created_at" : "2012-07-13 17:14:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223827161172279296",
  "text" : "\u6587\u7CFB\u3092\u8A00\u3044\u8A33\u306B\u3057\u306A\u3044\u3067\u6B32\u3057\u3044\u306A\u3001\u3044\u3084\u672C\u5F53\u306B",
  "id" : 223827161172279296,
  "created_at" : "2012-07-13 17:12:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223824739653795842",
  "text" : "@koketomi \u3056\u307E\u3042\u3042\u3042\u3042\u3042\u3042",
  "id" : 223824739653795842,
  "created_at" : "2012-07-13 17:02:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223818037969698817",
  "text" : "\u558B\u3063\u3066\u304B\u3089\u8003\u3048\u308B\u306E\u3084\u3081\u3088\u3046\u3068\u601D\u3044\u3064\u3064\u9762\u767D\u3044\u304B\u3089\u3084\u3081\u306A\u3044",
  "id" : 223818037969698817,
  "created_at" : "2012-07-13 16:35:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223817898974658560",
  "text" : "\u3082\u3046\u3053\u3068\u308A\u3093\u81EA\u8EAB\u304C\u306C\u3044\u3050\u308B\u307F\u306B\u306A\u308C\u3070\u3044\u3044\u3093\u3058\u3083",
  "id" : 223817898974658560,
  "created_at" : "2012-07-13 16:35:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223817133719683072",
  "text" : "\u306C\u3044\u3050\u308B\u307F\u3092\u81EA\u5206\u4EE5\u5916\u306B\u898B\u305B\u306A\u3044\u89E6\u3089\u305B\u306A\u3044\u3063\u3066\u306A\u3093\u304B\u30E4\u30F3\u30C7\u30EC\u3001\u30E1\u30F3\u30D8\u30E9\u611F\u304C\u3072\u3069\u3044",
  "id" : 223817133719683072,
  "created_at" : "2012-07-13 16:32:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308B\u304F\u308B(\u3064\u3044\u304D\u3093\u3057\u305F\u3044)",
      "screen_name" : "KURUKURU888333",
      "indices" : [ 0, 15 ],
      "id_str" : "337502390",
      "id" : 337502390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223816604843126784",
  "geo" : { },
  "id_str" : "223816940777512960",
  "in_reply_to_user_id" : 337502390,
  "text" : "@KURUKURU888333 @kotorin_z \u3058\u3083\u3042\u4EBA\u304C\u304F\u308B\u6642\u306B\u306F\u8EDF\u7981\u3057\u3066\u304A\u304F\u3057\u304B\u2026",
  "id" : 223816940777512960,
  "in_reply_to_status_id" : 223816604843126784,
  "created_at" : "2012-07-13 16:31:31 +0000",
  "in_reply_to_screen_name" : "KURUKURU888333",
  "in_reply_to_user_id_str" : "337502390",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223815847687372800",
  "text" : "@kotorin_z \u5C11\u306A\u304F\u3068\u3082\u8CB7\u3046\u6642\u306F\u305D\u3093\u306A\u306B\u6065\u305A\u304B\u3057\u304F\u7121\u3044\u3067\u3059\u306D",
  "id" : 223815847687372800,
  "created_at" : "2012-07-13 16:27:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223814222897885185",
  "text" : "@kotorin_z \u3058\u3001\u3058\u3083\u3042\u30A2\u30DE\u30BE\u30F3\u3067\u2026",
  "id" : 223814222897885185,
  "created_at" : "2012-07-13 16:20:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223813573443457024",
  "text" : "\u306C\u3044\u3050\u308B\u307F\u3068\u304B\u3061\u3087\u3063\u3068\u597D\u304D",
  "id" : 223813573443457024,
  "created_at" : "2012-07-13 16:18:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223813414131216384",
  "text" : "@kotorin_z \u3044\u3001\u4E00\u7DD2\u306B\u8CB7\u3044\u306B\u884C\u304D\u307E\u3059\u304B(\u8FEB\u771F",
  "id" : 223813414131216384,
  "created_at" : "2012-07-13 16:17:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223810798512914432",
  "text" : "\u8C46\u8150\u30E1\u30F3\u30BF\u30EB\u4EE5\u4E0A\u5F62\u72B6\u8A18\u61B6\u30E1\u30F3\u30BF\u30EB\u672A\u6E80",
  "id" : 223810798512914432,
  "created_at" : "2012-07-13 16:07:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223807862814683136",
  "text" : "\u3068\u3057\u3092\u3068\u3063\u305F\u306A\u3041",
  "id" : 223807862814683136,
  "created_at" : "2012-07-13 15:55:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223802740114075648",
  "text" : "@ayuretti \u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u754C\u9688\u3067\u306F",
  "id" : 223802740114075648,
  "created_at" : "2012-07-13 15:35:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223776715795726337",
  "text" : "@ayuretti \u30AE\u30E3\u30AE\u30E3\u57FA\u5E95\u306F\u6642\u3005\u3084\u3063\u3070\u3044\u304A\u3082\u3057\u308D\u3044",
  "id" : 223776715795726337,
  "created_at" : "2012-07-13 13:51:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223776009412030465",
  "text" : "TL\u3067\u307F\u3063\u3061\u3083\u3093\u306E\u8A71\u3057\u3066\u308B\u4EBA\u3044\u307E\u3057\u305F\uFF1F",
  "id" : 223776009412030465,
  "created_at" : "2012-07-13 13:48:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223766617195155457",
  "text" : "\u3055\u3041\u7D9A\u304D\u7D9A\u304D",
  "id" : 223766617195155457,
  "created_at" : "2012-07-13 13:11:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223766362001113088",
  "text" : "\u3046\u304A\u304A\u304A\u304A\u304A\u304A\u304A\u304A\u304A\u304A\u304A\u304A\u3084\u3063\u3068\u89E3\u3051\u305F\u3042\u3042\u3042\u3042\uFF01\uFF01",
  "id" : 223766362001113088,
  "created_at" : "2012-07-13 13:10:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 0, 9 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223732975408381953",
  "geo" : { },
  "id_str" : "223737575976861696",
  "in_reply_to_user_id" : 126927392,
  "text" : "@hanaoka_ \u4E86\u89E3\u3067\u3059\u30FC",
  "id" : 223737575976861696,
  "in_reply_to_status_id" : 223732975408381953,
  "created_at" : "2012-07-13 11:16:09 +0000",
  "in_reply_to_screen_name" : "hanaoka_",
  "in_reply_to_user_id_str" : "126927392",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223732694725566464",
  "text" : "\u3054\u98EF\u708A\u3051\u305F\uFF01",
  "id" : 223732694725566464,
  "created_at" : "2012-07-13 10:56:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 0, 9 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223732646860173313",
  "in_reply_to_user_id" : 126927392,
  "text" : "@hanaoka_ \u305D\u3046\u8A00\u3048\u3070\u304A\u501F\u308A\u3057\u3066\u3044\u305F\u672C\u3092\u8FD4\u3057\u305F\u3044\u306E\u3067\u3059\u304C\u30FC",
  "id" : 223732646860173313,
  "created_at" : "2012-07-13 10:56:34 +0000",
  "in_reply_to_screen_name" : "hanaoka_",
  "in_reply_to_user_id_str" : "126927392",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223723833239150593",
  "text" : "\u307E\u3041\u307E\u3060\u3054\u98EF\u708A\u3051\u3066\u306A\u3044\u3051\u3069\u306D",
  "id" : 223723833239150593,
  "created_at" : "2012-07-13 10:21:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223723621829459969",
  "text" : "\u81EA\u708A\u306E\u5272\u5B89\u611F\u304C\u534A\u7AEF\u3058\u3083\u306A\u3044\u306E\u3067\u30C6\u30B9\u30C8\u671F\u9593\u306F\u7C21\u5358\u306A\u3082\u306E\u3067\u3082\u7A4D\u6975\u7684\u306B\u81EA\u708A\u3057\u3066\u884C\u304Fsyozonn",
  "id" : 223723621829459969,
  "created_at" : "2012-07-13 10:20:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223723387330109442",
  "text" : "\u7D0D\u8C46\u3068\u5375\u3067\u7C21\u5358\u6669\u3054\u98EF",
  "id" : 223723387330109442,
  "created_at" : "2012-07-13 10:19:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223709352677212160",
  "text" : "\u30BC\u30DF\u306E\u52C9\u5F37\u304C\u6E1B\u3063\u3066\u5897\u3048\u305F",
  "id" : 223709352677212160,
  "created_at" : "2012-07-13 09:24:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223709055074570240",
  "text" : "@asaduke_1729 \u307E\u3041\u4E00\u5FDC\u8FBF\u308C\u306A\u3044\u3088\u3046\u306B\u3057\u305F\u304B\u3089\u3044\u3044\u304B\u306A\u30FC\u3068\u3002",
  "id" : 223709055074570240,
  "created_at" : "2012-07-13 09:22:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223675021913096192",
  "text" : "\u3060\u304B\u3089\u3068\u8A00\u3063\u3066\u5ACC\u3060\u3051\u308C\u3069",
  "id" : 223675021913096192,
  "created_at" : "2012-07-13 07:07:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223674956012208128",
  "text" : "\u307E\u3041\u7279\u306B\u89AA\u30D0\u30EC\u3057\u3066\u3082\u6065\u305A\u304B\u3057\u3044\u4EE5\u5916\u306E\u5B9F\u5BB3\u306F\u7121\u3044\u306E\u3060\u304C",
  "id" : 223674956012208128,
  "created_at" : "2012-07-13 07:07:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223674784855236610",
  "text" : "@asaduke_1729 LINE\u305D\u306E\u3082\u306E\u306E\u89AA\u30D0\u30EC\u306F\u6016\u304F\u306A\u3044\u3093\u3060\u304C\u30C4\u30A4\u30C3\u30BF\u30FC\u306B\u6CE2\u53CA\u3059\u308B\u306E\u306F\u56F0\u308B",
  "id" : 223674784855236610,
  "created_at" : "2012-07-13 07:06:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223674474304770048",
  "text" : "\u96FB\u8A71\u756A\u53F7\u3068\u3044\u3046\u60C5\u5831\u3092\u6271\u3046\u4EE5\u4E0A\u6C17\u3092\u3064\u3051\u3066\u6C17\u3092\u3064\u3051\u3059\u304E\u308B\u3053\u3068\u3082\u7121\u3044",
  "id" : 223674474304770048,
  "created_at" : "2012-07-13 07:05:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223673819578122240",
  "text" : "\u3053\u3053\u3067\u66F8\u3044\u305F\u3089\u9006\u691C\u7D22\u3067\u5272\u308C\u308B\u6050\u308C\u30D3\u30EC\u30BE\u30F3",
  "id" : 223673819578122240,
  "created_at" : "2012-07-13 07:02:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223673723058794496",
  "text" : "ID\u306Fendlicheriendlicheri(\u3061\u3087\u3063\u3068\u3057\u305F\u3089\u6D88\u3059\u306E\u3067\u7533\u8ACB\u3057\u305F\u3044\u4EBA\u306F\u9069\u5F53\u306B\u3069\u3046\u305E)",
  "id" : 223673723058794496,
  "created_at" : "2012-07-13 07:02:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223673214126133249",
  "text" : "ID\u3082\u540D\u524D\u3082\u30A2\u30A4\u30B3\u30F3\u3082\u5909\u3048\u305F\u304B\u3089\u6D41\u77F3\u306B\u4E00\u767A\u30C4\u30E2\u306F\u7121\u3044\u3060\u308D\u3046",
  "id" : 223673214126133249,
  "created_at" : "2012-07-13 07:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223673010563981315",
  "text" : "@asaduke_1729 \u305D\u306E\u5FC3\u306F\uFF1F",
  "id" : 223673010563981315,
  "created_at" : "2012-07-13 06:59:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223671725890617345",
  "text" : "id\u5909\u3048\u3089\u308C\u306A\u3044\u306A\u3089\u3044\u3063\u305F\u3093\u6D88\u3059\u304B",
  "id" : 223671725890617345,
  "created_at" : "2012-07-13 06:54:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223670844004642817",
  "text" : "\u3066\u3044\u3046\u304B\u3053\u308C\u89AA\u3068\u304B\u5F1F\u304C\u756A\u53F7\u3067\u691C\u7D22\u304B\u3051\u305F\u3089\u3044\u308D\u3044\u308D\u5272\u308C\u308B\u3084\u3093\u3002\u3044\u308D\u3044\u308D\u66F8\u304D\u63DB\u3048\u306A\u304D\u3083",
  "id" : 223670844004642817,
  "created_at" : "2012-07-13 06:50:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223669581091323905",
  "geo" : { },
  "id_str" : "223670207955210240",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5FC5\u8981\u6027\u304C\u751F\u3058\u305F\u304B\u3089\u4E00\u5FDC\u3044\u308C\u305F\u3051\u3069\u2026",
  "id" : 223670207955210240,
  "in_reply_to_status_id" : 223669581091323905,
  "created_at" : "2012-07-13 06:48:27 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223669096087171072",
  "text" : "\u3044\u308C\u3066\u898B\u305F\u3051\u308C\u3069\u3053\u308C\u306F\u2026\u3069\u3046\u3059\u308C\u3070\u826F\u3044\u3093\u3060\u308D\u3046",
  "id" : 223669096087171072,
  "created_at" : "2012-07-13 06:44:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223668934111543296",
  "text" : "LINE\u2026",
  "id" : 223668934111543296,
  "created_at" : "2012-07-13 06:43:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223630829874712576",
  "text" : "\u843D\u8A9E\u304A\u3082\u3057\u308D\u3044\u306E\u306B\u306D\u3047",
  "id" : 223630829874712576,
  "created_at" : "2012-07-13 04:11:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223630725675626496",
  "text" : "\u307E\u3041\u306B\u308F\u304B\u304C\u5897\u3048\u308B\u3088\u308A\u3044\u3044\u304B\uFF08\u81EA\u5206\u3082\u306B\u308F\u304B\u3060\u304C\uFF09",
  "id" : 223630725675626496,
  "created_at" : "2012-07-13 04:11:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223630468699004928",
  "text" : "\u307E\u3041\u3051\u3044\u304A\u3093\u3082\u97F3\u697D\u6D3B\u52D5\u3057\u3066\u306A\u304B\u3063\u305F\u3057\u305D\u3046\u3044\u3046\u3053\u3068\u306A\u306E\u304B\u306A",
  "id" : 223630468699004928,
  "created_at" : "2012-07-13 04:10:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223630379175772161",
  "text" : "\u3042\u308C\u3067\u539F\u4F5C\u3088\u308A\u3084\u3063\u3066\u308B\u3063\u3066\u539F\u4F5C\u3069\u3046\u306A\u3063\u3066\u3093\u3060\uFF0E",
  "id" : 223630379175772161,
  "created_at" : "2012-07-13 04:10:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223630247919230977",
  "text" : "@setsuna0321118 gdgd\u3068\u8A00\u8449\u904A\u3073\u304C\u5C0F\u6C17\u5473\u3044\u3044\u3067\u3059\u306D\u30FC",
  "id" : 223630247919230977,
  "created_at" : "2012-07-13 04:09:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223629791121776641",
  "geo" : { },
  "id_str" : "223630168730767366",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u3048\uFF0E",
  "id" : 223630168730767366,
  "in_reply_to_status_id" : 223629791121776641,
  "created_at" : "2012-07-13 04:09:21 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223629749803683840",
  "text" : "\u3067\u3082\u843D\u8A9E\u306F\u3084\u3089\u306A\u3044\u306E\u306D\u30FC",
  "id" : 223629749803683840,
  "created_at" : "2012-07-13 04:07:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223629693683896320",
  "text" : "\u3058\u3087\u3057\u3089\u304F\u6848\u5916\u9762\u767D\u304B\u3063\u305F",
  "id" : 223629693683896320,
  "created_at" : "2012-07-13 04:07:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223606112941899776",
  "text" : "mjkt",
  "id" : 223606112941899776,
  "created_at" : "2012-07-13 02:33:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223586469367918592",
  "text" : "@ayuretti \u306A\u306B\u305D\u308C\u3044\u3044\u306D",
  "id" : 223586469367918592,
  "created_at" : "2012-07-13 01:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223586225896947713",
  "text" : "@ayuretti \u3069\u3053\u884C\u304F\u306E\uFF1F",
  "id" : 223586225896947713,
  "created_at" : "2012-07-13 01:14:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223583048799756288",
  "text" : "\u76EE\u899A\u307E\u3057\u3092\u6B62\u3081\u308B\u901F\u3055\u3001\u6700\u901F(\u5F53\u4EBA\u6BD4)",
  "id" : 223583048799756288,
  "created_at" : "2012-07-13 01:02:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223502521015091200",
  "text" : "\u60AA\u5FAA\u74B0\u306F\u53EF\u63DB\u74B0\uFF1F",
  "id" : 223502521015091200,
  "created_at" : "2012-07-12 19:42:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223502504384659456",
  "text" : "\u7A7A\u8179\u3082\u53BB\u308B\u3053\u3068\u306A\u304C\u3089\u7720\u308C\u3066\u306A\u3044\u4E8B\u5B9F\u305D\u306E\u3082\u306E\u304C\u7720\u308A\u3092\u59A8\u3052\u308B\u60AA\u5FAA\u74B0",
  "id" : 223502504384659456,
  "created_at" : "2012-07-12 19:42:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223502051659878402",
  "text" : "\u7720\u308C\u306C\u591C\u306B\u795F\u308A\u306A\u3057",
  "id" : 223502051659878402,
  "created_at" : "2012-07-12 19:40:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223474695339651072",
  "text" : "\u9AEA\u304C\u304B\u308F\u304B\u306A\u3044\u3068\u3001\u5BDD\u308C\u306A\u307F",
  "id" : 223474695339651072,
  "created_at" : "2012-07-12 17:51:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223453969148682240",
  "text" : "\u751F\u6D3B\u30EA\u30BA\u30E0\u6539\u5584\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B",
  "id" : 223453969148682240,
  "created_at" : "2012-07-12 16:29:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223453931525775360",
  "text" : "\u3082\u3046\uFF11\uFF1A\uFF13\uFF10\u306A\u3093\u3067\u3059\u304B\u305D\u3046\u3067\u3059\u304B",
  "id" : 223453931525775360,
  "created_at" : "2012-07-12 16:29:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223452444015853568",
  "text" : "\u30AB\u30D0\u30FC\u639B\u304B\u3063\u3066\u3066\u3082\u64E6\u308C\u5177\u5408\u3067\u4E00\u767A\u30C4\u30E2\u3060\u3063\u305F",
  "id" : 223452444015853568,
  "created_at" : "2012-07-12 16:23:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3053\u3084\u3067",
      "screen_name" : "nekoyade",
      "indices" : [ 0, 9 ],
      "id_str" : "553253012",
      "id" : 553253012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223452182119321600",
  "geo" : { },
  "id_str" : "223452324079738880",
  "in_reply_to_user_id" : 553253012,
  "text" : "@nekoyade \u78BA\u8A8D\u3057\u305F\u3089\u3055\u3060\u307E\u3055\u3057\u3067\u3057\u305F",
  "id" : 223452324079738880,
  "in_reply_to_status_id" : 223452182119321600,
  "created_at" : "2012-07-12 16:22:40 +0000",
  "in_reply_to_screen_name" : "nekoyade",
  "in_reply_to_user_id_str" : "553253012",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223452121578737666",
  "text" : "\u89E3\u590F\u3060\u3063\u305F\u304B\u306A\uFF0E\u3042\u308C\u3082\u304A\u3082\u3057\u308D\u3044\u5C0F\u8AAC\u3060\u3063\u305F\uFF0E",
  "id" : 223452121578737666,
  "created_at" : "2012-07-12 16:21:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223451986928992256",
  "text" : "@i_horse \u672C\u5F53\u304B\u3069\u3046\u304B\u77E5\u3089\u306A\u3044\u3051\u308C\u3069\uFF0C\u3082\u3068\u3082\u3068\u898B\u3048\u3066\u3066\u8996\u529B\u3092\u5931\u3063\u305F\u4EBA\u304C\u898B\u308B\uFF08?\uFF09\u306E\u306F\u771F\u3063\u6697\u3058\u3083\u306A\u304F\u3066\u4E73\u767D\u8272\u3063\u3066\u805E\u3044\u305F\u3053\u3068\u3042\u308B\u306A\u30FC",
  "id" : 223451986928992256,
  "created_at" : "2012-07-12 16:21:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223451434199420928",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\uFF0C\u6027\u5225\u306E\u524D\u306B\u4EBA\u9593\u306A\u3093\u3060\u305C",
  "id" : 223451434199420928,
  "created_at" : "2012-07-12 16:19:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223451208717836288",
  "text" : "\u3044\u3084\u672C\u5F53\u306B\uFF0E",
  "id" : 223451208717836288,
  "created_at" : "2012-07-12 16:18:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223451120247377920",
  "text" : "\u305D\u3082\u305D\u3082\u540C\u3058\u30B9\u30C6\u30FC\u30B8\u306B\u7ACB\u3064\u3053\u3068\u304C\u51FA\u6765\u3066\u3044\u306A\u3044",
  "id" : 223451120247377920,
  "created_at" : "2012-07-12 16:17:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223450854341083137",
  "text" : "\u604B\u611B\u306F\u5272\u306B\u5408\u308F\u306A\u3044\u3068\u304B\u8003\u3048\u3066\u3044\u308B\u6BB5\u968E\u3067\u3082\u3046",
  "id" : 223450854341083137,
  "created_at" : "2012-07-12 16:16:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223450690930999296",
  "text" : "\u5FC3\u306E\u8E8D\u52D5\u307F\u305F\u3044\u306A\u3082\u306E\u3063\u3066\u3059\u3054\u304F\u75B2\u308C\u308B\uFF0E\u3044\u3084\u307E\u3041\u3082\u3061\u308D\u3093\u7D20\u6575\u306A\u3082\u306E\u3060\u3051\u308C\u3069\uFF0E",
  "id" : 223450690930999296,
  "created_at" : "2012-07-12 16:16:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3057\u30FC",
      "screen_name" : "oPAKILAo",
      "indices" : [ 0, 9 ],
      "id_str" : "547544213",
      "id" : 547544213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223450363313926144",
  "geo" : { },
  "id_str" : "223450471921229825",
  "in_reply_to_user_id" : 547544213,
  "text" : "@oPAKILAo \u305D\u3082\u305D\u3082\u4EBA\u3092\u597D\u304D\u306B\u306A\u308B\u3053\u3068\u306B\u304B\u304B\u308B\u30A8\u30CD\u30EB\u30AE\u30FC\u304C\u51C4\u3044\u3068\u601D\u3063\u3066\u3057\u307E\u3044\u307E\u3059",
  "id" : 223450471921229825,
  "in_reply_to_status_id" : 223450363313926144,
  "created_at" : "2012-07-12 16:15:18 +0000",
  "in_reply_to_screen_name" : "oPAKILAo",
  "in_reply_to_user_id_str" : "547544213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223450375703887872",
  "text" : "\u4F55\u3082\u8003\u3048\u306A\u3044\u3067\u558B\u3063\u3066\u3044\u308B\uFF0E",
  "id" : 223450375703887872,
  "created_at" : "2012-07-12 16:14:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223449814371811328",
  "text" : "\u554F\uFF13\u3063\u3066\u805E\u304F\u305F\u3073\u306B\u5BFE\u4E09\u3068\u601D\u3046\u7A0B\u5EA6\u306B\u306F\u6BD2\u3055\u308C\u3066\u3044\u308B",
  "id" : 223449814371811328,
  "created_at" : "2012-07-12 16:12:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223449669110476800",
  "text" : "@koketomi \u4E00\u9580\u5F35\u306B\u898B\u9593\u9055\u3048\u305F\u304B\u3089\u3082\u3046\u3060\u3081\u304B\u3082",
  "id" : 223449669110476800,
  "created_at" : "2012-07-12 16:12:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223449225185337344",
  "geo" : { },
  "id_str" : "223449452785041410",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30DD\u30ED\u30ED\u30C3\u30AB\u3060\u3063\u305F\u304B\u3082\uFF0E\u30A2\u30DE\u30BE\u30F3\u5DDD\u3060\u304B\u4F55\u3068\u304B\u5DDD\u3060\u304B\u304C\u4F55\u5E74\u304B\u306B\u4E00\u5EA6\u9006\u6D41\u3059\u308B\u73FE\u8C61\u306E\u3053\u3068",
  "id" : 223449452785041410,
  "in_reply_to_status_id" : 223449225185337344,
  "created_at" : "2012-07-12 16:11:15 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223449267585564673",
  "text" : "\u306A \u3093 \u3060 \u3053 \u308C \u306F",
  "id" : 223449267585564673,
  "created_at" : "2012-07-12 16:10:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 3, 9 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223449205425975296",
  "text" : "RT @alg_d: @kotorin_z \u5F7C\u5973\u3068\u306F\u304A\u524D\u81EA\u8EAB\u3060\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223449152837791746",
    "text" : "@kotorin_z \u5F7C\u5973\u3068\u306F\u304A\u524D\u81EA\u8EAB\u3060\u3002",
    "id" : 223449152837791746,
    "created_at" : "2012-07-12 16:10:04 +0000",
    "user" : {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "protected" : false,
      "id_str" : "127940910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579632693668773888\/0Susg2n0_normal.jpg",
      "id" : 127940910,
      "verified" : false
    }
  },
  "id" : 223449205425975296,
  "created_at" : "2012-07-12 16:10:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223448130144829440",
  "text" : "\u307C\u304F\u3061\u3087\u3063\u3068\u3072\u3063\u304F\u308A\u304B\u3048\u3057\u3061\u3083\u3063\u305F\u3060\u3051",
  "id" : 223448130144829440,
  "created_at" : "2012-07-12 16:06:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223447706557890561",
  "text" : "\u306E\u3046\u3053\u300C\u79C1\u4E0B\u30CD\u30BF\u306A\u306E\u3067\u7D14\u60C5\u3068\u304B\u3061\u3087\u3063\u3068\u2026\u2026\u3002\u300D",
  "id" : 223447706557890561,
  "created_at" : "2012-07-12 16:04:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223447295658688512",
  "text" : "\u82A5\u5DDD\u9F8D\u4E4B\u4ECB\u306E\u03BA",
  "id" : 223447295658688512,
  "created_at" : "2012-07-12 16:02:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223446871274823681",
  "text" : "\u30BC\u30EA\u30FC\u306E\u30DD\u30DD\u30ED\u30C3\u30AB",
  "id" : 223446871274823681,
  "created_at" : "2012-07-12 16:01:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223446734024613888",
  "text" : "\u4F55\u304C\u30CD\u30BF\u306B\u306A\u308B\u304B\u306F\u8AAD\u3080\u4EBA\u306B\u4F9D\u5B58\u3059\u308B\u3093\u3058\u3083 \uFF08\u4E0D\u5FC5\u8981\u306A\u30DE\u30B8\u30EC\u30B9\u3067\u3059\uFF09",
  "id" : 223446734024613888,
  "created_at" : "2012-07-12 16:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223445835059429376",
  "text" : "\u3042\u3093\u307E\u308A\u3048\u3052\u3064\u306A\u3044\u306E\u306F\u30A2\u30EC\u3060\u3051\u308C\u3069\uFF0E",
  "id" : 223445835059429376,
  "created_at" : "2012-07-12 15:56:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223445809876840448",
  "text" : "\u3067\u3082\u50D5\u5225\u306B\u4E0B\u30CD\u30BF\u304C\u30DE\u30A4\u30CA\u30B9\u3068\u306F\u601D\u3063\u3066\u306A\u3044\u3093\u3067\u3059\u3051\u308C\u3069\u306D\uFF0E",
  "id" : 223445809876840448,
  "created_at" : "2012-07-12 15:56:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223445560328331264",
  "text" : "-\uFF13\u5272\u6E1B\u3063\u305F\uFF0C\u307F\u305F\u3044\u306A\u3063\uFF01",
  "id" : 223445560328331264,
  "created_at" : "2012-07-12 15:55:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223445419592654848",
  "text" : "\u6E1B\u3063\u305F\u91CF\u304C\u8CA0\u3067\u3082\u6E1B\u3063\u305F\u3068\u3044\u3046\u306A\u3089\u2026\u306E\u3046\u3053\u3055\u3093\u3060\u3063\u3066\u6E1B\u91CF\u3067\u304D\u308B\u304B\u3082\uFF01\uFF01",
  "id" : 223445419592654848,
  "created_at" : "2012-07-12 15:55:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3060\u3063\u3066\u305D\u3082\u305D\u3082\u8A00\u308F\u306A\u3044",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223444851344154625",
  "text" : "\u4E0B\u30CD\u30BF\u6E1B\u91CF\u3068\u304B\u30DE\u30B8\u3067\u51FA\u6765\u306A\u3044\u308F\u30FC #\u3060\u3063\u3066\u305D\u3082\u305D\u3082\u8A00\u308F\u306A\u3044",
  "id" : 223444851344154625,
  "created_at" : "2012-07-12 15:52:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223444498938732544",
  "text" : "\u5E03\u56E3\u306B\u30C0\u30A4\u30D6\u3057\u305F\u3044\u3051\u308C\u3069\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u306A\u3044\u3068\u306A\u30FC",
  "id" : 223444498938732544,
  "created_at" : "2012-07-12 15:51:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223444187947872256",
  "text" : "\u305D\u308C\u306A\u30FC",
  "id" : 223444187947872256,
  "created_at" : "2012-07-12 15:50:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 3, 14 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223444177394999297",
  "text" : "RT @sakanafsku: \u30BC\u30DF\u304C\u7D42\u308F\u3063\u305F\u5F8C\u306F\u3084\u308B\u6C17\u306B\u6E80\u3061\u6EA2\u308C\u3066\u308B\u306E\u306B\u6642\u9593\u304C\u6642\u9593\u3060\u304B\u3089\u7761\u7720\u3068\u306E\u845B\u85E4\u304C\u3042\u3063\u3066\u56F0\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223444084013010944",
    "text" : "\u30BC\u30DF\u304C\u7D42\u308F\u3063\u305F\u5F8C\u306F\u3084\u308B\u6C17\u306B\u6E80\u3061\u6EA2\u308C\u3066\u308B\u306E\u306B\u6642\u9593\u304C\u6642\u9593\u3060\u304B\u3089\u7761\u7720\u3068\u306E\u845B\u85E4\u304C\u3042\u3063\u3066\u56F0\u308B",
    "id" : 223444084013010944,
    "created_at" : "2012-07-12 15:49:55 +0000",
    "user" : {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "protected" : true,
      "id_str" : "230481483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459354943862751235\/ueed-jK7_normal.jpeg",
      "id" : 230481483,
      "verified" : false
    }
  },
  "id" : 223444177394999297,
  "created_at" : "2012-07-12 15:50:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223444102807687168",
  "text" : "@asaduke_1729 \u9811\u5F35\u3063\u3066\u304F\u3060\u3055\u3044\uFF1E\uFF1C\uFF08\u5225\u306B\u304A\u3069\u304B\u3059\u305F\u3081\u306B\u30EA\u30D7\u30E9\u30A4\u3057\u305F\u308F\u3051\u3058\u3083\u306A\u3044\uFF09",
  "id" : 223444102807687168,
  "created_at" : "2012-07-12 15:50:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223443781268152320",
  "text" : "\u7740\u305F\u3044\u670D\u3092\u7740\u308B\u3063\u3066\u3053\u3068\u306F\u6691\u3044\u5BD2\u3044\u3092\u6211\u6162\u3059\u308B\u3053\u3068\u3063\u3066\u8AB0\u304B\u524D\u306B\u8A00\u3063\u3066\u305F",
  "id" : 223443781268152320,
  "created_at" : "2012-07-12 15:48:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223443585683562497",
  "text" : "\u5C11\u306A\u304F\u3068\u3082\u30D1\u30FC\u30AB\u30FC\u306F\u8981\u3089\u306A\u304B\u3063\u305F\uFF0E",
  "id" : 223443585683562497,
  "created_at" : "2012-07-12 15:47:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223443549612539905",
  "text" : "\u6628\u65E5\u3082\u9577\u8896\u3067\u904E\u3054\u3057\u304D\u3063\u305F\uFF0E\u8B0E\u306E\u610F\u5730\uFF0E",
  "id" : 223443549612539905,
  "created_at" : "2012-07-12 15:47:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223443201002971139",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u622F\u8A00\u30B7\u30EA\u30FC\u30BA\u3067\u4EBA\u9593\u306E\u30D1\u30BF\u30FC\u30F3\u306F12\u3060\u304B\uFF11\uFF11\u3060\u304B\u306B\u5927\u5225\u3055\u308C\u308B\u3063\u3066\u3042\u3063\u305F\u3051\u308C\u3069\u3042\u308C\u3063\u3066\u307B\u3093\u3068\u3046\u306A\u306E\u304B\u3057\u3089\u3093",
  "id" : 223443201002971139,
  "created_at" : "2012-07-12 15:46:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223442199000514561",
  "text" : "@asaduke_1729 \u7121\u7406\u3057\u3066\u8AAD\u3093\u3067\u3082\u5F97\u308B\u3082\u306E\u306F\u3042\u308B\uFF1F\uFF08\u305F\u3076\u3093\uFF09",
  "id" : 223442199000514561,
  "created_at" : "2012-07-12 15:42:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223441590088237059",
  "geo" : { },
  "id_str" : "223441741699743744",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u304A\u304B\u3048\u308A\u306A\u3055\u3044\u30FC",
  "id" : 223441741699743744,
  "in_reply_to_status_id" : 223441590088237059,
  "created_at" : "2012-07-12 15:40:37 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223441689921060865",
  "text" : "@asaduke_1729 \u53CB\u4EBA\u304C\u8AAD\u3093\u3067\u305F\u306A\u30FC\u3063\u3066\uFF0C\u305D\u308C\u3060\u3051\u306A\u3093\u3060\u3051\u308C\u3069\uFF08\u96E3\u3057\u304B\u3063\u305F\u3067\u3059\u3057\uFF09",
  "id" : 223441689921060865,
  "created_at" : "2012-07-12 15:40:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223441247610740740",
  "text" : "@asaduke_1729 \u5FA9\u523B\u7248\u306E\u3084\u3064\uFF1F",
  "id" : 223441247610740740,
  "created_at" : "2012-07-12 15:38:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223440645019271168",
  "text" : "\u5E30\u5B85\uFF01",
  "id" : 223440645019271168,
  "created_at" : "2012-07-12 15:36:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 11, 27 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 28, 39 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/kqvCMSPA",
      "expanded_url" : "http:\/\/densuke.biz\/list?cd=kkAfzDE7xSbQYtQx",
      "display_url" : "densuke.biz\/list?cd=kkAfzD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223430580040253440",
  "text" : "@coxff2006 @Jelly_in_a_tank @sakanafsku http:\/\/t.co\/kqvCMSPA",
  "id" : 223430580040253440,
  "created_at" : "2012-07-12 14:56:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223386307903234049",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 223386307903234049,
  "created_at" : "2012-07-12 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223317296440029184",
  "text" : "\u5C71\u306E\u65B9\u304C\u3082\u3084\u3082\u3084\u3082\u3084\u3082\u3084",
  "id" : 223317296440029184,
  "created_at" : "2012-07-12 07:26:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223316907951001600",
  "text" : "\u3042\u3041\u30CF\u30E2\u30CB\u30AB\u6A2A\u4E01\u306E\u305F\u3044\u713C\u304D\u5C4B\u3055\u3093\u306E\u305F\u3044\u713C\u304D\u304C\u975E\u5E38\u306B\u61D0\u304B\u3057\u3044",
  "id" : 223316907951001600,
  "created_at" : "2012-07-12 07:24:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223316518975447041",
  "text" : "\u305F\u3044\u713C\u304D\u98DF\u3079\u305F\u3044\u3093\u3060\u3051\u3069\u3069\u3053\u3067\u58F2\u3063\u3066\u308B\u304B\u306A",
  "id" : 223316518975447041,
  "created_at" : "2012-07-12 07:23:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223293472742977537",
  "text" : "\u8AB0\u3082\u3044\u306A\u3044\u3093\u3060\u304C\u30FC",
  "id" : 223293472742977537,
  "created_at" : "2012-07-12 05:51:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/410f4W5H",
      "expanded_url" : "http:\/\/4sq.com\/Ny69x3",
      "display_url" : "4sq.com\/Ny69x3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.034979, 135.781301 ]
  },
  "id_str" : "223293413838159872",
  "text" : "I'm at Weekenders http:\/\/t.co\/410f4W5H",
  "id" : 223293413838159872,
  "created_at" : "2012-07-12 05:51:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223286547913506816",
  "text" : "Weekenders\u3067\u52C9\u5F37\u3059\u308B\u304B\u2026",
  "id" : 223286547913506816,
  "created_at" : "2012-07-12 05:23:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223269390748094466",
  "text" : "\u982D\u60AA",
  "id" : 223269390748094466,
  "created_at" : "2012-07-12 04:15:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223267715673096193",
  "text" : "\u3082\u3046\u4E00\u4EBA\u30CF\u30C3\u30AB\u597D\u304D\u306A\u306E\u304C\u3082\u3046\u4E00\u4EBA\u3057\u304B\u3044\u306A\u304B\u3063\u305F\u6C17\u304C",
  "id" : 223267715673096193,
  "created_at" : "2012-07-12 04:09:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223267396595625984",
  "text" : "\u30CF\u30C3\u30AB\u30AD\u30E3\u30F3\u30C7\u30A3\u30FC\u306E\u51FA\u3066\u304F\u308B\u5922\u3092\u898B\u305F\u3001\u3088\u3046\u306A",
  "id" : 223267396595625984,
  "created_at" : "2012-07-12 04:07:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223263830829051904",
  "text" : "\u306C\u308B\u308A\u3068\u8D77\u304D\u305F",
  "id" : 223263830829051904,
  "created_at" : "2012-07-12 03:53:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223072272452292608",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 223072272452292608,
  "created_at" : "2012-07-11 15:12:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223072163878551552",
  "text" : "\u3059\u3070\u3089\u304F\u306D\u3080\u3044\u306E\u3067\u306D\u308B",
  "id" : 223072163878551552,
  "created_at" : "2012-07-11 15:12:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223072094680911872",
  "text" : "\u3059\u3070\u3089\u3063",
  "id" : 223072094680911872,
  "created_at" : "2012-07-11 15:11:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223071045878423552",
  "text" : "\u53CB\u4EBA\u5B85\u3067\u8AAD\u3093\u3067\u304B\u3089\u8CB7\u3063\u305F\u3093\u3051\u308C\u3069\u7D20\u6575\u306A\u8A71\u3067\u3057\u305F\u30FC",
  "id" : 223071045878423552,
  "created_at" : "2012-07-11 15:07:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223070876218818560",
  "text" : "\u30BF\u30AA\u306E\u57CE\u8AAD\u4E86",
  "id" : 223070876218818560,
  "created_at" : "2012-07-11 15:06:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223045115214692354",
  "text" : "@kotorin_z \u3044\u308D\u3044\u308D\u304A\u304B\u3057\u3044\uFF01\uFF01",
  "id" : 223045115214692354,
  "created_at" : "2012-07-11 13:24:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223044330292641793",
  "text" : "\u50D5\u306E\u7ACB\u3061\u4F4D\u7F6E \u3044\u305A \u3069\u3053",
  "id" : 223044330292641793,
  "created_at" : "2012-07-11 13:21:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223044196590821376",
  "text" : "\u6388\u696D\u3067\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u6F2B\u753B\u304C\u8CC7\u6599\u306B\u306A\u3063\u3066\u305F\n\u300C\u3053\u306E\u5B50\u304C\u3048\u30FC\u3068\u2026\u2026\u300D\n\u3048\u3093\u3069\u300C\u30C6\u30C8\u30E9\u3067\u3059\u300D\n\u300C\u3067\u4E3B\u4EBA\u516C\u304C\u2026(\u30C1\u30E9\u30C3\u300D\n\u3048\u3093\u3069\u300C\u4E3B\u4EBA\u516C\u306F\u540D\u524D\u306A\u3044\u3067\u3059\u3002\u50D5\u3002\u300D\n\n\u300C\u3042\u306E\u3001\u3082\u3046\u4E00\u4EBA\u306E\u5B50\u304C\u30FC(\u30C1\u30E9\u30C3\n\u3048\u3093\u3069\u300C\u30DF\u30EB\u30AB\u3055\u3093\u3067\u3059\u304B?\u300D\n\u300C\u3044\u3084\u3082\u3046\u4E00\u4EBA\u3061\u3063\u3061\u3083\u3044\u5B50\u300D\n\u3048\u3093\u3069\u300C\u30E6\u30FC\u30EA\u3067\u3059\u304B\u300D\n\u306A\u3093\u3060\u3053\u308C",
  "id" : 223044196590821376,
  "created_at" : "2012-07-11 13:20:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222951193847136256",
  "text" : "5\u6642\u306B\u8D77\u304D\u305F\u3089\u4E00\u65E5\u9577\u904E\u304E\u30EF\u30ED\u30BF",
  "id" : 222951193847136256,
  "created_at" : "2012-07-11 07:11:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222951069582491648",
  "text" : "\u7A7A\u8179\u306B\u6C17\u304C\u3064\u3044\u305F",
  "id" : 222951069582491648,
  "created_at" : "2012-07-11 07:10:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222927382271623168",
  "text" : "\u591A\u5206\u5408\u7406\u5316\u304C\u4E0A\u624B\u3067\u81EA\u5206\u3092\u3060\u307E\u304F\u3089\u304B\u3057\u3066\u3044\u304D\u3066\u308B\u3060\u3051\u306A\u306E\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 222927382271623168,
  "created_at" : "2012-07-11 05:36:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222927214675632129",
  "text" : "\u7D50\u679C\u304C\u90FD\u5408\u826F\u304F\u306A\u308B\u3053\u3068\u304C\u591A\u3044\u3060\u3051\uFF1F\u904B\u30B2\u30FC\uFF1F",
  "id" : 222927214675632129,
  "created_at" : "2012-07-11 05:36:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222927130382712833",
  "text" : "\u81EA\u5206\u306F\u3042\u3093\u307E\u308A\u5F8C\u6094\u306F\u3057\u306A\u3044\u65B9\u306A\u306E\u304B\u306A",
  "id" : 222927130382712833,
  "created_at" : "2012-07-11 05:35:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222926810718027776",
  "text" : "\u5C11\u3057\u5BDD\u3066\u3044\u305F\uFF0E15\u5206\u304F\u3089\u3044.",
  "id" : 222926810718027776,
  "created_at" : "2012-07-11 05:34:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3064\u3069\u3044\u7CFB\u30A4\u30D9\u30F3\u30C8\u7D39\u4ECBbot",
      "screen_name" : "sugakuto_osaka",
      "indices" : [ 3, 18 ],
      "id_str" : "481590089",
      "id" : 481590089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222926572737413120",
  "text" : "RT @sugakuto_osaka: \u3010\u6CE8\u610F\u4E8B\u9805\uFF1A\u98F2\u307F\u7269\u3011\u300C\u7B2C\u4E8C\u56DE\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044\u300D\u3067\u306F\u98F2\u307F\u7269\u306A\u3069\u3092\u3054\u7528\u610F\u3059\u308B\u4E88\u5B9A\u3067\u3059\u304C\u3001\u53C2\u52A0\u8005\u306B\u5BFE\u3057\u5341\u5206\u306A\u91CF\u3092\u63D0\u4F9B\u3059\u308B\u3053\u3068\u304C\u3067\u304D\u307E\u305B\u3093\u3002\u51B7\u305F\u3044\u98F2\u307F\u7269\u7B49\u3092\u5404\u81EA\u3067\u6301\u53C2\u3057\u3066\u3044\u305F\u3060\u304F\u3088\u3046\u304A\u9858\u3044\u3057\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222887341084246018",
    "text" : "\u3010\u6CE8\u610F\u4E8B\u9805\uFF1A\u98F2\u307F\u7269\u3011\u300C\u7B2C\u4E8C\u56DE\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044\u300D\u3067\u306F\u98F2\u307F\u7269\u306A\u3069\u3092\u3054\u7528\u610F\u3059\u308B\u4E88\u5B9A\u3067\u3059\u304C\u3001\u53C2\u52A0\u8005\u306B\u5BFE\u3057\u5341\u5206\u306A\u91CF\u3092\u63D0\u4F9B\u3059\u308B\u3053\u3068\u304C\u3067\u304D\u307E\u305B\u3093\u3002\u51B7\u305F\u3044\u98F2\u307F\u7269\u7B49\u3092\u5404\u81EA\u3067\u6301\u53C2\u3057\u3066\u3044\u305F\u3060\u304F\u3088\u3046\u304A\u9858\u3044\u3057\u307E\u3059\u3002",
    "id" : 222887341084246018,
    "created_at" : "2012-07-11 02:57:37 +0000",
    "user" : {
      "name" : "\u3064\u3069\u3044\u7CFB\u30A4\u30D9\u30F3\u30C8\u7D39\u4ECBbot",
      "screen_name" : "sugakuto_osaka",
      "protected" : false,
      "id_str" : "481590089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3194680581\/8cb7d07e676372cdcbae86769516bb49_normal.png",
      "id" : 481590089,
      "verified" : false
    }
  },
  "id" : 222926572737413120,
  "created_at" : "2012-07-11 05:33:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222865714523017216",
  "text" : "\u30C4\u30E2\u3060\u3063\u305F\u304B\u3089\u89AA\u306B\u8CA0\u62C5\u304C\u2026\u3068\u3044\u3046\u8AAC",
  "id" : 222865714523017216,
  "created_at" : "2012-07-11 01:31:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u3055\u3061\u3083\u3093",
      "screen_name" : "safour_1",
      "indices" : [ 3, 12 ],
      "id_str" : "397177453",
      "id" : 397177453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222865573183361024",
  "text" : "RT @safour_1: \u751F\u307E\u308C\u3066\u304D\u3066\u7B2C\u4E00\u58F0\u304C\u300C\u30CF\u30A4\u30C4\u30E2\u3067\u3059\u3088\u3053\u308C\u300D\u3060\u3063\u305F\u4FFA\u306B\u6B7B\u89D2\u306F\u306A\u3044\u3093\u3067\u3059\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222865486403223552",
    "text" : "\u751F\u307E\u308C\u3066\u304D\u3066\u7B2C\u4E00\u58F0\u304C\u300C\u30CF\u30A4\u30C4\u30E2\u3067\u3059\u3088\u3053\u308C\u300D\u3060\u3063\u305F\u4FFA\u306B\u6B7B\u89D2\u306F\u306A\u3044\u3093\u3067\u3059\u3088",
    "id" : 222865486403223552,
    "created_at" : "2012-07-11 01:30:47 +0000",
    "user" : {
      "name" : "\u3055\u3055\u3061\u3083\u3093",
      "screen_name" : "safour_1",
      "protected" : false,
      "id_str" : "397177453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474532360621273088\/NFlCbQmH_normal.jpeg",
      "id" : 397177453,
      "verified" : false
    }
  },
  "id" : 222865573183361024,
  "created_at" : "2012-07-11 01:31:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222865389477044224",
  "text" : "\u307E\u3041\u3044\u3044\u3051\u308C\u3069\uFF0E",
  "id" : 222865389477044224,
  "created_at" : "2012-07-11 01:30:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222865310179524608",
  "text" : "\u304A\u3068\u3068\u3044\u306E\u6388\u696D\u30AA\u30FC\u30E9\u30B9\u3060\u3063\u305F\u3093\u3067\u3059\u304B\u306D\u3053\u308C",
  "id" : 222865310179524608,
  "created_at" : "2012-07-11 01:30:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222860888263233536",
  "text" : "\u6559\u5BA4\u3067\u30D5\u30A9\u30ED\u30EF\u30FC\u306E\u672C\u540D\u304C\u805E\u3053\u3048\u305F\u2026\u3088\u3046\u306A\u2026",
  "id" : 222860888263233536,
  "created_at" : "2012-07-11 01:12:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222848296924880896",
  "text" : "TL\u3092\u773A\u3081\u308B\u79C1\u3068\u5927\u5B66\u306B\u884C\u304F\u79C1\u3068\u5FC5\u8981\u306A\u3093\u3060\u3051\u308C\u3069\uFF0E",
  "id" : 222848296924880896,
  "created_at" : "2012-07-11 00:22:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222847813376155648",
  "geo" : { },
  "id_str" : "222848004099551233",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 222848004099551233,
  "in_reply_to_status_id" : 222847813376155648,
  "created_at" : "2012-07-11 00:21:19 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222847743847178240",
  "text" : "\u3046\u307F\u3046\u3057\u3063\u3066\u3069\u3093\u306A\u725B\uFF1F",
  "id" : 222847743847178240,
  "created_at" : "2012-07-11 00:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222847118589706240",
  "text" : "\u7D50\u69CB\u3061\u3083\u3093\u3068\u5BDD\u3066\u308B\u3093\u3060\u3051\u308C\u3069\uFF0C\uFF16\u6642\u9593\u304F\u3089\u3044\uFF1F",
  "id" : 222847118589706240,
  "created_at" : "2012-07-11 00:17:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222847050906218499",
  "text" : "\u3061\u3087\u3063\u3068\u65E9\u8D77\u304D\u3057\u3059\u304E\u305F\u611F\uFF0E\u7591\u4F3C\u5FB9\u591C\u4F53\u9A13\uFF0E",
  "id" : 222847050906218499,
  "created_at" : "2012-07-11 00:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222846720692858882",
  "text" : "\u6A5F\u306F\u30B8\u30E5\u30AF\u30B8\u30E5\u30AF\u3057\u305F",
  "id" : 222846720692858882,
  "created_at" : "2012-07-11 00:16:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222845800600965120",
  "text" : "\u3057\u304B\u3057\u65E2\u306B\u7D50\u69CB\u306A\u91CF\u306E\u30B3\u30FC\u30D2\u30FC\u3092\u98F2\u3093\u3067\u3044\u308B\u4E8B\u5B9F",
  "id" : 222845800600965120,
  "created_at" : "2012-07-11 00:12:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222845467690663937",
  "text" : "\u96E8\u300C\u6628\u591C\u5C11\u3057\u964D\u308A\u307E\u3057\u305F\u300D\n\u96E8\u300C\u3042\u306830\u5206\u3067\u964D\u308A\u59CB\u3081\u307E\u3059\u300D\n\u96E8\u300C\u6765\u9031\u306E\u706B\u66DC\u65E514\u6642\u304B\u3089\u96F7\u96E8\u3067\u3044\u3044\u3067\u3057\u3087\u3046\u304B\u300D",
  "id" : 222845467690663937,
  "created_at" : "2012-07-11 00:11:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222845217370423297",
  "text" : "\u96E8\u3082\u3061\u3083\u3093\u3068\u5831\u544A\uFF0C\u9023\u7D61\uFF0C\u76F8\u8AC7\u3057\u3066\u307B\u3057\u3044",
  "id" : 222845217370423297,
  "created_at" : "2012-07-11 00:10:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222845050713931776",
  "text" : "\u96E8\u3063\u3066\u4F55\u6642\u304B\u3089\u964D\u308B\u4E88\u5B9A\u306A\u3093\u3067\u3059\u304B\u306D\u3047",
  "id" : 222845050713931776,
  "created_at" : "2012-07-11 00:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222844908241829888",
  "text" : "2\u9650\u306B\u554F\u984C\u8CB0\u3044\u306B\u884C\u3063\u3066\u30F4\u30A7\u30EB\u30C7\u30A3\u3067\u4E00\u4EBA\u81EA\u7FD2\u30AB\u30D5\u30A7\u3059\u308B\u304B\u30FC\uFF0E\uFF08\u3055\u3063\u304D\u3068\u8A00\u3063\u3066\u308B\u3053\u3068\u304C\uFF09",
  "id" : 222844908241829888,
  "created_at" : "2012-07-11 00:09:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222840596006584323",
  "geo" : { },
  "id_str" : "222842295760846848",
  "in_reply_to_user_id" : 371621213,
  "text" : "@al2_d2 \u6D77\u969B\u306B\u4F4F\u3093\u3067\u3044\u308B\u6C34\u7523\u7CFB\u306E\u5927\u5B66\u306E\u53CB\u4EBA\u305F\u3061\u306F\u7D50\u69CB\u7ACB\u6D3E\u306A\u6C34\u69FD\u3092\u6301\u3063\u3066\u307E\u3057\u305F\u304C\u3084\u3063\u3071\u74B0\u5883\u6574\u3048\u308B\u306E\u5927\u5909\u3067\u3059\u3088\u306D\u30FC",
  "id" : 222842295760846848,
  "in_reply_to_status_id" : 222840596006584323,
  "created_at" : "2012-07-10 23:58:38 +0000",
  "in_reply_to_screen_name" : "al_pmn",
  "in_reply_to_user_id_str" : "371621213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222839642687422464",
  "text" : "\u3082\u3057\u304B\u3057\u3066:\u6765\u9031\u306E\u6708\u66DC\u306F\u6D77\u306E\u65E5",
  "id" : 222839642687422464,
  "created_at" : "2012-07-10 23:48:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222838924203143169",
  "geo" : { },
  "id_str" : "222839165971206145",
  "in_reply_to_user_id" : 371621213,
  "text" : "@al2_d2 \u898B\u308B\u306E\u306F\u597D\u304D\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u30FC(\u4F5C\u308B\u307B\u3069\u6687\u3067\u3082\u306A\u3051\u308C\u3070\u30DE\u30E1\u3067\u3082\u7121\u3044)",
  "id" : 222839165971206145,
  "in_reply_to_status_id" : 222838924203143169,
  "created_at" : "2012-07-10 23:46:11 +0000",
  "in_reply_to_screen_name" : "al_pmn",
  "in_reply_to_user_id_str" : "371621213",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222838899200888832",
  "text" : "\u3060\u3063\u3066\u65E5\u713C\u3051\u3059\u308B\u3058\u3083\u306A\u3044\u3067\u3059\u304B",
  "id" : 222838899200888832,
  "created_at" : "2012-07-10 23:45:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222838812915666944",
  "text" : "\u3067\u3082\u9577\u8896\u9577\u30BA\u30DC\u30F3\u30AC\u30C1\u52E2",
  "id" : 222838812915666944,
  "created_at" : "2012-07-10 23:44:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222838050085011456",
  "text" : "\u6D74\u8863\u6B32\u3057\u3044\u306A(\u3063\u3066\u6BCE\u5E74\u8A00\u3063\u3066\u308B)",
  "id" : 222838050085011456,
  "created_at" : "2012-07-10 23:41:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222824348183040000",
  "text" : "@kotorin_z \u304A\u304A\u30FC\u3001\u3084\u3063\u3071\u666E\u6BB5\u4F7F\u3046\u3082\u306E\u306B\u306F\u3053\u3060\u308F\u308A\u304C\u3042\u308A\u307E\u3059\u3088\u306D\uFF01\u305F\u307E\u305F\u307E\u4F7F\u3063\u3066\u306A\u3044\u3082\u306E\u304C\u3042\u3063\u305F\u306E\u3092\u601D\u3044\u51FA\u3057\u305F\u3060\u3051\u306A\u306E\u3067\u304A\u6C17\u306B\u306A\u3055\u3089\u305A\uFF01",
  "id" : 222824348183040000,
  "created_at" : "2012-07-10 22:47:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222818866202542081",
  "geo" : { },
  "id_str" : "222818998306344961",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3046\u3080\u3001\u4E86\u89E3\u3057\u305F",
  "id" : 222818998306344961,
  "in_reply_to_status_id" : 222818866202542081,
  "created_at" : "2012-07-10 22:26:03 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222818609204969473",
  "text" : "@kotorin_z \u5C0F\u3055\u3044\u306E\u3067\u826F\u3051\u308C\u30706\u7A74\u306E\u30D0\u30A4\u30F3\u30C0\u30FC\u578B\u306E\u3084\u3064\u3044\u308A\u307E\u3059\uFF1F\u4E2D\u8EAB\u3082\u4F59\u3063\u3066\u307E\u3059\u3002",
  "id" : 222818609204969473,
  "created_at" : "2012-07-10 22:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222818285681508354",
  "text" : "\u601D\u3044\u51FA\u3059\u305F\u3073\u306B\u5E78\u305B\u306B\u306A\u308B\u304B\u3089\u3044\u3044\u304B\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 222818285681508354,
  "created_at" : "2012-07-10 22:23:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222818225174495232",
  "text" : "\u6708\u66DC\u65E5\u795D\u65E5\u3063\u3066\u304A\u3068\u3068\u3044\u805E\u3044\u305F\u306E\u306B\u3082\u3046\u5FD8\u308C\u3066\u305F\u3002",
  "id" : 222818225174495232,
  "created_at" : "2012-07-10 22:22:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222818011432759296",
  "geo" : { },
  "id_str" : "222818111781482496",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u5FD8\u308C\u3066\u3066\u5E78\u305B\u306B\u5305\u307E\u308C\u307E\u3057\u305F\u3002",
  "id" : 222818111781482496,
  "in_reply_to_status_id" : 222818011432759296,
  "created_at" : "2012-07-10 22:22:32 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222817985931386880",
  "text" : "\u4E09\u9031\u9593\u306B\u4E94\u56DE\u3082\u6708\u66DC\u65E5\u304C\u3042\u308B\u306E\u306F\u3046\u308B\u3046\u79D2\u306E\u5F71\u97FF",
  "id" : 222817985931386880,
  "created_at" : "2012-07-10 22:22:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222817782859964416",
  "geo" : { },
  "id_str" : "222817866087530498",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u6765\u9031\u3082\u4E8C\u56DE\u3042\u308A\u307E\u3059",
  "id" : 222817866087530498,
  "in_reply_to_status_id" : 222817782859964416,
  "created_at" : "2012-07-10 22:21:33 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222817758885318656",
  "text" : "\u30A4\u30D6\u30CB\u30F3\u30B0\u3058\u3083\u3093",
  "id" : 222817758885318656,
  "created_at" : "2012-07-10 22:21:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222816141599444992",
  "geo" : { },
  "id_str" : "222817712341127168",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30E2\u30FC\u30CB\u30F3\u30B0\u30B3\u30FC\u30EB\u3057\u3088\u304B\uFF1F",
  "id" : 222817712341127168,
  "in_reply_to_status_id" : 222816141599444992,
  "created_at" : "2012-07-10 22:20:57 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222817588646920193",
  "text" : "\u4ECA\u65E5\u3082\u6691\u3044\u306D\u3047",
  "id" : 222817588646920193,
  "created_at" : "2012-07-10 22:20:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222811062150504450",
  "text" : "\u6700\u5F8C\u306E\u306F\u3061\u3087\u3063\u3068\u4F59\u8A08\u304B",
  "id" : 222811062150504450,
  "created_at" : "2012-07-10 21:54:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222810993993056258",
  "text" : "\u3060\u3044\u305F\u3044\u5E7E\u3089\u9577\u5C45\u3057\u3066\u3082\u826F\u304F\u3066\uFF0C\u30B3\u30FC\u30D2\u30FC\u306F\uFF08\u3061\u3087\u3063\u3068\u9762\u5012\u3060\u3051\u308C\u3069\uFF09\u98F2\u307F\u653E\u984C\u3067\uFF0C\u597D\u304D\u306A\u97F3\u697D\u3092\u639B\u3051\u3066\u3082\u8AB0\u3082\u6587\u53E5\u3092\u8A00\u308F\u306A\u3044\uFF0C\u8CC7\u6599\u304C\u624B\u306E\u5C4A\u304F\u3068\u3053\u308D\u306B\u3042\u3063\u3066\u30CD\u30C3\u30C8\u74B0\u5883\u306E\u3042\u308B\u7A7A\u9593\u3063\u3066\u5BB6\u304F\u3089\u3044\u3057\u304B\u306A\u3044\u3093\u3058\u3083",
  "id" : 222810993993056258,
  "created_at" : "2012-07-10 21:54:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222810649028329472",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u5BB6\u3067\u52C9\u5F37\u3059\u308B\u306E\u304C\u4E00\u756A\u6C17\u5B89\u3044\u304B\u3089\u5BB6\u304B\u3089\u51FA\u305F\u304F\u306A\u3044\u3093\u3060\u304C\uFF0E",
  "id" : 222810649028329472,
  "created_at" : "2012-07-10 21:52:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222810535681466370",
  "text" : "\u4ECA\u65E5\u306F\u6F14\u7FD2\u306A\u306E\u304B\u30FC\uFF0E\u554F\u984C\u3060\u3051\u3082\u3089\u3044\u306B\u884C\u304F\u306E\u3082\u3042\u308A\u304B\u306A\uFF0E",
  "id" : 222810535681466370,
  "created_at" : "2012-07-10 21:52:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222803289199214593",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u308B\u304B\u30FC\u3002\u3053\u306E\u6642\u9593\u306B\u92AD\u6E6F\u3084\u3063\u3066\u305F\u3089\u78BA\u5B9F\u306B\u884C\u304F\u306E\u306B\u306A\u30FC\u3002",
  "id" : 222803289199214593,
  "created_at" : "2012-07-10 21:23:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222803034869207040",
  "text" : "\u3074\u3088\u3074\u3088",
  "id" : 222803034869207040,
  "created_at" : "2012-07-10 21:22:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222803023515238402",
  "text" : "\u65E9\u8D77\u304D\u3053\u3068\u308A\u3093\u304B\u3068\u601D\u3044\u304D\u3084\u3001\u4E0D\u7720\u3053\u3068\u308A\u3093\u3060\u3063\u305F",
  "id" : 222803023515238402,
  "created_at" : "2012-07-10 21:22:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222801573997322240",
  "text" : "\u5ACB\u3084\u304B\u3067\u3057\u306A\u3084\u304B\u3067",
  "id" : 222801573997322240,
  "created_at" : "2012-07-10 21:16:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222801490073489408",
  "text" : "\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u304C\u7A4F\u3084\u304B\u3067\u7DE9\u3084\u304B\u3067",
  "id" : 222801490073489408,
  "created_at" : "2012-07-10 21:16:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222789164289110017",
  "text" : "\u4ECA\u65E5\u3063\u3066\u6708\u66DC\u306E\u3058\u304B\u3093\u308F\u308A\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 222789164289110017,
  "created_at" : "2012-07-10 20:27:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/RM6L5b1F",
      "expanded_url" : "http:\/\/www.satosyokuhin.co.jp\/cooking\/rice\/rice_rec14.html",
      "display_url" : "satosyokuhin.co.jp\/cooking\/rice\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222788505175199747",
  "text" : "\u306A\u306B\u3053\u308C\u7F8E\u5473\u3057\u3044 http:\/\/t.co\/RM6L5b1F",
  "id" : 222788505175199747,
  "created_at" : "2012-07-10 20:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222783765733314560",
  "text" : "\u3055\u3066\u3001\u5BA3\u8A00\u901A\u308A\u8D77\u304D\u305F\u304C",
  "id" : 222783765733314560,
  "created_at" : "2012-07-10 20:06:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222686070297460737",
  "text" : "\u304A\u3084\u3059\u307F\uFF0E",
  "id" : 222686070297460737,
  "created_at" : "2012-07-10 13:37:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222683648422449152",
  "geo" : { },
  "id_str" : "222683684338270208",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 222683684338270208,
  "in_reply_to_status_id" : 222683648422449152,
  "created_at" : "2012-07-10 13:28:22 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222683570857193472",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u5165\u308C\u3066\u304A\u3051\u3070\u3055\u3081\u308B\u3057\u30A4\u30A4\u30CD\uFF0E",
  "id" : 222683570857193472,
  "created_at" : "2012-07-10 13:27:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222683443543277568",
  "text" : "\u4ECA\u5BDD\u30665\u6642\u304F\u3089\u3044\u306B\u8D77\u304D\u305F\u3089\u7D20\u6575\u6EC5\u6CD5\u306A\u306E\u3067\u306F\uFF1F",
  "id" : 222683443543277568,
  "created_at" : "2012-07-10 13:27:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222683366925926400",
  "text" : "\u305D\u3046\u304B\uFF0E\u4EEE\u7720\u304B\uFF0E\u305D\u308C\u3067\u751F\u6D3B\u30EA\u30BA\u30E0\u3092\u76F4\u3059\uFF0E\u60AA\u304F\u306A\u3044\uFF0E",
  "id" : 222683366925926400,
  "created_at" : "2012-07-10 13:27:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/HCj9fNIr",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/348?prefill=pilomn",
      "display_url" : "gohantabeyo.com\/nani\/348?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222676098142576640",
  "text" : "\u6D74\u8863\u3067\u30C7\u30FC\u30C8\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/HCj9fNIr",
  "id" : 222676098142576640,
  "created_at" : "2012-07-10 12:58:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222661543114973184",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 222661543114973184,
  "created_at" : "2012-07-10 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/319Nij2T",
      "expanded_url" : "http:\/\/4sq.com\/PKolaB",
      "display_url" : "4sq.com\/PKolaB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "222614898969026560",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/319Nij2T",
  "id" : 222614898969026560,
  "created_at" : "2012-07-10 08:55:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222568093354962945",
  "text" : "\u304F\u308B\u304F\u308B\u304F\u308B\u304F\u308B\u304F\u308B\u304F\u308B",
  "id" : 222568093354962945,
  "created_at" : "2012-07-10 05:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308B\u304F\u308B(\u3064\u3044\u304D\u3093\u3057\u305F\u3044)",
      "screen_name" : "KURUKURU888333",
      "indices" : [ 0, 15 ],
      "id_str" : "337502390",
      "id" : 337502390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222566459166031872",
  "geo" : { },
  "id_str" : "222566639684694016",
  "in_reply_to_user_id" : 337502390,
  "text" : "@KURUKURU888333 \u305D\u308C\u306F\u3042\u306A\u305F\u3067\u3059\uFF01",
  "id" : 222566639684694016,
  "in_reply_to_status_id" : 222566459166031872,
  "created_at" : "2012-07-10 05:43:16 +0000",
  "in_reply_to_screen_name" : "KURUKURU888333",
  "in_reply_to_user_id_str" : "337502390",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222566537062653954",
  "text" : "4\u9650\u304C\u3001\u59CB\u307E\u308B\u6642\u9593",
  "id" : 222566537062653954,
  "created_at" : "2012-07-10 05:42:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222566272842477568",
  "geo" : { },
  "id_str" : "222566427591319554",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u304A\u306F\u3088\u30FC\u3054\u3056\u3044\u307E\u305B\u3093\u3002\u304A\u305D\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 222566427591319554,
  "in_reply_to_status_id" : 222566272842477568,
  "created_at" : "2012-07-10 05:42:26 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222566159109730304",
  "text" : "\u3053\u3053\u306B\u3044\u3061\u3083\u30C0\u30E1\u3067\u3059\u3001\u306E\u3044\u3061\u3083\uFF1F",
  "id" : 222566159109730304,
  "created_at" : "2012-07-10 05:41:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222566000867024896",
  "text" : "\u30A4\u30C1\u30E3\u30A4\u30C1\u30E3\u306E\u3044\u3061\u3083\u3063\u3066\u4F55",
  "id" : 222566000867024896,
  "created_at" : "2012-07-10 05:40:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222434931769487360",
  "text" : "5\u6642\u304B\u308911\u6642\u307E\u30676\u6642\u9593\u3082\u3042\u308B\u3093\u3060\u3088\u306D\u3002\u4ECA\u30846\u6642\u3060\u3051\u3069\u3002",
  "id" : 222434931769487360,
  "created_at" : "2012-07-09 20:59:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222434748797169664",
  "text" : "\u306D\u3047\u30016\u6642\u3060\u3088",
  "id" : 222434748797169664,
  "created_at" : "2012-07-09 20:59:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222405559524134912",
  "text" : "\u306A\u308B\u307B\u3069\u30014\u6642\u3058\u3083\u306D\u30FC\u306E",
  "id" : 222405559524134912,
  "created_at" : "2012-07-09 19:03:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222382979765387266",
  "text" : "\u306F\u3058\u3081\u3088\u3046\u3080\u306D\u304A\u3069\u308B\u3088\u3046\u306A",
  "id" : 222382979765387266,
  "created_at" : "2012-07-09 17:33:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u70CF\u9F8D\u8336\u306F\u7F8E\u5473\u3044",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222382782712778752",
  "text" : "#\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u70CF\u9F8D\u8336\u306F\u7F8E\u5473\u3044",
  "id" : 222382782712778752,
  "created_at" : "2012-07-09 17:32:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222377177642045440",
  "text" : "\u4E2D\u9014\u534A\u7AEF\u306B\u6A2A\u306B\u306A\u308B\u3060\u3051\u306A\u3089\u52C9\u5F37\u3059\u308B\u3079\u304D\u306A\u306E",
  "id" : 222377177642045440,
  "created_at" : "2012-07-09 17:10:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222376699587862528",
  "text" : "5\u6642\u301C11\u6642\u3063\u30666\u6642\u9593\u3082\u3042\u308B\u3093\u3060\u306A\u30FC\u3001\u3075\u30FC\u3093",
  "id" : 222376699587862528,
  "created_at" : "2012-07-09 17:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3057\u3083\u3053",
      "screen_name" : "nashacom",
      "indices" : [ 0, 9 ],
      "id_str" : "90918872",
      "id" : 90918872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222374002923024384",
  "geo" : { },
  "id_str" : "222374157541851137",
  "in_reply_to_user_id" : 90918872,
  "text" : "@nashacom \u304A\u304B\u3048\u308A\u30A1\uFF01",
  "id" : 222374157541851137,
  "in_reply_to_status_id" : 222374002923024384,
  "created_at" : "2012-07-09 16:58:25 +0000",
  "in_reply_to_screen_name" : "nashacom",
  "in_reply_to_user_id_str" : "90918872",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222373785003757568",
  "text" : "\u305F\u3057\u304B\u5927\u962A\u6885\u7530\u306E\u672C\u5C4B\u304B\u3089\u65B0\u5BBF\u306B\u53D6\u308A\u5BC4\u305B\u305F\u3093\u3060\u3063\u3051\u304B\u3001\u3042\u306E\u6642\u306F\u3002",
  "id" : 222373785003757568,
  "created_at" : "2012-07-09 16:56:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222373437090439168",
  "text" : "\u3053\u3046\u3044\u3046\u306E\u524D\u306B\u3082\u3042\u3063\u305F\u306A\u3002\u305F\u3057\u304B\u5730\u5B66\u306E\u30BB\u30F3\u30BF\u30FC\u554F\u984C\u96C6\u304B\u3002",
  "id" : 222373437090439168,
  "created_at" : "2012-07-09 16:55:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222373281192349696",
  "text" : "\u306A\u308B\u307B\u3069\u3001\u4F1A\u793E\u306B\u5728\u5EAB\u304C\u306A\u3044\u3001\u3068\u3002",
  "id" : 222373281192349696,
  "created_at" : "2012-07-09 16:54:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222352574207115265",
  "text" : "\u9154\u3046yo",
  "id" : 222352574207115265,
  "created_at" : "2012-07-09 15:32:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222352544960233472",
  "text" : "\u4ECA\u307E\u3067\u306E\u56DE\u8EE2\u306B\u52A0\u3048\u3066\u76BF\u306E\u56DE\u8EE2\uFF0C\u30CD\u30BF\u306E\u56DE\u8EE2\uFF0C\u30B7\u30E3\u30EA\u306E\u56DE\u8EE2\uFF0C\u305D\u3057\u3066\u5E97\u5168\u4F53\u304C\u56DE\u8EE2\u3059\u308B",
  "id" : 222352544960233472,
  "created_at" : "2012-07-09 15:32:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u3042\u308B",
      "screen_name" : "fuwafuwa_Fuaru",
      "indices" : [ 3, 18 ],
      "id_str" : "237330800",
      "id" : 237330800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222352353989369856",
  "text" : "RT @fuwafuwa_Fuaru: \u5BFF\u53F8\u306B\u3053\u308C\u307E\u3067\u306E4\u500D\u306E\u56DE\u8EE2\u3092\u4E0E\u3048\u3066\u304F\u308C\u3066\u3044\u3044\u304B\u3089\u4FA1\u683C\u304C4\u5206\u306E1\u306B\u306A\u3089\u306A\u3044\u304B\u306A\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222352223903031296",
    "text" : "\u5BFF\u53F8\u306B\u3053\u308C\u307E\u3067\u306E4\u500D\u306E\u56DE\u8EE2\u3092\u4E0E\u3048\u3066\u304F\u308C\u3066\u3044\u3044\u304B\u3089\u4FA1\u683C\u304C4\u5206\u306E1\u306B\u306A\u3089\u306A\u3044\u304B\u306A\u3002",
    "id" : 222352223903031296,
    "created_at" : "2012-07-09 15:31:15 +0000",
    "user" : {
      "name" : "\u3075\u3042\u308B",
      "screen_name" : "fuwafuwa_Fuaru",
      "protected" : false,
      "id_str" : "237330800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606238942044647424\/R1YAek2g_normal.png",
      "id" : 237330800,
      "verified" : false
    }
  },
  "id" : 222352353989369856,
  "created_at" : "2012-07-09 15:31:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222351942125494273",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u518D\u53D7\u9A13\u3059\u308B\u6D41\u308C\u306B\u306A\u3063\u3066\u308B\u5922\u3092\u898B\u305F\uFF0E\u5730\u6B74\u3084\u3093\u306A\u304F\u3066\u3044\u3044\uFF01\u3063\u3066\u30C6\u30F3\u30B7\u30E7\u30F3\u3042\u3052\u3066\u305F\uFF0E",
  "id" : 222351942125494273,
  "created_at" : "2012-07-09 15:30:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222351635119226881",
  "text" : "\u3053\u306E\u9854\u6587\u5B57\u306E\u624B\u4F5C\u308A\u611F\u304C\u30E4\u30D0\u3044",
  "id" : 222351635119226881,
  "created_at" : "2012-07-09 15:28:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222351536217526272",
  "text" : "\uFF3F\u4EBA\u4EBA \u4EBA\u4EBA\uFF3F\n\uFF1E  \uFF08\uFF1E\uFF0E\uFF1C\uFF09 \uFF1C \u2190\u72ED\u305D\u3046\n\uFFE3Y^Y^YY^Y\uFFE3",
  "id" : 222351536217526272,
  "created_at" : "2012-07-09 15:28:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222351313265102848",
  "text" : "\uFF3F\u4EBA\u4EBA \u4EBA\u4EBA\uFF3F\n\uFF1E \u8C46\u8150\u306B\u93B9\uFF01\uFF1C\n\uFFE3Y^Y^YY^Y\uFFE3",
  "id" : 222351313265102848,
  "created_at" : "2012-07-09 15:27:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222351240405843970",
  "text" : "\uFF3F\u4EBA\u4EBA \u4EBA\u4EBA\uFF3F\n\uFF1E \u306C\u304B\u306B\u91D8\uFF01\uFF1C\n\uFFE3Y^Y^YY^Y\uFFE3",
  "id" : 222351240405843970,
  "created_at" : "2012-07-09 15:27:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222351126585020416",
  "text" : "\u30EA\u30D7\u30E9\u30A4\u3057\u306B\u3057\u3066\u306F\u7121\u99C4\u306B\u624B\u304C\u8FBC\u3093\u3067\u3044\u308B\uFF0E",
  "id" : 222351126585020416,
  "created_at" : "2012-07-09 15:26:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222351074407878660",
  "text" : "RT @akeopyaa: @end313124 \n\u6BBA\u4F10\u3068\u3057\u305F\uFF34\uFF2C\u306B\u30CA\u30C3\u30C8\u304C\uFF01\uFF01\n\u3000\u3000\u3000\u3000 \uFFE2\u3000\u3000\u2190\u30D0\u30FC\u30EB\u306E\u3088\u3046\u306A\u3082\u306E\n\uFF3F\u4EBA\u4EBA \u4EBA\u4EBA\uFF3F\n\uFF1E \u306C\u304B\u306B\u91D8\uFF01\uFF1C\n\uFFE3Y^Y^YY^Y\uFFE3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "222350334754963458",
    "geo" : { },
    "id_str" : "222351022574682114",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \n\u6BBA\u4F10\u3068\u3057\u305F\uFF34\uFF2C\u306B\u30CA\u30C3\u30C8\u304C\uFF01\uFF01\n\u3000\u3000\u3000\u3000 \uFFE2\u3000\u3000\u2190\u30D0\u30FC\u30EB\u306E\u3088\u3046\u306A\u3082\u306E\n\uFF3F\u4EBA\u4EBA \u4EBA\u4EBA\uFF3F\n\uFF1E \u306C\u304B\u306B\u91D8\uFF01\uFF1C\n\uFFE3Y^Y^YY^Y\uFFE3",
    "id" : 222351022574682114,
    "in_reply_to_status_id" : 222350334754963458,
    "created_at" : "2012-07-09 15:26:29 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 222351074407878660,
  "created_at" : "2012-07-09 15:26:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222350784552112129",
  "text" : "\u304A\u304A\uFF0C\u30DB\u30E1\u30AA\uFF0C\u3069\u3046\u3057\u3066\u3042\u306A\u305F\u306F\u30DB\u30E1\u30AA\u306A\u306E",
  "id" : 222350784552112129,
  "created_at" : "2012-07-09 15:25:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222350708974956544",
  "text" : "\u30DB\u30E1\u30AA\u3068\u30D6\u30E9\u30B1\u30C3\u30C8",
  "id" : 222350708974956544,
  "created_at" : "2012-07-09 15:25:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222350279218176001",
  "geo" : { },
  "id_str" : "222350334754963458",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \uFFE2\u30CA\u30C3\u30C8",
  "id" : 222350334754963458,
  "in_reply_to_status_id" : 222350279218176001,
  "created_at" : "2012-07-09 15:23:45 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222349893631619073",
  "text" : "\u6700\u4E2D\u3092\u98DF\u3079\u308B\u6700\u4E2D",
  "id" : 222349893631619073,
  "created_at" : "2012-07-09 15:22:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222349806771781633",
  "text" : "\u30E2\u30CA\u30AB\u3082\u306A\u304B\u306A\u304B\u306E\u3082\u306E\u304B",
  "id" : 222349806771781633,
  "created_at" : "2012-07-09 15:21:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222349626316034048",
  "geo" : { },
  "id_str" : "222349700320342016",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u306F\u3044\u3066\u30FC\u3068\u3044\u3068\u3044\u304B\u3068",
  "id" : 222349700320342016,
  "in_reply_to_status_id" : 222349626316034048,
  "created_at" : "2012-07-09 15:21:14 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222349480035495936",
  "text" : "\u30B3\u30FC\u30EB\u304C\u307F\u3093\u306A\u3092\u547C\u3093\u3067\u3044\u308B\uFF0E",
  "id" : 222349480035495936,
  "created_at" : "2012-07-09 15:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222349330265280512",
  "text" : "\u3067\u3082\u7D50\u69CB\u597D\u304D",
  "id" : 222349330265280512,
  "created_at" : "2012-07-09 15:19:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222349302075371520",
  "text" : "\u3053\u308C\u306F\u3072\u3063\u3069\u3044",
  "id" : 222349302075371520,
  "created_at" : "2012-07-09 15:19:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 88, 98 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 125, 134 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222349279619072000",
  "text" : "RT @akeopyaa: \u3054\u3081\u3093\u306A\u3055\u3044\uFF3C(&gt;_&lt;)\uFF0F\u3000\u30CD\u30C1\u30B1\u30C3\u30C8\u306B\u53CD\u3057\u307E\u3057\u305F\u306D\u3002\u30FB\u00B0\u00B0\u30FB(&gt;_&lt;)\u30FB\u00B0\u00B0\u30FB\u3002\u3000\u4EE5\u5F8C\u6C17\u3092\u3064\u3051\u307E\u3059( \u00B0O \u00B0;) RT @end313124 \u975E\u516C\u5F0F\u306F\u3084\u3081\u3066\u304F\u3060\u3055\u3044\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01RT @akeopyaa:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 74, 84 ],
        "id_str" : "155546700",
        "id" : 155546700
      }, {
        "name" : "\u8266\u5A18",
        "screen_name" : "akeopyaa",
        "indices" : [ 111, 120 ],
        "id_str" : "112398542",
        "id" : 112398542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "222348699106410500",
    "geo" : { },
    "id_str" : "222349233720795136",
    "in_reply_to_user_id" : 155546700,
    "text" : "\u3054\u3081\u3093\u306A\u3055\u3044\uFF3C(&gt;_&lt;)\uFF0F\u3000\u30CD\u30C1\u30B1\u30C3\u30C8\u306B\u53CD\u3057\u307E\u3057\u305F\u306D\u3002\u30FB\u00B0\u00B0\u30FB(&gt;_&lt;)\u30FB\u00B0\u00B0\u30FB\u3002\u3000\u4EE5\u5F8C\u6C17\u3092\u3064\u3051\u307E\u3059( \u00B0O \u00B0;) RT @end313124 \u975E\u516C\u5F0F\u306F\u3084\u3081\u3066\u304F\u3060\u3055\u3044\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01RT @akeopyaa: \u975E\u516C\u5F0F\u3054\u3081\u3093\u306D",
    "id" : 222349233720795136,
    "in_reply_to_status_id" : 222348699106410500,
    "created_at" : "2012-07-09 15:19:23 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 222349279619072000,
  "created_at" : "2012-07-09 15:19:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222349167220113408",
  "text" : "\u975E\u786C\u5F0F\u2026\u3064\u307E\u308A\u8EDF\u5F0F",
  "id" : 222349167220113408,
  "created_at" : "2012-07-09 15:19:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348935681945600",
  "text" : "\u52A0\u5BB3\u8005\u300C\u8ECA\u306E\u4FE1\u53F7\u306F\u9752\u3067\u3057\u305F\u300D\n\u88AB\u5BB3\u8005\u300C\u6B69\u884C\u8005\u306E\u4FE1\u53F7\u306F\u9752\u3067\u3057\u305F\u300D",
  "id" : 222348935681945600,
  "created_at" : "2012-07-09 15:18:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348783336431616",
  "text" : "\u4E8B\u6545\u8A00\u53CA\u306E\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9",
  "id" : 222348783336431616,
  "created_at" : "2012-07-09 15:17:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 26, 35 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348699106410500",
  "text" : "\u975E\u516C\u5F0F\u306F\u3084\u3081\u3066\u304F\u3060\u3055\u3044\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01RT @akeopyaa: \u975E\u516C\u5F0F\u3054\u3081\u3093\u306D",
  "id" : 222348699106410500,
  "created_at" : "2012-07-09 15:17:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348508424966144",
  "text" : "\u4E0B\u6BB5\u3092GetDown",
  "id" : 222348508424966144,
  "created_at" : "2012-07-09 15:16:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348436505247745",
  "text" : "\u4E2D\u6BB5\u3092\u4E2D\u65AD\uFF08\u30AD\u30E3\u30F3\u30BB\u30EB\uFF09",
  "id" : 222348436505247745,
  "created_at" : "2012-07-09 15:16:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348383212412929",
  "text" : "\u5197\u8AC7\u304C\u523A\u3055\u308B\uFF0E\u4E0A\u6BB5\u304C\u523A\u3055\u308B\uFF0E",
  "id" : 222348383212412929,
  "created_at" : "2012-07-09 15:16:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348226001502210",
  "text" : "\u5197\u8AC7\u306F\u826F\u304F\u306A\u3044\uFF0E",
  "id" : 222348226001502210,
  "created_at" : "2012-07-09 15:15:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "indices" : [ 3, 11 ],
      "id_str" : "20522410",
      "id" : 20522410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348187413905408",
  "text" : "RT @halhorn: \u3061\u3087\u3063\u3068\u5F85\u3063\u3066\uFF01\uFF17\u6708\u3082\u30461\/3\u7D42\u308F\u3063\u3061\u3083\u3063\u305F\u306E\uFF01\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222348155293925376",
    "text" : "\u3061\u3087\u3063\u3068\u5F85\u3063\u3066\uFF01\uFF17\u6708\u3082\u30461\/3\u7D42\u308F\u3063\u3061\u3083\u3063\u305F\u306E\uFF01\uFF1F",
    "id" : 222348155293925376,
    "created_at" : "2012-07-09 15:15:05 +0000",
    "user" : {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "protected" : false,
      "id_str" : "20522410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550565137359204353\/hwjKwmzK_normal.jpeg",
      "id" : 20522410,
      "verified" : false
    }
  },
  "id" : 222348187413905408,
  "created_at" : "2012-07-09 15:15:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222348021986361344",
  "text" : "\u7406\u8A70\u3081\u3067\u30EA\u30BA\u30E0\u3092\u523B\u3080 is \u7121\u7406",
  "id" : 222348021986361344,
  "created_at" : "2012-07-09 15:14:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222347817346281475",
  "text" : "\u751F\u6D3B\u30EA\u30BA\u30E0\u6539\u5584\u306E\u30D7\u30E9\u30F3\u3092",
  "id" : 222347817346281475,
  "created_at" : "2012-07-09 15:13:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222346065343557633",
  "text" : "\u9AEA\u304C\u9B31\u9676\u3057\u3044\u5B63\u7BC0\u306B\u306A\u3063\u3066\u307E\u3044\u308A\u307E\u3057\u305F\uFF0E",
  "id" : 222346065343557633,
  "created_at" : "2012-07-09 15:06:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222250488094134272",
  "text" : "\u30A6\u30FC\u30ED\u30F3\u8336",
  "id" : 222250488094134272,
  "created_at" : "2012-07-09 08:47:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222016083291406338",
  "text" : "3\n6\u3092\u51FA\u3057\u305F\u3089\u305D\u306E\u679A\u6570\u5F15\u304F\n\u30C9\u30E9\u3042\u304C\u308A\u306E\u7981\u6B62\n\u30C9\u30E9\u306B\u5BFE\u3057\u3066\u4EBA\u9593\u306E\u6570\u3067\u52DD\u3066\u308B\n\u5BCC\u8C6A\u306F3\u679A\u516C\u958B\n\u4EBA\u9593\u306B\u5BFE\u3057\u3066\u52D5\u7269\u306E\u6570\u3067\u52DD\u3066\u308B\nQ\u306F\u30C9\u30ED\u30FC2",
  "id" : 222016083291406338,
  "created_at" : "2012-07-08 17:15:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222016035073695746",
  "text" : "2\n\u6574\u6570\u306E\u9806\u5E8F\u3067\u306E\u968E\u6BB5 \uFF11\uFF13\uFF0D\uFF11\u3060\u3081\u30671-2-3-4\u30FB\u30FB\u30FB\u306F\u3042\u308A\n\u3061\u3087\u3044\u843D\u3061\n555\u3067\u9806\u756A\u30B9\u30AD\u30C3\u30D7\n\u30B9\u30DA3\u306F\u56FA\u6709\u3088\u308A\u5F37\u304F\u3066\u3001\u30C9\u30E9\u3088\u308A\u5F31\u3044 \u5EC3\u6B62\n\u57FA\u672C\u9769\u547D\u72B6\u614B\n7\u3092\u51FA\u3057\u305F\u3089\u305D\u306E\u679A\u6570\u3092\u6368\u3066\u306A\u3051\u308C\u3070\u306A\u3089\u306A\u3044\n\u5E73\u6C11\u306F31415926535\u3068\u6368\u3066\u3089\u308C\u308B\u3060\u3051\u6368\u3066\u3066\u3082\u826F\u3044",
  "id" : 222016035073695746,
  "created_at" : "2012-07-08 17:15:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222015740885204993",
  "text" : "\u5927\u5BCC\u8C6A\u306B\u5165\u3063\u305F\u30EB\u30FC\u30EB\u307E\u3068\u30811\n\u9769\u547D\njk\u4EFB\u610F\u306B\u5909\u66F4\u53EF\n\u4EA4\u63DB\n\u50D5\u306E\u8003\u3048\u305F\u6700\u5F37\u306E\u6570\n8\n11\u3067\u5F37\u5F31\u3068\u9806\u5E8F\n\u7D20\u6570\u7E1B\u308A2\n\u8D64\u9ED2\u4EA4\u4E923\n2jk\u3067\u306E\u4E0A\u304C\u308A\u7981\u6B62\n7\u4E09\u679A\u3067\u901A\u5E38\u306E\u9806\u5E8F\u306B\n\u30C9\u30E9\n\u89AA\u7236\u30AE\u30E3\u30B0\u3092\u3044\u3046 \u5E73\u6C11\u304C1\u3064\n\u88CF\u30C9\u30E9 \u5BCC\u8C6A\u304C\u6368\u3066\u672D\u304B\u3089\u4E00\u679A\u30E9\u30F3\u30C0\u30E0\u306B",
  "id" : 222015740885204993,
  "created_at" : "2012-07-08 17:14:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221956051199725568",
  "text" : "\u901F\u5831 \u5927\u5BCC\u8C6A\u306B\u88CF\u30C9\u30E9\u306E\u6982\u5FF5",
  "id" : 221956051199725568,
  "created_at" : "2012-07-08 13:17:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221936777399771136",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 221936777399771136,
  "created_at" : "2012-07-08 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221858206694129665",
  "text" : "Q. \u3053\u306E\u5BC4\u5E2D\u3092\u4F55\u3067\u77E5\u308A\u307E\u3057\u305F\u304B\uFF1F\nA.\u30A2\u30C9\u8857\u3092\u898B\u305F\uFF0E",
  "id" : 221858206694129665,
  "created_at" : "2012-07-08 06:48:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221855752975949824",
  "text" : "18:30\u3067\u3082\u3044\u3044\u304B\u3082",
  "id" : 221855752975949824,
  "created_at" : "2012-07-08 06:38:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221855353174896640",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3059\u307F\u307E\u305B\u3093\u3001\u96C6\u3044\u306E\u4F1A\u8B70\u304C20\u6642\u304B\u3089\u306A\u306E\u3067\u3061\u3087\u3063\u3068\u65E9\u3081\u3067\u3059\u304C18\u6642\u304F\u3089\u3044\u304B\u3089\u306B\u306A\u308A\u307E\u305B\u3093\u304B\u306D",
  "id" : 221855353174896640,
  "created_at" : "2012-07-08 06:36:52 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221840292066770944",
  "text" : "\u4EF2\u5165\u308A\u30FC",
  "id" : 221840292066770944,
  "created_at" : "2012-07-08 05:37:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221821882029182976",
  "text" : "\u82B1\u5CA1\u3055\u3093\u6765\u3066\u308B\u30FC\uFF1F",
  "id" : 221821882029182976,
  "created_at" : "2012-07-08 04:23:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221820554657804288",
  "text" : "\u5411\u304B\u3044\u306B\u3057\u3050\u307E\u3063\u304F\u3059\u3055\u3093\u3075\u3075\u3075",
  "id" : 221820554657804288,
  "created_at" : "2012-07-08 04:18:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221819904251269120",
  "text" : "@i_horse \u5C11\u306A\u304F\u3068\u3082\u4E00\u4EBA\u306F\u8D77\u304D\u3066\u308B\u306F\u305A\u306A\u3093\u3067\u3059\u304C\u306D\u3047",
  "id" : 221819904251269120,
  "created_at" : "2012-07-08 04:16:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221819669881962496",
  "text" : "\u3053\u308C\u304C\u7B54\u3048\u304B",
  "id" : 221819669881962496,
  "created_at" : "2012-07-08 04:15:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 3, 12 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221819647119474688",
  "text" : "RT @iwa_bj21: \u5BDD\u574A\u3057\u305F\u3042\u3042\u3042",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221819431922302978",
    "text" : "\u5BDD\u574A\u3057\u305F\u3042\u3042\u3042",
    "id" : 221819431922302978,
    "created_at" : "2012-07-08 04:14:08 +0000",
    "user" : {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "protected" : false,
      "id_str" : "305542897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1369723363\/45_normal.jpg",
      "id" : 305542897,
      "verified" : false
    }
  },
  "id" : 221819647119474688,
  "created_at" : "2012-07-08 04:14:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221819567633215489",
  "text" : "\u7720\u6C17\u3092\u62BC\u3057\u3066\u5F85\u3061\u5408\u308F\u305B\u6642\u9593\u30AE\u30EA\u30AE\u30EA\u306B\u7740\u305F\u3089\u8AB0\u3082\u3044\u306A\u304B\u3063\u305F\u6642\u306E\u9854\u3057\u3066\u308B",
  "id" : 221819567633215489,
  "created_at" : "2012-07-08 04:14:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96A3\u306E\u3068\u306A\u308A",
      "screen_name" : "tonar_no_tonari",
      "indices" : [ 0, 16 ],
      "id_str" : "262045935",
      "id" : 262045935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221811860352147456",
  "geo" : { },
  "id_str" : "221813676485779456",
  "in_reply_to_user_id" : 262045935,
  "text" : "@tonar_no_tonari \u52A9\u304B\u308A\u307E\u3057\u305F\u3002\u3069\u3046\u3082\u3067\u3059\u3002",
  "id" : 221813676485779456,
  "in_reply_to_status_id" : 221811860352147456,
  "created_at" : "2012-07-08 03:51:16 +0000",
  "in_reply_to_screen_name" : "tonar_no_tonari",
  "in_reply_to_user_id_str" : "262045935",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221811748917882881",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3057\u3083\u308F\u30FC",
  "id" : 221811748917882881,
  "created_at" : "2012-07-08 03:43:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221764498976026624",
  "geo" : { },
  "id_str" : "221764596908826624",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u7D76\u5BFE\u8D77\u304D\u306A\u3044\u3093\u3067\u3084\u3081\u307E\u3057\u3087\u3046",
  "id" : 221764596908826624,
  "in_reply_to_status_id" : 221764498976026624,
  "created_at" : "2012-07-08 00:36:14 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221764497663201280",
  "text" : "\u30E2\u30FC\u30CB\u30F3\u30B0\u3058\u3083\u306D\u3047\u2026",
  "id" : 221764497663201280,
  "created_at" : "2012-07-08 00:35:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221764401617829889",
  "text" : "\u8AB0\u304B12\u6642\u306B\u5727\u5012\u7684\u30E2\u30FC\u30CB\u30F3\u30B0\u30B3\u30FC\u30EB\u983C\u307F\u307E\u3059",
  "id" : 221764401617829889,
  "created_at" : "2012-07-08 00:35:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221764330545348610",
  "text" : "\u3061\u3087\u3063\u3068\u3060\u3051\u2026\u3061\u3087\u3063\u3068\u3060\u3051\u5BDD\u304B\u305B\u3066\u305F\u3082\u308C\uFF0E",
  "id" : 221764330545348610,
  "created_at" : "2012-07-08 00:35:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221763506616283136",
  "geo" : { },
  "id_str" : "221764209741004800",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u591C\u306A\u3089\u884C\u3051\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u304C\uFF0C\u5BDD\u3066\u3044\u308B\u304B\u3082\u3057\u308C\u307E\u305B\u3093\uFF0E\u663C\u306A\u3089\u5148\u7D04\u3042\u308B\u306E\u3067\u7121\u7406\u3067\u3059\u306D\uFF0E",
  "id" : 221764209741004800,
  "in_reply_to_status_id" : 221763506616283136,
  "created_at" : "2012-07-08 00:34:42 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221757846562422785",
  "geo" : { },
  "id_str" : "221757889625325568",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u5426\u3063\uFF01",
  "id" : 221757889625325568,
  "in_reply_to_status_id" : 221757846562422785,
  "created_at" : "2012-07-08 00:09:35 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221757678677000192",
  "geo" : { },
  "id_str" : "221757806154498048",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u50D5\u306F\u5BDD\u308B\u304B\u8FF7\u3063\u3066\u307E\u3059\uFF0E\uFF08\u305F\u3076\u3093\u5BDD\u307E\u3059\uFF0E\uFF09",
  "id" : 221757806154498048,
  "in_reply_to_status_id" : 221757678677000192,
  "created_at" : "2012-07-08 00:09:15 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221757464570372096",
  "geo" : { },
  "id_str" : "221757514570678272",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u304A\u5927\u4E8B\u306B\u30FC",
  "id" : 221757514570678272,
  "in_reply_to_status_id" : 221757464570372096,
  "created_at" : "2012-07-08 00:08:06 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221757371804950529",
  "text" : "\uFF91\uFF98\uFF80\uFF9E\uFF85",
  "id" : 221757371804950529,
  "created_at" : "2012-07-08 00:07:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221757349575139328",
  "text" : "\u96C6\u5408\u307E\u30674\u6642\u9593\u307B\u3069\u3042\u308B\u304C\u304C\u304C\u304C\uFF0E\u3053\u308C\u5BDD\u305F\u3089\u30C0\u30E1\u306A\u3084\u3064\u3060\u3088\u306A\u30FC\uFF0E2\u6642\u9593\u304F\u3089\u3044\u3067\u8D77\u304D\u3089\u308C\u308B\u306E\u304B\u306A\uFF0E",
  "id" : 221757349575139328,
  "created_at" : "2012-07-08 00:07:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221755912539471872",
  "geo" : { },
  "id_str" : "221756047696728065",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 221756047696728065,
  "in_reply_to_status_id" : 221755912539471872,
  "created_at" : "2012-07-08 00:02:16 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221755950971883520",
  "text" : "\u305D\u3057\u3066\u5727\u5012\u7684\u5E30\u5B85\uFF01",
  "id" : 221755950971883520,
  "created_at" : "2012-07-08 00:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221751376747823106",
  "text" : "\u5927\u52DD\u5229\u3060\u3063\u305F\u306E\u3067\u3075\u3075\u3075\u3075\u3075",
  "id" : 221751376747823106,
  "created_at" : "2012-07-07 23:43:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221751163823992833",
  "text" : "\u534A\u83586\u56DE\u3092\u6226\u3044\u629C\u3044\u3066\u6B69\u3044\u3066\u5E30\u8DEF",
  "id" : 221751163823992833,
  "created_at" : "2012-07-07 23:42:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221657694501740545",
  "geo" : { },
  "id_str" : "221750953966186497",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u6642\u9593\u306F\u30FC\uFF1F",
  "id" : 221750953966186497,
  "in_reply_to_status_id" : 221657694501740545,
  "created_at" : "2012-07-07 23:42:02 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    }, {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 9, 18 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221656373245652992",
  "geo" : { },
  "id_str" : "221657207094247425",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax @iwa_bj21 \u6A2A\u304B\u3089\u5727\u5012\u7684\u7406\u89E3\uFF01\u8D77\u304D\u3089\u308C\u308B\u306E\u304B\u2026",
  "id" : 221657207094247425,
  "in_reply_to_status_id" : 221656373245652992,
  "created_at" : "2012-07-07 17:29:31 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221574379371376642",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 221574379371376642,
  "created_at" : "2012-07-07 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221476815422767104",
  "text" : "\u5357\u86EE",
  "id" : 221476815422767104,
  "created_at" : "2012-07-07 05:32:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221476799186608128",
  "text" : "\u305D\u3093\u306A\u3093\u3070\u3093\u3054\u306F\u3093\u306B\u306A\u308B\u306B\u6C7A\u307E\u3063\u3066\u308B",
  "id" : 221476799186608128,
  "created_at" : "2012-07-07 05:32:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221476022212767744",
  "text" : "\u30AB\u30EA\u30FC\u4EE5\u5916\u306E\u6587\u5B57\u306B\u5E83\u304C\u3089\u306A\u3044\u306E\u306F\u304C\u3063\u304B\u308A",
  "id" : 221476022212767744,
  "created_at" : "2012-07-07 05:29:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 0, 7 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 19, 30 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221474809773686784",
  "text" : "@tenapi @9110alice @noukoknows \u30AB\u30EC\u30FC\u306F\u4E00\u56DE\u4F5C\u308B\u3068\u30AB\u30EC\u30FC\u3070\u3063\u304B\u308A\u30FC\u306B\u306A\u308A\u307E\u3059\u3088\u306D\u30FC",
  "id" : 221474809773686784,
  "created_at" : "2012-07-07 05:24:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221474342037504001",
  "text" : "\u30D0\u30F3\u30D1\u30A4\u30A2\u3063\u3066\u3042\u308C\u3067\u3057\u3087\u3001\u9280\u306E\u30CB\u30F3\u30CB\u30AF\u304C\u82E6\u624B\u306A\u5316\u3051\u7269\u3067\u3057\u3087\u3001\u3048\u3093\u3069\u3057\u3063\u3066\u308B",
  "id" : 221474342037504001,
  "created_at" : "2012-07-07 05:22:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221265646737031168",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 221265646737031168,
  "created_at" : "2012-07-06 15:33:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221265525727166466",
  "text" : "\u7761\u7720\u306E\u8CEA\u306F\u843D\u3061\u308B\u3051\u308C\u3069",
  "id" : 221265525727166466,
  "created_at" : "2012-07-06 15:33:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221265444525441026",
  "text" : "\u5FC3\u5730\u3088\u304F\u5165\u7720\u3059\u308B\u3068\u3057\u307E\u3057\u3087\u3046",
  "id" : 221265444525441026,
  "created_at" : "2012-07-06 15:32:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221265249968463873",
  "text" : "\u30AB\u30B7\u30B9\u30BD\u30FC\u30C0\u3067\u982D\u304C\u3075\u308F\u3075\u308F\u3059\u308B\u7A0B\u5EA6\u306B\u306F\u304A\u9152\u306B\u5F31\u3044\u9F6221",
  "id" : 221265249968463873,
  "created_at" : "2012-07-06 15:32:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221264664993087489",
  "text" : "\u65E5\u5409\u307E\u3067\u884C\u3053\u3046\u3068\u601D\u3048\u3070\u65B0\u5E79\u7DDA\u3067\u884C\u3051\u308B\u3002\u3067\u3082\u65B0\u5E79\u7DDA\u3092\u6301\u3063\u3066\u3044\u306A\u3044",
  "id" : 221264664993087489,
  "created_at" : "2012-07-06 15:29:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221263918922862592",
  "text" : "\u72D0\u3055\u3093\u300C\u3075\u3093\u3001\u837B\u91CE\u304B\u8429\u91CE\u304B\u3001\u305D\u3093\u306A\u306E\u306F\u3069\u3061\u3089\u3067\u3082\u540C\u3058\u3053\u3068\u3060\u3002\u300D",
  "id" : 221263918922862592,
  "created_at" : "2012-07-06 15:26:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221256635144880129",
  "text" : "\u306A\u3093\u304B\u304A\u9152\u98F2\u3080\u304B\u2026",
  "id" : 221256635144880129,
  "created_at" : "2012-07-06 14:57:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221255897010290690",
  "text" : "\u306A\u3093\u304B\u5149\u3063\u305F\u3068\u601D\u3063\u305F\u3089\u96F7",
  "id" : 221255897010290690,
  "created_at" : "2012-07-06 14:54:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221252819913687043",
  "text" : "\u6D77\u304C\u304D\u3053\u3048\u308B\u3063\u3066\u898B\u305F\u3053\u3068\u306A\u3044\u304B\u3082\u3001\u898B\u3066\u305F\u3068\u3057\u3066\u3082\u5370\u8C61\u306B\u306A\u3093\u306B\u3082\u6B8B\u3063\u3066\u306A\u3044",
  "id" : 221252819913687043,
  "created_at" : "2012-07-06 14:42:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "indices" : [ 3, 13 ],
      "id_str" : "515476338",
      "id" : 515476338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221252565055184896",
  "text" : "RT @hatsusato: \u3068\u306A\u308A\u306E\u5C71\u7530\u541B\u304C\u898B\u305F\u3044\u3002\u3042\u306E\u51C4\u307E\u3058\u3044\u4F5C\u753B\u3092\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221252410067255299",
    "text" : "\u3068\u306A\u308A\u306E\u5C71\u7530\u541B\u304C\u898B\u305F\u3044\u3002\u3042\u306E\u51C4\u307E\u3058\u3044\u4F5C\u753B\u3092\u3002",
    "id" : 221252410067255299,
    "created_at" : "2012-07-06 14:40:59 +0000",
    "user" : {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "protected" : false,
      "id_str" : "515476338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1908669681\/enter_normal.gif",
      "id" : 515476338,
      "verified" : false
    }
  },
  "id" : 221252565055184896,
  "created_at" : "2012-07-06 14:41:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221252114196856832",
  "text" : "\u732B\u306E\u5927\u7FA4\u304C\u4E3B\u4EBA\u516C\u3092\u732B\u306E\u56FD\u306B\u9023\u308C\u3066\u884C\u304F\u30B7\u30FC\u30F3\u304C\u672C\u7DE8\u3067\u305D\u308C\u3088\u308A\u524D\u306F\u30D7\u30ED\u30ED\u30FC\u30B0\u3067\u305D\u308C\u4EE5\u964D\u306F\u30A8\u30D4\u30ED\u30FC\u30B0",
  "id" : 221252114196856832,
  "created_at" : "2012-07-06 14:39:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221251872579788800",
  "text" : "\u732B\u306E\u6069\u8FD4\u3057\u3084\u308B\u306A\u3089\u898B\u305F\u3044\u306A",
  "id" : 221251872579788800,
  "created_at" : "2012-07-06 14:38:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221251064136073216",
  "text" : "\u6620\u50CF\u306F\u3068\u3082\u304B\u304F\u539F\u4F5C\u306F\u7D50\u69CB\u697D\u3057\u304F\u8AAD\u3081\u305F\u8A18\u61B6\u304C\u3042\u308B\u3093\u3060\u3051\u3069\u306A\u30FC\u3001\u9577\u3044\u3051\u308C\u3069\u3002",
  "id" : 221251064136073216,
  "created_at" : "2012-07-06 14:35:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221250947819646976",
  "text" : "\u30B2\u30C9\u6226\u8A18\u306F\u4E00\u6642\u671F\u5999\u306B\u53D6\u308A\u4E0A\u3052\u3089\u308C\u3066\u3044\u305F\u3051\u308C\u3069\u3001\u4ECA\u3084\u82E5\u5E72\u306A\u304B\u3063\u305F\u3053\u3068\u306B\u3055\u3048\u306A\u308A\u304B\u3051\u3066\u3044\u308B\u3088\u306A\u30FC",
  "id" : 221250947819646976,
  "created_at" : "2012-07-06 14:35:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221250379013308419",
  "text" : "\u30C8\u30C8\u30ED\u306B\u51FA\u3066\u304F\u308B\u307F\u3063\u3061\u3083\u3093\u306E\u8A71\u3059\u308B\u3068\u8AB0\uFF1F\u3063\u3066\u306A\u308B\u304B\u3089\u304A\u52E7\u3081",
  "id" : 221250379013308419,
  "created_at" : "2012-07-06 14:32:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3069\u306E\u53E3\u304C\u8A00\u3046",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221249629814136835",
  "text" : "RT @shigmax: \u307F\u3093\u306A\u3082\u3063\u3068\u4F5C\u54C1\u898B\u308B\u3053\u3068\u306B\u96C6\u4E2D\u3057\u305F\u307B\u3046\u304C\u3044\u3044\u3068\u601D\u3046\u3093\u3060 \uFF03\u3069\u306E\u53E3\u304C\u8A00\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u3069\u306E\u53E3\u304C\u8A00\u3046",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221249496259117056",
    "text" : "\u307F\u3093\u306A\u3082\u3063\u3068\u4F5C\u54C1\u898B\u308B\u3053\u3068\u306B\u96C6\u4E2D\u3057\u305F\u307B\u3046\u304C\u3044\u3044\u3068\u601D\u3046\u3093\u3060 \uFF03\u3069\u306E\u53E3\u304C\u8A00\u3046",
    "id" : 221249496259117056,
    "created_at" : "2012-07-06 14:29:25 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 221249629814136835,
  "created_at" : "2012-07-06 14:29:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8DE1\u5730",
      "screen_name" : "C4H10O2FP",
      "indices" : [ 0, 10 ],
      "id_str" : "559501524",
      "id" : 559501524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221248884989632512",
  "geo" : { },
  "id_str" : "221249266583212033",
  "in_reply_to_user_id" : 73630344,
  "text" : "@C4H10O2FP \u66F8\u7C4D\u3092\u304A\u52E7\u3081\u3057\u307E\u3059\u3002\u81EA\u5206\u3082\u5168\u90E8\u306F\u3088\u3081\u3066\u307E\u305B\u3093\u304C\u6620\u50CF\u3088\u308A\u306F\u826F\u3044\u3067\u3059\u3002",
  "id" : 221249266583212033,
  "in_reply_to_status_id" : 221248884989632512,
  "created_at" : "2012-07-06 14:28:30 +0000",
  "in_reply_to_screen_name" : "tubo28",
  "in_reply_to_user_id_str" : "73630344",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221248658992144385",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u30B2\u30C9\u6226\u8A18\u3067\u3082\u771F\u540D\u304C\u91CD\u8981\u306A\u30D5\u30A1\u30AF\u30BF\u30FC\u3060\u3063\u305F\u306A\u30FC",
  "id" : 221248658992144385,
  "created_at" : "2012-07-06 14:26:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221248462602244098",
  "text" : "\u82D7\u5B57\u3067\u5B58\u5728\u3092\u7E1B\u3089\u308C\u308B\u5FCD\u3061\u3083\u3093",
  "id" : 221248462602244098,
  "created_at" : "2012-07-06 14:25:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221248377214603267",
  "text" : "\u540D\u524D\u306F\u5927\u4E8B\uFF1F",
  "id" : 221248377214603267,
  "created_at" : "2012-07-06 14:24:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221244477052948480",
  "text" : "\u8AB0\u306B\u3082\u4F1D\u308F\u3089\u306A\u3044\u6C17\u304C\u3059\u308B #nowplaying Ogre who cries - A\uFF5EYA",
  "id" : 221244477052948480,
  "created_at" : "2012-07-06 14:09:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221233235760390144",
  "geo" : { },
  "id_str" : "221233434662666242",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u6B63\u3057\u304F\u306F \u3046\u306A\u304E \u3067\u3059\uFF01\uFF01\uFF01",
  "id" : 221233434662666242,
  "in_reply_to_status_id" : 221233235760390144,
  "created_at" : "2012-07-06 13:25:35 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221232657181327360",
  "text" : "\u30A2\u30CB\u30E1\u696D\u754C\u304D\u3063\u3066\u306E\u4EE3\u8868\u7684\u59B9\u30AD\u30E3\u30E9\u3067\u3042\u308B\u92AD\u5A46\u304C\u51FA\u3066\u308B\u3084\u3064\u3084\u3093",
  "id" : 221232657181327360,
  "created_at" : "2012-07-06 13:22:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221232373516349442",
  "text" : "\u306A\u3093\u3060\u3001\u5343\u3068\u5343\u5C0B\u3084\u3063\u3066\u308B\u306E\u304B",
  "id" : 221232373516349442,
  "created_at" : "2012-07-06 13:21:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221109746504179712",
  "text" : "\u76EE\u899A\u307E\u3057\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B\uFF0E\u30B9\u30A4\u30C3\u30C1\u3092\u30AA\u30F3\u306B\u3057\u640D\u306D\u308B\u3068\u306F...",
  "id" : 221109746504179712,
  "created_at" : "2012-07-06 05:14:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221109614085812224",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 221109614085812224,
  "created_at" : "2012-07-06 05:13:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221109601213497345",
  "text" : "\u4E8C\u9650\u2026\u51FA\u305F\u304B\u3063\u305F\u306E\u306B\u306A\u3041\uFF08\u9060\u3044\u76EE",
  "id" : 221109601213497345,
  "created_at" : "2012-07-06 05:13:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220918306046091266",
  "text" : "\u304B\u307F\u304C\u306A\u304B\u306A\u304B\u304B\u308F\u304B\u306A\u3044",
  "id" : 220918306046091266,
  "created_at" : "2012-07-05 16:33:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220917876197031936",
  "text" : "\u8868\u8A18\u306E\u3086\u308C\u3086\u308C",
  "id" : 220917876197031936,
  "created_at" : "2012-07-05 16:31:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220917678372700161",
  "geo" : { },
  "id_str" : "220917813500592128",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u7A7A\u306F\u3042\u304F\u307E\u3067\u7A7A\u306A\u3093\u3067\u3059\u3057\uFF1F",
  "id" : 220917813500592128,
  "in_reply_to_status_id" : 220917678372700161,
  "created_at" : "2012-07-05 16:31:25 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220917502522302464",
  "text" : "\u30BC\u30ED\u30B9\u30E9\u30C3\u30B7\u30E5",
  "id" : 220917502522302464,
  "created_at" : "2012-07-05 16:30:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220917216462372869",
  "text" : "\u7A7A\u3063\u3066\u3044\u3046\u3088\u3046\u306B\u305B\u306A\u3070\u3002\u308F\u304B\u3063\u3066\u3066\u3082\u30D5\u30A1\u30A4\u3063\u3066\u8A00\u3044\u304C\u3061",
  "id" : 220917216462372869,
  "created_at" : "2012-07-05 16:29:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 3, 14 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/8nqwf9dZ",
      "expanded_url" : "http:\/\/oku.edu.mie-u.ac.jp\/~okumura\/blog\/node\/2577",
      "display_url" : "oku.edu.mie-u.ac.jp\/~okumura\/blog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220916996227874816",
  "text" : "RT @noukoknows: http:\/\/t.co\/8nqwf9dZ\u3000\u3053\u3093\u306A\u8A18\u4E8B\u304C\uFF08\u7A7A\u96C6\u5408\u306E\u8A18\u53F7\u306B\u3064\u3044\u3066\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/8nqwf9dZ",
        "expanded_url" : "http:\/\/oku.edu.mie-u.ac.jp\/~okumura\/blog\/node\/2577",
        "display_url" : "oku.edu.mie-u.ac.jp\/~okumura\/blog\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "220916614500073473",
    "text" : "http:\/\/t.co\/8nqwf9dZ\u3000\u3053\u3093\u306A\u8A18\u4E8B\u304C\uFF08\u7A7A\u96C6\u5408\u306E\u8A18\u53F7\u306B\u3064\u3044\u3066\uFF09",
    "id" : 220916614500073473,
    "created_at" : "2012-07-05 16:26:39 +0000",
    "user" : {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "protected" : true,
      "id_str" : "348990022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000720729836\/990edaf9c5011972665a60414d8f2569_normal.png",
      "id" : 348990022,
      "verified" : false
    }
  },
  "id" : 220916996227874816,
  "created_at" : "2012-07-05 16:28:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220916076597358593",
  "text" : "\u305D\u306E\u6A5F\u4F1A\u3092\u3082\u305F\u305B\u308B\u3079\u304D\u306F\u6587\u7CFB\u306E\u4EBA\u9593\u306A\u3093\u3060\u304C\u2026",
  "id" : 220916076597358593,
  "created_at" : "2012-07-05 16:24:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3061\u3085",
      "screen_name" : "Matsch1024",
      "indices" : [ 3, 14 ],
      "id_str" : "265454236",
      "id" : 265454236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220915892761001984",
  "text" : "RT @Matsch1024: \u79D1\u5B66\u30EA\u30C6\u30E9\u30B7\u30FC\u3068\u304B\u3092\u8003\u3048\u3066\u3057\u307E\u3046\u3068\u6C17\u304C\u6EC5\u5165\u308B\u3057\uFF0C\u305D\u3082\u305D\u3082\u81EA\u767A\u7684\u306B\u305D\u3046\u3044\u3046\u3053\u3068\u306B\u307E\u3067\u8003\u3048\u304C\u56DE\u308B\u307B\u3069\u79C1\u306F\u6559\u80B2\u7684\u306A\u4EBA\u9593\u3067\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220915774989152256",
    "text" : "\u79D1\u5B66\u30EA\u30C6\u30E9\u30B7\u30FC\u3068\u304B\u3092\u8003\u3048\u3066\u3057\u307E\u3046\u3068\u6C17\u304C\u6EC5\u5165\u308B\u3057\uFF0C\u305D\u3082\u305D\u3082\u81EA\u767A\u7684\u306B\u305D\u3046\u3044\u3046\u3053\u3068\u306B\u307E\u3067\u8003\u3048\u304C\u56DE\u308B\u307B\u3069\u79C1\u306F\u6559\u80B2\u7684\u306A\u4EBA\u9593\u3067\u306A\u3044",
    "id" : 220915774989152256,
    "created_at" : "2012-07-05 16:23:19 +0000",
    "user" : {
      "name" : "\u307E\u3061\u3085",
      "screen_name" : "Matsch1024",
      "protected" : true,
      "id_str" : "265454236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436878927580000258\/FVpOxnos_normal.png",
      "id" : 265454236,
      "verified" : false
    }
  },
  "id" : 220915892761001984,
  "created_at" : "2012-07-05 16:23:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/jr2RxGik",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/37?prefill=ahh_Jun",
      "display_url" : "gohantabeyo.com\/nani\/37?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220910626170617856",
  "text" : "\u98F2\u307F\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/jr2RxGik",
  "id" : 220910626170617856,
  "created_at" : "2012-07-05 16:02:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220907297344471040",
  "text" : "\u5727\u5012\u7684\u5E30\u5B85\uFF01",
  "id" : 220907297344471040,
  "created_at" : "2012-07-05 15:49:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u501F\u308A\u65C5\u884C\u306E\u30C8\u30DE\u30B8\u30A6\u30B9",
      "screen_name" : "kagyu_phis",
      "indices" : [ 0, 11 ],
      "id_str" : "129850436",
      "id" : 129850436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220836153450967041",
  "geo" : { },
  "id_str" : "220850646801334273",
  "in_reply_to_user_id" : 129850436,
  "text" : "@kagyu_phis \u3054\u660E\u5BDF(^^)(^^)(^^)",
  "id" : 220850646801334273,
  "in_reply_to_status_id" : 220836153450967041,
  "created_at" : "2012-07-05 12:04:32 +0000",
  "in_reply_to_screen_name" : "kagyu_phis",
  "in_reply_to_user_id_str" : "129850436",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220824349601570817",
  "geo" : { },
  "id_str" : "220850587372232704",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u571F\u98DF\u3079\u308B\u3084\u3064\uFF57\uFF57\uFF57\uFF57",
  "id" : 220850587372232704,
  "in_reply_to_status_id" : 220824349601570817,
  "created_at" : "2012-07-05 12:04:17 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220849615346466817",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 220849615346466817,
  "created_at" : "2012-07-05 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u3055\u304B\u307F\u25C6\u30D5\u30A9\u30C8\u30CB\u30B3 6\/11-14",
      "screen_name" : "Hosaka_Mi",
      "indices" : [ 3, 13 ],
      "id_str" : "151459600",
      "id" : 151459600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220823072813481984",
  "text" : "RT @Hosaka_Mi: \u5C0F\u91CE\u2025\u30A4\u30CA\u30D5\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220822929854832640",
    "text" : "\u5C0F\u91CE\u2025\u30A4\u30CA\u30D5\uFF01",
    "id" : 220822929854832640,
    "created_at" : "2012-07-05 10:14:23 +0000",
    "user" : {
      "name" : "\u307B\u3055\u304B\u307F\u25C6\u30D5\u30A9\u30C8\u30CB\u30B3 6\/11-14",
      "screen_name" : "Hosaka_Mi",
      "protected" : false,
      "id_str" : "151459600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593593198393434114\/pqwdAxYH_normal.png",
      "id" : 151459600,
      "verified" : false
    }
  },
  "id" : 220823072813481984,
  "created_at" : "2012-07-05 10:14:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3063\u3064\u304D\u306E\u307F",
      "screen_name" : "downy_821",
      "indices" : [ 0, 10 ],
      "id_str" : "287541933",
      "id" : 287541933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220822830353358848",
  "geo" : { },
  "id_str" : "220823003561336833",
  "in_reply_to_user_id" : 287541933,
  "text" : "@downy_821 \u305F\u307E\u305F\u307E\u3067\u3059\u304C\u4ECA\u5468\u308A\u306B\u77E5\u3063\u3066\u308B\u4EBA\u3044\u306A\u304B\u3063\u305F\u306E\u3067\u3064\u3044w",
  "id" : 220823003561336833,
  "in_reply_to_status_id" : 220822830353358848,
  "created_at" : "2012-07-05 10:14:41 +0000",
  "in_reply_to_screen_name" : "downy_821",
  "in_reply_to_user_id_str" : "287541933",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220822692448829441",
  "text" : "\u30D5\u30A3\u30C3\u30B7\u30E5\u7AF9\u4E2D\u3055\u3093\u77E5\u3063\u3066\u308B\u4EBA\u3044\u306A\u3044\uFF1F",
  "id" : 220822692448829441,
  "created_at" : "2012-07-05 10:13:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306A\u3082\u3061",
      "screen_name" : "null_min",
      "indices" : [ 0, 9 ],
      "id_str" : "480291899",
      "id" : 480291899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220822116201799681",
  "geo" : { },
  "id_str" : "220822202226970624",
  "in_reply_to_user_id" : 480291899,
  "text" : "@null_min \u7F8E\u5473\u3057\u3044\u3067\u3059\u3088\u30FC",
  "id" : 220822202226970624,
  "in_reply_to_status_id" : 220822116201799681,
  "created_at" : "2012-07-05 10:11:30 +0000",
  "in_reply_to_screen_name" : "null_min",
  "in_reply_to_user_id_str" : "480291899",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220822036010897408",
  "text" : "\u5927\u8C46\u306F\u82F1\u8A9E\u3067\u30BD\u30A4\u3067\u3042\u308B",
  "id" : 220822036010897408,
  "created_at" : "2012-07-05 10:10:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220687255948374016",
  "text" : "\u96FB\u5353\u3068\u5F62\u3070\u304B\u308A\u306E\u7761\u7720\u3092\u53D6\u308A\u306B\u5E30\u308B\u304B\u306A\u30FC",
  "id" : 220687255948374016,
  "created_at" : "2012-07-05 01:15:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220681619617497088",
  "text" : "\u307E\u3055\u304B\u904E\u304E\u3066\u3075\u3075\u3075",
  "id" : 220681619617497088,
  "created_at" : "2012-07-05 00:52:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220681188757614592",
  "text" : "\u3053\u3053\u3060\u3051\u9BAE\u660E\u306B\u805E\u3053\u3048\u305F\u3042\u305F\u308A\u610F\u8B58\u4E0D\u660E",
  "id" : 220681188757614592,
  "created_at" : "2012-07-05 00:51:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30AD\u30EA\u30B9\u30C8\u6559\u5B66",
      "indices" : [ 35, 42 ]
    }, {
      "text" : "0\u306F\u81EA\u7136\u6570",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220681059078123520",
  "text" : "\u81EA\u7136\u6570\u306F\u3057\u3070\u3089\u304F1\u304B\u3089\u59CB\u307E\u3063\u3066\u2026\n\u301C\u3051\u30690\u3068\u3044\u3046\u306E\u304C\u898B\u3064\u304B\u3063\u3066\u4E91\u3005\u2026\n#\u30AD\u30EA\u30B9\u30C8\u6559\u5B66 #0\u306F\u81EA\u7136\u6570",
  "id" : 220681059078123520,
  "created_at" : "2012-07-05 00:50:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220666767071117313",
  "text" : "\u98DF\u751F\u6D3B\u304C\u8352\u308C\u308B\u3068\u3001\u808C\u304C\u8352\u308C\u308B\u3002\u4F53\u306F\u6848\u5916\u7D20\u76F4\u306B\u3067\u304D\u3066\u3044\u308B\u3002",
  "id" : 220666767071117313,
  "created_at" : "2012-07-04 23:53:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220666503270379521",
  "text" : "\u96E8\u964D\u308B\u306A\u3089\u4E00\u5EA6\u5E30\u3089\u306A\u3044\u3068\u30C0\u30E1\u3060\u306A",
  "id" : 220666503270379521,
  "created_at" : "2012-07-04 23:52:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220666171526086657",
  "text" : "\u308F\u304B\u3063\u3066\u3044\u305F\u3088\uFF01\uFF01\u541B\u304C\u305D\u308D\u305D\u308D\u30EC\u30DD\u30FC\u30C8\u306E\u8A73\u7D30\u306B\u3064\u3044\u3066\u8A71\u3059\u3067\u3042\u308D\u3046\u3053\u3068\u306F\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 220666171526086657,
  "created_at" : "2012-07-04 23:51:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220661033591783424",
  "text" : "\u3055\u3041\u305D\u306E\u70BA\u306B\u8D77\u304D\u305F\u3093\u3060\uFF0E\u51FA\u304B\u3051\u3088\u3046\uFF0E",
  "id" : 220661033591783424,
  "created_at" : "2012-07-04 23:31:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220656126641979392",
  "text" : "\u30E0\u30B7\u30E0\u30B7\u3059\u308B\u306A\u3041\u30FC",
  "id" : 220656126641979392,
  "created_at" : "2012-07-04 23:11:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 2, 11 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 12, 21 ],
      "id_str" : "126927392",
      "id" : 126927392
    }, {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 22, 32 ],
      "id_str" : "158645894",
      "id" : 158645894
    }, {
      "name" : "\u660E\u65E5\u5948@\u898F\u5236",
      "screen_name" : "saionjiasuna1",
      "indices" : [ 33, 47 ],
      "id_str" : "584394248",
      "id" : 584394248
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 48, 57 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u3084\u307E\u3063\u304F",
      "screen_name" : "y___m___c",
      "indices" : [ 58, 68 ],
      "id_str" : "271929353",
      "id" : 271929353
    }, {
      "name" : "\u975E\u305F\u305F\u307F\u3093",
      "screen_name" : "xwordsaladx",
      "indices" : [ 69, 81 ],
      "id_str" : "379731234",
      "id" : 379731234
    }, {
      "name" : "\u305F\u306C\u305F\u306C\uFF1E\u03C9\uFF1C",
      "screen_name" : "FireRacoon",
      "indices" : [ 82, 93 ],
      "id_str" : "225002271",
      "id" : 225002271
    }, {
      "name" : "\u63D0\u7763\u306F\u3057\u3051\u3093*\u30D0\u30B1\u30C4\u5099\u84C4",
      "screen_name" : "hashiken716",
      "indices" : [ 104, 116 ],
      "id_str" : "100018219",
      "id" : 100018219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220655959083716608",
  "text" : ". @akeopyaa @hanaoka_ @eclair_15 @saionjiasuna1 @nisehorn @y___m___c @xwordsaladx @FireRacoon @ispamgis @hashiken716 \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 220655959083716608,
  "created_at" : "2012-07-04 23:10:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220654885081853952",
  "text" : "\u5168\u304F\uFF0C\u80C3\u3092\u4F55\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u3093\u3060\uFF0E",
  "id" : 220654885081853952,
  "created_at" : "2012-07-04 23:06:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220654783575498752",
  "text" : "\u76EE\u304C\u899A\u3081\u305F\u3053\u3068\u306B\u3057\u3088\u3046\uFF0E\u3057\u304B\u3057\u6628\u65E5\u304B\u3089\u80C3\u306B\u8CA0\u62C5\u306E\u304B\u304B\u308B\u3053\u3068\u3057\u304B\u3057\u3066\u3044\u306A\u3044\uFF0E",
  "id" : 220654783575498752,
  "created_at" : "2012-07-04 23:06:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 0, 9 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220653969091989504",
  "geo" : { },
  "id_str" : "220654243466588160",
  "in_reply_to_user_id" : 126927392,
  "text" : "@hanaoka_ \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 220654243466588160,
  "in_reply_to_status_id" : 220653969091989504,
  "created_at" : "2012-07-04 23:04:05 +0000",
  "in_reply_to_screen_name" : "hanaoka_",
  "in_reply_to_user_id_str" : "126927392",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220653393067249664",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 220653393067249664,
  "created_at" : "2012-07-04 23:00:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220653348381143040",
  "text" : "\u304A\u304D\u305F",
  "id" : 220653348381143040,
  "created_at" : "2012-07-04 23:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220592048489762817",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uFF0E",
  "id" : 220592048489762817,
  "created_at" : "2012-07-04 18:56:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220592037597163520",
  "text" : "\u5BDD\u308B\u3075\u308A\u3092\u3059\u308B\u304B\u30FC\uFF0E",
  "id" : 220592037597163520,
  "created_at" : "2012-07-04 18:56:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220591997239574528",
  "text" : "@reflexio \u304D\u307F\u306F\u306A\u306B\u304B\u3042\u3063\u3068\u3046\u3066\u304D\u306B\u304B\u3093\u3061\u304C\u3044\u3057\u3066\u3044\u308B",
  "id" : 220591997239574528,
  "created_at" : "2012-07-04 18:56:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 8, 17 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220591582540341248",
  "text" : "\u304A\u3044\u3084\u3081\u308DRT @reflexio: FB\u3067\u6328\u62F6\u7206\u6483\u3057\u3088\u3046\u3068\u601D\u3063\u305F\u3089\u9023\u6253\u7981\u6B62\u3060\u3063\u305F",
  "id" : 220591582540341248,
  "created_at" : "2012-07-04 18:55:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220591559429718016",
  "text" : "\u6C7A\u3057\u3066\u7121\u8996\u3067\u304D\u306A\u3044\uFF0E",
  "id" : 220591559429718016,
  "created_at" : "2012-07-04 18:55:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 3, 12 ],
      "id_str" : "305542897",
      "id" : 305542897
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220591525409722368",
  "text" : "RT @iwa_bj21: @end313124 \u30AB\u30B9\u30B1\u30FC\u30C9\u3057\u306A\u304C\u3089\u9707\u3048\u58F0\u7DF4\u7FD2\u3057\u3066\u3066\u3082\u7121\u8996\u3057\u306A\u3044\u3067\u306Dwww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "220591098777702400",
    "geo" : { },
    "id_str" : "220591461765353472",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u30AB\u30B9\u30B1\u30FC\u30C9\u3057\u306A\u304C\u3089\u9707\u3048\u58F0\u7DF4\u7FD2\u3057\u3066\u3066\u3082\u7121\u8996\u3057\u306A\u3044\u3067\u306Dwww",
    "id" : 220591461765353472,
    "in_reply_to_status_id" : 220591098777702400,
    "created_at" : "2012-07-04 18:54:37 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "protected" : false,
      "id_str" : "305542897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1369723363\/45_normal.jpg",
      "id" : 305542897,
      "verified" : false
    }
  },
  "id" : 220591525409722368,
  "created_at" : "2012-07-04 18:54:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220591428944928768",
  "text" : "@reflexio \u30DB\u30C6\u30EB\u306E\u53D7\u4ED8\u3068\u304B\u306B\u3042\u308B\uFF81\uFF9D\uFF6F\u3063\u3066\u97F3\u304C\u9CF4\u308B\u6A5F\u4F1A\u3067\u3082\uFF8B\uFF9E\uFF78\uFF6F\u3066\u306A\u308B\u30EC\u30D9\u30EB\u306B\u8ABF\u6559\u3055\u308C\u3066\u3044\u308B\uFF0E",
  "id" : 220591428944928768,
  "created_at" : "2012-07-04 18:54:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220590586107928576",
  "geo" : { },
  "id_str" : "220591098777702400",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u51FA\u96F2\u8DEF\u6A4B\u3067\u305C\u3072\uFF57\uFF57\uFF57",
  "id" : 220591098777702400,
  "in_reply_to_status_id" : 220590586107928576,
  "created_at" : "2012-07-04 18:53:10 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220590813590200320",
  "text" : "\u3061\u306A\u307F\u306B\u3046\u3061\u306E\u76EE\u899A\u307E\u3057\u30AD\u30E3\u30D9\u30C4\u4E00\u3064\u3076\u3093\u304F\u3089\u3044\u306E\u30B5\u30A4\u30BA\u3068\uFF0C\u30D9\u30EB\u306E\u97F3\u306B\u810A\u9AC4\u53CD\u5C04\u7684\u306B\u9A5A\u304F\u3088\u3046\u306B\u4EBA\u3092\u5909\u3048\u308B\u7A0B\u5EA6\u306E\u97F3\u91CF\u304C\uFF08\u3042\u308B\u3044\u306F\u6028\u970A\u304C\uFF09\u3042\u308A\u307E\u3059\uFF0E",
  "id" : 220590813590200320,
  "created_at" : "2012-07-04 18:52:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220590497457115136",
  "text" : "\u76EE\u899A\u307E\u3057\u3092\u53F0\u6240\u306B\u65BC\u3051\u3070\u5426\u304C\u5FDC\u3067\u3082\u53F0\u6240\u306B\u884C\u304B\u306A\u3044\u3068\u3044\u3051\u306A\u3044\u306E\u3067\uFF0C\u305D\u306E\u8DB3\u3067\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3092\u98F2\u3080\uFF0E\u305D\u3057\u305F\u3089\uFF0C\u307B\u3089\uFF0C\u5727\u5012\u7684\u306B\u76EE\u304C\u899A\u3081\u308B\u3093\u3058\u3083\u306A\u3044\u3060\u308D\u3046\u304B\uFF0E",
  "id" : 220590497457115136,
  "created_at" : "2012-07-04 18:50:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220590309015429120",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u3092\u51B7\u3084\u3057\u3066\u304A\u3044\u3066\u7121\u7406\u77E2\u7406\u4E00\u9650\u306B\u8D77\u304D\u3066\u51FA\u308B\uFF0E\u3068\u3044\u3046\u5727\u5012\u7684\u9078\u629E\u80A2\uFF0E\u305D\u3046\u3067\u3082\u3057\u306A\u3044\u3068\u3053\u306E\u81EA\u5815\u843D\u306A\u30EA\u30BA\u30E0\u306F\u6CBB\u3089\u306A\u3044\uFF0E",
  "id" : 220590309015429120,
  "created_at" : "2012-07-04 18:50:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220589955892785152",
  "text" : "\u304A \u306F\u3088\u3046\uFF0C\u3053 \u3093\u306B \u3061\u308F\uFF0C\u3053 \u3093\u3070 \u3093\u308F\uFF0C\u304A \u306F \u3088\u3046\uFF0C\u304A \u3084\u3059 \u307F\uFF0C\u3069\u308C\u3082\u30B7\u30F3\u30D7\u30EB\u306A\u304C\u3089\u7D50\u69CB\u597D\u304D\u306A\u8A00\u8449\u306A\u3093\u3060\u3051\u308C\u3069\uFF0E",
  "id" : 220589955892785152,
  "created_at" : "2012-07-04 18:48:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220589642238529536",
  "text" : "\u6328\u62F6\u306E\u6A5F\u80FD\u3060\u3051\u3084\u3063\u3071\u308A\u307E\u3060\u7D0D\u5F97\u3067\u304D\u306A\u3044\uFF0E\u6328\u62F6\u306B\u306F\u305D\u308C\u305E\u308C\u8A00\u8449\u304C\u3042\u308B\u3093\u3060\u304B\u3089\u305D\u308C\u3092\u4F7F\u3046\u3079\u304D\u306A\u306E\u3067\u306F\uFF1F",
  "id" : 220589642238529536,
  "created_at" : "2012-07-04 18:47:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220588884935970817",
  "geo" : { },
  "id_str" : "220589213844897793",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u58CA\u6EC5\u7684\u306B\u9762\u767D\u304F\u306A\u304B\u3063\u305F\u3067\u3059\uFF0C\u3068\u3044\u3046\u306E\u3092\u30D3\u30D6\u30E9\u30FC\u30C8\u306B\u5305\u3093\u3067\u3069\u3053\u304C\u9762\u767D\u304B\u3063\u305F\u306E\u304B\u30AA\u30D6\u30E9\u30FC\u30C8\u306B\u5305\u3093\u3067\u805E\u3044\u3066\u307F\u308B\u3068\u304B\uFF1F",
  "id" : 220589213844897793,
  "in_reply_to_status_id" : 220588884935970817,
  "created_at" : "2012-07-04 18:45:41 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220588436468412417",
  "geo" : { },
  "id_str" : "220588865902227456",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u306A\u3093\u3068\u3044\u3048\u3070\u3044\u3044\u306E\u304B\u826F\u304F\u308F\u304B\u308A\u307E\u305B\u3093\u304C...\u8FD1\u3059\u304E\u308B\u306E\u3082\u8003\u3048\u7269\u3063\u3066\u3053\u3068\u3067\u3059\u304B\u306D\uFF0E",
  "id" : 220588865902227456,
  "in_reply_to_status_id" : 220588436468412417,
  "created_at" : "2012-07-04 18:44:18 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220588322886664193",
  "text" : "\u4F55\u3057\u308D\u81EA\u5206\u304C\u305D\u306E\u5074\u306B\u7ACB\u3064\u3053\u3068\u3082\u591A\u3044\u306E\u3060\u304B\u3089\uFF0E",
  "id" : 220588322886664193,
  "created_at" : "2012-07-04 18:42:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220588272286576640",
  "text" : "\u5272\u3068\u30C4\u30A4\u30C3\u30BF\u30FC\u306E\u304A\u304B\u3052\u3067\u5BFE\u4EBA\u7684\u306A\u610F\u5473\u3067\u7A4D\u6975\u7684\u306B\u306A\u308C\u3066\u3044\u3066\u305D\u308C\u306F\u304B\u306A\u308A\u3044\u3044\u3053\u3068\u3060\u3068\u601D\u3046\u3093\u3060\u3051\u308C\u3069\uFF0C\u3084\u3063\u3071\u308A\u8DDD\u96E2\u611F\u7684\u306A\u610F\u5473\u3067\u9055\u548C\u611F\u3092\u611F\u3058\u308B\u4EBA\u3082\u3044\u308B\uFF0C\u3048\u3093\u3069\u77E5\u3063\u3066\u308B\uFF0E",
  "id" : 220588272286576640,
  "created_at" : "2012-07-04 18:41:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220587812125294592",
  "text" : "\u304A\u3063\u304B\u3057\u3044\u306A\u30FC\u4ECA\u65E5\u30B3\u30FC\u30D2\u30FC\u3082\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u3082\u98F2\u3093\u3067\u306A\u3044\u306E\u306B\u306A\u30FC\uFF0E",
  "id" : 220587812125294592,
  "created_at" : "2012-07-04 18:40:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220587482968899586",
  "text" : "\u306A\u3093\u3067\u3053\u3093\u306A\u3058\u304B\u3093\u306A\u3093\u3067\u3059\u304B\u306D\u3047\u2026",
  "id" : 220587482968899586,
  "created_at" : "2012-07-04 18:38:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220587329767735296",
  "text" : "\u305D\u308C\u3067\u4EBA\u306B\u6279\u5224\u3055\u308C\u305F\u308A\u3082\u3057\u305F\u3051\u308C\u3069\uFF0E",
  "id" : 220587329767735296,
  "created_at" : "2012-07-04 18:38:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220587287182970880",
  "text" : "\u30DE\u30A4\u30DF\u30AF\u7533\u8ACB\u57FA\u6E96\u3068\u304B\u9298\u6253\u3063\u3066\u3061\u3087\u3063\u3068\u6016\u3044\u611F\u3058\u306B\u3057\u3066\u304A\u304F\u3068\u4E2D\u9014\u534A\u7AEF\u306A\u77E5\u308A\u5408\u3044\u304C\u3057\u308A\u8FBC\u307F\u3057\u3066\u304F\u308C\u3066\u4FBF\u5229\u3060\u3063\u305F\uFF0E",
  "id" : 220587287182970880,
  "created_at" : "2012-07-04 18:38:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220586961222643713",
  "text" : "mixi\u306E\u7533\u8ACB\u57FA\u6E96\u306F\u300C\u904E\u53BBend\u3068\uFF08\uFF14\u4EBA\u4EE5\u4E0B\u306E\u30B0\u30EB\u30FC\u30D7\u3067\uFF09\u98DF\u4E8B\u306B\u884C\u3063\u305F\u3053\u3068\u306E\u3042\u308B\u4EBA\u300D\u3063\u3066\u3057\u3066\u305F\uFF0E\u5727\u5012\u7684\u9589\u9396\u6027\uFF0E",
  "id" : 220586961222643713,
  "created_at" : "2012-07-04 18:36:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220586528710197249",
  "text" : "FB\u306E\u8DDD\u96E2\u611F\u304C\u307E\u3060\u308F\u304B\u3089\u306A\u3044\u304B\u3089\u306A\u30FC\uFF0E\u5272\u3068\u4ECA\u306F\u9069\u5F53\uFF0E",
  "id" : 220586528710197249,
  "created_at" : "2012-07-04 18:35:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 0, 14 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220586276229881856",
  "geo" : { },
  "id_str" : "220586388205207552",
  "in_reply_to_user_id" : 115541150,
  "text" : "@mearythindong \u306A\u3093\u3060\u304B\u3093\u3060\u3067\u3042\u3093\u307E\u308A\u304A\u3057\u3083\u3079\u308A\u3057\u3066\u306A\u3044\u3067\u3059\u3082\u3093\u306D\u30FC",
  "id" : 220586388205207552,
  "in_reply_to_status_id" : 220586276229881856,
  "created_at" : "2012-07-04 18:34:27 +0000",
  "in_reply_to_screen_name" : "mearythindong",
  "in_reply_to_user_id_str" : "115541150",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220586069450698752",
  "geo" : { },
  "id_str" : "220586313244622849",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u5148\u8FF0\u306E\u7406\u7531\u3067\u898B\u9001\u3063\u3061\u3083\u3063\u3066\u304A\uFF4B\u3067\u3059",
  "id" : 220586313244622849,
  "in_reply_to_status_id" : 220586069450698752,
  "created_at" : "2012-07-04 18:34:10 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220586034558287872",
  "text" : "SNS\u306E\u4F7F\u3044\u65B9\u306F\u4EBA\u305D\u308C\u305E\u308C\u306A\u306E\u3067\uFF0E\uFF08\u81EA\u5206\u3082mixi\u306F\u304B\u306A\u308A\u304B\u306A\u308A\u9589\u9396\u7684\u306B\u4F7F\u3063\u3066\u3044\u305F\uFF0E\uFF09",
  "id" : 220586034558287872,
  "created_at" : "2012-07-04 18:33:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220585922184482817",
  "text" : "\uFF7C\uFF9E\uFF84\uFF70\u3068\u306F\u8A00\u3063\u305F\u3082\u306E\u306E\u7533\u8ACB\u3057\u305F\u304F\u306A\u3051\u308C\u3070\u3057\u306A\u304F\u3066\u5168\u7136\u304A\uFF4B\u3067\u3059\u3057\uFF0E",
  "id" : 220585922184482817,
  "created_at" : "2012-07-04 18:32:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/CC1Kx4Br",
      "expanded_url" : "http:\/\/www.facebook.com\/kei.endo.33",
      "display_url" : "facebook.com\/kei.endo.33"
    } ]
  },
  "in_reply_to_status_id_str" : "220584779140173824",
  "geo" : { },
  "id_str" : "220585094094655488",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \uFF7C\uFF9E\uFF84\uFF70 http:\/\/t.co\/CC1Kx4Br",
  "id" : 220585094094655488,
  "in_reply_to_status_id" : 220584779140173824,
  "created_at" : "2012-07-04 18:29:19 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220584765244448769",
  "text" : "\u9AD8\u6821\u6642\u4EE3\u306E\u5148\u751F\u3092\u767A\u898B\u3057\u305F\u304C\u3053\u306E\u540D\u524D\u3060\u3068\u308F\u304B\u3089\u306A\u3044\u3060\u308D\u3046\u3057\u898B\u9001\u308A\uFF0E\u307E\u3041\u5927\u5B66\u3067\u5272\u308C\u308B\u3060\u308D\u3046\u304C\uFF0E",
  "id" : 220584765244448769,
  "created_at" : "2012-07-04 18:28:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220583640579588096",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u521D\u30A4\u30A4\u30CD\u306F\u5E73\u6CC9\u3055\u3093\u306B\u3042\u3052\u305F\uFF0C\u3044\u3084\uFF0C\u6295\u3052\u305F\uFF0E",
  "id" : 220583640579588096,
  "created_at" : "2012-07-04 18:23:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220583378813075456",
  "text" : "\u53CB\u9054\u306B\u3079\u308D\u3079\u308D\u3070\u3041\u3063\u3066\u8A00\u308F\u308C\u305F\u3051\u308C\u3069\u3069\u3046\u8003\u3048\u3066\u3082\u307A\u308D\u307A\u308D\u3071\u3041\u306E\u7D1B\u3044\u7269",
  "id" : 220583378813075456,
  "created_at" : "2012-07-04 18:22:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220582927908618240",
  "text" : "\u65E9\u304F\u3082\u30A4\u30A4\u30CD\u62BC\u3057\u3066\u7F6E\u3051\u3070\u3044\u3044\u3058\u3083\u3093\u7684\u96F0\u56F2\u6C17\u306B\u5446\u7136\u3068\u3057\u3066\u3044\u308B\uFF0E",
  "id" : 220582927908618240,
  "created_at" : "2012-07-04 18:20:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 0, 14 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/zHULM7NQ",
      "expanded_url" : "http:\/\/www.facebook.com\/?sk=welcome#!\/kei.endo.33",
      "display_url" : "facebook.com\/?sk=welcome#!\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "220582464236699650",
  "geo" : { },
  "id_str" : "220582517923778560",
  "in_reply_to_user_id" : 115541150,
  "text" : "@mearythindong http:\/\/t.co\/zHULM7NQ \u3053\u308C\u3067\u307F\u308C\u307E\u3059\uFF1F",
  "id" : 220582517923778560,
  "in_reply_to_status_id" : 220582464236699650,
  "created_at" : "2012-07-04 18:19:05 +0000",
  "in_reply_to_screen_name" : "mearythindong",
  "in_reply_to_user_id_str" : "115541150",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220582444695437313",
  "text" : "\u81EA\u5206\u306E\u6328\u62F6\u89B3\u304C\u97F3\u3092\u7ACB\u3066\u3066\u8ECB\u3093\u3067\u3044\u308B",
  "id" : 220582444695437313,
  "created_at" : "2012-07-04 18:18:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220582350143225856",
  "text" : "\u306A\u306B\u3053\u308C\u300C\u6328\u62F6\u304C\u3042\u308A\u307E\u3057\u305F\uFF0E\u6328\u62F6\u3092\u8FD4\u3059\uFF0E\u300D\u3063\u3066\u306A\u3093\u3060\u3088\uFF0E\u6328\u62F6\u306F\u3053\u3093\u306B\u3061\u306F\u3068\u304B\u305D\u3046\u3044\u3046\u8A00\u8449\u3092\u6307\u3059\u3093\u3058\u3083\u306A\u3044\u306E\u2026",
  "id" : 220582350143225856,
  "created_at" : "2012-07-04 18:18:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220578217558417408",
  "geo" : { },
  "id_str" : "220581719139557377",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u898B\u5F53\u305F\u3089\u306A\u3044\u304B\u3089\u4ECA\u5EA6\u4F1A\u3063\u305F\u6642\u306B\u305D\u306E\u5834\u3067\u691C\u7D22\u3057\u307E\u3059\uFF08\u3082\u3057\u304B\u3057\u305F\u3089\u672C\u540D\u899A\u3048\u9055\u3048\u3066\u3044\u308B\uFF09",
  "id" : 220581719139557377,
  "in_reply_to_status_id" : 220578217558417408,
  "created_at" : "2012-07-04 18:15:54 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220578565660479489",
  "text" : "\u89AA\u3057\u3044\u4EBA\u3068\u4E00\u6587\u5B57\u9055\u3044\u306E\u3042\u3093\u307E\u308A\u89AA\u3057\u304F\u306A\u3044\u4EBA\u306B\uFF46\uFF42\u7533\u8ACB\u3057\u305F\u53EF\u80FD\u6027\u304C\u5FAE\u30EC\u5B58\uFF0E",
  "id" : 220578565660479489,
  "created_at" : "2012-07-04 18:03:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220575123999174657",
  "text" : "@i_horse \u3042\uFF0C\u306F\u3044\uFF0E",
  "id" : 220575123999174657,
  "created_at" : "2012-07-04 17:49:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220574865177055232",
  "text" : "@i_horse \u76F8\u99AC\u8C4A\u3067\u639B\u304B\u3089\u306A\u3044\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 220574865177055232,
  "created_at" : "2012-07-04 17:48:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220574096436629504",
  "text" : "\u672C\u540D\u3067\u3084\u3063\u3066\u308B\u4EBA\u3069\u3046\u3084\u3063\u3066\u691C\u7D22\u306B\u304B\u3051\u308B\u304B\u304C\u554F\u984C\uFF0E\u3067\u3082\u307E\u3041\u672C\u540D\u3067\u3084\u3063\u3066\u308B\u4EBA\u3044\u308B\u306E\u304B\u3057\u3089\uFF0E",
  "id" : 220574096436629504,
  "created_at" : "2012-07-04 17:45:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220573993349029888",
  "text" : "\u3081\u3093\u3069\u3044\u304B\u3089\uFF46\uFF42\u3084\u3063\u3066\u308B\u3072\u3068\u9069\u5F53\u306B\u30EA\u30D7\u304B\u306A\u3093\u304B\u3067\u8868\u660E\u304F\u308C\u305F\u3089\u9069\u5F53\u306B\u7533\u8ACB\u3057\u305F\u308A\u3057\u306A\u304B\u3063\u305F\u308A\u3059\u308B\u3088\uFF01",
  "id" : 220573993349029888,
  "created_at" : "2012-07-04 17:45:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/zHULM7NQ",
      "expanded_url" : "http:\/\/www.facebook.com\/?sk=welcome#!\/kei.endo.33",
      "display_url" : "facebook.com\/?sk=welcome#!\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220572253119725568",
  "text" : "\u3053\u308C\u5F35\u3063\u305F\u3089\u3044\u3044\u306E\u304B\u306A http:\/\/t.co\/zHULM7NQ",
  "id" : 220572253119725568,
  "created_at" : "2012-07-04 17:38:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k@ori.k...",
      "screen_name" : "chinchikurin48",
      "indices" : [ 0, 15 ],
      "id_str" : "3018640687",
      "id" : 3018640687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220570182005960704",
  "geo" : { },
  "id_str" : "220570307394674689",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurin48 \u3044\u3084\uFF46\uFF42\u521D\u3081\u3066\u898B\u305F\u306E\u3067\u3044\u308D\u3044\u308D\u57CB\u3081\u3066\u308B\u306E\u3067\u3059",
  "id" : 220570307394674689,
  "in_reply_to_status_id" : 220570182005960704,
  "created_at" : "2012-07-04 17:30:33 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k@ori.k...",
      "screen_name" : "chinchikurin48",
      "indices" : [ 0, 15 ],
      "id_str" : "3018640687",
      "id" : 3018640687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220569884273283072",
  "geo" : { },
  "id_str" : "220570024941850625",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurin48 \u3069\u3086\u3053\u3068\u3067\u3059\uFF1F\uFF1F\uFF1F",
  "id" : 220570024941850625,
  "in_reply_to_status_id" : 220569884273283072,
  "created_at" : "2012-07-04 17:29:26 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220569772025331712",
  "text" : "\u643A\u5E2F\u304B\u3089\u3084\u3063\u3066\u308B\u306E\u304C\u3044\u3051\u306A\u3044\u306E\u304B\u306A",
  "id" : 220569772025331712,
  "created_at" : "2012-07-04 17:28:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220569068242079744",
  "geo" : { },
  "id_str" : "220569274111098880",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u672C\u5F53\u3060\uFF0E\u6F22\u5B57\u306B\u3057\u305F\u306E\u304C\u3044\u3051\u306A\u304B\u3063\u305F\u3093\u3067\u3059\u306D\uFF0C\u305F\u3076\u3093\uFF0E",
  "id" : 220569274111098880,
  "in_reply_to_status_id" : 220569068242079744,
  "created_at" : "2012-07-04 17:26:27 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220569059736039424",
  "text" : "\u3042\u3069\u308C\u3059\u3068\u304B\u66F8\u3044\u305F\u65B9\u304C\u65E9\u3044\u8AAC\uFF0E\u3069\u3053\u306E\u30A2\u30C9\u30EC\u30B9\u5F35\u308C\u3070\u3044\u3044\u3093\u3060\u308D\u3046\uFF0E",
  "id" : 220569059736039424,
  "created_at" : "2012-07-04 17:25:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220568793087348737",
  "text" : "\u3042\uFF0C\u3082\u3057\u304B\u3057\u3066\u6F22\u5B57\u3058\u3083\u306A\u3044\u3068\u691C\u7D22\u51FA\u6765\u306A\u3044\u306E\u304B\u306A\uFF0E",
  "id" : 220568793087348737,
  "created_at" : "2012-07-04 17:24:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220568537255788544",
  "geo" : { },
  "id_str" : "220568678981304320",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u3042\u308C\u30FC\uFF0C\u306A\u305C\u304B\u691C\u7D22\u5F15\u3063\u304B\u304B\u3093\u306A\u304B\u3063\u305F\u3093\u3067\u3059\u3088\u306D\uFF0E\u307E\u3041\u3053\u306E\u307E\u307E\u3067\u3082\u3044\u3044\u304B\u306A\u3068\u601D\u3063\u3066\u3044\u308B\uFF0E",
  "id" : 220568678981304320,
  "in_reply_to_status_id" : 220568537255788544,
  "created_at" : "2012-07-04 17:24:05 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 6, 14 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220568303750492160",
  "text" : "\u306F\u3044 RT @i_horse: \uFF74\uFF9D\uFF84\uFF9E\uFF75\uFF75\uFF75\uFF75\uFF75\uFF75\uFF75\uFF75\uFF75\uFF75\uFF75",
  "id" : 220568303750492160,
  "created_at" : "2012-07-04 17:22:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220568125580644352",
  "text" : "\u30AB\u30EF\u30A6\u30BD\u306F\u53EF\u611B\u3044\uFF0E\u305F\u3076\u3093\uFF0E",
  "id" : 220568125580644352,
  "created_at" : "2012-07-04 17:21:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220568047935692801",
  "text" : "\u53EF\u611B\u305D\u3046\u306A\uFF0E\u5426\uFF0C\u53EF\u54C0\u76F8\u306A\uFF0E",
  "id" : 220568047935692801,
  "created_at" : "2012-07-04 17:21:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220567976653500416",
  "text" : "\u73FE\u6BB5\u968E\u53CB\u9054\u304C\u3044\u306A\u3044\u30AB\u30EF\u30A6\u30BD\u306A\u5B50\u306A\u306E\u3067\u9069\u5F53\u306B\u3069\u3046\u305E",
  "id" : 220567976653500416,
  "created_at" : "2012-07-04 17:21:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220567762047733760",
  "text" : "@koketomi \u306A\u3093\u3060\u3042\u3063\u305F\u306E\u304B\uFF08\u6B8B\u5FF5\uFF09",
  "id" : 220567762047733760,
  "created_at" : "2012-07-04 17:20:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220567632250806274",
  "text" : "\u307E\u3041\u4EAC\u90FD\u5927\u5B66\u304C\u898B\u3064\u304B\u3089\u306A\u304B\u3063\u305F\u306E\u306B\u4EAC\u90FD\u5927\u5B66\u7406\u5B66\u90E8\u3057\u304B\u51FA\u3066\u3053\u306A\u304B\u3063\u305F\u306E\u3067\u7406\u5B66\u90E8\u306B\u306A\u3063\u3066\u307E\u3059\u304A\u6C17\u306B\u306A\u3055\u3089\u305A",
  "id" : 220567632250806274,
  "created_at" : "2012-07-04 17:19:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220567286937948160",
  "text" : "Endo Kei \u3067\u691C\u7D22\uFF01",
  "id" : 220567286937948160,
  "created_at" : "2012-07-04 17:18:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220567134596628481",
  "text" : "\u52E2\u3044\u3067FB\u767B\u9332\u3057\u305F\uFF0E",
  "id" : 220567134596628481,
  "created_at" : "2012-07-04 17:17:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220554413239046144",
  "text" : "\u90E8\u5C4B\u304C\u6563\u3089\u304B\u3063\u3066\u3044\u308B\u304B\u3089\u3044\u3051\u306A\u3044\u306E\u3067\u3042\u308B\uFF0E",
  "id" : 220554413239046144,
  "created_at" : "2012-07-04 16:27:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220554307685191681",
  "text" : "\u3061\u3087\u3063\u3068\u524D\u306B\u30E1\u30AC\u30CD\u4E00\u3064\u3075\u3093\u3058\u3083\u3063\u305F\u3093\u3060\u3051\u308C\u3069\u3053\u308C\u3082\u3046\u3060\u3081\u3060\u306A\uFF0E\u65B0\u3057\u3044\u306E\u3092\u8CB7\u304A\u3046\uFF0E",
  "id" : 220554307685191681,
  "created_at" : "2012-07-04 16:26:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6DF1\u591C\u306E\u6383\u9664",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220553422548647936",
  "text" : "\u4ECA\u591C\u3042\u305F\u308A\u306B\u3082\u3046\u4E00\u5EA6\u3067\u304D\u305F\u3089\u3044\u308D\u3044\u308D\u7D20\u6575\uFF0E #\u6DF1\u591C\u306E\u6383\u9664",
  "id" : 220553422548647936,
  "created_at" : "2012-07-04 16:23:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6DF1\u591C\u306E\u6383\u9664",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220553348842131456",
  "text" : "\u6383\u9664\u306F\u305D\u308D\u305D\u308D\u304A\u958B\u304D\u306B\u3057\u3088\u3046\u304B\u306A\u30FC #\u6DF1\u591C\u306E\u6383\u9664",
  "id" : 220553348842131456,
  "created_at" : "2012-07-04 16:23:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220550676424564737",
  "text" : "\u4E2D\u9014\u534A\u7AEF\u306B\u8A00\u8449\u3092\u6FC1\u3059\u3068\u6016\u3044\u3093\u3060\u3063\u305F\uFF0E\u308F\u3059\u308C\u3066\u305F\uFF0E",
  "id" : 220550676424564737,
  "created_at" : "2012-07-04 16:12:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220550518513221634",
  "geo" : { },
  "id_str" : "220550603032637440",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3080\u305A\u304B\u3057\u3044\u3057\u3064\u3082\u3093\u3067\u3059\u2026",
  "id" : 220550603032637440,
  "in_reply_to_status_id" : 220550518513221634,
  "created_at" : "2012-07-04 16:12:16 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220550416029593602",
  "geo" : { },
  "id_str" : "220550490973405184",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u5C0F\u9593\u4F7F\u3044\u3055\u3093\u304C\u5F7C\u5973\u3067\u306A\u3044\u3068\u306F\u9650\u3089\u306A\u3044\uFF01",
  "id" : 220550490973405184,
  "in_reply_to_status_id" : 220550416029593602,
  "created_at" : "2012-07-04 16:11:49 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220550160751656961",
  "geo" : { },
  "id_str" : "220550271225434113",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u305D\u308C\u5C0F\u9593\u4F7F\u3044\u3055\u3093",
  "id" : 220550271225434113,
  "in_reply_to_status_id" : 220550160751656961,
  "created_at" : "2012-07-04 16:10:56 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220550100483702784",
  "text" : "\u63FA\u308C\u305F\u6C17\u304C\u3057\u306A\u3044\u3051\u308C\u3069\uFF0E",
  "id" : 220550100483702784,
  "created_at" : "2012-07-04 16:10:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220549940634591232",
  "text" : "\u305F\u3060\u3057\u6B21\u5143\u306F\uFF13\u3068\u3059\u308B\uFF0E RT @kotorin_z: \u7537\u6027\u4E00\u4EBA\u5F53\u305F\u308A\u306B\u5BFE\u3059\u308B\u5F7C\u5973\u306E\u4EBA\u6570\u306E\u6700\u5927\u5024\u3092\u6C42\u3081\u3088\u3002",
  "id" : 220549940634591232,
  "created_at" : "2012-07-04 16:09:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220549536039448578",
  "geo" : { },
  "id_str" : "220549716209967105",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank Well-Defined\u3067\u306A\u3044\uFF0E\u3044\u3065\u308C\u3069\u3053\u304B\u306B\u77DB\u76FE\u304C\uFF0E",
  "id" : 220549716209967105,
  "in_reply_to_status_id" : 220549536039448578,
  "created_at" : "2012-07-04 16:08:44 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220549326076784640",
  "text" : "\u5F7C\u5973\u306F \u5B58 \u5728 \u3059 \u308C \u3070 \u4E00\u610F",
  "id" : 220549326076784640,
  "created_at" : "2012-07-04 16:07:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220549106735644672",
  "text" : "\u6DFB\u3044\u5BDD",
  "id" : 220549106735644672,
  "created_at" : "2012-07-04 16:06:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220548933141803008",
  "text" : "\u305D\u3046\u3044\u3046\u4FEE\u7E55\u6280\u8853\u6B32\u3057\u3044\u3093\u3060\u3051\u308C\u3069\u3069\u3053\u3067\u3082\u3089\u3048\u307E\u3059\u304B\uFF1F",
  "id" : 220548933141803008,
  "created_at" : "2012-07-04 16:05:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "issei\uFF20EGOISTix*fam",
      "screen_name" : "it__ssei",
      "indices" : [ 0, 9 ],
      "id_str" : "116213192",
      "id" : 116213192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220548634389913600",
  "geo" : { },
  "id_str" : "220548743785746433",
  "in_reply_to_user_id" : 116213192,
  "text" : "@it__ssei \u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3093\u3067\u3057\u3087\u3046",
  "id" : 220548743785746433,
  "in_reply_to_status_id" : 220548634389913600,
  "created_at" : "2012-07-04 16:04:52 +0000",
  "in_reply_to_screen_name" : "it__ssei",
  "in_reply_to_user_id_str" : "116213192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220548690392256512",
  "text" : "\u5207\u308C\u305F\u308A\u3057\u305F\u306E\u306F\u3042\u308B\u7A0B\u5EA6\u7E2B\u3063\u305F\u308A\u51FA\u6765\u308B\u3060\u308D\u3046\u304C\uFF0C\u64E6\u308A\u5207\u308C\u305F\u306E\u3063\u3066\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3044\uFF0E",
  "id" : 220548690392256512,
  "created_at" : "2012-07-04 16:04:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220548567356551168",
  "text" : "\u672C\u5F53\u306B\u6C17\u306B\u5165\u3063\u305F\u670D\u306F2\u7740\u8CB7\u3046\u3079\u304D\u306A\u306E\u304B\u306A\u30FC\uFF0E\u30B8\u30E3\u30B1\u30C3\u30C8\u306A\u3093\u304B\u306F\u64E6\u308A\u5207\u308C\u306F\u3057\u306A\u3044\u3060\u308D\u3046\u3057\uFF0C\u64E6\u308A\u5207\u308C\u308B\u306E\u306F\u305F\u3044\u3066\u3044\u30B7\u30E3\u30C4\uFF0E",
  "id" : 220548567356551168,
  "created_at" : "2012-07-04 16:04:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220548367514738689",
  "text" : "\u6700\u8FD1\u304A\u6C17\u306B\u5165\u308A\u306E\u670D\u304C\u64E6\u308A\u5207\u308C\u59CB\u3081\u3066\u3064\u3089\u3044\uFF0E\u9811\u5F35\u3063\u3066\u7740\u3066\u308B\u3051\u308C\u3069\uFF0E",
  "id" : 220548367514738689,
  "created_at" : "2012-07-04 16:03:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220543176723795968",
  "text" : "\u30A6\u30FC\u30ED\u30F3\u8336\u306F\u3084\u3063\u3071\u308A\u30B5\u30F3\u30C8\u30EA\u30FC\u3060\u3068\u601D\u3046\u3093\u3060\uFF0E",
  "id" : 220543176723795968,
  "created_at" : "2012-07-04 15:42:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220543125851082754",
  "text" : "\u30B1\u30F3\u30BF\u30C3\u30AD\u30FC\u306E\u305B\u3044\u3067\u5589\u304C\u6E07\u3044\u3066\u4ED5\u65B9\u306A\u3044\u306E\u3060\u308D\u3046\uFF0E",
  "id" : 220543125851082754,
  "created_at" : "2012-07-04 15:42:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220543076102443009",
  "text" : "\u30A6\u30FC\u30ED\u30F3\u8336\u304C\u304A\u3044\u3057\u3044\uFF0E\u3068\u3044\u3046\u304B\u4ECA\u65E5\u5915\u65B9\u4EE5\u964D\u30A6\u30FC\u30ED\u30F3\u8336\u3070\u3063\u304B\u308A\u98F2\u3093\u3067\u308B\uFF0E",
  "id" : 220543076102443009,
  "created_at" : "2012-07-04 15:42:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220540921383632897",
  "text" : "\u3067\u305F\uFF0C\u6383\u9664\u3057\u3066\u305F\u3089\u653E\u7F6E\u3057\u3066\u3042\u308B\u6F2B\u753B\u3092\u8AAD\u307F\u306F\u3058\u3081\u3061\u3083\u3046\u3084\u3064\u3060\uFF01\uFF08\u3088\u307F\u304A\u3048\u305F\uFF09",
  "id" : 220540921383632897,
  "created_at" : "2012-07-04 15:33:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6DF1\u591C\u306E\u6383\u9664",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220534340818452480",
  "text" : "\u5BDD\u3088\u3046\u3068\u601D\u3063\u305F\u304C\u6025\u306B\u6D17\u6FEF\u3068\u6383\u9664\u304C\u59CB\u307E\u3063\u305F\uFF0E #\u6DF1\u591C\u306E\u6383\u9664",
  "id" : 220534340818452480,
  "created_at" : "2012-07-04 15:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220534267044839424",
  "text" : "\u3055\u3041\u306F\u3058\u3081\u3088\u3046",
  "id" : 220534267044839424,
  "created_at" : "2012-07-04 15:07:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6DF1\u591C\u306E\u6383\u9664",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220534222463582209",
  "text" : "\u76EE\u6A19\u7D42\u4E86\u6642\u523B\u306F\u30FC1\u6642\uFF01 #\u6DF1\u591C\u306E\u6383\u9664",
  "id" : 220534222463582209,
  "created_at" : "2012-07-04 15:07:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220428826587566080",
  "text" : "\u4E09\u6761 \u56DB\u6761",
  "id" : 220428826587566080,
  "created_at" : "2012-07-04 08:08:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220428802088640512",
  "text" : "\u4EAC\u90FD\u3067\uFF13\uFF11\u3063\u3066\u60E8\u72B6\u3060\u304B\u79C1\u60C5\u3060\u304B\u306B\u3042\u308A\u307E\u3057\u305F\u3063\u3051\uFF1F",
  "id" : 220428802088640512,
  "created_at" : "2012-07-04 08:08:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220427117077331968",
  "geo" : { },
  "id_str" : "220427177408208896",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u305D\u3093\u306A\u9AD8\u3044\u3093\u3067\u3059\u304B",
  "id" : 220427177408208896,
  "in_reply_to_status_id" : 220427117077331968,
  "created_at" : "2012-07-04 08:01:49 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4ECA\u66F4",
      "indices" : [ 16, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220427148589142016",
  "text" : "\u30A6\u30FC\u30ED\u30F3\u8336\u3082\u3046\u4E00\u676F\u98F2\u307F\u305F\u304B\u3063\u305F #\u4ECA\u66F4",
  "id" : 220427148589142016,
  "created_at" : "2012-07-04 08:01:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220426290090614784",
  "text" : "10\u3068\u304B\u76F8\u99AC\u3055\u3093\u3082\u3042\u3063\u304D\u30FC\u3055\u3093\u3082\u51C4\u3044",
  "id" : 220426290090614784,
  "created_at" : "2012-07-04 07:58:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220426171593142273",
  "text" : "\u516B\u500B\u98DF\u3079\u305F\u3051\u308C\u3069\u6700\u5F8C\u306E\u4E00\u3064\u306F\u5727\u5012\u7684\u306B\u4F59\u8A08\u3067\u3042\u3063\u305F",
  "id" : 220426171593142273,
  "created_at" : "2012-07-04 07:57:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220423834241728512",
  "text" : "\u98DF\u3079\u653E\u984C\u306F\u3001\u3057\u3093\u3069\u3044",
  "id" : 220423834241728512,
  "created_at" : "2012-07-04 07:48:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220399902725902336",
  "text" : "\u7D50\u69CB\u6DF7\u3093\u3067\u308B\u3046\u3046\u3046",
  "id" : 220399902725902336,
  "created_at" : "2012-07-04 06:13:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220397996930629632",
  "text" : "\u304D\u305F\u305C\u3001\u3058\u3085\u308B\u308A\u3068\u3001(\u30BC\u30EA\u30FC\u3055\u3093\u3064\u308C\u305F)",
  "id" : 220397996930629632,
  "created_at" : "2012-07-04 06:05:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220395431727874048",
  "text" : "\u30B1\u30F3\u30BF\u30C3\u30AD\u30FC\u98DF\u3079\u653E\u984C\u884C\u304F\u4EBA\u3044\u308B\uFF1F(\u4E0B\u9D28)",
  "id" : 220395431727874048,
  "created_at" : "2012-07-04 05:55:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220124798917939200",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 220124798917939200,
  "created_at" : "2012-07-03 12:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/VciGJpj6",
      "expanded_url" : "http:\/\/4sq.com\/LUGUax",
      "display_url" : "4sq.com\/LUGUax"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "220068520086609920",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/VciGJpj6",
  "id" : 220068520086609920,
  "created_at" : "2012-07-03 08:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220044324145082368",
  "text" : "\u304B\u3048\u308A\u305F\u3044",
  "id" : 220044324145082368,
  "created_at" : "2012-07-03 06:40:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 0, 14 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220038496923037696",
  "geo" : { },
  "id_str" : "220040789378613248",
  "in_reply_to_user_id" : 320494295,
  "text" : "@riveriver4361 \u4EBA\u306B\u3088\u308B\u3051\u3069\u306A\u3093\u304B\u534A\u30AE\u30EC\u3060\u3063\u305F\u308A\u3059\u308B",
  "id" : 220040789378613248,
  "in_reply_to_status_id" : 220038496923037696,
  "created_at" : "2012-07-03 06:26:27 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 0, 14 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220028620104663041",
  "geo" : { },
  "id_str" : "220033635619844096",
  "in_reply_to_user_id" : 320494295,
  "text" : "@riveriver4361 \u5F62\u5F0F\u6307\u5B9A\u3057\u306A\u3044\u65B9\u304C\u60AA\u3044\u304B\u3089\u306A\u30FC\u3001\u666E\u901A\u306B\u8868\u7D19\u3064\u3051\u3066\u51FA\u305B\u3070\u3044\u3044\u3068\u601D\u3046\u3002\u6559\u52D9\u304C\u614B\u5EA6\u60AA\u3044\u304B\u3089\u63D0\u51FA\u304C\u6559\u52D9\u306A\u3089\u5FC3\u3057\u3066\u3002",
  "id" : 220033635619844096,
  "in_reply_to_status_id" : 220028620104663041,
  "created_at" : "2012-07-03 05:58:01 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220027845806800897",
  "geo" : { },
  "id_str" : "220028193711718400",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306F\u3044 \u3061\u3087\u3063\u3068\u3060\u3051\u9045\u308C\u308B\u304B\u3082",
  "id" : 220028193711718400,
  "in_reply_to_status_id" : 220027845806800897,
  "created_at" : "2012-07-03 05:36:23 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220026198334513152",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4F11\u8B1B\u308F\u3093\u3061\u3083\u3093\u3042\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 220026198334513152,
  "created_at" : "2012-07-03 05:28:28 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220025222370304000",
  "text" : "\u3067\u3001\u8B66\u5831\u3063\u3066\u51FA\u3066\u308B\u306E\uFF1F",
  "id" : 220025222370304000,
  "created_at" : "2012-07-03 05:24:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 0, 14 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220004791475113984",
  "geo" : { },
  "id_str" : "220019949069025280",
  "in_reply_to_user_id" : 320494295,
  "text" : "@riveriver4361 \u4F5C\u54C1\u306E\u4E00\u90E8\u3068\u3044\u3046\u3088\u3046\u306A\u610F\u5473\u3058\u3083\u306A\u3044\u304B\u306A(\u305F\u3076\u3093",
  "id" : 220019949069025280,
  "in_reply_to_status_id" : 220004791475113984,
  "created_at" : "2012-07-03 05:03:38 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marin Cassandra",
      "screen_name" : "riveriver4361",
      "indices" : [ 0, 14 ],
      "id_str" : "2999094310",
      "id" : 2999094310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219998974717861889",
  "geo" : { },
  "id_str" : "219999735682043904",
  "in_reply_to_user_id" : 320494295,
  "text" : "@riveriver4361 \u306F\u3044",
  "id" : 219999735682043904,
  "in_reply_to_status_id" : 219998974717861889,
  "created_at" : "2012-07-03 03:43:19 +0000",
  "in_reply_to_screen_name" : "cricetusmhx2",
  "in_reply_to_user_id_str" : "320494295",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219998707440041984",
  "text" : "\u96E8\u3048\u30FC",
  "id" : 219998707440041984,
  "created_at" : "2012-07-03 03:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219860558588030976",
  "text" : "\u30A8\u30F3\u30C9\u30EA\u30B1\u30EA\u30FC\u3082",
  "id" : 219860558588030976,
  "created_at" : "2012-07-02 18:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219860525440442369",
  "text" : "\u30A8\u30F3\u30C9\u30E2\u30EB\u30D5\u30A3\u30BA\u30E0\u3082\u30A8\u30F3\u30C9\u30E2\u30EB\u30D5\u30A3\u30F3\u3082\u5B58\u5728\u3059\u308B\u3089\u3057\u3044",
  "id" : 219860525440442369,
  "created_at" : "2012-07-02 18:30:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219859201999110144",
  "text" : "\u305D\u308D\u305D\u308D\u4E09\u6642\u534A\u306A\u3093\u3060\u304C\u301C\u301C\u301C\uFF1F\uFF1F\uFF1F",
  "id" : 219859201999110144,
  "created_at" : "2012-07-02 18:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219858336445767682",
  "geo" : { },
  "id_str" : "219858604377915393",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u305D\u308C\u304F\u3089\u3044\u5BDF\u305B\u3088",
  "id" : 219858604377915393,
  "in_reply_to_status_id" : 219858336445767682,
  "created_at" : "2012-07-02 18:22:30 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3042\u304F\u307E\u3067\u5730\u7406\u7684\u306B",
      "indices" : [ 8, 17 ]
    }, {
      "text" : "\u5B66\u529B\u306E\u8A71\u306F\u3084\u3081\u308D",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219858402027913216",
  "text" : "\u6771\u5927\u306E\u9662\u3082\u71B1\u3044 #\u3042\u304F\u307E\u3067\u5730\u7406\u7684\u306B #\u5B66\u529B\u306E\u8A71\u306F\u3084\u3081\u308D",
  "id" : 219858402027913216,
  "created_at" : "2012-07-02 18:21:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219857807288184833",
  "text" : "\u306F\u3044",
  "id" : 219857807288184833,
  "created_at" : "2012-07-02 18:19:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 3, 12 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3044\u3084\u9662\u3063\u3066\u4ECA\u306E\u307E\u307E\u3060\u3068\u78BA\u5B9F\u306B\u843D\u3061\u308B\u3082\u306E\u3060\u3068\u601D\u3063\u3066\u308B\u304B\u3089",
      "indices" : [ 14, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219857771049398272",
  "text" : "RT @isaribiz: #\u3044\u3084\u9662\u3063\u3066\u4ECA\u306E\u307E\u307E\u3060\u3068\u78BA\u5B9F\u306B\u843D\u3061\u308B\u3082\u306E\u3060\u3068\u601D\u3063\u3066\u308B\u304B\u3089",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u3044\u3084\u9662\u3063\u3066\u4ECA\u306E\u307E\u307E\u3060\u3068\u78BA\u5B9F\u306B\u843D\u3061\u308B\u3082\u306E\u3060\u3068\u601D\u3063\u3066\u308B\u304B\u3089",
        "indices" : [ 0, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219857707191119872",
    "text" : "#\u3044\u3084\u9662\u3063\u3066\u4ECA\u306E\u307E\u307E\u3060\u3068\u78BA\u5B9F\u306B\u843D\u3061\u308B\u3082\u306E\u3060\u3068\u601D\u3063\u3066\u308B\u304B\u3089",
    "id" : 219857707191119872,
    "created_at" : "2012-07-02 18:18:56 +0000",
    "user" : {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "protected" : true,
      "id_str" : "150662260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586179377114685441\/2LPKH2Xn_normal.jpg",
      "id" : 150662260,
      "verified" : false
    }
  },
  "id" : 219857771049398272,
  "created_at" : "2012-07-02 18:19:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219857368354267137",
  "text" : "\u4ED6\u4EBA\u304B\u3089\u4ED6\u4EBA\u3078\u306E\u30EA\u30D7\u304C\u523A\u3055\u308B",
  "id" : 219857368354267137,
  "created_at" : "2012-07-02 18:17:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219857128721100800",
  "text" : "\u9662\u6B7B\u30AC\u30C1\u52E2\u306F\u8AB0\u3088\u308A\u79C1",
  "id" : 219857128721100800,
  "created_at" : "2012-07-02 18:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219852524805566464",
  "text" : "\u6307\u30B9\u30DE\u306B\u52DD\u3064\u30B9\u30AD\u30EB\u3082",
  "id" : 219852524805566464,
  "created_at" : "2012-07-02 17:58:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219852428303020032",
  "text" : "\u81EA\u4E3B\u30BC\u30DF\u306B\u5FC5\u8981\u306A\u3082\u306E:\u3058\u3083\u3093\u3051\u3093\u306B\u52DD\u3064\u30B9\u30AD\u30EB",
  "id" : 219852428303020032,
  "created_at" : "2012-07-02 17:57:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219852214469005312",
  "text" : "\u305B\u3063\u304B\u304F\u304A\u3068\u3068\u3044\u65E9\u5BDD\u3057\u305F\u306E\u306B\u306A\u30FC",
  "id" : 219852214469005312,
  "created_at" : "2012-07-02 17:57:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219852069379641345",
  "text" : "\u8A9E\u5B66\u304C4\u9650\u3058\u3083\u306A\u304B\u3063\u305F\u3089\u3057\u3093\u3067\u3044\u305F",
  "id" : 219852069379641345,
  "created_at" : "2012-07-02 17:56:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219851953742680064",
  "text" : "\u3053\u308C\u306F\u3001\u4ECA\u65E5\u8D77\u304D\u3089\u308C\u306A\u3044\u30E4\u30C4\u3060\u306A\u30FC(^^)(^^)(^^)(^^)(^^)",
  "id" : 219851953742680064,
  "created_at" : "2012-07-02 17:56:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219851550477131777",
  "text" : "@i_horse 3\u6642\u307E\u3067\u306B\u30B3\u30C3\u30AF\u30B9\u304C\u793A\u305B\u306A\u304B\u3063\u305F\u3089\u7B54\u3048\u3092\u898B\u308B",
  "id" : 219851550477131777,
  "created_at" : "2012-07-02 17:54:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219851246620786688",
  "text" : "\u533B\u7642\u7528\u8A9E\u3068\u3044\u3046\u8AAC\u3001\u533B\u5B66\u90E8\u306E\u4EBA\u3069\u3046\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 219851246620786688,
  "created_at" : "2012-07-02 17:53:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219850956123291649",
  "text" : "@i_horse \u30EF\u30BF\u30B7\u3001\u30A6\u30BD\u3001\u30B1\u30B7\u30C6\u30C4\u30AB\u30CA\u30A4(164\u307A\u30FC\u3058\u306E\u8A3C\u660E\u3067\u5727\u5012\u7684\u505C\u6EDE",
  "id" : 219850956123291649,
  "created_at" : "2012-07-02 17:52:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219850703898812416",
  "text" : "\u3042\u3063\u3001\u3053\u308C\u3001\u8A00\u3063\u3061\u3083\u3044\u3051\u306A\u3044\u3093\u3060\u3063\u305F\u30FC",
  "id" : 219850703898812416,
  "created_at" : "2012-07-02 17:51:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219850640749363201",
  "text" : "\u306F\u3093\u3064\u3064\u3060\u3068\u601D\u3063\u3066\u3066\u7B11\u308F\u308C\u305F\u3068\u304B\u79D8\u5BC6\u3067\u3059\u3057",
  "id" : 219850640749363201,
  "created_at" : "2012-07-02 17:50:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219850530426593281",
  "text" : "@i_horse \u307E\u3058\u304B\u30FC\u6C17\u306B\u306A\u308A\u306A\u308A\u307E\u3059\u306D",
  "id" : 219850530426593281,
  "created_at" : "2012-07-02 17:50:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219850319348244480",
  "text" : "@i_horse \u307E\u3060\u7D42\u308F\u3063\u3066\u306A\u3044(\u771F\u9854",
  "id" : 219850319348244480,
  "created_at" : "2012-07-02 17:49:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219850254655295488",
  "text" : "@i_horse \u306F\u3093\u3068\u3046\u3067\u3078\u3093\u304B\u3093\u3067\u304D\u306A\u3044\u306E\u306FiPhone\u304C\u60C5\u5F31\u306A\u306E\u304B\u306A",
  "id" : 219850254655295488,
  "created_at" : "2012-07-02 17:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219849929936478208",
  "text" : "\u534A\u7B52\u2190\u306A\u3093\u3066\u8AAD\u3080\uFF1F",
  "id" : 219849929936478208,
  "created_at" : "2012-07-02 17:48:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219848982300606464",
  "text" : "\u3046\u30FC\u3001\u306B\u3083\u30FC(\u771F\u9854",
  "id" : 219848982300606464,
  "created_at" : "2012-07-02 17:44:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219848848485523456",
  "text" : "\u5727\u5012\u7684\u4E80\u30EA\u30D7",
  "id" : 219848848485523456,
  "created_at" : "2012-07-02 17:43:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u306F\u306D",
      "screen_name" : "leteometro",
      "indices" : [ 0, 11 ],
      "id_str" : "1445583608",
      "id" : 1445583608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219848695213072384",
  "text" : "@leteometro \u610F\u8B58\u305B\u305A\u306B\u30AC\u30F3\u30AC\u30F3\u3064\u3076\u3084\u3044\u3066\u3044\u3051",
  "id" : 219848695213072384,
  "created_at" : "2012-07-02 17:43:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219400031541800960",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 219400031541800960,
  "created_at" : "2012-07-01 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219301815634763777",
  "text" : "RT @0_uda: \u300C\u3055\u304B\u306A\u306F\u30DE\u30B8\u30A4\u30B1\u30E1\u30F3\u3067\u7406\u5B66\u90E8\u306A\u306E\u306B\u670D\u3082\u6E05\u6F54\u3067\u30AA\u30B7\u30E3\u30EC\u3067\u30DE\u30B8\u30A4\u30B1\u30E1\u30F3\u3067\u3057\u304B\u3082\u8CE2\u304F\u3066\u30E1\u30AC\u30CD\u5916\u3059\u3068\u30DE\u30B8\u30A4\u30B1\u30E1\u30F3\u300D [\u30B9\u30C6\u30DE]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/github.com\/vimpr\/vimperator-plugins\/blob\/master\/twittperator.js\" rel=\"nofollow\"\u003ETwittperator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219301537720176641",
    "text" : "\u300C\u3055\u304B\u306A\u306F\u30DE\u30B8\u30A4\u30B1\u30E1\u30F3\u3067\u7406\u5B66\u90E8\u306A\u306E\u306B\u670D\u3082\u6E05\u6F54\u3067\u30AA\u30B7\u30E3\u30EC\u3067\u30DE\u30B8\u30A4\u30B1\u30E1\u30F3\u3067\u3057\u304B\u3082\u8CE2\u304F\u3066\u30E1\u30AC\u30CD\u5916\u3059\u3068\u30DE\u30B8\u30A4\u30B1\u30E1\u30F3\u300D [\u30B9\u30C6\u30DE]",
    "id" : 219301537720176641,
    "created_at" : "2012-07-01 05:28:55 +0000",
    "user" : {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "protected" : false,
      "id_str" : "184844182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547956554922614784\/ccU36n2B_normal.png",
      "id" : 184844182,
      "verified" : false
    }
  },
  "id" : 219301815634763777,
  "created_at" : "2012-07-01 05:30:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219279774437220352",
  "text" : "\u304A\u304D\u305F\n\u30EB\u30CD\u5411\u304B\u3046\u304B",
  "id" : 219279774437220352,
  "created_at" : "2012-07-01 04:02:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219228757880344576",
  "text" : "3\u6642\u9593\u307B\u3069\u5BDD\u308B\u304B",
  "id" : 219228757880344576,
  "created_at" : "2012-07-01 00:39:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219228644470554624",
  "text" : "\u3057\u304B\u3057\u3053\u3053\u306B\u304D\u3066\u5727\u5012\u7684\u7720\u6C17",
  "id" : 219228644470554624,
  "created_at" : "2012-07-01 00:39:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219227879559532544",
  "text" : "\u3042\u308C\u300111\u6642\u307E\u3067\u3042\u306890\u5206\u4F4D\u3057\u304B\u306A\u3044\u3093\u3060\u304C\u30FC\uFF1F",
  "id" : 219227879559532544,
  "created_at" : "2012-07-01 00:36:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219220104934727681",
  "text" : "\u591A\u69D8\u4F53\u64CD\uFF01",
  "id" : 219220104934727681,
  "created_at" : "2012-07-01 00:05:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219220041860788224",
  "text" : "RT @the_TQFT: \u6570\u5B66\u4F53\u64CD\u3060\u3044\u3044\u3061\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043(^^)(^^)(^^)(^^)(^^)\u30DA\u30F3\u3092\u6301\u3063\u3066\u5FAE\u5206\u306E\u904B\u52D5\u3001\u306F\u3044!!!!!!!!!!!!!!!!!!!!!!!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219216479063769088",
    "text" : "\u6570\u5B66\u4F53\u64CD\u3060\u3044\u3044\u3061\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043\u3043(^^)(^^)(^^)(^^)(^^)\u30DA\u30F3\u3092\u6301\u3063\u3066\u5FAE\u5206\u306E\u904B\u52D5\u3001\u306F\u3044!!!!!!!!!!!!!!!!!!!!!!!!!!",
    "id" : 219216479063769088,
    "created_at" : "2012-06-30 23:50:56 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 219220041860788224,
  "created_at" : "2012-07-01 00:05:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219203926417879041",
  "text" : "\u3044\u3046\u306A\u308C\u3070\uFF0C\u306C\u308C\u306D\u305A\u307F",
  "id" : 219203926417879041,
  "created_at" : "2012-06-30 23:01:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]