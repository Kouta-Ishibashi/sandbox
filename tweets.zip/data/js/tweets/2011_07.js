Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97637684813643776",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 97637684813643776,
  "created_at" : "2011-07-31 12:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u9CE5\u30B3\u30F3",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97437795123077120",
  "text" : "100\uFF05\u508D\u89B3\u8005\u3060\u304C\u898B\u306B\u6765\u305F\u3088\u3093 \uFF03\u9CE5\u30B3\u30F3",
  "id" : 97437795123077120,
  "created_at" : "2011-07-30 22:45:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97436993071480832",
  "text" : "\u3053\u306E\u7A7A\u3092\u98DB\u3093\u3067\u6E56\u306B\u843D\u3061\u308B\u306E\u306F\u5FC3\u5730\u597D\u3044\u306B\u9055\u3044\u306A\u3044\u3002",
  "id" : 97436993071480832,
  "created_at" : "2011-07-30 22:42:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97431381642194944",
  "text" : "\u7435\u7436\u6E56\u306A\u3046\u3002\u3053\u308C\u4EBA\u9593\u306E\u611F\u899A\u3060\u3068\u3069\u3046\u8003\u3048\u3066\u3082\u6D77\u3060\u308F\u3002\u305F\u3060\u6DE1\u6C34\u3063\u3066\u3060\u3051\u3067\u3002",
  "id" : 97431381642194944,
  "created_at" : "2011-07-30 22:20:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97420926198624256",
  "text" : "\u3057\u304B\u3057\u6642\u9593\u3092\u6F70\u305B\u305D\u3046\u306A\u55AB\u8336\u5E97\u304C\u306A\u3044\u306A\u3041\u2026",
  "id" : 97420926198624256,
  "created_at" : "2011-07-30 21:38:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97420763065360384",
  "text" : "\u5F66\u6839\u306A\u3046\u3002\u79C1\u306F\u6ECB\u8CC0\u306A\u3044\u5B66\u751F\u3067\u3059\u3002\u6B7B\u304C\u306A\u3044\u5B66\u751F\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
  "id" : 97420763065360384,
  "created_at" : "2011-07-30 21:38:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 3, 12 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97416482354507776",
  "text" : "RT @nisehorn: \u30A8\u30E9\u30FC\uFF1A\u305D\u306E\u5E7B\u60F3\u306F\u3059\u3067\u306B\u3076\u3061\u6BBA\u3055\u308C\u3066\u3044\u307E\u3059",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97416003830550529",
    "text" : "\u30A8\u30E9\u30FC\uFF1A\u305D\u306E\u5E7B\u60F3\u306F\u3059\u3067\u306B\u3076\u3061\u6BBA\u3055\u308C\u3066\u3044\u307E\u3059",
    "id" : 97416003830550529,
    "created_at" : "2011-07-30 21:19:19 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "protected" : false,
      "id_str" : "96348838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009677836\/06-12-24_23-49m_normal.jpg",
      "id" : 96348838,
      "verified" : false
    }
  },
  "id" : 97416482354507776,
  "created_at" : "2011-07-30 21:21:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97414674060021761",
  "text" : "\u4EAC\u90FD\u304B\u3089\u4ED6\u5E9C\u770C\u306B\u51FA\u308B\u96FB\u8ECA\u304B\u3089\u898B\u308B\u666F\u8272\u3063\u3066\u65E5\u672C\u306E\u539F\u98A8\u666F\u3063\u307D\u304F\u3066\u597D\u304D\u3060\u306A\u3002\u8AAD\u8005\u306E\u5408\u9593\u306B\u3075\u3068\u898B\u308B\u306A\u3089\u304B\u3082\u3060\u3051\u3069\u3002",
  "id" : 97414674060021761,
  "created_at" : "2011-07-30 21:14:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97409865227579393",
  "text" : "\u96F6\u5D0E\u4EBA\u8B58\u3068\u622F\u8A00\u9063\u3044\u306E\u95A2\u4FC2\u306F\u30AF\u30D3\u30B7\u30E1\u30ED\u30DE\u30F3\u30C1\u30B9\u30C8\u306E\u88CF\u5074\u3063\u3066\u308F\u3051\u304B\u88CF\u304B\u3089\u5148\u306B\u8AAD\u3093\u3058\u307E\u3063\u305F\u3063\u3066\u308F\u3051\u304B\u3001\u60AA\u304F\u306A\u3044\u304C\u3002",
  "id" : 97409865227579393,
  "created_at" : "2011-07-30 20:54:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97397318810210305",
  "text" : "\u305D\u3057\u3066\u591C\u304C\u660E\u3051\u305F\u2026\uFF01",
  "id" : 97397318810210305,
  "created_at" : "2011-07-30 20:05:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97396597478010880",
  "text" : "\u4EAC\u90FD\u99C5\u306A\u3046\u3063\uFF01\u7740\u304F\u306E\u65E9\u904E\u304E\u308B\uFF01",
  "id" : 97396597478010880,
  "created_at" : "2011-07-30 20:02:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97390765801603073",
  "text" : "@koketomi \u304A\u306F\u3088\u3046",
  "id" : 97390765801603073,
  "created_at" : "2011-07-30 19:39:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97381962704093185",
  "text" : "\u5730\u9707TL\u2026",
  "id" : 97381962704093185,
  "created_at" : "2011-07-30 19:04:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97369431818248192",
  "text" : "\u307E\u3060\u8AE6\u3081\u305A\u4E8C\u5EA6\u5BDD\u3092\u8A66\u307F\u3066\u3044\u308B\u304C\u2026",
  "id" : 97369431818248192,
  "created_at" : "2011-07-30 18:14:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97367082756341760",
  "geo" : { },
  "id_str" : "97367270724087808",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 97367270724087808,
  "in_reply_to_status_id" : 97367082756341760,
  "created_at" : "2011-07-30 18:05:41 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97367197764161536",
  "text" : "\uFF083\u6642\u3068\u304B\"\u307E\u3060\"\u8D77\u304D\u3066\u308B\u6642\u9593\u3067\u3042\u3063\u3066\"\u3082\u3046\"\u8D77\u304D\u3066\u308B\u6642\u9593\u3058\u3083\u3042\u306A\u3044\u3088\u306A\u30FC\uFF09",
  "id" : 97367197764161536,
  "created_at" : "2011-07-30 18:05:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 13, 24 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97366496031932416",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn @magokoro84 \u304A\u3084\u3059\u307F\u3069\u3082\u3067\u3057\u305F\u30FC",
  "id" : 97366496031932416,
  "created_at" : "2011-07-30 18:02:36 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97366160307265536",
  "text" : "\u3080\u30FC\u3001\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u304F\u76EE\u304C\u899A\u3081\u3066\u3057\u307E\u3063\u305F\u3002\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 97366160307265536,
  "created_at" : "2011-07-30 18:01:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97275353738911744",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 97275353738911744,
  "created_at" : "2011-07-30 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97260055426109441",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 97260055426109441,
  "created_at" : "2011-07-30 10:59:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307D\u307D",
      "screen_name" : "_popopopoon_",
      "indices" : [ 17, 30 ],
      "id_str" : "154165877",
      "id" : 154165877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97255151659782144",
  "text" : "\u8A18\u53F7\u8AD6\u7406\u3068\u3069\u3046\u9055\u3046\u3093\u3067\u3057\u3087 RT @_popopopoon_ \u6570\u7406\u8AD6\u7406\u5B66\u3084\u3063\u3066\u307F\u305F\u3044\u3051\u3069\u3001\u3069\u3093\u306A\u3093\u3060\u308D\u3002",
  "id" : 97255151659782144,
  "created_at" : "2011-07-30 10:40:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97253499229843456",
  "geo" : { },
  "id_str" : "97254594517794816",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3064\u6771\u4EAC\u5927\u5B66\u51FA\u7248\u3001\u7D71\u8A08\u5B66\u5165\u9580",
  "id" : 97254594517794816,
  "in_reply_to_status_id" : 97253499229843456,
  "created_at" : "2011-07-30 10:37:56 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97250877311684608",
  "text" : "\u660E\u65E5\u306F\u7121\u99C4\u306B\u65E9\u3044\u304B\u3089\u305D\u308D\u305D\u308D\u5BDD\u308B\u6E96\u5099\u30FC\u3002\u3069\u3046\u305B\u3057\u3070\u3089\u304F\u306F\u7720\u308C\u306A\u3044\u3060\u308D\u3046\u3051\u3069\u306A\u30FC\u3002",
  "id" : 97250877311684608,
  "created_at" : "2011-07-30 10:23:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97245423424638976",
  "text" : "RT @fumiexcel: \u30DF\u30EB\u30AB\u300C\u30A8\u30A3\u30A8\u30A3\u304C\u3084\u3089\u308C\u305F\u3088\u3046\u3060\u306A\u2026\u300D\u30C6\u30C8\u30E9\u300C\u30AF\u30AF\u30AF\u2026\u5974\u306F\u56DB\u5929\u738B\u306E\u4E2D\u3067\u3082\u6700\u5F31\u2026\u300D\u30E6\u30FC\u30EA\u300C\u56DB\u5DFB\u3054\u3068\u304D\u3067\u3044\u306A\u304F\u306A\u308B\u3068\u306F\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u9762\u6C5A\u3057\u3088\u2026\u300D\u30EA\u30B5\u300C\u2026\u2026(\u9837\u304F)\u300D#mathgirl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mathgirl",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97243814191841280",
    "text" : "\u30DF\u30EB\u30AB\u300C\u30A8\u30A3\u30A8\u30A3\u304C\u3084\u3089\u308C\u305F\u3088\u3046\u3060\u306A\u2026\u300D\u30C6\u30C8\u30E9\u300C\u30AF\u30AF\u30AF\u2026\u5974\u306F\u56DB\u5929\u738B\u306E\u4E2D\u3067\u3082\u6700\u5F31\u2026\u300D\u30E6\u30FC\u30EA\u300C\u56DB\u5DFB\u3054\u3068\u304D\u3067\u3044\u306A\u304F\u306A\u308B\u3068\u306F\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u9762\u6C5A\u3057\u3088\u2026\u300D\u30EA\u30B5\u300C\u2026\u2026(\u9837\u304F)\u300D#mathgirl",
    "id" : 97243814191841280,
    "created_at" : "2011-07-30 09:55:06 +0000",
    "user" : {
      "name" : "Fumi O'Orient",
      "screen_name" : "fumieval",
      "protected" : false,
      "id_str" : "75975397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590538208829542400\/Q_vVjs8H_normal.png",
      "id" : 75975397,
      "verified" : false
    }
  },
  "id" : 97245423424638976,
  "created_at" : "2011-07-30 10:01:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30FC\u30B8",
      "screen_name" : "Kiriyama_George",
      "indices" : [ 3, 19 ],
      "id_str" : "130188593",
      "id" : 130188593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97231266289696768",
  "text" : "RT @Kiriyama_George: \u300C\u98F2\u9152\u904B\u8EE2\u306A\u3046\u300D\u3068\u3044\u3046\u3064\u3076\u3084\u304D\u304C\u3042\u3063\u305F\u3089\u3001\u98F2\u9152\u3088\u308A\u3082Twitter\u3057\u306A\u304C\u3089\u904B\u8EE2\u3057\u3066\u3044\u308B\u3053\u3068\u306B\u5371\u967A\u6027\u3092\u611F\u3058\u308B\u3079\u304D\u3067\u306F\u306A\u3044\u3060\u308D\u3046\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97229865186635776",
    "text" : "\u300C\u98F2\u9152\u904B\u8EE2\u306A\u3046\u300D\u3068\u3044\u3046\u3064\u3076\u3084\u304D\u304C\u3042\u3063\u305F\u3089\u3001\u98F2\u9152\u3088\u308A\u3082Twitter\u3057\u306A\u304C\u3089\u904B\u8EE2\u3057\u3066\u3044\u308B\u3053\u3068\u306B\u5371\u967A\u6027\u3092\u611F\u3058\u308B\u3079\u304D\u3067\u306F\u306A\u3044\u3060\u308D\u3046\u304B",
    "id" : 97229865186635776,
    "created_at" : "2011-07-30 08:59:40 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30FC\u30B8",
      "screen_name" : "Kiriyama_George",
      "protected" : false,
      "id_str" : "130188593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1698591176\/image_normal",
      "id" : 130188593,
      "verified" : false
    }
  },
  "id" : 97231266289696768,
  "created_at" : "2011-07-30 09:05:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97230654881800193",
  "geo" : { },
  "id_str" : "97231087167733760",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u6570\u5B66\u3092\u30CD\u30BF\u306B\u3057\u305F\u30DC\u30AB\u30ED\u66F2\u304B\u4F55\u304B\u3067\u305D\u3046\u3044\u3046\u30CD\u30BF\u3092\u898B\u305F\u3053\u3068\u304C\u3042\u308B\u3088\u3093",
  "id" : 97231087167733760,
  "in_reply_to_status_id" : 97230654881800193,
  "created_at" : "2011-07-30 09:04:32 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97230462421958656",
  "text" : "\u4ECA\u65E5\u306E\u304A\u5915\u98EF\u306F\u8C5A\u8089\u306E\u30BD\u30C6\u30FC\u30AB\u30EC\u30FC\u98A8\u3067\u3059\u3057",
  "id" : 97230462421958656,
  "created_at" : "2011-07-30 09:02:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97230256339030016",
  "text" : "\u304A\u304B\u305A\u51FA\u6765\u305F\u306E\u306B\u3054\u98EF\u708A\u3051\u3066\u306A\u3044\u30D1\u30BF\u30FC\u30F3\u5165\u308A\u307E\u3057\u305F\u30FC\uFF01",
  "id" : 97230256339030016,
  "created_at" : "2011-07-30 09:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 7, 16 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EAC\u5927\u3042\u308B\u3042\u308B",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97230093419675648",
  "text" : "\u306D\u30FC\u3088 RT @nisehorn: \u8CEA\u554F\u3059\u308B\u3068\u304D\u306F\u307E\u305A\u30E4\u30D5\u30FC\u77E5\u6075\u888B #\u4EAC\u5927\u3042\u308B\u3042\u308B",
  "id" : 97230093419675648,
  "created_at" : "2011-07-30 09:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97229571384033280",
  "text" : "\u304A\u3075\u304F\u308D\u3055\u3093\u306E\u6280\u8853\u529B\uFF57\uFF57\uFF57",
  "id" : 97229571384033280,
  "created_at" : "2011-07-30 08:58:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3051\u306A\u3073",
      "screen_name" : "kakenavi",
      "indices" : [ 3, 12 ],
      "id_str" : "48381394",
      "id" : 48381394
    }, {
      "name" : "Hirofumi",
      "screen_name" : "awaku7",
      "indices" : [ 14, 21 ],
      "id_str" : "171290310",
      "id" : 171290310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97229481248440320",
  "text" : "RT @kakenavi: @awaku7 \u5C0F\u5B66\u751F\u306E\u3068\u304D\u3067\u3059\u304C\u3002\u300C\u3042\u3093\u305F\u3001\u30D5\u30A1\u30DF\u30B3\u30F3\u3070\u3063\u304B\u308A\u3084\u3063\u3066\uFF01\u30C6\u30B9\u30C8\u306E\u70B9\u304C\u3042\u304C\u308B\u307E\u3067\u3001\u3053\u3046\u3059\u308B\uFF01\u300D\u3068\u8A00\u3063\u3066AC\u30A2\u30C0\u30D7\u30BF\u306E\u30B1\u30FC\u30D6\u30EB\u3092\u30CF\u30B5\u30DF\u3067\u5207\u3063\u305F\u304A\u888B\u306F\u3001\u305D\u306E\u5F8C\u6CE3\u304F\u6CE3\u304F\u52C9\u5F37\u3057\u305F\u606F\u5B50\u306E\u59FF\u3092\u898B\u306A\u304C\u3089\u3001\u30CF\u30F3\u30C0\u4ED8\u3051\u3067\u76F4\u3057\u307E\u3057\u305F\u3002\u3064\u3044\u3067\u306B\u3001\u30BF\u30A4\u30DE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hirofumi",
        "screen_name" : "awaku7",
        "indices" : [ 0, 7 ],
        "id_str" : "171290310",
        "id" : 171290310
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "97136294437720066",
    "geo" : { },
    "id_str" : "97136847867740160",
    "in_reply_to_user_id" : 171290310,
    "text" : "@awaku7 \u5C0F\u5B66\u751F\u306E\u3068\u304D\u3067\u3059\u304C\u3002\u300C\u3042\u3093\u305F\u3001\u30D5\u30A1\u30DF\u30B3\u30F3\u3070\u3063\u304B\u308A\u3084\u3063\u3066\uFF01\u30C6\u30B9\u30C8\u306E\u70B9\u304C\u3042\u304C\u308B\u307E\u3067\u3001\u3053\u3046\u3059\u308B\uFF01\u300D\u3068\u8A00\u3063\u3066AC\u30A2\u30C0\u30D7\u30BF\u306E\u30B1\u30FC\u30D6\u30EB\u3092\u30CF\u30B5\u30DF\u3067\u5207\u3063\u305F\u304A\u888B\u306F\u3001\u305D\u306E\u5F8C\u6CE3\u304F\u6CE3\u304F\u52C9\u5F37\u3057\u305F\u606F\u5B50\u306E\u59FF\u3092\u898B\u306A\u304C\u3089\u3001\u30CF\u30F3\u30C0\u4ED8\u3051\u3067\u76F4\u3057\u307E\u3057\u305F\u3002\u3064\u3044\u3067\u306B\u3001\u30BF\u30A4\u30DE\u30FC\u3067\u5207\u308C\u308B\u96FB\u6E90\u306B\u306A\u308A\u307E\u3057\u305F\u3002",
    "id" : 97136847867740160,
    "in_reply_to_status_id" : 97136294437720066,
    "created_at" : "2011-07-30 02:50:03 +0000",
    "in_reply_to_screen_name" : "awaku7",
    "in_reply_to_user_id_str" : "171290310",
    "user" : {
      "name" : "\u304B\u3051\u306A\u3073",
      "screen_name" : "kakenavi",
      "protected" : false,
      "id_str" : "48381394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2292448272\/866nvqr1p4qaisa29ebm_normal.png",
      "id" : 48381394,
      "verified" : false
    }
  },
  "id" : 97229481248440320,
  "created_at" : "2011-07-30 08:58:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97222221453471745",
  "geo" : { },
  "id_str" : "97229261731135488",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305D\u306E\u6CD5\u5247\u306F\u6570\u5B66\u7684\u306B\u306F\u5BFE\u79F0\u5F8B\u3063\u3066\u540D\u524D\u304C\u3042\u3063\u305F\u308A\u3059\u308B\u3002",
  "id" : 97229261731135488,
  "in_reply_to_status_id" : 97222221453471745,
  "created_at" : "2011-07-30 08:57:17 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97194772669796353",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u58F2\u3063\u305F\u304A\u91D1\u3067\u8CB7\u3063\u305F\u5FAE\u7A4D\u306E\u6F14\u7FD2\u672C\u3092\u89E6\u3063\u3066\u7D20\u6575\u306A\u5348\u5F8C\u3092\u6F14\u51FA\uFF08\uFF09",
  "id" : 97194772669796353,
  "created_at" : "2011-07-30 06:40:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97193543092797440",
  "text" : "\u3042\u30FC\u30AF\u30D3\u30AD\u30EA\u30B5\u30A4\u30AF\u30EB\u8AAD\u307F\u7D42\u3048\u3061\u3083\u3063\u305F\u3089\u660E\u65E5\u96FB\u8ECA\u3067\u8AAD\u3080\u672C\u304C\u306A\u3044\u3088\u306A\u3041\u2026\u3002\u4E8C\u4F5C\u54C1\u76EE\u3092\u8CB7\u3063\u3066\u304B\u3089\u884C\u304F\u304B\u30FC\u3002\u3053\u3046\u3057\u3066\u672C\u304C\u5897\u3048\u3066\u3044\u304F\u306E\u304B\u3002\n\u8CB7\u3046\u30DA\u30FC\u30B9\u3068\u8CA1\u5E03\u304C\u8EFD\u304F\u306A\u308B\u30DA\u30FC\u30B9\u304C\u901F\u3044\u3002\u3002\u3002",
  "id" : 97193543092797440,
  "created_at" : "2011-07-30 06:35:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97173412996317184",
  "geo" : { },
  "id_str" : "97173838575575040",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u305D\u308C\u306F\u30AB\u30F3\u9055\u3044\u3060\u306A",
  "id" : 97173838575575040,
  "in_reply_to_status_id" : 97173412996317184,
  "created_at" : "2011-07-30 05:17:03 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97170871160016898",
  "geo" : { },
  "id_str" : "97173175401590785",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u4F55\u3092\uFF1F",
  "id" : 97173175401590785,
  "in_reply_to_status_id" : 97170871160016898,
  "created_at" : "2011-07-30 05:14:25 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97170745469308929",
  "text" : "\u6674\u8003\u96E8\u8AAD\u306E\u81EA\u5206\u3068\u3057\u3066\u306F\u60AA\u304F\u306A\u3044\u304B\u306A\u3002\u4ECA\u65E5\u306F\u3053\u308C\u304B\u3089\u5BB6\u304B\u3089\u51FA\u308B\u4E88\u5B9A\u3082\u306A\u3044\u3057\u3002",
  "id" : 97170745469308929,
  "created_at" : "2011-07-30 05:04:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97170574601752577",
  "text" : "\u30B9\u30B3\u30FC\u30EB",
  "id" : 97170574601752577,
  "created_at" : "2011-07-30 05:04:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97170437087301632",
  "text" : "RT @tameninaru: \u300C\u601D\u6625\u671F\u306E\u5C11\u5E74\u306B\u3068\u3063\u3066\u3001\u9F3B\u3092\u307B\u3058\u304F\u308B\u3053\u3068\u306F\u666E\u901A\u306E\u884C\u52D5\u3067\u3042\u308B\u300D\u3068\u3044\u3046\u533B\u5B66\u7684\u767A\u898B\u3092\u7A81\u304D\u6B62\u3081\u305F\u3053\u3068\u306B\u5BFE\u3057\u3066\uFF082001\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u516C\u8846\u885B\u751F\u8CDE\uFF1A\u30C1\u30C3\u30BF\u30E9\u30F3\u30B8\u30E3\u30F3\u30FB\u30A2\u30F3\u30C9\u30EC\u30A4\u30C9\u3001B\u30FBS\u30FB\u30B9\u30EB\u30CF\u30EA\uFF09http:\/\/goo.gl\/sTnr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97169561446653952",
    "text" : "\u300C\u601D\u6625\u671F\u306E\u5C11\u5E74\u306B\u3068\u3063\u3066\u3001\u9F3B\u3092\u307B\u3058\u304F\u308B\u3053\u3068\u306F\u666E\u901A\u306E\u884C\u52D5\u3067\u3042\u308B\u300D\u3068\u3044\u3046\u533B\u5B66\u7684\u767A\u898B\u3092\u7A81\u304D\u6B62\u3081\u305F\u3053\u3068\u306B\u5BFE\u3057\u3066\uFF082001\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u516C\u8846\u885B\u751F\u8CDE\uFF1A\u30C1\u30C3\u30BF\u30E9\u30F3\u30B8\u30E3\u30F3\u30FB\u30A2\u30F3\u30C9\u30EC\u30A4\u30C9\u3001B\u30FBS\u30FB\u30B9\u30EB\u30CF\u30EA\uFF09http:\/\/goo.gl\/sTnr",
    "id" : 97169561446653952,
    "created_at" : "2011-07-30 05:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 97170437087301632,
  "created_at" : "2011-07-30 05:03:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97170264810459136",
  "text" : "\u9177\u3044\u96E8\u30FB\u30FB\u30FB",
  "id" : 97170264810459136,
  "created_at" : "2011-07-30 05:02:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97169190913445888",
  "text" : "\u30A2\u30EB\u30B3\u30FC\u30EB\u5EA6\u6570\u3092\u5FAE\u5206\u3057\u3066\u305F\u53CB\u4EBA\u304C\u3044\u3066\u3060\u306A\u2026 RT \u56DB\u5247\u6F14\u7B97\u51FA\u6765\u308C\u3070\u751F\u304D\u3066\u3044\u3051\u308B\u3002\u98F2\u307F\u4F1A\u3067\u56DB\u5247\u6F14\u7B97\u4EE5\u4E0A\u306E\u6570\u5B66\u3092\u4F7F\u3063\u3066\u308B\u3084\u3064\u3092\u898B\u305F\u4E8B\u304C\u306A\u3044\u3000#\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
  "id" : 97169190913445888,
  "created_at" : "2011-07-30 04:58:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97162770570682368",
  "text" : "\u3055\u3041\u5FF5\u9858\u306E\u30AF\u30D3\u30AD\u30EA\u30B5\u30A4\u30AF\u30EB\u3092\u8AAD\u3082\u3046\u3002",
  "id" : 97162770570682368,
  "created_at" : "2011-07-30 04:33:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 30, 37 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97161563890397184",
  "text" : "RT @magokoro84: \u3053\u308C\u306F\u3042\u308B\u3042\u308B\u3059\u304E\u308B RT @khulud: \u865A\u69CB\u65B0\u805E\u306E\u30C9\u30E1\u30A4\u30F3 kyoko-np.net \u306F\u3044\u3064\u3082 kyoto-u.ac.jp \u306B\u7A7A\u76EE\u3059\u308B\uFF0E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u062E\u0644\u0648\u062F",
        "screen_name" : "khulud",
        "indices" : [ 14, 21 ],
        "id_str" : "239486216",
        "id" : 239486216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97160590304350209",
    "text" : "\u3053\u308C\u306F\u3042\u308B\u3042\u308B\u3059\u304E\u308B RT @khulud: \u865A\u69CB\u65B0\u805E\u306E\u30C9\u30E1\u30A4\u30F3 kyoko-np.net \u306F\u3044\u3064\u3082 kyoto-u.ac.jp \u306B\u7A7A\u76EE\u3059\u308B\uFF0E",
    "id" : 97160590304350209,
    "created_at" : "2011-07-30 04:24:24 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 97161563890397184,
  "created_at" : "2011-07-30 04:28:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96973697197408258",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 96973697197408258,
  "created_at" : "2011-07-29 16:01:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96973633418829824",
  "text" : "\u5BDD\u308B\u3002",
  "id" : 96973633418829824,
  "created_at" : "2011-07-29 16:01:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96973156459360257",
  "text" : "\u5B66\u6821\u30B5\u30DC\u3063\u3066\u3001\u7ACB\u547D\u9928\u3068\u540C\u5FD7\u793E\u898B\u306B\u884C\u3063\u305F\u3082\u306E\u306E\u5EFA\u7269\u306B\u5165\u308B\u306E\u3092\u8E8A\u8E87\u3044\u3050\u308B\u3063\u3068\u6B69\u3044\u3066\u5E30\u3063\u305F\u601D\u3044\u51FA\u3002",
  "id" : 96973156459360257,
  "created_at" : "2011-07-29 15:59:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 8, 17 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96970986578116608",
  "text" : "\u304A\u3081\u30A1\uFF01 RT @isaribiz: \u521D\u6D41\u3057\u6E80\u8CAB\u30A1\uFF01",
  "id" : 96970986578116608,
  "created_at" : "2011-07-29 15:50:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96966496995127297",
  "geo" : { },
  "id_str" : "96967191102107648",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u591A\u724C\u3067\u3059\u30024000 2000\uFF01",
  "id" : 96967191102107648,
  "in_reply_to_status_id" : 96966496995127297,
  "created_at" : "2011-07-29 15:35:54 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 20, 28 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96966598614724608",
  "text" : "\u306A\u306B\u3053\u308C\u51C4\u3044\uFF01\u30D6\u30C3\u30AF\u30DE\u30FC\u30AF\u30A1\uFF01\uFF01 RT @i_horse \u89E3\u6790\u6982\u8AD6\u30BC\u30DF\u306F\u3053\u308C\u304B\u3089\u306F\u3053\u308C\u3067\u3084\u308B\u6642\u4EE3\u3060\u306A\u3000http:\/\/bit.ly\/iqvKa3",
  "id" : 96966598614724608,
  "created_at" : "2011-07-29 15:33:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96966264920092673",
  "text" : "RT @darkhwak: \u6DBC\u3057\u3044\u539F\u56E0\u304C\u5224\u660E\uFF1A\u677E\u5CA1\u4FEE\u9020\u65E5\u672C\u4E0D\u5728",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96519521103388672",
    "text" : "\u6DBC\u3057\u3044\u539F\u56E0\u304C\u5224\u660E\uFF1A\u677E\u5CA1\u4FEE\u9020\u65E5\u672C\u4E0D\u5728",
    "id" : 96519521103388672,
    "created_at" : "2011-07-28 09:57:01 +0000",
    "user" : {
      "name" : "\u3042\u3055\u304D\u3059\u3068\u540D\u4EBA\u305F\u304B\u306E\u3053\u304F\u3093",
      "screen_name" : "LMNT_takanoko",
      "protected" : false,
      "id_str" : "189501841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473857202944348160\/E-GYA_9w_normal.jpeg",
      "id" : 189501841,
      "verified" : false
    }
  },
  "id" : 96966264920092673,
  "created_at" : "2011-07-29 15:32:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 9, 20 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96966142580621312",
  "text" : "\u6559\u3048\u308B\u3088\u3063 RT @magokoro84: \u9EBB\u96C0\u899A\u3048\u306A\u3044\u3068\u306A",
  "id" : 96966142580621312,
  "created_at" : "2011-07-29 15:31:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 32, 40 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96960495780757505",
  "text" : "\u9762\u767D\u305D\u3046\u2026\u3068\u306F\u601D\u3046\u304C\u3064\u3044\u3066\u3044\u3051\u306A\u3055\u305D\u3046\u306A\u30EC\u30D9\u30EB\u3060\u3002\u3046\u3093\u3002 RT @i_horse \u5F8C\u671F\u78BA\u7387\u8AD6\u30BC\u30DF\u3084\u308A\u307E\u305B\u3093\u304B\u30FC\uFF1F\u3000KU\u3092\u4E88\u5B9A\u3057\u3066\u3044\u307E\u3059\u3002\u6559\u79D1\u66F8\u306F\u3053\u308C\u3067\u2192http:\/\/bit.ly\/oZGucX",
  "id" : 96960495780757505,
  "created_at" : "2011-07-29 15:09:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96906686102638592",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B\u3068\u3001kagakuma\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u304C\u3063\u3066\u3044\u307E\u3059 http:\/\/gohantabeyo.com\/nani\/1?prefill=kagakuma \u4E00\u7DD2\u306B\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u63A2\u3057\u307E\u3057\u3087\u3046\u3002",
  "id" : 96906686102638592,
  "created_at" : "2011-07-29 11:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kojima",
      "screen_name" : "t33f",
      "indices" : [ 0, 5 ],
      "id_str" : "14152394",
      "id" : 14152394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96899211701915648",
  "geo" : { },
  "id_str" : "96900174848339969",
  "in_reply_to_user_id" : 14152394,
  "text" : "@t33f \u591A\u5206\u6570\u5B66\u306E\u54F2\u5B66\u306E\u4E00\u5206\u91CE\u3060\u3068\u601D\u3044\u307E\u3059\u3002\u50D5\u3082\u9F67\u308A\u59CB\u3081\u3063\u3066\u3068\u3053\u308D\u306A\u306E\u3067\u3059\u304C\uFF57",
  "id" : 96900174848339969,
  "in_reply_to_status_id" : 96899211701915648,
  "created_at" : "2011-07-29 11:09:36 +0000",
  "in_reply_to_screen_name" : "t33f",
  "in_reply_to_user_id_str" : "14152394",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kojima",
      "screen_name" : "t33f",
      "indices" : [ 19, 24 ],
      "id_str" : "14152394",
      "id" : 14152394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96898298329317376",
  "text" : "\u3042\u308A\u307E\u3059\u3088\u30FC\u3002\u79D1\u5B66\u54F2\u5B66\u306E\u4E00\u5206\u91CE RT @t33f \u6570\u5B66\u306E\u54F2\u5B66\u306E\u4E2D\u306B\u7D71\u8A08\u306B\u3064\u3044\u3066\u8003\u3048\u308B\u5206\u91CE\u304C\u3042\u3063\u305F\u308A\u3059\u308B\u3093\u3060\u308D\u3046\u304B\u3002\u805E\u3044\u305F\u3053\u3068\u306F\u306A\u3044\u3051\u3069\u3002\u6570\u5B66\u306E\u54F2\u5B66\u3063\u3066\u6570\u7406\u8AD6\u7406\u306E\u65B9\u9762\u306B\u5411\u3044\u3066\u308B\u30A4\u30E1\u30FC\u30B8\u304C\u3042\u308B",
  "id" : 96898298329317376,
  "created_at" : "2011-07-29 11:02:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96897607330304000",
  "text" : "\u65E5\u672C\u8A9E\u3063\u3066\u96E3\u3057\u3044\u3088\u306D\u3001\u3046\u3093",
  "id" : 96897607330304000,
  "created_at" : "2011-07-29 10:59:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96799009997463552",
  "text" : "@ayu167 \u304D\u305F\u304F\u3057\u305F\u3002\u5149\u308A\u306E\u65E9\u3055\u3067\u3068\u308A\u304B\u304B\u308B",
  "id" : 96799009997463552,
  "created_at" : "2011-07-29 04:27:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96737401694715905",
  "geo" : { },
  "id_str" : "96737821603266560",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF",
  "id" : 96737821603266560,
  "in_reply_to_status_id" : 96737401694715905,
  "created_at" : "2011-07-29 00:24:28 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 3, 10 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96621754067333121",
  "text" : "RT @ayu167 \u30EC\u30DD\u30FC\u30C8\u4E00\u500B\u66F8\u304D\u7D42\u308F\u3063\u305F\u30FC",
  "id" : 96621754067333121,
  "created_at" : "2011-07-28 16:43:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96620930490564608",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 96620930490564608,
  "created_at" : "2011-07-28 16:39:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96620771601956864",
  "text" : "\u307E\u305F\u30EC\u30DD\u30FC\u30C8\u8ACB\u3051\u8CA0\u3063\u305F\u2190\u5BDD\u3088\u3046\u3002",
  "id" : 96620771601956864,
  "created_at" : "2011-07-28 16:39:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tomo@\u8107\u9053\u5BC4\u308A\u9053\u9060\u56DE\u308A",
      "screen_name" : "cocoatomo",
      "indices" : [ 17, 27 ],
      "id_str" : "7590702",
      "id" : 7590702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96615412069961728",
  "text" : "\u3042\u308B\u7A2E\u79D1\u5B66\u54F2\u5B66\u306E\u9818\u57DF\u304B\u306A\u3041 RT @cocoatomo \u305F\u3060\u3001\u6570\u5B66\u306E\u30E1\u30BF\u306A\u8A71\u306B\u3059\u308B\u3068\u79D1\u5B66\u7684\u601D\u8003\u306E\u8A71\u306B\u8FD1\u3044\u3057\u306A\u3041\u3002\u6570\u5B66\u7279\u6709\u3067\u3082\u306A\u3044\u6C17\u304C\u3059\u308B\u3002",
  "id" : 96615412069961728,
  "created_at" : "2011-07-28 16:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96614958330155008",
  "text" : "KU\u30EA\u30B9\u30C8\u898B\u3066\u308B\u3068\u300C\u6570\u5B66\u597D\u304D\u3060\u3051\u3069\u51FA\u6765\u306A\u3044\u7CFB\u5927\u5B66\u751F\u300D\u591A\u305D\u3046\u3060\u304B\u3089\u5F8C\u671F\u304B\u3089\u4F5C\u308B\u4E88\u5B9A\u306E\u3086\u308B\u3044\u6570\u5B66\u30B5\u30FC\u30AF\u30EB\u306E\u9700\u8981\u3042\u308A\u305D\u3046\u306A\u3093\u3060\u3051\u3069\u306A\u30FC\u3002\u4E0A\u624B\u306B\u5BA3\u4F1D\u3059\u308C\u3070\u4E00\u5B9A\u6570\u4EBA\u96C6\u307E\u308A\u305D\u3046\u3002",
  "id" : 96614958330155008,
  "created_at" : "2011-07-28 16:16:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 0, 10 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96612279059091456",
  "geo" : { },
  "id_str" : "96613743592615936",
  "in_reply_to_user_id" : 126326979,
  "text" : "@Keitaecon \u306A\u308B\u307B\u3069\u30FC\u3002\u6587\u5B66\u90E8\u3068\u7D4C\u6E08\u3067\u5358\u4F4D\u306E\u4E92\u63DB\u304C\u3042\u308B\u3089\u3057\u3044\u306E\u3067\u3061\u3087\u3063\u3068\u8208\u5473\u304C\u3042\u308B\u306E\u3067\u3059\u3002",
  "id" : 96613743592615936,
  "in_reply_to_status_id" : 96612279059091456,
  "created_at" : "2011-07-28 16:11:26 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96613222412591104",
  "text" : "\u7247\u601D\u3044\u30DE\u30FC\u30AF\u306E\u8AAD\u307F\u65B9\u3060\u308C\u304B\u304A\u3057\u3048\u3066\u307B\u3057\u3044\u2026",
  "id" : 96613222412591104,
  "created_at" : "2011-07-28 16:09:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96612397007126528",
  "text" : "\u3084\u308A\u305F\u3044\u3070\u304B\u308A\u304C\u5148\u884C\u3059\u308B\u3045",
  "id" : 96612397007126528,
  "created_at" : "2011-07-28 16:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96612330313494529",
  "text" : "\u30D9\u30AF\u30C8\u30EB\u89E3\u6790\u3082\u30FB\u30FB\u30FB\u3042\u30FC\u30AA\u30FC\u30D0\u30FC\u30EF\u30FC\u30AF\u3045",
  "id" : 96612330313494529,
  "created_at" : "2011-07-28 16:05:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96611248581517312",
  "text" : "\u5FAE\u7A4D\u30E9\u30C3\u30B7\u30E5\u3068\u306F\u805E\u304F\u304C\u2026\u3069\u3063\u3061\u304B\u3068\u8A00\u3048\u3070\u5FAE\u5206\u3060\u308D\u3046\u306A\u30FC \u3002\u8907\u7D20\u6570\u3068\u304B\u9593\u9055\u3063\u3066\u3082\u51FA\u3066\u6765\u306A\u3044\u3060\u308D\u3046\u306A\u30FC#math",
  "id" : 96611248581517312,
  "created_at" : "2011-07-28 16:01:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 26, 36 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96610947254333444",
  "text" : "\u7D4C\u6E08\u6570\u5B66\u3063\u3066\u5177\u4F53\u7684\u306B\u4F55\u3084\u3063\u3066\u308B\u3093\u3060\u308D\u30FB\u30FB\u30FB\u3002 RT @Keitaecon \u3088\u3057\u7D4C\u6E08\u6570\u5B66\u4E8C\u9031\u76EE\u7D42\u4E86\uFF0E",
  "id" : 96610947254333444,
  "created_at" : "2011-07-28 16:00:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96610482642890752",
  "text" : "\u4E88\u5099\u6821\u8B1B\u5E2B\u304C\u6570\u5B66\u8005\u306F\u7B97\u6570\u306F\u82E6\u624B\u3068\u8A00\u3063\u3066\u3044\u305F\u306E\u304C\u4ECA\u306B\u306A\u3063\u3066\u3088\u3046\u3084\u304F\u3075\u306B\u843D\u3061\u308B\u3088\u3046\u306B\u306A\u3063\u305F\u3002\u3067\u3082\u5F7C\u304C\u305D\u308C\u3092\u767A\u8A00\u3057\u305F\u30BF\u30A4\u30DF\u30F3\u30B0\u306F\u677F\u66F8\u306E\u8AA4\u308A\u3092\u6307\u6458\u3055\u308C\u305F\u6642\u3060\u3063\u305F\u306E\u304C\u4E0D\u5473\u304B\u3063\u305F\u3002\u3044\u3084\u3001\u6307\u6458\u3057\u305F\u306E\u4FFA\u306A\u3093\u3060\u3051\u3069\u3055\u3002 #math",
  "id" : 96610482642890752,
  "created_at" : "2011-07-28 15:58:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96609960225554432",
  "text" : "\u8A08\u7B97\u3068\u6570\u5B66\u3054\u3063\u3061\u3083\u306B\u3057\u3066\u308B\u4EBA\u591A\u3044\u3088\u306A\u30FC\u3002\u8A08\u7B97\u306F\u6570\u5B66\u306B\u3068\u3063\u3066\u5FC5\u8981\u3060\u3051\u3069\u5341\u5206\u3058\u3083\u306A\u3044\u3057\u3001\u6570\u5B66\u306E\u4E2D\u3067\u306F\u8A08\u7B97\u81EA\u4F53\u306F\u508D\u6D41\u306A\u304D\u3055\u3048\u3059\u308B\u3002 #math",
  "id" : 96609960225554432,
  "created_at" : "2011-07-28 15:56:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 3, 18 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96609621401288704",
  "text" : "RT @haruhalcyoncat: \u81EA\u5206\u6570\u5B66\u306F\u201C\u5ACC\u3044\u201D\u3067\u306F\u306A\u3044\u304C\u201C\u3067\u304D\u306A\u3044\u201D\u3002\u305D\u308C\u306F\u304D\u3063\u3068\u7A4D\u3082\u308A\u7A4D\u3082\u3063\u305F\u82E6\u624B\u610F\u8B58\u3067\u982D\u304C\u51DD\u308A\u56FA\u307E\u3063\u3066\u3044\u308B\u3053\u3068\u3068\u3001\u8AD6\u7406\u306E\u5B8C\u74A7\u6027\u306E\u8FFD\u6C42\u306B\u9014\u4E2D\u3067\u75B2\u308C\u3066\u3057\u307E\u3046\u3053\u3068\u3001\u305D\u3082\u305D\u3082\u8AD6\u7406\u306E\u5C55\u958B\u65B9\u6CD5\u304C\u8003\u3048\u3064\u304B\u306A\u3044\u3053\u3068\u304C\u7406\u7531\u3068\u8A00\u3048\u3070\u7406\u7531\u3001\u306A\u306E\u304B\u306A\u3002\u4ECA\u307E\u3067\u30B5\u30DC\u308A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96609128205656066",
    "text" : "\u81EA\u5206\u6570\u5B66\u306F\u201C\u5ACC\u3044\u201D\u3067\u306F\u306A\u3044\u304C\u201C\u3067\u304D\u306A\u3044\u201D\u3002\u305D\u308C\u306F\u304D\u3063\u3068\u7A4D\u3082\u308A\u7A4D\u3082\u3063\u305F\u82E6\u624B\u610F\u8B58\u3067\u982D\u304C\u51DD\u308A\u56FA\u307E\u3063\u3066\u3044\u308B\u3053\u3068\u3068\u3001\u8AD6\u7406\u306E\u5B8C\u74A7\u6027\u306E\u8FFD\u6C42\u306B\u9014\u4E2D\u3067\u75B2\u308C\u3066\u3057\u307E\u3046\u3053\u3068\u3001\u305D\u3082\u305D\u3082\u8AD6\u7406\u306E\u5C55\u958B\u65B9\u6CD5\u304C\u8003\u3048\u3064\u304B\u306A\u3044\u3053\u3068\u304C\u7406\u7531\u3068\u8A00\u3048\u3070\u7406\u7531\u3001\u306A\u306E\u304B\u306A\u3002\u4ECA\u307E\u3067\u30B5\u30DC\u308A\u904E\u304E\u305F\u305B\u3044\u304B\u3002\u3042\u3068\u7406\u7CFB\u3060\u3051\u3069\u8A08\u7B97\u306F\u5ACC\u3044\u3067\u3059\u3002",
    "id" : 96609128205656066,
    "created_at" : "2011-07-28 15:53:05 +0000",
    "user" : {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "protected" : false,
      "id_str" : "97121312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502815992611758081\/wOrq-PHB_normal.jpeg",
      "id" : 97121312,
      "verified" : false
    }
  },
  "id" : 96609621401288704,
  "created_at" : "2011-07-28 15:55:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thug thug",
      "screen_name" : "houbou",
      "indices" : [ 40, 47 ],
      "id_str" : "2934633845",
      "id" : 2934633845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96609486663454721",
  "text" : "\u305B\u3063\u304B\u304F\u3084\u308B\u3093\u3060\u3057\u697D\u3057\u3081\u3070\u3044\u3044\u306E\u306B\u306A\u3041\u2026\u3002\u5B9F\u969B\u62BC\u3057\u304D\u308C\u3066\u3057\u307E\u3046\u3051\u308C\u3069\u3002  RT @houbou \u6587\u7CFB\u6570\u5B66\u306F\u6697\u8A18\u3067\u62BC\u3057\u5207\u308C\u308B",
  "id" : 96609486663454721,
  "created_at" : "2011-07-28 15:54:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "indices" : [ 0, 10 ],
      "id_str" : "232545906",
      "id" : 232545906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96608790425772032",
  "geo" : { },
  "id_str" : "96609185428553728",
  "in_reply_to_user_id" : 232545906,
  "text" : "@math_neko \u7ACB\u3063\u3066\u308B\u571F\u4FF5\u304C\u3082\u3046\u9055\u3044\u307E\u3059\u3088\u306D\u3047\u2026\u4FFA\u3082\u597D\u304D\u306A\u306E\u3067\u7D9A\u3051\u307E\u3059\u3088\uFF01",
  "id" : 96609185428553728,
  "in_reply_to_status_id" : 96608790425772032,
  "created_at" : "2011-07-28 15:53:19 +0000",
  "in_reply_to_screen_name" : "math_neko",
  "in_reply_to_user_id_str" : "232545906",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96608930263863296",
  "text" : "\u5ACC\u3044\u3042\u308B\u3042\u308B\u3058\u3083\u306A\u304F\u3066\u597D\u304D\u3042\u308B\u3042\u308B\u3092\u898B\u305F\u65B9\u304C\u5E78\u305B\u306B\u306A\u308C\u308B\u3002\u9593\u9055\u3044\u306A\u3044\u3002",
  "id" : 96608930263863296,
  "created_at" : "2011-07-28 15:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30E0\u30D1\u30CD\u30EB\u30E9",
      "screen_name" : "kampa03",
      "indices" : [ 3, 11 ],
      "id_str" : "120029938",
      "id" : 120029938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6570\u5B66\u3042\u308B\u3042\u308B",
      "indices" : [ 45, 52 ]
    }, {
      "text" : "\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96608094955646977",
  "text" : "RT @kampa03: \u6570\u5B66\u306E\u554F\u984C\u3088\u308A\u3082\u6570\u5B66\u5ACC\u3044\u306E\u4EBA\u9593\u306E\u307B\u3046\u304C\u3088\u3063\u307D\u3069\u5049\u305D\u3046\u3060\u304B\u3089\u56F0\u308B #\u6570\u5B66\u3042\u308B\u3042\u308B #\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B #\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u6570\u5B66\u3042\u308B\u3042\u308B",
        "indices" : [ 32, 39 ]
      }, {
        "text" : "\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
        "indices" : [ 40, 49 ]
      }, {
        "text" : "\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
        "indices" : [ 50, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96604167510040576",
    "text" : "\u6570\u5B66\u306E\u554F\u984C\u3088\u308A\u3082\u6570\u5B66\u5ACC\u3044\u306E\u4EBA\u9593\u306E\u307B\u3046\u304C\u3088\u3063\u307D\u3069\u5049\u305D\u3046\u3060\u304B\u3089\u56F0\u308B #\u6570\u5B66\u3042\u308B\u3042\u308B #\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B #\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
    "id" : 96604167510040576,
    "created_at" : "2011-07-28 15:33:23 +0000",
    "user" : {
      "name" : "\u30AB\u30E0\u30D1\u30CD\u30EB\u30E9",
      "screen_name" : "kampa03",
      "protected" : false,
      "id_str" : "120029938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3148247328\/ee4c77f5612beeea60579b11145eec25_normal.jpeg",
      "id" : 120029938,
      "verified" : false
    }
  },
  "id" : 96608094955646977,
  "created_at" : "2011-07-28 15:48:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96607092554731522",
  "text" : "\u3053\u306E\u4EBA\u306E\u53E3\u306E\u304D\u304D\u65B9\u9762\u767D\u3044\u3067\u3059\u306D\uFF3E\uFF3E",
  "id" : 96607092554731522,
  "created_at" : "2011-07-28 15:45:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2020\u990C\u4E43\u9B3C\u4E43\u2020",
      "screen_name" : "nmrcapmw",
      "indices" : [ 3, 12 ],
      "id_str" : "587429690",
      "id" : 587429690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96607012074438656",
  "text" : "RT @nmrcapmw: \u8868\u305B\u3068\u304B\u8A08\u7B97\u305B\u3088\u3068\u304B\u547D\u4EE4\u6587\u3070\u3063\u304B\u3060\u306A\u3002\u53E3\u306E\u805E\u304D\u65B9\u304B\u3089\u51FA\u76F4\u305B\u3002\u6570\u5B66\u306E\u524D\u306B\u307E\u305A\u56FD\u8A9E\u3084\u3063\u3066\u3053\u3044\u3002 #\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96603700503642112",
    "text" : "\u8868\u305B\u3068\u304B\u8A08\u7B97\u305B\u3088\u3068\u304B\u547D\u4EE4\u6587\u3070\u3063\u304B\u3060\u306A\u3002\u53E3\u306E\u805E\u304D\u65B9\u304B\u3089\u51FA\u76F4\u305B\u3002\u6570\u5B66\u306E\u524D\u306B\u307E\u305A\u56FD\u8A9E\u3084\u3063\u3066\u3053\u3044\u3002 #\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B",
    "id" : 96603700503642112,
    "created_at" : "2011-07-28 15:31:31 +0000",
    "user" : {
      "name" : "\u3048\u306E\u304D\u306E\u3061\u3083\u3093",
      "screen_name" : "enokitty_",
      "protected" : false,
      "id_str" : "129492272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2243847794\/piMZD_normal.png",
      "id" : 129492272,
      "verified" : false
    }
  },
  "id" : 96607012074438656,
  "created_at" : "2011-07-28 15:44:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96599738232737792",
  "text" : "\u306A\u3093\u304B\u672C\u5BB6TL\u306E\u53D6\u5F97\u304C\u758E\u3089\u3060\u306A\u30FC",
  "id" : 96599738232737792,
  "created_at" : "2011-07-28 15:15:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96598693112856576",
  "text" : "\u4ED6\u8005\u7D39\u4ECB\u3055\u308C\u3066\u307F\u305F\u3044\u3051\u3069\u3057\u305F\u304F\u306F\u306A\u3044\u2190",
  "id" : 96598693112856576,
  "created_at" : "2011-07-28 15:11:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3060\u3058\u3047\u301C\u63D0\u7763(\u5815\u843D\u3061\u3045\uFF01)",
      "screen_name" : "takosudajye",
      "indices" : [ 3, 15 ],
      "id_str" : "263568314",
      "id" : 263568314
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96596576990003201",
  "text" : "RT @takosudajye: \u3068\u308A\u3042\u3048\u305A128\u3001256\u3001273\u3001512\u30011024\u3001125\u3001144\u3001121\u3001216\u306A\u3069\u3092\u898B\u308B\u3068\u3061\u3087\u3046\u3069\u826F\u3044\u6570\u5B57\u3060\u3068\u8A8D\u8B58\u3059\u308B\u3000#\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
        "indices" : [ 62, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96594978494615552",
    "text" : "\u3068\u308A\u3042\u3048\u305A128\u3001256\u3001273\u3001512\u30011024\u3001125\u3001144\u3001121\u3001216\u306A\u3069\u3092\u898B\u308B\u3068\u3061\u3087\u3046\u3069\u826F\u3044\u6570\u5B57\u3060\u3068\u8A8D\u8B58\u3059\u308B\u3000#\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
    "id" : 96594978494615552,
    "created_at" : "2011-07-28 14:56:52 +0000",
    "user" : {
      "name" : "\u3060\u3058\u3047\u301C\u63D0\u7763(\u5815\u843D\u3061\u3045\uFF01)",
      "screen_name" : "takosudajye",
      "protected" : false,
      "id_str" : "263568314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2517011606\/k2kgf95ch8w67tv3idg3_normal.jpeg",
      "id" : 263568314,
      "verified" : false
    }
  },
  "id" : 96596576990003201,
  "created_at" : "2011-07-28 15:03:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96595478807977986",
  "text" : "\u3075\u3041\u307C\u306E\u57FA\u6E96\u304C\u5206\u304B\u3089\u3093\u3002\u7686\u304C\u3075\u3041\u307C\u308B\u3088\u3046\u306A\u306E\u3092RT\u3057\u3066\u308B\u6C17\u304C\u3059\u308B\u3002",
  "id" : 96595478807977986,
  "created_at" : "2011-07-28 14:58:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 24, 34 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96595057326563328",
  "text" : "\u3042\u308A\u904E\u304E\u3066\u56F0\u308B\u3002\u305D\u3057\u3066\u6587\u5B66\u90E8\u3067\u306A\u304A\u56F0\u308B\u3002 RT @blackVELU \u6570\u5B66\u306E\u8A66\u9A13\u306E\u5F8C\u306B\u6570\u5B66\u304C\u3084\u308A\u305F\u304F\u306A\u3063\u305F #\u6570\u5B66\u597D\u304D\u3042\u308B\u3042\u308B",
  "id" : 96595057326563328,
  "created_at" : "2011-07-28 14:57:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96594699552440320",
  "text" : "\u3042\u30FC\u6570\u5B66\u5ACC\u3044\u3042\u308B\u3042\u308B\u8AAD\u3093\u3067\u305F\u3089\u8179\u7ACB\u3063\u3066\u304D\u305F\u3002\u5B66\u554F\u306B\u8208\u5473\u306A\u3044\u306E\u306F\u7B11\u3063\u3066\u8A31\u305B\u308B\u304C\u7121\u7406\u89E3\u306F\u2026",
  "id" : 96594699552440320,
  "created_at" : "2011-07-28 14:55:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96581753082347520",
  "text" : "\u4E00\u65E5\u8010\u4E45\u5C71\u624B\u7DDA\u6570\u5B66\u6F14\u7FD2\u3068\u304B\u6848\u5916\u306F\u304B\u3069\u308B\u3093\u3058\u3083\u306A\u304B\u308D\u3046\u304B\u3002\u9154\u308F\u306A\u3051\u308C\u3070\u3002 #math",
  "id" : 96581753082347520,
  "created_at" : "2011-07-28 14:04:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96581593803669504",
  "text" : "@np2i \u6D6A\u4EBA\u6642\u4EE3\u306B\u9589\u9928\u9593\u969B\u307E\u3067\u89E3\u3051\u306A\u304B\u3063\u305F\u554F\u984C\u304C\u5E30\u308A\u306E\u96FB\u8ECA\u3067\uFF15\uFF43\uFF4D\u56DB\u65B9\u304F\u3089\u3044\u306E\u30E1\u30E2\u5E33\u3067\u8003\u3048\u3066\u305F\u3089\u3042\u3063\u3055\u308A\u89E3\u3051\u305F\u3002\u3068\u304B\u306A\u3089\u3042\u308B\u3042\u308B\u306A\u306E\u3067\u3059\u304C\uFF0D\u3002",
  "id" : 96581593803669504,
  "created_at" : "2011-07-28 14:03:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96576802465644544",
  "text" : "\u3053\u3046\u3057\u3066\u3044\u308D\u3093\u306A\u4EBA\u3092\u975E\u516C\u5F0FRT\u3084\u3089RT\u3057\u3066\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3082\u3089\u3063\u3066\u30D5\u30A9\u30ED\u30FC\u3092\u8FD4\u3059\u3053\u3068\u3067\u81EA\u7136\u3068\u3055\u307E\u3056\u307E\u306A\u30EA\u30B9\u30C8\u306B\u5165\u308C\u3066\u3082\u3089\u3046\u4F5C\u6226\u3002",
  "id" : 96576802465644544,
  "created_at" : "2011-07-28 13:44:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 37, 45 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96573225307340800",
  "text" : "\u308F\u304B\u308A\u307E\u3059\uFF01\u5468\u308A\u306B\u898B\u3066\u308B\u4EBA\u304C\u3044\u306A\u3044\u304B\u3089\u81EA\u5206\u3060\u3051\u304B\u3068\u601D\u3063\u3066\u307E\u3057\u305F\u30FC\u3002 RT @i_horse \u30D5\u30E9\u30AF\u30BF\u30EB\u306F\uFF11\uFF11\u8A71\u306E\u633F\u5165\u6B4C\u304C\u6D41\u308C\u308B\u3068\u3053\u308D\u304C\u597D\u304D\uFF01",
  "id" : 96573225307340800,
  "created_at" : "2011-07-28 13:30:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96570856658055168",
  "text" : "\u5B66\u90E8\u3068\u95A2\u4FC2\u306E\u306A\u3044\u3084\u308A\u305F\u3044\u3053\u3068\u304C\u591A\u3059\u304E\u308B\u3088\u306A\u30FC\u3001\u96C6\u5408\u3068\u4F4D\u76F8\u3082\u5358\u4F4D\u3068\u308C\u305F\u304B\u306F\u3072\u3068\u307E\u305A\u304A\u304F\u306B\u3057\u3066\u3082\u5B8C\u74A7\u3058\u3083\u306A\u3044\u3082\u3093\u306A\u3041\u3002 #math",
  "id" : 96570856658055168,
  "created_at" : "2011-07-28 13:21:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96569727543029760",
  "text" : "\u6570\u5B66\u30EA\u30B9\u30C8\u306E\u8A71\u984C\u304C\u6570\u5B66\u57FA\u790E\u8AD6\u306B\u306A\u3063\u3066\u308B\u304C\u3001\u306E\u305E\u3044\u3066\u307F\u3066\u3082\u3044\u3044\u304B\u3082\u306A\u30FC\u3002\u3067\u3082\u7A4D\u8AAD\u306B\u306A\u308B\u3088\u306A\u3002\u5FAE\u7A4D\u3068\u7DDA\u5F62\u3092\u4E26\u884C\u3057\u3066\u95A2\u6570\u8AD6\u3084\u308A\u306A\u304C\u3089\u7D71\u8A08\u3001\u3068\u601D\u3063\u3066\u308B\u3051\u3069\u305D\u308C\u3060\u3051\u3067\u30AA\u30FC\u30D0\u30FC\u30EF\u30FC\u30AF\u3060\u3088\u306A\u30FC\u3002",
  "id" : 96569727543029760,
  "created_at" : "2011-07-28 13:16:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96568354466312192",
  "text" : "3000\u5186\u3067\u30EC\u30DD\u30FC\u30C8\u6253\u3063\u3066\u5FAE\u7A4D\u306E\u6F14\u7FD2\u672C\u8CB7\u3063\u305F\u3063\u305F\uFF01\u590F\u4F11\u307F\u306B\u5FAE\u7A4D\u3092\uFF01#math",
  "id" : 96568354466312192,
  "created_at" : "2011-07-28 13:11:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30FC\u30B8",
      "screen_name" : "Kiriyama_George",
      "indices" : [ 3, 19 ],
      "id_str" : "130188593",
      "id" : 130188593
    }, {
      "name" : "(V)\u30FB\u2200\u30FB(V)\u304B\u306B\u3071\u3093\u3002\uFF20\u3064\u304F\u3070",
      "screen_name" : "kanipan666",
      "indices" : [ 36, 47 ],
      "id_str" : "156955966",
      "id" : 156955966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/pakEK6Q",
      "expanded_url" : "http:\/\/blog.livedoor.jp\/ko_jo\/archives\/51479435.html",
      "display_url" : "blog.livedoor.jp\/ko_jo\/archives\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96567893713625088",
  "text" : "RT @Kiriyama_George: \u5C3B\u306B\u7A81\u3063\u8FBC\u3081\u3070\u3044\u3044\u304B\u3068 RT @kanipan666: \u3069\u3053\u304B\u3089\u7A81\u3063\u8FBC\u3081\u3070\u2026\u2026\u3010\u4E2D\u56FD\u3011\u5973\u88C5\u597D\u304D\u306E\u5C11\u5E74\u304C\u7537\u6027\u3092\u9A19\u3057\u7D50\u5A5A \u2192\u521D\u591C\u306B\u65B0\u90CE\u306E\u53D4\u7236\u306B\u4E71\u66B4\u3055\u308C\u6027\u5225\u304C\u767A\u899A http:\/\/t.co\/pakEK6Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(V)\u30FB\u2200\u30FB(V)\u304B\u306B\u3071\u3093\u3002\uFF20\u3064\u304F\u3070",
        "screen_name" : "kanipan666",
        "indices" : [ 15, 26 ],
        "id_str" : "156955966",
        "id" : 156955966
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 98 ],
        "url" : "http:\/\/t.co\/pakEK6Q",
        "expanded_url" : "http:\/\/blog.livedoor.jp\/ko_jo\/archives\/51479435.html",
        "display_url" : "blog.livedoor.jp\/ko_jo\/archives\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "96566867874955264",
    "text" : "\u5C3B\u306B\u7A81\u3063\u8FBC\u3081\u3070\u3044\u3044\u304B\u3068 RT @kanipan666: \u3069\u3053\u304B\u3089\u7A81\u3063\u8FBC\u3081\u3070\u2026\u2026\u3010\u4E2D\u56FD\u3011\u5973\u88C5\u597D\u304D\u306E\u5C11\u5E74\u304C\u7537\u6027\u3092\u9A19\u3057\u7D50\u5A5A \u2192\u521D\u591C\u306B\u65B0\u90CE\u306E\u53D4\u7236\u306B\u4E71\u66B4\u3055\u308C\u6027\u5225\u304C\u767A\u899A http:\/\/t.co\/pakEK6Q",
    "id" : 96566867874955264,
    "created_at" : "2011-07-28 13:05:10 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30FC\u30B8",
      "screen_name" : "Kiriyama_George",
      "protected" : false,
      "id_str" : "130188593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1698591176\/image_normal",
      "id" : 130188593,
      "verified" : false
    }
  },
  "id" : 96567893713625088,
  "created_at" : "2011-07-28 13:09:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96564951728136193",
  "text" : "RT @_flyingmoomin: \u300C\u305B\u3063\u304B\u304F\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u306B\u6765\u3066\u308B\u3093\u3060\u3057\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u98DF\u3079\u3088\u3046\u305C\uFF01\u300D\u3063\u3066\u5148\u8F29\u304C\u8A00\u3044\u51FA\u3057\u3066, \u5730\u5143\u306E\u4EBA\u306B\u300C\u3059\u307F\u307E\u305B\u3093\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u3063\u3066\u3069\u3053\u3067\u3059\u304B\uFF1F\u300D\u3063\u3066\u805E\u3044\u3066\u300C\u3053\u3053\u3060\u3088\u300D\u3063\u3066\u602A\u8A1D\u306A\u9854\u3055\u308C\u3066\u308B... \u5E30\u308A\u305F\u3044...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96564787890233344",
    "text" : "\u300C\u305B\u3063\u304B\u304F\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u306B\u6765\u3066\u308B\u3093\u3060\u3057\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u98DF\u3079\u3088\u3046\u305C\uFF01\u300D\u3063\u3066\u5148\u8F29\u304C\u8A00\u3044\u51FA\u3057\u3066, \u5730\u5143\u306E\u4EBA\u306B\u300C\u3059\u307F\u307E\u305B\u3093\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u3063\u3066\u3069\u3053\u3067\u3059\u304B\uFF1F\u300D\u3063\u3066\u805E\u3044\u3066\u300C\u3053\u3053\u3060\u3088\u300D\u3063\u3066\u602A\u8A1D\u306A\u9854\u3055\u308C\u3066\u308B... \u5E30\u308A\u305F\u3044...",
    "id" : 96564787890233344,
    "created_at" : "2011-07-28 12:56:54 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 96564951728136193,
  "created_at" : "2011-07-28 12:57:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96562048640626688",
  "text" : "RT\u591A\u304F\u3066\u7533\u3057\u8A33\u306A\u3044\u30FB\u30FB\u30FB\u3002\u3067\u3082\u304A\u3082\u3057\u308D\u3044\u3093\u3060\u3082\u3093\u3002",
  "id" : 96562048640626688,
  "created_at" : "2011-07-28 12:46:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96561318299058176",
  "text" : "RT @_flyingmoomin: \u301C\u4E16\u754C\u306E\u5E7C\u5973\u304B\u3089\u301C\u3000\u4ECA\u65E5\u306F\u30E8\u30FC\u30ED\u30C3\u30D1\u6709\u6570\u306E\u91D1\u878D\u90FD\u5E02\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u306B\u6765\u3066\u3044\u307E\u3059. \u5348\u524D11\u6642 \u5217\u8ECA\u306F\u897F\u30C9\u30A4\u30C4\u306B\u5230\u7740\u3057\u307E\u3057\u305F. \u53E4\u304F\u306F\u30ED\u30FC\u30DE\u5E1D\u56FD\u306E\u90FD\u5E02\u3068\u3057\u3066\u767A\u5C55\u3057\u3066\u304D\u305F\u3053\u306E\u8857\u306F, \u30B2\u30FC\u30C6\u3092\u751F\u3093\u3060\u3053\u3068\u3067\u3082\u6709\u540D\u3067, \u3053\u306E\u8857\u306E\u5E7C\u5973\u306F\u4E16\u754C\u907A\u7523\u306B\u767B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96560936336359424",
    "text" : "\u301C\u4E16\u754C\u306E\u5E7C\u5973\u304B\u3089\u301C\u3000\u4ECA\u65E5\u306F\u30E8\u30FC\u30ED\u30C3\u30D1\u6709\u6570\u306E\u91D1\u878D\u90FD\u5E02\u30D5\u30E9\u30F3\u30AF\u30D5\u30EB\u30C8\u306B\u6765\u3066\u3044\u307E\u3059. \u5348\u524D11\u6642 \u5217\u8ECA\u306F\u897F\u30C9\u30A4\u30C4\u306B\u5230\u7740\u3057\u307E\u3057\u305F. \u53E4\u304F\u306F\u30ED\u30FC\u30DE\u5E1D\u56FD\u306E\u90FD\u5E02\u3068\u3057\u3066\u767A\u5C55\u3057\u3066\u304D\u305F\u3053\u306E\u8857\u306F, \u30B2\u30FC\u30C6\u3092\u751F\u3093\u3060\u3053\u3068\u3067\u3082\u6709\u540D\u3067, \u3053\u306E\u8857\u306E\u5E7C\u5973\u306F\u4E16\u754C\u907A\u7523\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059. \u898B\u6240\u306E\u3072\u3068\u3064\u306F\u9752\u3044\u77B3\u3068\u9577\u3044\u811A",
    "id" : 96560936336359424,
    "created_at" : "2011-07-28 12:41:35 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 96561318299058176,
  "created_at" : "2011-07-28 12:43:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    }, {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 22, 31 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96560736645554176",
  "text" : "RT @dovanyahn: \u6B4C\u3048\u3088 RT @kuttinpa: \u96A3\u4EBA\u304C\u5973\u306E\u5B50\u3092\u90E8\u5C4B\u306B\u9023\u308C\u8FBC\u3093\u3060\u306E\u3092\u307F\u305F\u306E\u3067\u3001\u3060\u308C\u304B\u30D6\u30D6\u30BC\u30E9\u304B\u30C8\u30E9\u30F3\u30DA\u30C3\u30C8\u3092\u8CB8\u3057\u3066\u304F\u308C\u307E\u305B\u3093\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u304F\u3063\u3061\u3093\u3071",
        "screen_name" : "kuttinpa",
        "indices" : [ 7, 16 ],
        "id_str" : "102399578",
        "id" : 102399578
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96560500531400704",
    "text" : "\u6B4C\u3048\u3088 RT @kuttinpa: \u96A3\u4EBA\u304C\u5973\u306E\u5B50\u3092\u90E8\u5C4B\u306B\u9023\u308C\u8FBC\u3093\u3060\u306E\u3092\u307F\u305F\u306E\u3067\u3001\u3060\u308C\u304B\u30D6\u30D6\u30BC\u30E9\u304B\u30C8\u30E9\u30F3\u30DA\u30C3\u30C8\u3092\u8CB8\u3057\u3066\u304F\u308C\u307E\u305B\u3093\u304B",
    "id" : 96560500531400704,
    "created_at" : "2011-07-28 12:39:51 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 96560736645554176,
  "created_at" : "2011-07-28 12:40:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96550525012672513",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 96550525012672513,
  "created_at" : "2011-07-28 12:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96547302973517824",
  "text" : "\u8FD1\u85E4\u3055\u3093\u307E\u3055\u304B\u306E\u3063\u3066\u304F\u308B\u3068\u306F\u601D\u308F\u306A\u304B\u3063\u305F\u3044\u304C\u3044\u3067\u3059\u3002",
  "id" : 96547302973517824,
  "created_at" : "2011-07-28 11:47:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96545425288478720",
  "text" : "\u3055\u3093\u307E\u306E\u523A\u8EAB\u3092\u4E00\u679A\u3001\u4E8C\u679A\u3001\u4E09\u679A\u2190",
  "id" : 96545425288478720,
  "created_at" : "2011-07-28 11:39:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96544912086020097",
  "text" : "\u306F\u3082\u306F\u3082\u3046\u3044\u3044\u3084\u3002",
  "id" : 96544912086020097,
  "created_at" : "2011-07-28 11:37:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96544461173166080",
  "text" : "\u3044\u3055\u304E\u306E\u3088\u3044\u3001\u3044\u3055\u304D",
  "id" : 96544461173166080,
  "created_at" : "2011-07-28 11:36:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96543807734153216",
  "text" : "\u9593\u9AEA\u5165\u308C\u305A\u306B\u30AB\u30F3\u30D1\u30C1\uFF01",
  "id" : 96543807734153216,
  "created_at" : "2011-07-28 11:33:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30DB\u30EB\u30F3\u3042\u308B\u3042\u308B",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96254210768777217",
  "text" : "\u4E3B\u65CB\u5F8B\u306F\u304A\u308D\u304B\u76EE\u7ACB\u3063\u305F\u526F\u65CB\u5F8B\u3082\u306A\u304F\u88CF\u6253\u3061\u3084\u523B\u307F\u3067\u4E00\u66F2\u3092\u7D42\u3048\u308B\u3002#\u30DB\u30EB\u30F3\u3042\u308B\u3042\u308B",
  "id" : 96254210768777217,
  "created_at" : "2011-07-27 16:22:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30DB\u30EB\u30F3\u3042\u308B\u3042\u308B",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96253656130793472",
  "text" : "\u3050\u308B\u3050\u308B\u5DFB\u304D\u306E\u30AB\u30BF\u30C4\u30E0\u30EA\u307F\u305F\u3044\u306A\u306E\uFF01\u3063\u3066\u8AAC\u660E\u3059\u308B\u3068\u30C1\u30E5\u30FC\u30D0\u304B\u30E6\u30FC\u30D5\u30A9\u3068\u9593\u9055\u308F\u308C\u308B #\u30DB\u30EB\u30F3\u3042\u308B\u3042\u308B",
  "id" : 96253656130793472,
  "created_at" : "2011-07-27 16:20:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 3, 15 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96243686609911808",
  "text" : "RT @modestrella: \u304A\u8179\u75DB\u3044\u3002(\u3082\u305A\u304F\u3058\u3083\u306A\u3044\u3001\u3082\u305A\u304F\u3058\u3083\u306A\u3044\u3088\uFF01)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96243461837176832",
    "text" : "\u304A\u8179\u75DB\u3044\u3002(\u3082\u305A\u304F\u3058\u3083\u306A\u3044\u3001\u3082\u305A\u304F\u3058\u3083\u306A\u3044\u3088\uFF01)",
    "id" : 96243461837176832,
    "created_at" : "2011-07-27 15:40:04 +0000",
    "user" : {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "protected" : false,
      "id_str" : "146090085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413056775756083200\/AuY1KCKa_normal.jpeg",
      "id" : 146090085,
      "verified" : false
    }
  },
  "id" : 96243686609911808,
  "created_at" : "2011-07-27 15:40:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 3, 15 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96243668683468800",
  "text" : "RT @modestrella: \u8CDE\u5473\u671F\u96505\/7\u306E\u751F\u3082\u305A\u304F\u3001\u3044\u3051\u308B\u304B\u306A\u3042\uFF1F\u5473\u7684\u306B\u306F\u652F\u969C\u306A\u3055\u305D\u3046\u306A\u3093\u3060\u3051\u3069\u3002\u3061\u3087\u3063\u3068\u3060\u3051\u52C7\u6C17\u304C\u5FC5\u8981\u306A\u4E00\u54C1\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96234174381432832",
    "text" : "\u8CDE\u5473\u671F\u96505\/7\u306E\u751F\u3082\u305A\u304F\u3001\u3044\u3051\u308B\u304B\u306A\u3042\uFF1F\u5473\u7684\u306B\u306F\u652F\u969C\u306A\u3055\u305D\u3046\u306A\u3093\u3060\u3051\u3069\u3002\u3061\u3087\u3063\u3068\u3060\u3051\u52C7\u6C17\u304C\u5FC5\u8981\u306A\u4E00\u54C1\u3002",
    "id" : 96234174381432832,
    "created_at" : "2011-07-27 15:03:09 +0000",
    "user" : {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "protected" : false,
      "id_str" : "146090085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413056775756083200\/AuY1KCKa_normal.jpeg",
      "id" : 146090085,
      "verified" : false
    }
  },
  "id" : 96243668683468800,
  "created_at" : "2011-07-27 15:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96243565667160067",
  "text" : "\u306B\u305B\u307B\u306F\u4F55\u3067\u3082\u77E5\u3063\u3066\u308B\u306A\u3041",
  "id" : 96243565667160067,
  "created_at" : "2011-07-27 15:40:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 3, 14 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7530\u820E\u3042\u308B\u3042\u308B",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96243480904470528",
  "text" : "RT @nisehorrrn: \u3044\u307E\u3060\u306B\u73FE\u5F79\u306E\u30EB\u30FC\u30BA\u30BD\u30C3\u30AF\u30B9 #\u7530\u820E\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u7530\u820E\u3042\u308B\u3042\u308B",
        "indices" : [ 15, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96242828316901377",
    "text" : "\u3044\u307E\u3060\u306B\u73FE\u5F79\u306E\u30EB\u30FC\u30BA\u30BD\u30C3\u30AF\u30B9 #\u7530\u820E\u3042\u308B\u3042\u308B",
    "id" : 96242828316901377,
    "created_at" : "2011-07-27 15:37:33 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "protected" : false,
      "id_str" : "229752118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009819094\/110325_010601a_normal.jpg",
      "id" : 229752118,
      "verified" : false
    }
  },
  "id" : 96243480904470528,
  "created_at" : "2011-07-27 15:40:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 23, 32 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 54, 64 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 89, 98 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 100, 110 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96242105550258176",
  "text" : "\u4F59\u308A\u3063\u3066\u5358\u8A9E\u304C\u51FA\u3066\u3053\u306A\u3044\u304B\u30D2\u30E4\u30D2\u30E4\u3057\u305F RT @akeopyaa: \u5B66\u90E8\u306E\u53CB\u4EBA\u3060\u3063\u305F\u3089\uFF13\u3067\u5272\u308B\u3060\u3051\u3002 RT @end313124: \u53CB\u4EBA\u3067\u306A\u304F\u77E5\u4EBA\u3068\u66F8\u304F\u6240\u306B\u5207\u306A\u3055\u3092\u611F\u3058\u305F\u3002RT @akeopyaa: @end313124 \u4FFA\u6388\u696D\u62C5\u5F53\u6559\u5B98\u306E\u540D\u524D\u3001\u5B66\u90E8\u306E\u77E5\u4EBA\u306E\u540D\u524D\u306E\u6570\u500D\u77E5\u3063\u3066\u308B\u308F\u3002",
  "id" : 96242105550258176,
  "created_at" : "2011-07-27 15:34:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96241896711663616",
  "text" : "\u3042\u308B\u3042\u308B\u3002\u52C9\u5F37\u4E0D\u8DB3\u304C\u539F\u56E0\u3060\u3068\u601D\u3046\u3051\u3069\u3002",
  "id" : 96241896711663616,
  "created_at" : "2011-07-27 15:33:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307D\u307D",
      "screen_name" : "_popopopoon_",
      "indices" : [ 3, 16 ],
      "id_str" : "154165877",
      "id" : 154165877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96241771218079745",
  "text" : "RT @_popopopoon_: \u30BB\u30B0\u30E1\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u3063\u3066\u4F55\u3060\u3088(\u30D0\u30F3\u30D0\u30F3 \u306E\u30EC\u30D9\u30EB\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96241577642561536",
    "text" : "\u30BB\u30B0\u30E1\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u3063\u3066\u4F55\u3060\u3088(\u30D0\u30F3\u30D0\u30F3 \u306E\u30EC\u30D9\u30EB\u3002",
    "id" : 96241577642561536,
    "created_at" : "2011-07-27 15:32:34 +0000",
    "user" : {
      "name" : "\u307D\u307D",
      "screen_name" : "_popopopoon_",
      "protected" : false,
      "id_str" : "154165877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421655774574559232\/hT6bsWU5_normal.jpeg",
      "id" : 154165877,
      "verified" : false
    }
  },
  "id" : 96241771218079745,
  "created_at" : "2011-07-27 15:33:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307D\u307D",
      "screen_name" : "_popopopoon_",
      "indices" : [ 3, 16 ],
      "id_str" : "154165877",
      "id" : 154165877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96241749734862848",
  "text" : "RT @_popopopoon_: \u30BB\u30B0\u30E1\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u3068\u304B\u3001\u30DD\u30A4\u30F3\u30BF\u306E\u4F7F\u3044\u65B9\u9593\u9055\u3063\u3066\u3001\u300C\u30BB\u30B0\u30E1\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u9055\u53CD\u3067\u3059\u300D\u3063\u3066\u3068\u304D\u3057\u304B\u898B\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96241498605092864",
    "text" : "\u30BB\u30B0\u30E1\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u3068\u304B\u3001\u30DD\u30A4\u30F3\u30BF\u306E\u4F7F\u3044\u65B9\u9593\u9055\u3063\u3066\u3001\u300C\u30BB\u30B0\u30E1\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u9055\u53CD\u3067\u3059\u300D\u3063\u3066\u3068\u304D\u3057\u304B\u898B\u306A\u3044\u3002",
    "id" : 96241498605092864,
    "created_at" : "2011-07-27 15:32:16 +0000",
    "user" : {
      "name" : "\u307D\u307D",
      "screen_name" : "_popopopoon_",
      "protected" : false,
      "id_str" : "154165877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421655774574559232\/hT6bsWU5_normal.jpeg",
      "id" : 154165877,
      "verified" : false
    }
  },
  "id" : 96241749734862848,
  "created_at" : "2011-07-27 15:33:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 23, 32 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 34, 44 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96240979614515200",
  "text" : "\u53CB\u4EBA\u3067\u306A\u304F\u77E5\u4EBA\u3068\u66F8\u304F\u6240\u306B\u5207\u306A\u3055\u3092\u611F\u3058\u305F\u3002RT @akeopyaa: @end313124 \u4FFA\u6388\u696D\u62C5\u5F53\u6559\u5B98\u306E\u540D\u524D\u3001\u5B66\u90E8\u306E\u77E5\u4EBA\u306E\u540D\u524D\u306E\u6570\u500D\u77E5\u3063\u3066\u308B\u308F\u3002",
  "id" : 96240979614515200,
  "created_at" : "2011-07-27 15:30:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96240711556534272",
  "text" : "\u96C6\u5408\u4F4D\u76F8\u306E\u8A66\u9A13\u306E\u524D\u306B\u300C\u307E\u3069\u304B\u3063\u3066\u30E9\u30C3\u30BB\u30EB\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9\u8D77\u3053\u3057\u3066\u308B\u3088\u306A\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u898B\u77E5\u3089\u306C\u7406\u5B66\u90E8\u751F\uFF08\u63A8\u5B9A\uFF09\u306F\u5927\u4E08\u592B\u3060\u3063\u305F\u306E\u3060\u308D\u3046\u304B\u3002\u81EA\u5206\u3082\u51FA\u6765\u3082\u3042\u3084\u3057\u3044\u3093\u3060\u3051\u3069\u3055\u3002",
  "id" : 96240711556534272,
  "created_at" : "2011-07-27 15:29:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96240046386061313",
  "text" : "\u6587\u7CFB\u306E\u306F\u305A\u306E\u5143\u30AF\u30E9\u30B9\u30E1\u30A4\u30C8\u3082\u7D71\u8A08\u306E\u8A71\u3057\u3066\u305F\u3057\u306A\u30FC\u3002\u7A4D\u5206\u3068\u304B\u6975\u9650\u306A\u3057\u3067\u5B66\u3079\u308B\u3082\u3093\u306A\u306E\u304B\u306A\u2026\uFF1F",
  "id" : 96240046386061313,
  "created_at" : "2011-07-27 15:26:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96239824951971841",
  "text" : "KU\u30EA\u30B9\u30C8\u773A\u3081\u3066\u308B\u3068\u7D71\u8A08\u306E\u8A71\u984C\u591A\u3044\u3088\u306A\u30FC\u3002\u4EBA\u304C\u504F\u3063\u3066\u3093\u306E\u304B\u3001\u305D\u308C\u3068\u3082\u7D71\u8A08\u304C\u5E83\u304F\u52C9\u5F37\u3055\u308C\u3066\u3044\u308B\u306E\u304B\u3001\u691C\u5B9A\u3057\u3066\u307F\u3088\u3046\u304B\u306A\u2190",
  "id" : 96239824951971841,
  "created_at" : "2011-07-27 15:25:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96239547863666688",
  "text" : "\u6559\u6388\u306E\u540D\u524D\u3068\u304B\u8208\u5473\u306A\u3044\u3067\u3059\u3057\u2190\n\u305D\u308C\u3067\u3082\u4E00\u65B9\u7684\u306B\u597D\u304D\u306A\u6559\u6388\u306F\u7D50\u69CB\u899A\u3048\u3066\u308B\u3051\u3069\u3055\u3002",
  "id" : 96239547863666688,
  "created_at" : "2011-07-27 15:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 17, 24 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96239319559311361",
  "text" : "\u307B\u307C\u6BCE\u56DE\u308F\u304B\u3089\u306A\u304F\u3066\u767D\u7D19\u2026 RT @rpdexp: \u300C\u62C5\u5F53\u6559\u54E1\u540D\u306B\u81EA\u5206\u306E\u540D\u524D\u3092\u66F8\u304D\u307E\u3057\u305F\u304C\u81EA\u7FD2\u3057\u305F\u306E\u3067\u9593\u9055\u3063\u3066\u3044\u307E\u305B\u3093\u300D\u3063\u3066\u3044\u3046\u4EBA\u3044\u307E\u305B\u3093\u304B\u3002",
  "id" : 96239319559311361,
  "created_at" : "2011-07-27 15:23:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96239087769501698",
  "text" : "\u4E0D\u899A\u3063\u2026\u6DF1\u304F\u53CD\u7701\u3002",
  "id" : 96239087769501698,
  "created_at" : "2011-07-27 15:22:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96238757468045313",
  "text" : "@np2i \u304A\u3084\u3059\u307F\u30A1\uFF01",
  "id" : 96238757468045313,
  "created_at" : "2011-07-27 15:21:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96236604573761536",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u81EA\u5DF1\u7D39\u4ECB\u6587\u3092\u66F8\u304D\u63DB\u3048\u3088\u3046\u3002",
  "id" : 96236604573761536,
  "created_at" : "2011-07-27 15:12:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96236518737330176",
  "text" : "\u306A\u3093\u304B\u3082\u3046\u3053\u3063\u3061\u304C\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u306A\u304F\u3066\u3082\u30EA\u30B9\u30C8\u3067\u898B\u304B\u3051\u3066\u9762\u767D\u3044\u3068\u601D\u3063\u305F\u30C4\u30A4\u30FC\u30C8\u306FRT\u3057\u3061\u3083\u3063\u3066\u3093\u3060\u3057\u30EA\u30D7\u30E9\u30A4\u3068\u304B\u975E\u516C\u5F0FRT\u98DB\u3070\u3057\u3066\u3082\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u3068\u601D\u3044\u59CB\u3081\u305F\u3002\u9B31\u9676\u3057\u304B\u3063\u305F\u3089\u30D6\u30ED\u30C3\u30AF\u3057\u308D\u3063\u3066\u3044\u3046\u5F37\u6C17\u306A\u59FF\u52E2\u2026\u306F\u81EA\u5206\u52DD\u624B\u304B\u306A\u3001\u3068\u601D\u3046\u5F31\u6C17\u306A\u59FF\u52E2\u3002",
  "id" : 96236518737330176,
  "created_at" : "2011-07-27 15:12:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96232248663216128",
  "text" : "KU\u30EA\u30B9\u30C8\u306B\u53C2\u52A0\u3057\u305F\u3044\u3068\u601D\u3046\u4E00\u65B9\u30DE\u30B8\u30AD\u30C1\u306E\u6CE2\u306B\u3064\u3044\u3066\u3044\u3051\u306A\u3044\u3069\u3053\u308D\u304B\u8FEB\u5BB3\u3092\u53D7\u3051\u305D\u3046\u3060\u3057\u30B5\u30D6\u57A2\u3067\u3082\u3068\u308D\u3046\u304B\u306A\u2190",
  "id" : 96232248663216128,
  "created_at" : "2011-07-27 14:55:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96229407563325440",
  "geo" : { },
  "id_str" : "96230361759096832",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u6587\u91CE\u3055\u3093\u3082\u5DFB\u304D\u8FBC\u3093\u3067\u9694\u9031\u51FA\u5E2D\u306B\u3057\u3061\u307E\u3044\u307E\u3057\u3087\u3046\u2190",
  "id" : 96230361759096832,
  "in_reply_to_status_id" : 96229407563325440,
  "created_at" : "2011-07-27 14:48:00 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96225730513469440",
  "text" : "\u3067\u3082\u304A\u3054\u3063\u3066\u3082\u3089\u3048\u308B\u306A\u3089\u3088\u308D\u3053\u3093\u3067\u98F2\u3080\u30EC\u30D9\u30EB\u3002",
  "id" : 96225730513469440,
  "created_at" : "2011-07-27 14:29:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96225537420312576",
  "text" : "\u751F\u8336\u30B9\u30D1\u30FC\u30AF\u30EA\u30F3\u30B0\u30FB\u30FB\u30FB\u3002\u78BA\u304B\u306B\u671D\u98F2\u3093\u3060\u3089\u723D\u3084\u304B\u3060\u3068\u306F\u601D\u3046\u3051\u3069\uFF01\u98F2\u3081\u308B\u3051\u3069\uFF01\u304A\u52E7\u3081\u306F\u3057\u306A\u3044\u3057\u3001\uFF12\u672C\u76EE\u3092\u8CB7\u3046\u3053\u3068\u306F\u306A\u3044\u304B\u306A\u30FC\u3002",
  "id" : 96225537420312576,
  "created_at" : "2011-07-27 14:28:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96225245333159936",
  "text" : "\u3069\u3070\u306B\u3083\u3093\u304B\u308F\u3044\u305D\u3046\u306B\u30FB\u30FB\u30FB\u3002\u307E\u3041\u3053\u306E\u30E1\u30C3\u30BB\u30FC\u30B8\u3092\u5F7C\u304C\u898B\u308B\u3053\u3068\u3063\u3066\u6C7A\u3057\u3066\u306A\u3044\u3093\u3060\u3051\u3069\u3055\u3002",
  "id" : 96225245333159936,
  "created_at" : "2011-07-27 14:27:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96225099136512001",
  "text" : "RT @dovanyahn: \u3057\u304B\u3082\u518D\u8D77\u52D5\u5931\u6557wwwww\u304A\u524D\u3082\u3046\u5BFF\u547D\u306A\u306E\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96224461862350848",
    "text" : "\u3057\u304B\u3082\u518D\u8D77\u52D5\u5931\u6557wwwww\u304A\u524D\u3082\u3046\u5BFF\u547D\u306A\u306E\u304B",
    "id" : 96224461862350848,
    "created_at" : "2011-07-27 14:24:34 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 96225099136512001,
  "created_at" : "2011-07-27 14:27:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96224399505629185",
  "text" : "\u3053\u308C\u306F\u30FB\u30FB\u30FB",
  "id" : 96224399505629185,
  "created_at" : "2011-07-27 14:24:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96224302252294144",
  "text" : "RT @dovanyahn: \u304E\u3083\u3042\u3042\u3042\u3042\u30D6\u30EB\u30FC\u30B9\u30AF\u30EA\u30FC\u30F3\u98DF\u3089\u3063\u305F\u3042\u3042\u3042\u3042\u3042\u30EC\u30DD\u30FC\u30C8\u6D88\u3048\u305F\u3042\u3042\u3042\u3042\u3042\u3042",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96222174754512896",
    "text" : "\u304E\u3083\u3042\u3042\u3042\u3042\u30D6\u30EB\u30FC\u30B9\u30AF\u30EA\u30FC\u30F3\u98DF\u3089\u3063\u305F\u3042\u3042\u3042\u3042\u3042\u30EC\u30DD\u30FC\u30C8\u6D88\u3048\u305F\u3042\u3042\u3042\u3042\u3042\u3042",
    "id" : 96222174754512896,
    "created_at" : "2011-07-27 14:15:28 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 96224302252294144,
  "created_at" : "2011-07-27 14:23:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96214028002672641",
  "text" : "\u3042\u3001\u305D\u3082\u305D\u3082\u751F\u8336\u3042\u3093\u307E\u308A\u597D\u304D\u3058\u3083\u306A\u3044\u3093\u3060\u3063\u305F\u3002\u3044\u3084\u3001\u8A66\u3059\u3051\u3069\u3002",
  "id" : 96214028002672641,
  "created_at" : "2011-07-27 13:43:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96213479568056320",
  "text" : "\u751F\u8336\u30B9\u30D1\u30FC\u30AF\u30EA\u30F3\u30B0\u8A66\u3057\u3066\u898B\u3088\u3046\u304B\u3002\u3069\u30FC\u305B\u70AD\u9178\u6C34\u597D\u304D\u306A\u5974\u306E\u610F\u898B\u306F\u53C2\u8003\u306B\u306A\u3089\u306A\u3044\u3060\u308D\u3046\u3051\u3069\u306A\u3063\uFF01",
  "id" : 96213479568056320,
  "created_at" : "2011-07-27 13:40:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96211837653229568",
  "geo" : { },
  "id_str" : "96212392781946880",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u306F\u305F\u3089\u304D\u3082\u306E\u3001\u3048\u3089\u3044\u3002",
  "id" : 96212392781946880,
  "in_reply_to_status_id" : 96211837653229568,
  "created_at" : "2011-07-27 13:36:36 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96211124193730560",
  "text" : "\u30BB\u30A4\u30ED\u30F3\u3067\u6E7F\u308B\u3002\u7D05\u8336\u3092\u96F6\u3057\u305F\u3093\u3060\u306A\u3001\u304D\u3063\u3068\u3002",
  "id" : 96211124193730560,
  "created_at" : "2011-07-27 13:31:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96210415637381120",
  "text" : "\u3060\u3044\u305F\u3044\u4EBA\u9593\u306E\u6027\u683C\u306A\u3093\u3060\u304B\u3089\u591A\u304B\u308C\u5C11\u306A\u304B\u308C\u4E21\u65B9\u3042\u308B\u3060\u308D\u3001\u3068\u6B63\u8AD6\u3067\u7DE0\u3081\u308B\u3002",
  "id" : 96210415637381120,
  "created_at" : "2011-07-27 13:28:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96210147294195713",
  "text" : "\u3042\u3001\uFF2D\u3060\u304B\u3089\u3063\u3066\u30A4\u30B8\u308B\u98A8\u6F6E\u3082\u597D\u304D\u3058\u3083\u306A\u3044",
  "id" : 96210147294195713,
  "created_at" : "2011-07-27 13:27:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96209824169209856",
  "text" : "\u78BA\u304B\u306B\u3002\u30C9\uFF33\uFF08\u3057\u304B\u3082\u81EA\u79F0\uFF09\u306F\u4ED6\u8005\u306B\u30AD\u30C4\u304F\u632F\u308B\u821E\u3046\u514D\u7F6A\u7B26\u306B\u306F\u306A\u3089\u306A\u3044\u3088\u306A\u30FC\u3002",
  "id" : 96209824169209856,
  "created_at" : "2011-07-27 13:26:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96208074955689984",
  "text" : "\u3069\u3070\u306B\u3083\u3093\u5F10\u5BFA\u3084\u3063\u3066\u3093\u306E\u304B\uFF57\uFF57\uFF57",
  "id" : 96208074955689984,
  "created_at" : "2011-07-27 13:19:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96207948191244288",
  "text" : "RT @dovanyahn: \u3042\u3001\u305D\u3046\u3044\u3048\u3070\u4ECA\u65E51\u30AF\u30EC\u3057\u304B\u3057\u3066\u306A\u3044\u3051\u3069\u3001STR99\u306B\u306A\u3063\u305F\u3057\u4E0D\u6C88\u8266\u304C\u6C88\u6CA1\u3057\u306A\u304B\u3063\u305F\u3088\uFF01\u3084\u3063\u305F\u306D\u3069\u3070\u306B\u3083\u3093\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96207102619549696",
    "text" : "\u3042\u3001\u305D\u3046\u3044\u3048\u3070\u4ECA\u65E51\u30AF\u30EC\u3057\u304B\u3057\u3066\u306A\u3044\u3051\u3069\u3001STR99\u306B\u306A\u3063\u305F\u3057\u4E0D\u6C88\u8266\u304C\u6C88\u6CA1\u3057\u306A\u304B\u3063\u305F\u3088\uFF01\u3084\u3063\u305F\u306D\u3069\u3070\u306B\u3083\u3093\uFF01",
    "id" : 96207102619549696,
    "created_at" : "2011-07-27 13:15:35 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 96207948191244288,
  "created_at" : "2011-07-27 13:18:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96206896364662784",
  "text" : "\u6700\u8FD1KU\u30EA\u30B9\u30C8\u3092\u773A\u3081\u3066\u3044\u308B\u305B\u3044\u304B\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u304C\u9045\u304F\u611F\u3058\u308B",
  "id" : 96206896364662784,
  "created_at" : "2011-07-27 13:14:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96206033965432834",
  "text" : "\u5E73\u4E43\u2026\u53EF\u54C0\u76F8\u2026 RT @ milkyholmes: \u5E73\u4E43\u306E\u6C7A\u3081\u30AB\u30C3\u30C8\u304C\u5C11\u306A\u304F\u3066\u30B0\u30C3\u30BA\u88FD\u4F5C\u5927\u5909\u306A\u3093\u3067\u3059\u3051\u3069\u3068\u6012\u3089\u308C\u308B\u306A\u3046\u3002",
  "id" : 96206033965432834,
  "created_at" : "2011-07-27 13:11:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96204409440190464",
  "text" : "\u6708\u672B\u306B\u9CE5\u30B3\u30F3\u898B\u306B\u884C\u304F\u3051\u3069\u7D50\u5C40\u4F55\u3092\u3084\u308B\u30B3\u30F3\u30C6\u30B9\u30C8\u306A\u306E\u304B\u3044\u307E\u3072\u3068\u3064\u5177\u4F53\u7684\u306B\u89E3\u3063\u3066\u3044\u306A\u3044\u3002",
  "id" : 96204409440190464,
  "created_at" : "2011-07-27 13:04:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96202149645651968",
  "text" : "\u6587\u5B66\u90E8\u81EA\u7531\u5358\u4F4D\u3092\u7D4C\u6E08\u306E\u4E92\u63DB\u5358\u4F4D\u3067\u57CB\u3081\u5C3D\u304F\u3059\u8A08\u753B2011",
  "id" : 96202149645651968,
  "created_at" : "2011-07-27 12:55:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ishida",
      "screen_name" : "Ishida_math",
      "indices" : [ 3, 15 ],
      "id_str" : "1325842176",
      "id" : 1325842176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96200171267952641",
  "text" : "RT @ishida_math: \u767A\u884C\u3067\u304D\u308B\u901A\u904E\u306E\u679A\u6570\u304C\u6709\u9650\u3060\u304B\u3089\u7121\u7406\u3067\u3059\u3088\u3049\u3002 RT @uchiki2: \u7D4C\u6E08\u306B\u9023\u7D9A\u6027\u3082\u305F\u305B\u308B\u305F\u3081\u901A\u8CA8\u3092\u7A20\u5BC6\u306B\u3059\u3079\u304D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96195815902674944",
    "text" : "\u767A\u884C\u3067\u304D\u308B\u901A\u904E\u306E\u679A\u6570\u304C\u6709\u9650\u3060\u304B\u3089\u7121\u7406\u3067\u3059\u3088\u3049\u3002 RT @uchiki2: \u7D4C\u6E08\u306B\u9023\u7D9A\u6027\u3082\u305F\u305B\u308B\u305F\u3081\u901A\u8CA8\u3092\u7A20\u5BC6\u306B\u3059\u3079\u304D",
    "id" : 96195815902674944,
    "created_at" : "2011-07-27 12:30:44 +0000",
    "user" : {
      "name" : "Ishida\u3060\u3063\u305F\u3082\u306E",
      "screen_name" : "ishidamath",
      "protected" : true,
      "id_str" : "125193971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3474227429\/d4768cf2ed7d172224cd2929f3fa4c57_normal.png",
      "id" : 125193971,
      "verified" : false
    }
  },
  "id" : 96200171267952641,
  "created_at" : "2011-07-27 12:48:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96158041501745154",
  "text" : "\u30EA\u30B5\u3061\u3083\u3093\u304C\u5999\u306A\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u751F\u307F\u51FA\u3057\u3066\u308B\u2026",
  "id" : 96158041501745154,
  "created_at" : "2011-07-27 10:00:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 3, 13 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3042\u305A\u306B\u3083\u3093\u306B\u3042\u308A\u304C\u3068\u3046\u3068\u8A00\u3044\u7D9A\u3051\u308B\u3068\u5E78\u305B\u306B\u306A\u308C\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3058\u3083\u306A\u3044\u304B",
      "indices" : [ 15, 51 ]
    }, {
      "text" : "\u3072\u3089\u304C\u306A",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96157842880479232",
  "text" : "RT @Lisa_math: #\u3042\u305A\u306B\u3083\u3093\u306B\u3042\u308A\u304C\u3068\u3046\u3068\u8A00\u3044\u7D9A\u3051\u308B\u3068\u5E78\u305B\u306B\u306A\u308C\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3058\u3083\u306A\u3044\u304B\uFF1F\/\u3059\u3051\u304D\u3088\u3063\uFF01 #\u3072\u3089\u304C\u306A\/\u30ED\u30FC\u30DE\u5B57\u3001\u53F3Alt\u3001\u53F3Ctrl\u306E\u4F7F\u7528\u983B\u5EA6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/botis.org\/wiki\/PySocialBot\" rel=\"nofollow\"\u003EPySocialBot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u3042\u305A\u306B\u3083\u3093\u306B\u3042\u308A\u304C\u3068\u3046\u3068\u8A00\u3044\u7D9A\u3051\u308B\u3068\u5E78\u305B\u306B\u306A\u308C\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3058\u3083\u306A\u3044\u304B",
        "indices" : [ 0, 36 ]
      }, {
        "text" : "\u3072\u3089\u304C\u306A",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96156541153062912",
    "text" : "#\u3042\u305A\u306B\u3083\u3093\u306B\u3042\u308A\u304C\u3068\u3046\u3068\u8A00\u3044\u7D9A\u3051\u308B\u3068\u5E78\u305B\u306B\u306A\u308C\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3058\u3083\u306A\u3044\u304B\uFF1F\/\u3059\u3051\u304D\u3088\u3063\uFF01 #\u3072\u3089\u304C\u306A\/\u30ED\u30FC\u30DE\u5B57\u3001\u53F3Alt\u3001\u53F3Ctrl\u306E\u4F7F\u7528\u983B\u5EA6",
    "id" : 96156541153062912,
    "created_at" : "2011-07-27 09:54:40 +0000",
    "user" : {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "protected" : false,
      "id_str" : "254452685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1875685697\/Lisa_n1_normal.png",
      "id" : 254452685,
      "verified" : false
    }
  },
  "id" : 96157842880479232,
  "created_at" : "2011-07-27 09:59:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96155783586258944",
  "text" : "\u3060\u3044\u305F\u3044\u4FFA\u304C\u8108\u7D61\u306A\u3044\u3053\u3068\u66F8\u304F\u3088\u308A\u4ED6\u4EBA\u304C\u66F8\u3044\u305F\u3053\u3068\u306E\u65B9\u304C\u6109\u5FEB\u306A\u3093\u3060\u3088\u306A\u3041",
  "id" : 96155783586258944,
  "created_at" : "2011-07-27 09:51:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96155538274000896",
  "text" : "\u6700\u8FD1RT\u306E\u65B9\u304C\u591A\u3044\u306A\u2026",
  "id" : 96155538274000896,
  "created_at" : "2011-07-27 09:50:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CA\u30B9\u30AB\u306E\u75F4\u60C5\u30A7",
      "screen_name" : "synfunk",
      "indices" : [ 3, 11 ],
      "id_str" : "108973898",
      "id" : 108973898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96155324985253889",
  "text" : "RT @synfunk: \u307C\u304F\u306F\u5C0F\u5B661\u5E74\u751F\u306E\u6642\u306B\u540D\u524D\u3092\u6F22\u5B57\u3067\u66F8\u3044\u3066\u5148\u751F\u306B\u6012\u3089\u308C\u307E\u3057\u305F\u30022\u5E74\u751F\u306E\u6642\u306F\uFF17\u306E\u6BB5\u306E\u639B\u3051\u7B97\u3092\u3057\u3066\u6012\u3089\u308C\u307E\u3057\u305F\u3002\u300C\u307E\u3060\u6559\u3048\u3066\u3044\u306A\u3044\u4E8B\u306F\u3084\u3063\u3066\u306F\u3044\u3051\u307E\u305B\u3093\uFF01\u300D\u3063\u3066\u3002\u307C\u304F\u306F\u3044\u307E30\u6B73\u3092\u904E\u304E\u3066\u7AE5\u8C9E\u3067\u3059\u3002\u5148\u751F\u3068\u305A\u3063\u3068\u9023\u7D61\u304C\u3068\u308C\u307E\u305B\u3093\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95906765006323713",
    "text" : "\u307C\u304F\u306F\u5C0F\u5B661\u5E74\u751F\u306E\u6642\u306B\u540D\u524D\u3092\u6F22\u5B57\u3067\u66F8\u3044\u3066\u5148\u751F\u306B\u6012\u3089\u308C\u307E\u3057\u305F\u30022\u5E74\u751F\u306E\u6642\u306F\uFF17\u306E\u6BB5\u306E\u639B\u3051\u7B97\u3092\u3057\u3066\u6012\u3089\u308C\u307E\u3057\u305F\u3002\u300C\u307E\u3060\u6559\u3048\u3066\u3044\u306A\u3044\u4E8B\u306F\u3084\u3063\u3066\u306F\u3044\u3051\u307E\u305B\u3093\uFF01\u300D\u3063\u3066\u3002\u307C\u304F\u306F\u3044\u307E30\u6B73\u3092\u904E\u304E\u3066\u7AE5\u8C9E\u3067\u3059\u3002\u5148\u751F\u3068\u305A\u3063\u3068\u9023\u7D61\u304C\u3068\u308C\u307E\u305B\u3093\u3002",
    "id" : 95906765006323713,
    "created_at" : "2011-07-26 17:22:09 +0000",
    "user" : {
      "name" : "\u30CA\u30B9\u30AB\u306E\u75F4\u60C5\u30A7",
      "screen_name" : "synfunk",
      "protected" : false,
      "id_str" : "108973898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543357824265248768\/tr-42Zjc_normal.jpeg",
      "id" : 108973898,
      "verified" : false
    }
  },
  "id" : 96155324985253889,
  "created_at" : "2011-07-27 09:49:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96150432589684736",
  "text" : "\u5185\u8F2A\u30CD\u30BF\u3060\u304C\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B\u304C\u304A\u3082\u3057\u308C\u3047\u2026",
  "id" : 96150432589684736,
  "created_at" : "2011-07-27 09:30:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8449\u30CE\u5009\u3048\u3093(17)",
      "screen_name" : "en_1768",
      "indices" : [ 3, 11 ],
      "id_str" : "132862218",
      "id" : 132862218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96150047070232576",
  "text" : "RT @en_1768: \u3042\u3042\u5927\u6839\u8E0A\u308A\u306E #\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95672033354072064",
    "text" : "\u3042\u3042\u5927\u6839\u8E0A\u308A\u306E #\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
    "id" : 95672033354072064,
    "created_at" : "2011-07-26 01:49:24 +0000",
    "user" : {
      "name" : "\u8449\u30CE\u5009\u3048\u3093(17)",
      "screen_name" : "en_1768",
      "protected" : false,
      "id_str" : "132862218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519139019905437696\/-LTC1HnH_normal.png",
      "id" : 132862218,
      "verified" : false
    }
  },
  "id" : 96150047070232576,
  "created_at" : "2011-07-27 09:28:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3070\uFF20\u6162\u6027\u4E94\u6708\u75C5",
      "screen_name" : "NEVACCi",
      "indices" : [ 3, 11 ],
      "id_str" : "155416436",
      "id" : 155416436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96149970759069696",
  "text" : "RT @NEVACCi: \u30B5\u30DE\u30FC\u30BF\u30A4\u30E0\u3092\u5B9F\u65BD\u3057\u3066\u5F97\u3092\u3057\u305F\u4EBA\u9593\u304C\u7686\u7121 #\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
        "indices" : [ 21, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96072551930937344",
    "text" : "\u30B5\u30DE\u30FC\u30BF\u30A4\u30E0\u3092\u5B9F\u65BD\u3057\u3066\u5F97\u3092\u3057\u305F\u4EBA\u9593\u304C\u7686\u7121 #\u8FB2\u5DE5\u5927\u3042\u308B\u3042\u308B",
    "id" : 96072551930937344,
    "created_at" : "2011-07-27 04:20:55 +0000",
    "user" : {
      "name" : "\u306D\u3070\uFF20\u6162\u6027\u4E94\u6708\u75C5",
      "screen_name" : "NEVACCi",
      "protected" : false,
      "id_str" : "155416436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593278415513358337\/CyYjF89D_normal.jpg",
      "id" : 155416436,
      "verified" : false
    }
  },
  "id" : 96149970759069696,
  "created_at" : "2011-07-27 09:28:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    }, {
      "name" : "\u308F\u3075\u308F\u3075",
      "screen_name" : "39_wafuwafu21",
      "indices" : [ 44, 58 ],
      "id_str" : "183876985",
      "id" : 183876985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96049935916605442",
  "text" : "RT @dovanyahn: \u3070\u3063\u304B\u3082\u30FC\u3093\uFF01\u305D\u3044\u3064\u304C\u672C\u7269\u306E\u3069\u3070\u306B\u3083\u3093\u3060\uFF01\u8FFD\u3048\u30FC\uFF01 RT @39_wafuwafu21: \u307C\u3063\u3061\u98EF\u3057\u3066\u305F\u3089\u5F8C\u308D\u59FF\u304C\u3069\u3070\u305D\u3063\u304F\u308A\u306E\u4EBA\u3044\u305F\u304B\u3089\u3001\u58F0\u304B\u3051\u3088\u3046\u3068\u3057\u305F\u3089\u3069\u3070\u3058\u3083\u306A\u304B\u3063\u305F\uFF65\uFF65\uFF65(\u00B4\uFF65\u03C9\uFF65`)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u308F\u3075\u308F\u3075",
        "screen_name" : "39_wafuwafu21",
        "indices" : [ 29, 43 ],
        "id_str" : "183876985",
        "id" : 183876985
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96049638947303424",
    "text" : "\u3070\u3063\u304B\u3082\u30FC\u3093\uFF01\u305D\u3044\u3064\u304C\u672C\u7269\u306E\u3069\u3070\u306B\u3083\u3093\u3060\uFF01\u8FFD\u3048\u30FC\uFF01 RT @39_wafuwafu21: \u307C\u3063\u3061\u98EF\u3057\u3066\u305F\u3089\u5F8C\u308D\u59FF\u304C\u3069\u3070\u305D\u3063\u304F\u308A\u306E\u4EBA\u3044\u305F\u304B\u3089\u3001\u58F0\u304B\u3051\u3088\u3046\u3068\u3057\u305F\u3089\u3069\u3070\u3058\u3083\u306A\u304B\u3063\u305F\uFF65\uFF65\uFF65(\u00B4\uFF65\u03C9\uFF65`)",
    "id" : 96049638947303424,
    "created_at" : "2011-07-27 02:49:53 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 96049935916605442,
  "created_at" : "2011-07-27 02:51:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96049445157863424",
  "text" : "\u4E8C\u9650\u9045\u523B\u3057\u3066\u8997\u304D\u306B\u884C\u3063\u305F\u3089\u767A\u8868\u8005\u3068\u5148\u751F\u3057\u304B\u3044\u306A\u3055\u305D\u306A\u72B6\u6CC1\u3060\u3063\u305F\u304B\u3089\u5927\u4EBA\u3057\u304F\u30EC\u30DD\u30FC\u30C8\u51FA\u3057\u3066\u5E30\u3063\u3066\u304D\u305F\u3001\u306A\u3046\u3002",
  "id" : 96049445157863424,
  "created_at" : "2011-07-27 02:49:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308B\u30FC\u3075",
      "screen_name" : "roofoy",
      "indices" : [ 3, 10 ],
      "id_str" : "92254035",
      "id" : 92254035
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7406\u5B66\u90E8\u30CF\u30E9\u30B9\u30E1\u30F3\u30C8",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96048729550880768",
  "text" : "RT @roofoy: \u7269\u7406\u300C\u7C21\u5358\u306A\u8A08\u7B97\u306B\u3088\u308A\u300D\u60C5\u5831\u300C\u5B9F\u88C5\u3059\u308B\u3060\u3051\u300D\u6570\u5B66\u300C\u81EA\u660E\u300D #\u7406\u5B66\u90E8\u30CF\u30E9\u30B9\u30E1\u30F3\u30C8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u7406\u5B66\u90E8\u30CF\u30E9\u30B9\u30E1\u30F3\u30C8",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95887591613804544",
    "text" : "\u7269\u7406\u300C\u7C21\u5358\u306A\u8A08\u7B97\u306B\u3088\u308A\u300D\u60C5\u5831\u300C\u5B9F\u88C5\u3059\u308B\u3060\u3051\u300D\u6570\u5B66\u300C\u81EA\u660E\u300D #\u7406\u5B66\u90E8\u30CF\u30E9\u30B9\u30E1\u30F3\u30C8",
    "id" : 95887591613804544,
    "created_at" : "2011-07-26 16:05:58 +0000",
    "user" : {
      "name" : "\u308B\u30FC\u3075",
      "screen_name" : "roofoy",
      "protected" : false,
      "id_str" : "92254035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432147632685715457\/ox3MZH6t_normal.jpeg",
      "id" : 92254035,
      "verified" : false
    }
  },
  "id" : 96048729550880768,
  "created_at" : "2011-07-27 02:46:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96026764165382144",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u81EA\u8EE2\u8ECA\u306E\u30D1\u30F3\u30AF\u76F4\u3057\u306A\u304C\u3089\u5B66\u6821\u3078\u3002\u3055\u3066\u4F55\u5206\u9045\u523B\u304B\u306A\uFF1F",
  "id" : 96026764165382144,
  "created_at" : "2011-07-27 01:18:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shuntaro Nakano",
      "screen_name" : "nshun583ts",
      "indices" : [ 3, 14 ],
      "id_str" : "19172890",
      "id" : 19172890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter\u3042\u308B\u3042\u308B",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95907659198369792",
  "text" : "RT @nshun583ts: #twitter\u3042\u308B\u3042\u308B \u5404\u7A2E\u3042\u308B\u3042\u308B\u30CD\u30BF\u304C\u3060\u3093\u3060\u3093\u76EE\u969C\u308A\u306B\u306A\u3063\u3066\u304F\u308Bw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "twitter\u3042\u308B\u3042\u308B",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95907052827844608",
    "text" : "#twitter\u3042\u308B\u3042\u308B \u5404\u7A2E\u3042\u308B\u3042\u308B\u30CD\u30BF\u304C\u3060\u3093\u3060\u3093\u76EE\u969C\u308A\u306B\u306A\u3063\u3066\u304F\u308Bw",
    "id" : 95907052827844608,
    "created_at" : "2011-07-26 17:23:17 +0000",
    "user" : {
      "name" : "Shuntaro Nakano",
      "screen_name" : "nshun583ts",
      "protected" : false,
      "id_str" : "19172890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1355816476\/image_normal.jpg",
      "id" : 19172890,
      "verified" : false
    }
  },
  "id" : 95907659198369792,
  "created_at" : "2011-07-26 17:25:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95901826523729920",
  "geo" : { },
  "id_str" : "95903090229788672",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u7FFC\u3092\u6388\u304B\u308B\uFF01",
  "id" : 95903090229788672,
  "in_reply_to_status_id" : 95901826523729920,
  "created_at" : "2011-07-26 17:07:33 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u65E7\u3059\u307F\u308C\u3055\u3093 \u65B0\u3059\u307F\u308C\u3055\u3093\u306Fcymupe",
      "screen_name" : "sumire_unipro",
      "indices" : [ 3, 17 ],
      "id_str" : "523378894",
      "id" : 523378894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95898812350070784",
  "text" : "RT @sumire_unipro: \u3068\u30FC\u3061\u3083\u3093\u300C\u67D0\u5927\u5B66\u306E\u5C65\u4FEE\u767B\u9332\u30B7\u30B9\u30C6\u30E0\u3092\u4F5C\u3063\u305F\u3068\u304D\u3001\u4E0D\u8DB3\u5358\u4F4D\u306E\u8B66\u544A\u6A5F\u80FD\u5B9F\u88C5\u306E\u8A71\u304C\u3042\u3063\u305F\u3002\u5358\u4F4D\u304C\u8DB3\u308A\u306A\u3044\u3053\u3068\u306B\u6C17\u3065\u304B\u305A\u7559\u5E74\u3059\u308B\u5B66\u751F\u304C\u4E00\u5B9A\u6570\u3044\u308B\u3068\u3044\u3046\u3053\u3068\u3060\u3063\u305F\u304C\u3001\u307B\u3093\u307E\u304B\u3044\u306A\u3068\u601D\u3063\u3066\u7B11\u3063\u3066\u3044\u305F\u3089\u5A18\u304C\u305D\u3046\u306A\u3063\u305F\u3002\u53D7\u6CE8\u5143\u306B\u305D\u306E\u8A71\u3092\u3057\u305F\u3089\u30A6\u30B1\u305F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86088718150148096",
    "text" : "\u3068\u30FC\u3061\u3083\u3093\u300C\u67D0\u5927\u5B66\u306E\u5C65\u4FEE\u767B\u9332\u30B7\u30B9\u30C6\u30E0\u3092\u4F5C\u3063\u305F\u3068\u304D\u3001\u4E0D\u8DB3\u5358\u4F4D\u306E\u8B66\u544A\u6A5F\u80FD\u5B9F\u88C5\u306E\u8A71\u304C\u3042\u3063\u305F\u3002\u5358\u4F4D\u304C\u8DB3\u308A\u306A\u3044\u3053\u3068\u306B\u6C17\u3065\u304B\u305A\u7559\u5E74\u3059\u308B\u5B66\u751F\u304C\u4E00\u5B9A\u6570\u3044\u308B\u3068\u3044\u3046\u3053\u3068\u3060\u3063\u305F\u304C\u3001\u307B\u3093\u307E\u304B\u3044\u306A\u3068\u601D\u3063\u3066\u7B11\u3063\u3066\u3044\u305F\u3089\u5A18\u304C\u305D\u3046\u306A\u3063\u305F\u3002\u53D7\u6CE8\u5143\u306B\u305D\u306E\u8A71\u3092\u3057\u305F\u3089\u30A6\u30B1\u305F\u300D\u79C1\u300C(^p^)\u300D",
    "id" : 86088718150148096,
    "created_at" : "2011-06-29 15:08:44 +0000",
    "user" : {
      "name" : "\u767E\u5408\uFF1F\u8594\u8587\uFF1F\u3044\u3044\u3048\u79C1\u306F\u3059\u307F\u308C\u3055\u3093",
      "screen_name" : "CyMuPe",
      "protected" : false,
      "id_str" : "146767357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608253867986452480\/6lVZlAwN_normal.png",
      "id" : 146767357,
      "verified" : false
    }
  },
  "id" : 95898812350070784,
  "created_at" : "2011-07-26 16:50:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 3, 13 ],
      "id_str" : "126326979",
      "id" : 126326979
    }, {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 37, 47 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95893696469409792",
  "text" : "RT @Keitaecon: \u305D\u3057\u3066\u30C9\u30AF\u30BF\u30FC\u306F\u8003\u3048\u308B\u306E\u3092\u3084\u3081\u305F\uFF0E\uFF0E\uFF0ERT @JOJO_math: \u300C\uFF14\u5E74\u9593\u3067\u3000\uFF11\u518A\u306E\u6570\u5B66\u66F8\u306E\u7CBE\u8AAD\u304C\u3067\u304D\u308B\u3088\u3046\u306B\u306A\u308C\uFF01\uFF01\u300D\u300C\u3064\u304E\u306F\uFF12\u5E74\u9593\u6700\u65B0\u306E\u8AD6\u6587\u306E\u5185\u5BB9\u3092\u5438\u53CE\u3057\u3064\u3065\u3051\u3066\u3000\uFF13\u5E74\u9593\u65B0\u305F\u306A\u5B9A\u7406\u3092\u6A21\u7D22\u3057\u3064\u3065\u3051\u308D\u30C3\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
        "screen_name" : "JOJO_math",
        "indices" : [ 22, 32 ],
        "id_str" : "249297914",
        "id" : 249297914
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95893232088662017",
    "text" : "\u305D\u3057\u3066\u30C9\u30AF\u30BF\u30FC\u306F\u8003\u3048\u308B\u306E\u3092\u3084\u3081\u305F\uFF0E\uFF0E\uFF0ERT @JOJO_math: \u300C\uFF14\u5E74\u9593\u3067\u3000\uFF11\u518A\u306E\u6570\u5B66\u66F8\u306E\u7CBE\u8AAD\u304C\u3067\u304D\u308B\u3088\u3046\u306B\u306A\u308C\uFF01\uFF01\u300D\u300C\u3064\u304E\u306F\uFF12\u5E74\u9593\u6700\u65B0\u306E\u8AD6\u6587\u306E\u5185\u5BB9\u3092\u5438\u53CE\u3057\u3064\u3065\u3051\u3066\u3000\uFF13\u5E74\u9593\u65B0\u305F\u306A\u5B9A\u7406\u3092\u6A21\u7D22\u3057\u3064\u3065\u3051\u308D\u30C3\u300D",
    "id" : 95893232088662017,
    "created_at" : "2011-07-26 16:28:22 +0000",
    "user" : {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "protected" : true,
      "id_str" : "126326979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3535232419\/5f799797d2a44059913591d3e610ad70_normal.jpeg",
      "id" : 126326979,
      "verified" : false
    }
  },
  "id" : 95893696469409792,
  "created_at" : "2011-07-26 16:30:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95881206440267776",
  "text" : "\u65E9\u671D\u6700\u901F\u3067\u5F66\u6839\u306B\u884C\u304F\u305F\u3063\u305F\u4E00\u3064\u306E\u3055\u3048\u305F\u3084\u308A\u65B9\u77E5\u3063\u3066\u308B\u4EBA\u3044\u307E\u305B\u3093\u304B\u30FB\u30FB\u30FB",
  "id" : 95881206440267776,
  "created_at" : "2011-07-26 15:40:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95829432975110145",
  "text" : "\u7C98\u5EA6\u306E\u9AD8\u3044\u7C98\u571F",
  "id" : 95829432975110145,
  "created_at" : "2011-07-26 12:14:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "indices" : [ 3, 12 ],
      "id_str" : "105498380",
      "id" : 105498380
    }, {
      "name" : "\u3042\u3059\u3057",
      "screen_name" : "at_sushi_bar",
      "indices" : [ 27, 40 ],
      "id_str" : "92534754",
      "id" : 92534754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95829230620901376",
  "text" : "RT @_Nururin: \u304A\u524D\u306F\u4FFA\u3092\u6012\u3089\u305B\u305F RT @at_sushi_bar: \u4E09\u91CD\u304C\u307F\u3048\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3042\u3059\u3057",
        "screen_name" : "at_sushi_bar",
        "indices" : [ 13, 26 ],
        "id_str" : "92534754",
        "id" : 92534754
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95828837019033600",
    "text" : "\u304A\u524D\u306F\u4FFA\u3092\u6012\u3089\u305B\u305F RT @at_sushi_bar: \u4E09\u91CD\u304C\u307F\u3048\u306A\u3044",
    "id" : 95828837019033600,
    "created_at" : "2011-07-26 12:12:29 +0000",
    "user" : {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "protected" : false,
      "id_str" : "105498380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591661205489520640\/gzUrW2-9_normal.jpg",
      "id" : 105498380,
      "verified" : false
    }
  },
  "id" : 95829230620901376,
  "created_at" : "2011-07-26 12:14:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "indices" : [ 3, 18 ],
      "id_str" : "158991353",
      "id" : 158991353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95828750779957248",
  "text" : "RT @sorayama_asobi: \u5618\u3068\u672C\u5F53\u306E\u3053\u3068\u6DF7\u305C\u3066\u8A71\u3059\u3068\u5618\u304C\u3070\u308C\u306A\u3044\u3063\u3066\u805E\u3044\u305F\u304B\u3089\u3001\u300C\u6628\u65E5\u4F55\u3057\u3066\u305F\uFF1F\u300D\u3063\u3066\u805E\u304B\u308C\u305F\u3068\u304D\u672C\u5F53\u306E\u3053\u3068\u8A00\u3044\u305F\u304F\u306A\u304F\u3066\u3068\u3063\u3055\u306B\u300C\u3044\u3001\u4E00\u65E5\u4E2D\u722A\u5207\u3063\u3066\u305F\u300D\uFF08\u6628\u6669\u5B9F\u969B\u306B\u722A\u3092\u5207\u3063\u305F\uFF09\u3063\u3066\u8A00\u3063\u305F\u3051\u3069\u3001\u3070\u308C\u306A\u304B\u3063\u305F\u306E\u3060\u308D\u3046\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95828437863907329",
    "text" : "\u5618\u3068\u672C\u5F53\u306E\u3053\u3068\u6DF7\u305C\u3066\u8A71\u3059\u3068\u5618\u304C\u3070\u308C\u306A\u3044\u3063\u3066\u805E\u3044\u305F\u304B\u3089\u3001\u300C\u6628\u65E5\u4F55\u3057\u3066\u305F\uFF1F\u300D\u3063\u3066\u805E\u304B\u308C\u305F\u3068\u304D\u672C\u5F53\u306E\u3053\u3068\u8A00\u3044\u305F\u304F\u306A\u304F\u3066\u3068\u3063\u3055\u306B\u300C\u3044\u3001\u4E00\u65E5\u4E2D\u722A\u5207\u3063\u3066\u305F\u300D\uFF08\u6628\u6669\u5B9F\u969B\u306B\u722A\u3092\u5207\u3063\u305F\uFF09\u3063\u3066\u8A00\u3063\u305F\u3051\u3069\u3001\u3070\u308C\u306A\u304B\u3063\u305F\u306E\u3060\u308D\u3046\u304B",
    "id" : 95828437863907329,
    "created_at" : "2011-07-26 12:10:54 +0000",
    "user" : {
      "name" : "\u7A7A\u5C71\u904A\uFF20\u304C\u3093\u3070\u308B",
      "screen_name" : "sorayama_asobi",
      "protected" : false,
      "id_str" : "158991353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1864231491\/totoro_t_normal.jpg",
      "id" : 158991353,
      "verified" : false
    }
  },
  "id" : 95828750779957248,
  "created_at" : "2011-07-26 12:12:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 13, 23 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95827764447412224",
  "text" : "\u7559\u6570\u3060\u3088\u306D\uFF1F\u2026\u306D\uFF1F RT @Lisa_math: \u7559\u5E74\u5B9A\u7406",
  "id" : 95827764447412224,
  "created_at" : "2011-07-26 12:08:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95825763978321921",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 95825763978321921,
  "created_at" : "2011-07-26 12:00:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 3, 13 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7530\u820E\u3042\u308B\u3042\u308B",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95756936682807296",
  "text" : "RT @blackVELU: \u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01 #\u7530\u820E\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u7530\u820E\u3042\u308B\u3042\u308B",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95756468351025152",
    "text" : "\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30A6\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30AA\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30A2\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01 #\u7530\u820E\u3042\u308B\u3042\u308B",
    "id" : 95756468351025152,
    "created_at" : "2011-07-26 07:24:55 +0000",
    "user" : {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "protected" : false,
      "id_str" : "102325414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450656382325248000\/cnubEZOd_normal.jpeg",
      "id" : 102325414,
      "verified" : false
    }
  },
  "id" : 95756936682807296,
  "created_at" : "2011-07-26 07:26:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3079\u308A\u30FC\u305A\u3073\u3085\u30FC\u3066\u3043\u30FC",
      "screen_name" : "TKS_lakoon",
      "indices" : [ 3, 14 ],
      "id_str" : "159903756",
      "id" : 159903756
    }, {
      "name" : "\u30A6\u30A3\u30EB\u30D8\u30A4\u30E0@\u306B\u3083\u3093\u3053\u306A\u3046",
      "screen_name" : "willhame",
      "indices" : [ 22, 31 ],
      "id_str" : "104157044",
      "id" : 104157044
    }, {
      "name" : "\u3079\u308A\u30FC\u305A\u3073\u3085\u30FC\u3066\u3043\u30FC",
      "screen_name" : "TKS_lakoon",
      "indices" : [ 48, 59 ],
      "id_str" : "159903756",
      "id" : 159903756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95756294060908545",
  "text" : "RT @TKS_lakoon: \u3042\u30FC\uFF57RT @willhame: \u305F\u3063\u305F\u306E22post\u5206 RT @TKS_lakoon: \u30EC\u30DD\u30FC\u30C83000\u5B57\u6B7B\u306C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30A6\u30A3\u30EB\u30D8\u30A4\u30E0@\u306B\u3083\u3093\u3053\u306A\u3046",
        "screen_name" : "willhame",
        "indices" : [ 6, 15 ],
        "id_str" : "104157044",
        "id" : 104157044
      }, {
        "name" : "\u3079\u308A\u30FC\u305A\u3073\u3085\u30FC\u3066\u3043\u30FC",
        "screen_name" : "TKS_lakoon",
        "indices" : [ 32, 43 ],
        "id_str" : "159903756",
        "id" : 159903756
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95755144469286912",
    "text" : "\u3042\u30FC\uFF57RT @willhame: \u305F\u3063\u305F\u306E22post\u5206 RT @TKS_lakoon: \u30EC\u30DD\u30FC\u30C83000\u5B57\u6B7B\u306C",
    "id" : 95755144469286912,
    "created_at" : "2011-07-26 07:19:40 +0000",
    "user" : {
      "name" : "\u3079\u308A\u30FC\u305A\u3073\u3085\u30FC\u3066\u3043\u30FC",
      "screen_name" : "TKS_lakoon",
      "protected" : false,
      "id_str" : "159903756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572480081096744960\/0V8KWfPa_normal.jpeg",
      "id" : 159903756,
      "verified" : false
    }
  },
  "id" : 95756294060908545,
  "created_at" : "2011-07-26 07:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "indices" : [ 19, 28 ],
      "id_str" : "119635653",
      "id" : 119635653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95748589871050752",
  "text" : "\u7D05\u751F\u59DC\u3063\u3066\u30DE\u30A4\u30CA\u30FC\u306A\u306E\u304B\u306A\u3041\u2026 RT @nanjolno: \u30AB\u30EC\u30FC\u306F\u3001\u798F\u795E\u6F2C\u3051\u6D3E\uFF1F\u3089\u3063\u304D\u3087\u3046\u6D3E\uFF1F\uFF1F",
  "id" : 95748589871050752,
  "created_at" : "2011-07-26 06:53:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 3, 13 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95736697026912256",
  "text" : "RT @eclair_15: \u5186\u5468\u7387\u306F\uFF13\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u30023.14\u3067\u3059",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95735267754917888",
    "text" : "\u5186\u5468\u7387\u306F\uFF13\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u30023.14\u3067\u3059",
    "id" : 95735267754917888,
    "created_at" : "2011-07-26 06:00:41 +0000",
    "user" : {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "protected" : false,
      "id_str" : "158645894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604517314164162560\/4WMjGFnD_normal.png",
      "id" : 158645894,
      "verified" : false
    }
  },
  "id" : 95736697026912256,
  "created_at" : "2011-07-26 06:06:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30C9\u30E9",
      "screen_name" : "k_kadora",
      "indices" : [ 3, 12 ],
      "id_str" : "138079871",
      "id" : 138079871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8A66\u9A13\u3042\u308B\u3042\u308B",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95730052238540800",
  "text" : "RT @k_kadora: \u3053\u306E\u8B1B\u7FA9\u3063\u3066\u3053\u3093\u306A\u306B\u53D7\u8B1B\u8005\u3044\u305F\u3093\u3060 #\u8A66\u9A13\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u8A66\u9A13\u3042\u308B\u3042\u308B",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95729277970030592",
    "text" : "\u3053\u306E\u8B1B\u7FA9\u3063\u3066\u3053\u3093\u306A\u306B\u53D7\u8B1B\u8005\u3044\u305F\u3093\u3060 #\u8A66\u9A13\u3042\u308B\u3042\u308B",
    "id" : 95729277970030592,
    "created_at" : "2011-07-26 05:36:53 +0000",
    "user" : {
      "name" : "\u30AB\u30C9\u30E9",
      "screen_name" : "k_kadora",
      "protected" : false,
      "id_str" : "138079871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592639289227247616\/uyA9dVa6_normal.png",
      "id" : 138079871,
      "verified" : false
    }
  },
  "id" : 95730052238540800,
  "created_at" : "2011-07-26 05:39:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95729578135400449",
  "text" : "\u8D85\u30DD\u30B8\u30C6\u30A3\u30D6\u306A\u53D7\u3051\u53D6\u308A\u65B9\u3060\u306A\uFF57\uFF57\uFF57 Browsing : \u30CD\u30C3\u30C8\u306E\u300C\u30B0\u30F3\u30DE\u30FC\u300D\u30CD\u30BF\u3092\u7FA4\u99AC\u770C\u77E5\u4E8B\u304C\u77E5\u308B - ITmedia \u30CB\u30E5\u30FC\u30B9 http:\/\/www.itmedia.co.jp\/news\/articles\/1107\/26\/news027.html",
  "id" : 95729578135400449,
  "created_at" : "2011-07-26 05:38:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95728985824182272",
  "text" : "\u3082\u3046\u4E00\u500B\u7D42\u308F\u3063\u305F\u30FC\u3002\u3084\u3063\u3064\u3051\u3060\u3051\u3069\u3002\u3084\u308A\u59CB\u3081\u3066\u3057\u307E\u3048\u3070\u3059\u3050\u7D42\u308F\u308B\u30EC\u30DD\u30FC\u30C8\u7FA4",
  "id" : 95728985824182272,
  "created_at" : "2011-07-26 05:35:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95713443956527104",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u4E00\u3064\u7D42\u308F\u3063\u305F\uFF67\uFF01\u3082\u3044\u3063\u3053\u3084\u3063\u3066\u304B\u3089\u30A2\u30EB\u30D0\u30A4\u30C8\u5206\u3092\u3084\u308D\u3046\u3002",
  "id" : 95713443956527104,
  "created_at" : "2011-07-26 04:33:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 11, 18 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95708973780582401",
  "text" : "\u3042\u3089\u304A\u3081\u3067\u3068\u3046 RT @ayu167: \u3084\u3063\u305F\u5341\u6BB5\u3046\u304B\u3063\u305F\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 95708973780582401,
  "created_at" : "2011-07-26 04:16:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95704180546748417",
  "geo" : { },
  "id_str" : "95706127135817728",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u56F3\u66F8\u9928\u3067\u5BDD\u308B\uFF01",
  "id" : 95706127135817728,
  "in_reply_to_status_id" : 95704180546748417,
  "created_at" : "2011-07-26 04:04:53 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95699740997599232",
  "geo" : { },
  "id_str" : "95699913828081664",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 95699913828081664,
  "in_reply_to_status_id" : 95699740997599232,
  "created_at" : "2011-07-26 03:40:12 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95698506324508673",
  "geo" : { },
  "id_str" : "95699209587662848",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u305D\u3082\u305D\u3082\u30CE\u30FC\u30C8\u3092\u751F\u5354\u3067\u8CB7\u3063\u3066\u306A\u3044\u3093\u3060\u3051\u3069\u914D\u3063\u3066\u3093\u306E\u304B\u306A\u3041\u3002",
  "id" : 95699209587662848,
  "in_reply_to_status_id" : 95698506324508673,
  "created_at" : "2011-07-26 03:37:24 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3093",
      "screen_name" : "campho",
      "indices" : [ 3, 10 ],
      "id_str" : "50575347",
      "id" : 50575347
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EAC\u5927\u3042\u308B\u3042\u308B",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95698768749539328",
  "text" : "RT @campho: \u6559\u52D9\u306F\u6027\u683C\u60AA\u3044\u9806\u306B\u63A1\u7528\u3055\u308C\u3066\u308B #\u4EAC\u5927\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/cheebow.info\/chemt\/archives\/2007\/04\/twitterwindowst.html\" rel=\"nofollow\"\u003ETwit for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u4EAC\u5927\u3042\u308B\u3042\u308B",
        "indices" : [ 16, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95693713535275008",
    "text" : "\u6559\u52D9\u306F\u6027\u683C\u60AA\u3044\u9806\u306B\u63A1\u7528\u3055\u308C\u3066\u308B #\u4EAC\u5927\u3042\u308B\u3042\u308B",
    "id" : 95693713535275008,
    "created_at" : "2011-07-26 03:15:33 +0000",
    "user" : {
      "name" : "\u304B\u3093",
      "screen_name" : "campho",
      "protected" : false,
      "id_str" : "50575347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591071559\/2009y12m01d_183418388_normal.jpg",
      "id" : 50575347,
      "verified" : false
    }
  },
  "id" : 95698768749539328,
  "created_at" : "2011-07-26 03:35:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 22, 32 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EAC\u5927\u3042\u308B\u3042\u308B",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95698522971713536",
  "text" : "\u3067\u3082\u307F\u3093\u306A\u51FA\u3066\u306A\u3044\u304B\u3089\u81EA\u6162\u306B\u306A\u3089\u306A\u3044 RT @dovanyahn: \u6388\u696D\u306B\u51FA\u3066\u306A\u3044\u3053\u3068\u3092\u81EA\u6162\u3059\u308B #\u4EAC\u5927\u3042\u308B\u3042\u308B",
  "id" : 95698522971713536,
  "created_at" : "2011-07-26 03:34:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95698293140623360",
  "text" : "\u56F3\u66F8\u9928\u3067\u96FB\u6E90\u3042\u308B\u5E2D\u78BA\u4FDD\u3057\u305F\u3089\u30CE\u30FC\u30C8\u306E\u30EF\u30FC\u30C9\u304C\u30E9\u30A4\u30BB\u30F3\u30B9\u5207\u308C\u3068\u304Borz",
  "id" : 95698293140623360,
  "created_at" : "2011-07-26 03:33:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30E9\u30B5\u30FC",
      "screen_name" : "pureboy69",
      "indices" : [ 3, 13 ],
      "id_str" : "88908934",
      "id" : 88908934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4EAC\u5927\u3042\u308B\u3042\u308B",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95691484904435712",
  "text" : "RT @pureboy69: \u5358\u4F4D\u306A\u3044\u306A\u3044\u3000#\u4EAC\u5927\u3042\u308B\u3042\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u4EAC\u5927\u3042\u308B\u3042\u308B",
        "indices" : [ 7, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95691297679089664",
    "text" : "\u5358\u4F4D\u306A\u3044\u306A\u3044\u3000#\u4EAC\u5927\u3042\u308B\u3042\u308B",
    "id" : 95691297679089664,
    "created_at" : "2011-07-26 03:05:57 +0000",
    "user" : {
      "name" : "\u30A2\u30E9\u30B5\u30FC",
      "screen_name" : "pureboy69",
      "protected" : false,
      "id_str" : "88908934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606456932107321346\/GUYKifv2_normal.png",
      "id" : 88908934,
      "verified" : false
    }
  },
  "id" : 95691484904435712,
  "created_at" : "2011-07-26 03:06:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3058\u3087\u3079",
      "screen_name" : "mineorrison",
      "indices" : [ 3, 15 ],
      "id_str" : "18721091",
      "id" : 18721091
    }, {
      "name" : "\u3084\u308C\u3084\u308C\u3060\u305C",
      "screen_name" : "Dai_oh",
      "indices" : [ 25, 32 ],
      "id_str" : "203724784",
      "id" : 203724784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95690895436951553",
  "text" : "RT @mineorrison: \u305D\u308C\u91CD\u8981 RT @Dai_oh: \uFF16\u5272\u306E\u624B\u5FDC\u3048\u3092\u91CF\u7523\u3059\u308B\u7A0B\u5EA6\u306E\u80FD\u529B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3084\u308C\u3084\u308C\u3060\u305C",
        "screen_name" : "Dai_oh",
        "indices" : [ 8, 15 ],
        "id_str" : "203724784",
        "id" : 203724784
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95689274481057792",
    "text" : "\u305D\u308C\u91CD\u8981 RT @Dai_oh: \uFF16\u5272\u306E\u624B\u5FDC\u3048\u3092\u91CF\u7523\u3059\u308B\u7A0B\u5EA6\u306E\u80FD\u529B",
    "id" : 95689274481057792,
    "created_at" : "2011-07-26 02:57:55 +0000",
    "user" : {
      "name" : "\u3058\u3087\u3079",
      "screen_name" : "mineorrison",
      "protected" : false,
      "id_str" : "18721091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450982941020004352\/mYi_q-4e_normal.jpeg",
      "id" : 18721091,
      "verified" : false
    }
  },
  "id" : 95690895436951553,
  "created_at" : "2011-07-26 03:04:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30AD\/\u3046\u305F\u304B\u305F",
      "screen_name" : "yoshiki_utakata",
      "indices" : [ 3, 19 ],
      "id_str" : "83811178",
      "id" : 83811178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95687653990735872",
  "text" : "RT @yoshiki_utakata: \u5171\u5B66\u3042\u308B\u3042\u308B:\u7570\u6027\u304C\u3044\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95686192032526336",
    "text" : "\u5171\u5B66\u3042\u308B\u3042\u308B:\u7570\u6027\u304C\u3044\u308B",
    "id" : 95686192032526336,
    "created_at" : "2011-07-26 02:45:40 +0000",
    "user" : {
      "name" : "\u30E8\u30B7\u30AD\/\u3046\u305F\u304B\u305F",
      "screen_name" : "yoshiki_utakata",
      "protected" : false,
      "id_str" : "83811178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596630159605665795\/sX5kSa0j_normal.jpg",
      "id" : 83811178,
      "verified" : false
    }
  },
  "id" : 95687653990735872,
  "created_at" : "2011-07-26 02:51:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95645607670185984",
  "text" : "\u6709\u308A\u3059\u304E\u308B\u3045",
  "id" : 95645607670185984,
  "created_at" : "2011-07-26 00:04:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8336\u8272",
      "screen_name" : "zer0_Shiki",
      "indices" : [ 3, 14 ],
      "id_str" : "166849367",
      "id" : 166849367
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30DB\u30EB\u30F3\u3042\u308B\u3042\u308B",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95645538778759168",
  "text" : "RT @zer0_Shiki: \u5439\u594F\u697D\u300C\u30DB\u30EB\u30F3\u805E\u3053\u3048\u306A\u3044\u3082\u3063\u3068\u51FA\u3057\u3066\u300D\u300C\uFF08\u3082\u3046\u9650\u754C\u306A\u3093\u3067\u3059\u3051\u3069\u2026\u9178\u6B20\u3067\u6B7B\u306C\uFF09\u300D\u3000\u30AA\u30B1\u300C\u30DB\u30EB\u30F3\u3067\u304B\u3044\u97F3\u91CF\u304A\u3068\u3057\u3066\u300D\u300C\uFF08\u3053\u308C\u4EE5\u4E0A\u843D\u3068\u3057\u305F\u3089\u3057\u3087\u307C\u3044\u97F3\u3057\u304B\u9CF4\u3089\u306A\u3044\u3088\u2026\u300D\u3000\u91D1\uFF15\u300C\u30DB\u30EB\u30F3\u3082\u3063\u3068\u51FA\u3057\u3066\u3044\u3044\u3088\u300D\u300C\u3042\u3001\u3054\u3081\u3093\u300D\u3000\u6728\uFF15\u300C\u30DB\u30EB\u30F3\u3082\u3063\u3068\u843D\u3068\u305B\u308B\uFF1F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u30DB\u30EB\u30F3\u3042\u308B\u3042\u308B",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95506886031441920",
    "text" : "\u5439\u594F\u697D\u300C\u30DB\u30EB\u30F3\u805E\u3053\u3048\u306A\u3044\u3082\u3063\u3068\u51FA\u3057\u3066\u300D\u300C\uFF08\u3082\u3046\u9650\u754C\u306A\u3093\u3067\u3059\u3051\u3069\u2026\u9178\u6B20\u3067\u6B7B\u306C\uFF09\u300D\u3000\u30AA\u30B1\u300C\u30DB\u30EB\u30F3\u3067\u304B\u3044\u97F3\u91CF\u304A\u3068\u3057\u3066\u300D\u300C\uFF08\u3053\u308C\u4EE5\u4E0A\u843D\u3068\u3057\u305F\u3089\u3057\u3087\u307C\u3044\u97F3\u3057\u304B\u9CF4\u3089\u306A\u3044\u3088\u2026\u300D\u3000\u91D1\uFF15\u300C\u30DB\u30EB\u30F3\u3082\u3063\u3068\u51FA\u3057\u3066\u3044\u3044\u3088\u300D\u300C\u3042\u3001\u3054\u3081\u3093\u300D\u3000\u6728\uFF15\u300C\u30DB\u30EB\u30F3\u3082\u3063\u3068\u843D\u3068\u305B\u308B\uFF1F\u300D\u300C\u3042\u3001\u3054\u3081\u3093\u300D\u3000#\u30DB\u30EB\u30F3\u3042\u308B\u3042\u308B",
    "id" : 95506886031441920,
    "created_at" : "2011-07-25 14:53:10 +0000",
    "user" : {
      "name" : "\u8336\u8272",
      "screen_name" : "zer0_Shiki",
      "protected" : false,
      "id_str" : "166849367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415777684996644864\/n0GfD99w_normal.jpeg",
      "id" : 166849367,
      "verified" : false
    }
  },
  "id" : 95645538778759168,
  "created_at" : "2011-07-26 00:04:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 12, 23 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5439\u594F\u697D\u3042\u308B\u3042\u308B",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95502799198097408",
  "text" : "\u3042\u3063\u305F\u2026\u61D0\u304B\u3057\u3044\u3002RT @akiyohmori: \u5171\u611F\u3057\u904E\u304E\u3066\u3084\u3070\u3044 \u3069\u3053\u3082\u4E00\u7DD2\u306A\u306E\u306D \u201C \u5148\u751F\u300C\u3058\u3083\u3041\u305D\u3053\u306EB\u5439\u3044\u3066\u300D\u300C\u30FB\u30FB\u30FB(\u3048\u3001B\uFF1FD\uFF1F)\u300D\u5148\u751F\u300C\u30D9\u30B8\u30BF\u30D6\u30EB\u306EB\uFF01\u300D\u4ED6\u3000\u5148\u751F\u300CM\u304B\u3089\u3082\u30461\u56DE\u300D\u300C(M\uFF1FN?\u30FB\u30FB\u30FB\u3069\u3063\u3061\u3084)\u300D\u300C\u30DE\u30EA\u30AA\u306EM\uFF01\u300D\u3000#\u5439\u594F\u697D\u3042\u308B\u3042\u308B\u201D",
  "id" : 95502799198097408,
  "created_at" : "2011-07-25 14:36:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95475129584336896",
  "text" : "\u3069\u3046\u8003\u3048\u3066\u3082\u6570\u5B66\u79D1\u306E\u5973\u306E\u5B50\u306E\u65B9\u304C\u2026\u3068\u601D\u3063\u305F\u3089\u500B\u4EBA\u7684\u306A\u30ED\u30DE\u30F3\u304B\u3002\u7D50\u5C40\u500B\u4EBA\u7684\u306A\u30ED\u30DE\u30F3\u4EE5\u5916\u306B\u30ED\u30DE\u30F3\u3063\u3066\u3042\u308B\u306E\u304B\u306A\u3002\u7D76\u5BFE\u7684\u306A\u30ED\u30DE\u30F3\u3002\u7121\u3044\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u30FC\u3002",
  "id" : 95475129584336896,
  "created_at" : "2011-07-25 12:46:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95450692478697473",
  "text" : "\u3042\u308C\u30FC\uFF1F\u4F5C\u696D\u7528BGM\u3067\u3082\u6D41\u3057\u3066\u304A\u3053\u3046\u3068\u601D\u3063\u305F\u3089\u306B\u30CB\u30B3\u52D5\u30E1\u30F3\u30C6\u304B\u3088\u3063\u3002\u307E\u3041\u3044\u3044\u304B\u3002",
  "id" : 95450692478697473,
  "created_at" : "2011-07-25 11:09:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95446529334190080",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u30EC\u30DD\u30FC\u30C8\u3092\u3084\u308D\u3046\u3002\u3084\u308A\u59CB\u3081\u308C\u3070\u30EC\u30DD\u30FC\u30C8\u306E\u65B9\u304B\u3089\u306E\u6B69\u307F\u5BC4\u308A\u306B\u3088\u308A\u8FC5\u901F\u306B\u7D42\u308F\u308B\u306F\u305A\u3060\u3002",
  "id" : 95446529334190080,
  "created_at" : "2011-07-25 10:53:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ishida",
      "screen_name" : "Ishida_math",
      "indices" : [ 3, 15 ],
      "id_str" : "1325842176",
      "id" : 1325842176
    }, {
      "name" : "\u56DB\u6B21\u5143\u6BBA\u6CD5\u30B3\u30F3\u30D3bot",
      "screen_name" : "4dkill",
      "indices" : [ 30, 37 ],
      "id_str" : "96954440",
      "id" : 96954440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95441336936841216",
  "text" : "RT @ishida_math: \u306A\u3093\u2026\u2026\u3060\u3068\u2026\u2026\u3002 RT @4dkill: \u826F\u3044\u5B50\u306E\u8AF8\u541B\uFF01\u300C\uFF10\u300D(\u30BC\u30ED)\u3068\u3044\u3046\u6982\u5FF5\u304C\u30A4\u30F3\u30C9\u3067\u751F\u307E\u308C\u305F\u306E\u306F\u6709\u540D\u306A\u8A71\u3060\u304C\u3001\u305D\u306E\u30A4\u30F3\u30C9\u306B\u306F\u30BC\u30ED\u30EB\u30D4\u30FC\u7D19\u5E63\u307E\u3067\u3042\u308B\uFF01\u3057\u304B\u3082\u4F7F\u3044\u9053\u306F\u30A4\u30F3\u30C9\u4EBA\u3082\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3089\u3057\u3044\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u56DB\u6B21\u5143\u6BBA\u6CD5\u30B3\u30F3\u30D3bot",
        "screen_name" : "4dkill",
        "indices" : [ 13, 20 ],
        "id_str" : "96954440",
        "id" : 96954440
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95438974671257600",
    "text" : "\u306A\u3093\u2026\u2026\u3060\u3068\u2026\u2026\u3002 RT @4dkill: \u826F\u3044\u5B50\u306E\u8AF8\u541B\uFF01\u300C\uFF10\u300D(\u30BC\u30ED)\u3068\u3044\u3046\u6982\u5FF5\u304C\u30A4\u30F3\u30C9\u3067\u751F\u307E\u308C\u305F\u306E\u306F\u6709\u540D\u306A\u8A71\u3060\u304C\u3001\u305D\u306E\u30A4\u30F3\u30C9\u306B\u306F\u30BC\u30ED\u30EB\u30D4\u30FC\u7D19\u5E63\u307E\u3067\u3042\u308B\uFF01\u3057\u304B\u3082\u4F7F\u3044\u9053\u306F\u30A4\u30F3\u30C9\u4EBA\u3082\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3089\u3057\u3044\uFF01",
    "id" : 95438974671257600,
    "created_at" : "2011-07-25 10:23:19 +0000",
    "user" : {
      "name" : "Ishida\u3060\u3063\u305F\u3082\u306E",
      "screen_name" : "ishidamath",
      "protected" : true,
      "id_str" : "125193971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3474227429\/d4768cf2ed7d172224cd2929f3fa4c57_normal.png",
      "id" : 125193971,
      "verified" : false
    }
  },
  "id" : 95441336936841216,
  "created_at" : "2011-07-25 10:32:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95441261347094528",
  "text" : "RT @osamiiiin: \u3066\u3086\u30FC\u304B\u3001\u4EAC\u5927\u6587\u5B66\u90E8\u306F\u3001\u901A\u5E74\u5236\u306E\u5C65\u4FEE\u767B\u9332\u3092\u3059\u3050\u306B\u3067\u3082\u5EC3\u6B62\u3057\u3066\u3001\u30BB\u30DF\u30B9\u30BF\u30FC\uFF08\u5B66\u671F\uFF09\u5236\u3092\u63A1\u7528\u3059\u3079\u304D\u304B\u3068\u601D\u3046\u3002\u5B66\u90E8\uFF14\u5E74\u751F\u5F8C\u671F\u306B\u306F\u9662\u8A66\u304C\u63A7\u3048\u3066\u3044\u308B\u3057\u3001\uFF13\u5E74\u751F\u5F8C\u671F\u306B\u306F\u5C31\u8077\u6D3B\u52D5\u304C\u63A7\u3048\u3066\u3044\u308B\u3002\u307E\u305F\u3001\uFF19\u6708\u304B\u3089\u59CB\u307E\u308B\u3053\u3068\u306E\u591A\u3044\u6D77\u5916\u306E\u5927\u5B66\u3078\u306E\u7559\u5B66\u306B\u3068\u3063\u3066\u3082\u8DB3\u67B7\u306B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95438548584505344",
    "text" : "\u3066\u3086\u30FC\u304B\u3001\u4EAC\u5927\u6587\u5B66\u90E8\u306F\u3001\u901A\u5E74\u5236\u306E\u5C65\u4FEE\u767B\u9332\u3092\u3059\u3050\u306B\u3067\u3082\u5EC3\u6B62\u3057\u3066\u3001\u30BB\u30DF\u30B9\u30BF\u30FC\uFF08\u5B66\u671F\uFF09\u5236\u3092\u63A1\u7528\u3059\u3079\u304D\u304B\u3068\u601D\u3046\u3002\u5B66\u90E8\uFF14\u5E74\u751F\u5F8C\u671F\u306B\u306F\u9662\u8A66\u304C\u63A7\u3048\u3066\u3044\u308B\u3057\u3001\uFF13\u5E74\u751F\u5F8C\u671F\u306B\u306F\u5C31\u8077\u6D3B\u52D5\u304C\u63A7\u3048\u3066\u3044\u308B\u3002\u307E\u305F\u3001\uFF19\u6708\u304B\u3089\u59CB\u307E\u308B\u3053\u3068\u306E\u591A\u3044\u6D77\u5916\u306E\u5927\u5B66\u3078\u306E\u7559\u5B66\u306B\u3068\u3063\u3066\u3082\u8DB3\u67B7\u306B\u3057\u304B\u306A\u3089\u306A\u3044\u3002\u901A\u5E74\u5236\u306B\u306F\u5F0A\u5BB3\u3057\u304B\u306A\u3044\u3002",
    "id" : 95438548584505344,
    "created_at" : "2011-07-25 10:21:37 +0000",
    "user" : {
      "name" : "\u304A\u3055\u307F\u3093",
      "screen_name" : "LOTUS033",
      "protected" : false,
      "id_str" : "130062075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3780826630\/16dff37ee874cb0b3f1e24139eedb470_normal.jpeg",
      "id" : 130062075,
      "verified" : false
    }
  },
  "id" : 95441261347094528,
  "created_at" : "2011-07-25 10:32:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95337422925209600",
  "text" : "@koketomi \u307E\u3041\u4FE1\u3058\u3055\u305B\u308B\u3068\u9A19\u3059\u3063\u3066\u53D7\u3051\u53D6\u308A\u65B9\u306B\u3088\u308B\u3060\u3051\u3067\u7D50\u69CB\u8FD1\u3057\u3044\u3088\u306D",
  "id" : 95337422925209600,
  "created_at" : "2011-07-25 03:39:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95335837935472640",
  "text" : "\u3066\u304B\u30AF\u30B9\u30CE\u30AD\u524D\u306A\u3093\u3067\u4FEE\u5B66\u65C5\u884C\u751F\uFF08\u95A2\u897F\u5F01\u307D\u3044\u3057\u305F\u3060\u306E\u30BB\u30EB\u30D5\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\uFF1F\uFF09\u304C\u308F\u3089\u308F\u3089\u3044\u3093\u3060\u308D\u3002",
  "id" : 95335837935472640,
  "created_at" : "2011-07-25 03:33:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95335484095594496",
  "text" : "\u4ECA\u671F\u30C6\u30B9\u30C8\u671F\u9593\u306E\u30C6\u30FC\u30DE\u306F\u300C\u305D\u308C\u3089\u3057\u3044\u7B54\u6848\u3001\u305D\u308C\u3089\u3057\u3044\u30EC\u30DD\u30FC\u30C8\u300D\u306B\u6210\u308A\u305D\u3046\u3002",
  "id" : 95335484095594496,
  "created_at" : "2011-07-25 03:32:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95335097078784002",
  "text" : "1200\u5B57\u00D7\uFF13\u3068\u6307\u5B9A\u7121\u3057\u304C\u4E00\u3064\u3002\u3084\u308B\u6C17\u4E00\u3064\u3067\u77AC\u6BBA\u51FA\u6765\u305D\u3046\u3002",
  "id" : 95335097078784002,
  "created_at" : "2011-07-25 03:30:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95334768090157056",
  "text" : "\u305D\u3057\u3066\u6960\u306E\u6728\u524D\u3067\u53CB\u4EBA\u5F85\u3061\u3064\u3064\u73FE\u5B9F\u9003\u907F\u2026\u660E\u65E5\u306E\uFF12\u3001\uFF15\u9650\u3068\u660E\u5F8C\u65E5\u306E\uFF13\u9650\u306E\u30C6\u30B9\u30C8\u9664\u3051\u3070\u3042\u3068\u30EC\u30DD\u30FC\u30C8\uFF14\u3064\u304B\u3002",
  "id" : 95334768090157056,
  "created_at" : "2011-07-25 03:29:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95303151510495232",
  "text" : "\u5358\u4F4D\u6765\u3066\u3082\u6765\u306A\u304F\u3066\u3082\u3084\u3063\u3071\u308A\u3001\u3068\u601D\u3048\u308B\u7A0B\u5EA6\u306E\u51FA\u6765\u3002\u305D\u308C\u3089\u3057\u3044\u3051\u3069\u81EA\u4FE1\u306F\u306A\u3044\u3002",
  "id" : 95303151510495232,
  "created_at" : "2011-07-25 01:23:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95274579819364352",
  "geo" : { },
  "id_str" : "95274904617893888",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30E6\u30FC\u30E2\u30A2\u306E\u30BB\u30F3\u30B9\u306E\u306A\u3044\u4EBA\u306E\u5B58\u5728\u304C\u3059\u3067\u306B\u30B9\u30D1\u30E0",
  "id" : 95274904617893888,
  "in_reply_to_status_id" : 95274579819364352,
  "created_at" : "2011-07-24 23:31:22 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95270427823325185",
  "text" : "\u65E9\u304F\u77E5\u308A\u5408\u3044\u6765\u306A\u3044\u304B\u306A\u30FC",
  "id" : 95270427823325185,
  "created_at" : "2011-07-24 23:13:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95270150760169472",
  "text" : "KU\u30AF\u30E9\u30B9\u30BF\u306E\u4EBA\u306B\u7279\u5B9A\u3055\u308C\u306A\u3044\u3088\u3046\u306B\u9ED9\u3063\u3066\u304A\u3053\u3046",
  "id" : 95270150760169472,
  "created_at" : "2011-07-24 23:12:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95269961982951424",
  "text" : "\u3057\u304B\u3082\u4E8C\u4EBA\u304C\u6570\u5B66\u30AC\u30FC\u30EB\u3063\u3066\u306A\u3093\u3060\u3088\u3002\u7406\u5B66\u90E8\u3063\u3066\u5973\u5B50\u306F\u5E0C\u5C11\u7A2E\u3063\u3066\uFF14\u30B3\u30DE\u3067\u8AAD\u3093\u3060\u305E\u3002",
  "id" : 95269961982951424,
  "created_at" : "2011-07-24 23:11:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95269728750276610",
  "text" : "\u3053\u3093\u306A\u306B\u65E9\u304F\u6765\u3066\u52C9\u5F37\u3057\u3066\u308B\u3075\u308A\u3059\u308B\u306E\u306F\u4E45\u3005\u3060\u304C\u56DE\u308A\u306E\u6570\u4EBA\u7406\u5B66\u90E8\u306E\u4EBA\u304C\u89AA\u3057\u305D\u3046\u3067\u5207\u306A\u3044",
  "id" : 95269728750276610,
  "created_at" : "2011-07-24 23:10:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95269471282921472",
  "text" : "\u304A\u3044\u3057\u3044\u30B3\u30FC\u30D2\u30FC\u2026\u6253\u3061\u9593\u9055\u3044\u3063\u3066\u30EC\u30D9\u30EB\u3058\u3083\u306A\u3044\u306A\u3002",
  "id" : 95269471282921472,
  "created_at" : "2011-07-24 23:09:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95269227476422656",
  "text" : "\u304A\u3044\u3072\u3044Cauthy\u304C\u7121\u304F\u306A\u3063\u305F\u3002",
  "id" : 95269227476422656,
  "created_at" : "2011-07-24 23:08:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95263469145829376",
  "text" : "RT @NISIOISIN_BOT: \u78BA\u304B\u306B\u50D5\u306F\u308F\u304B\u3089\u306A\u3044\u3053\u3068\u3092\u5ACC\u60AA\u3059\u308B\u3002\u305D\u3057\u3066\u5168\u3066\u3092\u7406\u89E3\u3059\u308B\u3053\u3068\u3092\u671B\u3093\u3067\u3044\u308B\u3002\u5168\u3066\u304C\u308F\u304B\u308B\u5834\u6240\u304C\u3042\u308C\u3070\u3001\u9593\u9055\u3044\u306A\u304F\u305D\u3053\u3078\u3068\u5411\u304B\u3046\u3060\u308D\u3046\u2500\u2500\u7406\u4E0D\u5C3D\u3068\u4E0D\u6761\u7406\u304C\u6392\u9664\u3055\u308C\u305F\u305D\u306E\u5834\u6240\u3078\u3001\u8FF7\u3046\u3053\u3068\u306A\u304F\u5411\u304B\u3046\u3060\u308D\u3046\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95263205454123008",
    "text" : "\u78BA\u304B\u306B\u50D5\u306F\u308F\u304B\u3089\u306A\u3044\u3053\u3068\u3092\u5ACC\u60AA\u3059\u308B\u3002\u305D\u3057\u3066\u5168\u3066\u3092\u7406\u89E3\u3059\u308B\u3053\u3068\u3092\u671B\u3093\u3067\u3044\u308B\u3002\u5168\u3066\u304C\u308F\u304B\u308B\u5834\u6240\u304C\u3042\u308C\u3070\u3001\u9593\u9055\u3044\u306A\u304F\u305D\u3053\u3078\u3068\u5411\u304B\u3046\u3060\u308D\u3046\u2500\u2500\u7406\u4E0D\u5C3D\u3068\u4E0D\u6761\u7406\u304C\u6392\u9664\u3055\u308C\u305F\u305D\u306E\u5834\u6240\u3078\u3001\u8FF7\u3046\u3053\u3068\u306A\u304F\u5411\u304B\u3046\u3060\u308D\u3046\u3002",
    "id" : 95263205454123008,
    "created_at" : "2011-07-24 22:44:52 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 95263469145829376,
  "created_at" : "2011-07-24 22:45:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95249973486166017",
  "text" : "\u671D\u304B\u3089\u30B3\u30FC\u30D2\u30FC\u3092\u714E\u308C\u308B\u4F59\u88D5\u3002\u30C6\u30B9\u30C8\u3092\u9664\u3051\u3070\u7406\u60F3\u7684\u3067\u5922\u60F3\u7684\u306A\u6708\u66DC\u306E\u671D\u3060\u306A\u3002",
  "id" : 95249973486166017,
  "created_at" : "2011-07-24 21:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u9078\u629E\u516C\u7406\u3061\u3083\u3093\u30DE\u30B8\u516C\u7406",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/KxFJMPK",
      "expanded_url" : "http:\/\/shindanmaker.com\/140435",
      "display_url" : "shindanmaker.com\/140435"
    } ]
  },
  "geo" : { },
  "id_str" : "95234371400892416",
  "text" : "end313124\u306F\u4ECA\u65E5\u306F&quot;dx\/dt = e^t&quot;\u3092\u89E3\u304D\u307E\u3059\u3067\u3059\u3002 http:\/\/t.co\/KxFJMPK #\u9078\u629E\u516C\u7406\u3061\u3083\u3093\u30DE\u30B8\u516C\u7406",
  "id" : 95234371400892416,
  "created_at" : "2011-07-24 20:50:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95231672135593984",
  "geo" : { },
  "id_str" : "95232009139535872",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306A\u3093\u304B\u899A\u3048\u3066\u305F\u304C\u5B9A\u304B\u3058\u3083\u306A\u3044\u304B\u3089\u306A\u30FC\u3002\u30A2\u30EC\u306A\u3089\u78BA\u8A8D\u3057\u308C\u30FC\u3002",
  "id" : 95232009139535872,
  "in_reply_to_status_id" : 95231672135593984,
  "created_at" : "2011-07-24 20:40:54 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95231054914400258",
  "geo" : { },
  "id_str" : "95231485090611200",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 53\u304F\u3089\u3044\u3060\u3063\u305F\u3088\u306A\u2026\u539F\u6587\u30B3\u30D4\u30FC\u306A\u3044\u306E\u304B\u3044\uFF1F",
  "id" : 95231485090611200,
  "in_reply_to_status_id" : 95231054914400258,
  "created_at" : "2011-07-24 20:38:50 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95230885942669312",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u76EE\u304C\u899A\u3081\u3061\u3083\u3063\u305F\u3002",
  "id" : 95230885942669312,
  "created_at" : "2011-07-24 20:36:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95230342608326657",
  "geo" : { },
  "id_str" : "95230802236944384",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306A\u3093\u3067\u304A\u524D\u4FFA\u3088\u308A\u9045\u304F\u5BDD\u3066\u4FFA\u3088\u308A\u65E9\u304F\u8D77\u304D\u3066\u3093\u3060\u304A\u306F\u3088\u3046\u3002",
  "id" : 95230802236944384,
  "in_reply_to_status_id" : 95230342608326657,
  "created_at" : "2011-07-24 20:36:07 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95141125488263168",
  "geo" : { },
  "id_str" : "95141459317108736",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u3055\u306B\u7791\u60F3\u3057\u3066\u5BDD\u308B\u3068\u3053\u3060\u3063\u305F\u3088\u2026",
  "id" : 95141459317108736,
  "in_reply_to_status_id" : 95141125488263168,
  "created_at" : "2011-07-24 14:41:06 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95139674556874752",
  "text" : "\u7720\u308A\u304B\u3051\u3066\u305F\u306E\u306B\u306A\u30FC\uFF08\u306D\u3080\u3044\u3081",
  "id" : 95139674556874752,
  "created_at" : "2011-07-24 14:34:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5730\u9707\u901F\u5831",
      "screen_name" : "earthquake_jp",
      "indices" : [ 3, 17 ],
      "id_str" : "4104111",
      "id" : 4104111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saigai",
      "indices" : [ 114, 121 ]
    }, {
      "text" : "eqjp",
      "indices" : [ 122, 127 ]
    }, {
      "text" : "earthquake",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "jishin",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95139566855536640",
  "text" : "RT @earthquake_jp: \u3010\u901F\u5831LV1\u301124\u65E523\u664232\u5206\u9803 \u4E09\u91CD\u770C\u718A\u91CE\u5E02\u8FD1\u8FBA(N33.9\/E136.2)\u306B\u3066(\u63A8\u5B9AM4.6)\u306E\u5730\u9707\u304C\u767A\u751F\u3002\u9707\u6E90\u306E\u6DF1\u3055\u306F\u63A8\u5B9A50.5km\u3002( http:\/\/j.mp\/nUabrd ) #saigai #eqjp #earthqu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/labs.transrain.net\/products\/earthquake_jp\/\" rel=\"nofollow\"\u003E\u65E5\u672C\u306E\u5730\u4E0B\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "saigai",
        "indices" : [ 95, 102 ]
      }, {
        "text" : "eqjp",
        "indices" : [ 103, 108 ]
      }, {
        "text" : "earthquake",
        "indices" : [ 109, 120 ]
      }, {
        "text" : "jishin",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95139445082304512",
    "text" : "\u3010\u901F\u5831LV1\u301124\u65E523\u664232\u5206\u9803 \u4E09\u91CD\u770C\u718A\u91CE\u5E02\u8FD1\u8FBA(N33.9\/E136.2)\u306B\u3066(\u63A8\u5B9AM4.6)\u306E\u5730\u9707\u304C\u767A\u751F\u3002\u9707\u6E90\u306E\u6DF1\u3055\u306F\u63A8\u5B9A50.5km\u3002( http:\/\/j.mp\/nUabrd ) #saigai #eqjp #earthquake #jishin",
    "id" : 95139445082304512,
    "created_at" : "2011-07-24 14:33:05 +0000",
    "user" : {
      "name" : "\u5730\u9707\u901F\u5831",
      "screen_name" : "earthquake_jp",
      "protected" : false,
      "id_str" : "4104111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/368358807\/eqjp_normal.png",
      "id" : 4104111,
      "verified" : false
    }
  },
  "id" : 95139566855536640,
  "created_at" : "2011-07-24 14:33:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95139435624140801",
  "text" : "\u5730\u9707\u2026\uFF1F",
  "id" : 95139435624140801,
  "created_at" : "2011-07-24 14:33:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95133546372546560",
  "text" : "\u3042\u30FC\u8A66\u9A13\u306B\u5099\u3048\u3066\u5BDD\u308B\u304B\u306A\u30FC\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 95133546372546560,
  "created_at" : "2011-07-24 14:09:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95100999735328770",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 95100999735328770,
  "created_at" : "2011-07-24 12:00:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u307A\u3067\u3043",
      "screen_name" : "copedy",
      "indices" : [ 3, 10 ],
      "id_str" : "152242373",
      "id" : 152242373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95093616116105216",
  "text" : "RT @copedy: \u3010\u203B\u3044\u3064\u3082TL\u306B\u3044\u308B\u4EBA\u3078\u203B\u3011\n2011\u5E743\u6708\u306B\u767A\u8868\u3055\u308C\u305F\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u5229\u7528\u52D5\u5411\u8ABF\u67FB\u306B\u3088\u308B\u3068\u3001\u65E5\u672C\u306ETwitter\u30E6\u30FC\u30B6\u30FC\u306E\u6708\u9593\u5E73\u5747\u5229\u7528\u6642\u9593\u306F26\u5206\u3002\u3064\u307E\u308A\u3001\u4E00\u65E5\u3042\u305F\u308A\u306ETwitter\u5229\u7528\u6642\u9593\u306F\u2026\u202652\u79D2\u3002\u304A\u524D\u3089\u76F8\u5F53\u30E4\u30D0\u3044\u3002\nhttp:\/\/bit.l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67209893534375936",
    "text" : "\u3010\u203B\u3044\u3064\u3082TL\u306B\u3044\u308B\u4EBA\u3078\u203B\u3011\n2011\u5E743\u6708\u306B\u767A\u8868\u3055\u308C\u305F\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u5229\u7528\u52D5\u5411\u8ABF\u67FB\u306B\u3088\u308B\u3068\u3001\u65E5\u672C\u306ETwitter\u30E6\u30FC\u30B6\u30FC\u306E\u6708\u9593\u5E73\u5747\u5229\u7528\u6642\u9593\u306F26\u5206\u3002\u3064\u307E\u308A\u3001\u4E00\u65E5\u3042\u305F\u308A\u306ETwitter\u5229\u7528\u6642\u9593\u306F\u2026\u202652\u79D2\u3002\u304A\u524D\u3089\u76F8\u5F53\u30E4\u30D0\u3044\u3002\nhttp:\/\/bit.ly\/mCqRqe",
    "id" : 67209893534375936,
    "created_at" : "2011-05-08 12:51:01 +0000",
    "user" : {
      "name" : "\u3053\u307A\u3067\u3043",
      "screen_name" : "copedy",
      "protected" : false,
      "id_str" : "152242373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428845627313647616\/yx6wMaK6_normal.jpeg",
      "id" : 152242373,
      "verified" : false
    }
  },
  "id" : 95093616116105216,
  "created_at" : "2011-07-24 11:30:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728\u79C1\u304C\u3046\u3044\u306B\u3083\u3093\u3060\u2728",
      "screen_name" : "ui_nyan",
      "indices" : [ 3, 11 ],
      "id_str" : "14052309",
      "id" : 14052309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95089055573880832",
  "text" : "RT @ui_nyan: \u30C6\u30EC\u6771\u4F1D\u8AAC\uFF57\uFF57\uFF57\uFF57\uFF57 http:\/\/twitpic.com\/5uzvcb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95023626864168960",
    "text" : "\u30C6\u30EC\u6771\u4F1D\u8AAC\uFF57\uFF57\uFF57\uFF57\uFF57 http:\/\/twitpic.com\/5uzvcb",
    "id" : 95023626864168960,
    "created_at" : "2011-07-24 06:52:52 +0000",
    "user" : {
      "name" : "\u2728\u79C1\u304C\u3046\u3044\u306B\u3083\u3093\u3060\u2728",
      "screen_name" : "ui_nyan",
      "protected" : false,
      "id_str" : "14052309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602622688679473152\/ls3X2nXo_normal.jpg",
      "id" : 14052309,
      "verified" : false
    }
  },
  "id" : 95089055573880832,
  "created_at" : "2011-07-24 11:12:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95072070244900864",
  "text" : "\u306A\u3093\u3067\u3053\u3093\u306A\u30B5\u30B6\u30A8\u3055\u3093\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306A\u306E\u3055",
  "id" : 95072070244900864,
  "created_at" : "2011-07-24 10:05:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "integral88",
      "indices" : [ 3, 14 ],
      "id_str" : "113386278",
      "id" : 113386278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95034874678874112",
  "text" : "RT @integral88: \u3053\u306E\u307E\u307E\u6642\u304C\u6B62\u307E\u3063\u3066\u304F\u308C\u305F\u3089\u3044\u3044\u306E\u306B\u30FB\u30FB\u30FB\u30FB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38275646736179200",
    "text" : "\u3053\u306E\u307E\u307E\u6642\u304C\u6B62\u307E\u3063\u3066\u304F\u308C\u305F\u3089\u3044\u3044\u306E\u306B\u30FB\u30FB\u30FB\u30FB",
    "id" : 38275646736179200,
    "created_at" : "2011-02-17 16:36:39 +0000",
    "user" : {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "integral88",
      "protected" : false,
      "id_str" : "113386278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2155898850\/twipple1335093302047_normal.jpg",
      "id" : 113386278,
      "verified" : false
    }
  },
  "id" : 95034874678874112,
  "created_at" : "2011-07-24 07:37:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "integral7890",
      "indices" : [ 3, 16 ],
      "id_str" : "176283956",
      "id" : 176283956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95034855301197824",
  "text" : "RT @integral7890: \uFF8C\uFF9E\uFF70\uFF9D\uFF8C\uFF9E\uFF9D\u91C8\u8FE6\uFF57\uFF57\uFF57\uFF8C\uFF9E\uFF8C\uFF9E\uFF9D\uFF8C\uFF9E\uFF70\uFF9D\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94875950398976000",
    "text" : "\uFF8C\uFF9E\uFF70\uFF9D\uFF8C\uFF9E\uFF9D\u91C8\u8FE6\uFF57\uFF57\uFF57\uFF8C\uFF9E\uFF8C\uFF9E\uFF9D\uFF8C\uFF9E\uFF70\uFF9D\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
    "id" : 94875950398976000,
    "created_at" : "2011-07-23 21:06:03 +0000",
    "user" : {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "integral7890",
      "protected" : false,
      "id_str" : "176283956",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_2_normal.png",
      "id" : 176283956,
      "verified" : false
    }
  },
  "id" : 95034855301197824,
  "created_at" : "2011-07-24 07:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "intgrllllllllll",
      "indices" : [ 3, 19 ],
      "id_str" : "288580970",
      "id" : 288580970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95034828742860800",
  "text" : "RT @intgrllllllllll: \uFF62\u3044\u3093\u3066\u3050\u3089\u308B\uFF63\u3067\u30E6\u30FC\u30B6\u30FC\u691C\u7D22\u3057\u305F\u3089\u3001\uFF62\uFF8C\uFF9E\uFF70\uFF9D\uFF8C\uFF9E\uFF9D\u91C8\u8FE6\uFF57\uFF57\uFF57\uFF8C\uFF9E\uFF8C\uFF9E\uFF9D\uFF8C\uFF9E\uFF70\uFF9D\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF63\u3060\u3051\u3067700\u8FD1\u304F\u545F\u3044\u3066\u308B\u57A2\u3068\u304B\u3001\u6628\u5E742\u6708\u306E\u767B\u9332\u4EE5\u964D\uFF62\u3053\u306E\u307E\u307E\u6642\u304C\u6B62\u307E\u308C\u3070\u3044\u3044\u306E\u306B\u2026\u2026\uFF63\u3063\u3066\uFF12\u30F6\u6708\u3050\u3089\u3044\u524D\u306B\u3057\u305F\uFF11\u30C4\u30A4\u30FC\u30C8\u3060\u3051\u306E\u57A2\u3068\u304B\u304C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95033222118912000",
    "text" : "\uFF62\u3044\u3093\u3066\u3050\u3089\u308B\uFF63\u3067\u30E6\u30FC\u30B6\u30FC\u691C\u7D22\u3057\u305F\u3089\u3001\uFF62\uFF8C\uFF9E\uFF70\uFF9D\uFF8C\uFF9E\uFF9D\u91C8\u8FE6\uFF57\uFF57\uFF57\uFF8C\uFF9E\uFF8C\uFF9E\uFF9D\uFF8C\uFF9E\uFF70\uFF9D\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF63\u3060\u3051\u3067700\u8FD1\u304F\u545F\u3044\u3066\u308B\u57A2\u3068\u304B\u3001\u6628\u5E742\u6708\u306E\u767B\u9332\u4EE5\u964D\uFF62\u3053\u306E\u307E\u307E\u6642\u304C\u6B62\u307E\u308C\u3070\u3044\u3044\u306E\u306B\u2026\u2026\uFF63\u3063\u3066\uFF12\u30F6\u6708\u3050\u3089\u3044\u524D\u306B\u3057\u305F\uFF11\u30C4\u30A4\u30FC\u30C8\u3060\u3051\u306E\u57A2\u3068\u304B\u304C\u3044\u3066\u3001\u3044\u3093\u3066\u3050\u3089\u308B\u3068\u3044\u3046\u540D\u524D\u306E\u884C\u304F\u672B\u3092\u5606\u3044\u3066\u3044\u308B\u3002",
    "id" : 95033222118912000,
    "created_at" : "2011-07-24 07:31:00 +0000",
    "user" : {
      "name" : "\u3044\u3093\u3066\u3050\u3089\u308B",
      "screen_name" : "intgrllllllllll",
      "protected" : false,
      "id_str" : "288580970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421366363559428096\/QAJBPTpm_normal.jpeg",
      "id" : 288580970,
      "verified" : false
    }
  },
  "id" : 95034828742860800,
  "created_at" : "2011-07-24 07:37:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94976526008844288",
  "text" : "\u3055\u3041\u9078\u629E\u516C\u7406\u3068\u6226\u304A\u3046",
  "id" : 94976526008844288,
  "created_at" : "2011-07-24 03:45:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94966216090861568",
  "text" : "\u9045\u304B\u3063\u305F\u3067\u3059\u3057\u30FB\u30FB\u30FB",
  "id" : 94966216090861568,
  "created_at" : "2011-07-24 03:04:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94966071085379584",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 94966071085379584,
  "created_at" : "2011-07-24 03:04:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94958236272300034",
  "text" : "RT @JOJO_math: \u3042\u2026\u3042\u308A\u306E\u307E\u307E\u3000\u4ECA\u8D77\u3053\u3063\u305F\u4E8B\u3092\u8A71\u3059\u305C\uFF01\u300E\u304A\u308C\u306F\u89AA\u306B\u300E\u6570\u5B66\u30AC\u30FC\u30EB\u300F\u306E\u8CB7\u3044\u7269\u3092\u983C\u3093\u3060\u3068\u601D\u3063\u305F\u3089\u3044\u3064\u306E\u307E\u306B\u304B\u300E\u6570\u5B66\u5973\u5B50\u300F\u3092\u53D7\u3051\u53D6\u3063\u3066\u3044\u305F\u300F\u306A\u2026\u4F55\u3092\u8A00\u3063\u3066\u3044\u308B\u306E\u304B\uFF08\u7565\uFF09\u50AC\u7720\u8853\u3060\u3068\u304B\u8D85\u30B9\u30D4\u30FC\u30C9\u3060\u3068\u304B\u305D\u3093\u306A\u30C1\u30E3\u30C1\u306A\u3082\u3093\u3058\u3083\u3042\u65AD\u3058\u3066\u306D\u3048\u3000\u3082\u3063\u3068\u6050\u308D\u3057\u3044\u76F4\u8A33 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94956983551139841",
    "text" : "\u3042\u2026\u3042\u308A\u306E\u307E\u307E\u3000\u4ECA\u8D77\u3053\u3063\u305F\u4E8B\u3092\u8A71\u3059\u305C\uFF01\u300E\u304A\u308C\u306F\u89AA\u306B\u300E\u6570\u5B66\u30AC\u30FC\u30EB\u300F\u306E\u8CB7\u3044\u7269\u3092\u983C\u3093\u3060\u3068\u601D\u3063\u305F\u3089\u3044\u3064\u306E\u307E\u306B\u304B\u300E\u6570\u5B66\u5973\u5B50\u300F\u3092\u53D7\u3051\u53D6\u3063\u3066\u3044\u305F\u300F\u306A\u2026\u4F55\u3092\u8A00\u3063\u3066\u3044\u308B\u306E\u304B\uFF08\u7565\uFF09\u50AC\u7720\u8853\u3060\u3068\u304B\u8D85\u30B9\u30D4\u30FC\u30C9\u3060\u3068\u304B\u305D\u3093\u306A\u30C1\u30E3\u30C1\u306A\u3082\u3093\u3058\u3083\u3042\u65AD\u3058\u3066\u306D\u3048\u3000\u3082\u3063\u3068\u6050\u308D\u3057\u3044\u76F4\u8A33\u306E\u7247\u9C57\u3092\u5473\u308F\u3063\u305F\u305C\u2026",
    "id" : 94956983551139841,
    "created_at" : "2011-07-24 02:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 94958236272300034,
  "created_at" : "2011-07-24 02:33:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94954867768037376",
  "text" : "\u8D77\u304D\u305F\u3002",
  "id" : 94954867768037376,
  "created_at" : "2011-07-24 02:19:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94775170761363457",
  "text" : "RT @NISIOISIN_BOT: \u305D\u308C\u3068\u306A\u304F\u53CB\u597D\u7684\u306B\u3055\u308A\u3052\u306A\u304F\u6392\u4ED6\u7684\u306B\u3001\u9069\u5EA6\u306B\u89AA\u5BC6\u306B\u9069\u5F53\u306B\u5BFE\u7ACB\u3059\u308B\u3002\u307C\u304F\u306E\u4E3B\u7FA9\u3067\u3059\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94773795323256832",
    "text" : "\u305D\u308C\u3068\u306A\u304F\u53CB\u597D\u7684\u306B\u3055\u308A\u3052\u306A\u304F\u6392\u4ED6\u7684\u306B\u3001\u9069\u5EA6\u306B\u89AA\u5BC6\u306B\u9069\u5F53\u306B\u5BFE\u7ACB\u3059\u308B\u3002\u307C\u304F\u306E\u4E3B\u7FA9\u3067\u3059\u3088",
    "id" : 94773795323256832,
    "created_at" : "2011-07-23 14:20:08 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 94775170761363457,
  "created_at" : "2011-07-23 14:25:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "indices" : [ 3, 16 ],
      "id_str" : "96289411",
      "id" : 96289411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94774009245335553",
  "text" : "RT @d_v_osorezan: \u300C\u306F\u3044\u3001\u6CD5\u5B9A\u901F\u5EA6\uFF15\u30AD\u30ED\u30AA\u30FC\u30D0\u30FC\u306D\u3002\u514D\u8A31\u8A3C\u898B\u305B\u3066\u300D\n\u300C\u304A\u304A\u3081\u306B\u898B\u3066\u3082\u3089\u3048\u307E\u305B\u3093\u304B\u306D\u300D\n\u300C\u3058\u3083\u3042\uFF11\uFF10\u30AD\u30ED\u30AA\u30FC\u30D0\u30FC\u306B\u3059\u308B\u304B\uFF1F\u300D\n\u300C\u305D\u3046\u3044\u3046\u610F\u5473\u3058\u3083\u306A\u3044\u3067\u3059\u300D\n\u300C\u3060\u3063\u305F\u3089\u514D\u8A31\u8A3C\uFF15\u679A\u898B\u305B\u3066\u300D\n\u300C\u305D\u3046\u3044\u3046\u610F\u5473\u3067\u3082\u306A\u3044\u3067\u3059\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94767787125387264",
    "text" : "\u300C\u306F\u3044\u3001\u6CD5\u5B9A\u901F\u5EA6\uFF15\u30AD\u30ED\u30AA\u30FC\u30D0\u30FC\u306D\u3002\u514D\u8A31\u8A3C\u898B\u305B\u3066\u300D\n\u300C\u304A\u304A\u3081\u306B\u898B\u3066\u3082\u3089\u3048\u307E\u305B\u3093\u304B\u306D\u300D\n\u300C\u3058\u3083\u3042\uFF11\uFF10\u30AD\u30ED\u30AA\u30FC\u30D0\u30FC\u306B\u3059\u308B\u304B\uFF1F\u300D\n\u300C\u305D\u3046\u3044\u3046\u610F\u5473\u3058\u3083\u306A\u3044\u3067\u3059\u300D\n\u300C\u3060\u3063\u305F\u3089\u514D\u8A31\u8A3C\uFF15\u679A\u898B\u305B\u3066\u300D\n\u300C\u305D\u3046\u3044\u3046\u610F\u5473\u3067\u3082\u306A\u3044\u3067\u3059\u300D",
    "id" : 94767787125387264,
    "created_at" : "2011-07-23 13:56:15 +0000",
    "user" : {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "protected" : false,
      "id_str" : "96289411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3457427933\/e9c1859b77927509e49bcdd8ea328bdb_normal.jpeg",
      "id" : 96289411,
      "verified" : false
    }
  },
  "id" : 94774009245335553,
  "created_at" : "2011-07-23 14:20:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 8, 20 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94766777426378752",
  "text" : "\u3042\u3089\u7D20\u6575 RT @modestrella: \u305D\u3046\u3044\u3048\u3070\u6614\u306F\u604B\u7169\u3044\u3057\u3066\u308B\u6642\u307B\u3069\u3001\u591C\u306E\u7406\u60F3\u90F7\u306E\u5C55\u671B\u53F0\u306B\u884C\u3063\u3066\u305F\u304B\u3082\u3002\u6708\u660E\u304B\u308A\u306E\u6D77\u898B\u306A\u304C\u3089\u30E1\u30FC\u30EB\u306E\u8FD4\u4FE1\u3068\u304B\u5F85\u3063\u305F\u308A\u3002\u61D0\u304B\u3057\u3044\u306A\u3041\u3002@\u9D28\u5DDD",
  "id" : 94766777426378752,
  "created_at" : "2011-07-23 13:52:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94738568496431104",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 94738568496431104,
  "created_at" : "2011-07-23 12:00:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    }, {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 15, 25 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94697527613460480",
  "geo" : { },
  "id_str" : "94697740323393536",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro @tadash126 \u4F50\u4F2F\u5148\u751F\u306E\u30BC\u30DF\u306B\u30B5\u30FC\u30AF\u30EB\u306E\u5148\u8F29\u304C\u3044\u307E\u3059\u3088\u3046",
  "id" : 94697740323393536,
  "in_reply_to_status_id" : 94697527613460480,
  "created_at" : "2011-07-23 09:17:55 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94657803683246080",
  "text" : "\u6BD4\u8F03\u6559\u80B2\u30EC\u30DD\u534A\u5206\u7D42\u308F\u3063\u305F\u3002\u6848\u5916\uFF12\uFF10\uFF10\uFF10\u5B57\u3063\u3066\u3059\u3050\u57CB\u307E\u308B\u3082\u306E\u306D\u30FC\u3002",
  "id" : 94657803683246080,
  "created_at" : "2011-07-23 06:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94639273361412097",
  "text" : "\u81EA\u5206\u306E\u597D\u304D\u306A\u3082\u306E\u304C\u7206\u767A\u3057\u3066\u308B\u3068\u60B2\u3057\u3044\u5272\u306B\u3001\u5ACC\u3044\u306A\u7269\u3067\u3082\u7206\u767A\u3057\u308D\u3068\u3082\u601D\u308F\u306A\u3044\u305B\u3044\u3067\u898B\u3066\u3066\u6C17\u6301\u3061\u826F\u304F\u306A\u3044\u306E\u3067\u3057\u305F\u3002",
  "id" : 94639273361412097,
  "created_at" : "2011-07-23 05:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94639001918640128",
  "text" : "\u7D50\u5C40\u30DC\u30E0\u30C3\u30BF\u2015\u30A2\u30F3\u30D5\u30A9\u30ED\u30FC\u3057\u3061\u3083\u3063\u305F\u3002\u7206\u767A\u3057\u308D\u3063\u3066\u8A00\u8449\u306E\u62D2\u7D76\u611F\u304C\u3069\u3046\u306B\u3082\u30C0\u30E1\u3060\u3002",
  "id" : 94639001918640128,
  "created_at" : "2011-07-23 05:24:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94629779357175810",
  "geo" : { },
  "id_str" : "94630099986563072",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u4ECA\u65E5\u306F\u304A\u4F11\u307F\uFF1F",
  "id" : 94630099986563072,
  "in_reply_to_status_id" : 94629779357175810,
  "created_at" : "2011-07-23 04:49:08 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94629971145932800",
  "text" : "\u4ECA\u65E5\u306F\u30EC\u30DD\u30FC\u30C83\u3064\u7247\u3065\u3051\u3066\u65E5\u4ED8\u304C\u5909\u308F\u308B\u524D\u306B\u5BDD\u308B\u3001\u3092\u76EE\u6A19\u306B\u3057\u3088\u3046\uFF01\u2026\u304B\u306A\u3041\u30FB\u30FB\u30FB\u3002",
  "id" : 94629971145932800,
  "created_at" : "2011-07-23 04:48:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94629777562013697",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3002\u307E\u30412\u6642\u9593\u304F\u3089\u3044\u524D\u304B\u3089\u8D77\u304D\u3066\u308B\u3093\u3060\u3051\u3069\u3055\u30FC\u3002",
  "id" : 94629777562013697,
  "created_at" : "2011-07-23 04:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94629681059475456",
  "text" : "\u3061\u3087\u3063\u3068\u9045\u3044\u3051\u3069\u304A\u663C\u3092\u4F5C\u308D\u3046\u3002\u30B4\u30FC\u30E4\u3068\u30C4\u30CA\u306E\u30D1\u30B9\u30BF\u3002\u6700\u8FD1\u30B4\u30FC\u30E4\u304C\u304A\u3044\u3057\u3044\u3002",
  "id" : 94629681059475456,
  "created_at" : "2011-07-23 04:47:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94058223623086080",
  "geo" : { },
  "id_str" : "94058443958267904",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u308C\u3082\u3042\u308A\u3060\u308D\u3046\u3088\u3002\u73FE\u5B9F\u3002\u3002\u3002",
  "id" : 94058443958267904,
  "in_reply_to_status_id" : 94058223623086080,
  "created_at" : "2011-07-21 14:57:35 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94058225623777280",
  "text" : "\u3068\u304B\u8A00\u3044\u3064\u3064\u3069\u308C\u3082\u307E\u3060\u307E\u3060\u3002",
  "id" : 94058225623777280,
  "created_at" : "2011-07-21 14:56:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94058006978891776",
  "text" : "\u82F1\u6570C\u304F\u3089\u3044\u3067\u304D\u306A\u3044\u3068\u308D\u304F\u306B\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u3082\u3067\u304D\u306A\u3044\uFF08\uFF77\uFF98\uFF6F",
  "id" : 94058006978891776,
  "created_at" : "2011-07-21 14:55:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94056707923247104",
  "text" : "\u7D4C\u6E08\u3068\u304B\u91D1\u878D\uFF08\u5DE5\u5B66\uFF09\u3068\u304B\u3082\u89E6\u3063\u3066\u307F\u3088\u3046\u304B\u306A\u30FC\u2026\u3068\u8A66\u9A13\u524D\u306B\u306A\u308B\u3068\u95A2\u4FC2\u306A\u3044\u5B66\u554F\u9063\u308A\u305F\u304F\u306A\u308B\u75C5\u304C\u304C\u304C\u3002",
  "id" : 94056707923247104,
  "created_at" : "2011-07-21 14:50:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94055849714139136",
  "text" : "\u7A4D\u5206\u533A\u9593\u7684\u306A\u610F\u5473\u5408\u3044\u3067\u3002",
  "id" : 94055849714139136,
  "created_at" : "2011-07-21 14:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94055696324235266",
  "text" : "\u7A4D\u3076\u3093\u5B66\u90E8\u306A\u3089\u533A\u5207\u308A\u306F\u5927\u4E8B\u3060\u3088\u306A\uFF08\uFF77\uFF98\uFF6F",
  "id" : 94055696324235266,
  "created_at" : "2011-07-21 14:46:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94055352991092736",
  "text" : "RT @magokoro84: a faculty of literature\u3092\u6587\u5B66\u90E8\u3068\u8A33\u3059\u306E\u306F\u30CA\u30F3\u30BB\u30F3\u30B9\u3002\u305D\u3082\u305D\u3082\u300C\u6587\u5B66\u300D\u306F\u5B66\u554F\u306E\u540D\u524D\u3067\u306A\u304F\u82B8\u8853\u4F5C\u54C1\u306E\u7DCF\u79F0\u306A\u306E\u3067\u4EBA\u6587\u79D1\u5B66\u90E8\u3068\u3044\u3046\u306E\u304C\u4E00\u756A\u3057\u3063\u304F\u308A\u304F\u308B\u3002\u305F\u3060\u591A\u304F\u306E\u4EBA\u304C\uFF08\u305D\u3057\u3066\u591A\u304F\u306E\u6587\u5B66\u90E8\u751F\u3055\u3048\u3082\uFF09\u300C\u6587\u5B66\u30FB\u90E8\u300D\u3067\u533A\u5207\u3063\u3066\u308B\u304B\u3089 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94049976035979265",
    "text" : "a faculty of literature\u3092\u6587\u5B66\u90E8\u3068\u8A33\u3059\u306E\u306F\u30CA\u30F3\u30BB\u30F3\u30B9\u3002\u305D\u3082\u305D\u3082\u300C\u6587\u5B66\u300D\u306F\u5B66\u554F\u306E\u540D\u524D\u3067\u306A\u304F\u82B8\u8853\u4F5C\u54C1\u306E\u7DCF\u79F0\u306A\u306E\u3067\u4EBA\u6587\u79D1\u5B66\u90E8\u3068\u3044\u3046\u306E\u304C\u4E00\u756A\u3057\u3063\u304F\u308A\u304F\u308B\u3002\u305F\u3060\u591A\u304F\u306E\u4EBA\u304C\uFF08\u305D\u3057\u3066\u591A\u304F\u306E\u6587\u5B66\u90E8\u751F\u3055\u3048\u3082\uFF09\u300C\u6587\u5B66\u30FB\u90E8\u300D\u3067\u533A\u5207\u3063\u3066\u308B\u304B\u3089\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u3044\u3002",
    "id" : 94049976035979265,
    "created_at" : "2011-07-21 14:23:56 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 94055352991092736,
  "created_at" : "2011-07-21 14:45:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitPic",
      "screen_name" : "TwitPic",
      "indices" : [ 57, 65 ],
      "id_str" : "12925072",
      "id" : 12925072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 52 ],
      "url" : "http:\/\/t.co\/1vbiaVk",
      "expanded_url" : "http:\/\/twitpic.com\/5tfzg8",
      "display_url" : "twitpic.com\/5tfzg8"
    } ]
  },
  "geo" : { },
  "id_str" : "94041965917777920",
  "text" : "RT @kouennnoyuugu: \u3082\u3046\u3001\u3046\u3061\u306E\u9AD8\u6821\u3060\u3081\u3060\u308F\n http:\/\/t.co\/1vbiaVk via @twitpic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TwitPic",
        "screen_name" : "TwitPic",
        "indices" : [ 38, 46 ],
        "id_str" : "12925072",
        "id" : 12925072
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 33 ],
        "url" : "http:\/\/t.co\/1vbiaVk",
        "expanded_url" : "http:\/\/twitpic.com\/5tfzg8",
        "display_url" : "twitpic.com\/5tfzg8"
      } ]
    },
    "geo" : { },
    "id_str" : "94041188742594560",
    "text" : "\u3082\u3046\u3001\u3046\u3061\u306E\u9AD8\u6821\u3060\u3081\u3060\u308F\n http:\/\/t.co\/1vbiaVk via @twitpic",
    "id" : 94041188742594560,
    "created_at" : "2011-07-21 13:49:01 +0000",
    "user" : {
      "name" : "TAKU\uFF08\u3075\u3089\u304F\u305F\u304F\uFF09",
      "screen_name" : "phy_neko",
      "protected" : false,
      "id_str" : "230889478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578561851400704000\/KFwEbjVq_normal.png",
      "id" : 230889478,
      "verified" : false
    }
  },
  "id" : 94041965917777920,
  "created_at" : "2011-07-21 13:52:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94028535756361729",
  "geo" : { },
  "id_str" : "94037390246686720",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u307E\u3041\u30EC\u30DD\u30FC\u30C8\u591A\u3081\u306A\u306E\u3067\u5927\u4E08\u592B\u3060\u3068\u601D\u3044\u307E\u3059\u304C\u30FC",
  "id" : 94037390246686720,
  "in_reply_to_status_id" : 94028535756361729,
  "created_at" : "2011-07-21 13:33:55 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94034082589188096",
  "geo" : { },
  "id_str" : "94037213628743680",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u30C1\u30FC\u30C8\u3058\u3083\u306A\u3044\u3067\u3059\u3088\u3045\u300213\u9762\u3068\u304B\u521D\u3081\u3066\u3067\u3059\u3057\u3002",
  "id" : 94037213628743680,
  "in_reply_to_status_id" : 94034082589188096,
  "created_at" : "2011-07-21 13:33:13 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94025909035732992",
  "text" : "\u56FD\u58EB13\u9762\u30AD\u30BF\uFF013\u6253\u3061\u3060\u3051\u3069\u306A\u30FC\u3002\u3066\u304B\u8A66\u9A13\u524D\u306B\u4F55\u3084\u3063\u3066\u3093\u3060\u308D\u3046\u3002 http:\/\/tenhou.net\/0\/?log=2011072121gm-0059-0000-43583a1a&tw=2",
  "id" : 94025909035732992,
  "created_at" : "2011-07-21 12:48:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94013836365012992",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 94013836365012992,
  "created_at" : "2011-07-21 12:00:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93941788695461888",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6728\uFF15\u30EC\u30DD\u30FC\u30C8\uFF13\u3064\u3067\u3057\u305F\u3088\u3045\u2026",
  "id" : 93941788695461888,
  "created_at" : "2011-07-21 07:14:02 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93941528661196800",
  "text" : "\u671D\u30B3\u30CD\u30AF\u30C8\u805E\u3044\u305F\u3089\u8033\u304B\u3089\u96E2\u308C\u306A\u3044\u2026",
  "id" : 93941528661196800,
  "created_at" : "2011-07-21 07:13:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5F71\u4E95\u516C\u5F66@\u75C2\u3060\u3089\u3051\u306E\u7F8A\u9054\u306E\u6C88\u9ED9",
      "screen_name" : "kagaykimihiko",
      "indices" : [ 3, 17 ],
      "id_str" : "97677398",
      "id" : 97677398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93880360710045696",
  "text" : "RT @kagaykimihiko: \u3010\u590F\u4F11\u307F\u306B\u601D\u3046\u4E8B\u5E74\u9F62\u5225\u4E00\u89A7\u3011\u793E\u4F1A\u4EBA\uFF1A\u5B66\u751F\u306F\u3044\u3044\u306A\u3000\u5927\u5B66\u751F\uFF1A\u91D1\u304C\u7121\u3044\u3088\u3000\u9AD8\u6821\u751F\uFF1A\u3072\u3068\u590F\u306E\u7D4C\u9A13\u3068\u304B\u51FA\u6765\u308B\u304B\u306A\u3000\u4E2D\u5B66\u751F\uFF1A\u90E8\u6D3B\u30C0\u30EB\u30A4\u3000\u5C0F\u5B66\u751F\uFF08\u9AD8\u5B66\u5E74\uFF09\uFF1A\u5BBF\u984C\u3081\u3093\u3069\u304F\u3055\u3044\u3000\u5C0F\u5B66\u751F\uFF08\u4F4E\u5B66\u5E74\uFF09\uFF1A\u4ECA\u65E5\u306F\u8749\u6355\u308B\uFF57\uFF57\uFF57\uFF57\u660E\u65E5\u3082\u8749\u6355\u308B\uFF57\uFF57\uFF57\uFF57\u660E\u5F8C\u65E5\u3082\u8749\u6355\u308B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93616130400325632",
    "text" : "\u3010\u590F\u4F11\u307F\u306B\u601D\u3046\u4E8B\u5E74\u9F62\u5225\u4E00\u89A7\u3011\u793E\u4F1A\u4EBA\uFF1A\u5B66\u751F\u306F\u3044\u3044\u306A\u3000\u5927\u5B66\u751F\uFF1A\u91D1\u304C\u7121\u3044\u3088\u3000\u9AD8\u6821\u751F\uFF1A\u3072\u3068\u590F\u306E\u7D4C\u9A13\u3068\u304B\u51FA\u6765\u308B\u304B\u306A\u3000\u4E2D\u5B66\u751F\uFF1A\u90E8\u6D3B\u30C0\u30EB\u30A4\u3000\u5C0F\u5B66\u751F\uFF08\u9AD8\u5B66\u5E74\uFF09\uFF1A\u5BBF\u984C\u3081\u3093\u3069\u304F\u3055\u3044\u3000\u5C0F\u5B66\u751F\uFF08\u4F4E\u5B66\u5E74\uFF09\uFF1A\u4ECA\u65E5\u306F\u8749\u6355\u308B\uFF57\uFF57\uFF57\uFF57\u660E\u65E5\u3082\u8749\u6355\u308B\uFF57\uFF57\uFF57\uFF57\u660E\u5F8C\u65E5\u3082\u8749\u6355\u308B\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
    "id" : 93616130400325632,
    "created_at" : "2011-07-20 09:39:59 +0000",
    "user" : {
      "name" : "\u5F71\u4E95\u516C\u5F66@\u75C2\u3060\u3089\u3051\u306E\u7F8A\u9054\u306E\u6C88\u9ED9",
      "screen_name" : "kagaykimihiko",
      "protected" : false,
      "id_str" : "97677398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571963502904000512\/DdEEX3cM_normal.jpeg",
      "id" : 97677398,
      "verified" : false
    }
  },
  "id" : 93880360710045696,
  "created_at" : "2011-07-21 03:09:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93866088118497280",
  "geo" : { },
  "id_str" : "93880287674634241",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u6728\u66DC\u3060\u304C",
  "id" : 93880287674634241,
  "in_reply_to_status_id" : 93866088118497280,
  "created_at" : "2011-07-21 03:09:39 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93865600203505664",
  "geo" : { },
  "id_str" : "93865803811799041",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u6B62\u3081\u3066",
  "id" : 93865803811799041,
  "in_reply_to_status_id" : 93865600203505664,
  "created_at" : "2011-07-21 02:12:06 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93865357583982593",
  "geo" : { },
  "id_str" : "93865447358857218",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u3046\u306A\u30FC",
  "id" : 93865447358857218,
  "in_reply_to_status_id" : 93865357583982593,
  "created_at" : "2011-07-21 02:10:41 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93865098220810241",
  "geo" : { },
  "id_str" : "93865209768321024",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn 11\u6642\u3060\u304C",
  "id" : 93865209768321024,
  "in_reply_to_status_id" : 93865098220810241,
  "created_at" : "2011-07-21 02:09:44 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93864326787633152",
  "geo" : { },
  "id_str" : "93864981086470144",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u8D77\u304D\u305F\u3093\u3060\u3088\u3063",
  "id" : 93864981086470144,
  "in_reply_to_status_id" : 93864326787633152,
  "created_at" : "2011-07-21 02:08:50 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93864065155342336",
  "text" : "\u7720\u3044\u2026",
  "id" : 93864065155342336,
  "created_at" : "2011-07-21 02:05:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93681520274976768",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u30EC\u30DD\u30FC\u30C8\u304C\u7ACB\u3066\u8FBC\u3080\u304B\u3082\u3002\u96C6\u5408\u4F4D\u76F8\u306F\u65E5\u66DC\u306B\u683C\u95D8\u3059\u308B\u4E88\u5B9A\u3002",
  "id" : 93681520274976768,
  "created_at" : "2011-07-20 13:59:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93673644789743616",
  "text" : "RT @JOJO_math: \u3053\u3044\u3064\u306B\u56DB\u8272\u5B9A\u7406\u306E\u8A3C\u660E\u3092\u30BB\u30DF\u30CA\u30FC\u3067\u767A\u8868\u3055\u305B\u3066\u3084\u308A\u305F\u3044\u3093\u3067\u3059\u304C\u3000\u304B\u307E\u3044\u307E\u305B\u3093\u306D\u30C3\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93673527261147136",
    "text" : "\u3053\u3044\u3064\u306B\u56DB\u8272\u5B9A\u7406\u306E\u8A3C\u660E\u3092\u30BB\u30DF\u30CA\u30FC\u3067\u767A\u8868\u3055\u305B\u3066\u3084\u308A\u305F\u3044\u3093\u3067\u3059\u304C\u3000\u304B\u307E\u3044\u307E\u305B\u3093\u306D\u30C3\uFF01\uFF01",
    "id" : 93673527261147136,
    "created_at" : "2011-07-20 13:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 93673644789743616,
  "created_at" : "2011-07-20 13:28:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93655389094158336",
  "text" : "RT @_flyingmoomin: AKB48\u4FE1\u8005\u306E\u53CB\u4EBA\u304C\u300CAKB\u306E\u3053\u3068\u306F\u305F\u3076\u3093\u524D\u4E16\u304B\u3089\u597D\u304D\u3060\u3063\u305F\u3068\u601D\u3046\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3093\u3060\u3051\u3069, \u305F\u3076\u3093\u524D\u4E16\u306BAKB48\u306F\u7121\u304B\u3063\u305F\u3068\u601D\u3046.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93655190368030720",
    "text" : "AKB48\u4FE1\u8005\u306E\u53CB\u4EBA\u304C\u300CAKB\u306E\u3053\u3068\u306F\u305F\u3076\u3093\u524D\u4E16\u304B\u3089\u597D\u304D\u3060\u3063\u305F\u3068\u601D\u3046\u300D\u3063\u3066\u8A00\u3063\u3066\u305F\u3093\u3060\u3051\u3069, \u305F\u3076\u3093\u524D\u4E16\u306BAKB48\u306F\u7121\u304B\u3063\u305F\u3068\u601D\u3046.",
    "id" : 93655190368030720,
    "created_at" : "2011-07-20 12:15:12 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 93655389094158336,
  "created_at" : "2011-07-20 12:15:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93640030505025536",
  "text" : "RT @NISIOISIN_BOT: \u300C\u30D9\u30B9\u30C8\u30B3\u30F3\u30C7\u30A3\u30B7\u30E7\u30F3\u3067\u6311\u3080\u3053\u3068\u3092\u8AE6\u3081\u308B\u3093\u3060\u3088\u3001\u30B3\u30B9\u30E1\u3002\u3044\u3084\u3001\u5C0F\u5A18\u300D\u300C\u30B3\u30B9\u30E1\u3068\u5C0F\u5A18\u3092\u8A00\u3044\u9593\u9055\u3048\u308B\u308F\u3051\u306A\u3044\u3067\u3057\u3087\u3046!?\u3000\u300E\u3080\u300F\u307F\u305F\u3044\u306A\u6012\u6D9B\u306E\u767A\u97F3\u529B\u3092\u8A87\u308B\u5358\u8A9E\u304C\u3069\u3046\u3057\u3066\u629C\u3051\u843D\u3061\u3061\u3083\u3046\u3093\u3067\u3059\u304B\uFF01\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93638159652495360",
    "text" : "\u300C\u30D9\u30B9\u30C8\u30B3\u30F3\u30C7\u30A3\u30B7\u30E7\u30F3\u3067\u6311\u3080\u3053\u3068\u3092\u8AE6\u3081\u308B\u3093\u3060\u3088\u3001\u30B3\u30B9\u30E1\u3002\u3044\u3084\u3001\u5C0F\u5A18\u300D\u300C\u30B3\u30B9\u30E1\u3068\u5C0F\u5A18\u3092\u8A00\u3044\u9593\u9055\u3048\u308B\u308F\u3051\u306A\u3044\u3067\u3057\u3087\u3046!?\u3000\u300E\u3080\u300F\u307F\u305F\u3044\u306A\u6012\u6D9B\u306E\u767A\u97F3\u529B\u3092\u8A87\u308B\u5358\u8A9E\u304C\u3069\u3046\u3057\u3066\u629C\u3051\u843D\u3061\u3061\u3083\u3046\u3093\u3067\u3059\u304B\uFF01\u300D",
    "id" : 93638159652495360,
    "created_at" : "2011-07-20 11:07:31 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 93640030505025536,
  "created_at" : "2011-07-20 11:14:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u592A\u9F13\u306E\u30DE\u30B5\u30B3\u307D\u30FC\u305F\u3076\u308B\u2161@\u8FB2\u8015\u6C11\u65CF",
      "screen_name" : "napotyo",
      "indices" : [ 3, 11 ],
      "id_str" : "264700565",
      "id" : 264700565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93595990447239169",
  "text" : "RT @napotyo: \u3059\u308C\u9055\u3044\u306E\u7537\u5B50\u9AD8\u6821\u751F\u300C\u53F0\u98A8\u306F\u3044\u3044\u3088\u306A\u30FC\u3001\u9032\u8DEF\u6C7A\u307E\u3063\u3066\u3066\u300D\u5439\u3044\u305F\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93272502108819456",
    "text" : "\u3059\u308C\u9055\u3044\u306E\u7537\u5B50\u9AD8\u6821\u751F\u300C\u53F0\u98A8\u306F\u3044\u3044\u3088\u306A\u30FC\u3001\u9032\u8DEF\u6C7A\u307E\u3063\u3066\u3066\u300D\u5439\u3044\u305F\uFF57",
    "id" : 93272502108819456,
    "created_at" : "2011-07-19 10:54:32 +0000",
    "user" : {
      "name" : "\u592A\u9F13\u306E\u30DE\u30B5\u30B3\u307D\u30FC\u305F\u3076\u308B\u2161@\u8FB2\u8015\u6C11\u65CF",
      "screen_name" : "napotyo",
      "protected" : false,
      "id_str" : "264700565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585489577097433088\/X0WH-ii-_normal.jpg",
      "id" : 264700565,
      "verified" : false
    }
  },
  "id" : 93595990447239169,
  "created_at" : "2011-07-20 08:19:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93590088449134592",
  "text" : "\u30EA\u30B5\u3061\u3083\u3093\u306E\u30A2\u30A4\u30B3\u30F3\u304C\u590F\u670D\u306B\u306A\u3063\u3066\u308B\uFF01",
  "id" : 93590088449134592,
  "created_at" : "2011-07-20 07:56:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93586267404644352",
  "text" : "@ayu167 skype me!",
  "id" : 93586267404644352,
  "created_at" : "2011-07-20 07:41:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93548374086787072",
  "text" : "\u751F\u6D3B\u306E\u30EA\u30BA\u30E0\u304C\u30E4\u30D0\u3044\u3002\u4ECA\u8D77\u304D\u305F\u3002",
  "id" : 93548374086787072,
  "created_at" : "2011-07-20 05:10:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93289036831145986",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 93289036831145986,
  "created_at" : "2011-07-19 12:00:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93216141018791936",
  "text" : "\u660E\u65E5\u306E\uFF12\u9650\u306F\u53F0\u98A8\u3067\u81EA\u4E3B\u4F11\u8B1B\u304B\u306A\u30FC",
  "id" : 93216141018791936,
  "created_at" : "2011-07-19 07:10:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93213875616481280",
  "text" : "\u4EBA\u9593\u30B7\u30EA\u30FC\u30BA\u3060\u3051\u3060\u3068\u8A71\u304C\u30CF\u30F3\u30D1\u306A\u611F\u3058\u304C\u3059\u308B\u3093\u3060\u3088\u306A\u30FC\u3002\u622F\u8A00\u30B7\u30EA\u30FC\u30BA\u3082\u8AAD\u307E\u306A\u304D\u3083\u304B\u2026",
  "id" : 93213875616481280,
  "created_at" : "2011-07-19 07:01:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93212376597413888",
  "text" : "\u30E0\u30B7\u30E0\u30B7\u3057\u3066\u30D9\u30BF\u30D9\u30BF\u3057\u3066gdgd\u3057\u3066\u30E2\u30E4\u30E2\u30E4\u3059\u308B",
  "id" : 93212376597413888,
  "created_at" : "2011-07-19 06:55:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93212070274797568",
  "text" : "\u53CC\u8B58\u2026",
  "id" : 93212070274797568,
  "created_at" : "2011-07-19 06:54:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92956476427087872",
  "text" : "@ayu167 \u3060\u3044\u3058\u3087\u3076\u304B\uFF1F",
  "id" : 92956476427087872,
  "created_at" : "2011-07-18 13:58:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92886380019056640",
  "geo" : { },
  "id_str" : "92887223032217600",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u56EE\u7269\u8A9E\u8AAD\u3093\u3060\uFF1F",
  "id" : 92887223032217600,
  "in_reply_to_status_id" : 92886380019056640,
  "created_at" : "2011-07-18 09:23:34 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92787840483737600",
  "text" : "\u7720\u3044\u2026\u3084\u3063\u3071\u8DB3\u308A\u306A\u3044\u3088\u306A\u3041\u7761\u7720\u6642\u9593",
  "id" : 92787840483737600,
  "created_at" : "2011-07-18 02:48:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304F\u3089\u3093\u30DC\u30D3\u30F3\u30BD\u30F3",
      "screen_name" : "bob_036",
      "indices" : [ 3, 11 ],
      "id_str" : "131057178",
      "id" : 131057178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92787549617143808",
  "text" : "RT @bob_036: \u30EC\u30DD\u30FC\u30C8\u8AB2\u984C\u3084\u3063\u3066\u30662000\u5B57\u4EE5\u4E0A\u66F8\u304F\u3068\u6025\u306B\u982D\u304C\u304A\u304B\u3057\u304F\u306A\u3063\u3066\u304F\u308B\u3093\u3067\u3059\u3051\u3069\u3001\u4ECA\u65E5\u306F\u63D0\u51FA\u671F\u9650\u304C\u6B8B\u308A\uFF12\u6642\u9593\u306B\u8FEB\u3063\u3066\u305F\u306E\u3067\u305D\u306E\u9650\u754C\u3092\u8D85\u3048\u3066\u534A\u5206\u610F\u8B58\u5931\u3044\u306A\u304C\u3089\u66F8\u3044\u3066\u305F\u3089\u3001\u76EE\u899A\u3081\u305F\u3068\u304D\u5F8C\u534A\u90E8\u5206\u304C\u2517(^o^ )\u2513\u3068\u304B\uFF3C(^o^)\uFF0F\u3067\u57CB\u3081\u5C3D\u304F\u3055\u308C\u3066\u3066\u6050\u308B\u6050\u308B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "92600490566758400",
    "text" : "\u30EC\u30DD\u30FC\u30C8\u8AB2\u984C\u3084\u3063\u3066\u30662000\u5B57\u4EE5\u4E0A\u66F8\u304F\u3068\u6025\u306B\u982D\u304C\u304A\u304B\u3057\u304F\u306A\u3063\u3066\u304F\u308B\u3093\u3067\u3059\u3051\u3069\u3001\u4ECA\u65E5\u306F\u63D0\u51FA\u671F\u9650\u304C\u6B8B\u308A\uFF12\u6642\u9593\u306B\u8FEB\u3063\u3066\u305F\u306E\u3067\u305D\u306E\u9650\u754C\u3092\u8D85\u3048\u3066\u534A\u5206\u610F\u8B58\u5931\u3044\u306A\u304C\u3089\u66F8\u3044\u3066\u305F\u3089\u3001\u76EE\u899A\u3081\u305F\u3068\u304D\u5F8C\u534A\u90E8\u5206\u304C\u2517(^o^ )\u2513\u3068\u304B\uFF3C(^o^)\uFF0F\u3067\u57CB\u3081\u5C3D\u304F\u3055\u308C\u3066\u3066\u6050\u308B\u6050\u308B\u6642\u8A08\u898B\u308B\u3068\u3084\u3063\u3071\u308A\u63D0\u51FA\u671F\u9650\u904E\u304E\u3066\u305F",
    "id" : 92600490566758400,
    "created_at" : "2011-07-17 14:24:12 +0000",
    "user" : {
      "name" : "\u3055\u304F\u3089\u3093\u30DC\u30D3\u30F3\u30BD\u30F3",
      "screen_name" : "bob_036",
      "protected" : false,
      "id_str" : "131057178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226332146\/Konachan.com_-_85253_panty___stocking_with_garterbelt_panty__character__stocking__character__normal.jpg",
      "id" : 131057178,
      "verified" : false
    }
  },
  "id" : 92787549617143808,
  "created_at" : "2011-07-18 02:47:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92759981513916417",
  "text" : "\u96E8\u2026\u3060\u3068\u2026\uFF01\uFF1F",
  "id" : 92759981513916417,
  "created_at" : "2011-07-18 00:57:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92564245237088256",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 92564245237088256,
  "created_at" : "2011-07-17 12:00:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92486455485665280",
  "text" : "\u306B\u305B\u307B\u30FB\u30FB\u30FB",
  "id" : 92486455485665280,
  "created_at" : "2011-07-17 06:51:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92481500263620608",
  "text" : "\u5BB5\u5C71\u306E\u96F0\u56F2\u6C17\u306B\u4E57\u3058\u3066\u7740\u7269\u3067\u51FA\u3088\u3046\u3068\u601D\u3063\u305F\u3051\u3069\u2026\u3053\u308C\u6691\u3044\u306A\u3041\u3002\u751A\u5E73\u306B\u3057\u3066\u304A\u304F\u3079\u304D\u304B\u30FB\u30FB\u30FB\u3002",
  "id" : 92481500263620608,
  "created_at" : "2011-07-17 06:31:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92452391072448512",
  "text" : "\u304A\u7D20\u9EBA\u3067\u3082\u3086\u3067\u307E\u3057\u3087\u304B",
  "id" : 92452391072448512,
  "created_at" : "2011-07-17 04:35:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92452315574968320",
  "text" : "\u8D77\u5E8A\u3001\u3044\u3084\u30D9\u30C3\u30C9\u3067\uFF47\uFF44\uFF47\uFF44\u3057\u3066\u305F\u3093\u3060\u3051\u3069\u3002",
  "id" : 92452315574968320,
  "created_at" : "2011-07-17 04:35:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92440021495316480",
  "text" : "RT @akeopyaa: \u6570\u5B66\u306E\u8A3C\u660E\u306E\u6700\u5F8C\u306B\u925B\u7B46\u3067\u300C\u30C8\u30F3\u30C3\u300D\u3068\u3001\u3084\u3084\u5927\u3052\u3055\u306B\u30D4\u30EA\u30AA\u30C9\u3092\u6253\u3064\u3002\u4E00\u3064\u306E\u4EA4\u97FF\u66F2\u304C\u300C\u30B8\u30E3\u30F3\u30C3\u300D\u3068\u7D42\u308F\u308B\u3088\u3046\u3067\u3001\u597D\u304D\u3002\u6570\u5B57\u306E\u4E0B\u306B\u300C\u30B7\u30E3\u30C3\u300D\u3068\u7DDA\u3092\u5F15\u304F\u306E\u3082\u3001\u4F59\u97FB\u3068\u3044\u3046\u304B\u3001\u30D5\u30A7\u30EB\u30DE\u30FC\u30BF\u3092\u610F\u8B58\u3057\u3066\u3057\u307E\u3046\u3002\u540C\u3058\u3088\u3046\u306B\u3001\u9577\u3081\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u3057\u305F\u6642\u3082\u30A8\u30F3\u30BF\u30FC\u30AD\u30FC\u3092 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "92437659456245760",
    "text" : "\u6570\u5B66\u306E\u8A3C\u660E\u306E\u6700\u5F8C\u306B\u925B\u7B46\u3067\u300C\u30C8\u30F3\u30C3\u300D\u3068\u3001\u3084\u3084\u5927\u3052\u3055\u306B\u30D4\u30EA\u30AA\u30C9\u3092\u6253\u3064\u3002\u4E00\u3064\u306E\u4EA4\u97FF\u66F2\u304C\u300C\u30B8\u30E3\u30F3\u30C3\u300D\u3068\u7D42\u308F\u308B\u3088\u3046\u3067\u3001\u597D\u304D\u3002\u6570\u5B57\u306E\u4E0B\u306B\u300C\u30B7\u30E3\u30C3\u300D\u3068\u7DDA\u3092\u5F15\u304F\u306E\u3082\u3001\u4F59\u97FB\u3068\u3044\u3046\u304B\u3001\u30D5\u30A7\u30EB\u30DE\u30FC\u30BF\u3092\u610F\u8B58\u3057\u3066\u3057\u307E\u3046\u3002\u540C\u3058\u3088\u3046\u306B\u3001\u9577\u3081\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u3057\u305F\u6642\u3082\u30A8\u30F3\u30BF\u30FC\u30AD\u30FC\u3092\u5F37\u304F\u53E9\u3044\u3066\u3057\u307E\u3046\u3002\u30CE\u30EA\u30CE\u30EA\u3067\u3059\u306D\u3002",
    "id" : 92437659456245760,
    "created_at" : "2011-07-17 03:37:10 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 92440021495316480,
  "created_at" : "2011-07-17 03:46:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92259995835568128",
  "geo" : { },
  "id_str" : "92260177910312960",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3044\u3048\u3044\u3048\u30FC\u697D\u3057\u304B\u3063\u305F\u306E\u3067\u4F3C\u305F\u3088\u3046\u306A\u306E\u3042\u3063\u305F\u3089\u8A98\u3063\u3066\u304F\u3060\u3055\u3044\u306A\u3002",
  "id" : 92260177910312960,
  "in_reply_to_status_id" : 92259995835568128,
  "created_at" : "2011-07-16 15:51:55 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92258744490139649",
  "text" : "\u305F\u3060\u5730\u5143\u306E\u6700\u5BC4\u99C5\u307E\u3067\u4E00\u7DD2\u306E\u4EBA\u304C\u3044\u305F\u306E\u306F\u611F\u52D5\u3057\u3066\u73CD\u3057\u304F\u30C6\u30F3\u30B7\u30E7\u30F3\u4E0A\u304C\u3063\u305F\u3002\u7ACB\u6559\u5973\u5B66\u9662\u306E\u524D\u3068\u304B\uFF57\uFF57\uFF57",
  "id" : 92258744490139649,
  "created_at" : "2011-07-16 15:46:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92258578907398144",
  "text" : "\u30B5\u30FC\u30AF\u30EB\u306E\u5148\u8F29\u306E\u6240\u5C5E\u3059\u308B\u5225\u30B5\u30FC\u30AF\u30EB\u306E\u98F2\u307F\u4F1A\u306B\u6D41\u308C\u3067\u53C2\u52A0\u3059\u308B\u4FFA\u3002\u305D\u3057\u3066\u99B4\u67D3\u3080\u4FFA\u2026\u3002",
  "id" : 92258578907398144,
  "created_at" : "2011-07-16 15:45:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92254817061318657",
  "text" : "\u5E30\u5B85\u30A1\uFF01",
  "id" : 92254817061318657,
  "created_at" : "2011-07-16 15:30:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92201854741647361",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 92201854741647361,
  "created_at" : "2011-07-16 12:00:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92082816883503104",
  "text" : "\u3042\u3001\u753B\u50CF\u898B\u305F\u3089\u30AB\u30AA\u30BD\u30FC\u30A4\u98DF\u3079\u305F\u304F\u3066\u4ED5\u65B9\u306A\u3044\u2026\u3002",
  "id" : 92082816883503104,
  "created_at" : "2011-07-16 04:07:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92075256365318144",
  "geo" : { },
  "id_str" : "92075913780543488",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u3044\u3084\u3001\u4FFA\u3082\u53CB\u9054\u306E\u4ED8\u6DFB\uFF08\uFF1F\uFF09\u3067\u884C\u304F\u304B\u3082\u3057\u308C\u307E\u305B\u3093",
  "id" : 92075913780543488,
  "in_reply_to_status_id" : 92075256365318144,
  "created_at" : "2011-07-16 03:39:43 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92074626414428160",
  "geo" : { },
  "id_str" : "92075117718421504",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u9CE5\u30B3\u30F3\u884C\u304F\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 92075117718421504,
  "in_reply_to_status_id" : 92074626414428160,
  "created_at" : "2011-07-16 03:36:33 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91735688726315008",
  "text" : "\u4F8B\u5916\u306E\u65B9\u304C\u591A\u3044\u898F\u5247\u2026\u79D1\u5B66\u54F2\u5B66\u306E\u6388\u696D\u4E2D\u306A\u306E\u306B\u53CD\u5FDC\u3057\u3066\u3057\u307E\u3063\u305F",
  "id" : 91735688726315008,
  "created_at" : "2011-07-15 05:07:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ken-ken",
      "screen_name" : "icHAnNelER",
      "indices" : [ 3, 14 ],
      "id_str" : "119731493",
      "id" : 119731493
    }, {
      "name" : "\u6570\u5B66\u554F\u984Cbot",
      "screen_name" : "mathematics_bot",
      "indices" : [ 16, 32 ],
      "id_str" : "96739891",
      "id" : 96739891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91733018888257536",
  "text" : "RT @icHAnNelER: @mathematics_bot \u53CB\u4EBA\u306B\u3059\u3059\u3081\u3089\u308C\u3001\u534A\u4FE1\u534A\u7591\u3067\u59CB\u3081\u305F\u6570\u5B66\u30DC\u30C3\u30C8\u3002\u7A7A\u304D\u6642\u9593\u306B\u8AAD\u307F\u98DB\u3070\u3057\u3066\u3044\u305F\u3060\u3051\u306A\u306E\u306B\u3001\u6C17\u4ED8\u304F\u3068\u30C6\u30B9\u30C8\u306E\u70B9\u6570\u306F\u4E0A\u6607\u3057\u3001\u30D0\u30B9\u30B1\u90E8\u306E\u4E3B\u5C06\u306B\u3082\u5927\u629C\u64E2\u3055\u308C\u307E\u3057\u305F\u3002\u305D\u3057\u3066\u5148\u65E5\u3001\u3064\u3044\u306B\u4EBA\u751F\u3067\u521D\u3081\u3066\u306E\u5F7C\u5973\u304C\u51FA\u6765\u307E\u3057\u305F\uFF01\u3042\u308A\u304C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twimi.jp\/?r=via\" rel=\"nofollow\"\u003Etwimi\u2606new\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6570\u5B66\u554F\u984Cbot",
        "screen_name" : "mathematics_bot",
        "indices" : [ 0, 16 ],
        "id_str" : "96739891",
        "id" : 96739891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "91088401335455745",
    "geo" : { },
    "id_str" : "91091733181497344",
    "in_reply_to_user_id" : 96739891,
    "text" : "@mathematics_bot \u53CB\u4EBA\u306B\u3059\u3059\u3081\u3089\u308C\u3001\u534A\u4FE1\u534A\u7591\u3067\u59CB\u3081\u305F\u6570\u5B66\u30DC\u30C3\u30C8\u3002\u7A7A\u304D\u6642\u9593\u306B\u8AAD\u307F\u98DB\u3070\u3057\u3066\u3044\u305F\u3060\u3051\u306A\u306E\u306B\u3001\u6C17\u4ED8\u304F\u3068\u30C6\u30B9\u30C8\u306E\u70B9\u6570\u306F\u4E0A\u6607\u3057\u3001\u30D0\u30B9\u30B1\u90E8\u306E\u4E3B\u5C06\u306B\u3082\u5927\u629C\u64E2\u3055\u308C\u307E\u3057\u305F\u3002\u305D\u3057\u3066\u5148\u65E5\u3001\u3064\u3044\u306B\u4EBA\u751F\u3067\u521D\u3081\u3066\u306E\u5F7C\u5973\u304C\u51FA\u6765\u307E\u3057\u305F\uFF01\u3042\u308A\u304C\u3068\u3046\u6570\u5B66\u30DC\u30C3\u30C8\uFF01\uFF08\u9CE5\u53D6\u770C\u30FB\uFF11\uFF16\u6B73\u30FB\u7537\uFF09",
    "id" : 91091733181497344,
    "in_reply_to_status_id" : 91088401335455745,
    "created_at" : "2011-07-13 10:28:56 +0000",
    "in_reply_to_screen_name" : "mathematics_bot",
    "in_reply_to_user_id_str" : "96739891",
    "user" : {
      "name" : "ken-ken",
      "screen_name" : "icHAnNelER",
      "protected" : false,
      "id_str" : "119731493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743927065\/NEC_0038_normal.jpg",
      "id" : 119731493,
      "verified" : false
    }
  },
  "id" : 91733018888257536,
  "created_at" : "2011-07-15 04:57:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mojikoji\uFF08\u7269\u6B32\u7CFB\u7537\u5B50\uFF09",
      "screen_name" : "mojikoji",
      "indices" : [ 3, 12 ],
      "id_str" : "79354229",
      "id" : 79354229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91717536160284672",
  "text" : "RT @mojikoji: \u4E00\u5EA6\u3067\u3044\u3044\u304B\u3089\u5973\u5B50\u3068\u6570\u5B66\u8A0E\u8AD6\u3057\u3066\u307F\u305F\u3044\u3002\u3060\u308C\u304B\u6570\u5B66\u30AC\u30FC\u30EB\u7D39\u4ECB\u3057\u3066\u304F\u308C\u3044\u3002\u304D\u3063\u3068\u30D5\u30EB\u30DC\u3063\u3053\u3055\u308C\u308B\u3060\u308D\u3046\u3051\u3069\u3001\u305D\u308C\u306F\u305D\u308C\u3067\u2026 #mathgirl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mathgirl",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91713186813837312",
    "text" : "\u4E00\u5EA6\u3067\u3044\u3044\u304B\u3089\u5973\u5B50\u3068\u6570\u5B66\u8A0E\u8AD6\u3057\u3066\u307F\u305F\u3044\u3002\u3060\u308C\u304B\u6570\u5B66\u30AC\u30FC\u30EB\u7D39\u4ECB\u3057\u3066\u304F\u308C\u3044\u3002\u304D\u3063\u3068\u30D5\u30EB\u30DC\u3063\u3053\u3055\u308C\u308B\u3060\u308D\u3046\u3051\u3069\u3001\u305D\u308C\u306F\u305D\u308C\u3067\u2026 #mathgirl",
    "id" : 91713186813837312,
    "created_at" : "2011-07-15 03:38:22 +0000",
    "user" : {
      "name" : "mojikoji\uFF08\u7269\u6B32\u7CFB\u7537\u5B50\uFF09",
      "screen_name" : "mojikoji",
      "protected" : false,
      "id_str" : "79354229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1487448293\/AccountIcon_M_bigger_normal.jpg",
      "id" : 79354229,
      "verified" : false
    }
  },
  "id" : 91717536160284672,
  "created_at" : "2011-07-15 03:55:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91678187649646592",
  "text" : "@np2i \u306B\u305B\u307B\u308B\u308B\u3093 \u3084 \u306B\u305B\u307B\u308B\u308B\u308B\u3093 \u306A\u3093\u304B\u306F\u306B\u305B\u307B\u306E\u898F\u5236\u7528\u30A2\u30AB\u30A6\u30F3\u30C8\u3067\u3059\u3088\u30FC",
  "id" : 91678187649646592,
  "created_at" : "2011-07-15 01:19:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91654867235516416",
  "text" : "\u9045\u523B\u306A\u3089\u884C\u304B\u306A\u304F\u3066\u3044\u30FC\u304B\u306A\u30FC\uFF08\u3057\u308D\u3081",
  "id" : 91654867235516416,
  "created_at" : "2011-07-14 23:46:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91654716534169600",
  "text" : "\u3042\u308C\uFF1F\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u305F\u3089\u4E00\u9650\u9045\u523B\u2026",
  "id" : 91654716534169600,
  "created_at" : "2011-07-14 23:46:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 3, 12 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91644200285782016",
  "text" : "RT @nisehorn: \u4E45\u3057\u3076\u308A\u306E\u5409\u7965\u5BFA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91642460673028097",
    "text" : "\u4E45\u3057\u3076\u308A\u306E\u5409\u7965\u5BFA",
    "id" : 91642460673028097,
    "created_at" : "2011-07-14 22:57:19 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "protected" : false,
      "id_str" : "96348838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009677836\/06-12-24_23-49m_normal.jpg",
      "id" : 96348838,
      "verified" : false
    }
  },
  "id" : 91644200285782016,
  "created_at" : "2011-07-14 23:04:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91644187803529216",
  "text" : "\u306B\u305B\u307B\u304C\u5409\u7965\u5BFA\u306B\u3044\u308B\u3068\u304B\u80F8\u71B1",
  "id" : 91644187803529216,
  "created_at" : "2011-07-14 23:04:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91641323907596288",
  "text" : "\u8D77\u5E8A \u4E45\u3005\u306B\u4E00\u9650\u51FA\u308C\u305D\u3046",
  "id" : 91641323907596288,
  "created_at" : "2011-07-14 22:52:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "indices" : [ 3, 10 ],
      "id_str" : "26393410",
      "id" : 26393410
    }, {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 25, 31 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91640938849509377",
  "text" : "RT @tomo37: note to self @hyuki #mathgirl 2011\u5E747\u670826\u65E5\uFF08\u706B\uFF09 19\u664230\u5206\u304B\u3089\u306ENHK\u7DCF\u5408\u300C\u30AF\u30ED\u30FC\u30BA\u30A2\u30C3\u30D7\u73FE\u4EE3\u300D\u6570\u5B66\u66F8\u30D6\u30FC\u30E0\u306B\u95A2\u3059\u308B\u7279\u96C6\u30B3\u30FC\u30CA\u30FC\u3067\u3001\u300E\u6570\u5B66\u30AC\u30FC\u30EB\u300F\u30B7\u30EA\u30FC\u30BA4\u518A\u304C\u6620\u308B\u3068\u306E\u3053\u3068\u3002\u7DE8\u96C6\u90E8\u304B\u3089\u306E\u60C5\u5831\u3067\u3057\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u7D50\u57CE\u6D69",
        "screen_name" : "hyuki",
        "indices" : [ 13, 19 ],
        "id_str" : "5335922",
        "id" : 5335922
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mathgirl",
        "indices" : [ 20, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91631123855192066",
    "text" : "note to self @hyuki #mathgirl 2011\u5E747\u670826\u65E5\uFF08\u706B\uFF09 19\u664230\u5206\u304B\u3089\u306ENHK\u7DCF\u5408\u300C\u30AF\u30ED\u30FC\u30BA\u30A2\u30C3\u30D7\u73FE\u4EE3\u300D\u6570\u5B66\u66F8\u30D6\u30FC\u30E0\u306B\u95A2\u3059\u308B\u7279\u96C6\u30B3\u30FC\u30CA\u30FC\u3067\u3001\u300E\u6570\u5B66\u30AC\u30FC\u30EB\u300F\u30B7\u30EA\u30FC\u30BA4\u518A\u304C\u6620\u308B\u3068\u306E\u3053\u3068\u3002\u7DE8\u96C6\u90E8\u304B\u3089\u306E\u60C5\u5831\u3067\u3057\u305F\u3002",
    "id" : 91631123855192066,
    "created_at" : "2011-07-14 22:12:17 +0000",
    "user" : {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "protected" : false,
      "id_str" : "26393410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3196977964\/6ea5fc209db56d1d26d6a24de65b7277_normal.jpeg",
      "id" : 26393410,
      "verified" : false
    }
  },
  "id" : 91640938849509377,
  "created_at" : "2011-07-14 22:51:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3083\u308B",
      "screen_name" : "_shalu_",
      "indices" : [ 3, 11 ],
      "id_str" : "111832032",
      "id" : 111832032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91547826059874304",
  "text" : "RT @_shalu_: \u304A\u3001\u3084\u3079\u3047\u3001\u9685\u7530\u5DDD\u82B1\u706B\u5927\u4F1A\u3063\u30668\/27\u3063\u3066\u66F8\u3044\u305F\u3051\u3069\u3001\u3088\u304F\u3088\u304F\u8003\u3048\u305F\u3089(2\/3)^3\u3058\u3083\u306D\uFF1F\u3084\u3063\u3079\u3048\u3048\u3047\u3047\u3047\u3047\u3047\u3047\uFF58\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u30C6\u30F3\u30B7\u30E7\u30F3\u4E0A\u304C\u308B\u308F\u30FC\u30FC\u30FC\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91537604729769984",
    "text" : "\u304A\u3001\u3084\u3079\u3047\u3001\u9685\u7530\u5DDD\u82B1\u706B\u5927\u4F1A\u3063\u30668\/27\u3063\u3066\u66F8\u3044\u305F\u3051\u3069\u3001\u3088\u304F\u3088\u304F\u8003\u3048\u305F\u3089(2\/3)^3\u3058\u3083\u306D\uFF1F\u3084\u3063\u3079\u3048\u3048\u3047\u3047\u3047\u3047\u3047\u3047\uFF58\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u30C6\u30F3\u30B7\u30E7\u30F3\u4E0A\u304C\u308B\u308F\u30FC\u30FC\u30FC\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
    "id" : 91537604729769984,
    "created_at" : "2011-07-14 16:00:40 +0000",
    "user" : {
      "name" : "\u3057\u3083\u308B",
      "screen_name" : "_shalu_",
      "protected" : false,
      "id_str" : "111832032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535121801618014208\/YriwYBCa_normal.png",
      "id" : 111832032,
      "verified" : false
    }
  },
  "id" : 91547826059874304,
  "created_at" : "2011-07-14 16:41:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91537087664369664",
  "text" : "\u3055\u30FC\u3066PC\u843D\u3068\u3059\u304B\u306A\u3002\u643A\u5E2F\u304B\u3089\u898B\u3066\u307E\u3059\u304C\u30FC\u3002",
  "id" : 91537087664369664,
  "created_at" : "2011-07-14 15:58:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 23, 32 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91535976144449536",
  "geo" : { },
  "id_str" : "91536546271985664",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu @mar1e666 \u2026\u4E00\u5FDC\u9811\u5F35\u3063\u3066\u307F\u307E\u3059\u304C\u3001\u904E\u5EA6\u306A\u671F\u5F85\u306F\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u306A\u3002",
  "id" : 91536546271985664,
  "in_reply_to_status_id" : 91535976144449536,
  "created_at" : "2011-07-14 15:56:27 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 3, 14 ],
      "id_str" : "95958826",
      "id" : 95958826
    }, {
      "name" : "\u8D77\u5E8ALv2.167",
      "screen_name" : "kishoujin",
      "indices" : [ 31, 41 ],
      "id_str" : "54097973",
      "id" : 54097973
    }, {
      "name" : "Takashi EGAWA",
      "screen_name" : "t_egg",
      "indices" : [ 44, 50 ],
      "id_str" : "4104301",
      "id" : 4104301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 61, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91536004825104384",
  "text" : "RT @SugaTheKid: \u3010\u512A\u52DD\u3011\u3000\u604B\u306E\u7D50\u5408\u5F8B\uFF08\u6CD5\u5247\uFF09\u3000@kishoujin \u69D8 @t_egg \u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u8D77\u5E8ALv2.167",
        "screen_name" : "kishoujin",
        "indices" : [ 15, 25 ],
        "id_str" : "54097973",
        "id" : 54097973
      }, {
        "name" : "Takashi EGAWA",
        "screen_name" : "t_egg",
        "indices" : [ 28, 34 ],
        "id_str" : "4104301",
        "id" : 4104301
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sugaku_ogiri",
        "indices" : [ 45, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91381289592160257",
    "text" : "\u3010\u512A\u52DD\u3011\u3000\u604B\u306E\u7D50\u5408\u5F8B\uFF08\u6CD5\u5247\uFF09\u3000@kishoujin \u69D8 @t_egg \u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
    "id" : 91381289592160257,
    "created_at" : "2011-07-14 05:39:31 +0000",
    "user" : {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "protected" : true,
      "id_str" : "95958826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595628560808878081\/EHNKb-wq_normal.jpg",
      "id" : 95958826,
      "verified" : false
    }
  },
  "id" : 91536004825104384,
  "created_at" : "2011-07-14 15:54:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 3, 14 ],
      "id_str" : "95958826",
      "id" : 95958826
    }, {
      "name" : "\u30C8\u30EA\u30A4\u30ED\u30B9\u30BA\u30E1\uFF20\u30DE\u30ED\u30C6\u30B9\u30AB\u30FC",
      "screen_name" : "suzume_moon",
      "indices" : [ 30, 42 ],
      "id_str" : "96645296",
      "id" : 96645296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91535980296798209",
  "text" : "RT @SugaTheKid: \u3010\u30B7\u30F3\u30D7\u30EB\u8CDE\u3011\u3000\u604B\u306E\u30B5\u30A4\u30F3\u3000@suzume_moon\u3000\u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30C8\u30EA\u30A4\u30ED\u30B9\u30BA\u30E1\uFF20\u30DE\u30ED\u30C6\u30B9\u30AB\u30FC",
        "screen_name" : "suzume_moon",
        "indices" : [ 14, 26 ],
        "id_str" : "96645296",
        "id" : 96645296
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sugaku_ogiri",
        "indices" : [ 37, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91382375870771200",
    "text" : "\u3010\u30B7\u30F3\u30D7\u30EB\u8CDE\u3011\u3000\u604B\u306E\u30B5\u30A4\u30F3\u3000@suzume_moon\u3000\u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
    "id" : 91382375870771200,
    "created_at" : "2011-07-14 05:43:50 +0000",
    "user" : {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "protected" : true,
      "id_str" : "95958826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595628560808878081\/EHNKb-wq_normal.jpg",
      "id" : 95958826,
      "verified" : false
    }
  },
  "id" : 91535980296798209,
  "created_at" : "2011-07-14 15:54:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 3, 14 ],
      "id_str" : "95958826",
      "id" : 95958826
    }, {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 30, 39 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91535953214193665",
  "text" : "RT @SugaTheKid: \u3010\u6E96\u512A\u52DD\u3011\u3000\u604B\u306EABC\u4E88\u60F3\u3000@nartakio \u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nartakio",
        "screen_name" : "nartakio",
        "indices" : [ 14, 23 ],
        "id_str" : "612419223",
        "id" : 612419223
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sugaku_ogiri",
        "indices" : [ 34, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91381695839862786",
    "text" : "\u3010\u6E96\u512A\u52DD\u3011\u3000\u604B\u306EABC\u4E88\u60F3\u3000@nartakio \u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
    "id" : 91381695839862786,
    "created_at" : "2011-07-14 05:41:08 +0000",
    "user" : {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "protected" : true,
      "id_str" : "95958826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595628560808878081\/EHNKb-wq_normal.jpg",
      "id" : 95958826,
      "verified" : false
    }
  },
  "id" : 91535953214193665,
  "created_at" : "2011-07-14 15:54:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 3, 14 ],
      "id_str" : "95958826",
      "id" : 95958826
    }, {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 32, 41 ],
      "id_str" : "612419223",
      "id" : 612419223
    }, {
      "name" : "erutuf",
      "screen_name" : "erutuf13",
      "indices" : [ 44, 53 ],
      "id_str" : "94744189",
      "id" : 94744189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 64, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91535931554803714",
  "text" : "RT @SugaTheKid: \u3010\u7279\u5225\u8CDE\u3011\u3000\u604B\u306E\u68EE\u30C9\u30EA\u30FC\u30E0\u7A7A\u9593\u3000@nartakio \u69D8 @erutuf13 \u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nartakio",
        "screen_name" : "nartakio",
        "indices" : [ 16, 25 ],
        "id_str" : "612419223",
        "id" : 612419223
      }, {
        "name" : "erutuf",
        "screen_name" : "erutuf13",
        "indices" : [ 28, 37 ],
        "id_str" : "94744189",
        "id" : 94744189
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sugaku_ogiri",
        "indices" : [ 48, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91382133905563649",
    "text" : "\u3010\u7279\u5225\u8CDE\u3011\u3000\u604B\u306E\u68EE\u30C9\u30EA\u30FC\u30E0\u7A7A\u9593\u3000@nartakio \u69D8 @erutuf13 \u69D8\u3000\u3010\u6570\u5B66\u5927\u559C\u5229\u3011 #sugaku_ogiri",
    "id" : 91382133905563649,
    "created_at" : "2011-07-14 05:42:53 +0000",
    "user" : {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "protected" : true,
      "id_str" : "95958826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595628560808878081\/EHNKb-wq_normal.jpg",
      "id" : 95958826,
      "verified" : false
    }
  },
  "id" : 91535931554803714,
  "created_at" : "2011-07-14 15:54:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 70 ],
      "url" : "http:\/\/t.co\/F2pgl8m",
      "expanded_url" : "http:\/\/togetter.com\/li\/161352",
      "display_url" : "togetter.com\/li\/161352"
    } ]
  },
  "geo" : { },
  "id_str" : "91535448287100929",
  "text" : "\u53C2\u52A0\u3057\u305F\u3051\u3069\u3059\u3052\u30FC\u9762\u767D\u304B\u3063\u305F \u3010\u6570\u5B66\u5927\u559C\u5229\u3011\u6570\u5B66\u7528\u8A9E\u306E\u524D\u306B\u300C\u604B\u306E\u300D\u3092\u3064\u3051\u3066\u4E00\u756A\u3068\u304D\u3081\u304B\u305B\u305F\u5974\u304C\u512A\u52DD\uFF08 http:\/\/t.co\/F2pgl8m",
  "id" : 91535448287100929,
  "created_at" : "2011-07-14 15:52:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 23, 32 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91535002327715840",
  "geo" : { },
  "id_str" : "91535347808354304",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu @mar1e666 \u3048\u3063\u305D\u3093\u306A\u30C6\u30FC\u30DE\u306A\u3093\u3067\u3059\u304B\uFF57\u307F\u306A\u3055\u3093\u3068\u306F\u9055\u3063\u3066\u305D\u3093\u306A\u306B\u9762\u767D\u3044\u8A71\u306F\u3067\u304D\u306A\u3044\u3067\u3059\u3088\u3046",
  "id" : 91535347808354304,
  "in_reply_to_status_id" : 91535002327715840,
  "created_at" : "2011-07-14 15:51:42 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 11, 22 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 23, 32 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91533342855544832",
  "geo" : { },
  "id_str" : "91533820565782528",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu @akiyohmori @mar1e666 \u79C1\u306A\u3093\u304B\u306E\u70BA\u306B\u4E88\u5B9A\u3092\u305A\u3089\u3057\u3066\u3082\u3089\u3063\u3066\u7533\u3057\u8A33\u306A\u3044\u2026\u2026\u3068\u540C\u6642\u306B\u3042\u308A\u304C\u3068\u3046\uFF01",
  "id" : 91533820565782528,
  "in_reply_to_status_id" : 91533342855544832,
  "created_at" : "2011-07-14 15:45:38 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91532304282951680",
  "geo" : { },
  "id_str" : "91533279248908288",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u3044\u3064\u306F\u697D\u3057\u307F\u3060\u3002\u884C\u3051\u308B\u304B\u3069\u3046\u304B\u306F\u514E\u3082\u89D2\u5B9F\u73FE\u3059\u308B\u306A\u3089\u9023\u7D61\u3057\u3066\u304A\u304F\u308C\u3002",
  "id" : 91533279248908288,
  "in_reply_to_status_id" : 91532304282951680,
  "created_at" : "2011-07-14 15:43:29 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91529454656032769",
  "geo" : { },
  "id_str" : "91529801596284928",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307C\u304F\u3067\u3082\u3055\u3093\u304B\u3067\u304D\u307E\u3059\u304B\uFF1F",
  "id" : 91529801596284928,
  "in_reply_to_status_id" : 91529454656032769,
  "created_at" : "2011-07-14 15:29:39 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 3, 15 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91520856597082113",
  "text" : "RT @undefined_k: \u79D1\u5B66\u8005\u306F\u30B7\u30A7\u30A4\u30AF\u30B9\u30D4\u30A2\u3092\u3001\n\u6587\u5B66\u8005\u306F\u76F8\u5BFE\u6027\u7406\u8AD6\u3092\u8AAD\u307E\u306A\u3051\u308C\u3070\u306A\u3089\u306A\u3044\uFF08\u591A\u7530\u5BCC\u96C4\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90478524292538369",
    "text" : "\u79D1\u5B66\u8005\u306F\u30B7\u30A7\u30A4\u30AF\u30B9\u30D4\u30A2\u3092\u3001\n\u6587\u5B66\u8005\u306F\u76F8\u5BFE\u6027\u7406\u8AD6\u3092\u8AAD\u307E\u306A\u3051\u308C\u3070\u306A\u3089\u306A\u3044\uFF08\u591A\u7530\u5BCC\u96C4\uFF09",
    "id" : 90478524292538369,
    "created_at" : "2011-07-11 17:52:15 +0000",
    "user" : {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "protected" : false,
      "id_str" : "114792585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462798391173332992\/-BCgGXZy_normal.jpeg",
      "id" : 114792585,
      "verified" : false
    }
  },
  "id" : 91520856597082113,
  "created_at" : "2011-07-14 14:54:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91512521743282176",
  "text" : "@ayu167 \u306A\u306B\u5931\u70B9\u306E\uFF57\uFF57\u306A\uFF12\uFF14\u3063\u3066\u3093\u306E\uFF57\uFF57\uFF57",
  "id" : 91512521743282176,
  "created_at" : "2011-07-14 14:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91509434970411008",
  "geo" : { },
  "id_str" : "91510118927187969",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \uFF19\u304B\uFF11\uFF10\u306A\u3089\u884C\u3051\u308B\u306E\u3067\u3059\u304C\u30FC\u30FB\u30FB\u30FB\u3002\u7121\u7406\u305D\u3046\u306A\u3089\u5E30\u56FD\u5F8C\u300220\u304B\u308925\u306E\u9593\u304F\u3089\u3044\uFF1F",
  "id" : 91510118927187969,
  "in_reply_to_status_id" : 91509434970411008,
  "created_at" : "2011-07-14 14:11:27 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91509913829912576",
  "text" : "@mo5nya \u6587\u6CD5\u3068\u304B\u5358\u8A9E\u3068\u304B\u3063\u3066\u3044\u3046\u3088\u308A\u7A4D\u6975\u6027\u306E\u554F\u984C\u3067\u3059\u3088\u306D\u3047\u3002\u82F1\u4F5C\u306F\u5272\u306B\u30B5\u30AF\u30B5\u30AF\u51FA\u6765\u308B\u306E\u306B\u307A\u3089\u307A\u3089\u558B\u308C\u306A\u3044\u30AE\u30E3\u30C3\u30D7\u554F\u984C\u30FB\u30FB\u30FB\u3002",
  "id" : 91509913829912576,
  "created_at" : "2011-07-14 14:10:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 12, 21 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91508863072870400",
  "geo" : { },
  "id_str" : "91509187896553473",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @mar1e666 11\u304B\u3089\u30CF\u30EF\u30A4\u306B\u884C\u304F\u4E88\u5B9A\u306A\u306E\u3067\u3059\u304C\u30FC",
  "id" : 91509187896553473,
  "in_reply_to_status_id" : 91508863072870400,
  "created_at" : "2011-07-14 14:07:45 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91508196837048320",
  "geo" : { },
  "id_str" : "91509009261150208",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5BB6\u304B\u3089\u51FA\u308B\uFF1F",
  "id" : 91509009261150208,
  "in_reply_to_status_id" : 91508196837048320,
  "created_at" : "2011-07-14 14:07:02 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE Axis of Evil",
      "screen_name" : "Cryolite",
      "indices" : [ 3, 12 ],
      "id_str" : "12873342",
      "id" : 12873342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91508032122527744",
  "text" : "RT @Cryolite: \u65E5\u672C\u306E\u30C8\u30C3\u30D7\u30A2\u30EB\u30B4\u30EA\u30BA\u30DE\u30FC\u305F\u3061\u306F\uFF0C\u65E9\u304F\u300C\u30B3\u30DF\u30C3\u30AF\u5358\u884C\u672C\u6700\u65B0\u520A\u3092\u8AAD\u307F\u59CB\u3081\u305F\u3089\u4EE5\u524D\u306E\u5185\u5BB9\u3092\u899A\u3048\u3066\u3044\u306A\u304F\u3066\u8A71\u306B\u3064\u3044\u3066\u3044\u3051\u306A\u304B\u3063\u305F\u306E\u30671\u5DFB\u304B\u3089\u8AAD\u307F\u76F4\u3059\u300D\u3068\u3044\u3046 O(N^2) \u306E\u30A2\u30EB\u30B4\u30EA\u30BA\u30E0\u306B\u95A2\u3057\u3066\uFF0C\u8A08\u7B97\u91CF\u30AA\u30FC\u30C0\u30FC\u3092\u843D\u3068\u3059\u30EC\u30D9\u30EB\u306E\u5287\u7684\u306A\u6539\u5584\u306B\u53D6\u308A\u7D44\u3093\u3067\u3044 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91503826120609792",
    "text" : "\u65E5\u672C\u306E\u30C8\u30C3\u30D7\u30A2\u30EB\u30B4\u30EA\u30BA\u30DE\u30FC\u305F\u3061\u306F\uFF0C\u65E9\u304F\u300C\u30B3\u30DF\u30C3\u30AF\u5358\u884C\u672C\u6700\u65B0\u520A\u3092\u8AAD\u307F\u59CB\u3081\u305F\u3089\u4EE5\u524D\u306E\u5185\u5BB9\u3092\u899A\u3048\u3066\u3044\u306A\u304F\u3066\u8A71\u306B\u3064\u3044\u3066\u3044\u3051\u306A\u304B\u3063\u305F\u306E\u30671\u5DFB\u304B\u3089\u8AAD\u307F\u76F4\u3059\u300D\u3068\u3044\u3046 O(N^2) \u306E\u30A2\u30EB\u30B4\u30EA\u30BA\u30E0\u306B\u95A2\u3057\u3066\uFF0C\u8A08\u7B97\u91CF\u30AA\u30FC\u30C0\u30FC\u3092\u843D\u3068\u3059\u30EC\u30D9\u30EB\u306E\u5287\u7684\u306A\u6539\u5584\u306B\u53D6\u308A\u7D44\u3093\u3067\u3044\u305F\u3060\u304D\u305F\u3044\uFF0E",
    "id" : 91503826120609792,
    "created_at" : "2011-07-14 13:46:26 +0000",
    "user" : {
      "name" : "THE Axis of Evil",
      "screen_name" : "Cryolite",
      "protected" : false,
      "id_str" : "12873342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564934049475481601\/N4EABMS6_normal.png",
      "id" : 12873342,
      "verified" : false
    }
  },
  "id" : 91508032122527744,
  "created_at" : "2011-07-14 14:03:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91507791528869888",
  "text" : "\u3067\u3082\u796D\u308A\u4EE5\u5916\u3067\u3082\u8EFD\u30FC\u3044\u30CE\u30EA\u3067\u7740\u7269\u3092\u7740\u308B\u7FD2\u6163\u3063\u3066\u5168\u7136\u306A\u3044\u3088\u306D\u30FC\u3002\u304B\u304F\u3044\u3046\u81EA\u5206\u3082\u306A\u304B\u306A\u304B\u7740\u3066\u51FA\u308B\u6A5F\u4F1A\u304C\u306A\u3044\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 91507791528869888,
  "created_at" : "2011-07-14 14:02:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91507539157594153",
  "text" : "\u3088\u3044\u3088\u3044\u3088\u3044\u3084\u307E\u3089\u3057\u3044\u3002\u7740\u7269\u59FF\u306E\u5973\u6027\u304C\u591A\u304F\u3066\u7D20\u6575\u3002\u3057\u304B\u3057\u7740\u7269\u3092\u7740\u305F\u5973\u6027\u304C\u597D\u304D\u306A\u3093\u3058\u3083\u306A\u304F\u3066\u5973\u6027\u304C\u7740\u3066\u3044\u308B\u7740\u7269\u304C\u306A\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u601D\u3046\u81EA\u5206\u3002",
  "id" : 91507539157594153,
  "created_at" : "2011-07-14 14:01:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91489519735549952",
  "text" : "\u6708\u5947\u9E97",
  "id" : 91489519735549952,
  "created_at" : "2011-07-14 12:49:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91477103903645696",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 91477103903645696,
  "created_at" : "2011-07-14 12:00:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91437148632395776",
  "text" : "RT @JOJO_math: \u2026\u3053\u306E\u7A7A\u6761\u627F\u592A\u90CE\u306F\u2026\u3044\u308F\u3086\u308B\u4E0D\u826F\u306E\u30EC\u30C3\u30C6\u30EB\u3092\u306F\u3089\u308C\u3066\u3044\u308B\u2026\u6388\u696D\u6599\u4EE5\u4E0B\u306E\u30DE\u30BA\u30A4\u8B1B\u7FA9\u3092\u3059\u308B\u6559\u54E1\u306B\u306F\u656C\u610F\u3092\u6255\u308F\u306D\u30FC\u306A\u3093\u3066\u306E\u306F\u3057\u3087\u3063\u3061\u3085\u3046\u3088\u3000\u3060\u304C\u3053\u3093\u306A\u304A\u308C\u306B\u3082\u306F\u304D\u6C17\u306E\u3059\u308B\u300E\u60AA\u300F\u306F\u308F\u304B\u308B\uFF01\u300E\u60AA\u300F\u3068\u306F\u3066\u3081\u30FC\u81EA\u8EAB\u306E\u5408\u683C\u306E\u305F\u3081\u3060\u3051\u306B\u8A66\u9A13\u4E2D\u306B\u30A6\u30A7\u30D6\u63B2\u793A\u677F\u3092\u5229 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91423702746529792",
    "text" : "\u2026\u3053\u306E\u7A7A\u6761\u627F\u592A\u90CE\u306F\u2026\u3044\u308F\u3086\u308B\u4E0D\u826F\u306E\u30EC\u30C3\u30C6\u30EB\u3092\u306F\u3089\u308C\u3066\u3044\u308B\u2026\u6388\u696D\u6599\u4EE5\u4E0B\u306E\u30DE\u30BA\u30A4\u8B1B\u7FA9\u3092\u3059\u308B\u6559\u54E1\u306B\u306F\u656C\u610F\u3092\u6255\u308F\u306D\u30FC\u306A\u3093\u3066\u306E\u306F\u3057\u3087\u3063\u3061\u3085\u3046\u3088\u3000\u3060\u304C\u3053\u3093\u306A\u304A\u308C\u306B\u3082\u306F\u304D\u6C17\u306E\u3059\u308B\u300E\u60AA\u300F\u306F\u308F\u304B\u308B\uFF01\u300E\u60AA\u300F\u3068\u306F\u3066\u3081\u30FC\u81EA\u8EAB\u306E\u5408\u683C\u306E\u305F\u3081\u3060\u3051\u306B\u8A66\u9A13\u4E2D\u306B\u30A6\u30A7\u30D6\u63B2\u793A\u677F\u3092\u5229\u7528\u3057\u3000\u5165\u8A66\u3092\u3075\u307F\u3064\u3051\u308B\u3084\u3064\u306E\u3053\u3068\u3060\uFF01\uFF01",
    "id" : 91423702746529792,
    "created_at" : "2011-07-14 08:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 91437148632395776,
  "created_at" : "2011-07-14 09:21:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5473\u564C\u716E\u8FBC\u307F\u30CD\u30B3",
      "screen_name" : "misonikomineko",
      "indices" : [ 3, 18 ],
      "id_str" : "2571069817",
      "id" : 2571069817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91436649677987840",
  "text" : "RT @misonikomineko: \u6570\u5B66\u306E\u554F\u984C\u304C\u4E38\u4E00\u65E5\u304B\u3051\u3066\u3082\u89E3\u3051\u306A\u3044\u3001\u3060\u3068\uFF1F\n\u3060\u304B\u3089\u81EA\u5206\u306F\u982D\u304C\u60AA\u3044\u3001\u3060\u3068\uFF1F\n\u3075\u3056\u3051\u308B\u306A\uFF01\n\u30D5\u30A7\u30EB\u30DE\u30FC\u306E\u6700\u7D42\u5B9A\u7406\u306F\u89E3\u304F\u306E\u306B400\u5E74\u304B\u304B\u3063\u305F\u3093\u3060\u305E\uFF1F\n400\u5E74\u9593\u304B\u3051\u305F\u5974\u306F\u7686\u3001\u99AC\u9E7F\u306A\u306E\u304B\uFF1F\n\u4F55\u767E\u5E74\u304B\u3051\u3066\u3067\u3082\u89E3\u3051\u3088\u3002\n\u77E5\u7684\u30B2\u30FC\u30E0\u306B\u52DD\u8005\u306A\u3057\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91410432987893760",
    "text" : "\u6570\u5B66\u306E\u554F\u984C\u304C\u4E38\u4E00\u65E5\u304B\u3051\u3066\u3082\u89E3\u3051\u306A\u3044\u3001\u3060\u3068\uFF1F\n\u3060\u304B\u3089\u81EA\u5206\u306F\u982D\u304C\u60AA\u3044\u3001\u3060\u3068\uFF1F\n\u3075\u3056\u3051\u308B\u306A\uFF01\n\u30D5\u30A7\u30EB\u30DE\u30FC\u306E\u6700\u7D42\u5B9A\u7406\u306F\u89E3\u304F\u306E\u306B400\u5E74\u304B\u304B\u3063\u305F\u3093\u3060\u305E\uFF1F\n400\u5E74\u9593\u304B\u3051\u305F\u5974\u306F\u7686\u3001\u99AC\u9E7F\u306A\u306E\u304B\uFF1F\n\u4F55\u767E\u5E74\u304B\u3051\u3066\u3067\u3082\u89E3\u3051\u3088\u3002\n\u77E5\u7684\u30B2\u30FC\u30E0\u306B\u52DD\u8005\u306A\u3057\u3002",
    "id" : 91410432987893760,
    "created_at" : "2011-07-14 07:35:20 +0000",
    "user" : {
      "name" : "\u732B\u5C3E \u9C39\u4ECB\uFF08thilogane\uFF09",
      "screen_name" : "nekoogle",
      "protected" : false,
      "id_str" : "15978114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420520806053982209\/Aa27eDFj_normal.jpeg",
      "id" : 15978114,
      "verified" : false
    }
  },
  "id" : 91436649677987840,
  "created_at" : "2011-07-14 09:19:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91406821012684800",
  "text" : "\u5FEB\u6674\u30A1\uFF01",
  "id" : 91406821012684800,
  "created_at" : "2011-07-14 07:20:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91406157947740161",
  "geo" : { },
  "id_str" : "91406560844185600",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u30B9\u30AB\u30A4\u30D7\u3067\u8AB0\u304B\u3068gdgd\u558B\u308A\u3064\u3064\u30EC\u30DD\u30FC\u30C8\u306F\uFF1F\u80FD\u7387\u306F\u4E0B\u304C\u308B\u3051\u3069",
  "id" : 91406560844185600,
  "in_reply_to_status_id" : 91406157947740161,
  "created_at" : "2011-07-14 07:19:57 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91373248964608000",
  "text" : "\u5BFE\u9762\u3082\u30C4\u30A4\u30C3\u30BF\u30FC\u898B\u3066\u3066\u7B11\u3044\u305D\u3046\u306B\u306A\u3063\u305F\uFF57",
  "id" : 91373248964608000,
  "created_at" : "2011-07-14 05:07:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91370633262399489",
  "geo" : { },
  "id_str" : "91371014533038080",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u771F\u663C\u9593\u3060\u3088\uFF01",
  "id" : 91371014533038080,
  "in_reply_to_status_id" : 91370633262399489,
  "created_at" : "2011-07-14 04:58:42 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91369914010566656",
  "geo" : { },
  "id_str" : "91370451632275456",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u5BDD\u306A\u3044\u3088\uFF01",
  "id" : 91370451632275456,
  "in_reply_to_status_id" : 91369914010566656,
  "created_at" : "2011-07-14 04:56:27 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91370145104146433",
  "text" : "\u96A3\u306E\u3084\u3064\u304C\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7\u306E\u30A2\u30A4\u30B3\u30F3\u3067\u5927\u304D\u3044\u77E2\u5370\u3068\u304B\u4F5C\u3063\u3066\u3066\u898B\u308B\u305F\u3073\u306B\u7B11\u3063\u3066\u3057\u307E\u3046\uFF57",
  "id" : 91370145104146433,
  "created_at" : "2011-07-14 04:55:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91368936121184256",
  "geo" : { },
  "id_str" : "91369782120685568",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u6687\u306A\u3093\u3060\u304C",
  "id" : 91369782120685568,
  "in_reply_to_status_id" : 91368936121184256,
  "created_at" : "2011-07-14 04:53:48 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 9, 20 ],
      "id_str" : "95958826",
      "id" : 95958826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 57, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91364940115484672",
  "text" : "\u604B\u306E\u4E00\u610F\u6027 RT @SugaTheKid: \u3010\u6570\u5B66\u5927\u559C\u5229\u3011\u6570\u5B66\u7528\u8A9E\u306E\u524D\u306B\uFF62\u604B\u306E\uFF63\u3092\u3064\u3051\u3066\u4E00\u756A\u3068\u304D\u3081\u304B\u305B\u305F\u5974\u304C\u512A\u52DD #sugaku_ogiri",
  "id" : 91364940115484672,
  "created_at" : "2011-07-14 04:34:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91363585191718912",
  "text" : "RT @JOJO_math: \u3053\u3044\u3064\u306F\u975E\u6B63\u30FC\u30C3\uFF01\u30BC\u30ED\u4EE5\u4E0B\u306E\u306B\u304A\u3044\u304C\u30D7\u30F3\u30D7\u30F3\u3059\u308B\u305C\u30C3\u30FC\u30FC\u30FC\u30C3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91363300528500738",
    "text" : "\u3053\u3044\u3064\u306F\u975E\u6B63\u30FC\u30C3\uFF01\u30BC\u30ED\u4EE5\u4E0B\u306E\u306B\u304A\u3044\u304C\u30D7\u30F3\u30D7\u30F3\u3059\u308B\u305C\u30C3\u30FC\u30FC\u30FC\u30C3\uFF01",
    "id" : 91363300528500738,
    "created_at" : "2011-07-14 04:28:02 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 91363585191718912,
  "created_at" : "2011-07-14 04:29:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 23, 34 ],
      "id_str" : "95958826",
      "id" : 95958826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91363516530966528",
  "text" : "\u604B\u306E\u5909\u6570\u5909\u63DB \u604B\u6570\u5909\u63DB\u306E\u304C\u3088\u304B\u3063\u305F\u304B\uFF1F RT @SugaTheKid: \u3010\u6570\u5B66\u5927\u559C\u5229\u3011\u6570\u5B66\u7528\u8A9E\u306E\u524D\u306B\uFF62\u604B\u306E\uFF63\u3092\u3064\u3051\u3066\u4E00\u756A\u3068\u304D\u3081\u304B\u305B\u305F\u5974\u304C\u512A\u52DD #sugaku_ogiri",
  "id" : 91363516530966528,
  "created_at" : "2011-07-14 04:28:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91330189459603456",
  "text" : "@ayu167 \u307E\u3060\u30D9\u30C3\u30C9\u306E\u4E0A",
  "id" : 91330189459603456,
  "created_at" : "2011-07-14 02:16:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 40, 51 ],
      "id_str" : "95958826",
      "id" : 95958826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91330059826249729",
  "text" : "\u30CA\u30D3\u30A8\u30FB\u30B9\u30C8\u30FC\u30AF\u30B9\u65B9\u7A0B\u5F0F\u306E\u604B\u306E\u5B58\u5728\u3068\u305D\u306E\u306A\u3081\u3089\u304B\u3055\u2026\u3063\u3066\u4E00\u756A\u524D\u3058\u3083\u306A\u3044\u304B RT @SugaTheKid: \u3010\u6570\u5B66\u5927\u559C\u5229\u3011\u6570\u5B66\u7528\u8A9E\u306E\u524D\u306B\uFF62\u604B\u306E\uFF63\u3092\u3064\u3051\u3066\u4E00\u756A\u3068\u304D\u3081\u304B\u305B\u305F\u5974\u304C\u512A\u52DD #sugaku_ogiri",
  "id" : 91330059826249729,
  "created_at" : "2011-07-14 02:15:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91329447189413888",
  "text" : "@ayu167 \u4FFA\u307E\u3060\u59CB\u307E\u3063\u3066\u7121\u3044\u3093\u3059\u3051\u3069",
  "id" : 91329447189413888,
  "created_at" : "2011-07-14 02:13:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 10, 21 ],
      "id_str" : "95958826",
      "id" : 95958826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91327207359778816",
  "text" : "\u604B\u306E\u9078\u629E\u516C\u7406 RT @SugaTheKid: \u3010\u6570\u5B66\u5927\u559C\u5229\u3011\u6570\u5B66\u7528\u8A9E\u306E\u524D\u306B\uFF62\u604B\u306E\uFF63\u3092\u3064\u3051\u3066\u4E00\u756A\u3068\u304D\u3081\u304B\u305B\u305F\u5974\u304C\u512A\u52DD #sugaku_ogiri",
  "id" : 91327207359778816,
  "created_at" : "2011-07-14 02:04:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suga",
      "screen_name" : "SugaTheKid",
      "indices" : [ 10, 21 ],
      "id_str" : "95958826",
      "id" : 95958826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugaku_ogiri",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91326781986054144",
  "text" : "\u604B\u306E\u53CE\u675F\u534A\u5F84 RT @SugaTheKid: \u3010\u6570\u5B66\u5927\u559C\u5229\u3011\u6570\u5B66\u7528\u8A9E\u306E\u524D\u306B\uFF62\u604B\u306E\uFF63\u3092\u3064\u3051\u3066\u4E00\u756A\u3068\u304D\u3081\u304B\u305B\u305F\u5974\u304C\u512A\u52DD #sugaku_ogiri",
  "id" : 91326781986054144,
  "created_at" : "2011-07-14 02:02:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "tokoya",
      "screen_name" : "tokoya",
      "indices" : [ 21, 28 ],
      "id_str" : "4119831",
      "id" : 4119831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91325793631862784",
  "text" : "RT @hyuki: \u307F\u306A\u307F\u3061\u3083\u3093 RT @tokoya: \u6570\u5B66\u30AC\u30FC\u30EB\u8AAD\u3080\u3068\u8133\u5185\u3067\u767B\u5834\u4EBA\u7269\u304C\u300C\u3089\u304D\u2606\u3059\u305F\u300D\u306E\u30AD\u30E3\u30E9\u306B\u306A\u3063\u3066\u3057\u307E\u3046\u3093\u3060\u304C\u3001\u6700\u65B0\u520A\u306B\u767B\u5834\u306E\u30EA\u30B5\u306B\u8A72\u5F53\u3059\u308B\u30AD\u30E3\u30E9\u30AF\u30BF\u304C\u3044\u306A\u304F\u3066\u56F0\u3063\u3066\u3044\u308B\uFF08\u7B11\uFF09\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "tokoya",
        "screen_name" : "tokoya",
        "indices" : [ 10, 17 ],
        "id_str" : "4119831",
        "id" : 4119831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91318985940934657",
    "text" : "\u307F\u306A\u307F\u3061\u3083\u3093 RT @tokoya: \u6570\u5B66\u30AC\u30FC\u30EB\u8AAD\u3080\u3068\u8133\u5185\u3067\u767B\u5834\u4EBA\u7269\u304C\u300C\u3089\u304D\u2606\u3059\u305F\u300D\u306E\u30AD\u30E3\u30E9\u306B\u306A\u3063\u3066\u3057\u307E\u3046\u3093\u3060\u304C\u3001\u6700\u65B0\u520A\u306B\u767B\u5834\u306E\u30EA\u30B5\u306B\u8A72\u5F53\u3059\u308B\u30AD\u30E3\u30E9\u30AF\u30BF\u304C\u3044\u306A\u304F\u3066\u56F0\u3063\u3066\u3044\u308B\uFF08\u7B11\uFF09\u3002",
    "id" : 91318985940934657,
    "created_at" : "2011-07-14 01:31:57 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 91325793631862784,
  "created_at" : "2011-07-14 01:59:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91198275637612545",
  "text" : "\u663C\u5BDD\u3057\u305F\u3051\u3069\u30EC\u30DD\u30FC\u30C8\u7D42\u308F\u3063\u305F\u3057\u5BDD\u308B\u304B\u306A\u30FC\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 91198275637612545,
  "created_at" : "2011-07-13 17:32:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91198106229686273",
  "text" : "RT @JOJO_math: \u3060 \u304B \u3089 \u3053 \u306E '97 \u30BB \u30F3 \u30BF \u30FC \u8A66 \u9A13 \u3067 \u3053 \u306E \u82B1 \u4EAC \u9662 \u5178 \u660E \u306B \u7CBE \u795E \u7684 \u52D5 \u63FA \u306B \u3088 \u308B 39\/45 \u306E \u7D04 \u5206 \u3057 \u5FD8 \u308C \u306F \u6C7A \u3057 \u3066 \u306A \u3044 \uFF01 \u3068\u601D\u3063\u3066\u3044\u305F\u3060\u3053\u3046\u30C3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91197212670951425",
    "text" : "\u3060 \u304B \u3089 \u3053 \u306E '97 \u30BB \u30F3 \u30BF \u30FC \u8A66 \u9A13 \u3067 \u3053 \u306E \u82B1 \u4EAC \u9662 \u5178 \u660E \u306B \u7CBE \u795E \u7684 \u52D5 \u63FA \u306B \u3088 \u308B 39\/45 \u306E \u7D04 \u5206 \u3057 \u5FD8 \u308C \u306F \u6C7A \u3057 \u3066 \u306A \u3044 \uFF01 \u3068\u601D\u3063\u3066\u3044\u305F\u3060\u3053\u3046\u30C3\uFF01",
    "id" : 91197212670951425,
    "created_at" : "2011-07-13 17:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 91198106229686273,
  "created_at" : "2011-07-13 17:31:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91187915115347968",
  "text" : "\u5D16\u306E\u4E0A\u306E\u30DD\u30CB\u30E7\u2192\u307E\u306A\u677F\u306E\u4E0A\u306E\u9BC9\u2192\u80C3\u306E\u4E2D\u306E\u86D9 \u3053\u308C\u306F\u826F\u3044\u6D41\u308C\uFF1F",
  "id" : 91187915115347968,
  "created_at" : "2011-07-13 16:51:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91187676744650752",
  "text" : "\u80C3\u306E\u4E2D\u306E\u86D9\u3063\u3066\u307E\u306A\u677F\u306E\u9BC9\u306E\u5F8C\u6BB5\u968E\u3063\u3066\u89E3\u91C8\u3067OK?",
  "id" : 91187676744650752,
  "created_at" : "2011-07-13 16:50:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91183955935629313",
  "text" : "\u3067\u3082\u66F8\u304D\u7D42\u308F\u3063\u305F\uFF01",
  "id" : 91183955935629313,
  "created_at" : "2011-07-13 16:35:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91183702733889536",
  "text" : "\u3042\u308C\uFF1F\u30EC\u30DD\u30FC\u30C8\u306E\u53C2\u8003\u6587\u732E\u304C\u89E3\u6790\u3068\u7D71\u8A08\u306E\u6559\u79D1\u66F8\u3060\u3088\u3002\u3053\u3093\u306A\u306E\u7D76\u5BFE\u304A\u304B\u3057\u3044\u3088\u3002",
  "id" : 91183702733889536,
  "created_at" : "2011-07-13 16:34:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "101753216",
      "id" : 101753216
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 32, 42 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91182198404816896",
  "text" : "RT @factoring_bot: 817=19*43 RT @end313124: 817\u6587\u5B57\uFF0117\u6587\u5B57\u524A\u3089\u306A\u3044\u3068\u30FB\u30FB\u30FB\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/prime.4403.biz\/factoring_bot\/\" rel=\"nofollow\"\u003Efactoring_bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 13, 23 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "91181120334462976",
    "geo" : { },
    "id_str" : "91181609386123264",
    "in_reply_to_user_id" : 155546700,
    "text" : "817=19*43 RT @end313124: 817\u6587\u5B57\uFF0117\u6587\u5B57\u524A\u3089\u306A\u3044\u3068\u30FB\u30FB\u30FB\u3002",
    "id" : 91181609386123264,
    "in_reply_to_status_id" : 91181120334462976,
    "created_at" : "2011-07-13 16:26:04 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "protected" : false,
      "id_str" : "101753216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727655584\/factan_normal.png",
      "id" : 101753216,
      "verified" : false
    }
  },
  "id" : 91182198404816896,
  "created_at" : "2011-07-13 16:28:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91181120334462976",
  "text" : "817\u6587\u5B57\uFF0117\u6587\u5B57\u524A\u3089\u306A\u3044\u3068\u30FB\u30FB\u30FB\u3002",
  "id" : 91181120334462976,
  "created_at" : "2011-07-13 16:24:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91176833789345792",
  "geo" : { },
  "id_str" : "91177048906809346",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u30FB\u30FB\u30FB\u3080\u3057\u308D\u89E3\u3063\u305F\u3089\u304A\u4E92\u3044\u5171\u6709\u3059\u308B\u611F\u3058\u3067\u884C\u304D\u307E\u3057\u3087\u3046\u304B\uFF57",
  "id" : 91177048906809346,
  "in_reply_to_status_id" : 91176833789345792,
  "created_at" : "2011-07-13 16:07:57 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91166606444601345",
  "geo" : { },
  "id_str" : "91167514570141696",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u805E\u304D\u5F79\u7981\u6B62\u4EE4\uFF01\u6050\u308D\u3057\u3044\u8A00\u8449\u3060\u3051\u3069\u558B\u308A\u305F\u304C\u308A\u306E\u5272\u306B\u81EA\u5206\u8A9E\u308A\u304C\u82E6\u624B\u306A\u306E\u3092\u6539\u5584\u3057\u306A\u304D\u3083\u3068\u601D\u3063\u3066\u308B\u304B\u3089\u4E01\u5EA6\u3044\u3044\u306E\u304B\u3082",
  "id" : 91167514570141696,
  "in_reply_to_status_id" : 91166606444601345,
  "created_at" : "2011-07-13 15:30:03 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91166968182353920",
  "text" : "\u6587\u5B66\u90E8\u79D1\u76EE\u306E\u30EC\u30DD\u30FC\u30C8\u3092\u66F8\u304F\u306E\u306B\u89E3\u6790\u306E\u6559\u79D1\u66F8\u3092\u5E83\u3052\u3066\u308B\u5909\u614B\u306F\u81EA\u5206\u3060\u3051\u3067\u3044\u3044\u3002",
  "id" : 91166968182353920,
  "created_at" : "2011-07-13 15:27:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91166609368035329",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u7A81\u7136\u3059\u307F\u307E\u305B\u3093\u304C\u96C6\u5408\u3068\u4F4D\u76F8\u306E\u8A66\u9A13\u7BC4\u56F2\u3063\u3066\u3069\u3053\u307E\u3067\u3067\u3059\u304B\uFF1F\u6700\u5F8C\u307E\u3067\u51FA\u640D\u306A\u3044\u3063\u3071\u306A\u3057\u3067\u5F53\u7136\u53CB\u9054\u3082\u3044\u306A\u3044\u306E\u3067\u3055\u3063\u3071\u308A\u306A\u306E\u3067\u3059\u30FB\u30FB\u30FB\u3002",
  "id" : 91166609368035329,
  "created_at" : "2011-07-13 15:26:28 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91165206071349248",
  "text" : "\u3042\u30FC\u4EBA\u74B0\u7DCF\u4EBA\u56F3\u66F8\u9928\u3067\u865A\u6570\u306E\u60C5\u7DD2\u501F\u308A\u3066\u304F\u308C\u3070\u826F\u304B\u3063\u305F\u304B\u306A\u30FB\u30FB\u30FB\u3002",
  "id" : 91165206071349248,
  "created_at" : "2011-07-13 15:20:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91163968835559424",
  "geo" : { },
  "id_str" : "91164471216713728",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3042\u308C\u306A\u3089\u6587\u5B66\u90E8\u56F3\u66F8\u9928\u884C\u3063\u3066\u307F\u3066\u3082\u3044\u3044\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u306D\u3002",
  "id" : 91164471216713728,
  "in_reply_to_status_id" : 91163968835559424,
  "created_at" : "2011-07-13 15:17:58 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91162993789894656",
  "geo" : { },
  "id_str" : "91164088448716801",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305D\u3057\u3066\u805E\u304D\u5F79\u306B\u5FB9\u3057\u3066\u3057\u307E\u3046\u306E\u306F\u6614\u304B\u3089\u306E\u60AA\u3044\u7656\u3002\u30BF\u30A4\u30D7\u306E\u597D\u304D\u597D\u304D\u3082\u7D50\u5C40\u7D75\u306B\u63CF\u3044\u305F\u9905\u306B\u306A\u308A\u304C\u3061\u3060\u3082\u3093\u306D\u3047\u3002\u305D\u3046\u3044\u3046\u8A71\u3082\u5ACC\u3044\u3058\u3083\u306A\u3051\u3069\u7D50\u5C40\u805E\u304D\u5F79\u306B\uFF08\uFF52\uFF59",
  "id" : 91164088448716801,
  "in_reply_to_status_id" : 91162993789894656,
  "created_at" : "2011-07-13 15:16:27 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91163163646627841",
  "geo" : { },
  "id_str" : "91163385701474304",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u53C2\u8003\u306B\u306A\u308B\u304B\u306F\u30A2\u30EC\u3067\u3059\u304C\u3082\u3063\u3066\u3044\u304D\u307E\u3059\u30FC",
  "id" : 91163385701474304,
  "in_reply_to_status_id" : 91163163646627841,
  "created_at" : "2011-07-13 15:13:39 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91162693356105728",
  "text" : "\u767A\u898B\u3066\u306E\u306F\u4E0D\u9069\u5207\u3060\u306A\u3001\u5C0E\u5165\u3068\u3059\u3079\u304D\u304B\u3002",
  "id" : 91162693356105728,
  "created_at" : "2011-07-13 15:10:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3059\u305F\u308A\u3059\u304F",
      "screen_name" : "asterisk37n",
      "indices" : [ 26, 38 ],
      "id_str" : "216776517",
      "id" : 216776517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91162551827693568",
  "text" : "RT @yuu_ane: \u898B\u3064\u304B\u3089\u3093\u2026\u56F0\u3063\u305F RT @asterisk37n: \u3010\u9999\u5DDD\u770C\u3092\u898B\u3064\u3051\u3089\u308C\u305F\u3089\u516C\u5F0FRT\u3011\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u9999\u5DDD\u770C\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.softama.com\/\" rel=\"nofollow\"\u003E\u30C4\u30A4\u30BF\u30DE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3042\u3059\u305F\u308A\u3059\u304F",
        "screen_name" : "asterisk37n",
        "indices" : [ 13, 25 ],
        "id_str" : "216776517",
        "id" : 216776517
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91162436660510720",
    "text" : "\u898B\u3064\u304B\u3089\u3093\u2026\u56F0\u3063\u305F RT @asterisk37n: \u3010\u9999\u5DDD\u770C\u3092\u898B\u3064\u3051\u3089\u308C\u305F\u3089\u516C\u5F0FRT\u3011\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u9999\u5DDD\u770C\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093\u3046\u3069\u3093",
    "id" : 91162436660510720,
    "created_at" : "2011-07-13 15:09:53 +0000",
    "user" : {
      "name" : "\u306F\u308B\u306D\uFF20\u3086\u30FC",
      "screen_name" : "yuu_harune",
      "protected" : false,
      "id_str" : "115959501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000001263784\/5d1dec393dfb874472791af500d391c3_normal.jpeg",
      "id" : 115959501,
      "verified" : false
    }
  },
  "id" : 91162551827693568,
  "created_at" : "2011-07-13 15:10:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91162500510400514",
  "text" : "\u79D1\u5B66\u7684\u767A\u898B\u306E\u4E8B\u4F8B\u2026\u865A\u6570\u306E\u767A\u898B\u3068\u304B\u3069\u3046\u3060\u308D\u3002\u7D50\u5C40\u6570\u5B66\u7CFB\u306E\u8A71\u306B\u843D\u3061\u7740\u3044\u3066\u3044\u304F\u79D1\u54F2\u30EC\u30DD\u30FC\u30C8\u2026\u3002",
  "id" : 91162500510400514,
  "created_at" : "2011-07-13 15:10:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91160085908291585",
  "geo" : { },
  "id_str" : "91162061157056512",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u8A9E\u308C\u307E\u305B\u3093\u304C\u67F3\u7530\u570B\u7537\u306E\u602A\u8AC7\u96C6\u307F\u305F\u3044\u306E\u306F\u6301\u3063\u3066\u307E\u3059\u3002\u7A4D\u8AAD\u306B\u306A\u3063\u3061\u3083\u3063\u3066\u307E\u3059\u304C\u3002",
  "id" : 91162061157056512,
  "in_reply_to_status_id" : 91160085908291585,
  "created_at" : "2011-07-13 15:08:23 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91161825000947713",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3069\u3063\u3061\u3082\u3054\u305F\u307E\u305C\u306B\u306A\u3063\u3066\u308B\u3051\u3069\u30CD\u30BF\u306B\u306A\u3089\u306A\u3044\u306E\u306F\u3042\u308B\u3002",
  "id" : 91161825000947713,
  "created_at" : "2011-07-13 15:07:27 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91160115566231552",
  "text" : "\u65E5\u4ED8\u5909\u3063\u305F\u2026",
  "id" : 91160115566231552,
  "created_at" : "2011-07-13 15:00:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91156891417321473",
  "text" : "\u3088\u3063\u3057\u3083\u554F\uFF12\u7D42\u308F\u3063\u305F\u3002\u5F8C\u308D\u304B\u3089\u3084\u3063\u3066\u308B\u304B\u3089\u3042\u3068\u554F1\u3060\u3051\u3084\u3063\u3064\u3051\u308C\u3070\u4ECA\u9031\u306F\u307B\u307C\u7D42\u4E86\u306E\u306F\u305A\u3002",
  "id" : 91156891417321473,
  "created_at" : "2011-07-13 14:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91127677720870914",
  "geo" : { },
  "id_str" : "91127986010603520",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u540C\u6027\u306A\u3089\u2026\u3063\u3066\u8A00\u8449\u904A\u3073\u306B\u3057\u3066\u3082\u4E4B\u306F\u9177\u3044\u30CD\u30BF\u3060\u306A\u3002",
  "id" : 91127986010603520,
  "in_reply_to_status_id" : 91127677720870914,
  "created_at" : "2011-07-13 12:52:59 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91127058557698048",
  "geo" : { },
  "id_str" : "91127451396214784",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4FFA\u3082\u4E0B\u5BBF\u751F\u306A\u306E\u306B\u8D77\u3053\u3057\u3066\u3082\u3089\u3048\u306A\u304B\u3063\u305F\u3002",
  "id" : 91127451396214784,
  "in_reply_to_status_id" : 91127058557698048,
  "created_at" : "2011-07-13 12:50:52 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91123425640333312",
  "text" : "\u5BDD \u904E \u304E \u305F\n\n\u3055\u3041\u30EC\u30DD\u30FC\u30C8\u306E\u6642\u9593\u3060\u3002",
  "id" : 91123425640333312,
  "created_at" : "2011-07-13 12:34:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "indices" : [ 3, 15 ],
      "id_str" : "94825321",
      "id" : 94825321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30DF\u30EB\u30AD\u30A3\u307B\u3080\u307B\u3080",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91057151220527105",
  "text" : "RT @milkyholmes: iphone\u3067\u300C\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA\u300D\u3063\u3066\u6253\u3064\u3068\u304D\u300C\u30DF\u300D\u2192\uFF08\u5909\u63DB\u3000\u30DF\u30EB\u30AD\u30A3\uFF09\u2192\u300C\u30DB\u300D\u2192\uFF08\u5909\u63DB\u3000\u30DB\u30FC\u30E0\u30BA\uFF09\u3063\u3066\u3044\u3064\u3082\u3084\u3063\u3066\u308B\u3093\u3067\u3059\u304C\u3000\u4ECA\u65E5\u306F\u300C\u30DB\u300D\u306E\u5909\u63DB\u306E\uFF11\u756A\u76EE\u304C\u300C\u307B\u3080\u307B\u3080\u300D\u306B\u306A\u3063\u3066\u305F\u304B\u3089\u3000\u307B\u3080\u307B\u3080\u304C\u53EF\u611B\u3044\u306E\u304C\u60AA\u3044\u3000 #\u30DF\u30EB\u30AD\u30A3\u307B\u3080\u307B\u3080",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u30DF\u30EB\u30AD\u30A3\u307B\u3080\u307B\u3080",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91047991724605440",
    "text" : "iphone\u3067\u300C\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA\u300D\u3063\u3066\u6253\u3064\u3068\u304D\u300C\u30DF\u300D\u2192\uFF08\u5909\u63DB\u3000\u30DF\u30EB\u30AD\u30A3\uFF09\u2192\u300C\u30DB\u300D\u2192\uFF08\u5909\u63DB\u3000\u30DB\u30FC\u30E0\u30BA\uFF09\u3063\u3066\u3044\u3064\u3082\u3084\u3063\u3066\u308B\u3093\u3067\u3059\u304C\u3000\u4ECA\u65E5\u306F\u300C\u30DB\u300D\u306E\u5909\u63DB\u306E\uFF11\u756A\u76EE\u304C\u300C\u307B\u3080\u307B\u3080\u300D\u306B\u306A\u3063\u3066\u305F\u304B\u3089\u3000\u307B\u3080\u307B\u3080\u304C\u53EF\u611B\u3044\u306E\u304C\u60AA\u3044\u3000 #\u30DF\u30EB\u30AD\u30A3\u307B\u3080\u307B\u3080",
    "id" : 91047991724605440,
    "created_at" : "2011-07-13 07:35:07 +0000",
    "user" : {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "protected" : false,
      "id_str" : "94825321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593967810226753537\/kej69_3u_normal.jpg",
      "id" : 94825321,
      "verified" : false
    }
  },
  "id" : 91057151220527105,
  "created_at" : "2011-07-13 08:11:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90966983188807680",
  "text" : "\u30D7\u30EC\u30BC\u30F3\u7D42\u308F\u3063\u305F\u3002\u6765\u9031\u5EA7\u3063\u3066\u308B\u3060\u3051\u304B\u2026\u3002",
  "id" : 90966983188807680,
  "created_at" : "2011-07-13 02:13:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 12, 21 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 22, 36 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90855052633321472",
  "geo" : { },
  "id_str" : "90965612683214848",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 @nisehorn @mearythindong \u304A\u3084\u3059\u307F\u3069\u3082\u3067\u3057\u305F\u30FC",
  "id" : 90965612683214848,
  "in_reply_to_status_id" : 90855052633321472,
  "created_at" : "2011-07-13 02:07:46 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 8, 15 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 44, 51 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90965260055494656",
  "text" : "\u3042\u308C\uFF1F\uFF57 QT @ayu167: 4\u9650\u30685\u9650\u306F\u51FA\u306A\u304F\u3066\u826F\u3044\u3084\u3001\u5E30\u3063\u3066BMS\u3084\u308D\u3046 RT @ayu167: \u5371\u6A5F\u611F\u306E\u7121\u3055\u3092\u4F55\u3068\u304B\u3057\u305F\u3044\u3002\u3053\u306E\u30CE\u30EA\u3060\u3068\u30EA\u30A2\u30EB\u306B\u7559\u5E74\u3057\u305D\u3046",
  "id" : 90965260055494656,
  "created_at" : "2011-07-13 02:06:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "indices" : [ 3, 15 ],
      "id_str" : "76905775",
      "id" : 76905775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90855680784875520",
  "text" : "RT @Einstein_ja: \u604B\u306B\u843D\u3061\u308B\u306E\u306F\u611A\u884C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u304C\u3001\u91CD\u529B\u306B\u305D\u306E\u8CAC\u4EFB\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/Einstein_ja\" rel=\"nofollow\"\u003E\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90855264307257344",
    "text" : "\u604B\u306B\u843D\u3061\u308B\u306E\u306F\u611A\u884C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u304C\u3001\u91CD\u529B\u306B\u305D\u306E\u8CAC\u4EFB\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
    "id" : 90855264307257344,
    "created_at" : "2011-07-12 18:49:17 +0000",
    "user" : {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "protected" : false,
      "id_str" : "76905775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433263313\/einstein_normal.jpg",
      "id" : 76905775,
      "verified" : false
    }
  },
  "id" : 90855680784875520,
  "created_at" : "2011-07-12 18:50:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90855640104321024",
  "text" : "\u4ECA\u3053\u305D\u76EE\u899A\u307E\u3057\u306E\u97F3\u91CF\u3001\u4E2D\u3092\u89E3\u653E\u3059\u308B\u6642\uFF01",
  "id" : 90855640104321024,
  "created_at" : "2011-07-12 18:50:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90855004348485633",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 90855004348485633,
  "created_at" : "2011-07-12 18:48:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90854949545717760",
  "text" : "\u307E\u3041\u307B\u304B\u306B\u4ED5\u4E8B\u3057\u3066\u306A\u3044\u3057\u5206\u696D\u3068\u3057\u3066\u306F\u3061\u3087\u3046\u3069\u3044\u3044\u306E\u304B\u306A\u3002",
  "id" : 90854949545717760,
  "created_at" : "2011-07-12 18:48:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90854858160214016",
  "text" : "\u6211\u306A\u304C\u3089\u9811\u5F35\u3063\u305F\u2026\u30022\u6642\u9593\u8FD1\u304F\u30B9\u30AB\u30A4\u30D7\u3067\u30C1\u30E3\u30C3\u30C8\u3055\u308C\u308B\u5185\u5BB9\u3092\u7E8F\u3081\u306A\u304C\u3089\u82F1\u8A9E\u306B\u8A33\u3059\u4F5C\u696D\u2026\u4ECA\u65E5\u306E\u30D7\u30EC\u30BC\u30F3\u7528\u306A\u3093\u3060\u3051\u3069\u8D77\u304D\u308C\u308B\u306E\u304B\u306A\u2026\u3002",
  "id" : 90854858160214016,
  "created_at" : "2011-07-12 18:47:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90806988317011968",
  "geo" : { },
  "id_str" : "90810616041836544",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3046\u3061\u306E\u73FE\u4EE3\u6587\u6559\u5E2B\u306F\u5165\u8A66\u5BFE\u7B56\u3084\u3063\u3066\u304F\u308C\u305F\u306A\u30FC\u3002\u30DE\u30FC\u30C1\u304F\u3089\u3044\u306E\u3084\u3064\u3060\u3051\u3069\u3053\u307D\u3063\u3066\u6301\u3063\u3066\u304D\u3066\u305F\u308F\u3002",
  "id" : 90810616041836544,
  "in_reply_to_status_id" : 90806988317011968,
  "created_at" : "2011-07-12 15:51:52 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90752337102123008",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 90752337102123008,
  "created_at" : "2011-07-12 12:00:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90710225736306688",
  "text" : "\uFF11\u6642\u9593\u7A0B\u6687\u30A1\uFF01",
  "id" : 90710225736306688,
  "created_at" : "2011-07-12 09:12:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90709049313726464",
  "text" : "\u3042\u3001\u30CE\u30FC\u30C8\u5145\u96FB\u5207\u308C\u305Forz",
  "id" : 90709049313726464,
  "created_at" : "2011-07-12 09:08:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90706839171383297",
  "text" : "\u84B8\u3059\u3002\u96E8\u306B\u52A0\u3048\u3066\u6A5F\u68B0\u71B1\u3002\u3002\u3002",
  "id" : 90706839171383297,
  "created_at" : "2011-07-12 08:59:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90705810769969152",
  "text" : "saezuri\u524D\u9762\u8868\u793A\u3067\u30B3\u30FC\u30EB\u3068\u3044\u3046\u3084\u308B\u6C17\u306E\u306A\u3055",
  "id" : 90705810769969152,
  "created_at" : "2011-07-12 08:55:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90704282327846912",
  "text" : "\u30E1\u30C7\u30A3\u30BB\u30F3\u3067\u30B3\u30FC\u30EB\u3084\u3063\u3066\u308B\u4EBA\u591A\u904E\u304E\u2026",
  "id" : 90704282327846912,
  "created_at" : "2011-07-12 08:49:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90656714969456640",
  "text" : "@ayu167 \u30B2\u30FC\u30BB\u30F3\u3067\u306F\u304A\u9759\u304B\u306B\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 90656714969456640,
  "created_at" : "2011-07-12 05:40:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90654841508077568",
  "geo" : { },
  "id_str" : "90655460901928960",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u843D\u3061\u7740\u3051\u3001\u541B\u306F\u8179\u304C\u6E1B\u3063\u3066\u3044\u308B\u3060\u3051\u306A\u3093\u3060\u3002",
  "id" : 90655460901928960,
  "in_reply_to_status_id" : 90654841508077568,
  "created_at" : "2011-07-12 05:35:20 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90655154084388865",
  "text" : "\u3053\u306E\u6697\u3055\u306F\u6587\u5B66\u90E8\u5B66\u751F\u306E\u5C06\u6765\u3092\u6587\u5B66\u7684\u306B\u6697\u55A9\u3057\u3066\u308B\uFF08\uFF77\uFF98\uFF6F",
  "id" : 90655154084388865,
  "created_at" : "2011-07-12 05:34:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90654316091809792",
  "geo" : { },
  "id_str" : "90654839356391424",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u30DD\u30B1\u30E2\u30F3\u597D\u304D\uFF1F",
  "id" : 90654839356391424,
  "in_reply_to_status_id" : 90654316091809792,
  "created_at" : "2011-07-12 05:32:52 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90654658493820929",
  "text" : "\u6587\u5B66\u90E8may\u6697\u3044",
  "id" : 90654658493820929,
  "created_at" : "2011-07-12 05:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90654028324814848",
  "geo" : { },
  "id_str" : "90654313898192896",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u7121\u8996\u304B\u3088\u3063",
  "id" : 90654313898192896,
  "in_reply_to_status_id" : 90654028324814848,
  "created_at" : "2011-07-12 05:30:47 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90653456435658752",
  "geo" : { },
  "id_str" : "90654026315726848",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u8AB0\uFF1F",
  "id" : 90654026315726848,
  "in_reply_to_status_id" : 90653456435658752,
  "created_at" : "2011-07-12 05:29:38 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90652796898127872",
  "geo" : { },
  "id_str" : "90653453231210496",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math AB\u597D\u304D\uFF1F",
  "id" : 90653453231210496,
  "in_reply_to_status_id" : 90652796898127872,
  "created_at" : "2011-07-12 05:27:22 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90644936516579328",
  "geo" : { },
  "id_str" : "90650481029947392",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u307F\u305F\u304B\u3063\u305F\u306A\u3002\u306A\u3093\u3064\u3063\u3066\u3002",
  "id" : 90650481029947392,
  "in_reply_to_status_id" : 90644936516579328,
  "created_at" : "2011-07-12 05:15:33 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J",
      "screen_name" : "Bla9Rabbit",
      "indices" : [ 3, 14 ],
      "id_str" : "216714861",
      "id" : 216714861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90650385324314625",
  "text" : "RT @Bla9Rabbit: \uFF31\u5168\u88F8\u3067\u4F55\u3092\u3057\u307E\u3059\u304B\uFF1F\n\uFF21\u65E9\u7A32\u7530\u300C\u9154\u308F\u305B\u3066\u8972\u3044\u307E\u3059\u300D\n\u6176\u61C9\u300C\u99C5\u306E\u30DB\u30FC\u30E0\u3092\u99C6\u3051\u629C\u3051\u307E\u3059\u300D\n\u4E0A\u667A\u300Cmixi\u306B\u30A2\u30C3\u30D7\u3057\u307E\u3059\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89496847382618113",
    "text" : "\uFF31\u5168\u88F8\u3067\u4F55\u3092\u3057\u307E\u3059\u304B\uFF1F\n\uFF21\u65E9\u7A32\u7530\u300C\u9154\u308F\u305B\u3066\u8972\u3044\u307E\u3059\u300D\n\u6176\u61C9\u300C\u99C5\u306E\u30DB\u30FC\u30E0\u3092\u99C6\u3051\u629C\u3051\u307E\u3059\u300D\n\u4E0A\u667A\u300Cmixi\u306B\u30A2\u30C3\u30D7\u3057\u307E\u3059\u300D",
    "id" : 89496847382618113,
    "created_at" : "2011-07-09 00:51:25 +0000",
    "user" : {
      "name" : "J",
      "screen_name" : "Bla9Rabbit",
      "protected" : false,
      "id_str" : "216714861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422749339220336641\/31S3EkL1_normal.jpeg",
      "id" : 216714861,
      "verified" : false
    }
  },
  "id" : 90650385324314625,
  "created_at" : "2011-07-12 05:15:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90643445533769728",
  "geo" : { },
  "id_str" : "90644777028173824",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u4E09\u9DF9\u8A73\u3057\u3044\u306E\uFF1F",
  "id" : 90644777028173824,
  "in_reply_to_status_id" : 90643445533769728,
  "created_at" : "2011-07-12 04:52:53 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr.\u30BF\u30F3\u30AF\u30C8\u30C3\u30D7",
      "screen_name" : "anti_gakureki",
      "indices" : [ 3, 17 ],
      "id_str" : "326738053",
      "id" : 326738053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90640130339110912",
  "text" : "RT @anti_gakureki: \u4ECA\u65E5\u306E\u4F1A\u793E\u8AAC\u660E\u4F1A\u3001\u30AF\u30FC\u30EB\u30D3\u30BA\u3067\u6765\u3066\u304F\u308C\u3068\u4F1D\u3048\u3089\u308C\u3066\u3044\u305F\u306B\u3082\u95A2\u308F\u3089\u305A\u30B9\u30FC\u30C4\u3092\u7740\u8FBC\u3093\u3060\u30AC\u30EA\u52C9\u9AD8\u5B66\u6B74\u306E\u30AF\u30BA\u3067\u3042\u3075\u308C\u304B\u3048\u3063\u3066\u3044\u305F\u3002\u4FFA\u306F\u304A\u6C17\u306B\u5165\u308A\u306ET\u30B7\u30E3\u30C4\u3001\u30B8\u30FC\u30D1\u30F3\u3001\u30B5\u30F3\u30C0\u30EB\u3067\u884C\u3063\u305F\u3002\u30AF\u30FC\u30EB\uFF08\u304B\u3063\u3053\u3044\u3044\uFF09\u30D3\u30BA\uFF08\u683C\u597D\uFF09\u306A\u3093\u3060\u304B\u3089\u30B9\u30FC\u30C4\u3067\u884C\u3063\u3066\u3069 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88567553160511488",
    "text" : "\u4ECA\u65E5\u306E\u4F1A\u793E\u8AAC\u660E\u4F1A\u3001\u30AF\u30FC\u30EB\u30D3\u30BA\u3067\u6765\u3066\u304F\u308C\u3068\u4F1D\u3048\u3089\u308C\u3066\u3044\u305F\u306B\u3082\u95A2\u308F\u3089\u305A\u30B9\u30FC\u30C4\u3092\u7740\u8FBC\u3093\u3060\u30AC\u30EA\u52C9\u9AD8\u5B66\u6B74\u306E\u30AF\u30BA\u3067\u3042\u3075\u308C\u304B\u3048\u3063\u3066\u3044\u305F\u3002\u4FFA\u306F\u304A\u6C17\u306B\u5165\u308A\u306ET\u30B7\u30E3\u30C4\u3001\u30B8\u30FC\u30D1\u30F3\u3001\u30B5\u30F3\u30C0\u30EB\u3067\u884C\u3063\u305F\u3002\u30AF\u30FC\u30EB\uFF08\u304B\u3063\u3053\u3044\u3044\uFF09\u30D3\u30BA\uFF08\u683C\u597D\uFF09\u306A\u3093\u3060\u304B\u3089\u30B9\u30FC\u30C4\u3067\u884C\u3063\u3066\u3069\u3046\u3059\u308B\u3002\u30AC\u30EA\u52C9\u9AD8\u5B66\u6B74\u306F\u3053\u308C\u3060\u304B\u3089\u601D\u3044\u3084\u3089\u308C\u308B\u3002",
    "id" : 88567553160511488,
    "created_at" : "2011-07-06 11:18:44 +0000",
    "user" : {
      "name" : "Mr.\u30BF\u30F3\u30AF\u30C8\u30C3\u30D7",
      "screen_name" : "anti_gakureki",
      "protected" : false,
      "id_str" : "326738053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1420247879\/DQN_normal.png",
      "id" : 326738053,
      "verified" : false
    }
  },
  "id" : 90640130339110912,
  "created_at" : "2011-07-12 04:34:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304D\u306E\u306D\uFF20\u4F50\u4E16\u4FDD\u93AE\u5B88\u5E9C",
      "screen_name" : "530spec",
      "indices" : [ 3, 11 ],
      "id_str" : "85556161",
      "id" : 85556161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90639889401516033",
  "text" : "RT @530spec: \u3010\u901F\u5831\u3011\u300C\u71B1\u4E2D\u75C7\u306B\u306A\u308B\u5974\u306F\u30D0\u30AB\u3057\u304B\u3044\u306A\u3044\u300D\u3068\u8C6A\u8A9E\u3057\u3066\u3044\u305F\u5F53\u793E\u76E3\u67FB\u5F79\u304C\u71B1\u4E2D\u75C7\u3067\u5165\u9662\u3057\u307E\u3057\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/extensions\/detail\/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\"\u003ESilver Bird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90628637585448961",
    "text" : "\u3010\u901F\u5831\u3011\u300C\u71B1\u4E2D\u75C7\u306B\u306A\u308B\u5974\u306F\u30D0\u30AB\u3057\u304B\u3044\u306A\u3044\u300D\u3068\u8C6A\u8A9E\u3057\u3066\u3044\u305F\u5F53\u793E\u76E3\u67FB\u5F79\u304C\u71B1\u4E2D\u75C7\u3067\u5165\u9662\u3057\u307E\u3057\u305F\u3002",
    "id" : 90628637585448961,
    "created_at" : "2011-07-12 03:48:45 +0000",
    "user" : {
      "name" : "\u3042\u304D\u306E\u306D\uFF20\u4F50\u4E16\u4FDD\u93AE\u5B88\u5E9C",
      "screen_name" : "530spec",
      "protected" : false,
      "id_str" : "85556161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604577400643411968\/IM85tcpw_normal.jpg",
      "id" : 85556161,
      "verified" : false
    }
  },
  "id" : 90639889401516033,
  "created_at" : "2011-07-12 04:33:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u68EE\u306E\u672A\u77E5311",
      "screen_name" : "morinomichi311",
      "indices" : [ 3, 18 ],
      "id_str" : "246659385",
      "id" : 246659385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90639562359050240",
  "text" : "RT @morinomichi311: \u4FE1\u7528\u3067\u304D\u306A\u3044\u8A00\u8449\u4E00\u89A7(\u30B0\u30EC\u30FC\u30C9\u30A2\u30C3\u30D7\u7248)\nsts\u300C\u4FFA\u306F\u53CB\u9054\u304C\u5C11\u306A\u3044\u300D\u300C\u4FFA\u306F\u8A18\u61B6\u529B\u304C\u60AA\u3044\u300D\u300C\u3088\u3057\u3084\u3059\u3055\u3093\u306E\u51FA\u8EAB\u6821\u77E5\u3089\u306A\u3044\u3067\u3059\u300D\nranaluta\u300C\u9662\u8A66\u3053\u3048\u30FC\u300D\u300C\u4FFA\u3001\u5E7E\u4F55\u306E\u4EBA\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u3089\u300D\n\u83C5\u300C\u30E1\u30C9\u304C\u3064\u3044\u305F\u3089\u8F9E\u3081\u308B\u300D\n\u9CE9\u5C71\u300CTrus ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90598506141716480",
    "text" : "\u4FE1\u7528\u3067\u304D\u306A\u3044\u8A00\u8449\u4E00\u89A7(\u30B0\u30EC\u30FC\u30C9\u30A2\u30C3\u30D7\u7248)\nsts\u300C\u4FFA\u306F\u53CB\u9054\u304C\u5C11\u306A\u3044\u300D\u300C\u4FFA\u306F\u8A18\u61B6\u529B\u304C\u60AA\u3044\u300D\u300C\u3088\u3057\u3084\u3059\u3055\u3093\u306E\u51FA\u8EAB\u6821\u77E5\u3089\u306A\u3044\u3067\u3059\u300D\nranaluta\u300C\u9662\u8A66\u3053\u3048\u30FC\u300D\u300C\u4FFA\u3001\u5E7E\u4F55\u306E\u4EBA\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u3089\u300D\n\u83C5\u300C\u30E1\u30C9\u304C\u3064\u3044\u305F\u3089\u8F9E\u3081\u308B\u300D\n\u9CE9\u5C71\u300CTrust me!\u300D",
    "id" : 90598506141716480,
    "created_at" : "2011-07-12 01:49:01 +0000",
    "user" : {
      "name" : "\u68EE\u306E\u672A\u77E5311",
      "screen_name" : "morinomichi311",
      "protected" : false,
      "id_str" : "246659385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/437171830676135936\/QsEgkgVz_normal.jpeg",
      "id" : 246659385,
      "verified" : false
    }
  },
  "id" : 90639562359050240,
  "created_at" : "2011-07-12 04:32:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "indices" : [ 3, 17 ],
      "id_str" : "122620301",
      "id" : 122620301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90610284972085248",
  "text" : "RT @NISIOISIN_BOT: \u6B63\u8AD6\u3060\u3063\u305F\u3002\u6B63\u8AD6\u904E\u304E\u3066\u6C17\u6301\u3061\u60AA\u3044\u3002\u307E\u3042\u3001\u6C17\u5206\u723D\u5FEB\u306A\u6B63\u8AD6\u306A\u3069\u3001\u751F\u307E\u308C\u3066\u3053\u306E\u65B9\u805E\u3044\u305F\u3053\u3068\u304C\u306A\u3044\u3051\u308C\u3069\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/NISIOISIN_BOT\/stats\" rel=\"nofollow\"\u003E\u897F\u5C3E\u7DAD\u65B0\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90606898944032769",
    "text" : "\u6B63\u8AD6\u3060\u3063\u305F\u3002\u6B63\u8AD6\u904E\u304E\u3066\u6C17\u6301\u3061\u60AA\u3044\u3002\u307E\u3042\u3001\u6C17\u5206\u723D\u5FEB\u306A\u6B63\u8AD6\u306A\u3069\u3001\u751F\u307E\u308C\u3066\u3053\u306E\u65B9\u805E\u3044\u305F\u3053\u3068\u304C\u306A\u3044\u3051\u308C\u3069\u3002",
    "id" : 90606898944032769,
    "created_at" : "2011-07-12 02:22:22 +0000",
    "user" : {
      "name" : "\u897F\u5C3E\u7DAD\u65B0BOT",
      "screen_name" : "NISIOISIN_BOT",
      "protected" : false,
      "id_str" : "122620301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752231484\/NISIOISIN_normal.JPG",
      "id" : 122620301,
      "verified" : false
    }
  },
  "id" : 90610284972085248,
  "created_at" : "2011-07-12 02:35:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90582438748762112",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\n\n\u65E5\u66DC\u65E5\u306E\u904B\u52D5\u3067\u672A\u3060\u7B4B\u8089\u75DB\u2026",
  "id" : 90582438748762112,
  "created_at" : "2011-07-12 00:45:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90468925028040705",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 90468925028040705,
  "created_at" : "2011-07-11 17:14:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90436668053655552",
  "text" : "RT @tameninaru: \u30CD\u30C3\u30C8\u30B2\u30FC\u30E0\u3067\u30EC\u30D9\u30EB\u304C\u4E0A\u304C\u308B\u3068\u73FE\u5B9F\u3067\u306E\u30EC\u30D9\u30EB\u304C\u4E0B\u304C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90435187606949889",
    "text" : "\u30CD\u30C3\u30C8\u30B2\u30FC\u30E0\u3067\u30EC\u30D9\u30EB\u304C\u4E0A\u304C\u308B\u3068\u73FE\u5B9F\u3067\u306E\u30EC\u30D9\u30EB\u304C\u4E0B\u304C\u308B",
    "id" : 90435187606949889,
    "created_at" : "2011-07-11 15:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 90436668053655552,
  "created_at" : "2011-07-11 15:05:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90401502530772993",
  "text" : "\u30EA\u30B9\u30CB\u30F3\u30B0\u2026\u7720\u3044",
  "id" : 90401502530772993,
  "created_at" : "2011-07-11 12:46:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90397059894611968",
  "geo" : { },
  "id_str" : "90397222495203328",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3068\u304A\u3082\u3063\u305F\u3089\u3042\u3068\uFF14\uFF0C\uFF15\u3057\u304B\u306A\u304B\u3063\u305F\uFF57",
  "id" : 90397222495203328,
  "in_reply_to_status_id" : 90397059894611968,
  "created_at" : "2011-07-11 12:29:12 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90389364349214720",
  "geo" : { },
  "id_str" : "90390474753458176",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 Cal\uFF4C\u8A66\u9A13\u7BC4\u56F2\u4F55\u51E6\u307E\u3067\uFF1F",
  "id" : 90390474753458176,
  "in_reply_to_status_id" : 90389364349214720,
  "created_at" : "2011-07-11 12:02:23 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90389467214524416",
  "text" : "\u52C9\u5F37\u3059\u308B\u306E\u306B\u97F3\u697D\u306E\u30D7\u30EC\u30A4\u30EA\u30B9\u30C8\u7528\u610F\u3057\u305F\u3051\u3069\u82F1\u8A9E\u306E\u30EA\u30B9\u30CB\u30F3\u30B0\u3060\u3063\u3066\u3053\u3068\u306B\u6C17\u304C\u4ED8\u3044\u305Forz",
  "id" : 90389467214524416,
  "created_at" : "2011-07-11 11:58:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90386686575521793",
  "text" : "\u3061\u3087\u3063\u3068\u524D\u307E\u3067\u30EA\u30B5\u3061\u3083\u3093bot\u306E\u7D39\u4ECB\u30DA\u30FC\u30B8\u306E\u5225\u9805\u76EE\u306B\u307E\u3068\u3081\u304C\u3042\u3063\u305F\u3051\u3069\u306A\u3041\u3002\u4E2D\u4E8C\u3063\u307D\u3044\u6570\u5B66\u7528\u8A9E\u307E\u3068\u3081\u3001\u307F\u305F\u3044\u306A\u3002",
  "id" : 90386686575521793,
  "created_at" : "2011-07-11 11:47:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 30, 35 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math_ogiri",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90386472192049152",
  "text" : "exponential explosion \u6307\u6570\u7206\u767A RT @np2i: \u8D85\u7ACB\u65B9\u4F53\uFF1C\u30CF\u30A4\u30D1\u30FC\u30AD\u30E5\u30FC\u30D6\uFF1E RT @fumiexcel:\u3010\u5927\u559C\u5229\u3011\u4E00\u756A\u4E2D\u4E8C\u75C5\u3063\u307D\u3044\u6570\u5B66\u7528\u8A9E\u77E5\u3063\u3066\u308B\u5974\u304C\u512A\u52DD\u3002 #math_ogiri",
  "id" : 90386472192049152,
  "created_at" : "2011-07-11 11:46:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90374018418479104",
  "text" : "\u6700\u8FD1\u98DF\u4E8B\u306E\u7D42\u4E86\u6761\u4EF6\u304C\u300C\u6E80\u8179\u300D\u304B\u3089\u300C\u7A7A\u8179\u3067\u306A\u3044\u300D\u306B\u306A\u3063\u3066\u304D\u305F\u3002",
  "id" : 90374018418479104,
  "created_at" : "2011-07-11 10:56:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90269080896028672",
  "text" : "\u723D\u304C\u6EB6\u3051\u308B\u306E\u304C\u65E9\u305D\u3046\u3060",
  "id" : 90269080896028672,
  "created_at" : "2011-07-11 04:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 45, 52 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90263350696611841",
  "text" : "RT @hyuki: #mathgirl \u305D\u306E\u3046\u3061\u30D5\u30A3\u30FC\u30EB\u30BA\u8CDE\u8A18\u8005\u4F1A\u898B\u3067\u2026(^^) RT @tenapi: \u3060\u3051\u3069\u3001\u300C\u6570\u5B66\u30AC\u30FC\u30EB\u300D\u8AAD\u3093\u3067\u6570\u5B66\u79D1\u3092\u5FD7\u671B\u3059\u308B\u3053\u3068\u306B\u3057\u307E\u3057\u305F\u3001\u3068\u9762\u63A5\u3067\u8A00\u3046\u53D7\u9A13\u751F\u306B\u306F\u3001\u6B8B\u5FF5\u306A\u304C\u3089\u3001\u307E\u3060\u51FA\u4F1A\u3063\u3066\u3044\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "api",
        "screen_name" : "TenApi",
        "indices" : [ 34, 41 ],
        "id_str" : "3240677334",
        "id" : 3240677334
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mathgirl",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90260091961491456",
    "text" : "#mathgirl \u305D\u306E\u3046\u3061\u30D5\u30A3\u30FC\u30EB\u30BA\u8CDE\u8A18\u8005\u4F1A\u898B\u3067\u2026(^^) RT @tenapi: \u3060\u3051\u3069\u3001\u300C\u6570\u5B66\u30AC\u30FC\u30EB\u300D\u8AAD\u3093\u3067\u6570\u5B66\u79D1\u3092\u5FD7\u671B\u3059\u308B\u3053\u3068\u306B\u3057\u307E\u3057\u305F\u3001\u3068\u9762\u63A5\u3067\u8A00\u3046\u53D7\u9A13\u751F\u306B\u306F\u3001\u6B8B\u5FF5\u306A\u304C\u3089\u3001\u307E\u3060\u51FA\u4F1A\u3063\u3066\u3044\u306A\u3044\u3002",
    "id" : 90260091961491456,
    "created_at" : "2011-07-11 03:24:17 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 90263350696611841,
  "created_at" : "2011-07-11 03:37:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90258588911673344",
  "text" : "\u8131\u6C34\u8001\u5973\u3084\u8131\u6C34\u8001\u7537\u3082\u3044\u305D\u3046\u3002",
  "id" : 90258588911673344,
  "created_at" : "2011-07-11 03:18:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90258376113659905",
  "text" : "\u8131\u6C34\u5C11\u5E74\u3082",
  "id" : 90258376113659905,
  "created_at" : "2011-07-11 03:17:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90258285151789056",
  "text" : "\u8131\u6C34\u5C11\u5973\u304C\u591A\u767A\u3057\u305D\u3046\u306A\u6C17\u6E29",
  "id" : 90258285151789056,
  "created_at" : "2011-07-11 03:17:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90229646125309952",
  "text" : "\u4E8C\u5EA6\u5BDD\u3057\u305F\u2026\u4E8C\u9650\u306F\u884C\u304F\u3088\u3002\u3053\u306E\u611F\u3058\u3060\u3068\u9045\u523B\u3060\u304C",
  "id" : 90229646125309952,
  "created_at" : "2011-07-11 01:23:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90212149024133120",
  "text" : "\u6765\u9031\u3067\u3082\u3044\u3044\u304B\u306A\u30FC\uFF08\u3057\u308D\u3081",
  "id" : 90212149024133120,
  "created_at" : "2011-07-11 00:13:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90212024604303360",
  "text" : "@koketomi \u304A\u306F\u3088\u3046",
  "id" : 90212024604303360,
  "created_at" : "2011-07-11 00:13:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90211947403939840",
  "text" : "\u3068\u3053\u308D\u3067\u4E00\u9650\u884C\u304B\u306A\u3044\u3068\u8A66\u9A13\u7BC4\u56F2\u89E3\u3089\u306A\u3044\u3093\u3060\u304C",
  "id" : 90211947403939840,
  "created_at" : "2011-07-11 00:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90208739927400448",
  "geo" : { },
  "id_str" : "90210038353895424",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u305D\u308C\u306F\u9593\u9055\u3063\u3066\u308B\u3002",
  "id" : 90210038353895424,
  "in_reply_to_status_id" : 90208739927400448,
  "created_at" : "2011-07-11 00:05:23 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90208549258543106",
  "text" : "\u9593\u9055\u3063\u3066\u306F\u3044\u306A\u3044",
  "id" : 90208549258543106,
  "created_at" : "2011-07-10 23:59:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90205975319027712",
  "geo" : { },
  "id_str" : "90207849581518848",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u541B\u9054\u4EBA\u9593\u306F\u9B42\u306E\u5728\u308A\u304B\u306A\u3093\u3066\u305D\u3082\u305D\u3082\u81EA\u899A\u3067\u304D\u3066\u306A\u3044\u3093\u3060\u308D\u3046\uFF1F",
  "id" : 90207849581518848,
  "in_reply_to_status_id" : 90205975319027712,
  "created_at" : "2011-07-10 23:56:41 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90205251604459520",
  "geo" : { },
  "id_str" : "90205769210925056",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u3069\u3057\u305F\uFF1F",
  "id" : 90205769210925056,
  "in_reply_to_status_id" : 90205251604459520,
  "created_at" : "2011-07-10 23:48:25 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90205021446225920",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 90205021446225920,
  "created_at" : "2011-07-10 23:45:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90204959517327361",
  "text" : "\u5BDD\u574A\u306B\u306A\u308B\u306E\u304B\u306A\u3001\u7BC4\u56F2\u78BA\u304B\u3081\u306B\u9045\u523B\u3057\u3066\u884C\u304F\u304B\u306A\u30FC",
  "id" : 90204959517327361,
  "created_at" : "2011-07-10 23:45:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E5\u30FC\u5B50\uFF08\u308Dbot\uFF09",
      "screen_name" : "DigitalCuko",
      "indices" : [ 0, 12 ],
      "id_str" : "180848288",
      "id" : 180848288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90088690038214656",
  "geo" : { },
  "id_str" : "90089463077797891",
  "in_reply_to_user_id" : 180848288,
  "text" : "@DigitalCuko \u308F\u304B\u308A\u306B\u304F\u3044\u306A",
  "id" : 90089463077797891,
  "in_reply_to_status_id" : 90088690038214656,
  "created_at" : "2011-07-10 16:06:16 +0000",
  "in_reply_to_screen_name" : "DigitalCuko",
  "in_reply_to_user_id_str" : "180848288",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305B\u307E\u3072\u308D",
      "screen_name" : "semahiro",
      "indices" : [ 3, 12 ],
      "id_str" : "99500452",
      "id" : 99500452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90062397598990337",
  "text" : "RT @semahiro: \u3010 \u7FA4\u99AC\u770C\u6C11\u3092\u6FC0\u6012\u3055\u305B\u308B\u4E00\u8A00\u3011\n\u4E94\u4F4D\u300C\u0644\u0627 \u0623\u0645\u0644\u0643 \u0627\u0644\u0628\u062D\u0631\u300D\n\u56DB\u4F4D\u300C\u0644\u0645 \u0623\u0643\u0646 \u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0644\u0643\u0647\u0631\u0628\u0627\u0626\u064A\u0629\u300D\n\u4E09\u4F4D\u300C\u062A\u0641\u0636\u0644 \u062A\u0648\u062A\u0634\u064A\u063A\u064A\u300D\n\u4E8C\u4F4D\u300C\u0644\u0646 \u0623\u0639\u064A\u0634 \u0641\u064A \u0634\u062C\u0631\u0629\u300D\n\u4E00\u4F4D\u300C\u0627\u0644\u064A\u0627\u0628\u0627\u0646\u064A\u0629 \u0627\u0644\u0646\u0627\u0637\u0642\u0629\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tabtter.jp\" rel=\"nofollow\"\u003ETabtter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90034392168280066",
    "text" : "\u3010 \u7FA4\u99AC\u770C\u6C11\u3092\u6FC0\u6012\u3055\u305B\u308B\u4E00\u8A00\u3011\n\u4E94\u4F4D\u300C\u0644\u0627 \u0623\u0645\u0644\u0643 \u0627\u0644\u0628\u062D\u0631\u300D\n\u56DB\u4F4D\u300C\u0644\u0645 \u0623\u0643\u0646 \u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0644\u0643\u0647\u0631\u0628\u0627\u0626\u064A\u0629\u300D\n\u4E09\u4F4D\u300C\u062A\u0641\u0636\u0644 \u062A\u0648\u062A\u0634\u064A\u063A\u064A\u300D\n\u4E8C\u4F4D\u300C\u0644\u0646 \u0623\u0639\u064A\u0634 \u0641\u064A \u0634\u062C\u0631\u0629\u300D\n\u4E00\u4F4D\u300C\u0627\u0644\u064A\u0627\u0628\u0627\u0646\u064A\u0629 \u0627\u0644\u0646\u0627\u0637\u0642\u0629\u300D",
    "id" : 90034392168280066,
    "created_at" : "2011-07-10 12:27:26 +0000",
    "user" : {
      "name" : "\u305B\u307E\u3072\u308D",
      "screen_name" : "semahiro",
      "protected" : false,
      "id_str" : "99500452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551367714577457152\/v6V7U8wS_normal.png",
      "id" : 99500452,
      "verified" : false
    }
  },
  "id" : 90062397598990337,
  "created_at" : "2011-07-10 14:18:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90057692600741888",
  "text" : "\u306A\u304B\u536F\u306A\u3046\u3001\u304B\u306A\u3002\uFF08\u56DE\u6587\uFF09",
  "id" : 90057692600741888,
  "created_at" : "2011-07-10 14:00:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90040796593668096",
  "geo" : { },
  "id_str" : "90045131763363841",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u624D\u80FD\uFF1F",
  "id" : 90045131763363841,
  "in_reply_to_status_id" : 90040796593668096,
  "created_at" : "2011-07-10 13:10:07 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 18, 30 ],
      "id_str" : "229754624",
      "id" : 229754624
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 32, 42 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90041004526284800",
  "text" : "\u306B\u305B\u307B\u304C\u8179\u7ACB\u305F\u3057\u3044\u4EF6\u306B\u3064\u3044\u3066 RT @nisehorrrrn: @end313124 \u5929\u304B\u3089\u6388\u304B\u3063\u305F\u624D\u80FD\u304C\u3053\u3093\u306A\u306B\u3082\u6E80\u3061\u6EA2\u308C\u308B\u308F\u3057\u304C\u3001\u5929\u3092\u88CF\u5207\u308A\u571F\u306B\u5E30\u308C\u308B\u306F\u305A\u304C\u3042\u308D\u3046\u304B(\u3044\u3084\u3001\u306A\u3044)\u3002",
  "id" : 90041004526284800,
  "created_at" : "2011-07-10 12:53:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90040794857213952",
  "text" : "\u4F55\u304B\u51B7\u305F\u3044\u3082\u306E\u3067\u3082\u98DF\u3079\u3066\u5E30\u308A\u305F\u3044\u304C\u5E30\u8DEF\u306B\u4F55\u3082\u7121\u3044",
  "id" : 90040794857213952,
  "created_at" : "2011-07-10 12:52:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89993322889871360",
  "geo" : { },
  "id_str" : "90040481739833344",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u571F\u306B\u5E30\u308C",
  "id" : 90040481739833344,
  "in_reply_to_status_id" : 89993322889871360,
  "created_at" : "2011-07-10 12:51:38 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90040359098392576",
  "text" : "\u7B4B\u8089\u75DB\u304C\u5FCD\u3073\u5BC4\u308B\u2026",
  "id" : 90040359098392576,
  "created_at" : "2011-07-10 12:51:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90027549492641792",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 90027549492641792,
  "created_at" : "2011-07-10 12:00:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89992569831964672",
  "geo" : { },
  "id_str" : "89993180321288192",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u3056\u307E\u3041",
  "id" : 89993180321288192,
  "in_reply_to_status_id" : 89992569831964672,
  "created_at" : "2011-07-10 09:43:40 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89992673917800448",
  "text" : "\u4E57\u308A\u7D99\u304E\u30CB\u30A2\u30DF\u30B9\u2026\u7126\u308B\u3093\u3058\u3083\u306A\u3044\u3001\u4FFA\u306F\u30C4\u30A4\u3066\u3044\u306A\u3044\u3060\u3051\u306A\u3093\u3060",
  "id" : 89992673917800448,
  "created_at" : "2011-07-10 09:41:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89985030620852224",
  "geo" : { },
  "id_str" : "89992167455596544",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30D5\u30EA\u30FC\u30B6\u30FC\u306F\uFF1F",
  "id" : 89992167455596544,
  "in_reply_to_status_id" : 89985030620852224,
  "created_at" : "2011-07-10 09:39:39 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89984749204029440",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u52D8\u5F01\u3057\u3066\u304F\u308C",
  "id" : 89984749204029440,
  "created_at" : "2011-07-10 09:10:10 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89984568576323584",
  "text" : "\u4E45\u3005\u306B\u904B\u52D5\u3057\u306B\u884C\u3053\u3046\u3068\u601D\u3063\u305F\u3089\u59CB\u307E\u308B\u524D\u306B\u6C57\u3060\u304F\u306E\u6E80\u8EAB\u5275\u75CD\u3067\u3059orz",
  "id" : 89984568576323584,
  "created_at" : "2011-07-10 09:09:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89984217848623104",
  "text" : "\u3066\u304B\u85E4\u68EE\u3067\u4E8B\u6545\u306A\u304B\u3063\u305F\u3089\u4E88\u5B9A\u901A\u308A\u30D0\u30A4\u30C8\u7D42\u308F\u3063\u3066\u30AE\u30EA\u30AE\u30EA\u5B87\u6CBB\u306E\u4E8B\u6545\u907F\u3051\u3089\u308C\u305F\u3093\u3058\u3083\u2026",
  "id" : 89984217848623104,
  "created_at" : "2011-07-10 09:08:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89984010738073600",
  "text" : "\u81EA\u5206\u306E\u30DF\u30B9\u306F\u4ED5\u65B9\u306A\u3044\u304C\u30C4\u30A4\u3066\u306A\u3055\u904E\u304E\u308B\u3002",
  "id" : 89984010738073600,
  "created_at" : "2011-07-10 09:07:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89983807536631808",
  "text" : "\u884C\u304D\u306B\u85E4\u68EE\u3067\u4EBA\u8EAB\u4E8B\u6545\u2192\u30D0\u30A4\u30C8\u304C30\u5206\u7E70\u4E0B\u3052\u2192\u5B87\u6CBB\u3067\u4EBA\u8EAB\u4E8B\u6545\u2192\uFF2A\uFF32\u3067\u306A\u304F\u8FD1\u9244\u4F7F\u3046\u4E8B\u306B\u306A\u308A\u6700\u5BC4\u99C5\u307E\u3067\u5F92\u6B69\u2192\u66F2\u304C\u308B\u3068\u3053\u9593\u9055\u3048\u305F\u3089\u3057\u304F\u8FD1\u9244\u306E\u4E00\u500B\u5148\u306E\u99C5\u3078\u2192\u5230\u7740\u3057\u96FB\u8ECA\u5F85\u3061\u2190\u30A4\u30DE\u30B3\u30B3",
  "id" : 89983807536631808,
  "created_at" : "2011-07-10 09:06:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E2D\u91CE\u6893\u3067\u306A\u3044\u3002",
      "screen_name" : "gozisaruo",
      "indices" : [ 3, 13 ],
      "id_str" : "115645537",
      "id" : 115645537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89983131020558336",
  "text" : "RT @gozisaruo: \u30DD\u30B1\u30C3\u30C8\u306E\u4E2D\u306B\u306F\u300C\u865A\u7A7A\u300D\u304C\u3072\u3068\u3064 \u30DD\u30B1\u30C3\u30C8\u3092\u53E9\u304F\u3068\u300C\u865A\u7A7A\u300D\u304C\u3075\u305F\u3064 \u3082\u3046\u3072\u3068\u3064\u53E9\u304F\u3068\u300C\u865A\u7A7A\u300D\u306F\u307F\u3063\u3064 \u53E9\u3044\u3066\u307F\u308B\u305F\u3073    \u56E0    \u679C    \u304C    \u4E71    \u308C   \u308B   \uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89687892825354241",
    "text" : "\u30DD\u30B1\u30C3\u30C8\u306E\u4E2D\u306B\u306F\u300C\u865A\u7A7A\u300D\u304C\u3072\u3068\u3064 \u30DD\u30B1\u30C3\u30C8\u3092\u53E9\u304F\u3068\u300C\u865A\u7A7A\u300D\u304C\u3075\u305F\u3064 \u3082\u3046\u3072\u3068\u3064\u53E9\u304F\u3068\u300C\u865A\u7A7A\u300D\u306F\u307F\u3063\u3064 \u53E9\u3044\u3066\u307F\u308B\u305F\u3073    \u56E0    \u679C    \u304C    \u4E71    \u308C   \u308B   \uFF01\uFF01",
    "id" : 89687892825354241,
    "created_at" : "2011-07-09 13:30:34 +0000",
    "user" : {
      "name" : "\u4E2D\u91CE\u6893\u3067\u306A\u3044\u3002",
      "screen_name" : "gozisaruo",
      "protected" : false,
      "id_str" : "115645537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1461969631\/19010848_normal.png",
      "id" : 115645537,
      "verified" : false
    }
  },
  "id" : 89983131020558336,
  "created_at" : "2011-07-10 09:03:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89930772454195200",
  "text" : "\u7194\u3051\u308B",
  "id" : 89930772454195200,
  "created_at" : "2011-07-10 05:35:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89922134872309760",
  "text" : "RT @tameninaru: \u5F7C\u3089\u306E\u5F69\u308A\u3092\u6DFB\u3048\u308B\u8AD6\u6587\u3001\u300E\u5C0F\u8AD6\u6587\u3092\u8AAD\u3080\u969B\u306B\u3001\u524D\u3082\u3063\u3066\u5F15\u3044\u3066\u304A\u3044\u305F\u4E0D\u9069\u5F53\u306A\u5F37\u8ABF\u7DDA\u304C\u4E0E\u3048\u308B\u5F71\u97FF\u300F\u306B\u5BFE\u3057\u3066\u3002\uFF082002\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u6587\u5B66\u8CDE\uFF1A\u30F4\u30A3\u30C3\u30AD\u30FC\u30FBL\u30FB\u30B7\u30EB\u30F4\u30A1\u30FC\u30BA\u3001\u30C7\u30A4\u30F4\u30A3\u30C3\u30C9\u30FBS\u30FB\u30AF\u30E9\u30A4\u30CA\u30FC\uFF09http:\/\/goo.gl\/sTnr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89921806139539456",
    "text" : "\u5F7C\u3089\u306E\u5F69\u308A\u3092\u6DFB\u3048\u308B\u8AD6\u6587\u3001\u300E\u5C0F\u8AD6\u6587\u3092\u8AAD\u3080\u969B\u306B\u3001\u524D\u3082\u3063\u3066\u5F15\u3044\u3066\u304A\u3044\u305F\u4E0D\u9069\u5F53\u306A\u5F37\u8ABF\u7DDA\u304C\u4E0E\u3048\u308B\u5F71\u97FF\u300F\u306B\u5BFE\u3057\u3066\u3002\uFF082002\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u6587\u5B66\u8CDE\uFF1A\u30F4\u30A3\u30C3\u30AD\u30FC\u30FBL\u30FB\u30B7\u30EB\u30F4\u30A1\u30FC\u30BA\u3001\u30C7\u30A4\u30F4\u30A3\u30C3\u30C9\u30FBS\u30FB\u30AF\u30E9\u30A4\u30CA\u30FC\uFF09http:\/\/goo.gl\/sTnr",
    "id" : 89921806139539456,
    "created_at" : "2011-07-10 05:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 89922134872309760,
  "created_at" : "2011-07-10 05:01:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89921399690506240",
  "text" : "\u6025\u3044\u3067\u306F\u3044\u306A\u3044\u304C\u5272\u306B\u5206\u523B\u307F\u306E\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\u306A\u306E\u306B\u4EBA\u8EAB\u4E8B\u6545\u2026\u65E9\u304F\u3082\u8A70\u3093\u3060\uFF1F",
  "id" : 89921399690506240,
  "created_at" : "2011-07-10 04:58:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89916731182682112",
  "text" : "\u96E2\u8131\u30A1\uFF01",
  "id" : 89916731182682112,
  "created_at" : "2011-07-10 04:39:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89916659141324800",
  "text" : "\u8D85\u306F\u4ECA\u65E5\u5FD9\u3057\u3044\u306A\u3002\u305F\u307E\u306B\u306F\u30A2\u30EA\u304B\u3002\u3068\u3044\u3046\u304B\u666E\u6BB5\u306E\u30C4\u30B1\u304B\u3002",
  "id" : 89916659141324800,
  "created_at" : "2011-07-10 04:39:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89908993224478720",
  "text" : "\u8074\u724C\u306F\u3057\u3066\u3044\u305F\u3002",
  "id" : 89908993224478720,
  "created_at" : "2011-07-10 04:09:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89908942892843009",
  "text" : "\u95D8\u724C\u306F\u3057\u3066\u3044\u305F\u304C\u3001\u5F8C\u6094\u306F\u3057\u3066\u3044\u306A\u3044\u3002",
  "id" : 89908942892843009,
  "created_at" : "2011-07-10 04:08:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89908767705149441",
  "text" : "\u30DE\u30B8\u9EBB\u96C0\u3068\u304B\u3084\u3063\u3066\u308B\u5834\u5408\u3058\u3083\u306A\u304B\u3063\u305F\uFF57\uFF57\uFF57",
  "id" : 89908767705149441,
  "created_at" : "2011-07-10 04:08:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89908636553457664",
  "text" : "\u82F1\u8A9E\u306E\u8AB2\u984C\u304C\u7D42\u308F\u308B\u6C17\u304C\u3057\u306A\u3044\u3043\u2026\u666E\u6BB5\u983C\u307F\u306B\u3057\u3066\u308B\u6708\u66DC4\u9650\u306B\u30C6\u30B9\u30C8\u3068\u3044\u3046\u3002\u305D\u3063\u3061\u306E\u52C9\u5F37\u3082\u305B\u306A\u30FB\u30FB\u30FB\u3002",
  "id" : 89908636553457664,
  "created_at" : "2011-07-10 04:07:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89869643489095681",
  "text" : "6\u6642\u9593\u4F4D\u3067\u76EE\u899A\u3081\u305F\u3002\u5E78\u305B\u306A\u5922\u3092\u898B\u305F\u6C17\u304C\u3059\u308B\u3002",
  "id" : 89869643489095681,
  "created_at" : "2011-07-10 01:32:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89774992924999680",
  "text" : "\uFF11\uFF10\u5E61\u306E\u500D\u6E80\u3066\u640D\u3057\u305F\u6C17\u304C\u3059\u308B\u3088\u3046\u306A\u2026",
  "id" : 89774992924999680,
  "created_at" : "2011-07-09 19:16:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89774760824807427",
  "text" : "\u4ECA\u591C\u306E\u7406\u4E0D\u5C3D\u548C\u4E86\u3001\u30E9\u30B9\u9806\u8FFD\u3063\u304B\u3051\u7ACB\u76F4\u306E\u4E0B\u5BB6\u304B\u3089\u3002\n\u7ACB\u76F4\u3001\u4E09\u8272\u3001\u8868\u30C9\u30E9\uFF11\u3001\u88CF\u30C9\u30E9\uFF16\n\u500D\u6E80\u3002",
  "id" : 89774760824807427,
  "created_at" : "2011-07-09 19:15:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89769799567163392",
  "text" : "@nico_reflexio \u4F5C\u3063\u305F\u3089zip\u3067\u304F\u308C",
  "id" : 89769799567163392,
  "created_at" : "2011-07-09 18:56:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89665509821382656",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 89665509821382656,
  "created_at" : "2011-07-09 12:01:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89621033820237824",
  "text" : "\u3066\u304B\u8CC7\u6599\u898B\u308B\u9650\u308A\u6709\u610F\u6C34\u6E96\u3068\u304B\u6BCD\u5E73\u5747\u3068\u304B\u6BCD\u96C6\u56E3\u3068\u304B\u6A19\u672C\u5206\u6563\u3068\u304B\u305D\u3093\u306A\u5358\u8A9E\u3067\u3066\u304D\u305F\u8A18\u61B6\u304C\u306A\u3044\u304B\u3089\u3053\u308C\u3063\u3066\u3053\u3053\u307E\u3067\u53B3\u5BC6\u306B\u3084\u3089\u306A\u304F\u3066\u3082\u826F\u304B\u3063\u305F\u3093\u3058\u3083\u2026\u307E\u3041\u3044\u3044\u3051\u3069\u3002",
  "id" : 89621033820237824,
  "created_at" : "2011-07-09 09:04:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89617979918139392",
  "geo" : { },
  "id_str" : "89618931169505280",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3055\u3093\u304D\u3085\uFF57\u307E\u3060\u304A\uFF4B \u52A9\u304B\u308B\u308F\u3002",
  "id" : 89618931169505280,
  "in_reply_to_status_id" : 89617979918139392,
  "created_at" : "2011-07-09 08:56:32 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89616650378297344",
  "text" : "\u554F\u4E00800\u5B57(40\u70B9)\u3001\u554F\u4E8C600\u5B57(40\u70B9)\u3001\u554F\u4E09\u7121\u5236\u9650(20\u70B9)\u3067\u554F\u4E09\u306E\u62EC\u5F27\uFF11\u3067\u65E2\u306B800\u5B57\u4EE5\u4E0A\u3042\u308B\u4EF6\u306B\u3064\u3044\u3066",
  "id" : 89616650378297344,
  "created_at" : "2011-07-09 08:47:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89403407265316865",
  "text" : "\u305D\u3093\u306A\u3053\u3093\u306A\u3067\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\u30A2\u30F3\u30B1\u30FC\u30C8\u7B54\u3048\u3066\u304F\u3060\u3055\u3063\u305F\u65B9\u672C\u5F53\u306B\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\uFF01\u975E\u5E38\u306B\u52A9\u304B\u308A\u307E\u3059\u3002",
  "id" : 89403407265316865,
  "created_at" : "2011-07-08 18:40:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89402591640956928",
  "text" : "\u5BFE\u7ACB\u4EEE\u8AAC\u3001\u5E30\u7121\u4EEE\u8AAC\u3001\u6BCD\u96C6\u56E3\u3001\u6BCD\u5206\u6563\u2026\u2026\u53BB\u5E74\u5F8C\u671F\u3084\u3063\u305F\u3064\u3082\u308A\u306B\u306A\u3063\u3066\u305F\u304C\u3084\u3063\u3071\u308A\u3064\u3082\u308A\u6B62\u307E\u308A\u304B\u30FC\u3002\u8D77\u304D\u305F\u3089\u8003\u3048\u76F4\u305D\u3046\u3002",
  "id" : 89402591640956928,
  "created_at" : "2011-07-08 18:36:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89402149867503616",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u4E00\u5FDC\u5927\u5B66\u751F\u3092\u60F3\u5B9A\u3057\u305F\u30A2\u30F3\u30B1\u30FC\u30C8\u306A\u3093\u3067\u901A\u3063\u3066\u308B\u5927\u5B66\u306B\u3063\u3066\u610F\u5473\u3067\u3059\u3002\u82F1\u8A9E\u306E\u8AB2\u984C\u306E\u4E00\u90E8\u306A\u306E\u3067\u305D\u3053\u307E\u3067\u6DF1\u304F\u8003\u3048\u3089\u308C\u3066\u3044\u307E\u305B\u3093\u3067\u7533\u3057\u8A33\u306A\u3044\u3067\u3059\u3002",
  "id" : 89402149867503616,
  "created_at" : "2011-07-08 18:35:08 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89400807270780930",
  "geo" : { },
  "id_str" : "89401687420321793",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\u52A9\u304B\u308A\u307E\u3059\u3002\u3061\u306A\u307F\u306B\u30AB\u30E9\u30FC\u306F\u96F0\u56F2\u6C17\u3068\u304B\u5B66\u98A8\u307F\u305F\u3044\u306A\u610F\u5473\u3067\u3059\u3002",
  "id" : 89401687420321793,
  "in_reply_to_status_id" : 89400807270780930,
  "created_at" : "2011-07-08 18:33:17 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89395784809852928",
  "geo" : { },
  "id_str" : "89396034941370368",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u5F53\u7136\u53EF\u3067\u3059\uFF01\u3084\u3063\u3066\u3044\u305F\u3060\u3051\u308B\u3068\u52A9\u304B\u308A\u307E\u3059\u3002",
  "id" : 89396034941370368,
  "in_reply_to_status_id" : 89395784809852928,
  "created_at" : "2011-07-08 18:10:50 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89393840435380224",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 89393840435380224,
  "created_at" : "2011-07-08 18:02:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "indices" : [ 0, 7 ],
      "id_str" : "26393410",
      "id" : 26393410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89392512548089856",
  "geo" : { },
  "id_str" : "89393020859985920",
  "in_reply_to_user_id" : 26393410,
  "text" : "@tomo37 \u6D77\u5916\u306E\u4EBA\u306E\u30C7\u30FC\u30BF\u3063\u3066\u3059\u3054\u304F\u53D6\u308A\u306B\u304F\u3044\u3093\u3067\u52A9\u304B\u308A\u307E\u3059\u3002\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 89393020859985920,
  "in_reply_to_status_id" : 89392512548089856,
  "created_at" : "2011-07-08 17:58:51 +0000",
  "in_reply_to_screen_name" : "tomo37",
  "in_reply_to_user_id_str" : "26393410",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 6, 15 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89388531071463425",
  "text" : "@np2i @bukuburi \u307E\u3041\u671F\u5F85\u3068\u73FE\u5B9F\u3068\u4E21\u65B9\u5206\u3051\u3066\u805E\u304F\u3063\u3066\u6848\u3082\u3042\u3063\u305F\u3093\u3067\u3059\u304C\u610F\u8B58\u8ABF\u67FB\u3063\u3066\u3053\u3068\u3067\u73FE\u5B9F\u306F\u898B\u306A\u3044\u3053\u3068\u306B\u3057\u307E\u3057\u305F\u2190",
  "id" : 89388531071463425,
  "created_at" : "2011-07-08 17:41:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89385985338650624",
  "geo" : { },
  "id_str" : "89388316411183104",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k \u305D\u3053\u307E\u3067\u7D30\u304B\u3044\u7D71\u8A08\u3058\u3083\u306A\u3044\u3093\u3067\u3059\u3051\u3069\u306D\u30FC\u3002\u4E00\u5FDC\u6559\u80B2\u306B\u5BFE\u3059\u308B\u610F\u8B58\u4E91\u3005\u307F\u305F\u3044\u306A\u30A2\u30F3\u30B1\u30FC\u30C8\u3067\u3059\u3002",
  "id" : 89388316411183104,
  "in_reply_to_status_id" : 89385985338650624,
  "created_at" : "2011-07-08 17:40:10 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89385023404388353",
  "geo" : { },
  "id_str" : "89385460585070592",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\u52A9\u304B\u308A\u307E\u3059\u3002",
  "id" : 89385460585070592,
  "in_reply_to_status_id" : 89385023404388353,
  "created_at" : "2011-07-08 17:28:49 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 0, 9 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89384021494214656",
  "geo" : { },
  "id_str" : "89384487896616960",
  "in_reply_to_user_id" : 187163335,
  "text" : "@bukuburi \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\u307E\u3041\u610F\u8B58\u8ABF\u67FB\u7684\u306A\u7269\u306A\u3093\u3067\u7D50\u679C\u306F\u3068\u3082\u304B\u304F\u3001\u3067\u3059\u3002",
  "id" : 89384487896616960,
  "in_reply_to_status_id" : 89384021494214656,
  "created_at" : "2011-07-08 17:24:57 +0000",
  "in_reply_to_screen_name" : "bukuburi",
  "in_reply_to_user_id_str" : "187163335",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89383254486028289",
  "text" : "\u3042\u3001\u82F1\u8A9E\u30B3\u30FC\u30EB\u3068\u304B\u3053\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u306F\u30DE\u30B8\u30AD\u30C1\u3060\u306A\u3002\u6587\u5B66\u90E8\u82F1\u8A9E\u3082\u65E9\u3081\u306B\u3084\u308D\u3046\u3068\u601D\u3063\u3066\u3084\u3063\u3066\u306A\u3044\u3057\u3002\u706B\u66DC\u306E\u30D5\u30E9\u30F3\u30B9\u8A9E\u306E\u4E88\u7FD2\u3082\u3084\u3063\u3066\u306D\u3047\u3002\u3042\u308C\uFF1F",
  "id" : 89383254486028289,
  "created_at" : "2011-07-08 17:20:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89381778447536128",
  "text" : "\u3053\u3093\u306A\u611F\u3058\u3067\u697D\u3060\u3068\u601D\u3046\u3093\u3067\u6687\u306A\u4EBA\u306F\u304A\u9858\u3044\u3057\u307E\u3059\u3045\u3002\u3063\u3066\u4EBA\u304C\u3044\u308B\u3068\u304D\u306B\u3084\u308B\u3079\u304D\u3060\u3063\u305Forz",
  "id" : 89381778447536128,
  "created_at" : "2011-07-08 17:14:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89381570082910208",
  "text" : "\u5927\u5B66\u306B\u4F55\u3092\u6C42\u3081\u3066\u3044\u307E\u3059\u304B\uFF1F\n\u56FD\u7C4D\u30FB\u6027\u5225\u30FB\u5E74\u9F62\u3092\u6559\u3048\u3066\u4E0B\u3055\u3044\n\u2460\u5B66\u554F\n\u2461\u5C31\u8077\u306E\u305F\u3081\u306E\u30B9\u30AD\u30EB\n\u2462\u4EA4\u53CB\u95A2\u4FC2\u30FB\u4EBA\u8108\n\u2463\u30CD\u30FC\u30E0\u30D0\u30EA\u30E5\u30FC\n\u2464\u30D0\u30A4\u30C8\n\u2465\u5FD7\u671B\u5927\u5B66\u306E\u30AB\u30E9\u30FC\n\u2466\u8DA3\u5473\u30FB\u30B5\u30FC\u30AF\u30EB\u6D3B\u52D5\n\u2467\u5927\u5B66\u306E\u7ACB\u5730\u30FB\u8857\n\uFF11\uFF08\u305D\u3046\u601D\u308F\u306A\u3044\uFF09\uFF5E\uFF14\uFF08\u305D\u3046\u601D\u3046\uFF09\u3067\u7B54\u3048\u3066\u304F\u3060\u3055\u3044\n\u307E\u305F\u4ED6\u306B\u6C42\u3081\u3066\u3044\u308B\u3053\u3068\u304C\u3042\u308C\u3070\u3002",
  "id" : 89381570082910208,
  "created_at" : "2011-07-08 17:13:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89380510018707457",
  "text" : "\u3066\u304B\uFF34\uFF2C\u4E0A\u306E\u5927\u5B66\u751F\u306B\uFF24\uFF2D\u9001\u3063\u305F\u65B9\u304C\u65E9\u3044\u304B\uFF1F\n\u3082\u3061\u308D\u3093\u30B9\u30EB\u30FC\u3057\u305F\u304B\u3063\u305F\u3089\u30B9\u30EB\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
  "id" : 89380510018707457,
  "created_at" : "2011-07-08 17:09:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89379483999678466",
  "text" : "\u6B63\u76F4\u5FD8\u308C\u3066\u305F\u3002\u96C0\u8358\u3067\u53CB\u9054\u3068\u6253\u3063\u3066\u307E\u3057\u305F\u3002\u3054\u3081\u3093\u306A\u3055\u3044\u3002",
  "id" : 89379483999678466,
  "created_at" : "2011-07-08 17:05:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89379335756197888",
  "text" : "\u8D77\u304D\u3066\u3066\u6687\u3067\uFF11\u5206\u3082\u304B\u304B\u3089\u305A\u306B\u7D42\u308F\u308B\u30A2\u30F3\u30B1\u30FC\u30C8\u306B\u5354\u529B\u3057\u3066\u304F\u308C\u308B\u5927\u5B66\u751F\u30EA\u30D7\u30E9\u30A4\u304F\u3060\u3055\u3044\u2026\u3002\u706B\u66DC\u767A\u8868\u3067\u7D71\u8A08\u51E6\u7406\u3069\u3053\u308D\u304B\u96C6\u8A08\u3055\u3048\u3067\u304D\u3066\u306A\u3044orz",
  "id" : 89379335756197888,
  "created_at" : "2011-07-08 17:04:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89377432171331584",
  "text" : "\u3053\u306E\u6642\u9593\u3063\u3066\u3053\u3093\u306A\u306B\u7A4F\u3084\u304B\u3060\u3063\u305F\u3063\u3051\u30FB\u30FB\u30FB\u3002",
  "id" : 89377432171331584,
  "created_at" : "2011-07-08 16:56:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89376901700927489",
  "text" : "\uFF34\uFF2C\u4E0A\u306E\u5927\u5B66\u751F\u306B\u30A2\u30F3\u30B1\u30FC\u30C8\u306E\u304A\u9858\u3044\u3057\u3088\u3046\u3068\u601D\u3063\u305F\u3089\u4EBA\u3044\u306D\u3047\uFF57\uFF57\uFF57\uFF57",
  "id" : 89376901700927489,
  "created_at" : "2011-07-08 16:54:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89281227449843712",
  "geo" : { },
  "id_str" : "89281548460883969",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30E9\u30FC\u30E1\u30F3\u597D\u304D\uFF1F",
  "id" : 89281548460883969,
  "in_reply_to_status_id" : 89281227449843712,
  "created_at" : "2011-07-08 10:35:54 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89281417309208576",
  "text" : "\u96FB\u8ECA\u306E\u624B\u3059\u308A\u304C\u51B7\u3048\u3066\u308B\u3068\u3073\u3063\u304F\u308A\u3059\u308B\u304C\u751F\u6E29\u3044\u3068\u3052\u3093\u306A\u308A\u3059\u308B",
  "id" : 89281417309208576,
  "created_at" : "2011-07-08 10:35:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89280786217443328",
  "geo" : { },
  "id_str" : "89281014945415168",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30DE\u30A4\u30DB\u30FC\u30E0\u3067\u3082\u8CB7\u3046\u306E\u304B\uFF1F\uFF57",
  "id" : 89281014945415168,
  "in_reply_to_status_id" : 89280786217443328,
  "created_at" : "2011-07-08 10:33:47 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89280653073465344",
  "text" : "\u6211\u306A\u304C\u3089\u8868\u73FE\u304C\u30D0\u30AB\u3060\u306A\u2026",
  "id" : 89280653073465344,
  "created_at" : "2011-07-08 10:32:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89280563957075968",
  "text" : "\u5149\u306E\u901F\u3055\u3067\u96FB\u6C60\u304C\u30DE\u30C3\u30CF\u306A\u3093\u3060\u304C",
  "id" : 89280563957075968,
  "created_at" : "2011-07-08 10:31:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89280265079369728",
  "text" : "\u4ECA\u65E5\u306F\u4E57\u308A\u63DB\u3048\u305F\u3044\u30EC\u30D9\u30EB\u3060\u304C\u2026",
  "id" : 89280265079369728,
  "created_at" : "2011-07-08 10:30:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89280094031458304",
  "text" : "\u307E\u3041\u968F\u5206\u6642\u9593\u5DEE\u3042\u308B\u304B\u3002\u305D\u308C\u3088\u308A20\u6642\u307E\u3067\u306B\u5E30\u5B85\u51FA\u6765\u308B\u304B\u306A",
  "id" : 89280094031458304,
  "created_at" : "2011-07-08 10:30:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89279538625912832",
  "text" : "\u51FA\u753A\u307E\u3067\uFF11\uFF10\u5206\u3066\u3068\u3053\u304B\u304F\u308B\u30FC\u3069\u3055\u3093\u3068\u3059\u308C\u9055\u3063\u305F\u3089\u3068\u601D\u3046\u3068\u80F8\u71B1",
  "id" : 89279538625912832,
  "created_at" : "2011-07-08 10:27:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89279255116128256",
  "text" : "\u7A7A\u6C17\u306F\u51AC\u306E\u304C\u597D\u304D\u3060\u3051\u3069\u666F\u8272\u306F\u590F\u306E\u304C\u597D\u304D\u3060\u3002",
  "id" : 89279255116128256,
  "created_at" : "2011-07-08 10:26:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89279070176673792",
  "text" : "\u7A7A\u304C\u8584\u7D2B\u3067\u7F8E\u3057\u3044",
  "id" : 89279070176673792,
  "created_at" : "2011-07-08 10:26:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89278007931449344",
  "text" : "\u30A2\u30AF\u30A2\u30E9\u30A4\u30F3\u306E\u65B9\u5F0F\u597D\u304D\u3060\uFF57\uFF57",
  "id" : 89278007931449344,
  "created_at" : "2011-07-08 10:21:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89277908396421120",
  "text" : "RT @wwwwww_bot: [\u304A\u7B11\u3044] \u65E5\u672C\u306F\u3069\u3046\u3084\u3063\u3066\uFF17\uFF19\uFF15\u5146\u5186\u306E\u501F\u91D1\u8FD4\u3059\u306E\uFF1F\uFF1F\u300C\u30C6\u30F3\u30B3\u30FC\u30DE\u30B8\u30C3\u30AF\u3067\u6D88\u3059\u300D\u300C\u5FB3\u653F\u4EE4\u30AB\u30FC\u30C9\u300D\u300C\u5FB3\u5DDD\u57CB\u8535\u91D1\u306E\u518D\u767A\u6398\u958B\u59CB\u300D\u300C\u30A2\u30AF\u30A2\u30E9\u30A4\u30F3\u306E\u901A\u884C\u6599\u3092\u4E00\u77AC795\u5146\u5186\u306B\u5024\u4E0A\u3052\u3057\u3066\u3001\u8AB0\u304B\u304CETC\u3067\u901A\u904E\u3059\u308B\u307E\u3067\u5F85\u3064\u3002\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89277129690333184",
    "text" : "[\u304A\u7B11\u3044] \u65E5\u672C\u306F\u3069\u3046\u3084\u3063\u3066\uFF17\uFF19\uFF15\u5146\u5186\u306E\u501F\u91D1\u8FD4\u3059\u306E\uFF1F\uFF1F\u300C\u30C6\u30F3\u30B3\u30FC\u30DE\u30B8\u30C3\u30AF\u3067\u6D88\u3059\u300D\u300C\u5FB3\u653F\u4EE4\u30AB\u30FC\u30C9\u300D\u300C\u5FB3\u5DDD\u57CB\u8535\u91D1\u306E\u518D\u767A\u6398\u958B\u59CB\u300D\u300C\u30A2\u30AF\u30A2\u30E9\u30A4\u30F3\u306E\u901A\u884C\u6599\u3092\u4E00\u77AC795\u5146\u5186\u306B\u5024\u4E0A\u3052\u3057\u3066\u3001\u8AB0\u304B\u304CETC\u3067\u901A\u904E\u3059\u308B\u307E\u3067\u5F85\u3064\u3002\u300D",
    "id" : 89277129690333184,
    "created_at" : "2011-07-08 10:18:21 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 89277908396421120,
  "created_at" : "2011-07-08 10:21:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89276506454491136",
  "text" : "\u305D\u3057\u3066\u8912\u3081\u3089\u308C\u308B\u306E\u304C\u4E0B\u624B\u306A\u79C1\u306F\u30C6\u30F3\u30D1\u3063\u3066\u3057\u307E\u3046\u306E\u3067\u3059\u3002",
  "id" : 89276506454491136,
  "created_at" : "2011-07-08 10:15:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89276354608119808",
  "text" : "\u7D20\u76F4\u306B\u5B09\u3057\u3044\u3093\u3060\u3051\u3069\u306D\u3002\u7A7F\u3061\u904E\u304E\uFF1F",
  "id" : 89276354608119808,
  "created_at" : "2011-07-08 10:15:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89276218184171520",
  "text" : "\u6642\u3005\u3001\u307B\u3093\u3068\u306B\u6642\u3005\u3060\u3051\u3069\u300C\u670D\u300D\u3092\u8912\u3081\u3089\u308C\u308B\u4E8B\u304C\u3042\u308B\u3002\u3067\u3082\u300C\u670D\u300D\u3057\u304B\u8912\u3081\u3089\u308C\u306A\u3044\u3063\u3066\u3053\u3068\u306F\u300C\u670D\u306E\u30C1\u30E7\u30A4\u30B9\u306F\u3044\u3044\u3051\u3069\u7D44\u307F\u5408\u308F\u305B\u306F\u30A2\u30EC\u300D\u3063\u3066\u4E8B\u306A\u306E\u304B\u306A\u3001\u3068\u601D\u308F\u306A\u3044\u3067\u306F\u306A\u3044\u3002",
  "id" : 89276218184171520,
  "created_at" : "2011-07-08 10:14:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89275558571163650",
  "text" : "\u884C\u304D\u3082\u5E30\u308A\u3082\u5404\u505C\u304B\u2026\u96FB\u8ECA\u306E\u30C4\u30E2\u304C\u60AA\u3044\u306A\u3041",
  "id" : 89275558571163650,
  "created_at" : "2011-07-08 10:12:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89275368766320642",
  "text" : "\u3042\u3001\uFF34\uFF2C\u56DE\u53CE\u3057\u3066\u305F\u3089\u306B\u305B\u307B\u30FC\u898B\u9003\u3057\u305F\u2026",
  "id" : 89275368766320642,
  "created_at" : "2011-07-08 10:11:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89274876577329152",
  "text" : "\u30A2\u30F3\u30B5\u30A4\u30AF\u30ED\u30DA\u30C7\u30A3\u30A2\u306E\u304C\u8A73\u3057\u304B\u3063\u305F\u304C",
  "id" : 89274876577329152,
  "created_at" : "2011-07-08 10:09:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89274775440068609",
  "text" : "RT @tameninaru: \u98A8\u3068\u6876\u5C4B\u306E\u95A2\u4FC2\u306F\u300C\u98A8\u304C\u5439\u304F\u2192\u7802\u307C\u3053\u308A\u304C\u305F\u3063\u3066\u76EE\u306B\u7802\u304C\u5165\u308B\u2192\u76EE\u3092\u60A3\u3063\u3066\u76F2\u76EE\u306B\u306A\u308B\u4EBA\u304C\u5897\u3048\u308B\u2192\uFF08\u76F2\u76EE\u306B\u306A\u3063\u305F\u4EBA\u304C\uFF09\u751F\u8A08\u3092\u7ACB\u3066\u308B\u305F\u3081\u3001\u4E09\u5473\u7DDA\u3092\u5F3E\u304F\u4EBA\u304C\u5897\u3048\u308B\u2192\u4E09\u5473\u7DDA\u306B\u5F35\u308B\u732B\u306E\u76AE\u304C\u5927\u91CF\u306B\u5FC5\u8981\u3068\u306A\u308B\u2192\u732B\u304C\u6E1B\u308B\u2192\u30CD\u30BA\u30DF\u304C\u5897\u3048\u3066\u6876\u3092\u304B\u3058\u308A\u58CA\u3057\u3066\u3057\u307E\u3046\u2192\u6876 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89257429962989568",
    "text" : "\u98A8\u3068\u6876\u5C4B\u306E\u95A2\u4FC2\u306F\u300C\u98A8\u304C\u5439\u304F\u2192\u7802\u307C\u3053\u308A\u304C\u305F\u3063\u3066\u76EE\u306B\u7802\u304C\u5165\u308B\u2192\u76EE\u3092\u60A3\u3063\u3066\u76F2\u76EE\u306B\u306A\u308B\u4EBA\u304C\u5897\u3048\u308B\u2192\uFF08\u76F2\u76EE\u306B\u306A\u3063\u305F\u4EBA\u304C\uFF09\u751F\u8A08\u3092\u7ACB\u3066\u308B\u305F\u3081\u3001\u4E09\u5473\u7DDA\u3092\u5F3E\u304F\u4EBA\u304C\u5897\u3048\u308B\u2192\u4E09\u5473\u7DDA\u306B\u5F35\u308B\u732B\u306E\u76AE\u304C\u5927\u91CF\u306B\u5FC5\u8981\u3068\u306A\u308B\u2192\u732B\u304C\u6E1B\u308B\u2192\u30CD\u30BA\u30DF\u304C\u5897\u3048\u3066\u6876\u3092\u304B\u3058\u308A\u58CA\u3057\u3066\u3057\u307E\u3046\u2192\u6876\u5C4B\u304C\u5132\u304B\u308B\u300D",
    "id" : 89257429962989568,
    "created_at" : "2011-07-08 09:00:04 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 89274775440068609,
  "created_at" : "2011-07-08 10:08:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 3, 17 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89273571599327232",
  "text" : "RT @mearythindong: \u6587\u5B66\u90E8\u6559\u6388\u300C\u50D5\u306F\u7686\u3055\u3093\u306E\uFF08\u63D0\u51FA\u3055\u308C\u305F\uFF09\u5BBF\u984C\u3092\u7121\u304F\u3057\u305F\u304B\u3082\u3057\u308C\u306A\u3044\u3002\u305D\u306E\u53EF\u80FD\u6027\u306F\u6975\u3081\u3066\u9AD8\u3044\u300D\u2015\u8AB2\u984C\u63D0\u51FA\u3084\u6210\u7E3E\u8A55\u4FA1\u306B\u3053\u3060\u308F\u308B\u306E\u304C\u3044\u304B\u306B\u4E0B\u3089\u306A\u3044\u304B\u3068\u3044\u3046\u3053\u3068\u3092\u8A00\u3044\u305F\u3044\u3093\u3067\u3059\u3088\u306D\u3001\u5206\u304B\u308A\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89241633387843584",
    "text" : "\u6587\u5B66\u90E8\u6559\u6388\u300C\u50D5\u306F\u7686\u3055\u3093\u306E\uFF08\u63D0\u51FA\u3055\u308C\u305F\uFF09\u5BBF\u984C\u3092\u7121\u304F\u3057\u305F\u304B\u3082\u3057\u308C\u306A\u3044\u3002\u305D\u306E\u53EF\u80FD\u6027\u306F\u6975\u3081\u3066\u9AD8\u3044\u300D\u2015\u8AB2\u984C\u63D0\u51FA\u3084\u6210\u7E3E\u8A55\u4FA1\u306B\u3053\u3060\u308F\u308B\u306E\u304C\u3044\u304B\u306B\u4E0B\u3089\u306A\u3044\u304B\u3068\u3044\u3046\u3053\u3068\u3092\u8A00\u3044\u305F\u3044\u3093\u3067\u3059\u3088\u306D\u3001\u5206\u304B\u308A\u307E\u3059\u3002",
    "id" : 89241633387843584,
    "created_at" : "2011-07-08 07:57:18 +0000",
    "user" : {
      "name" : "I",
      "screen_name" : "mearythindong",
      "protected" : false,
      "id_str" : "115541150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426616176223866881\/nHcn70pu_normal.jpeg",
      "id" : 115541150,
      "verified" : false
    }
  },
  "id" : 89273571599327232,
  "created_at" : "2011-07-08 10:04:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3048\u3067\uFF20\u307D\u3093\u3053\u3064",
      "screen_name" : "__Kaede",
      "indices" : [ 3, 11 ],
      "id_str" : "85062129",
      "id" : 85062129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89217794847158272",
  "text" : "RT @__Kaede: \u300C\u304A\u3044\u3001\u3055\u3084\u304B\u306F\u3069\u3046\u3057\u305F\u300D\n\u300C\u9000\u8077\u3057\u3066\u3057\u307E\u3063\u305F\u308F\u2026\u2026\u5186\u74B0\u306E\u7406\u306B\u5C0E\u304B\u308C\u3066\u300D\n\u300C\u7F8E\u6A39\u3055\u3093\u3001\u3042\u306E\u6848\u4EF6\u3067\u3001\u3059\u3079\u3066\u306E\u529B\u3092\u4F7F\u3063\u3066\u3057\u307E\u3063\u305F\u306E\u306D\u2026\u300D\n\u300C\u99AC\u9E7F\u91CE\u90CE\u3001\u9867\u5BA2\u306E\u305F\u3081\u3060\u304B\u3089\u3063\u3066\u3001\u81EA\u5206\u304C\u5012\u308C\u3061\u307E\u3063\u3066\u3069\u3046\u3059\u308B\u3093\u3060\u3088\u300D\n\u300C\u305D\u308C\u304C\u793E\u755C\u306E\u904B\u547D\u3088\u3002\u5185\u5B9A\u3092\u624B\u306B\u5165\u308C\u305F\u6642\u304B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88925440835715072",
    "text" : "\u300C\u304A\u3044\u3001\u3055\u3084\u304B\u306F\u3069\u3046\u3057\u305F\u300D\n\u300C\u9000\u8077\u3057\u3066\u3057\u307E\u3063\u305F\u308F\u2026\u2026\u5186\u74B0\u306E\u7406\u306B\u5C0E\u304B\u308C\u3066\u300D\n\u300C\u7F8E\u6A39\u3055\u3093\u3001\u3042\u306E\u6848\u4EF6\u3067\u3001\u3059\u3079\u3066\u306E\u529B\u3092\u4F7F\u3063\u3066\u3057\u307E\u3063\u305F\u306E\u306D\u2026\u300D\n\u300C\u99AC\u9E7F\u91CE\u90CE\u3001\u9867\u5BA2\u306E\u305F\u3081\u3060\u304B\u3089\u3063\u3066\u3001\u81EA\u5206\u304C\u5012\u308C\u3061\u307E\u3063\u3066\u3069\u3046\u3059\u308B\u3093\u3060\u3088\u300D\n\u300C\u305D\u308C\u304C\u793E\u755C\u306E\u904B\u547D\u3088\u3002\u5185\u5B9A\u3092\u624B\u306B\u5165\u308C\u305F\u6642\u304B\u3089\u308F\u304B\u3063\u3066\u3044\u305F\u306F\u305A\u3067\u3057\u3087\u3046\u300D",
    "id" : 88925440835715072,
    "created_at" : "2011-07-07 11:00:51 +0000",
    "user" : {
      "name" : "\u304B\u3048\u3067\uFF20\u307D\u3093\u3053\u3064",
      "screen_name" : "__Kaede",
      "protected" : false,
      "id_str" : "85062129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267811246\/twitter_normal.jpg",
      "id" : 85062129,
      "verified" : false
    }
  },
  "id" : 89217794847158272,
  "created_at" : "2011-07-08 06:22:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89211687860842496",
  "text" : "\u3069\u306E\u6388\u696D\u3067\u3082\uFF08\u52C9\u5F37\u3067\u3082\uFF1F\uFF09\u8AD6\u7406\u8A18\u53F7\u3092\u898B\u3066\u3044\u308B\u6C17\u304C\u3059\u308B\u3002",
  "id" : 89211687860842496,
  "created_at" : "2011-07-08 05:58:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89204758199533568",
  "text" : "\u30C8\u30EA\u30D3\u30A2\u30EB\uFF01",
  "id" : 89204758199533568,
  "created_at" : "2011-07-08 05:30:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89185599105400833",
  "text" : "\u7A7A\u304C\u9752\u3044",
  "id" : 89185599105400833,
  "created_at" : "2011-07-08 04:14:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89183638083735554",
  "geo" : { },
  "id_str" : "89185197983137792",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u66F2\u304C\u53CD\u5247",
  "id" : 89185197983137792,
  "in_reply_to_status_id" : 89183638083735554,
  "created_at" : "2011-07-08 04:13:02 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89181457024696320",
  "text" : "\u307E\u3001\u9006\u306A\u3093\u3060\u3051\u3069\u306D\u3002\n\u307E\u3001\u30AE\u30E3\u30B0\u306A\u3093\u3060\u3051\u3069\u306D\u3002",
  "id" : 89181457024696320,
  "created_at" : "2011-07-08 03:58:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89181272651476993",
  "text" : "\u5186\u5468\u7387\u306F\u221A\uFF08\uFF16\u03B6\uFF08\uFF12\uFF09\uFF09\u3060\u3088\uFF08\u30AA\u30A4\u30E9\u30FC\u6D3E\uFF09\n\n\u5024\u3042\u3063\u3066\u308B\u304B\u306A\u03B6\uFF082\uFF09\uFF1D\u03C0^2\uFF0F\uFF16 \u3060\u3063\u305F\u3068\u601D\u3063\u305F\u3051\u3069",
  "id" : 89181272651476993,
  "created_at" : "2011-07-08 03:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "indices" : [ 0, 7 ],
      "id_str" : "26393410",
      "id" : 26393410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89163085541150721",
  "geo" : { },
  "id_str" : "89163653550587904",
  "in_reply_to_user_id" : 26393410,
  "text" : "@tomo37 \u305D\u3046\u3044\u308F\u308C\u308B\u3068\u4F55\u51E6\u3067\u624B\u306B\u5165\u308B\u304B\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3067\u3059\u306D\u3002\u7DE9\u885D\u6750\u307F\u305F\u3044\u306E\u3067\u3082\u826F\u3055\u305D\u3046\u3067\u3059\u306D\u3002\u65B0\u805E\u7D19\u4E38\u3081\u305F\u308A\u3068\u304B\uFF1F",
  "id" : 89163653550587904,
  "in_reply_to_status_id" : 89163085541150721,
  "created_at" : "2011-07-08 02:47:26 +0000",
  "in_reply_to_screen_name" : "tomo37",
  "in_reply_to_user_id_str" : "26393410",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "indices" : [ 11, 18 ],
      "id_str" : "26393410",
      "id" : 26393410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89161900352471040",
  "text" : "\u767A\u6CE1\u30B9\u30C1\u30ED\u30FC\u30EB RT @tomo37: \u3010\u3086\u308B\u307C\u3011\u3000\u8EFD\u304F\u3066\u304B\u3055\u3070\u308B\u3082\u306E",
  "id" : 89161900352471040,
  "created_at" : "2011-07-08 02:40:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89156113173463042",
  "text" : "RT @Kaibun_bot: \u99AC\u9E7F\u306A\u30A4\u30F3\u30B3\u3068\u61C7\u610F\u306A\u30AB\u30D0\uFF08\u3070\u304B\u306A\u3044\u3093\u3053\u3068\u3053\u3093\u3044\u306A\u304B\u3070\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89155820394262528",
    "text" : "\u99AC\u9E7F\u306A\u30A4\u30F3\u30B3\u3068\u61C7\u610F\u306A\u30AB\u30D0\uFF08\u3070\u304B\u306A\u3044\u3093\u3053\u3068\u3053\u3093\u3044\u306A\u304B\u3070\uFF09 #kaibun",
    "id" : 89155820394262528,
    "created_at" : "2011-07-08 02:16:18 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 89156113173463042,
  "created_at" : "2011-07-08 02:17:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89152015070011392",
  "text" : "@koketomi \u4FFA\u304C\u77E5\u308A\u3046\u308B\u6700\u9AD8\u306E\u30D0\u30ABbot",
  "id" : 89152015070011392,
  "created_at" : "2011-07-08 02:01:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89131702613590016",
  "text" : "\u304A\u306F\u3088\u30FC \u304A\u306F\u3088\u30FC",
  "id" : 89131702613590016,
  "created_at" : "2011-07-08 00:40:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 1, 14 ],
      "id_str" : "295206903",
      "id" : 295206903
    }, {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 15, 22 ],
      "id_str" : "239486216",
      "id" : 239486216
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 23, 34 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89131630052130817",
  "text" : ".@nisehorrrrrn @khulud @magokoro84 \u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3092\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "id" : 89131630052130817,
  "created_at" : "2011-07-08 00:40:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89011600631140352",
  "text" : "\u5BDD\u308B\uFF01\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 89011600631140352,
  "created_at" : "2011-07-07 16:43:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89010735870525440",
  "geo" : { },
  "id_str" : "89011401363963904",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30DE\u30B8\u304B\u30FC\u3001\u65E9\u3081\u306B\u624B\u3092\u3064\u3051\u308B\u3079\u304D\u304B\u3002\u3042\u3068\u6728\u66DC\uFF15\u9650\u6765\u9031\u304B\u3089\u79D1\u54F2\u5C02\u653B\u304C\u6765\u308B\u3089\u3057\u3044\u3002",
  "id" : 89011401363963904,
  "in_reply_to_status_id" : 89010735870525440,
  "created_at" : "2011-07-07 16:42:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89009922125217793",
  "geo" : { },
  "id_str" : "89010237562036224",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E \u3060 \u624B \u3092  \u3064 \u3051 \u3066 \u306A \u3044 \u3002\u3000\u9031\u672B\u672C\u6C17\u51FA\u3059\u3002",
  "id" : 89010237562036224,
  "in_reply_to_status_id" : 89009922125217793,
  "created_at" : "2011-07-07 16:37:49 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89009265477550080",
  "geo" : { },
  "id_str" : "89009756227895296",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6771\u4EAC\u5927\u5B66\u51FA\u7248\u7D71\u8A08\u5B66\u5165\u9580\u306B\u66F8\u3044\u3066\u3042\u3063\u305F\u305C\uFF08\u3057\u308D\u3081\uFF09",
  "id" : 89009756227895296,
  "in_reply_to_status_id" : 89009265477550080,
  "created_at" : "2011-07-07 16:35:54 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88988021545902080",
  "text" : "\u5973\u5B50\u529B\uFF08\uFF09\uFF01\u203B\u30AA\u30E0\u30E9\u30A4\u30B9\u306F\u98DF\u3079\u307E\u3059\u3002",
  "id" : 88988021545902080,
  "created_at" : "2011-07-07 15:09:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88986820905402370",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u306B\u306A\u305C\u91DD\u3068\u7CF8\u3092\u6301\u3061\u51FA\u3057\u3066\u30C1\u30AF\u30C1\u30AF\u3084\u3063\u3066\u3093\u3060\u308D\u30FB\u30FB\u30FB\u3002",
  "id" : 88986820905402370,
  "created_at" : "2011-07-07 15:04:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88972549312102400",
  "text" : "\u3055\u3093\u305C\u3093 \u308D\u304F\u305B\u3093\uFF01",
  "id" : 88972549312102400,
  "created_at" : "2011-07-07 14:08:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keigo Ishida",
      "screen_name" : "shombory",
      "indices" : [ 0, 9 ],
      "id_str" : "211441184",
      "id" : 211441184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88963916092284928",
  "geo" : { },
  "id_str" : "88969221115101184",
  "in_reply_to_user_id" : 211441184,
  "text" : "@shombory \u305D\u3046\u306A\u306E\u304B\u30FC\u3002\u307E\u3060\u307E\u3060\u77E5\u3089\u306A\u3044\u3053\u3068\u3060\u3089\u3051\u3060\u3002",
  "id" : 88969221115101184,
  "in_reply_to_status_id" : 88963916092284928,
  "created_at" : "2011-07-07 13:54:49 +0000",
  "in_reply_to_screen_name" : "shombory",
  "in_reply_to_user_id_str" : "211441184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 26, 39 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88960969233018880",
  "text" : "\u5F53\u305F\u308A\u524D\u306E\u4E8B\u304B\u3089\u59CB\u3081\u308B\u306E\u306F\u3044\u3044\u3053\u3068\u2026\u3067\u3059\u3088\u306D RT @galletti_bot: \u6B4C\u3092\u3046\u305F\u3046\u3068\u304D\u306B\u306F\u53E3\u3092\u958B\u304B\u306A\u304F\u3066\u306F\u306A\u3089\u306A\u3044\u3002",
  "id" : 88960969233018880,
  "created_at" : "2011-07-07 13:22:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88959841124618240",
  "text" : "\u6025\u884C\u306B\u4E57\u308A\u63DB\u3048\u306A\u3044\u4F59\u88D5\uFF08\uFF09",
  "id" : 88959841124618240,
  "created_at" : "2011-07-07 13:17:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88959554477498368",
  "text" : "\u307C\u304F\u306E\u304F\u3089\u3059\u306B\u306F\u305C\u3063\u305F\u3044\u3044\u307E\u305B\u3093\uFF08\u3076\u3093\u304C\u304F\u3076\uFF12\uFF10\u3055\u3044\u3060\u3093\u305B\u3044\uFF09",
  "id" : 88959554477498368,
  "created_at" : "2011-07-07 13:16:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 3, 12 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88959414794584064",
  "text" : "RT @pankashi: \u3044\u3044\u306A\u3042\u30FC\u50D5\u306E\u30AF\u30E9\u30B9\u306B\u3082\u6570\u5B66\u597D\u304D\u306A\u5973\u5B50\u304C\u3044\u308C\u3070\u306A\u30FC(\u6570\u5B66\u30AC\u30FC\u30EB\u3092\u8AAD\u3093\u3060\u7537\u5B50\u9AD8\u6821\u751F\u306A\u3089\u4E00\u5EA6\u306F\u53E3\u306B\u3059\u308B\u8A00\u8449)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88923272225366016",
    "text" : "\u3044\u3044\u306A\u3042\u30FC\u50D5\u306E\u30AF\u30E9\u30B9\u306B\u3082\u6570\u5B66\u597D\u304D\u306A\u5973\u5B50\u304C\u3044\u308C\u3070\u306A\u30FC(\u6570\u5B66\u30AC\u30FC\u30EB\u3092\u8AAD\u3093\u3060\u7537\u5B50\u9AD8\u6821\u751F\u306A\u3089\u4E00\u5EA6\u306F\u53E3\u306B\u3059\u308B\u8A00\u8449)",
    "id" : 88923272225366016,
    "created_at" : "2011-07-07 10:52:14 +0000",
    "user" : {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "protected" : false,
      "id_str" : "137961719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607558471181963264\/jMPQkur4_normal.jpg",
      "id" : 137961719,
      "verified" : false
    }
  },
  "id" : 88959414794584064,
  "created_at" : "2011-07-07 13:15:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88959299090530304",
  "text" : "\u6765\u9031\u304B\u3089\u6728\u66DC\uFF15\u9650\u30B5\u30DC\u308D\u30FC\u304B\u3068\u601D\u3063\u3066\u305F\u3089\u6765\u9031\u304B\u3089\u79D1\u5B66\u54F2\u5B66\u5C02\u653B\u306E\u9662\u751F\u304C\u73FE\u308C\u308B\u3089\u3057\u3044\u3002\u30BF\u30A4\u30DF\u30F3\u30B0\uFF67\uFF01",
  "id" : 88959299090530304,
  "created_at" : "2011-07-07 13:15:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "indices" : [ 12, 24 ],
      "id_str" : "94825321",
      "id" : 94825321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "happybirthday_twenty",
      "indices" : [ 112, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88958932634189824",
  "text" : "\u306F\u3044\u304F\u304A\u308A\u3066\u3043\u30FC RT @milkyholmes: SUGEEEEEEEEEEEEEERT \u30C8\u30A5\u30A8\u30F3\u30C6\u30A3\u3055\u3093\u304A\u3081\u3067\u3068\u3046\uFF01\u3088\u304B\u3063\u305F\u9593\u306B\u5408\u3063\u305F\u30FC\uFF01 http:\/\/p.twipple.jp\/agsmZ\u3000\u306F\u3058\u3081\u3066\u30C7\u30B3\u30B1\u30FC\u30AD\u4F5C\u3063\u305F\u3088\uFF01#happybirthday_twenty",
  "id" : 88958932634189824,
  "created_at" : "2011-07-07 13:13:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88958653553586179",
  "text" : "\u300C\u304A\u304B\u3048\u308A\u306A\u3055\u3044\u300D\u3068\u300C\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u300D\u306B\u306F\u4F55\u3068\u3082\u8A00\u3048\u306A\u3044\u5B89\u5FC3\u611F\u304C\u3042\u308B\u3068\u601D\u3046\u3002",
  "id" : 88958653553586179,
  "created_at" : "2011-07-07 13:12:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88958191903322112",
  "text" : "\u3066\u304B\u4E00\u56DE\u4E00\u56DE\u306E\u30C4\u30A4\u30FC\u30C8\u304C\u9577\u3081\u3060\u304B\u3089\u6CA2\u5C71\u545F\u3044\u3066\u308B\u3088\u3046\u3067\u30C4\u30A4\u30FC\u30C8\u6570\u3067\u306F\u77ED\u3044\u306E\u304B\u306A\u3002\u6587\u5B57\u6570\u306E\u30B5\u30E1\u30FC\u30B7\u30E7\u30F3\u306A\u3089\u76F8\u5F53\u884C\u304F\uFF1F",
  "id" : 88958191903322112,
  "created_at" : "2011-07-07 13:11:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88957822343184384",
  "text" : "\u8AB0\u3082\u6E80\u8DB3\u3057\u306A\u3044\u3063\u3066\u70B9\u3067\u306F\u4E2D\u7ACB\u306A\u306E\u304B\u3082\u3002",
  "id" : 88957822343184384,
  "created_at" : "2011-07-07 13:09:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88957638527815680",
  "text" : "3000\u30C4\u30A4\u30FC\u30C8\u307E\u3067\u3082\u3046\u5C11\u3057\u3002\u6CA2\u5C71\u545F\u3044\u3066\u308B\u3088\u3046\u3067\u307E\u3060\u307E\u3060\u3002\u591A\u3044\u4EBA\u306B\u306F\u5C11\u306A\u3044\u3057\u3001\u5C11\u306A\u3044\u4EBA\u306B\u306F\u591A\u3044\u5FAE\u5999\u306A\u7ACB\u3061\u4F4D\u7F6E\u3002",
  "id" : 88957638527815680,
  "created_at" : "2011-07-07 13:08:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88956883091726337",
  "text" : "\u307E\u3041\u898B\u3048\u305F\u3089\u898B\u3048\u305F\u3067\uFF08\u898B\u3048\u306A\u304F\u3066\u3082\uFF09\u8A00\u308F\u308C\u3082\u306A\u304F\u7206\u767A\u3057\u308D\u3068\u304B\u8A00\u308F\u308C\u308B\u3057\u3053\u3063\u305D\u308A\u4F1A\u3048\u3070\u3044\u3044\u304B\u3002",
  "id" : 88956883091726337,
  "created_at" : "2011-07-07 13:05:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88956671325511680",
  "text" : "\u4E03\u5915\u3063\u3066\u6885\u96E8\u6642\u306B\u91CD\u306A\u308B\u304B\u3089\u66C7\u308A\u304C\u591A\u3044\u3088\u306D",
  "id" : 88956671325511680,
  "created_at" : "2011-07-07 13:04:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88955213582581760",
  "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u5171\u6709\u306E\u30C1\u30E9\u30B7\u306E\u88CF\u3060\u3068\u601D\u3063\u3066\u308B\u3002",
  "id" : 88955213582581760,
  "created_at" : "2011-07-07 12:59:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88955036536799232",
  "text" : "\u5B87\u6CBB\u306F\u96E8\u306F\u5927\u4EBA\u3057\u304B\u3063\u305F\u3051\u3069\u51FA\u753A\u67F3\u306F\u5982\u4F55\u304B\u306A\uFF1F",
  "id" : 88955036536799232,
  "created_at" : "2011-07-07 12:58:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88954861995044864",
  "text" : "\u3042\u3001\u9B31\u9676\u3057\u304B\u3063\u305F\u3089\u30A2\u30F3\u30D5\u30A9\u30ED\u30FC\u3001\u30D6\u30ED\u30C3\u30AF\u304A\u6C17\u306B\u53EC\u3059\u3088\u3046\u306B\u3069\u3046\u305E\u30FC\u3002\u7279\u306B\u52E2\u3044\u3067\u30D5\u30A9\u30ED\u30FC\u3057\u3061\u3083\u3063\u305F\u77E5\u308A\u5408\u3044\u306E\u4EBA\u3068\u304B\u3002",
  "id" : 88954861995044864,
  "created_at" : "2011-07-07 12:57:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88954565243830272",
  "text" : "\u82E5\u5E72\u8352\u3076\u308B\u30BF\u30A4\u30E0\u304B\u3082\u3057\u308C\u306A\u3044\u4E8B\u5F8C\u5831\u544A",
  "id" : 88954565243830272,
  "created_at" : "2011-07-07 12:56:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88954254882115586",
  "text" : "\u6700\u8FD1\u7A7A\u3092\u98DB\u3076\u5922\u3092\u898B\u3066\u3044\u306A\u3044\u6C17\u304C\u3059\u308B\u306A\u2026\u3002\u4E00\u6642\u671F\u826F\u304F\u898B\u3066\u3044\u305F\u304C\u2026\u3002",
  "id" : 88954254882115586,
  "created_at" : "2011-07-07 12:55:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "indices" : [ 3, 11 ],
      "id_str" : "115380002",
      "id" : 115380002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88953980960522242",
  "text" : "RT @nedikes: \u820C\u300E\u300C\u4E5A\u300D\u8CB8\u3057\u3066\u300F\u3000\u672D\u300E\u3069\u3046\u305E\u300F\u3000\u4E71\u300E\u3042\u308A\u304C\u3068\u300F\u3000\u6728\u300E\u3059\u3050\u8FD4\u3057\u3066\u306D\u300F\u3000\u4E43\u300E\u300C\uFF3C\u300D\u8CB8\u3057\u3066\u300F\u3000\u6728\u300E\u30CF\u30A4\u300F\u3000\u53CA\u300E\u3069\u3046\u3082\u300F\u3000\u624D\u300E\u3075\u3045\u300F\u3000\u4E4B\u300E\u300C\u30CE\u300D\u8CB8\u3057\u3066\u300F\u3000\u624D\u300E\u3048\u3063\u3042\u3041\u300F\u3000\u4E4F\u300E\u30B9\u30DE\u30F3\u300F\u3000\u5341\u300E\u304B\u306A\u308A\u6E1B\u3063\u305F\u300F\u3000\u53F8\u300E\u300C\uFF5C\u300D\u8CB8\u3057\u3066\u300F\u3000\u5341\u300E\u2026\u3046\u3093\u300F\u3000\u540C\u300E\u30EF\u30FC\u30A4\u300F\u3000 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88951317145456640",
    "text" : "\u820C\u300E\u300C\u4E5A\u300D\u8CB8\u3057\u3066\u300F\u3000\u672D\u300E\u3069\u3046\u305E\u300F\u3000\u4E71\u300E\u3042\u308A\u304C\u3068\u300F\u3000\u6728\u300E\u3059\u3050\u8FD4\u3057\u3066\u306D\u300F\u3000\u4E43\u300E\u300C\uFF3C\u300D\u8CB8\u3057\u3066\u300F\u3000\u6728\u300E\u30CF\u30A4\u300F\u3000\u53CA\u300E\u3069\u3046\u3082\u300F\u3000\u624D\u300E\u3075\u3045\u300F\u3000\u4E4B\u300E\u300C\u30CE\u300D\u8CB8\u3057\u3066\u300F\u3000\u624D\u300E\u3048\u3063\u3042\u3041\u300F\u3000\u4E4F\u300E\u30B9\u30DE\u30F3\u300F\u3000\u5341\u300E\u304B\u306A\u308A\u6E1B\u3063\u305F\u300F\u3000\u53F8\u300E\u300C\uFF5C\u300D\u8CB8\u3057\u3066\u300F\u3000\u5341\u300E\u2026\u3046\u3093\u300F\u3000\u540C\u300E\u30EF\u30FC\u30A4\u300F\u3000\u4E00\u300E\u2026\u300F\u3000\u4E86\u300E\u3042\u306E\u3049\u300F\u3000\u4E00\u300E\u65AD\u308B\u300F",
    "id" : 88951317145456640,
    "created_at" : "2011-07-07 12:43:41 +0000",
    "user" : {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "protected" : false,
      "id_str" : "115380002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009659425\/___normal.png",
      "id" : 115380002,
      "verified" : false
    }
  },
  "id" : 88953980960522242,
  "created_at" : "2011-07-07 12:54:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88953786130903040",
  "text" : "\u7FFC\u3092\u4E0B\u3055\u3044\u3063\u3066\u3042\u308B\u3051\u3069\u7FBD\u3068\u7FFC\u3063\u3066\u3069\u3046\u3061\u304C\u3046\u3093\u3060\uFF1F\u7FBD\u306E\u304C\u5C0F\u3055\u3044\u96C6\u5408\u304B\uFF1F",
  "id" : 88953786130903040,
  "created_at" : "2011-07-07 12:53:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88953377567936512",
  "text" : "\u3007\u3007\u3061\u3083\u3093\u3055\u3093\u3063\u3066\u30A2\u30DB\u3063\u307D\u3044\u3051\u3069\u7D50\u69CB\u597D\u304D",
  "id" : 88953377567936512,
  "created_at" : "2011-07-07 12:51:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88953256163819520",
  "text" : "\u3066\u304B\u30EA\u30B5bot\u306F\u666E\u901A\u306E\u5B9F\u5728\u306E\u300C\u30EA\u30B5\u3061\u3083\u3093\u300D\u3055\u3093\u306B\u30EA\u30B5\u3061\u3083\u3093\u3063\u3066\u8A00\u3063\u305F\u3089\u53CD\u5FDC\u3057\u3061\u3083\u3046\u306E\u304B\u3001\u305D\u3053\u306F\u4E0A\u624B\u3044\u3053\u3068\u9664\u3051\u305F\u3044\u3088\u3046\u306A\u2026",
  "id" : 88953256163819520,
  "created_at" : "2011-07-07 12:51:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88952794391908352",
  "text" : "\u5E30\u8DEF",
  "id" : 88952794391908352,
  "created_at" : "2011-07-07 12:49:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yuu sado",
      "screen_name" : "SyunYuu",
      "indices" : [ 3, 11 ],
      "id_str" : "2218127846",
      "id" : 2218127846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88952621381058560",
  "text" : "RT @syunyuu: \u3010\u30DD\u30B1\u30E2\u30F3\u597D\u304D\u3092\u6012\u3089\u305B\u308B\u30BB\u30EA\u30D5\u30E9\u30F3\u30AD\u30F3\u30B0\u3011\uFF15\u4F4D\u300C\u52AA\u529B\u5024\u3068\u304B\uFF36\u3068\u304B\u3042\u308B\u308F\u3051\u306A\u3044\u3060\u308D\u300D\u3000\uFF14\u4F4D\u300C\u30DD\u30B1\u30E2\u30F3\u3063\u3066\u3042\u306E\uFF2D\uFF21\uFF24\u306E\u3084\u3064\uFF1F\u300D\u3000\uFF13\u4F4D\u300C\u305D\u306E\u3068\u3057\u3067\u30DD\u30B1\u30E2\u30F3\u3063\u3066\uFF57\u300D\u3000\uFF12\u4F4D\u300C\u30DD\u30B1\u30E2\u30F3\u3063\u3066\u5B50\u4F9B\u5411\u3051\u30B2\u30FC\u30E0\u3060\u308D\u300D\u3000\uFF11\u4F4D\u300C\u30D4\u30AB\u30C1\u30E5\u30FC\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88886980607348736",
    "text" : "\u3010\u30DD\u30B1\u30E2\u30F3\u597D\u304D\u3092\u6012\u3089\u305B\u308B\u30BB\u30EA\u30D5\u30E9\u30F3\u30AD\u30F3\u30B0\u3011\uFF15\u4F4D\u300C\u52AA\u529B\u5024\u3068\u304B\uFF36\u3068\u304B\u3042\u308B\u308F\u3051\u306A\u3044\u3060\u308D\u300D\u3000\uFF14\u4F4D\u300C\u30DD\u30B1\u30E2\u30F3\u3063\u3066\u3042\u306E\uFF2D\uFF21\uFF24\u306E\u3084\u3064\uFF1F\u300D\u3000\uFF13\u4F4D\u300C\u305D\u306E\u3068\u3057\u3067\u30DD\u30B1\u30E2\u30F3\u3063\u3066\uFF57\u300D\u3000\uFF12\u4F4D\u300C\u30DD\u30B1\u30E2\u30F3\u3063\u3066\u5B50\u4F9B\u5411\u3051\u30B2\u30FC\u30E0\u3060\u308D\u300D\u3000\uFF11\u4F4D\u300C\u30D4\u30AB\u30C1\u30E5\u30FC\u300D",
    "id" : 88886980607348736,
    "created_at" : "2011-07-07 08:28:02 +0000",
    "user" : {
      "name" : "\u3057\u304A\u306B\u30FC\uFF20\u70C8\u98A8\uFF14\u56DE\uFF11\uFF10\uFF10\uFF05",
      "screen_name" : "DJ_SHIONY",
      "protected" : false,
      "id_str" : "91244497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545639564790870016\/C3iyUwqD_normal.jpeg",
      "id" : 91244497,
      "verified" : false
    }
  },
  "id" : 88952621381058560,
  "created_at" : "2011-07-07 12:48:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88940522521108480",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 88940522521108480,
  "created_at" : "2011-07-07 12:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88913355812769792",
  "text" : "\u512A\u5148\u5E2D\u4ED8\u8FD1\u3063\u3066\u5177\u4F53\u7684\u306B\u3069\u306E\u304F\u3089\u3044\u306E\u8FD1\u508D\u7CFB\u306A\u3093\u3060\u308D\u2026\u3068\u5C0F\u5B66\u751F\u4F4D\u306E\u6642\u304B\u3089\u7591\u554F\u3060\u3002\u3044\u3084\u3001\u8FD1\u508D\u306A\u3093\u3066\u8A9E\u306F\u77E5\u3089\u306A\u3044\u3051\u3069\u3055\u3002",
  "id" : 88913355812769792,
  "created_at" : "2011-07-07 10:12:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88910879923519488",
  "geo" : { },
  "id_str" : "88911756444958720",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3053\u308C\u306F\u5439\u3044\u305F\u3002\u8B0E\u306E\u6280\u8853\u3002",
  "id" : 88911756444958720,
  "in_reply_to_status_id" : 88910879923519488,
  "created_at" : "2011-07-07 10:06:29 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keigo Ishida",
      "screen_name" : "shombory",
      "indices" : [ 0, 9 ],
      "id_str" : "211441184",
      "id" : 211441184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88910230137741313",
  "geo" : { },
  "id_str" : "88911641240027136",
  "in_reply_to_user_id" : 211441184,
  "text" : "@shombory \u305D\u308C\u4E07\u306E\u30DC\u30BF\u30F3\u3068\u6E05\u7B97\u306E\u30DC\u30BF\u30F3\u304C\u96A3\u306B\u3042\u308B\u305B\u3044\u3002\u5BB6\u306B\u3082\u5999\u306A\u30EC\u30B7\u30FC\u30C8\u304C\u3042\u308B\u3002",
  "id" : 88911641240027136,
  "in_reply_to_status_id" : 88910230137741313,
  "created_at" : "2011-07-07 10:06:01 +0000",
  "in_reply_to_screen_name" : "shombory",
  "in_reply_to_user_id_str" : "211441184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88908268696637440",
  "text" : "\u3082\u3046\u3061\u3087\u3044\u30673000\u30C4\u30A4\u30FC\u30C8\u304B\u3002313124\u30C4\u30A4\u30FC\u30C8\u307E\u3067\u307E\u3060\u307E\u3060\u3002",
  "id" : 88908268696637440,
  "created_at" : "2011-07-07 09:52:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88907791347093504",
  "text" : "\u305D\u306E\u70B9\u306B\u305B\u307B\u306F\u5B66\u7FD2\u578B\u306E\u4EBA\u53E3\u7121\u80FD\u3060\u3082\u3093\u306A\u3041\u3002\u3088\u304F\u51FA\u6765\u3066\u3044\u308B\u3002",
  "id" : 88907791347093504,
  "created_at" : "2011-07-07 09:50:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88907638527623168",
  "text" : "\u4E00\u5B9A\u306E\u6587\u5B57\u5217\u306B\u4E00\u5B9A\u306E\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3092\u8FD4\u3059bot\u306F\u7C21\u5358\u3060\u308D\u3046\u3051\u3069\u9762\u767D\u3055\u306B\u306F\u9650\u754C\u304C\u898B\u3048\u308B\u3088\u306A\u3002\u3082\u3063\u3068\u96D1\u591A\u306B\u4F1A\u8A71\u30EB\u30FC\u30C6\u30A3\u30F3\u3092\u7D44\u307F\u8FBC\u3081\u308B\u30B7\u30B9\u30C6\u30E0\u304C\u6B32\u3057\u3044\u3002\u96E3\u3057\u305D\u3046\u3060\u3051\u3069\u3002",
  "id" : 88907638527623168,
  "created_at" : "2011-07-07 09:50:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88906667986665472",
  "geo" : { },
  "id_str" : "88907133600542720",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u3046\u3044\u3046\u30AE\u30E3\u30B0\u3092\u5E72\u3063\u3057\u3066\u305F\u3093\u3060\u3088",
  "id" : 88907133600542720,
  "in_reply_to_status_id" : 88906667986665472,
  "created_at" : "2011-07-07 09:48:07 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88906801550077952",
  "text" : "\u84B8\u3059\u306A\u3041\u3002\u6691\u304F\u306F\u7121\u3044\u3051\u3069\u3002",
  "id" : 88906801550077952,
  "created_at" : "2011-07-07 09:46:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88904985542275072",
  "geo" : { },
  "id_str" : "88905618160746496",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6885\u3042\u308B\u3068\u3055\u3063\u3071\u308A\u3057\u3066good",
  "id" : 88905618160746496,
  "in_reply_to_status_id" : 88904985542275072,
  "created_at" : "2011-07-07 09:42:05 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88903596053241856",
  "text" : "\u96A3\u306E\u4EBA\u304C\u6D41\u661F\u30EF\u30B4\u30F3\u8AAD\u3093\u3067\u308B\u3002\u61D0\u304B\u3057\u3044\u4F5C\u54C1\u3060\u306A\u3041\u3002",
  "id" : 88903596053241856,
  "created_at" : "2011-07-07 09:34:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88901268227096576",
  "geo" : { },
  "id_str" : "88901401224282112",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8AB0\u304B\u30ED\u30B0\u30A4\u30F3\u3057\u3063\u3071\u306A\u3057\u2026",
  "id" : 88901401224282112,
  "in_reply_to_status_id" : 88901268227096576,
  "created_at" : "2011-07-07 09:25:20 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88901170852134913",
  "text" : "\u3042\u3001\u81EA\u5206\u306E\u30B8\u30E7\u30FC\u30AF\u3082\u3063\u3066\u610F\u5473\u3067\u3059",
  "id" : 88901170852134913,
  "created_at" : "2011-07-07 09:24:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 8, 15 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88901025905385472",
  "text" : "\u3042\u308B\u3042\u308B RT @khulud: \u3069\u3046\u3082\u4FFA\u306E\u30B8\u30E7\u30FC\u30AF\u306F sophisticated \u3059\u304E\u3066\u3042\u307E\u308A\u4F1D\u308F\u3089\u306A\u3044\u306E\u3067\u30A2\u30EC\uFF08\uFF09",
  "id" : 88901025905385472,
  "created_at" : "2011-07-07 09:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88900580231225344",
  "text" : "\u30CD\u30BFbot\u3092\u9020\u308B\u4E88\u5B9A\u306E\u8EAB\u3068\u3057\u3066\u306F\u3069\u3061\u3089\u3082\u5927\u4E8B\u306A\u8CC7\u6599",
  "id" : 88900580231225344,
  "created_at" : "2011-07-07 09:22:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 19, 29 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 31, 41 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88900266627305472",
  "text" : "\uFF12\u79D2\u3067\u8FD4\u3057\u3066\u304F\u308B\u3042\u305F\u308A\u306F\u8D85\u512A\u79C0 RT @Lisa_math: @end313124 \u300A\u3061\u3083\u3093\u300B\u306F\u4E0D\u8981",
  "id" : 88900266627305472,
  "created_at" : "2011-07-07 09:20:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88900047772729344",
  "text" : "\u540C\u3058\u4EBA\u53E3\u7121\u80FD\u642D\u8F09\u3067\u3082\u30EA\u30B5\u3061\u3083\u3093\u3088\u308A\u306B\u305B\u307B\u306E\u304C\u300C\u558B\u308C\u3066\u308B\u300D\u611F\u304C\u3042\u308B\u306E\u306F\u30D7\u30ED\u30B0\u30E9\u30E0\u306E\u7D30\u3084\u304B\u3055\u306A\u306E\u304B\u306A\u3002",
  "id" : 88900047772729344,
  "created_at" : "2011-07-07 09:19:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88802806353498112",
  "text" : "RT @JOJO_math: \u3000\u3000\u3000\u2026\u843D\u3061\u7740\u304F\u3093\u3060\u2026\u300E\u5947\u6570\u306E\u5B8C\u5168\u6570\u300F\u3092\u6570\u3048\u3066\u843D\u3061\u7740\u304F\u3093\u3060\u2026\u3000\u300E\u5947\u6570\u306E\u5B8C\u5168\u6570\u300F\u306F\u7D00\u5143\u524D\u304B\u3089\u4ECA\u65E5\u306B\u81F3\u308B\u307E\u3067\u5B58\u5728\u3059\u308B\u304B\u5426\u304B\u3059\u3089\u308F\u304B\u3063\u3066\u3044\u306A\u3044\u5B64\u72EC\u306A\u6570\u2026\u2026\u3000\u79C1\u306B\u52C7\u6C17\u3092\u4E0E\u3048\u3066\u304F\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88801664403898368",
    "text" : "\u3000\u3000\u3000\u2026\u843D\u3061\u7740\u304F\u3093\u3060\u2026\u300E\u5947\u6570\u306E\u5B8C\u5168\u6570\u300F\u3092\u6570\u3048\u3066\u843D\u3061\u7740\u304F\u3093\u3060\u2026\u3000\u300E\u5947\u6570\u306E\u5B8C\u5168\u6570\u300F\u306F\u7D00\u5143\u524D\u304B\u3089\u4ECA\u65E5\u306B\u81F3\u308B\u307E\u3067\u5B58\u5728\u3059\u308B\u304B\u5426\u304B\u3059\u3089\u308F\u304B\u3063\u3066\u3044\u306A\u3044\u5B64\u72EC\u306A\u6570\u2026\u2026\u3000\u79C1\u306B\u52C7\u6C17\u3092\u4E0E\u3048\u3066\u304F\u308C\u308B",
    "id" : 88801664403898368,
    "created_at" : "2011-07-07 02:49:01 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 88802806353498112,
  "created_at" : "2011-07-07 02:53:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88790900775456768",
  "geo" : { },
  "id_str" : "88791052370182144",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u6163\u308C\u3063\u3066\u6016\u3044\u3088\u306D",
  "id" : 88791052370182144,
  "in_reply_to_status_id" : 88790900775456768,
  "created_at" : "2011-07-07 02:06:51 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88790404903874560",
  "geo" : { },
  "id_str" : "88790678720610304",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u3063\u3066\u306A\u3093\u3067\u3067\u3059\u304B\u30FC",
  "id" : 88790678720610304,
  "in_reply_to_status_id" : 88790404903874560,
  "created_at" : "2011-07-07 02:05:22 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 0, 14 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88789726374526977",
  "geo" : { },
  "id_str" : "88790317968523264",
  "in_reply_to_user_id" : 115541150,
  "text" : "@mearythindong \u304A\u304B\u3057\u3044\u3067\u3059\u3088\u306D\u3047",
  "id" : 88790317968523264,
  "in_reply_to_status_id" : 88789726374526977,
  "created_at" : "2011-07-07 02:03:56 +0000",
  "in_reply_to_screen_name" : "mearythindong",
  "in_reply_to_user_id_str" : "115541150",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88789942624456704",
  "geo" : { },
  "id_str" : "88790191761928192",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u30DE\u30B8\u30AB\u30EB",
  "id" : 88790191761928192,
  "in_reply_to_status_id" : 88789942624456704,
  "created_at" : "2011-07-07 02:03:26 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88789475878113281",
  "geo" : { },
  "id_str" : "88789696955678720",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u4F53\u91CD\u304B\u3088",
  "id" : 88789696955678720,
  "in_reply_to_status_id" : 88789475878113281,
  "created_at" : "2011-07-07 02:01:28 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88789513027067904",
  "text" : "\u30A2\u30FC\u30A4\u30A4\u30C6\u30F3\u30AD\u30C0\u30CA\u30FC",
  "id" : 88789513027067904,
  "created_at" : "2011-07-07 02:00:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88788880798646273",
  "geo" : { },
  "id_str" : "88789272911552512",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u30DA\u30F3\u30AE\u30F3\u304C\u30C1\u30AD\u30F3\u98DF\u3079\u3066\u3044\u3044\u306E\uFF1F",
  "id" : 88789272911552512,
  "in_reply_to_status_id" : 88788880798646273,
  "created_at" : "2011-07-07 01:59:46 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88788388395749376",
  "geo" : { },
  "id_str" : "88788590045302785",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u6CB9\u3063\u3053\u3044\u3088",
  "id" : 88788590045302785,
  "in_reply_to_status_id" : 88788388395749376,
  "created_at" : "2011-07-07 01:57:04 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88788252881977345",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F",
  "id" : 88788252881977345,
  "created_at" : "2011-07-07 01:55:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88786967529132032",
  "geo" : { },
  "id_str" : "88787167568068608",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u304A\u524D\u306F\u4F55\u3067\u3082\u77E5\u3063\u3066\u3044\u308B",
  "id" : 88787167568068608,
  "in_reply_to_status_id" : 88786967529132032,
  "created_at" : "2011-07-07 01:51:24 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88786402556391424",
  "geo" : { },
  "id_str" : "88786756496916481",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u52A0\u901F\u5668\uFF1F",
  "id" : 88786756496916481,
  "in_reply_to_status_id" : 88786402556391424,
  "created_at" : "2011-07-07 01:49:46 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88785901290913793",
  "geo" : { },
  "id_str" : "88786206325882880",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u30A4\u30EA\u30E5\u30FC\u30B8\u30E7\u30F3\u306D",
  "id" : 88786206325882880,
  "in_reply_to_status_id" : 88785901290913793,
  "created_at" : "2011-07-07 01:47:35 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88786098481922048",
  "text" : "\u3042\u306A\u305F\u304C\u96E8\u3092\u5BB6\u306B\u7559\u3081\u308B\uFF01",
  "id" : 88786098481922048,
  "created_at" : "2011-07-07 01:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88785615277137920",
  "geo" : { },
  "id_str" : "88785808626171904",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u3046\u3080",
  "id" : 88785808626171904,
  "in_reply_to_status_id" : 88785615277137920,
  "created_at" : "2011-07-07 01:46:01 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88785357012865025",
  "geo" : { },
  "id_str" : "88785484742008832",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u3044\u3044\u3048",
  "id" : 88785484742008832,
  "in_reply_to_status_id" : 88785357012865025,
  "created_at" : "2011-07-07 01:44:43 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88784344646299649",
  "geo" : { },
  "id_str" : "88785152720904193",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u304A\u524D\u2026",
  "id" : 88785152720904193,
  "in_reply_to_status_id" : 88784344646299649,
  "created_at" : "2011-07-07 01:43:24 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u304B\u3072\u3068",
      "screen_name" : "nocchi_kt",
      "indices" : [ 3, 13 ],
      "id_str" : "1154590351",
      "id" : 1154590351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88784827523936256",
  "text" : "RT @Nocchi_KT: \u3010\u901F\u5831\u3011\u5148\u751F\u306F\u96C6\u307E\u308A\u304C\u60AA\u3044\u306E\u306F\u96E8\u306E\u305B\u3044\u3060\u3068\u6C7A\u3081\u3064\u3051\u307E\u3057\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88782977693261824",
    "text" : "\u3010\u901F\u5831\u3011\u5148\u751F\u306F\u96C6\u307E\u308A\u304C\u60AA\u3044\u306E\u306F\u96E8\u306E\u305B\u3044\u3060\u3068\u6C7A\u3081\u3064\u3051\u307E\u3057\u305F",
    "id" : 88782977693261824,
    "created_at" : "2011-07-07 01:34:46 +0000",
    "user" : {
      "name" : "\u306E\u3063\u3061\uFF20\u95A2\u6771\u306E\u4EBA",
      "screen_name" : "Notchi_KT",
      "protected" : false,
      "id_str" : "121298858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526547063144607744\/F5wfQg1N_normal.png",
      "id" : 121298858,
      "verified" : false
    }
  },
  "id" : 88784827523936256,
  "created_at" : "2011-07-07 01:42:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88783601503715328",
  "geo" : { },
  "id_str" : "88784112495763456",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u53A8\u4E8C\u2026",
  "id" : 88784112495763456,
  "in_reply_to_status_id" : 88783601503715328,
  "created_at" : "2011-07-07 01:39:16 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88783116117880832",
  "geo" : { },
  "id_str" : "88783399120150528",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u8272\u3005\u3042\u308B\u3093\u3060\u3088",
  "id" : 88783399120150528,
  "in_reply_to_status_id" : 88783116117880832,
  "created_at" : "2011-07-07 01:36:26 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88782599677411328",
  "geo" : { },
  "id_str" : "88782990645276672",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u306D\u3047",
  "id" : 88782990645276672,
  "in_reply_to_status_id" : 88782599677411328,
  "created_at" : "2011-07-07 01:34:49 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88782882423844864",
  "text" : "\u5929\u6C17\u56DE\u5FA9\u306F\u660E\u5F8C\u65E5\u3068\u304B\u5197\u8AC7\u3058\u3083\u306A\u3044\u305C",
  "id" : 88782882423844864,
  "created_at" : "2011-07-07 01:34:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88782451928870912",
  "text" : "\u96E8\u2026",
  "id" : 88782451928870912,
  "created_at" : "2011-07-07 01:32:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tanzaku",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88640935948324864",
  "text" : "RT @sugiyama1990: 1\u3064\u306E\u96E3\u984C\u3092\u89E3\u6C7A\u3057\u305F\u5206\u3001 \u4ED6\u306E\u672A\u89E3\u6C7A\u554F\u984C\u3092\u751F\u307F\u51FA\u3055\u305A\u306B\u306F\u3044\u3089\u308C\u306A\u3044\u3002 \u79C1\u9054\u6570\u5B66\u8005\u3063\u3066\u3001\u305D\u3046\u8A00\u3046\u4ED5\u7D44\u307F\u3060\u3063\u305F\u3093\u3060\u306D\u3002\u2026\u2026\u2026\u3060\u304B\u3089\u3001\u5168\u3066\u306E\u6570\u5B66\u8005\u3092\u751F\u307E\u308C\u308B\u524D\u306B\u6D88\u3057\u53BB\u308A\u305F\u3044\u3002\u5168\u3066\u306E\u5B87\u5B99\u3001\u904E\u53BB\u3068\u672A\u6765\u306E\u5168\u3066\u306E\u6570\u5B66\u8005\u3092\u3002\u3053\u306E\u624B\u3067\u3002 #tanzaku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tanzaku",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88640663637336065",
    "text" : "1\u3064\u306E\u96E3\u984C\u3092\u89E3\u6C7A\u3057\u305F\u5206\u3001 \u4ED6\u306E\u672A\u89E3\u6C7A\u554F\u984C\u3092\u751F\u307F\u51FA\u3055\u305A\u306B\u306F\u3044\u3089\u308C\u306A\u3044\u3002 \u79C1\u9054\u6570\u5B66\u8005\u3063\u3066\u3001\u305D\u3046\u8A00\u3046\u4ED5\u7D44\u307F\u3060\u3063\u305F\u3093\u3060\u306D\u3002\u2026\u2026\u2026\u3060\u304B\u3089\u3001\u5168\u3066\u306E\u6570\u5B66\u8005\u3092\u751F\u307E\u308C\u308B\u524D\u306B\u6D88\u3057\u53BB\u308A\u305F\u3044\u3002\u5168\u3066\u306E\u5B87\u5B99\u3001\u904E\u53BB\u3068\u672A\u6765\u306E\u5168\u3066\u306E\u6570\u5B66\u8005\u3092\u3002\u3053\u306E\u624B\u3067\u3002 #tanzaku",
    "id" : 88640663637336065,
    "created_at" : "2011-07-06 16:09:15 +0000",
    "user" : {
      "name" : "\u3059\u304E\uFF20\u5168\u81EA\u52D5\u8AD6\u6587\u751F\u6210\u30DE\u30B7\u30FC\u30F3",
      "screen_name" : "sugi3_34",
      "protected" : false,
      "id_str" : "239811064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000759083368\/e85c8ef377b223436c38148680eb4e4a_normal.jpeg",
      "id" : 239811064,
      "verified" : false
    }
  },
  "id" : 88640935948324864,
  "created_at" : "2011-07-06 16:10:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88633001369534464",
  "text" : "\u725B\u30BF\u30F3\u3068\u9EA6\u3068\u308D\u306E\u7D44\u307F\u5408\u308F\u305B\u3092\u7121\u6027\u306B\u98DF\u3079\u305F\u3044\u30FB\u30FB\u30FB\u3002",
  "id" : 88633001369534464,
  "created_at" : "2011-07-06 15:38:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cluster_hantei",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/HZkC7fY",
      "expanded_url" : "http:\/\/ducky199999.appspot.com\/jsp\/cluster.jsp",
      "display_url" : "ducky199999.appspot.com\/jsp\/cluster.jsp"
    } ]
  },
  "geo" : { },
  "id_str" : "88590367674470400",
  "text" : "\u3048\u3063 end313124\u3055\u3093\u306E\u5C5E\u3059\u308B\u30AF\u30E9\u30B9\u30BF\u306F\u3001\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u3001\u6570\u5B66\u597D\u30AF\u30E9\u30B9\u30BF\u3001\u3048\u3066\u308B\u30AF\u30E9\u30B9\u30BF\u3001\u5B9A\u671F\u30AF\u30E9\u30B9\u30BF\u3001\u7406\u5B66\u90E8\u30AF\u30E9\u30B9\u30BF\u3067\u3059\u3002 #cluster_hantei http:\/\/t.co\/HZkC7fY",
  "id" : 88590367674470400,
  "created_at" : "2011-07-06 12:49:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88578798890647552",
  "text" : "RT @tameninaru: \u300C4000\u4EBA\u306E\u8A13\u7DF4\u3055\u308C\u305F\u7791\u60F3\u8005\u306F\u3001\u30EF\u30B7\u30F3\u30C8\u30F3D.C.\u306E\u66B4\u529B\u72AF\u7F6A\u309218%\u6E1B\u5C11\u3055\u305B\u308B\u300D\u3068\u3044\u3046\u3001\u5F7C\u306E\u5B9F\u9A13\u7684\u306A\u7D50\u8AD6\u306B\u5BFE\u3057\u3066\u3002\uFF081994\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u5E73\u548C\u8CDE\u53D7\u8CDE\uFF1A\u30B8\u30E7\u30F3\u30FB\u30CF\u30B0\u30EA\u30F3\uFF09http:\/\/goo.gl\/sTnr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88577952194891776",
    "text" : "\u300C4000\u4EBA\u306E\u8A13\u7DF4\u3055\u308C\u305F\u7791\u60F3\u8005\u306F\u3001\u30EF\u30B7\u30F3\u30C8\u30F3D.C.\u306E\u66B4\u529B\u72AF\u7F6A\u309218%\u6E1B\u5C11\u3055\u305B\u308B\u300D\u3068\u3044\u3046\u3001\u5F7C\u306E\u5B9F\u9A13\u7684\u306A\u7D50\u8AD6\u306B\u5BFE\u3057\u3066\u3002\uFF081994\u5E74\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u5E73\u548C\u8CDE\u53D7\u8CDE\uFF1A\u30B8\u30E7\u30F3\u30FB\u30CF\u30B0\u30EA\u30F3\uFF09http:\/\/goo.gl\/sTnr",
    "id" : 88577952194891776,
    "created_at" : "2011-07-06 12:00:04 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 88578798890647552,
  "created_at" : "2011-07-06 12:03:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 3, 13 ],
      "id_str" : "131534834",
      "id" : 131534834
    }, {
      "name" : "massa ",
      "screen_name" : "ssm_h",
      "indices" : [ 24, 30 ],
      "id_str" : "519545152",
      "id" : 519545152
    }, {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 39, 49 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88575122801307648",
  "text" : "RT @maru_mtod: \u3059\u30FB\u30FB\u30FB? RT @ssm_h: \u3059\u30FB\u30FB\u30FBRT @maru_mtod: \u6E05\u539F\u306F\u6E05\u539F\u3067\u3082\u3001\u5B50\u4F9B\u3060\u3063\u305F\u306E\u306B\u7FCC\u65E5\u306B\u6E05\u539F\u306B\u306A\u308B\u6E05\u539F\u306F\u306A\u30FC\u3093\u3060\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "massa ",
        "screen_name" : "ssm_h",
        "indices" : [ 9, 15 ],
        "id_str" : "519545152",
        "id" : 519545152
      }, {
        "name" : "\u307E\u308B",
        "screen_name" : "maru_mtod",
        "indices" : [ 24, 34 ],
        "id_str" : "131534834",
        "id" : 131534834
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88574902461923331",
    "text" : "\u3059\u30FB\u30FB\u30FB? RT @ssm_h: \u3059\u30FB\u30FB\u30FBRT @maru_mtod: \u6E05\u539F\u306F\u6E05\u539F\u3067\u3082\u3001\u5B50\u4F9B\u3060\u3063\u305F\u306E\u306B\u7FCC\u65E5\u306B\u6E05\u539F\u306B\u306A\u308B\u6E05\u539F\u306F\u306A\u30FC\u3093\u3060\uFF1F",
    "id" : 88574902461923331,
    "created_at" : "2011-07-06 11:47:57 +0000",
    "user" : {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "protected" : true,
      "id_str" : "131534834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2637146392\/f145e81f3a6524c5f749f3f38ea7e64d_normal.jpeg",
      "id" : 131534834,
      "verified" : false
    }
  },
  "id" : 88575122801307648,
  "created_at" : "2011-07-06 11:48:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "indices" : [ 3, 15 ],
      "id_str" : "94825321",
      "id" : 94825321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "happybirthday_twenty",
      "indices" : [ 119, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88574730864570368",
  "text" : "RT @milkyholmes: \u7E54\u59EB\u69D8\u3084\u5F66\u661F\u69D8\u306B\u300C\u30EA\u30A2\u5145\u7206\u767A\u3057\u308D\u300D\u3063\u3066\u3044\u3046\u306E\u306F\u7C21\u5358\u306A\u3093\u3067\u3059\u3088\u3000\u6211\u3005\u306F\u65E5\u672C\u306E\u6B74\u53F2\u3068\u3044\u3046\u5927\u304D\u306A\u5954\u6D41\u306E\u4E2D\u3067\u305D\u308C\u3092\u53D7\u3051\u5165\u308C\u3066\u3044\u304B\u306A\u3051\u308C\u3070\u306A\u3089\u306A\u3044\u3000\u3067\u3082\u306D\u3001\u305D\u3093\u306A\u4E2D\u50D5\u305F\u3061\u306F\u30C8\u30A5\u30A8\u30F3\u30C6\u30A3\u3055\u3093\u3092\u795D\u304A\u3046\u3063\u3066\u3044\u3046\u3093\u3060\uFF01\uFF01\u3000#happybirthday_twenty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "happybirthday_twenty",
        "indices" : [ 102, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88574270153834496",
    "text" : "\u7E54\u59EB\u69D8\u3084\u5F66\u661F\u69D8\u306B\u300C\u30EA\u30A2\u5145\u7206\u767A\u3057\u308D\u300D\u3063\u3066\u3044\u3046\u306E\u306F\u7C21\u5358\u306A\u3093\u3067\u3059\u3088\u3000\u6211\u3005\u306F\u65E5\u672C\u306E\u6B74\u53F2\u3068\u3044\u3046\u5927\u304D\u306A\u5954\u6D41\u306E\u4E2D\u3067\u305D\u308C\u3092\u53D7\u3051\u5165\u308C\u3066\u3044\u304B\u306A\u3051\u308C\u3070\u306A\u3089\u306A\u3044\u3000\u3067\u3082\u306D\u3001\u305D\u3093\u306A\u4E2D\u50D5\u305F\u3061\u306F\u30C8\u30A5\u30A8\u30F3\u30C6\u30A3\u3055\u3093\u3092\u795D\u304A\u3046\u3063\u3066\u3044\u3046\u3093\u3060\uFF01\uFF01\u3000#happybirthday_twenty",
    "id" : 88574270153834496,
    "created_at" : "2011-07-06 11:45:26 +0000",
    "user" : {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "protected" : false,
      "id_str" : "94825321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593967810226753537\/kej69_3u_normal.jpg",
      "id" : 94825321,
      "verified" : false
    }
  },
  "id" : 88574730864570368,
  "created_at" : "2011-07-06 11:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88568638403121152",
  "text" : "\u6CE2\u4E71\u306E\u6771\u5357\u6226\u3067\u3057\u305F\u3002\u6700\u5F8C\u6372\u3063\u3066\u5FC3\u5730\u3088\u304B\u3063\u305F\u304B\u3089\u52C9\u5F37\u306B\u79FB\u308A\u307E\u3059\u3002 http:\/\/tenhou.net\/0\/?log=2011070619gm-0059-0000-e5091cd1&tw=1",
  "id" : 88568638403121152,
  "created_at" : "2011-07-06 11:23:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88555170442649600",
  "text" : "\u30DB\u30AF\u30DB\u30AF\u304A\u3044\u3057\u30FC\u3067\u3059\u3045\u3000\u30B8\u30E3\u30AC\u30A4\u30E2\uFF3E\uFF3E",
  "id" : 88555170442649600,
  "created_at" : "2011-07-06 10:29:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88552409932115968",
  "text" : "\u6885\u305D\u3046\u3081\u3093\u3046\u3081\u30FC",
  "id" : 88552409932115968,
  "created_at" : "2011-07-06 10:18:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88412648198250496",
  "text" : "\u4E8C\u5EA6\u5BDD \u5149\u306E\u901F\u3055\u3067\u30B7\u30E3\u30EF\u30FC\uFF01",
  "id" : 88412648198250496,
  "created_at" : "2011-07-06 01:03:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88282745255641088",
  "geo" : { },
  "id_str" : "88284344652808192",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u3069\u3046\u3067\u3082\u3044\u3044\u304C\u5927\u5B66\u306E\u30AF\u30E9\u30B9\u30BF\u3067\u30DE\u30C3\u30C4\u306A\u3046\u2192\u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\u2192\u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\u3063\u3066\u30C6\u30F3\u30D7\u30EC\u304C\u3042\u308B\u3093\u3060\u3088\u306D",
  "id" : 88284344652808192,
  "in_reply_to_status_id" : 88282745255641088,
  "created_at" : "2011-07-05 16:33:22 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88281360309039105",
  "geo" : { },
  "id_str" : "88281902947115008",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4",
  "id" : 88281902947115008,
  "in_reply_to_status_id" : 88281360309039105,
  "created_at" : "2011-07-05 16:23:40 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88279013382045696",
  "geo" : { },
  "id_str" : "88280815494111232",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3042\u308B\u3042\u308B\uFF57\u7121\u8336\u3076\u308A\u3060\u3088\u306D\u3047",
  "id" : 88280815494111232,
  "in_reply_to_status_id" : 88279013382045696,
  "created_at" : "2011-07-05 16:19:21 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88280226404106243",
  "text" : "\u6C34\u5272\u308A\u3054\u99B3\u8D70\u69D8\u3067\u3057\u305F\u3002\u6C17\u6301\u3061\u826F\u3044\u307E\u307E\u30D9\u30C3\u30C9\u3078\uFF01",
  "id" : 88280226404106243,
  "created_at" : "2011-07-05 16:17:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 24, 35 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88278111212417024",
  "text" : "\u6587\u5B66\u7684\u306B\u306F\u3069\u3046\u306A\u306E\uFF1F\u3000\u3068\u304B\u3063\u3066\u30D5\u30EA\u3082\u4E00\u7DD2\u3000RT @magokoro84: \u6587\u5B66\u90E8\u751F\u306B\u300C\u6E90\u6C0F\u7269\u8A9E\u306B\u3064\u3044\u3066\u6559\u3048\u3066\u3088\u300D\u3063\u3066\u8A00\u3046\u306E\u3082\u540C\u3058",
  "id" : 88278111212417024,
  "created_at" : "2011-07-05 16:08:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3089\u3054\u3093\u3058",
      "screen_name" : "dragonjitheDF4",
      "indices" : [ 3, 18 ],
      "id_str" : "173886326",
      "id" : 173886326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88278089230073856",
  "text" : "RT @dragonjitheDF4: \u30E9\u30C3\u30D1\u30FC\u306B\u300C\u3061\u3087\u3063\u3068\u30E9\u30C3\u30D7\u3057\u3066\u3088\u300D\u3068\u304B\u3001\u304A\u7B11\u3044\u82B8\u4EBA\u306B\u300C\u3061\u3087\u3063\u3068\u9762\u767D\u3044\u3053\u3068\u8A00\u3063\u3066\u3088\u300D\u3063\u3066\u8A00\u3046\u306E\u306F\u3001\u5B87\u5B99\u98DB\u884C\u58EB\u306B\u300C\u3061\u3087\u3063\u3068\u6708\u307E\u3067\u884C\u3063\u3066\u3088\u300D\u3068\u304B\u3001AV\u5973\u512A\u306B\u300C\u3061\u3087\u3063\u3068\u30BB\u30C3\u30AF\u30B9\u3057\u3066\u3088\u300D\u3063\u3066\u8A00\u3046\u306E\u3068\u540C\u3058",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88214338107740160",
    "text" : "\u30E9\u30C3\u30D1\u30FC\u306B\u300C\u3061\u3087\u3063\u3068\u30E9\u30C3\u30D7\u3057\u3066\u3088\u300D\u3068\u304B\u3001\u304A\u7B11\u3044\u82B8\u4EBA\u306B\u300C\u3061\u3087\u3063\u3068\u9762\u767D\u3044\u3053\u3068\u8A00\u3063\u3066\u3088\u300D\u3063\u3066\u8A00\u3046\u306E\u306F\u3001\u5B87\u5B99\u98DB\u884C\u58EB\u306B\u300C\u3061\u3087\u3063\u3068\u6708\u307E\u3067\u884C\u3063\u3066\u3088\u300D\u3068\u304B\u3001AV\u5973\u512A\u306B\u300C\u3061\u3087\u3063\u3068\u30BB\u30C3\u30AF\u30B9\u3057\u3066\u3088\u300D\u3063\u3066\u8A00\u3046\u306E\u3068\u540C\u3058",
    "id" : 88214338107740160,
    "created_at" : "2011-07-05 11:55:11 +0000",
    "user" : {
      "name" : "\u3069\u3089\u3054\u3093\u3058",
      "screen_name" : "dragonjitheDF4",
      "protected" : false,
      "id_str" : "173886326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595077732624564224\/0rhGBEeg_normal.jpg",
      "id" : 173886326,
      "verified" : false
    }
  },
  "id" : 88278089230073856,
  "created_at" : "2011-07-05 16:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88276285285072896",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 88276285285072896,
  "created_at" : "2011-07-05 16:01:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88275097617575936",
  "geo" : { },
  "id_str" : "88275720354283520",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3080\u3063\u3061\u3083\u3075\u3041\u307C\u3089\u308C\u3066\u308B\uFF57\uFF57\uFF57\uFF57\u5403\u9A5A\uFF57\uFF57\uFF57",
  "id" : 88275720354283520,
  "in_reply_to_status_id" : 88275097617575936,
  "created_at" : "2011-07-05 15:59:06 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88274645463220225",
  "geo" : { },
  "id_str" : "88275075748466690",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u50D5\u3082\u3057\u3070\u3089\u304F\u51FA\u308C\u3066\u307E\u305B\u3093\uFF1E\uFF1C\u6559\u79D1\u66F8\u5FC5\u6B7B\u3067\u8FFD\u3044\u304B\u3051\u3066\u307E\u3059\u304C\u8A66\u9A13\u65E5\u7A0B\u3082\u7BC4\u56F2\u3082\u3055\u3063\u3071\u308A\uFF57",
  "id" : 88275075748466690,
  "in_reply_to_status_id" : 88274645463220225,
  "created_at" : "2011-07-05 15:56:32 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88274092205154305",
  "geo" : { },
  "id_str" : "88274366953046016",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u6708\u66DC\u4E00\u9650\u306E\u3084\u3064\u3067\u3059\u304B\uFF1F",
  "id" : 88274366953046016,
  "in_reply_to_status_id" : 88274092205154305,
  "created_at" : "2011-07-05 15:53:43 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88221847128248320",
  "geo" : { },
  "id_str" : "88268910620717056",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u9045\u304F\u306A\u3063\u3066\u3054\u3081\u3093\u3088\u30FC\u3002\u4ECA\u3071\u3063\u3068\u51FA\u308B\u306E\u306F\u5C71\u5C3E\u3055\u3093\u3068\u304B\u304B\u306A\u3002",
  "id" : 88268910620717056,
  "in_reply_to_status_id" : 88221847128248320,
  "created_at" : "2011-07-05 15:32:02 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88215642414661633",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 88215642414661633,
  "created_at" : "2011-07-05 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88173719456980992",
  "text" : "\u3042\u3001\u901A\u308B\u78BA\u7387\u3058\u3083\u306A\u304F\u3053\u306E\u5272\u5408\u70B9\u53D6\u3063\u305F\u3089\u901A\u308B\u3063\u3066\u8A71\u3067\u3059\u3002",
  "id" : 88173719456980992,
  "created_at" : "2011-07-05 09:13:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88173532244230144",
  "text" : "\u63D0\u51FA\u8AB2\u984C\u306E\u914D\u70B9\u304C\u4E00\u56DE\uFF15\u70B9\u306A\u3089\uFF12\u5272 \u4E00\u56DE\uFF11\uFF10\u70B9\u306A\u3089\u30DE\u30A4\u30CA\u30B91\/2\u5272\u3067\u901A\u308B\u3002\u3042\u308C\uFF1F",
  "id" : 88173532244230144,
  "created_at" : "2011-07-05 09:13:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88173139984519168",
  "text" : "\u4ECA\u65E5\u306E\u30C6\u30B9\u30C8\u3067\uFF12\u5272\u3068\u308C\u3070\u53EF\u3067\u901A\u308B\u8A08\u7B97\u3002\uFF12\u5272\u306F\u5272\u3089\u306A\u3044\u3060\u308Djk",
  "id" : 88173139984519168,
  "created_at" : "2011-07-05 09:11:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88168032001728512",
  "text" : "RT @wwwwww_bot: \u304A\u524D\u306E\u5B50\u306F\u9810\u304B\u3063\u305F \u8FD4\u3057\u3066\u6B32\u3057\u3051\u308C\u30701\u3092 \u305D\u308C\u4EE5\u5916\u306F2\u3092\u62BC\u3057\u3066\u304F\u3060\u3055\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88167375580569600",
    "text" : "\u304A\u524D\u306E\u5B50\u306F\u9810\u304B\u3063\u305F \u8FD4\u3057\u3066\u6B32\u3057\u3051\u308C\u30701\u3092 \u305D\u308C\u4EE5\u5916\u306F2\u3092\u62BC\u3057\u3066\u304F\u3060\u3055\u3044",
    "id" : 88167375580569600,
    "created_at" : "2011-07-05 08:48:35 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 88168032001728512,
  "created_at" : "2011-07-05 08:51:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 23, 34 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88166549399154688",
  "text" : "\u4FFA\u3082\u56F3\u5F62\u3060\u3068\u601D\u3044\u8FBC\u307E\u308C\u3066\u308B\u4E8B\u304C\u2026\u306A\u3044\u304B RT @magokoro84: \u6700\u8FD1\u30A2\u30A4\u30B3\u30F3\u3092\u898B\u3066\u5973\u6027\u3068\u601D\u3044\u8FBC\u307E\u308C\u3066\u308B\u3053\u3068\u304C\u591A\u3044",
  "id" : 88166549399154688,
  "created_at" : "2011-07-05 08:45:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88159809152626688",
  "text" : "@ayu167 \u30CF\u30A4\u30EC\u30D9\u30EB\u306A\u30D0\u30AB\u306E\u8A71\u304B\u3088\uFF57\uFF57\uFF57\uFF57",
  "id" : 88159809152626688,
  "created_at" : "2011-07-05 08:18:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88158836720025600",
  "text" : "@ayu167 \u3060\u308C\u3060\u3088\uFF57",
  "id" : 88158836720025600,
  "created_at" : "2011-07-05 08:14:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88157705608503296",
  "text" : "\u30B3\u30FC\u30EB\u3042\u308B\u65E5\u306B\u9650\u3063\u3066\uFF15\u9650\u306E\u8AB2\u984C\u304C\u77AC\u6BBA\u3067\u304D\u308B\u30B8\u30F3\u30AF\u30B9",
  "id" : 88157705608503296,
  "created_at" : "2011-07-05 08:10:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoshifumi YAMAGUCHI",
      "screen_name" : "ymotongpoo",
      "indices" : [ 3, 14 ],
      "id_str" : "4135891",
      "id" : 4135891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88157475072782336",
  "text" : "RT @ymotongpoo: \u3044\u307ETL\u306B\u300C\u30AC\u30EA\u30AC\u30EA\u541B\u306E\u68A8\u5473\u306E\u539F\u6750\u6599\u304C\u30EA\u30F3\u30B4\u300D\u3068\u3044\u3046\u885D\u6483\u30CB\u30E5\u30FC\u30B9\u304C\u98DB\u3073\u8FBC\u3093\u3067\u304D\u3066\u3001\u6B63\u76F4\u3046\u308D\u305F\u3048\u3066\u3044\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88018017585340416",
    "text" : "\u3044\u307ETL\u306B\u300C\u30AC\u30EA\u30AC\u30EA\u541B\u306E\u68A8\u5473\u306E\u539F\u6750\u6599\u304C\u30EA\u30F3\u30B4\u300D\u3068\u3044\u3046\u885D\u6483\u30CB\u30E5\u30FC\u30B9\u304C\u98DB\u3073\u8FBC\u3093\u3067\u304D\u3066\u3001\u6B63\u76F4\u3046\u308D\u305F\u3048\u3066\u3044\u308B",
    "id" : 88018017585340416,
    "created_at" : "2011-07-04 22:55:05 +0000",
    "user" : {
      "name" : "Yoshifumi YAMAGUCHI",
      "screen_name" : "ymotongpoo",
      "protected" : false,
      "id_str" : "4135891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577731230776455168\/DFdo3A-D_normal.png",
      "id" : 4135891,
      "verified" : false
    }
  },
  "id" : 88157475072782336,
  "created_at" : "2011-07-05 08:09:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 8, 17 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 19, 30 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88157409499037696",
  "text" : "\u306B\u305B\u307B\u2026 RT @nisehorn: @magokoro84 \u3080 \u3057 \u308D \u306F \u3058 \u307E \u3063 \u305F",
  "id" : 88157409499037696,
  "created_at" : "2011-07-05 08:08:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88142493387993088",
  "text" : "\u30CF\u30A4\u30EC\u30D9\u30EB\u306A\u30A2\u30DB\u3063\u3066\u5927\u597D\u304D",
  "id" : 88142493387993088,
  "created_at" : "2011-07-05 07:09:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u307A\u3067\u3043",
      "screen_name" : "copedy",
      "indices" : [ 3, 10 ],
      "id_str" : "152242373",
      "id" : 152242373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88142105985302528",
  "text" : "RT @copedy: \u9AD8\u6821\u751F\u300C\u53D7\u9A13\u306B\u6210\u529F\u3059\u308C\u3070\u52DD\u3061\u7D44\uFF01\uFF01\u300D\n\n\u5927\u5B66\u751F\u300C\u3070\u30FC\u304B\u3002\u5927\u5B66\u306A\u3093\u3066\u7D50\u5C40\u904A\u3073\u3060\u3088\u3002\u5C31\u8077\u304C\u5168\u3066\u3060\uFF01\u300D\n\n\u793E\u4F1A\u4EBA\u300C\u3061\u3052\u30FC\u3088\u3002\u50CD\u3044\u305F\u3089\u308F\u304B\u308B\u3051\u3069\u3001\u5927\u5207\u306A\u306E\u306F\u81EA\u5206\u306E\u6642\u9593\u3060\u3088\u3002\u300D\n\n\u4E2D\u5E74\u300C\u99AC\u9E7F\u3060\u306A\u304A\u524D\u3089\u2026\u5BB6\u5EAD\u3092\u6301\u3063\u3066\u304B\u3089\u304C\u4EBA\u751F\u3060\uFF01\u300D\n\n\u30CB\u30FC\u30C8\u300C\u3046\u304A\u304A\u304A\u304A\u304A\uFF01\uFF01 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88112876698611713",
    "text" : "\u9AD8\u6821\u751F\u300C\u53D7\u9A13\u306B\u6210\u529F\u3059\u308C\u3070\u52DD\u3061\u7D44\uFF01\uFF01\u300D\n\n\u5927\u5B66\u751F\u300C\u3070\u30FC\u304B\u3002\u5927\u5B66\u306A\u3093\u3066\u7D50\u5C40\u904A\u3073\u3060\u3088\u3002\u5C31\u8077\u304C\u5168\u3066\u3060\uFF01\u300D\n\n\u793E\u4F1A\u4EBA\u300C\u3061\u3052\u30FC\u3088\u3002\u50CD\u3044\u305F\u3089\u308F\u304B\u308B\u3051\u3069\u3001\u5927\u5207\u306A\u306E\u306F\u81EA\u5206\u306E\u6642\u9593\u3060\u3088\u3002\u300D\n\n\u4E2D\u5E74\u300C\u99AC\u9E7F\u3060\u306A\u304A\u524D\u3089\u2026\u5BB6\u5EAD\u3092\u6301\u3063\u3066\u304B\u3089\u304C\u4EBA\u751F\u3060\uFF01\u300D\n\n\u30CB\u30FC\u30C8\u300C\u3046\u304A\u304A\u304A\u304A\u304A\uFF01\uFF01\uFF01\u30EA\u30AA\u30EC\u30A6\u30B93\u5206\u3067\u5012\u3057\u305F\uFF01\uFF01\uFF01\u300D",
    "id" : 88112876698611713,
    "created_at" : "2011-07-05 05:12:01 +0000",
    "user" : {
      "name" : "\u3053\u307A\u3067\u3043",
      "screen_name" : "copedy",
      "protected" : false,
      "id_str" : "152242373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428845627313647616\/yx6wMaK6_normal.jpeg",
      "id" : 152242373,
      "verified" : false
    }
  },
  "id" : 88142105985302528,
  "created_at" : "2011-07-05 07:08:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88135327532843008",
  "geo" : { },
  "id_str" : "88135599441186816",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30DE\u30B8\u304B\uFF57\uFF57\u6C17\u3065\u304B\u306A\u304B\u3063\u305F\u308F\u3002\u9053\u7406\u3067\u30D5\u30A9\u30ED\u30EF\u30FC\u5897\u3048\u3066\u308B\u308F\u3051\u3060\u3002",
  "id" : 88135599441186816,
  "in_reply_to_status_id" : 88135327532843008,
  "created_at" : "2011-07-05 06:42:19 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88135408348692480",
  "text" : "\u8A18\u53F7\u8AD6\u7406 \u96C6\u5408\u3068\u4F4D\u76F8 \u30B7\u30E5\u30DF\u30EC\u30FC\u30B7\u30E7\u30F3\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0 \u5168\u90E8\u304C\u5FAE\u304B\u306B\u7E4B\u304C\u308B\u306E\u304C\u5FC3\u5730\u826F\u3044",
  "id" : 88135408348692480,
  "created_at" : "2011-07-05 06:41:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88134976171810816",
  "text" : "\u3086\u30FC\u3052\u3093\u3059\u3066\u3063\u3077\u3067\u3057\u3085\u3046\u308A\u3087\u3046\u3059\u308B\u3051\u30FC\u3055\u3093",
  "id" : 88134976171810816,
  "created_at" : "2011-07-05 06:39:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88134642649141248",
  "text" : "\u3052\u3093\u3057\u3055\u3044\u304D\u3066\u304D\u304B\u3093\u3059\u30FC\u306E\u308C\u3044",
  "id" : 88134642649141248,
  "created_at" : "2011-07-05 06:38:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88133827934945280",
  "text" : "\uFF31 \u81EA\u7136\u6570\u304B\u7720\u308A\u59EB\u306E\u30A4\u30E1\u30FC\u30B8",
  "id" : 88133827934945280,
  "created_at" : "2011-07-05 06:35:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88132386201681921",
  "geo" : { },
  "id_str" : "88133542470619136",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5927\u6728\u3055\u3093\u306B\u30E1\u30FC\u30EB\u3057\u3068\u304D",
  "id" : 88133542470619136,
  "in_reply_to_status_id" : 88132386201681921,
  "created_at" : "2011-07-05 06:34:08 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "\u5CA1\u4E09\u30DE\u30F3",
      "screen_name" : "okasanman",
      "indices" : [ 28, 38 ],
      "id_str" : "56654358",
      "id" : 56654358
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 40, 47 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88131834440974336",
  "text" : "RT @NHK_PR: \u30A2\u30CA\u30ED\u30B0\u30DE\u306F\u60C5\u5F31\uFF08\uFF77\uFF98\uFF6F RT @okasanman: @NHK_PR \u8CB4\u65B9\u306F\u30A2\u30CA\u30ED\u30B0\u30DE\u306E\u6C17\u6301\u3061\u3092\u8003\u3048\u305F\u3053\u3068\u304C\u3042\u308B\u3093\u3067\u3059\u304B\u30C3\u30FD(#\uFF40\u03B5\u00B4)\u30CE\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5CA1\u4E09\u30DE\u30F3",
        "screen_name" : "okasanman",
        "indices" : [ 16, 26 ],
        "id_str" : "56654358",
        "id" : 56654358
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 28, 35 ],
        "id_str" : "93311525",
        "id" : 93311525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88130695947501569",
    "text" : "\u30A2\u30CA\u30ED\u30B0\u30DE\u306F\u60C5\u5F31\uFF08\uFF77\uFF98\uFF6F RT @okasanman: @NHK_PR \u8CB4\u65B9\u306F\u30A2\u30CA\u30ED\u30B0\u30DE\u306E\u6C17\u6301\u3061\u3092\u8003\u3048\u305F\u3053\u3068\u304C\u3042\u308B\u3093\u3067\u3059\u304B\u30C3\u30FD(#\uFF40\u03B5\u00B4)\u30CE\uFF01",
    "id" : 88130695947501569,
    "created_at" : "2011-07-05 06:22:49 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 88131834440974336,
  "created_at" : "2011-07-05 06:27:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88124331527376896",
  "geo" : { },
  "id_str" : "88126258080264192",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \n\u30B3\u30FC\u30EB\u30C6\u30B9\u30C8\u3053\u308C\u305D\u3046\uFF1F",
  "id" : 88126258080264192,
  "in_reply_to_status_id" : 88124331527376896,
  "created_at" : "2011-07-05 06:05:11 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88122593290362880",
  "text" : "\u30ED\u30D3\u30F3\u30BD\u30F3\u3055\u3093\u304C\u8003\u3048\u305F\u30ED\u30D3\u30F3\u30BD\u30F3\u3055\u3093\u8853\u2026",
  "id" : 88122593290362880,
  "created_at" : "2011-07-05 05:50:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88098823234256896",
  "geo" : { },
  "id_str" : "88099340777820160",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u63D0\u51FA\u524D\u3058\u3083\u306A\u304F\u3066\u672C\u5F53\u306B\u826F\u304B\u3063\u305F\u3067\u3059\u3002",
  "id" : 88099340777820160,
  "in_reply_to_status_id" : 88098823234256896,
  "created_at" : "2011-07-05 04:18:14 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88089070139486208",
  "geo" : { },
  "id_str" : "88098379875368960",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u7406\u79D1\u5927\u306F\u5927\u5B66\u9662\u4E88\u5099\u6821\u3067\u7559\u5E74\u7387\u304C\u9AD8\u3044\u3002\u53B3\u3057\u3044\u3093\u3058\u3083\u306A\u3044\uFF1F",
  "id" : 88098379875368960,
  "in_reply_to_status_id" : 88089070139486208,
  "created_at" : "2011-07-05 04:14:25 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 17, 24 ],
      "id_str" : "239486216",
      "id" : 239486216
    }, {
      "name" : "\u0424\u0435\u0434\u043E\u0442\u043E\u0432\r\n",
      "screen_name" : "Core2DuoE6320",
      "indices" : [ 37, 51 ],
      "id_str" : "2982532882",
      "id" : 2982532882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88086417024098305",
  "text" : "\u5931\u8A00\u3057\u3066\u4EBA\u9593\u3092\u3084\u3081\u308B\u305E\u30FC\uFF01 RT @khulud: \u3053\u308C\u306F\u30AC\u30C1\u2026\u2026\uFF0ERT @Core2DuoE6320: \u5931\u8A00\u3057\u3066twitter\u8F9E\u3081\u305F\u304F\u306A\u3063\u305F",
  "id" : 88086417024098305,
  "created_at" : "2011-07-05 03:26:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88077248250384384",
  "text" : "RT @JOJO_math: \u307C\u304F\u306F\u541B\u3092\u3084\u308A\u3053\u3081\u305F\u304F\u3063\u3066\u9593\u9055\u3044\u3092\u6307\u6458\u3057\u305F\u3093\u3058\u3083\u3042\u306A\u3044\u305E\u30C3\uFF01\u307C\u304F\u3089\u306F\u672C\u5F53\u306E\u6570\u5B66\u8005\u3092\u3081\u3056\u3057\u3066\u3044\u308B\u304B\u3089\u3060\uFF01\u541B\u306E\u8A3C\u660E\u304C\u8AA4\u3063\u3066\u3044\u305F\u304B\u3089\u3060\uFF01\u76F8\u624B\u304C\u4EF2\u306E\u3044\u3044\u30E4\u30C4\u3060\u304B\u3089\u3063\u3066\u3000\u30BB\u30DF\u30CA\u30FC\u304C\u5EF6\u3073\u3066\u7D42\u96FB\u3092\u9003\u3059\u3068\u308F\u304B\u3063\u3066\u308B\u304B\u3089\u3063\u3066\u3000\u6570\u5B66\u8005\u306F\u52C7\u6C17\u3092\u6301\u3063\u3066\u3000\u8AA4\u308A\u3092\u6307\u6458\u3057 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88071615400775681",
    "text" : "\u307C\u304F\u306F\u541B\u3092\u3084\u308A\u3053\u3081\u305F\u304F\u3063\u3066\u9593\u9055\u3044\u3092\u6307\u6458\u3057\u305F\u3093\u3058\u3083\u3042\u306A\u3044\u305E\u30C3\uFF01\u307C\u304F\u3089\u306F\u672C\u5F53\u306E\u6570\u5B66\u8005\u3092\u3081\u3056\u3057\u3066\u3044\u308B\u304B\u3089\u3060\uFF01\u541B\u306E\u8A3C\u660E\u304C\u8AA4\u3063\u3066\u3044\u305F\u304B\u3089\u3060\uFF01\u76F8\u624B\u304C\u4EF2\u306E\u3044\u3044\u30E4\u30C4\u3060\u304B\u3089\u3063\u3066\u3000\u30BB\u30DF\u30CA\u30FC\u304C\u5EF6\u3073\u3066\u7D42\u96FB\u3092\u9003\u3059\u3068\u308F\u304B\u3063\u3066\u308B\u304B\u3089\u3063\u3066\u3000\u6570\u5B66\u8005\u306F\u52C7\u6C17\u3092\u6301\u3063\u3066\u3000\u8AA4\u308A\u3092\u6307\u6458\u3057\u306A\u304F\u3066\u306F\u306A\u3089\u306A\u3044\u6642\u304C\u3042\u308B\u304B\u3089\u3060\u305E\u30C3\uFF01\uFF01",
    "id" : 88071615400775681,
    "created_at" : "2011-07-05 02:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 88077248250384384,
  "created_at" : "2011-07-05 02:50:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "indices" : [ 3, 14 ],
      "id_str" : "161635350",
      "id" : 161635350
    }, {
      "name" : "\u5C71\u7530\u9AD8\u5F18",
      "screen_name" : "_yamadaman_",
      "indices" : [ 31, 43 ],
      "id_str" : "109341663",
      "id" : 109341663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88072329657196544",
  "text" : "RT @kisalantis: \u305F\u3060\u3054\u3068\u3067\u306F\u306A\u3044\u3067\u3059\u306A\uFF01RT @_yamadaman_: \u6BBA\u3055\u308C\u308B\u30FC\uFF01\u52A9\u3051\u3066\u30FC\uFF01\u3068\u3044\u3046\u5973\u306E\u5B50\u306E\u53EB\u3073\u58F0\u304C\u5ECA\u4E0B\u3067\u805E\u3053\u3048\u3066 \u88F8\u8DB3\u3067\u98DB\u3073\u51FA\u3057\u305F\u3089 \u30B9\u30AB\u30FC\u30C8\u5C65\u3044\u305F\u7537\u304C\u5973\u306E\u5B50\u306E\u9996\u3057\u3081\u3066\u3066 \u73FE\u5728\u8B66\u5BDF\u6C99\u6C70\u306A\u3046\u3002\u3002\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5C71\u7530\u9AD8\u5F18",
        "screen_name" : "_yamadaman_",
        "indices" : [ 15, 27 ],
        "id_str" : "109341663",
        "id" : 109341663
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88067944847904768",
    "text" : "\u305F\u3060\u3054\u3068\u3067\u306F\u306A\u3044\u3067\u3059\u306A\uFF01RT @_yamadaman_: \u6BBA\u3055\u308C\u308B\u30FC\uFF01\u52A9\u3051\u3066\u30FC\uFF01\u3068\u3044\u3046\u5973\u306E\u5B50\u306E\u53EB\u3073\u58F0\u304C\u5ECA\u4E0B\u3067\u805E\u3053\u3048\u3066 \u88F8\u8DB3\u3067\u98DB\u3073\u51FA\u3057\u305F\u3089 \u30B9\u30AB\u30FC\u30C8\u5C65\u3044\u305F\u7537\u304C\u5973\u306E\u5B50\u306E\u9996\u3057\u3081\u3066\u3066 \u73FE\u5728\u8B66\u5BDF\u6C99\u6C70\u306A\u3046\u3002\u3002\u3002",
    "id" : 88067944847904768,
    "created_at" : "2011-07-05 02:13:28 +0000",
    "user" : {
      "name" : "\u30E9\u30F3\u30C6\u30A3\u30B9\u30AD\u30B5\u30E9",
      "screen_name" : "kisalantis",
      "protected" : false,
      "id_str" : "161635350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451385034910347265\/OhkVStyG_normal.jpeg",
      "id" : 161635350,
      "verified" : false
    }
  },
  "id" : 88072329657196544,
  "created_at" : "2011-07-05 02:30:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88049996162797568",
  "text" : "\u305D\u308D\u305D\u308D\u8D77\u304D\u4E0A\u304C\u3089\u306A\u3044\u3068\u9593\u306B\u5408\u308F\u306A\u3044\u306A\u3041\u3002\u6691\u304F\u3066\u71B1\u304F\u3066\u3084\u308B\u6C17\u304C\u304C\u304C",
  "id" : 88049996162797568,
  "created_at" : "2011-07-05 01:02:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88049796920770560",
  "text" : "@ayu167 \u3064\u6795",
  "id" : 88049796920770560,
  "created_at" : "2011-07-05 01:01:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88043965777063936",
  "text" : "@mo5nya \u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u30FC\u3002",
  "id" : 88043965777063936,
  "created_at" : "2011-07-05 00:38:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88037188150886401",
  "geo" : { },
  "id_str" : "88038623936643072",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u7720\u3044\u3093\u3060\u3051\u3069",
  "id" : 88038623936643072,
  "in_reply_to_status_id" : 88037188150886401,
  "created_at" : "2011-07-05 00:16:58 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88036934047375361",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3002",
  "id" : 88036934047375361,
  "created_at" : "2011-07-05 00:10:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88036848680706049",
  "text" : "\u8D77\u304D\u305F\u3002\u5BDD\u8DB3\u308A\u306A\u3044\u2026\u3002",
  "id" : 88036848680706049,
  "created_at" : "2011-07-05 00:09:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87929143584493568",
  "text" : "\u3093\u30FC\u5BDD\u308B\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 87929143584493568,
  "created_at" : "2011-07-04 17:01:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87925786740408320",
  "geo" : { },
  "id_str" : "87926913213005824",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3084\u3059\u307F",
  "id" : 87926913213005824,
  "in_reply_to_status_id" : 87925786740408320,
  "created_at" : "2011-07-04 16:53:04 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87918685494325248",
  "geo" : { },
  "id_str" : "87925068063182849",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu \u4E8C\u9031\u76EE\u306B\u98DF\u3044\u8FBC\u3080\u304B\u3082\u3060\u304B\u3089\u78BA\u5B9A\u3057\u305F\u3089\u77E5\u3089\u305B\u307E\u3059\u30FC\u3002",
  "id" : 87925068063182849,
  "in_reply_to_status_id" : 87918685494325248,
  "created_at" : "2011-07-04 16:45:44 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87924277961175040",
  "geo" : { },
  "id_str" : "87924818988634112",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5999\u306A\u89AA\u8FD1\u611F",
  "id" : 87924818988634112,
  "in_reply_to_status_id" : 87924277961175040,
  "created_at" : "2011-07-04 16:44:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87917204984696832",
  "geo" : { },
  "id_str" : "87917343228952576",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6628\u591C\u306F\u904A\u3073\u3059\u304E\u305F\u306A",
  "id" : 87917343228952576,
  "in_reply_to_status_id" : 87917204984696832,
  "created_at" : "2011-07-04 16:15:02 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87915364796735488",
  "text" : "\u306A\u3093\u304B\uFF12\u30C4\u30A4\u30FC\u30C8\u3057\u304B\u3057\u306A\u3044\u65E5\u3082\u3042\u308C\u3070\u4ECA\u65E5\u307F\u305F\u3044\u306B\u8352\u3076\u308B\u65E5\u3082\u3042\u308B\u3051\u3069\u6C17\u5206\u306E\u554F\u984C\u306A\u306E\u304B\u306A\u3002",
  "id" : 87915364796735488,
  "created_at" : "2011-07-04 16:07:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87915208357593088",
  "text" : "\u65E9\u3081\u306B\u5E03\u56E3\u306B\u79FB\u308B\u304B\u306A\u30FC\u3002\u307E\u3060\u5BDD\u306A\u3044\u3060\u308D\u3046\u3051\u3069\u3002",
  "id" : 87915208357593088,
  "created_at" : "2011-07-04 16:06:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87914908078968832",
  "text" : "\u6700\u8FD1\uFF12\u6642\u304F\u3089\u3044\u306B\uFF30\uFF23\u843D\u3068\u3057\u3066\u7720\u308A\u306B\u3064\u304F\u306E\u304C\uFF13\u6642\u904E\u304E\u3063\u3066\u30B5\u30A4\u30AF\u30EB\u304C\u3067\u304D\u304B\u3051\u3066\u3066\u3088\u304F\u306A\u3044\u306A\u3002\u4ECA\u65E5\u3082\u4E00\u9650\u4F59\u88D5\u3067\u9593\u306B\u5408\u3046\u6642\u9593\u306B\u8D77\u304D\u308C\u305F\u306E\u306B\u9664\u6E7F\u4ED8\u3051\u3066\u30C8\u30A4\u30EC\u884C\u3063\u3066\u304B\u3089\u610F\u56F3\u7684\u306B\u4E8C\u5EA6\u5BDD\u3057\u3061\u3083\u3063\u305F\u3057\u306A\u3002\u3057\u304B\u3082\uFF14\u9650\u3082\u307B\u307C\u5BDD\u3066\u305F\u3002",
  "id" : 87914908078968832,
  "created_at" : "2011-07-04 16:05:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87914333564190721",
  "text" : "\u4E88\u5B9A\u304C\u5728\u3063\u305F\u3089\u30C0\u30E1\u3060\u3051\u3069 \u4E88\u5B9A\u304C\u5408\u3063\u305F\u3089\u884C\u304D\u307E\u3057\u3087\u3046\u3002\u3084\u3084\u3053\u3057\u3044\u9593\u9055\u3044\u3060\u306A\u3002",
  "id" : 87914333564190721,
  "created_at" : "2011-07-04 16:03:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87913516664750080",
  "geo" : { },
  "id_str" : "87914150189219840",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu \u8A73\u7D30\u672A\u5B9A\u3060\u3051\u3069\uFF18\u6708\uFF11\u9031\u76EE\u306B\u5E30\u7701\u3059\u308B\u3051\u3069\u4E88\u5B9A\u304C\u3042\u3063\u305F\u3089\u8EFD\u304F\u98F2\u307F\u306B\u3067\u3082\u884C\u304D\u307E\u3059\u304B\u30FC\u3002\u524D\u7530\u3055\u3093\u3068\u304B\u5352\u696D\u4EE5\u6765\u4F1A\u3063\u3066\u306A\u3044\u3088\u3046\u306A\u3002\u3002\u3002",
  "id" : 87914150189219840,
  "in_reply_to_status_id" : 87913516664750080,
  "created_at" : "2011-07-04 16:02:21 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 12, 22 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87912700209934336",
  "geo" : { },
  "id_str" : "87913401191378944",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori @blackpiyu \u3042\u308B\u3088\u30FC\u3002\u534A\u5206\u8A66\u7528\u5E97\u8217\u307F\u305F\u3044\u306A\u611F\u3058\u3060\u3063\u305F\u3089\u3057\u3044\u3002\u68DA\u3068\u304B\u306B\u306A\u30FC\u3093\u306B\u3082\u306A\u3044\u30B3\u30F3\u30D3\u30CB\u3063\u3066\u975E\u65E5\u5E38\u611F\u304C\u3042\u3063\u3066\u9762\u767D\u304B\u3063\u305F\u306A\u3002\u3042\u3068\u304A\u5E97\u306B\u5728\u3063\u305F\u30DD\u30C3\u30C8\u3068\u304B\u4F59\u3063\u3066\u305F\u30B9\u30C8\u30ED\u30FC\u3068\u304B\u7D19\u888B\u3068\u304B\u30B9\u30C6\u30A3\u30C3\u30AF\u30B7\u30E5\u30AC\u30FC\u3092\u5927\u91CF\u306B\u9802\u3044\u305F\u306E\u306F\u3044\u3044\u601D\u3044\u51FA\u3002",
  "id" : 87913401191378944,
  "in_reply_to_status_id" : 87912700209934336,
  "created_at" : "2011-07-04 15:59:22 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87912252426043392",
  "geo" : { },
  "id_str" : "87912935095144448",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u3042\u308C\uFF1F\u77E5\u3089\u306A\u304B\u3063\u305F\u306E\u304B\u30FC\u3001\u4E00\u90E8\u306B\u306F\u6F0F\u308C\u3066\u305F\u307F\u305F\u3044\u3060\u3063\u305F\u3051\u3069\u3002\u30DE\u30C3\u30AF\u304B\u30FC\u3002\u30DE\u30C3\u30AF\u306E\u30D0\u30A4\u30C8\u306B\u3042\u3093\u307E\u308A\u3044\u3044\u8A71\u3092\u805E\u304B\u306A\u3044\u3093\u3060\u3051\u3069\u3069\u3046\u306A\u306E\u304B\u306D\uFF1F\u305D\u3082\u305D\u3082\u30DE\u30C3\u30AF\u5ACC\u3044\u3060\u304B\u3089\u30A2\u30EC\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 87912935095144448,
  "in_reply_to_status_id" : 87912252426043392,
  "created_at" : "2011-07-04 15:57:31 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87912308537430016",
  "text" : "\u6628\u65E5\u3068\u4ECA\u65E5\u3067\u53CD\u5C04\u5F8B \u5BFE\u79F0\u5F8B \u53CD\u5BFE\u79F0\u5F8B \u63A8\u79FB\u5F8B\u3068\u306F\u304A\u53CB\u9054\u306B\u306A\u308C\u305F\u304B\u306A\uFF1F\u5076\u7136\u8A18\u53F7\u8AD6\u7406\u3068\u96C6\u5408\u304C\u91CD\u306A\u3063\u305F\u3060\u3051\u3060\u3051\u3069\u3002",
  "id" : 87912308537430016,
  "created_at" : "2011-07-04 15:55:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87911952097095680",
  "text" : "\uFF12\u2260\uFF13\u3068\uFF11\u2260\uFF10\u3092\u8A3C\u660E\u3059\u308B\u3060\u3051\u306E\u7C21\u5358\u306A\u8AB2\u984C\u3002\u80CC\u7406\u6CD5\u4F7F\u3063\u3066\u516C\u7406\u307E\u3067\u3055\u304B\u306E\u307C\u308B\u3002\u3068\u3053\u308D\u3067\u300C\u3044\u3053\u30FC\u308B\u300D\u3067\u300C\u2260\u300D\u3068\u304B\u300C\u2252\u300D\u304C\u5909\u63DB\u3067\u304D\u308B\u306E\u306B\u7D0D\u5F97\u3044\u304B\u306A\u3044\u3002\u3044\u3084\u3001\u4FBF\u5229\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 87911952097095680,
  "created_at" : "2011-07-04 15:53:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87911151526096896",
  "text" : "\u3057\u3087\u3046\u3048\u3044\u306E\u753B\u50CF\u306B\u5F35\u308A\u66FF\u3048\u3066\u3042\u3063\u305F\u3089\u2026",
  "id" : 87911151526096896,
  "created_at" : "2011-07-04 15:50:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87910032028606464",
  "geo" : { },
  "id_str" : "87910885783371777",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u3084\u3063\u3071\u9589\u5E97\u304B\u30FC\u3044\u3064\u3082\u3068\u9055\u3046\u696D\u52D9\u304C\u65B0\u9BAE\u3060\u3063\u305F\u308A\u3059\u308B\u3088\u306D\u3001\u5B9F\u306F\u9AD8\u6821\u306E\u6642\u30B3\u30F3\u30D3\u30CB\u306E\u30AF\u30ED\u30FC\u30BA\u3084\u3063\u305F\u3053\u3068\u3042\u308B\u3093\u3060\u308F\u3002\u4ECA\u306F\u5BB6\u5EAD\u6559\u5E2B\u3084\u3063\u3066\u308B\u3088\u30FC\u3002\u5272\u306F\u826F\u3044\u3051\u3069\u5358\u4F4D\u6642\u9593\u304C\u5C11\u306A\u304F\u3066\u5897\u3084\u305D\u3046\u304B\u8003\u3048\u4E2D\u2026\u3002",
  "id" : 87910885783371777,
  "in_reply_to_status_id" : 87910032028606464,
  "created_at" : "2011-07-04 15:49:23 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87906899332313088",
  "geo" : { },
  "id_str" : "87907470336471040",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u305D\u308C\u3067\u3082\u4E0D\u5BE9\u3060\u3088\u306D\u2026\u304A\u75B2\u308C\u69D8\u3067\u3057\u305F\u3002\u3068\u3053\u308D\u3067\u30AF\u30ED\u30FC\u30BA\u3063\u3066\u5E97\u8217\u306E\u9589\u5E97\uFF1F\u305D\u308C\u3068\u3082\u305D\u306E\u65E5\u306E\u7D42\u308F\u308A\u3063\u3066\u610F\u5473\uFF1F",
  "id" : 87907470336471040,
  "in_reply_to_status_id" : 87906899332313088,
  "created_at" : "2011-07-04 15:35:48 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tetsu",
      "screen_name" : "tetsu678",
      "indices" : [ 3, 12 ],
      "id_str" : "70092627",
      "id" : 70092627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87906739009228800",
  "text" : "RT @tetsu678: \u3055\u3063\u304D\u306E\u7A32\u5149\u306F\u51C4\u304B\u3063\u305F\u3002\u64AE\u3063\u3066\u3066\u30D3\u30D3\u3063\u305F \u6C57    http:\/\/twitpic.com\/5l2jww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87859665211363329",
    "text" : "\u3055\u3063\u304D\u306E\u7A32\u5149\u306F\u51C4\u304B\u3063\u305F\u3002\u64AE\u3063\u3066\u3066\u30D3\u30D3\u3063\u305F \u6C57    http:\/\/twitpic.com\/5l2jww",
    "id" : 87859665211363329,
    "created_at" : "2011-07-04 12:25:51 +0000",
    "user" : {
      "name" : "Tetsu",
      "screen_name" : "tetsu678",
      "protected" : false,
      "id_str" : "70092627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/391137129\/IMG_0283_normal.jpg",
      "id" : 70092627,
      "verified" : false
    }
  },
  "id" : 87906739009228800,
  "created_at" : "2011-07-04 15:32:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87905421104381953",
  "text" : "@koketomi \u3042\u308C\u304B\u3089\uFF13\uFF4B\uFF47\u3063\u3066\u300C\u8CB4\u69D8\u306E\u3069\u3053\u306B\u305D\u3093\u306A\u8CEA\u91CF\u304C\u6B8B\u3063\u3066\u3044\u305F\u3068\u3044\u3046\u3093\u3060\u30C3\u300D\u3063\u3066\u30EC\u30D9\u30EB\u3060\u306A\u3002",
  "id" : 87905421104381953,
  "created_at" : "2011-07-04 15:27:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87905251914547200",
  "text" : "RT @p_kumaa: \u305D\u3046\u3044\u3048\u3070\u3001\u300C\u3053\u308C\u7A4D\u5206\u3059\u308B\u306E\u306B\u90E8\u5206\u7A4D\u52065\u56DE\u3082\u3059\u308B\u5FC5\u8981\u304C\u3042\u308B\u306A\u2026\u2192\u4ED6\u306B\u3044\u3044\u3084\u308A\u65B9\u306F\u7121\u3044\u304B\u2026\u2192\uFF08\u4E2D\u7565\uFF09\u2192\u4FFA\u306F\u90E8\u5206\u7A4D\u5206\u306E\u9B3C\u306B\u306A\u308B\u2026\uFF01\u300D\u3068\u304B\u30DD\u30B9\u30C8\u3057\u3066\u305F\u4EBA\u3001\u305D\u308C\u4EE5\u6765Twitter\u3067\u898B\u3066\u306A\u3044\u306A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87903174509346816",
    "text" : "\u305D\u3046\u3044\u3048\u3070\u3001\u300C\u3053\u308C\u7A4D\u5206\u3059\u308B\u306E\u306B\u90E8\u5206\u7A4D\u52065\u56DE\u3082\u3059\u308B\u5FC5\u8981\u304C\u3042\u308B\u306A\u2026\u2192\u4ED6\u306B\u3044\u3044\u3084\u308A\u65B9\u306F\u7121\u3044\u304B\u2026\u2192\uFF08\u4E2D\u7565\uFF09\u2192\u4FFA\u306F\u90E8\u5206\u7A4D\u5206\u306E\u9B3C\u306B\u306A\u308B\u2026\uFF01\u300D\u3068\u304B\u30DD\u30B9\u30C8\u3057\u3066\u305F\u4EBA\u3001\u305D\u308C\u4EE5\u6765Twitter\u3067\u898B\u3066\u306A\u3044\u306A",
    "id" : 87903174509346816,
    "created_at" : "2011-07-04 15:18:44 +0000",
    "user" : {
      "name" : "\u304F\u307E\u30FC",
      "screen_name" : "p_kumaaa",
      "protected" : false,
      "id_str" : "131824731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596198649287159808\/Fb4yldFB_normal.png",
      "id" : 131824731,
      "verified" : false
    }
  },
  "id" : 87905251914547200,
  "created_at" : "2011-07-04 15:26:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87902720828252160",
  "text" : "\u3084\u308A\u304B\u306D\u306A\u3044\u4EBA\u9593\u304C\u96C6\u307E\u3063\u3066\u307E\u3059\u3088\u3045\u30FB\u30FB\u30FB",
  "id" : 87902720828252160,
  "created_at" : "2011-07-04 15:16:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30C3\u30AD\u30FC\uFF08\u795E\u30BF\u30A4\u30D7\uFF09",
      "screen_name" : "m_naru",
      "indices" : [ 3, 10 ],
      "id_str" : "131528063",
      "id" : 131528063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87902620357894145",
  "text" : "RT @m_naru: \u4EAC\u5927\u306E\u300C\u30D7\u30FC\u30EB\u4F7F\u7528\u5FC3\u5F97\u300D\u306B\u201D\u5FC5\u305A\u3001\u6C34\u6CF3\u5E3D\u3092\u7740\u7528\u3059\u308B\u3053\u3068\u3002\u201D\u3063\u3066\u3042\u308B\u3093\u3060\u3051\u3069\u3001\u8863\u985E\u306E\u7740\u7528\u306B\u3064\u3044\u3066\u306F\u4F55\u3082\u66F8\u3044\u3066\u306A\u3044\u3002\u3063\u3066\u3053\u3068\u306F\u8AB0\u3082\u3044\u306A\u304B\u3063\u305F\u3089\u5168\u88F8\u306B\u6C34\u6CF3\u5E3D\u3067\u6CF3\u3052\u308B\u30FB\u30FB\u30FB\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87888217096978432",
    "text" : "\u4EAC\u5927\u306E\u300C\u30D7\u30FC\u30EB\u4F7F\u7528\u5FC3\u5F97\u300D\u306B\u201D\u5FC5\u305A\u3001\u6C34\u6CF3\u5E3D\u3092\u7740\u7528\u3059\u308B\u3053\u3068\u3002\u201D\u3063\u3066\u3042\u308B\u3093\u3060\u3051\u3069\u3001\u8863\u985E\u306E\u7740\u7528\u306B\u3064\u3044\u3066\u306F\u4F55\u3082\u66F8\u3044\u3066\u306A\u3044\u3002\u3063\u3066\u3053\u3068\u306F\u8AB0\u3082\u3044\u306A\u304B\u3063\u305F\u3089\u5168\u88F8\u306B\u6C34\u6CF3\u5E3D\u3067\u6CF3\u3052\u308B\u30FB\u30FB\u30FB\uFF01\uFF01",
    "id" : 87888217096978432,
    "created_at" : "2011-07-04 14:19:18 +0000",
    "user" : {
      "name" : "\u30DF\u30C3\u30AD\u30FC\uFF08\u795E\u30BF\u30A4\u30D7\uFF09",
      "screen_name" : "m_naru",
      "protected" : true,
      "id_str" : "131528063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534697756917383169\/nz6PEM9A_normal.jpeg",
      "id" : 131528063,
      "verified" : false
    }
  },
  "id" : 87902620357894145,
  "created_at" : "2011-07-04 15:16:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87902362970234880",
  "geo" : { },
  "id_str" : "87902534810877954",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u4E8C\u500B\u958B\u3051\u3066\u4E00\u500B\u9589\u3058\u3066\u30FB\u30FB\u30FB\u3067\u3082\u30C0\u30E1\u304B\u3002",
  "id" : 87902534810877954,
  "in_reply_to_status_id" : 87902362970234880,
  "created_at" : "2011-07-04 15:16:12 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87902411309580288",
  "text" : "\uFF33\uFF41\uFF45\uFF5A\uFF55\uFF52\uFF49\u3063\u3066\u30D6\u30ED\u30C3\u30AF\u3067\u304D\u308B\u306E\uFF1F",
  "id" : 87902411309580288,
  "created_at" : "2011-07-04 15:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87901929434398720",
  "text" : "\u4F55\u3060\u3053\u306E\u8EAB\u9577\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u30FB\u30FB\u30FB\u4EBA\u9593\u306E\u8EAB\u9577\u306A\u3093\u3066\u30B9\u30AB\u30A4\u30C4\u30EA\u30FC\u304B\u3089\u898B\u305F\u3089\u8AA4\u5DEE\u3060\u308D\u3002\u541B\u305F\u3061\u4EBA\u9593\u306F\u3044\u3064\u3082\u305D\u3046\u3060\u306D\u3002\u8A33\u304C\u5206\u304B\u3089\u306A\u3044\u3088\u3002",
  "id" : 87901929434398720,
  "created_at" : "2011-07-04 15:13:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87886602495467520",
  "text" : "\u5E30\u5B85\u3000\u8352\u3076\u308B\u30C4\u30A4\u30C3\u30BF\u30FC\u30BF\u30A4\u30E0\u3082\u3053\u308C\u3067\u4E00\u4ED5\u4E8B\u304A\u3057\u307E\u3044",
  "id" : 87886602495467520,
  "created_at" : "2011-07-04 14:12:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 18, 29 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 39, 49 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 61, 72 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87881316913250305",
  "text" : "\u84B8\u3068\u71D5\u3063\u3066\u4F3C\u3066\u308B\u3088\u306D\u3001\u3046\u3093\u3002 RT @magokoro84: \u3069\u3086\u3053\u3068\uFF1FRT @end313124: \u71D5\u6691\u304F\u306A\u3044\u304B RT @magokoro84: \u96E8\u304C\u964D\u3063\u3066\u308B\u304B\u3089\u51B7\u623F\u5165\u308C\u306A\u304F\u3066\u3082\u3084\u3063\u3066\u3044\u3051\u308B",
  "id" : 87881316913250305,
  "created_at" : "2011-07-04 13:51:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87881160759316481",
  "text" : "\u89E3\u8131\n\n\u3058\u3083\u306A\u304F\u3066\u96E2\u8131",
  "id" : 87881160759316481,
  "created_at" : "2011-07-04 13:51:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 10, 21 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87880392731930625",
  "text" : "\u71D5\u6691\u304F\u306A\u3044\u304B RT @magokoro84: \u96E8\u304C\u964D\u3063\u3066\u308B\u304B\u3089\u51B7\u623F\u5165\u308C\u306A\u304F\u3066\u3082\u3084\u3063\u3066\u3044\u3051\u308B",
  "id" : 87880392731930625,
  "created_at" : "2011-07-04 13:48:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87880319402901504",
  "text" : "RT @magokoro84: \u96E8\u304C\u964D\u3063\u3066\u308B\u304B\u3089\u51B7\u623F\u5165\u308C\u306A\u304F\u3066\u3082\u3084\u3063\u3066\u3044\u3051\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87880151316172800",
    "text" : "\u96E8\u304C\u964D\u3063\u3066\u308B\u304B\u3089\u51B7\u623F\u5165\u308C\u306A\u304F\u3066\u3082\u3084\u3063\u3066\u3044\u3051\u308B",
    "id" : 87880151316172800,
    "created_at" : "2011-07-04 13:47:15 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 87880319402901504,
  "created_at" : "2011-07-04 13:47:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87879976950566912",
  "text" : "\u96FB\u6C60\u304C\u2026",
  "id" : 87879976950566912,
  "created_at" : "2011-07-04 13:46:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87879751057936384",
  "text" : "\u6570\u5B66\u5973\u5B50\u8AAD\u3093\u3067\u304B\u3089\u968F\u6240\u306B\u30AB\u30A8\u30B5\u30EB\u6697\u53F7\u3092\u66F8\u304F\u7FD2\u6163\u304C\u2026",
  "id" : 87879751057936384,
  "created_at" : "2011-07-04 13:45:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 13, 20 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87879530995384320",
  "text" : "\u753B\u671F\u7684\u3059\u3050\u308B\uFF57\uFF57\uFF57 RT @khulud: \u3055\u3063\u304D\u306E 8 \u9032\u6CD5\u304C\u3082\u3057\u81EA\u7531\u81EA\u5728\u306B\u3067\u304D\u308C\u3070\u4EBA\u9593\u306F\u7247\u624B\u306E\u6307\u3060\u3051\u3067 16 383 (= 2^14 - 1) \u307E\u3067\u6570\u3048\u3089\u308C\u308B\u3053\u3068\u306B\u306A\u308B\u305E\uFF0E\u89AA\u6307\u3060\u3051\u95A2\u7BC0 2 \u3064\u3057\u304B\u306A\u3044\u304B\u3089 14 \u4E57\u306B\u306A\u3063\u3066\u308B\uFF0E",
  "id" : 87879530995384320,
  "created_at" : "2011-07-04 13:44:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87879131357904896",
  "text" : "\u98DB\u3073\u8DF3\u306D\u308B\u9CF6\u306F\u5BDD\u308B\u3002\u3068\u308A\u3068\u3081\u306E\u306A\u3044\u30C4\u30A4\u30FC\u30C8\u306A\u304B\u306B\u9CE5\u3068\u3044\u3046\u30C6\u30FC\u30DE\u304C\uFF01",
  "id" : 87879131357904896,
  "created_at" : "2011-07-04 13:43:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87878839518236675",
  "text" : "\u884C\u304D\u8A70\u307E\u308A\u606F\u8A70\u307E\u308B\u3002\u6C34\u4E2D\u8FF7\u8DEF\uFF1F",
  "id" : 87878839518236675,
  "created_at" : "2011-07-04 13:42:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87878637252132864",
  "text" : "\u3068\u308A\u3068\u3081\u306E\u306A\u3055\u3067\u4E00\u547D\u3092\u3068\u308A\u3068\u3081\u308B\u3002\u9DF9\u5320\u306F\u80A9\u306B\u9CE5\u6B62\u3081\u308B\u3002",
  "id" : 87878637252132864,
  "created_at" : "2011-07-04 13:41:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87878228106158080",
  "text" : "\u3084\u304F\u307F\u3064\u308B\u2192\u5F79\u6E80\u3064\u308B\u2192\u5F79\u6E80\u306E\u601D\u8003\u56DE\u8DEF",
  "id" : 87878228106158080,
  "created_at" : "2011-07-04 13:39:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87877884412313600",
  "text" : "\u30C6\u30C8\u30E9\u3061\u3083\u3093\u306F\u5929\u7136\u3060\u304B\u3089\u3044\u3044\u306E\u3067\u306F\u306A\u3044\u304B\u3002\u3002\u3002",
  "id" : 87877884412313600,
  "created_at" : "2011-07-04 13:38:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87877693416284161",
  "text" : "\u5929\u7136\u3063\u3066\u76EE\u6307\u3057\u305F\u3089\u3082\u3046\u990A\u6B96\u3060\u3088\u306A\u3041",
  "id" : 87877693416284161,
  "created_at" : "2011-07-04 13:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87877397042569216",
  "geo" : { },
  "id_str" : "87877587900174336",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u53CC\u5B50\u304C\u3075\u3068\u6D6E\u304B\u3093\u3060\u3093\u3060\u3002\u305D\u308C\u3060\u3051\u3002",
  "id" : 87877587900174336,
  "in_reply_to_status_id" : 87877397042569216,
  "created_at" : "2011-07-04 13:37:04 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87877418701959168",
  "text" : "\u7D50\u57CE\u5148\u751F\u2026",
  "id" : 87877418701959168,
  "created_at" : "2011-07-04 13:36:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87877356546572288",
  "text" : "RT @hyuki: \u307F\u3093\u306A\u30FC\uFF01\u30C6\u30C8\u30E9\u306E\u3055\u3093\u3059\u3046\u6559\u5BA4\u306F\u3058\u307E\u308B\u3088\u30FC\uFF01 \u3042\u305F\u3057\u307F\u305F\u3044\u306A\u5929\u7136\u3081\u3056\u3057\u3066\u2026\n#mathgirl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mathgirl",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87877274183016449",
    "text" : "\u307F\u3093\u306A\u30FC\uFF01\u30C6\u30C8\u30E9\u306E\u3055\u3093\u3059\u3046\u6559\u5BA4\u306F\u3058\u307E\u308B\u3088\u30FC\uFF01 \u3042\u305F\u3057\u307F\u305F\u3044\u306A\u5929\u7136\u3081\u3056\u3057\u3066\u2026\n#mathgirl",
    "id" : 87877274183016449,
    "created_at" : "2011-07-04 13:35:49 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 87877356546572288,
  "created_at" : "2011-07-04 13:36:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87877244105662464",
  "text" : "\u6E96\u6025\u304B\u3002\u4ECA\u65E5\u306F\u96FB\u8ECA\u306E\u30C4\u30E2\u304C\u51B4\u3048\u3066\u308B\u306A\u3002",
  "id" : 87877244105662464,
  "created_at" : "2011-07-04 13:35:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87876662225670144",
  "geo" : { },
  "id_str" : "87877004099190784",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u51FA\u6765\u305F\u3089\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u8CDE\u3082\u306E\u3067\u3059\u306D\uFF01",
  "id" : 87877004099190784,
  "in_reply_to_status_id" : 87876662225670144,
  "created_at" : "2011-07-04 13:34:45 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87876738306150400",
  "text" : "\u30AA\u30FC\u30DE\u30A4\u30AD\u30FC\u77E5\u3063\u3066\u308B\u4EBA\u3044\u308B\u304B\u306A\u2026",
  "id" : 87876738306150400,
  "created_at" : "2011-07-04 13:33:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87876003338260483",
  "geo" : { },
  "id_str" : "87876164118519809",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30B5\u30F3\u30AF\u30B9\uFF01",
  "id" : 87876164118519809,
  "in_reply_to_status_id" : 87876003338260483,
  "created_at" : "2011-07-04 13:31:24 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87876070891720705",
  "text" : "\uFF12^63\u3063\u3066\u3059\u3052\u3047\u6570\u3048\u3089\u308C\u308B\u306A\uFF57\uFF57\uFF57",
  "id" : 87876070891720705,
  "created_at" : "2011-07-04 13:31:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87875886799536128",
  "text" : "\u3042\u3063\u3068\u3044\u3046\u307E\u306B12\uFF05\u3060\u304C\u6771\u798F\u5BFA",
  "id" : 87875886799536128,
  "created_at" : "2011-07-04 13:30:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87875411987529728",
  "geo" : { },
  "id_str" : "87875700643741696",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u30D2\u30F3\u30C8.\u4E8C\u9032\u6570\u8868\u73FE",
  "id" : 87875700643741696,
  "in_reply_to_status_id" : 87875411987529728,
  "created_at" : "2011-07-04 13:29:34 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87875065156354048",
  "geo" : { },
  "id_str" : "87875458049392640",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u4ED6\u4EBA\u306E\uFF34\uFF2C\u3092\u4E0B\u3089\u306A\u3044\u30C4\u30A4\u30FC\u30C8\u3067\u57CB\u3081\u5C3D\u304F\u3059\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u30B9\u30DD\u30FC\u30C4\n\u3044\u3084\u3001\u60AA\u610F\u3082\u4F5C\u70BA\u3082\u306A\u3044\u3060\u3051\u3069\u3055",
  "id" : 87875458049392640,
  "in_reply_to_status_id" : 87875065156354048,
  "created_at" : "2011-07-04 13:28:36 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87875097741897728",
  "text" : "\u3068\u3046\u3082\u3053\u308D\u3057\u3092\u4E45\u3057\u304F\u98DF\u3079\u3066\u306A\u3044\u6C17\u304C\u3059\u308B\u3002",
  "id" : 87875097741897728,
  "created_at" : "2011-07-04 13:27:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87874877264117761",
  "text" : "\u306F\u3054\u308D\u3082\u30D5\u30FC\u30BA\u3063\u3066\u306A\u3093\u306E\u4F1A\u793E\u3060\u3063\u3051\uFF1F\u7F36\u8A70\u306E\u30B3\u30FC\u30F3\u306E\u30A4\u30E1\u30FC\u30B8",
  "id" : 87874877264117761,
  "created_at" : "2011-07-04 13:26:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87874622015537152",
  "text" : "\u3053\u306E\u4E0B\u3089\u306A\u3044\u30C4\u30A4\u30FC\u30C8\u3060\u308C\u306E\uFF1Fwhose trivial tweet is this\uFF1F",
  "id" : 87874622015537152,
  "created_at" : "2011-07-04 13:25:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87874228296220673",
  "text" : "\u30D4\u30FC\u30C1\u30C4\u30EA\u30FC\u306F\u30D5\u30A3\u30BA\u304B\u3002",
  "id" : 87874228296220673,
  "created_at" : "2011-07-04 13:23:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87874059962023936",
  "text" : "\u8EAB\u306B\u899A\u3048\u304C\u3042\u308B\u306F\u305A\u3002\n\n\u30D5\u30A1\u30BA\u3063\u3066\u30A8\u30D5\u30A7\u30AF\u30BF\u30FC\u3060\u3063\u3051\uFF1F",
  "id" : 87874059962023936,
  "created_at" : "2011-07-04 13:23:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87873884329750528",
  "text" : "\u3068\u306F\u3044\u3048Kernel\u304C\u4F55\u3060\u3063\u305F\u306E\"\u304B\u304F\"\u308F\u3057\u304F\u899A\u3048\u3066\u306A\u3044\u2026\u30C6\u30B9\u30C8\u671F\u9593\u306E\u7121\u95A2\u4FC2\u306E\u79D1\u76EE\u306E\u610F\u8B58\u306E\u9AD8\u307E\u308A\u306F\u7570\u5E38\u3002",
  "id" : 87873884329750528,
  "created_at" : "2011-07-04 13:22:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87873495844929536",
  "text" : "\u305F\u3060\u533A\u9593\u5FEB\u901F\u306B\u4E57\u308C\u305F\u304B\u3089\u79FB\u52D5\u3082\u65E9\u3044\u306F\u305A",
  "id" : 87873495844929536,
  "created_at" : "2011-07-04 13:20:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87873246262861824",
  "text" : "\u96FB\u6C60\u304C\u5207\u308C\u308B\u307E\u3067\u3060\u3051\u3069\u306D\u30FC\u3002\u4ECA\uFF12\uFF11\uFF05",
  "id" : 87873246262861824,
  "created_at" : "2011-07-04 13:19:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87873080294252544",
  "text" : "\u77E5\u308A\u5408\u3044\u5897\u3048\u3066\u6765\u305F\u3051\u3069\u6C17\u306B\u3057\u306A\u3044\u3067\u4E0B\u3089\u306A\u3044\u3053\u3068\u545F\u304F\u305E\u30FC",
  "id" : 87873080294252544,
  "created_at" : "2011-07-04 13:19:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87872786269339648",
  "text" : "\u8352\u3076\u308B\u30C4\u30A4\u30C3\u30BF\u30FC\u30BF\u30A4\u30E0\uFF6F\uFF01\uFF01",
  "id" : 87872786269339648,
  "created_at" : "2011-07-04 13:17:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87867847371538432",
  "text" : "\u82F1\u8A9E\u306E\u6388\u696D\u3067kernel\u51FA\u3066\u304D\u3066\u5973\u306E\u5B50\u304C\u8A33\u305B\u3066\u306A\u304F\u3066\u300C\u7DDA\u5F62\u3067\u3084\u3063\u305F\u3060\u308D\u300D\u3068\u601D\u3063\u305F\u3089\u6587\u5B66\u90E8\u82F1\u8A9E\u3060\u3063\u305Forz",
  "id" : 87867847371538432,
  "created_at" : "2011-07-04 12:58:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87782315052371968",
  "text" : "\u98A8\u304C\u751F\u6E29\u3044\u2026\u8352\u308C\u305D\u3046\u3002",
  "id" : 87782315052371968,
  "created_at" : "2011-07-04 07:18:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87782188371804160",
  "text" : "RT @galletti_bot: \u672C\u5F53\u306E\u30B7\u30EA\u30A2\u306F\u3061\u3083\u3093\u3068\u3057\u3066\u3044\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87782048563081216",
    "text" : "\u672C\u5F53\u306E\u30B7\u30EA\u30A2\u306F\u3061\u3083\u3093\u3068\u3057\u3066\u3044\u308B\u3002",
    "id" : 87782048563081216,
    "created_at" : "2011-07-04 07:17:25 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 87782188371804160,
  "created_at" : "2011-07-04 07:17:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87753471796846592",
  "text" : "\u5360\u3044\u306B\u76DB\u308A\u4E0A\u304C\u308B\u5973\u5B50\u5927\u751F\u2026\u5360\u3044\u306D\u3047\u2026",
  "id" : 87753471796846592,
  "created_at" : "2011-07-04 05:23:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87750941603930112",
  "text" : "\u71D5\u3057\u6691\u3044\u306D\u2026\u30E9\u30A6\u30F3\u30B8\u30AF\u30FC\u30E9\u30FC\u304D\u3044\u3066\u306A\u3044\u3002\u304B\u3068\u3044\u3063\u3066\u52B9\u304D\u904E\u304E\u3066\u308B\u3068\u305D\u308C\u306F\u305D\u308C\u3067\u4F53\u3092\u58CA\u3057\u305D\u3046\u3060\u304C\u3002",
  "id" : 87750941603930112,
  "created_at" : "2011-07-04 05:13:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87748284952756224",
  "text" : "\u6700\u5F8C\u306E\u3084\u3064\u597D\u304D\u3060\u306A\u2026",
  "id" : 87748284952756224,
  "created_at" : "2011-07-04 05:03:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "indices" : [ 3, 10 ],
      "id_str" : "15570902",
      "id" : 15570902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87748226131828736",
  "text" : "RT @m_soba: \u30FB\u5186\u5468\u7387\u306F3.14\u3060\u3088\u6D3E\uFF08\u4FDD\u5B88\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306F3.1415926535\u2026\u2026\u3060\u3088\u6D3E\uFF08\u539F\u7406\u4E3B\u7FA9\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306F\u304A\u3088\u305D3\u3060\u3088\u6D3E\uFF08\u6025\u9032\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306F\u3061\u3087\u3046\u30693\u3060\u3088\u6D3E\uFF08\u904E\u6FC0\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306Fexp(-x^2)\u3092\u4E21\u5074\u7121\u9650\u7A4D\u5206\u3057\u305F\u3082\u306E\u306E2\u4E57\u3060\u3088\u6D3E\uFF08\u4F55\u8A00\u3063 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"erased_102559\" rel=\"nofollow\"\u003Eerased_102559\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87515052478971904",
    "text" : "\u30FB\u5186\u5468\u7387\u306F3.14\u3060\u3088\u6D3E\uFF08\u4FDD\u5B88\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306F3.1415926535\u2026\u2026\u3060\u3088\u6D3E\uFF08\u539F\u7406\u4E3B\u7FA9\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306F\u304A\u3088\u305D3\u3060\u3088\u6D3E\uFF08\u6025\u9032\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306F\u3061\u3087\u3046\u30693\u3060\u3088\u6D3E\uFF08\u904E\u6FC0\u6D3E\uFF09\u3000\n\u30FB\u5186\u5468\u7387\u306Fexp(-x^2)\u3092\u4E21\u5074\u7121\u9650\u7A4D\u5206\u3057\u305F\u3082\u306E\u306E2\u4E57\u3060\u3088\u6D3E\uFF08\u4F55\u8A00\u3063\u3066\u308B\u304B\u5206\u304B\u3089\u3093\u3001\u5E30\u308C\uFF09",
    "id" : 87515052478971904,
    "created_at" : "2011-07-03 13:36:29 +0000",
    "user" : {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "protected" : false,
      "id_str" : "15570902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484672991460982784\/o-QnjXOh_normal.png",
      "id" : 15570902,
      "verified" : false
    }
  },
  "id" : 87748226131828736,
  "created_at" : "2011-07-04 05:03:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87747613520166912",
  "text" : "\u71D5\u3057\u6691\u3044\u2026",
  "id" : 87747613520166912,
  "created_at" : "2011-07-04 05:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87744235666812928",
  "geo" : { },
  "id_str" : "87744453086949376",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u52AA\u529B\u3057\u305F\uFF1F",
  "id" : 87744453086949376,
  "in_reply_to_status_id" : 87744235666812928,
  "created_at" : "2011-07-04 04:48:02 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87744091542130688",
  "text" : "\u80A9\u51DD\u308A\u982D\u75DB\u306E\u30B3\u30F3\u30DC\u304C\u6765\u305F\u305C\u2026\u306C\u308B\u308A\u3068\u2026",
  "id" : 87744091542130688,
  "created_at" : "2011-07-04 04:46:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87742988645703681",
  "geo" : { },
  "id_str" : "87743953960579074",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u304A\u524D\u2026",
  "id" : 87743953960579074,
  "in_reply_to_status_id" : 87742988645703681,
  "created_at" : "2011-07-04 04:46:03 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87742715755892736",
  "text" : "\u6C17\u3065\u304B\u306A\u304B\u3063\u305F\u308F\u30FC",
  "id" : 87742715755892736,
  "created_at" : "2011-07-04 04:41:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87742527406489600",
  "text" : "\u305D\u3046\u3044\u3084\uFF11\uFF16\u6B21\u5F0F\u306E\u5224\u5225\u5F0F\u306E\u30A2\u30EB\u30B4\u30EA\u30BA\u30E0\u306E\u6559\u6388\u304C\u30D7\u30ED\u30B0\u30E9\u30E0\u3092\u7FD2\u3063\u3066\u308B\u6559\u6388\u3060\u3063\u305F\u3002",
  "id" : 87742527406489600,
  "created_at" : "2011-07-04 04:40:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87739554232152065",
  "text" : "\u3042\u3001\u79F0\u306E\u5B57\u9593\u9055\u3063\u3066\u308B\u2026",
  "id" : 87739554232152065,
  "created_at" : "2011-07-04 04:28:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87739420417069056",
  "text" : "\u604B\u611B\u95A2\u4FC2\u306B\u5BFE\u8C61\u5F8B\u304C\u6210\u308A\u7ACB\u3066\u3070\u2026\u3063\u3066\u306A\u611F\u3058\u306E\u6B4C\u8A5E\u306E\u30DC\u30AB\u30ED\u66F2\u3092\u7D50\u57CE\u5148\u751F\u306E\u30C4\u30A4\u30FC\u30C8\u3067\u8074\u3044\u305F\u8A18\u61B6\u304C\u3042\u308B\u3051\u3069\u771F\u306B\u7406\u89E3\u3057\u305F",
  "id" : 87739420417069056,
  "created_at" : "2011-07-04 04:28:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87735469445611520",
  "text" : "\u6559\u6388\u304C\u8AD6\u6587\u5171\u8457\u3067\u66F8\u304F\u306A\u3089\u4FFA\u3089\u3082\u2026",
  "id" : 87735469445611520,
  "created_at" : "2011-07-04 04:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u697D\u3057\u3044\u4F8B\u6587",
      "screen_name" : "funfunreibun",
      "indices" : [ 48, 61 ],
      "id_str" : "103407158",
      "id" : 103407158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87735218336841728",
  "text" : "Let's write the report by turns.\u4EA4\u4EE3\u3067\u30EC\u30DD\u30FC\u30C8\u3092\u66F8\u3053\u3046  QT @funfunreibun: Let's row the boat by turns. \u4EA4\u4EE3\u3067\u30DC\u30FC\u30C8\u3092\u6F15\u3054\u3046\u3002",
  "id" : 87735218336841728,
  "created_at" : "2011-07-04 04:11:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87726450224021504",
  "text" : "\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u30B9\u30C8\u30EC\u30FC\u30C8\u30D1\u30FC\u30DE\uFF08\u521D\u671F\u88C5\u5099\uFF09",
  "id" : 87726450224021504,
  "created_at" : "2011-07-04 03:36:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87726213480722432",
  "text" : "\u304B\u3051\u305F\u306F\u305A\u306E\u30D1\u30FC\u30DE\u304C\u4E8C\u9031\u9593\u8DB3\u3089\u305A\u3067\u307B\u307C\u5143\u306B\u623B\u308B\u7A0B\u5EA6\u306E\u9006\u304F\u305B\u3063\u6BDB",
  "id" : 87726213480722432,
  "created_at" : "2011-07-04 03:35:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87725785842061312",
  "text" : "\uFF3B\u30D5\u30E9\u30AF\u30BF\u30EB\uFF3D\u3067\u691C\u7D22\u66F8\u3051\u308B\u3068\u3001\u30A2\u30CB\u30E1\u306E\u30D5\u30E9\u30AF\u30BF\u30EB\u304C\u51FA\u3066\u300C\u56F3\u5F62\u306E\u65B9\u306A\u3093\u3060\u3051\u3069\u306A\u300D\u3068\u601D\u3046\u4E00\u65B9\u3001\u30A2\u30CB\u30E1\u3082\u5ACC\u3044\u3058\u3083\u306A\u3044\u304B\u3089\u307E\u3041\u3044\u3044\u304B\u306A\u30FC\u3068\u601D\u3063\u3066\u898B\u3066\u308B\u3068\u4E0D\u4EBA\u6C17\u3092\u4F1D\u3048\u308B\u30D6\u30ED\u30B0\u3060\u3063\u305F\u308A\u3057\u3066\u6D6E\u304D\u6C88\u307F\u304C\u6FC0\u3057\u3044",
  "id" : 87725785842061312,
  "created_at" : "2011-07-04 03:33:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87723468870791168",
  "text" : "\u30D4\u30ED\u30B7\u30AD\u7F8E\u5473\u3057\u3044\u2026",
  "id" : 87723468870791168,
  "created_at" : "2011-07-04 03:24:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "101753216",
      "id" : 101753216
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 36, 46 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87723167749115904",
  "text" : "RT @factoring_bot: 313 is prime! RT @end313124: 313\u6708124\u65E5\u751F\u307E\u308C\uFF08\uFF77\uFF98\uFF6F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/prime.4403.biz\/factoring_bot\/\" rel=\"nofollow\"\u003Efactoring_bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 17, 27 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "87719549981564930",
    "geo" : { },
    "id_str" : "87720044854915072",
    "in_reply_to_user_id" : 155546700,
    "text" : "313 is prime! RT @end313124: 313\u6708124\u65E5\u751F\u307E\u308C\uFF08\uFF77\uFF98\uFF6F",
    "id" : 87720044854915072,
    "in_reply_to_status_id" : 87719549981564930,
    "created_at" : "2011-07-04 03:11:03 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "protected" : false,
      "id_str" : "101753216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727655584\/factan_normal.png",
      "id" : 101753216,
      "verified" : false
    }
  },
  "id" : 87723167749115904,
  "created_at" : "2011-07-04 03:23:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87719549981564930",
  "text" : "313\u6708124\u65E5\u751F\u307E\u308C\uFF08\uFF77\uFF98\uFF6F",
  "id" : 87719549981564930,
  "created_at" : "2011-07-04 03:09:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87678356107173888",
  "text" : "\u304A\u306F\u3088\u3046 \u304A\u306F\u3088\u3046",
  "id" : 87678356107173888,
  "created_at" : "2011-07-04 00:25:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87678280165105665",
  "text" : "\u8D77\u304D\u305F\u3002\u30DB\u30F3\u30C8\u306F\u8A08\u753B\u4E8C\u5EA6\u5BDD\u306A\u3093\u3060\u3051\u3069\u306D\u3002",
  "id" : 87678280165105665,
  "created_at" : "2011-07-04 00:25:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87584837497655296",
  "geo" : { },
  "id_str" : "87585768037560320",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3084\u3059\u307F",
  "id" : 87585768037560320,
  "in_reply_to_status_id" : 87584837497655296,
  "created_at" : "2011-07-03 18:17:29 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87568726601375745",
  "text" : "\u5DEE\u3068\u6BD4\u3092\u3054\u3063\u3061\u3083\u306B\u3057\u3061\u3083\u3044\u3051\u306A\u3044\u3088\u306D\u3002",
  "id" : 87568726601375745,
  "created_at" : "2011-07-03 17:09:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87568234856980480",
  "geo" : { },
  "id_str" : "87568625417986049",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3066\u304B\u4E16\u9593\u3067\uFF11\uFF10\u6B73\u5DEE\u306E\u592B\u5A66\u3068\u304B\u30B6\u30E9\u3060\u3088\u306A\u30FC\u3002\u3044\u307E\uFF11\uFF10\u6B73\u4E0B\u306F\u30E4\u30D0\u3044\u3060\u308D\u3046\u304C\u3001\u6642\u9593\u3068\u3068\u3082\u306B\u6BD4\u306F\uFF11\uFF1A\uFF11\u306B\u8FD1\u3065\u3044\u3066\u3044\u304F\u3088\u306D\u3002",
  "id" : 87568625417986049,
  "in_reply_to_status_id" : 87568234856980480,
  "created_at" : "2011-07-03 17:09:21 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87563178095017984",
  "text" : "@np2i \u3093\u30FC\u3002\u50D5\u3082\u8A9E\u5B66\u3084\u308A\u305F\u304F\u3066\u3063\u3066\u8A00\u3046\u3088\u308A\u3084\u3089\u3056\u308B\u3092\u5F97\u306A\u304F\u3066\u3084\u3063\u3066\u308B\u611F\u3058\u306B\u306A\u3063\u3066\u308B\u3093\u3067\u3001\u8CB7\u304A\u3046\u304B\u8FF7\u3063\u3061\u3083\u3044\u307E\u3059\u306D\u3002",
  "id" : 87563178095017984,
  "created_at" : "2011-07-03 16:47:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 17, 24 ],
      "id_str" : "239486216",
      "id" : 239486216
    }, {
      "name" : "\u629E\u4E00\u89E3\u3051BOT\uFF205\u53F7\uFF08\u30A4\u30A8\u30ED\u30FC\uFF09",
      "screen_name" : "do_takuitu5",
      "indices" : [ 38, 50 ],
      "id_str" : "282084010",
      "id" : 282084010
    }, {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 52, 59 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87556500498821121",
  "text" : "\u6B64\u308C\u306F\u5353\u8D8A\u3057\u305F\u30BB\u30F3\u30B9\u3067\u3059\u306D RT @khulud: \u3069\u3046\u3044\u3046\u3053\u3068\u3060\u3088\uFF0ERT @do_takuitu5: @khulud \u629E\u4E00\u3068\u9000\u5C48\u3063\u3066\u4F3C\u3066\u308B\u3088\u306D",
  "id" : 87556500498821121,
  "created_at" : "2011-07-03 16:21:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87556377073025024",
  "text" : "\u3053\u306E\u6642\u9593\u3063\u3066\u304A\u8179\u6E1B\u308B\u3088\u306A\u30FC\u3002",
  "id" : 87556377073025024,
  "created_at" : "2011-07-03 16:20:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87553714029723650",
  "text" : "\u539F\u30C1\u30E3\u65B0\u54C1\u8CB7\u3046\u3063\u3066\u306E\u3082\u6709\u308A\u306A\u3093\u3060\u3088\u306A\u2026\u3002",
  "id" : 87553714029723650,
  "created_at" : "2011-07-03 16:10:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87541896045535232",
  "text" : "\u30B9\u30DE\u30DB\u30E6\u30FC\u30B6\u30FC\u3067\u8F9E\u66F8\u4F7F\u3044\u52DD\u624B\u306E\u3044\u3044\u3084\u3064\u3042\u308B\u3063\u3066\u4EBA\u3044\u305F\u3089\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u306A",
  "id" : 87541896045535232,
  "created_at" : "2011-07-03 15:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87541344473591808",
  "text" : "\u82F1\u8A9E\u306E\u306F\u5B9F\u5BB6\u306B\u3042\u308B\u304C\uFF08\u5F1F\u306B\u3042\u3052\u305F\uFF09\u30D5\u30E9\u30F3\u30B9\u8A9E\u306F\u306A\u3041\u2026\u3002\u30B9\u30DE\u30DB\u306E\u30A2\u30D7\u30EA\u3068\u304B\u3067\u3042\u308B\u306A\u3089\u30B9\u30DE\u30DB\u306B\u5909\u3048\u308B\u306E\u3082\u3042\u308A\u3060\u306A\u30FC\u3002",
  "id" : 87541344473591808,
  "created_at" : "2011-07-03 15:20:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87541003673804800",
  "text" : "\u899A\u3048\u304C\u60AA\u3044\u304B\u3089\u304A\u3093\u306A\u3058\u5358\u8A9E\u4F55\u56DE\u3082\u5F15\u3044\u3061\u3083\u3046\u3057\u5C65\u6B74\u898B\u308C\u305F\u308A\u6210\u53E5\u3084\u3089\u4F8B\u6587\u3084\u3089\u306E\u691C\u7D22\u3067\u304D\u305F\u308A\u3059\u308B\u306E\u306F\u5F37\u3044\u3088\u306A\u30FC\u96FB\u5B50\u8F9E\u66F8\u3002",
  "id" : 87541003673804800,
  "created_at" : "2011-07-03 15:19:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87540779928649728",
  "text" : "\u96FB\u5B50\u8F9E\u66F8\u2026\u30DB\u30F3\u30C8\u306B\u8981\u308B\u306E\u304B\u306A\u3002\u7D19\u8F9E\u66F8\u306F\u3042\u308B\u3051\u3069\u91CD\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u82F1\u8A9E\u306F\u7D19\u3067\u3082\u3044\u3044\u3093\u3060\u3051\u3069\uFF08\u89E3\u3093\u306A\u3044\u5358\u8A9E\u306E\u51FA\u73FE\u983B\u5EA6\u304C\u305D\u3053\u307E\u3067\u9AD8\u304F\u306A\u3044\uFF09\u30D5\u30E9\u30F3\u30B9\u8A9E\u306F\u6CA2\u5C71\u305F\u304F\u3055\u3093\u8ABF\u3079\u306A\u3044\u3068\u3060\u3057\u82E6\u75DB\u30FB\u30FB\u30FB",
  "id" : 87540779928649728,
  "created_at" : "2011-07-03 15:18:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87540343083507713",
  "text" : "\u6D6A\u6F2B\u3082\u3042\u3053\u304C\u308C\u3082\u7279\u306B\u306A\u3044\u304B\u3089\u4E57\u308C\u308C\u3070\u3044\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u4E2D\u53E4\u3067\u5168\u7136\u304A\uFF4B",
  "id" : 87540343083507713,
  "created_at" : "2011-07-03 15:16:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87540218412007424",
  "text" : "\u539F\u30C1\u30E3\u3068\u30B9\u30AF\u30FC\u30BF\u30FC\u3063\u3066\u3069\u3046\u9055\u3046\u306E\uFF1F",
  "id" : 87540218412007424,
  "created_at" : "2011-07-03 15:16:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87539867516551168",
  "text" : "\u539F\u30C1\u30E3\u3068\u96FB\u5B50\u8F9E\u66F8\u2026\u512A\u5148\u3059\u3079\u304D\u306F\u3069\u3063\u3061\u3060\u308D\u2026\uFF1F",
  "id" : 87539867516551168,
  "created_at" : "2011-07-03 15:15:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87490876108058624",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 87490876108058624,
  "created_at" : "2011-07-03 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87415888030085120",
  "text" : "17\u6642\u2026\u3044\u3084\u300116\u664230\u5206\u304B\u3089\u672C\u6C17\u51FA\u3059\uFF01\u2026\u3044\u3084\u3001\u51FA\u3055\u306A\u3044\u3068\u307E\u305A\u3044\u3002",
  "id" : 87415888030085120,
  "created_at" : "2011-07-03 07:02:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E5\u30A5\u3079\u3048",
      "screen_name" : "QB0",
      "indices" : [ 3, 7 ],
      "id_str" : "248096715",
      "id" : 248096715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87415610958553088",
  "text" : "RT @QB0: \u307E\u305F\u3069\u3053\u304B\u306E\u5927\u5B66\u751F\u304C\u66B4\u6319\u306B\u51FA\u305F\u307F\u305F\u3044\u3060\u306D\u3002\u30CE\u30EA\u3067\u59CB\u307E\u308A\u3001\u708E\u4E0A\u3067\u7D42\u308F\u308B\u3002\u3053\u308C\u307E\u3067\u3001\u6570\u591A\u306E\u30CD\u30C3\u30C8\u30E6\u30FC\u30B6\u30FC\u305F\u3061\u304C\u7E70\u308A\u8FD4\u3057\u3066\u304D\u305F\u30B5\u30A4\u30AF\u30EB\u3060\u3002\u4E2D\u306B\u306F\u3001\u5927\u304D\u306A\u554F\u984C\u3092\u8D77\u3053\u3057\u3066\u3001\u4E8B\u614B\u3092\u65B0\u3057\u3044\u30B9\u30C6\u30FC\u30B8\u3078\u3068\u5C0E\u3044\u305F\u5B50\u3082\u3044\u305F\u3002\u5F7C\u3089\u3092\u88CF\u5207\u3063\u305F\u306E\u306F\u30CD\u30C3\u30C8\u3067\u306F\u306A\u304F\u3001\u5BE7\u308D\u81EA\u5206\u81EA\u8EAB\u306E\u7948\u308A\u3060\u3088\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87404875033485312",
    "text" : "\u307E\u305F\u3069\u3053\u304B\u306E\u5927\u5B66\u751F\u304C\u66B4\u6319\u306B\u51FA\u305F\u307F\u305F\u3044\u3060\u306D\u3002\u30CE\u30EA\u3067\u59CB\u307E\u308A\u3001\u708E\u4E0A\u3067\u7D42\u308F\u308B\u3002\u3053\u308C\u307E\u3067\u3001\u6570\u591A\u306E\u30CD\u30C3\u30C8\u30E6\u30FC\u30B6\u30FC\u305F\u3061\u304C\u7E70\u308A\u8FD4\u3057\u3066\u304D\u305F\u30B5\u30A4\u30AF\u30EB\u3060\u3002\u4E2D\u306B\u306F\u3001\u5927\u304D\u306A\u554F\u984C\u3092\u8D77\u3053\u3057\u3066\u3001\u4E8B\u614B\u3092\u65B0\u3057\u3044\u30B9\u30C6\u30FC\u30B8\u3078\u3068\u5C0E\u3044\u305F\u5B50\u3082\u3044\u305F\u3002\u5F7C\u3089\u3092\u88CF\u5207\u3063\u305F\u306E\u306F\u30CD\u30C3\u30C8\u3067\u306F\u306A\u304F\u3001\u5BE7\u308D\u81EA\u5206\u81EA\u8EAB\u306E\u7948\u308A\u3060\u3088\u3002",
    "id" : 87404875033485312,
    "created_at" : "2011-07-03 06:18:40 +0000",
    "user" : {
      "name" : "\u30AD\u30E5\u30A5\u3079\u3048",
      "screen_name" : "QB0",
      "protected" : false,
      "id_str" : "248096715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3461010832\/aa1e7cc0e019ebf811a62eab36e1683e_normal.jpeg",
      "id" : 248096715,
      "verified" : false
    }
  },
  "id" : 87415610958553088,
  "created_at" : "2011-07-03 07:01:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3089\u308A\u3093",
      "screen_name" : "1219hr",
      "indices" : [ 3, 10 ],
      "id_str" : "230451926",
      "id" : 230451926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87415504079290368",
  "text" : "RT @1219hr: \u6C34\u66DC\u3069\u3046\u3067\u3057\u3087\u3046 \u2192 \u6728\u66DC\u306A\u3089\u3044\u3044\u3067\u3057\u3087\u3046\uFF1F \u2192 \u91D1\u66DC\u306A\u3089\u591C\u306F\u7A7A\u3044\u3066\u308B\u3067\u3057\u3087\u3046\uFF1F \u2192 \u571F\u66DC\u306F\u4F11\u307F\u3067\u3057\u3087\u3046\uFF1F \u2192 \u65E5\u66DC\u3082\u3069\u3046\u305B\u65AD\u308B\u3093\u3067\u3057\u3087\u3046\uFF1F \u2192 \u6708\u66DC\u306A\u3093\u3066\u4F1A\u3063\u3066\u304F\u308C\u306A\u3044\u3067\u3057\u3087\u3046\uFF1F \u2192 \u706B\u66DC\u30B5\u30B9\u30DA\u30F3\u30B9\u5287\u5834",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87170337137111041",
    "text" : "\u6C34\u66DC\u3069\u3046\u3067\u3057\u3087\u3046 \u2192 \u6728\u66DC\u306A\u3089\u3044\u3044\u3067\u3057\u3087\u3046\uFF1F \u2192 \u91D1\u66DC\u306A\u3089\u591C\u306F\u7A7A\u3044\u3066\u308B\u3067\u3057\u3087\u3046\uFF1F \u2192 \u571F\u66DC\u306F\u4F11\u307F\u3067\u3057\u3087\u3046\uFF1F \u2192 \u65E5\u66DC\u3082\u3069\u3046\u305B\u65AD\u308B\u3093\u3067\u3057\u3087\u3046\uFF1F \u2192 \u6708\u66DC\u306A\u3093\u3066\u4F1A\u3063\u3066\u304F\u308C\u306A\u3044\u3067\u3057\u3087\u3046\uFF1F \u2192 \u706B\u66DC\u30B5\u30B9\u30DA\u30F3\u30B9\u5287\u5834",
    "id" : 87170337137111041,
    "created_at" : "2011-07-02 14:46:42 +0000",
    "user" : {
      "name" : "\u3072\u3089\u308A\u3093",
      "screen_name" : "1219hr",
      "protected" : false,
      "id_str" : "230451926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3338177657\/86bbec123485771bf7849bc3698752cb_normal.png",
      "id" : 230451926,
      "verified" : false
    }
  },
  "id" : 87415504079290368,
  "created_at" : "2011-07-03 07:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87401447318237185",
  "text" : "\u8D77\u304D\u305F\u3002\u304A\u306F\u3088\u3046\uFF08\uFF1F\uFF09",
  "id" : 87401447318237185,
  "created_at" : "2011-07-03 06:05:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87293326692319232",
  "text" : "15\u6642\u306B\u306F\u8D77\u304D\u308B\u3001\u4E88\u5B9A",
  "id" : 87293326692319232,
  "created_at" : "2011-07-02 22:55:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87293204046688256",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044 \u8D77\u304D\u305F\u3089\u8AB2\u984C\u30E9\u30C3\u30B7\u30E5\uFF6A\u2026\uFF08\u8A9E\u5B66\uFF09",
  "id" : 87293204046688256,
  "created_at" : "2011-07-02 22:54:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87293042666647552",
  "text" : "\u548C\u4E86\u3063\u305F\u306E\u306F\u8AB0\u304B\u306A\uFF1F\n\u2026\u79C1\u3060\u3041\uFF01",
  "id" : 87293042666647552,
  "created_at" : "2011-07-02 22:54:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87292879168483328",
  "text" : "\u6628\u591C\u306E\u7406\u4E0D\u5C3D\u548C\u4E86\u308ANo\uFF11\u306F\u30EA\u30FC\u30C1\uFF08\u4E8C\u9806\u76EE\uFF09\u81EA\u6478\u3001\u8868\u30C9\u30E9\uFF13\uFF087m\uFF09\u3001\u88CF\u30C9\u30E9\uFF13\uFF082p\uFF09\u306E\u500D\u6E80\u3067\u3057\u305F\u3002",
  "id" : 87292879168483328,
  "created_at" : "2011-07-02 22:53:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 8, 19 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 20, 29 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87289546789756928",
  "geo" : { },
  "id_str" : "87292355731918849",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud @magokoro84 @nisehorn \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 87292355731918849,
  "in_reply_to_status_id" : 87289546789756928,
  "created_at" : "2011-07-02 22:51:34 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87289417282224128",
  "text" : "\u30DE\u30C3\u30C4\u306A\u3046",
  "id" : 87289417282224128,
  "created_at" : "2011-07-02 22:39:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87128473520451584",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 87128473520451584,
  "created_at" : "2011-07-02 12:00:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86846157472542720",
  "text" : "\u5BDD\u308B\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 86846157472542720,
  "created_at" : "2011-07-01 17:18:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86796402990120960",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u30D5\u30A9\u30ED\u30FC\u3057\u307E\u3057\u305F\u30FC\u3002\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059\u3002",
  "id" : 86796402990120960,
  "created_at" : "2011-07-01 14:00:49 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keigo Ishida",
      "screen_name" : "shombory",
      "indices" : [ 0, 9 ],
      "id_str" : "211441184",
      "id" : 211441184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86755423767642112",
  "geo" : { },
  "id_str" : "86796146143526912",
  "in_reply_to_user_id" : 211441184,
  "text" : "@shombory \u4E86\u89E3\u30FC\u9762\u5B50\u96C6\u307E\u3089\u305A\u6D41\u5C40\u3067\u3057\u305F\u30FC\u3002",
  "id" : 86796146143526912,
  "in_reply_to_status_id" : 86755423767642112,
  "created_at" : "2011-07-01 13:59:48 +0000",
  "in_reply_to_screen_name" : "shombory",
  "in_reply_to_user_id_str" : "211441184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86795465508659201",
  "text" : "\u3093\uFF1F\u3082\u306E\u306E\u3051\u59EB\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306A\u306E\uFF1F\u305F\u3060\u3044\u307E\u3002",
  "id" : 86795465508659201,
  "created_at" : "2011-07-01 13:57:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86684005856051200",
  "text" : "\u96E2\u8131",
  "id" : 86684005856051200,
  "created_at" : "2011-07-01 06:34:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86683951883755520",
  "text" : "\u666E\u6BB5\u306A\u3089\u8A00\u3046\u3092\u3086\u3046\u3068\u304B\u66F8\u3044\u3061\u3083\u3046\u4EBA\u306F\u30A2\u30EC\u3060\u3068\u601D\u3046\u3051\u3069\u3002\u3053\u3046\u3044\u3046\u6642\u3060\u3051\u306F\u3042\u308A\u3060\u3068\u4FE1\u3058\u3066\u3044\u308B\u3002",
  "id" : 86683951883755520,
  "created_at" : "2011-07-01 06:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86683740025257985",
  "text" : "\u3053\u3046\u3086\u3046\u6642\u306B\u4EA4\u53CB\u306E\u72ED\u3055\u3092\u75DB\u611F\u3059\u308B\u3002",
  "id" : 86683740025257985,
  "created_at" : "2011-07-01 06:33:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86683573997932544",
  "text" : "\u4ECA\u6669\u306E\u9EBB\u96C0\u306F\u9762\u5B50\u304C\u4E00\u4EBA\u96C6\u307E\u3089\u306A\u3055\u305D\u3046\u3002\u4E09\u9EBB\u3060\u3063\u305F\u3089\u3084\u3089\u306A\u3044\u65B9\u5411\u304B\u306A\u30FB\u30FB\u30FB\u3002",
  "id" : 86683573997932544,
  "created_at" : "2011-07-01 06:32:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5982\u6708\u30C4\u30F4\u30A1\u30F0\uFF0Aship4",
      "screen_name" : "ZWEIGNW002",
      "indices" : [ 3, 14 ],
      "id_str" : "105485964",
      "id" : 105485964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86643372927881217",
  "text" : "RT @ZWEIGNW002: \u5C0F\u5B66\u751F\uFF1A\u590F\u4F11\u307F\u304C\u6765\u308B\u305C\u308F\u3041\u3044\uFF01\u3000\u4E2D\u5B66\u751F\uFF1A\u590F\u4F11\u307F\u304C\u6765\u308B\u305C\u308F\u3041\u3044\uFF01\u3000\u9AD8\u6821\uFF11\uFF5E\uFF12\u5E74\u751F\uFF1A\u590F\u4F11\u307F\u304C\u6765\u308B\u305C\u308F\u3041\u3044\uFF01\u3000\u9AD8\u6821\uFF13\u5E74\u751F\uFF1A\u590F\u671F\u8B1B\u7FD2\u3060\u6B7B\u306C\u3000\u5927\u5B66\u751F\uFF1A\u524D\u671F\u5206\u306E\u5358\u4F4D\u843D\u3068\u3057\u305D\u3046\u6B7B\u306C\u3000\u793E\u4F1A\u4EBA\uFF1A\u590F\u4F11\u307F\u306A\u3093\u3066\u7121\u304B\u3063\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86444792980049921",
    "text" : "\u5C0F\u5B66\u751F\uFF1A\u590F\u4F11\u307F\u304C\u6765\u308B\u305C\u308F\u3041\u3044\uFF01\u3000\u4E2D\u5B66\u751F\uFF1A\u590F\u4F11\u307F\u304C\u6765\u308B\u305C\u308F\u3041\u3044\uFF01\u3000\u9AD8\u6821\uFF11\uFF5E\uFF12\u5E74\u751F\uFF1A\u590F\u4F11\u307F\u304C\u6765\u308B\u305C\u308F\u3041\u3044\uFF01\u3000\u9AD8\u6821\uFF13\u5E74\u751F\uFF1A\u590F\u671F\u8B1B\u7FD2\u3060\u6B7B\u306C\u3000\u5927\u5B66\u751F\uFF1A\u524D\u671F\u5206\u306E\u5358\u4F4D\u843D\u3068\u3057\u305D\u3046\u6B7B\u306C\u3000\u793E\u4F1A\u4EBA\uFF1A\u590F\u4F11\u307F\u306A\u3093\u3066\u7121\u304B\u3063\u305F",
    "id" : 86444792980049921,
    "created_at" : "2011-06-30 14:43:39 +0000",
    "user" : {
      "name" : "\u5982\u6708\u30C4\u30F4\u30A1\u30F0\uFF0Aship4",
      "screen_name" : "ZWEIGNW002",
      "protected" : false,
      "id_str" : "105485964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607806971551432704\/xu81lh2n_normal.png",
      "id" : 105485964,
      "verified" : false
    }
  },
  "id" : 86643372927881217,
  "created_at" : "2011-07-01 03:52:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86620274514079744",
  "text" : "RT @Kaibun_bot: \uFF13\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3088\u308A\uFF14\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3055\u3000\uFF08\u3055\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3088\u308A\u3088\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3055\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86619233152286720",
    "text" : "\uFF13\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3088\u308A\uFF14\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3055\u3000\uFF08\u3055\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3088\u308A\u3088\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3055\uFF09 #kaibun",
    "id" : 86619233152286720,
    "created_at" : "2011-07-01 02:16:49 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 86620274514079744,
  "created_at" : "2011-07-01 02:20:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86598577371099136",
  "geo" : { },
  "id_str" : "86599590702362624",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u691C\u7D22\u65B9\u6CD5\u306F\u3072\u3068\u3064\uFF01\u3058\u3083\u306A\u3044\uFF01",
  "id" : 86599590702362624,
  "in_reply_to_status_id" : 86598577371099136,
  "created_at" : "2011-07-01 00:58:46 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86597489276358658",
  "text" : "RT @n_two_ne_b: \u30B5\u30D6\u30ED\u30FC\uFF01\u30B5\u30D6\u30ED\u30FC\uFF01\u3069\u3053\u306B\u884C\u304F\u306E\uFF1F\u540D\u524D\u30FC\uFF01\u540D\u524D\u30FC\uFF01\u304B\u308F\u3063\u3061\u3083\u3046\u306E\uFF01 \u7403\u56E3\u304C\uFF3C\u30CF\u30A4\uFF01\uFF0F\u751F\u3048\u629C\u304D\u3092\uFF3C\u30CF\u30A4\uFF01\uFF0F\u3046\u30FB\u308A\u30FB\u3068\u30FB\u3070\u30FB\u3059\u30FC\uFF3C\u5927\u2606\u6751\u2606\u4E09\u2606\u90CE\u2606\uFF0F\uFF3C( \u309C\u30EE\u309C)\uFF1E \uFF3C(\u309C\u30EE\u309C)\uFF0F \uFF3C(\u309C\u30EE\u309C)\uFF0F \uFF1C(\u309C\u30EE\uFF3E )\uFF0F\u3000 \u300E\u30B5\u30D6\u30ED\u30FC\u306F\u30ED\u30C3\u30C6\uFF01\u3058\u3083\u306A\u3044!!\u300F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86309708641730560",
    "text" : "\u30B5\u30D6\u30ED\u30FC\uFF01\u30B5\u30D6\u30ED\u30FC\uFF01\u3069\u3053\u306B\u884C\u304F\u306E\uFF1F\u540D\u524D\u30FC\uFF01\u540D\u524D\u30FC\uFF01\u304B\u308F\u3063\u3061\u3083\u3046\u306E\uFF01 \u7403\u56E3\u304C\uFF3C\u30CF\u30A4\uFF01\uFF0F\u751F\u3048\u629C\u304D\u3092\uFF3C\u30CF\u30A4\uFF01\uFF0F\u3046\u30FB\u308A\u30FB\u3068\u30FB\u3070\u30FB\u3059\u30FC\uFF3C\u5927\u2606\u6751\u2606\u4E09\u2606\u90CE\u2606\uFF0F\uFF3C( \u309C\u30EE\u309C)\uFF1E \uFF3C(\u309C\u30EE\u309C)\uFF0F \uFF3C(\u309C\u30EE\u309C)\uFF0F \uFF1C(\u309C\u30EE\uFF3E )\uFF0F\u3000 \u300E\u30B5\u30D6\u30ED\u30FC\u306F\u30ED\u30C3\u30C6\uFF01\u3058\u3083\u306A\u3044!!\u300F",
    "id" : 86309708641730560,
    "created_at" : "2011-06-30 05:46:52 +0000",
    "user" : {
      "name" : "\u3064\u306D",
      "screen_name" : "o_two_ne",
      "protected" : false,
      "id_str" : "86948478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561322826754310144\/GMOTBPd7_normal.jpeg",
      "id" : 86948478,
      "verified" : false
    }
  },
  "id" : 86597489276358658,
  "created_at" : "2011-07-01 00:50:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 18, 25 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 27, 37 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86597410872246273",
  "text" : "\u3042\u3086\u3055\u3093\u3001\u73FE\u5B9F\u306F\u53B3\u3057\u3044\u3067\u3059\u3088 RT @ayu167: @end313124 \u304A\u306F\u3088\u3046\u30022\u9650\u304B\u3089\u306F\u9003\u3052\u3093\u306A\u3088",
  "id" : 86597410872246273,
  "created_at" : "2011-07-01 00:50:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "clngn",
      "screen_name" : "clngn",
      "indices" : [ 3, 9 ],
      "id_str" : "93391607",
      "id" : 93391607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86596796347973632",
  "text" : "RT @clngn: \u6570\u5B66\u30AC\u30FC\u30EB\u306E\u7D50\u57CE\u3055\u3093\u304C\u9577\u9580\u30B9\u30AD\u30FC\u3068\u77E5\u3063\u3066\u6226\u6144\u3057\u3066\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.softama.com\/\" rel=\"nofollow\"\u003E\u30C4\u30A4\u30BF\u30DE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86584727577968640",
    "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u7D50\u57CE\u3055\u3093\u304C\u9577\u9580\u30B9\u30AD\u30FC\u3068\u77E5\u3063\u3066\u6226\u6144\u3057\u3066\u308B",
    "id" : 86584727577968640,
    "created_at" : "2011-06-30 23:59:42 +0000",
    "user" : {
      "name" : "clngn",
      "screen_name" : "clngn",
      "protected" : false,
      "id_str" : "93391607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1363356294\/icon_kemzo_normal.png",
      "id" : 93391607,
      "verified" : false
    }
  },
  "id" : 86596796347973632,
  "created_at" : "2011-07-01 00:47:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86595200591466496",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 86595200591466496,
  "created_at" : "2011-07-01 00:41:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86595120471879680",
  "text" : "\u7D50\u5C40\u4E00\u9650\u51FA\u640D\u306A\u3046\u3002\u4E00\u9650\u69D8\u304A\u65AD\u308A\u304B\u3002",
  "id" : 86595120471879680,
  "created_at" : "2011-07-01 00:41:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86594797447561217",
  "text" : "RT @Kaibun_bot: \u79C1\u3001\u6BCE\u65E5\u7740\u3066\u304F\u3082\u306E\u3072\u305F\u3059\u3089\u300C\u53CB\u306B\u300D\u3068\u5DEE\u3057\u51FA\u3057\u3001\u6545\u90F7(\u3055\u3068)\u306B\u623B\u3089\u305A\u65C5\u306E\u76EE\u7684\u5730\u306B\u5C45\u307E\u3057\u305F\u308F\u3000\uFF08\u308F\u305F\u3057\u307E\u3044\u306B\u3061\u304D\u3066\u304F\u3082\u306E\u3072\u305F\u3059\u3089\u3068\u3082\u306B\u3068\u3055\u3057\u3060\u3057\u3055\u3068\u306B\u3082\u3068\u3089\u3059\u305F\u3072\u306E\u3082\u304F\u3066\u304D\u3061\u306B\u3044\u307E\u3057\u305F\u308F\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 93, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86574029678452736",
    "text" : "\u79C1\u3001\u6BCE\u65E5\u7740\u3066\u304F\u3082\u306E\u3072\u305F\u3059\u3089\u300C\u53CB\u306B\u300D\u3068\u5DEE\u3057\u51FA\u3057\u3001\u6545\u90F7(\u3055\u3068)\u306B\u623B\u3089\u305A\u65C5\u306E\u76EE\u7684\u5730\u306B\u5C45\u307E\u3057\u305F\u308F\u3000\uFF08\u308F\u305F\u3057\u307E\u3044\u306B\u3061\u304D\u3066\u304F\u3082\u306E\u3072\u305F\u3059\u3089\u3068\u3082\u306B\u3068\u3055\u3057\u3060\u3057\u3055\u3068\u306B\u3082\u3068\u3089\u3059\u305F\u3072\u306E\u3082\u304F\u3066\u304D\u3061\u306B\u3044\u307E\u3057\u305F\u308F\uFF09 #kaibun",
    "id" : 86574029678452736,
    "created_at" : "2011-06-30 23:17:11 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 86594797447561217,
  "created_at" : "2011-07-01 00:39:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86467201447636993",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u306F\u3044\u3001\u30AB\u30AF\u30C6\u30EB\u306E\u8A71\u3067\u3059\u3002\u3082\u3068\u3082\u3068\u4EBA\u306E\u540D\u524D\u307F\u305F\u3044\u3060\u3057\u7531\u6765\u306F\u4E00\u7DD2\u304B\u3082\u3057\u308C\u306A\u3044\u3051\u3069\u306D\u30FC\u3002\n\u3044\u3084\u3001\u307E\u3041\u30D5\u30EA\u30D5\u30EA\u306E\u6D0B\u670D\u3082\u5ACC\u3044\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u3069\u3055\u2190",
  "id" : 86467201447636993,
  "created_at" : "2011-06-30 16:12:41 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86465767658373120",
  "geo" : { },
  "id_str" : "86466224183189504",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3044\u3084\u3001\u306A\u3093\u304B\u3061\u3087\u3063\u3068\u304A\u6D12\u843D\u306A\uFF8A\uFF9E\uFF70\u307F\u305F\u3044\u306A\u6240\u3067\u6CE8\u6587\u3057\u305F\u306E\u3067\u3059\u3088\u3002",
  "id" : 86466224183189504,
  "in_reply_to_status_id" : 86465767658373120,
  "created_at" : "2011-06-30 16:08:48 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86464294094503936",
  "text" : "\u30B7\u30E3\u30FC\u30EA\u30FC\u30C6\u30F3\u30D7\u30EB\u3092\u30B7\u30E5\u30E9\u30A4\u30F3\u30C6\u30F3\u30D7\u30EB\u3068\u9593\u9055\u3048\u3066\u3044\u305F\u2026\u6065\u305A\u304B\u3057\u3044\u3002\u5B9F\u969B\u795E\u793E\u306A\u3093\u3060\u304B\u5BFA\u306A\u3093\u3060\u304B\u308F\u304B\u3093\u306A\u3044\u3063\u3066\u8A00\u3063\u305F\u8A18\u61B6\u304C\u2026\u91CD\u306D\u3066\u6065\u305A\u304B\u3057\u3044\u3002",
  "id" : 86464294094503936,
  "created_at" : "2011-06-30 16:01:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86460611181019136",
  "text" : "@ayu167 \u51FA\u6765\u308B\u306A\u3089\u4EBA\u53E3\u7121\u80FD\u307E\u3067\u5165\u308C\u305F\u3044\u3051\u3069\u306D\u3047\u3002UMA\u306E\u89E3\u8AAC\u3068\u304B\uFF1F\uFF57\uFF57",
  "id" : 86460611181019136,
  "created_at" : "2011-06-30 15:46:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86460106258132993",
  "text" : "\uFF16\u6587\u5B57\u3057\u308A\u53D6\u308A\u3084\u3063\u3066\u3066\u5C71\u672C\u5C71\u3063\u3066\u8A00\u3063\u305F\u3089\u8AB0\u3082\u77E5\u3089\u306A\u304F\u3066\u51F9\u3093\u3060",
  "id" : 86460106258132993,
  "created_at" : "2011-06-30 15:44:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86459892809998336",
  "text" : "\u4E0A\u304B\u3089\u8AAD\u3093\u3067\u3082\u3001\u4E0B\u304B\u3089\u8AAD\u3093\u3067\u3082\u300C\u5C71\u672C\u5C71\u300D\u3063\u3066\u6D77\u82D4\u304B\u4F55\u304B\u306E\u30E1\u30FC\u30AB\u30FC\u77E5\u3063\u3066\u308B\u4EBA\u306F\u516C\u5F0FRT",
  "id" : 86459892809998336,
  "created_at" : "2011-06-30 15:43:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86459068755091456",
  "text" : "\u4FFA\u3001\u8A66\u9A13\u671F\u9593\u304C\u7D42\u308F\u3063\u305F\u3089\u3001\u8EAB\u5185\u30CD\u30BFbot\u4F5C\u308B\u3093\u3060\u2026",
  "id" : 86459068755091456,
  "created_at" : "2011-06-30 15:40:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86457275618820097",
  "geo" : { },
  "id_str" : "86457553596321793",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u306A\u3093\u304B\u306E\u30CD\u30BF\u30D0\u30EC\u898B\u305F\u304F\u306A\u304B\u3063\u305F\u306E\u3067\u5916\u3057\u3066\u307E\u3057\u305F\u3001\u3059\u307F\u307E\u305B\u3093\u3002",
  "id" : 86457553596321793,
  "in_reply_to_status_id" : 86457275618820097,
  "created_at" : "2011-06-30 15:34:21 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86456432102359040",
  "geo" : { },
  "id_str" : "86457172287950848",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u50ED\u8D8A\u306A\u304C\u3089\u79C1\u3081\u304C\u512A\u52DD\u3057\u307E\u3057\u305F\u3002\u5CA9\u4E95\u3055\u3093\u3068\u8D85\u50C5\u5DEE\u3067\u3057\u305F\u3051\u3069\u3002",
  "id" : 86457172287950848,
  "in_reply_to_status_id" : 86456432102359040,
  "created_at" : "2011-06-30 15:32:50 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86455990765105153",
  "text" : "\u3061\u3087\u3063\u3068\u65E9\u3044\u3051\u3069\u5BDD\u308B\u304B\u2026\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 86455990765105153,
  "created_at" : "2011-06-30 15:28:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]